<?php
/**
 * Front page template
 *
 * @package GlowGridGrace
 */

get_header();
?>

<div class="relative">
    <main>
        <?php get_template_part('template-parts/sections/hero'); ?>
        <?php get_template_part('template-parts/sections/services'); ?>
        <?php get_template_part('template-parts/sections/case-studies'); ?>
        <?php get_template_part('template-parts/sections/about'); ?>
        <?php get_template_part('template-parts/sections/contact'); ?>
    </main>
</div>

<?php
get_footer();
