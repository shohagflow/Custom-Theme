<?php
/**
 * Glow Grid Grace Theme Functions
 *
 * @package GlowGridGrace
 */

if (!defined('ABSPATH')) {
    exit;
}

// Theme setup
function glow_grid_grace_setup() {
    // Add theme support
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption'));
    add_theme_support('custom-logo');
    add_theme_support('responsive-embeds');
    
    // Register navigation menus
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'glow-grid-grace'),
    ));
}
add_action('after_setup_theme', 'glow_grid_grace_setup');

// Enqueue scripts and styles
function glow_grid_grace_scripts() {
    $theme_version = wp_get_theme()->get('Version');
    
    // Custom styles (includes Tailwind utilities)
    wp_enqueue_style('glow-grid-grace-style', get_stylesheet_uri(), array(), $theme_version);
    wp_enqueue_style('glow-grid-grace-main', get_template_directory_uri() . '/assets/css/main.css', array(), $theme_version);
    
    // Scripts
    wp_enqueue_script('lenis', 'https://cdn.jsdelivr.net/npm/@studio-freight/lenis@1.0.42/dist/lenis.min.js', array(), '1.0.42', true);
    wp_enqueue_script('glow-grid-grace-main', get_template_directory_uri() . '/assets/js/main.js', array('jquery', 'lenis'), $theme_version, true);
    
    // Localize script for AJAX
    wp_localize_script('glow-grid-grace-main', 'glowGridGrace', array(
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('glow_grid_grace_nonce'),
    ));
}
add_action('wp_enqueue_scripts', 'glow_grid_grace_scripts');

// Register Services Custom Post Type
function glow_grid_grace_register_services() {
    $labels = array(
        'name' => _x('Services', 'Post type general name', 'glow-grid-grace'),
        'singular_name' => _x('Service', 'Post type singular name', 'glow-grid-grace'),
        'menu_name' => _x('Services', 'Admin Menu text', 'glow-grid-grace'),
        'add_new' => __('Add New', 'glow-grid-grace'),
        'add_new_item' => __('Add New Service', 'glow-grid-grace'),
        'edit_item' => __('Edit Service', 'glow-grid-grace'),
        'new_item' => __('New Service', 'glow-grid-grace'),
        'view_item' => __('View Service', 'glow-grid-grace'),
        'search_items' => __('Search Services', 'glow-grid-grace'),
    );

    $args = array(
        'labels' => $labels,
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'query_var' => true,
        'rewrite' => array('slug' => 'services'),
        'capability_type' => 'post',
        'has_archive' => true,
        'hierarchical' => false,
        'menu_position' => 20,
        'menu_icon' => 'dashicons-admin-tools',
        'supports' => array('title', 'editor', 'thumbnail', 'excerpt', 'custom-fields'),
        'show_in_rest' => true,
    );

    register_post_type('service', $args);
}
add_action('init', 'glow_grid_grace_register_services');

// Register Case Studies Custom Post Type
function glow_grid_grace_register_case_studies() {
    $labels = array(
        'name' => _x('Case Studies', 'Post type general name', 'glow-grid-grace'),
        'singular_name' => _x('Case Study', 'Post type singular name', 'glow-grid-grace'),
        'menu_name' => _x('Case Studies', 'Admin Menu text', 'glow-grid-grace'),
    );

    $args = array(
        'labels' => $labels,
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'query_var' => true,
        'rewrite' => array('slug' => 'case-studies'),
        'capability_type' => 'post',
        'has_archive' => true,
        'hierarchical' => false,
        'menu_position' => 21,
        'menu_icon' => 'dashicons-portfolio',
        'supports' => array('title', 'editor', 'thumbnail', 'excerpt', 'custom-fields'),
        'show_in_rest' => true,
    );

    register_post_type('case_study', $args);
}
add_action('init', 'glow_grid_grace_register_case_studies');

// Add custom meta boxes for Services
function glow_grid_grace_add_service_meta_boxes() {
    add_meta_box(
        'service_details',
        __('Service Details', 'glow-grid-grace'),
        'glow_grid_grace_service_meta_box_callback',
        'service',
        'normal',
        'high'
    );
}
add_action('add_meta_boxes', 'glow_grid_grace_add_service_meta_boxes');

function glow_grid_grace_service_meta_box_callback($post) {
    wp_nonce_field('glow_grid_grace_save_service_meta', 'glow_grid_grace_service_meta_nonce');
    
    $service_number = get_post_meta($post->ID, '_service_number', true);
    $service_short_title = get_post_meta($post->ID, '_service_short_title', true);
    $service_tagline = get_post_meta($post->ID, '_service_tagline', true);
    $service_description = get_post_meta($post->ID, '_service_description', true);
    $service_features = get_post_meta($post->ID, '_service_features', true);
    $service_technologies = get_post_meta($post->ID, '_service_technologies', true);
    $related_case_studies = get_post_meta($post->ID, '_related_case_studies', true);
    
    ?>
    <table class="form-table">
        <tr>
            <th><label for="service_number"><?php _e('Service Number', 'glow-grid-grace'); ?></label></th>
            <td><input type="text" id="service_number" name="service_number" value="<?php echo esc_attr($service_number); ?>" class="regular-text" /></td>
        </tr>
        <tr>
            <th><label for="service_short_title"><?php _e('Short Title', 'glow-grid-grace'); ?></label></th>
            <td><input type="text" id="service_short_title" name="service_short_title" value="<?php echo esc_attr($service_short_title); ?>" class="regular-text" /></td>
        </tr>
        <tr>
            <th><label for="service_tagline"><?php _e('Tagline', 'glow-grid-grace'); ?></label></th>
            <td><input type="text" id="service_tagline" name="service_tagline" value="<?php echo esc_attr($service_tagline); ?>" class="regular-text" /></td>
        </tr>
        <tr>
            <th><label for="service_description"><?php _e('Short Description', 'glow-grid-grace'); ?></label></th>
            <td><textarea id="service_description" name="service_description" rows="3" class="large-text"><?php echo esc_textarea($service_description); ?></textarea></td>
        </tr>
        <tr>
            <th><label for="service_features"><?php _e('Features (one per line)', 'glow-grid-grace'); ?></label></th>
            <td><textarea id="service_features" name="service_features" rows="10" class="large-text"><?php echo esc_textarea($service_features); ?></textarea></td>
        </tr>
        <tr>
            <th><label for="service_technologies"><?php _e('Technologies (JSON format)', 'glow-grid-grace'); ?></label></th>
            <td><textarea id="service_technologies" name="service_technologies" rows="10" class="large-text"><?php echo esc_textarea($service_technologies); ?></textarea>
            <p class="description">Format: [{"name":"React","category":"Frontend"},{"name":"Node.js","category":"Backend"}]</p></td>
        </tr>
    </table>
    <?php
}

function glow_grid_grace_save_service_meta($post_id) {
    if (!isset($_POST['glow_grid_grace_service_meta_nonce']) || 
        !wp_verify_nonce($_POST['glow_grid_grace_service_meta_nonce'], 'glow_grid_grace_save_service_meta')) {
        return;
    }

    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }

    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    $fields = array('service_number', 'service_short_title', 'service_tagline', 'service_description', 'service_features', 'service_technologies');
    
    foreach ($fields as $field) {
        if (isset($_POST[$field])) {
            update_post_meta($post_id, '_' . $field, sanitize_text_field($_POST[$field]));
        }
    }
}
add_action('save_post', 'glow_grid_grace_save_service_meta');

// Helper function to get services
function glow_grid_grace_get_services($args = array()) {
    $defaults = array(
        'post_type' => 'service',
        'posts_per_page' => -1,
        'orderby' => 'menu_order',
        'order' => 'ASC',
        'post_status' => 'publish',
    );
    
    $args = wp_parse_args($args, $defaults);
    
    // Handle post__not_in for excluding posts
    if (isset($args['post__not_in']) && !empty($args['post__not_in'])) {
        $args['post__not_in'] = (array) $args['post__not_in'];
    }
    
    return get_posts($args);
}

// Helper function to get case studies
function glow_grid_grace_get_case_studies($args = array()) {
    $defaults = array(
        'post_type' => 'case_study',
        'posts_per_page' => -1,
        'orderby' => 'date',
        'order' => 'DESC',
        'post_status' => 'publish',
    );
    
    $args = wp_parse_args($args, $defaults);
    return get_posts($args);
}

// Add body classes
function glow_grid_grace_body_classes($classes) {
    if (is_front_page()) {
        $classes[] = 'home-page';
    }
    return $classes;
}
add_filter('body_class', 'glow_grid_grace_body_classes');

// Remove WordPress version from head
remove_action('wp_head', 'wp_generator');
