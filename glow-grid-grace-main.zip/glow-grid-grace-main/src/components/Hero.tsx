import { motion } from 'framer-motion';
import { ArrowDown } from 'lucide-react';

const Hero = () => {
  const words = ['Impulsamos', 'la', 'competitividad'];
  const subWords = ['de las organizaciones', 'con tecnologías abiertas', 'e innovadoras'];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15,
        delayChildren: 0.3,
      },
    },
  };

  const wordVariants = {
    hidden: { y: 80, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.8,
        ease: [0.25, 0.46, 0.45, 0.94] as const,
      },
    },
  };

  return (
    <section className="relative min-h-screen surface-light grid-pattern flex items-center justify-center overflow-hidden">
      {/* Animated Grid Lines */}
      <div className="absolute inset-0 pointer-events-none">
        <motion.div
          animate={{ y: [0, 60] }}
          transition={{ duration: 3, repeat: Infinity, ease: 'linear' }}
          className="absolute inset-0 grid-pattern opacity-50"
        />
      </div>

      {/* Green Accent Element */}
      <motion.div
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 1.2, delay: 1 }}
        className="absolute top-1/4 right-1/4 w-32 h-48 md:w-48 md:h-72 bg-neon rounded-t-full"
      />

      <div className="relative z-10 container px-6 md:px-12 pt-32">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="max-w-[1400px] mx-auto"
        >
          {/* Main Headline */}
          <div className="mb-6">
            {words.map((word, index) => (
              <motion.span
                key={index}
                variants={wordVariants}
                className="headline-massive block md:inline-block md:mr-6"
              >
                {word}
              </motion.span>
            ))}
          </div>

          {/* Subheadline */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.9 }}
            className="mt-8 md:mt-12"
          >
            {subWords.map((line, index) => (
              <span
                key={index}
                className="text-xl md:text-2xl lg:text-3xl font-display font-medium text-muted-foreground block"
              >
                {line}
              </span>
            ))}
          </motion.div>

          {/* Description */}
          <motion.p
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 1.2 }}
            className="mt-12 max-w-xl text-base md:text-lg text-muted-foreground leading-relaxed"
          >
            Somos una ingeniería tecnológica especializada en soluciones avanzadas open source, 
            referente en el ámbito nacional.
          </motion.p>

          {/* CTA */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 1.4 }}
            className="mt-12 flex flex-wrap gap-4"
          >
            <button className="group flex items-center gap-3 px-8 py-4 bg-primary text-primary-foreground font-medium rounded-full hover:bg-neon-lime hover:text-accent-foreground transition-all duration-300">
              Ver servicios
              <ArrowDown className="w-4 h-4 group-hover:translate-y-1 transition-transform" />
            </button>
            <button className="px-8 py-4 border border-primary/20 font-medium rounded-full hover:border-primary/50 transition-colors">
              Contactar
            </button>
          </motion.div>
        </motion.div>
      </div>

      {/* Scroll Indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.8, delay: 2 }}
        className="absolute bottom-12 left-1/2 -translate-x-1/2 flex flex-col items-center gap-3"
      >
        <span className="text-xs font-medium tracking-widest text-muted-foreground uppercase">Scroll</span>
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{ duration: 1.5, repeat: Infinity, ease: 'easeInOut' }}
        >
          <ArrowDown className="w-5 h-5 text-muted-foreground" />
        </motion.div>
      </motion.div>
    </section>
  );
};

export default Hero;
