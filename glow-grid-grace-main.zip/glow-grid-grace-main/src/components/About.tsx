import { motion } from 'framer-motion';

const stats = [
  { value: '20+', label: 'Años de experiencia' },
  { value: '500+', label: 'Proyectos completados' },
  { value: '100+', label: 'Profesionales' },
  { value: '98%', label: 'Clientes satisfechos' },
];

const About = () => {
  return (
    <section id="about" className="surface-dark py-24 md:py-32 lg:py-40 relative overflow-hidden">
      <div className="container px-6 md:px-12 max-w-[1800px] mx-auto">
        {/* Section Label */}
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          whileInView={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="mb-16"
        >
          <span className="text-xs font-medium tracking-widest uppercase" style={{ color: 'rgba(255,255,255,0.5)' }}>
            Sobre nosotros
          </span>
        </motion.div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-24">
          {/* Left Column - Big Quote */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2
              className="text-3xl md:text-4xl lg:text-5xl font-display font-bold leading-tight"
              style={{ color: 'white' }}
            >
              La suma de nuestro conocimiento y experiencia dan como resultado un servicio único,
              <span style={{ color: 'hsl(68, 100%, 50%)' }}> estratégicamente orientado a conseguir la consecución de tus objetivos y los de tu compañía.</span>
            </h2>
          </motion.div>

          {/* Right Column - Description & Stats */}
          <div>
            <motion.p
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              viewport={{ once: true }}
              className="text-lg leading-relaxed mb-12"
              style={{ color: 'rgba(255,255,255,0.7)' }}
            >
              Somos una ingeniería tecnológica con más de 20 años de experiencia, 
              especializados en soluciones avanzadas open source. Nuestro equipo 
              de profesionales altamente cualificados trabaja para transformar 
              digitalmente tu negocio con las mejores tecnologías del mercado.
            </motion.p>

            {/* Stats Grid */}
            <div className="grid grid-cols-2 gap-8">
              {stats.map((stat, index) => (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.3 + index * 0.1 }}
                  viewport={{ once: true }}
                  className="border-t pt-6"
                  style={{ borderColor: 'rgba(255,255,255,0.1)' }}
                >
                  <span
                    className="block text-4xl md:text-5xl font-display font-bold mb-2"
                    style={{ color: 'hsl(68, 100%, 50%)' }}
                  >
                    {stat.value}
                  </span>
                  <span
                    className="text-sm"
                    style={{ color: 'rgba(255,255,255,0.5)' }}
                  >
                    {stat.label}
                  </span>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
