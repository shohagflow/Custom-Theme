import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, ArrowUpRight } from 'lucide-react';
import { services } from '@/data/services';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();

  const mainMenuItems = [
    { label: 'Inicio', href: '/' },
    { label: 'Servicios', href: '/services' },
    { label: 'Casos de Éxito', href: '/#cases' },
    { label: 'Nosotros', href: '/#about' },
    { label: 'Contacto', href: '/#contact' },
  ];

  const isActive = (href: string) => {
    if (href === '/') return location.pathname === '/';
    return location.pathname.startsWith(href.replace('/#', ''));
  };

  return (
    <>
      <motion.header
        initial={{ y: -100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.8, ease: [0.25, 0.46, 0.45, 0.94] as const }}
        className="glass-header fixed top-0 left-0 right-0 z-50 px-6 md:px-12 py-4"
      >
        <div className="flex items-center justify-between max-w-[1800px] mx-auto">
          <Link to="/">
            <motion.div
              whileHover={{ scale: 1.02 }}
              className="font-display text-2xl md:text-3xl font-bold tracking-tight"
            >
              Irontec<span className="text-neon">.</span>
            </motion.div>
          </Link>

          <nav className="hidden lg:flex items-center gap-8">
            {mainMenuItems.map((item) => (
              <Link
                key={item.label}
                to={item.href}
                className={`link-underline text-sm font-medium tracking-wide transition-colors ${
                  isActive(item.href) ? 'text-foreground' : 'text-foreground/60 hover:text-foreground'
                }`}
              >
                {item.label}
              </Link>
            ))}
          </nav>

          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="flex items-center gap-2 text-sm font-medium tracking-wide"
          >
            <span className="hidden md:block">Menu</span>
            <motion.div
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </motion.div>
          </button>
        </div>
      </motion.header>

      {/* Full Screen Menu */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-0 z-40 surface-dark overflow-y-auto"
          >
            <div className="min-h-screen pt-24 pb-12 px-6 md:px-12">
              <div className="max-w-[1800px] mx-auto grid grid-cols-1 lg:grid-cols-2 gap-16">
                {/* Left Column - Main Navigation */}
                <div>
                  <motion.span
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4, delay: 0.1 }}
                    className="text-xs font-medium tracking-widest uppercase mb-8 block"
                    style={{ color: 'rgba(255,255,255,0.5)' }}
                  >
                    Navegación
                  </motion.span>
                  <nav className="space-y-4">
                    {mainMenuItems.map((item, index) => (
                      <motion.div
                        key={item.label}
                        initial={{ y: 30, opacity: 0 }}
                        animate={{ y: 0, opacity: 1 }}
                        exit={{ y: 30, opacity: 0 }}
                        transition={{ duration: 0.4, delay: 0.1 + index * 0.05 }}
                      >
                        <Link
                          to={item.href}
                          onClick={() => setIsMenuOpen(false)}
                          className="group flex items-center justify-between py-3 border-b transition-colors duration-300"
                          style={{ 
                            borderColor: 'rgba(255,255,255,0.1)',
                            color: 'white'
                          }}
                        >
                          <span className="text-4xl md:text-5xl lg:text-6xl font-display font-bold group-hover:text-accent transition-colors duration-300">
                            {item.label}
                          </span>
                          <ArrowUpRight 
                            className="w-6 h-6 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                            style={{ color: 'hsl(68, 100%, 50%)' }}
                          />
                        </Link>
                      </motion.div>
                    ))}
                  </nav>
                </div>

                {/* Right Column - Services */}
                <div>
                  <motion.span
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4, delay: 0.2 }}
                    className="text-xs font-medium tracking-widest uppercase mb-8 block"
                    style={{ color: 'rgba(255,255,255,0.5)' }}
                  >
                    Servicios
                  </motion.span>
                  <nav className="space-y-3">
                    {services.map((service, index) => (
                      <motion.div
                        key={service.id}
                        initial={{ y: 20, opacity: 0 }}
                        animate={{ y: 0, opacity: 1 }}
                        exit={{ y: 20, opacity: 0 }}
                        transition={{ duration: 0.4, delay: 0.2 + index * 0.05 }}
                      >
                        <Link
                          to={`/services/${service.id}`}
                          onClick={() => setIsMenuOpen(false)}
                          className="group flex items-center gap-4 py-3 transition-colors duration-300"
                        >
                          <span
                            className="text-sm font-medium group-hover:text-accent transition-colors duration-300"
                            style={{ color: 'rgba(255,255,255,0.4)' }}
                          >
                            {service.number}
                          </span>
                          <span
                            className="text-xl md:text-2xl font-display font-medium group-hover:text-accent transition-colors duration-300"
                            style={{ color: 'white' }}
                          >
                            {service.title}
                          </span>
                          <ArrowUpRight 
                            className="w-5 h-5 opacity-0 group-hover:opacity-100 transition-all duration-300 group-hover:translate-x-1 group-hover:-translate-y-1"
                            style={{ color: 'hsl(68, 100%, 50%)' }}
                          />
                        </Link>
                      </motion.div>
                    ))}
                  </nav>

                  {/* Contact Info */}
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4, delay: 0.5 }}
                    className="mt-16 pt-8 border-t"
                    style={{ borderColor: 'rgba(255,255,255,0.1)' }}
                  >
                    <span
                      className="text-xs font-medium tracking-widest uppercase mb-4 block"
                      style={{ color: 'rgba(255,255,255,0.5)' }}
                    >
                      Contacto
                    </span>
                    <a
                      href="mailto:info@irontec.com"
                      className="block text-xl font-display mb-2 hover:text-accent transition-colors"
                      style={{ color: 'white' }}
                    >
                      info@irontec.com
                    </a>
                    <a
                      href="tel:+34944048182"
                      className="block text-xl font-display hover:text-accent transition-colors"
                      style={{ color: 'white' }}
                    >
                      +34 944 048 182
                    </a>
                  </motion.div>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default Header;
