import { motion, useScroll, useTransform } from 'framer-motion';
import { useRef } from 'react';
import { ArrowUpRight } from 'lucide-react';

import caseStudy1 from '@/assets/case-study-1.jpg';
import caseStudy2 from '@/assets/case-study-2.jpg';
import heroTech from '@/assets/hero-tech.jpg';
import caseStudy4 from '@/assets/case-study-4.jpg';

const cases = [
  {
    title: 'Irontela',
    category: 'Telecomunicaciones',
    image: heroTech,
  },
  {
    title: 'GM Food',
    category: 'Distribución alimentaria',
    image: caseStudy1,
  },
  {
    title: 'Grupo Euskaltel',
    category: 'Telecomunicaciones',
    image: caseStudy2,
  },
  {
    title: 'Euskalmet',
    category: 'Gobierno Vasco',
    image: caseStudy4,
  },
];

const CaseStudies = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ['start end', 'end start'],
  });

  const parallaxY = useTransform(scrollYProgress, [0, 1], [100, -100]);

  return (
    <section id="cases" ref={containerRef} className="relative surface-light section-premium overflow-hidden">
      {/* Parallax Background Text */}
      <motion.div
        style={{ y: parallaxY }}
        className="absolute top-0 left-0 w-full pointer-events-none select-none"
      >
        <span className="parallax-text block">CASOS</span>
        <span className="parallax-text block text-right">DE ÉXITO</span>
      </motion.div>

      <div className="relative z-10 container px-6 md:px-12">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="mb-16 md:mb-24"
        >
          <span className="text-xs font-medium tracking-widest text-muted-foreground uppercase">
            Casos de éxito
          </span>
        </motion.div>

        {/* Cases Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12">
          {cases.map((caseItem, index) => (
            <motion.article
              key={caseItem.title}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: index * 0.15 }}
              viewport={{ once: true, margin: '-100px' }}
              className={`group cursor-pointer ${index % 3 === 0 ? 'md:col-span-1' : ''}`}
            >
              {/* Image Container */}
              <div className="image-zoom aspect-[4/3] rounded-lg mb-6 relative overflow-hidden bg-muted">
                <img
                  src={caseItem.image}
                  alt={caseItem.title}
                  className="w-full h-full object-cover"
                />
                {/* Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-foreground/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                
                {/* Arrow */}
                <motion.div
                  initial={{ opacity: 0, scale: 0.8 }}
                  whileHover={{ opacity: 1, scale: 1 }}
                  className="absolute top-4 right-4 w-12 h-12 bg-background rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                >
                  <ArrowUpRight className="w-5 h-5" />
                </motion.div>
              </div>

              {/* Content */}
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="text-xl md:text-2xl font-display font-bold mb-1 group-hover:text-neon-lime transition-colors duration-300">
                    {caseItem.title}
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    {caseItem.category}
                  </p>
                </div>
              </div>
            </motion.article>
          ))}
        </div>

        {/* View All Link */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          viewport={{ once: true }}
          className="mt-16 md:mt-24 text-center"
        >
          <a
            href="#"
            className="inline-flex items-center gap-3 text-lg font-medium link-underline group"
          >
            Ver todos los casos
            <ArrowUpRight className="w-5 h-5 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
          </a>
        </motion.div>
      </div>
    </section>
  );
};

export default CaseStudies;
