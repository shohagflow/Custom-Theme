import { motion } from 'framer-motion';
import { ArrowUpRight, Mail, MapPin, Phone } from 'lucide-react';

const Contact = () => {
  return (
    <section id="contact" className="surface-light section-premium relative overflow-hidden">
      <div className="container px-6 md:px-12 max-w-[1800px] mx-auto">
        {/* CTA Banner */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="bg-primary text-primary-foreground rounded-3xl p-8 md:p-16 lg:p-24 mb-24 relative overflow-hidden"
        >
          {/* Decorative Element */}
          <div className="absolute -right-20 -bottom-20 w-64 h-64 bg-neon rounded-full opacity-20" />
          
          <div className="relative z-10 max-w-3xl">
            <h2 className="headline-large mb-6">
              Si tú también quieres aliarte con Irontec para impulsar la competitividad de tu organización, escríbenos.
            </h2>
            <p className="text-lg opacity-70 mb-8">
              Nos gustan los retos.
            </p>
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="inline-flex items-center gap-3 px-8 py-4 bg-neon text-accent-foreground font-medium rounded-full hover:opacity-90 transition-opacity"
            >
              Contactar ahora
              <ArrowUpRight className="w-5 h-5" />
            </motion.button>
          </div>
        </motion.div>

        {/* Contact Info Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 md:gap-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="flex items-start gap-4"
          >
            <div className="w-12 h-12 rounded-full bg-secondary flex items-center justify-center flex-shrink-0">
              <Mail className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-display font-bold mb-2">Email</h3>
              <a href="mailto:info@irontec.com" className="link-underline text-muted-foreground hover:text-foreground transition-colors">
                info@irontec.com
              </a>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            viewport={{ once: true }}
            className="flex items-start gap-4"
          >
            <div className="w-12 h-12 rounded-full bg-secondary flex items-center justify-center flex-shrink-0">
              <Phone className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-display font-bold mb-2">Teléfono</h3>
              <a href="tel:+34944048182" className="link-underline text-muted-foreground hover:text-foreground transition-colors">
                +34 944 048 182
              </a>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            viewport={{ once: true }}
            className="flex items-start gap-4"
          >
            <div className="w-12 h-12 rounded-full bg-secondary flex items-center justify-center flex-shrink-0">
              <MapPin className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-display font-bold mb-2">Ubicación</h3>
              <p className="text-muted-foreground">
                Bilbao, España
              </p>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
