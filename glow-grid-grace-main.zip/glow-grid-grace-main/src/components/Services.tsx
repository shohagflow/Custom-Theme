import { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowUpRight } from 'lucide-react';
import { services } from '@/data/services';

const Services = () => {
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  return (
    <section id="services" className="surface-dark py-24 md:py-32 lg:py-40 relative overflow-hidden">
      {/* Section Label */}
      <motion.div
        initial={{ opacity: 0, x: -30 }}
        whileInView={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.6 }}
        viewport={{ once: true }}
        className="container px-6 md:px-12 mb-16"
      >
        <span className="text-xs font-medium tracking-widest text-muted-foreground uppercase" style={{ color: 'rgba(255,255,255,0.5)' }}>
          Servicios
        </span>
      </motion.div>

      {/* Services List */}
      <div className="container px-6 md:px-12 max-w-[1800px] mx-auto">
        {services.map((service, index) => (
          <motion.div
            key={service.number}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: index * 0.1 }}
            viewport={{ once: true }}
            onMouseEnter={() => setHoveredIndex(index)}
            onMouseLeave={() => setHoveredIndex(null)}
            className="group relative border-t py-8 md:py-12 cursor-pointer transition-all duration-500"
            style={{ borderColor: 'rgba(255,255,255,0.1)' }}
          >
            <Link to={`/services/${service.id}`} className="block">
              <div className="flex items-center justify-between">
                <div className="flex items-start gap-6 md:gap-12">
                  {/* Number */}
                  <span
                    className="text-sm font-medium transition-colors duration-300"
                    style={{ color: hoveredIndex === index ? 'hsl(68, 100%, 50%)' : 'rgba(255,255,255,0.4)' }}
                  >
                    {service.number}
                  </span>

                  {/* Title & Description */}
                  <div>
                    <h3
                      className="text-3xl md:text-4xl lg:text-5xl font-display font-bold tracking-tight transition-colors duration-300"
                      style={{ color: hoveredIndex === index ? 'hsl(68, 100%, 50%)' : 'white' }}
                    >
                      {service.title}
                    </h3>
                    <motion.p
                      initial={{ height: 0, opacity: 0 }}
                      animate={{
                        height: hoveredIndex === index ? 'auto' : 0,
                        opacity: hoveredIndex === index ? 1 : 0,
                      }}
                      transition={{ duration: 0.3 }}
                      className="mt-4 text-base md:text-lg max-w-md overflow-hidden"
                      style={{ color: 'rgba(255,255,255,0.6)' }}
                    >
                      {service.description}
                    </motion.p>
                  </div>
                </div>

                {/* Arrow */}
                <motion.div
                  animate={{
                    x: hoveredIndex === index ? 0 : -10,
                    opacity: hoveredIndex === index ? 1 : 0,
                  }}
                  transition={{ duration: 0.3 }}
                >
                  <ArrowUpRight
                    className="w-8 h-8 md:w-10 md:h-10"
                    style={{ color: 'hsl(68, 100%, 50%)' }}
                  />
                </motion.div>
              </div>

              {/* Hover Image */}
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{
                  opacity: hoveredIndex === index ? 1 : 0,
                  scale: hoveredIndex === index ? 1 : 0.9,
                }}
                transition={{ duration: 0.4 }}
                className="absolute right-12 md:right-24 top-1/2 -translate-y-1/2 w-48 md:w-64 h-32 md:h-40 rounded-lg overflow-hidden pointer-events-none hidden lg:block"
              >
                <img
                  src={service.heroImage}
                  alt={service.title}
                  className="w-full h-full object-cover"
                />
              </motion.div>
            </Link>
          </motion.div>
        ))}

        {/* Last border */}
        <div className="border-t" style={{ borderColor: 'rgba(255,255,255,0.1)' }} />

        {/* View All Link */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          viewport={{ once: true }}
          className="mt-12 text-center"
        >
          <Link
            to="/services"
            className="inline-flex items-center gap-3 text-lg font-medium group"
            style={{ color: 'white' }}
          >
            <span className="group-hover:text-accent transition-colors duration-300">
              Ver todos los servicios
            </span>
            <ArrowUpRight 
              className="w-5 h-5 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform"
              style={{ color: 'hsl(68, 100%, 50%)' }}
            />
          </Link>
        </motion.div>
      </div>
    </section>
  );
};

export default Services;
