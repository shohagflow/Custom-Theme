import caseStudy1 from '@/assets/case-study-1.jpg';
import caseStudy2 from '@/assets/case-study-2.jpg';
import caseStudy3 from '@/assets/case-study-3.jpg';
import caseStudy4 from '@/assets/case-study-4.jpg';
import heroTech from '@/assets/hero-tech.jpg';

export interface Service {
  id: string;
  number: string;
  title: string;
  shortTitle: string;
  tagline: string;
  description: string;
  longDescription: string;
  features: string[];
  technologies: { name: string; category: string }[];
  caseStudies: {
    title: string;
    category: string;
    description: string;
    image: string;
  }[];
  heroImage: string;
}

export const services: Service[] = [
  {
    id: 'cloud-it-business',
    number: '01',
    title: 'Cloud & IT Business',
    shortTitle: 'Cloud & IT',
    tagline: 'Infraestructura escalable para tu negocio',
    description: 'Infraestructura cloud escalable y gestión IT empresarial',
    longDescription: 'Diseñamos, implementamos y gestionamos infraestructuras cloud que permiten a tu organización escalar sin límites. Nuestros servicios de IT Business garantizan la continuidad operativa y la optimización de recursos tecnológicos.',
    features: [
      'Migración a la nube (AWS, Azure, GCP)',
      'Arquitectura de microservicios',
      'DevOps y CI/CD pipelines',
      'Monitorización y observabilidad',
      'Gestión de infraestructura como código',
      'Disaster recovery y backup',
    ],
    technologies: [
      { name: 'AWS', category: 'Cloud' },
      { name: 'Azure', category: 'Cloud' },
      { name: 'Google Cloud', category: 'Cloud' },
      { name: 'Kubernetes', category: 'Orchestration' },
      { name: 'Docker', category: 'Containers' },
      { name: 'Terraform', category: 'IaC' },
      { name: 'Ansible', category: 'Automation' },
      { name: 'Prometheus', category: 'Monitoring' },
      { name: 'Grafana', category: 'Visualization' },
    ],
    caseStudies: [
      {
        title: 'Euskaltel',
        category: 'Telecomunicaciones',
        description: 'Migración completa de infraestructura legacy a cloud nativo con reducción del 40% en costes operativos.',
        image: heroTech,
      },
      {
        title: 'Eroski',
        category: 'Retail',
        description: 'Implementación de arquitectura híbrida para gestión de inventario en tiempo real.',
        image: caseStudy2,
      },
    ],
    heroImage: heroTech,
  },
  {
    id: 'software-engineering',
    number: '02',
    title: 'Software Engineering',
    shortTitle: 'Software',
    tagline: 'Desarrollo a medida con impacto real',
    description: 'Desarrollo de software a medida con tecnologías open source',
    longDescription: 'Creamos soluciones de software personalizadas que transforman la manera en que operas. Desde aplicaciones web y móviles hasta sistemas empresariales complejos, nuestro equipo de ingenieros utiliza las mejores prácticas y tecnologías open source.',
    features: [
      'Aplicaciones web progresivas (PWA)',
      'Desarrollo de APIs REST y GraphQL',
      'Aplicaciones móviles multiplataforma',
      'Sistemas de gestión empresarial (ERP)',
      'Integraciones con terceros',
      'Modernización de aplicaciones legacy',
    ],
    technologies: [
      { name: 'React', category: 'Frontend' },
      { name: 'Vue.js', category: 'Frontend' },
      { name: 'TypeScript', category: 'Language' },
      { name: 'Node.js', category: 'Backend' },
      { name: 'Python', category: 'Backend' },
      { name: 'Go', category: 'Backend' },
      { name: 'PostgreSQL', category: 'Database' },
      { name: 'MongoDB', category: 'Database' },
      { name: 'Redis', category: 'Cache' },
    ],
    caseStudies: [
      {
        title: 'GM Food',
        category: 'Distribución alimentaria',
        description: 'Plataforma de gestión logística que optimizó rutas de entrega reduciendo tiempos en un 25%.',
        image: caseStudy1,
      },
      {
        title: 'Irontela',
        category: 'Telecomunicaciones',
        description: 'Sistema de gestión de clientes y facturación para operador de telecomunicaciones.',
        image: caseStudy3,
      },
    ],
    heroImage: caseStudy1,
  },
  {
    id: 'communications',
    number: '03',
    title: 'Communications',
    shortTitle: 'Comms',
    tagline: 'Conecta tu organización sin límites',
    description: 'Soluciones de comunicaciones unificadas y VoIP',
    longDescription: 'Implementamos sistemas de comunicaciones unificadas que integran voz, video, mensajería y colaboración. Nuestras soluciones VoIP basadas en Asterisk y Odin ofrecen máxima flexibilidad y control.',
    features: [
      'Centralitas virtuales (PBX)',
      'VoIP y SIP trunking',
      'Contact centers omnicanal',
      'Videoconferencia empresarial',
      'Mensajería instantánea corporativa',
      'Integración con CRM y ERP',
    ],
    technologies: [
      { name: 'Asterisk', category: 'PBX' },
      { name: 'Odin', category: 'Communications' },
      { name: 'WebRTC', category: 'Real-time' },
      { name: 'SIP', category: 'Protocol' },
      { name: 'Odin', category: 'Platform' },
      { name: 'Odin', category: 'Platform' },
      { name: 'Odin', category: 'Platform' },
      { name: 'FreePBX', category: 'PBX' },
      { name: 'Odin', category: 'Platform' },
    ],
    caseStudies: [
      {
        title: 'Grupo Euskaltel',
        category: 'Telecomunicaciones',
        description: 'Despliegue de infraestructura VoIP para más de 50.000 usuarios empresariales.',
        image: caseStudy2,
      },
      {
        title: 'Ayuntamiento de Bilbao',
        category: 'Administración Pública',
        description: 'Sistema de comunicaciones unificadas para atención ciudadana multicanal.',
        image: heroTech,
      },
    ],
    heroImage: caseStudy3,
  },
  {
    id: 'cybersecurity',
    number: '04',
    title: 'Cybersecurity',
    shortTitle: 'Security',
    tagline: 'Protección integral contra amenazas',
    description: 'Protección integral y auditorías de seguridad',
    longDescription: 'Protegemos los activos digitales de tu organización con un enfoque integral de ciberseguridad. Desde auditorías de vulnerabilidades hasta implementación de SOC, cubrimos todas las capas de seguridad.',
    features: [
      'Auditorías de seguridad y pentesting',
      'Implementación de SIEM/SOC',
      'Gestión de identidades (IAM)',
      'Seguridad en cloud',
      'Formación y concienciación',
      'Respuesta a incidentes',
    ],
    technologies: [
      { name: 'OWASP', category: 'Framework' },
      { name: 'Wazuh', category: 'SIEM' },
      { name: 'Snort', category: 'IDS' },
      { name: 'Suricata', category: 'IDS' },
      { name: 'OpenVAS', category: 'Scanner' },
      { name: 'Keycloak', category: 'IAM' },
      { name: 'HashiCorp Vault', category: 'Secrets' },
      { name: 'Falco', category: 'Runtime Security' },
      { name: 'ClamAV', category: 'Antivirus' },
    ],
    caseStudies: [
      {
        title: 'Banco Regional',
        category: 'Finanzas',
        description: 'Implementación de SOC 24/7 con detección y respuesta automatizada a incidentes.',
        image: caseStudy4,
      },
      {
        title: 'Hospital Universitario',
        category: 'Sanidad',
        description: 'Auditoría integral y remediación de vulnerabilidades en infraestructura crítica.',
        image: caseStudy2,
      },
    ],
    heroImage: caseStudy4,
  },
  {
    id: 'data-intelligence',
    number: '05',
    title: 'Data Intelligence',
    shortTitle: 'Data',
    tagline: 'Transforma datos en decisiones',
    description: 'Análisis de datos y business intelligence avanzado',
    longDescription: 'Convertimos tus datos en ventaja competitiva. Diseñamos arquitecturas de datos modernas, implementamos soluciones de BI y desarrollamos modelos de machine learning que impulsan la toma de decisiones.',
    features: [
      'Data warehousing y data lakes',
      'Business Intelligence y reporting',
      'Machine Learning e IA',
      'ETL y pipelines de datos',
      'Visualización y dashboards',
      'Gobierno del dato',
    ],
    technologies: [
      { name: 'Apache Spark', category: 'Processing' },
      { name: 'Apache Kafka', category: 'Streaming' },
      { name: 'Airflow', category: 'Orchestration' },
      { name: 'dbt', category: 'Transformation' },
      { name: 'Snowflake', category: 'Data Warehouse' },
      { name: 'Metabase', category: 'BI' },
      { name: 'Superset', category: 'BI' },
      { name: 'TensorFlow', category: 'ML' },
      { name: 'PyTorch', category: 'ML' },
    ],
    caseStudies: [
      {
        title: 'Euskalmet',
        category: 'Gobierno Vasco',
        description: 'Plataforma de análisis predictivo para datos meteorológicos con visualización en tiempo real.',
        image: caseStudy3,
      },
      {
        title: 'Cadena Retail',
        category: 'Comercio',
        description: 'Sistema de recomendaciones basado en ML que incrementó ventas cruzadas en un 35%.',
        image: caseStudy1,
      },
    ],
    heroImage: caseStudy3,
  },
];

export const getServiceById = (id: string): Service | undefined => {
  return services.find((service) => service.id === id);
};
