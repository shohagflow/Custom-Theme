import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, ArrowUpRight, Check } from 'lucide-react';
import { useLenis } from '@/hooks/useLenis';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { getServiceById, services } from '@/data/services';

const ServiceDetail = () => {
  useLenis();
  const { serviceId } = useParams<{ serviceId: string }>();
  const service = getServiceById(serviceId || '');

  if (!service) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-4xl font-bold mb-4">Servicio no encontrado</h1>
          <Link to="/" className="text-neon-lime hover:underline">
            Volver al inicio
          </Link>
        </div>
      </div>
    );
  }

  const otherServices = services.filter((s) => s.id !== service.id);

  return (
    <div className="relative">
      <Header />
      
      <main>
        {/* Hero Section */}
        <section className="relative min-h-[70vh] surface-dark flex items-end overflow-hidden pt-32 pb-16 md:pb-24">
          {/* Background Image */}
          <div className="absolute inset-0 z-0">
            <img
              src={service.heroImage}
              alt={service.title}
              className="w-full h-full object-cover opacity-30"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black via-black/80 to-black/40" />
          </div>

          <div className="relative z-10 container px-6 md:px-12 max-w-[1800px] mx-auto">
            {/* Back Link */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              className="mb-8"
            >
              <Link
                to="/#services"
                className="inline-flex items-center gap-2 text-sm font-medium transition-colors"
                style={{ color: 'rgba(255,255,255,0.6)' }}
              >
                <ArrowLeft className="w-4 h-4" />
                Todos los servicios
              </Link>
            </motion.div>

            {/* Number & Title */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.1 }}
            >
              <span
                className="block text-sm font-medium mb-4"
                style={{ color: 'hsl(68, 100%, 50%)' }}
              >
                {service.number}
              </span>
              <h1
                className="headline-massive mb-6"
                style={{ color: 'white' }}
              >
                {service.title}
              </h1>
              <p
                className="text-xl md:text-2xl font-display max-w-2xl"
                style={{ color: 'rgba(255,255,255,0.7)' }}
              >
                {service.tagline}
              </p>
            </motion.div>
          </div>
        </section>

        {/* Description Section */}
        <section className="surface-light section-premium">
          <div className="container px-6 md:px-12 max-w-[1800px] mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-24">
              {/* Left Column */}
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8 }}
                viewport={{ once: true }}
              >
                <span className="text-xs font-medium tracking-widest text-muted-foreground uppercase mb-6 block">
                  Descripción
                </span>
                <p className="text-xl md:text-2xl lg:text-3xl font-display leading-relaxed">
                  {service.longDescription}
                </p>
              </motion.div>

              {/* Right Column - Features */}
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.2 }}
                viewport={{ once: true }}
              >
                <span className="text-xs font-medium tracking-widest text-muted-foreground uppercase mb-6 block">
                  Qué incluye
                </span>
                <ul className="space-y-4">
                  {service.features.map((feature, index) => (
                    <motion.li
                      key={feature}
                      initial={{ opacity: 0, x: -20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.5, delay: 0.1 * index }}
                      viewport={{ once: true }}
                      className="flex items-start gap-4"
                    >
                      <div className="w-6 h-6 rounded-full bg-neon flex items-center justify-center flex-shrink-0 mt-0.5">
                        <Check className="w-4 h-4 text-accent-foreground" />
                      </div>
                      <span className="text-lg">{feature}</span>
                    </motion.li>
                  ))}
                </ul>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Technology Stack Section */}
        <section className="surface-dark py-24 md:py-32">
          <div className="container px-6 md:px-12 max-w-[1800px] mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="mb-12"
            >
              <span className="text-xs font-medium tracking-widest uppercase mb-4 block" style={{ color: 'rgba(255,255,255,0.5)' }}>
                Stack Tecnológico
              </span>
              <h2 className="text-3xl md:text-4xl lg:text-5xl font-display font-bold" style={{ color: 'white' }}>
                Tecnologías que utilizamos
              </h2>
            </motion.div>

            <div className="flex flex-wrap gap-4">
              {service.technologies.map((tech, index) => (
                <motion.div
                  key={`${tech.name}-${index}`}
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.4, delay: 0.05 * index }}
                  viewport={{ once: true }}
                  whileHover={{ scale: 1.05 }}
                  className="group px-6 py-4 rounded-full border transition-all duration-300 cursor-default"
                  style={{ borderColor: 'rgba(255,255,255,0.2)' }}
                >
                  <span
                    className="text-sm font-medium transition-colors duration-300 group-hover:text-accent"
                    style={{ color: 'white' }}
                  >
                    {tech.name}
                  </span>
                  <span
                    className="text-xs ml-2"
                    style={{ color: 'rgba(255,255,255,0.4)' }}
                  >
                    {tech.category}
                  </span>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Case Studies Section */}
        <section className="surface-light section-premium">
          <div className="container px-6 md:px-12 max-w-[1800px] mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="mb-12"
            >
              <span className="text-xs font-medium tracking-widest text-muted-foreground uppercase mb-4 block">
                Casos de éxito
              </span>
              <h2 className="text-3xl md:text-4xl lg:text-5xl font-display font-bold">
                Proyectos relacionados
              </h2>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12">
              {service.caseStudies.map((caseStudy, index) => (
                <motion.article
                  key={caseStudy.title}
                  initial={{ opacity: 0, y: 50 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: index * 0.15 }}
                  viewport={{ once: true }}
                  className="group cursor-pointer"
                >
                  <div className="image-zoom aspect-[4/3] rounded-lg mb-6 relative overflow-hidden bg-muted">
                    <img
                      src={caseStudy.image}
                      alt={caseStudy.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-foreground/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                    <motion.div
                      className="absolute top-4 right-4 w-12 h-12 bg-background rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                    >
                      <ArrowUpRight className="w-5 h-5" />
                    </motion.div>
                  </div>
                  <div>
                    <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
                      {caseStudy.category}
                    </span>
                    <h3 className="text-2xl md:text-3xl font-display font-bold mt-2 mb-3 group-hover:text-neon-lime transition-colors duration-300">
                      {caseStudy.title}
                    </h3>
                    <p className="text-muted-foreground leading-relaxed">
                      {caseStudy.description}
                    </p>
                  </div>
                </motion.article>
              ))}
            </div>
          </div>
        </section>

        {/* Other Services Section */}
        <section className="surface-dark py-24 md:py-32">
          <div className="container px-6 md:px-12 max-w-[1800px] mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="mb-12"
            >
              <span className="text-xs font-medium tracking-widest uppercase mb-4 block" style={{ color: 'rgba(255,255,255,0.5)' }}>
                Explorar más
              </span>
              <h2 className="text-3xl md:text-4xl lg:text-5xl font-display font-bold" style={{ color: 'white' }}>
                Otros servicios
              </h2>
            </motion.div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {otherServices.map((otherService, index) => (
                <motion.div
                  key={otherService.id}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  viewport={{ once: true }}
                >
                  <Link
                    to={`/services/${otherService.id}`}
                    className="group block p-6 rounded-2xl border transition-all duration-300 hover:border-accent"
                    style={{ borderColor: 'rgba(255,255,255,0.1)' }}
                  >
                    <span
                      className="text-xs font-medium mb-3 block transition-colors duration-300 group-hover:text-accent"
                      style={{ color: 'rgba(255,255,255,0.4)' }}
                    >
                      {otherService.number}
                    </span>
                    <h3
                      className="text-xl font-display font-bold transition-colors duration-300 group-hover:text-accent"
                      style={{ color: 'white' }}
                    >
                      {otherService.shortTitle}
                    </h3>
                    <ArrowUpRight
                      className="w-5 h-5 mt-4 transition-all duration-300 opacity-0 group-hover:opacity-100 group-hover:translate-x-1 group-hover:-translate-y-1"
                      style={{ color: 'hsl(68, 100%, 50%)' }}
                    />
                  </Link>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="surface-light section-premium">
          <div className="container px-6 md:px-12 max-w-[1800px] mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="bg-primary text-primary-foreground rounded-3xl p-8 md:p-16 lg:p-24 relative overflow-hidden"
            >
              <div className="absolute -right-20 -bottom-20 w-64 h-64 bg-neon rounded-full opacity-20" />
              
              <div className="relative z-10 max-w-3xl">
                <h2 className="headline-large mb-6">
                  ¿Listo para impulsar tu {service.shortTitle.toLowerCase()}?
                </h2>
                <p className="text-lg opacity-70 mb-8">
                  Hablemos sobre cómo podemos ayudarte a alcanzar tus objetivos.
                </p>
                <Link
                  to="/#contact"
                  className="inline-flex items-center gap-3 px-8 py-4 bg-neon text-accent-foreground font-medium rounded-full hover:opacity-90 transition-opacity"
                >
                  Contactar ahora
                  <ArrowUpRight className="w-5 h-5" />
                </Link>
              </div>
            </motion.div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default ServiceDetail;
