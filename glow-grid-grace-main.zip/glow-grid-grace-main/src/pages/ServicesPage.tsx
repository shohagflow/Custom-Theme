import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowUpRight } from 'lucide-react';
import { useLenis } from '@/hooks/useLenis';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { services } from '@/data/services';

const ServicesPage = () => {
  useLenis();

  return (
    <div className="relative">
      <Header />
      
      <main>
        {/* Hero Section */}
        <section className="relative min-h-[50vh] surface-light grid-pattern flex items-end overflow-hidden pt-32 pb-16 md:pb-24">
          <div className="relative z-10 container px-6 md:px-12 max-w-[1800px] mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <span className="text-xs font-medium tracking-widest text-muted-foreground uppercase mb-6 block">
                Nuestros servicios
              </span>
              <h1 className="headline-massive mb-6">
                Soluciones
                <br />
                <span className="text-neon">tecnológicas</span>
              </h1>
              <p className="text-xl md:text-2xl text-muted-foreground max-w-2xl">
                Servicios integrales de tecnología para impulsar la transformación digital de tu organización.
              </p>
            </motion.div>
          </div>
        </section>

        {/* Services Grid */}
        <section className="surface-dark py-24 md:py-32 lg:py-40">
          <div className="container px-6 md:px-12 max-w-[1800px] mx-auto">
            {services.map((service, index) => (
              <motion.div
                key={service.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <Link
                  to={`/services/${service.id}`}
                  className="group block border-t py-12 md:py-16 transition-all duration-500"
                  style={{ borderColor: 'rgba(255,255,255,0.1)' }}
                >
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
                    {/* Number */}
                    <div className="lg:col-span-1">
                      <span
                        className="text-sm font-medium transition-colors duration-300 group-hover:text-accent"
                        style={{ color: 'rgba(255,255,255,0.4)' }}
                      >
                        {service.number}
                      </span>
                    </div>

                    {/* Title */}
                    <div className="lg:col-span-5">
                      <h2
                        className="text-3xl md:text-4xl lg:text-5xl font-display font-bold transition-colors duration-300 group-hover:text-accent"
                        style={{ color: 'white' }}
                      >
                        {service.title}
                      </h2>
                    </div>

                    {/* Description */}
                    <div className="lg:col-span-5">
                      <p
                        className="text-lg leading-relaxed"
                        style={{ color: 'rgba(255,255,255,0.6)' }}
                      >
                        {service.description}
                      </p>
                    </div>

                    {/* Arrow */}
                    <div className="lg:col-span-1 flex justify-end">
                      <motion.div
                        initial={{ x: -10, opacity: 0 }}
                        whileInView={{ x: 0, opacity: 1 }}
                        transition={{ duration: 0.3 }}
                        className="opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                      >
                        <ArrowUpRight
                          className="w-8 h-8"
                          style={{ color: 'hsl(68, 100%, 50%)' }}
                        />
                      </motion.div>
                    </div>
                  </div>

                  {/* Preview Image on Hover */}
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    whileHover={{ opacity: 1, y: 0 }}
                    className="mt-8 overflow-hidden rounded-lg max-h-0 group-hover:max-h-64 transition-all duration-500"
                  >
                    <img
                      src={service.heroImage}
                      alt={service.title}
                      className="w-full h-64 object-cover"
                    />
                  </motion.div>
                </Link>
              </motion.div>
            ))}
            
            {/* Last border */}
            <div className="border-t" style={{ borderColor: 'rgba(255,255,255,0.1)' }} />
          </div>
        </section>

        {/* CTA Section */}
        <section className="surface-light section-premium">
          <div className="container px-6 md:px-12 max-w-[1800px] mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <h2 className="headline-large mb-8">
                ¿No sabes qué servicio necesitas?
              </h2>
              <p className="text-xl text-muted-foreground mb-12 max-w-2xl mx-auto">
                Cuéntanos tu proyecto y te asesoraremos sobre la mejor solución para tu organización.
              </p>
              <Link
                to="/#contact"
                className="inline-flex items-center gap-3 px-8 py-4 bg-primary text-primary-foreground font-medium rounded-full hover:opacity-90 transition-opacity"
              >
                Hablar con un experto
                <ArrowUpRight className="w-5 h-5" />
              </Link>
            </motion.div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default ServicesPage;
