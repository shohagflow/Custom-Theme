import { useLenis } from '@/hooks/useLenis';
import Header from '@/components/Header';
import Hero from '@/components/Hero';
import Services from '@/components/Services';
import CaseStudies from '@/components/CaseStudies';
import About from '@/components/About';
import Contact from '@/components/Contact';
import Footer from '@/components/Footer';

const Index = () => {
  // Initialize Lenis smooth scrolling
  useLenis();

  return (
    <div className="relative">
      <Header />
      <main>
        <Hero />
        <Services />
        <CaseStudies />
        <About />
        <Contact />
      </main>
      <Footer />
    </div>
  );
};

export default Index;
