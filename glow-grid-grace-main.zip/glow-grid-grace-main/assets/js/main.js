/**
 * Main JavaScript file for Glow Grid Grace theme
 */

(function() {
    'use strict';

    // Initialize Lenis smooth scrolling
    function initLenis() {
        if (typeof Lenis !== 'undefined') {
            const lenis = new Lenis({
                duration: 1.2,
                easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
                orientation: 'vertical',
                gestureOrientation: 'vertical',
                smoothWheel: true,
                wheelMultiplier: 1,
                touchMultiplier: 2,
            });

            function raf(time) {
                lenis.raf(time);
                requestAnimationFrame(raf);
            }

            requestAnimationFrame(raf);
        }
    }

    // Mobile menu toggle
    function initMobileMenu() {
        const menuToggle = document.getElementById('menu-toggle');
        const fullScreenMenu = document.getElementById('full-screen-menu');
        const menuIcon = document.getElementById('menu-icon');

        if (menuToggle && fullScreenMenu) {
            menuToggle.addEventListener('click', function() {
                fullScreenMenu.classList.toggle('hidden');
                document.body.style.overflow = fullScreenMenu.classList.contains('hidden') ? '' : 'hidden';
            });

            // Close menu when clicking on links
            const menuLinks = fullScreenMenu.querySelectorAll('a');
            menuLinks.forEach(link => {
                link.addEventListener('click', function() {
                    fullScreenMenu.classList.add('hidden');
                    document.body.style.overflow = '';
                });
            });
        }
    }

    // Smooth scroll for anchor links
    function initSmoothScroll() {
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                const href = this.getAttribute('href');
                if (href !== '#' && href.length > 1) {
                    const target = document.querySelector(href);
                    if (target) {
                        e.preventDefault();
                        target.scrollIntoView({
                            behavior: 'smooth',
                            block: 'start'
                        });
                    }
                }
            });
        });
    }

    // Parallax effect for case studies section
    function initParallax() {
        const parallaxSection = document.querySelector('[data-parallax-section]');
        if (!parallaxSection) return;

        const parallaxText = parallaxSection.querySelector('.parallax-bg-text');
        if (!parallaxText) return;

        function updateParallax() {
            const rect = parallaxSection.getBoundingClientRect();
            const scrollProgress = (window.innerHeight - rect.top) / (window.innerHeight + rect.height);
            const translateY = 100 - (scrollProgress * 200);
            parallaxText.style.transform = `translateY(${translateY}px)`;
        }

        window.addEventListener('scroll', updateParallax);
        updateParallax();
    }

    // Intersection Observer for fade-in animations
    function initScrollAnimations() {
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -100px 0px'
        };

        const observer = new IntersectionObserver(function(entries) {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('animate-fade-up');
                    observer.unobserve(entry.target);
                }
            });
        }, observerOptions);

        // Observe elements that should animate on scroll
        document.querySelectorAll('.case-study-item, .service-item').forEach(el => {
            observer.observe(el);
        });
    }

    // Service item hover effects
    function initServiceHovers() {
        const serviceItems = document.querySelectorAll('.service-item');
        
        serviceItems.forEach(item => {
            item.addEventListener('mouseenter', function() {
                const index = this.dataset.index;
                // Remove active state from other items
                serviceItems.forEach(otherItem => {
                    if (otherItem !== this) {
                        otherItem.classList.remove('active');
                    }
                });
                this.classList.add('active');
            });

            item.addEventListener('mouseleave', function() {
                this.classList.remove('active');
            });
        });
    }

    // Initialize everything when DOM is ready
    function init() {
        initLenis();
        initMobileMenu();
        initSmoothScroll();
        initParallax();
        initScrollAnimations();
        initServiceHovers();
    }

    // Wait for DOM to be ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    // Re-initialize on AJAX navigation (if using AJAX)
    document.addEventListener('wpAjaxComplete', init);
})();
