# Glow Grid Grace - WordPress Theme

A modern WordPress theme converted from React/Vite project for Irontec technology company.

## Features

- Modern, premium design with smooth animations
- Custom Post Types for Services and Case Studies
- Responsive design (mobile-first)
- Smooth scrolling with Lenis
- Tailwind CSS styling
- Custom meta fields for services
- Glassmorphism header
- Parallax effects
- Neon lime accent color scheme

## Installation

1. Upload the theme folder to `/wp-content/themes/`
2. Activate the theme through the 'Appearance' menu in WordPress
3. Go to 'Services' in the admin menu to add your services
4. Go to 'Case Studies' to add case studies
5. Set a static front page in Settings > Reading (optional)

## Theme Setup

### Adding Services

1. Go to **Services > Add New** in WordPress admin
2. Enter the service title and description
3. Fill in the custom fields:
   - **Service Number**: e.g., "01", "02"
   - **Short Title**: Short version of the title
   - **Tagline**: Brief tagline for the service
   - **Short Description**: Brief description
   - **Features**: One feature per line
   - **Technologies**: JSON format: `[{"name":"React","category":"Frontend"}]`
4. Set a featured image (hero image)
5. Publish

### Adding Case Studies

1. Go to **Case Studies > Add New**
2. Enter title, description, and category
3. Set a featured image
4. Publish

### Customization

- **Colors**: Edit CSS variables in `assets/css/main.css`
- **Fonts**: Google Fonts (Manrope & Inter) are loaded automatically
- **Menu**: Go to Appearance > Menus to configure navigation

## File Structure

```
glow-grid-grace-main/
├── style.css                 # Theme header (required)
├── functions.php             # Theme functions
├── index.php                 # Main template
├── header.php                # Header template
├── footer.php                # Footer template
├── front-page.php            # Homepage template
├── archive-service.php       # Services archive
├── single-service.php        # Single service template
├── 404.php                   # 404 error page
├── template-parts/           # Reusable template parts
│   ├── header/
│   │   └── navigation.php
│   ├── footer/
│   │   └── footer.php
│   └── sections/
│       ├── hero.php
│       ├── services.php
│       ├── case-studies.php
│       ├── about.php
│       └── contact.php
├── assets/
│   ├── css/
│   │   └── main.css          # Custom styles
│   ├── js/
│   │   └── main.js           # Theme JavaScript
│   └── images/               # Theme images
│       ├── hero-tech.jpg
│       ├── case-study-1.jpg
│       ├── case-study-2.jpg
│       ├── case-study-3.jpg
│       └── case-study-4.jpg
└── README-WORDPRESS.md       # This file
```

## Requirements

- WordPress 6.0 or higher
- PHP 8.0 or higher
- Modern browser with JavaScript enabled

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## Credits

- **Design**: Converted from React/Vite project
- **Fonts**: Google Fonts (Manrope, Inter)
- **Smooth Scroll**: Lenis by Studio Freight
- **CSS Framework**: Tailwind CSS

## Support

For theme support, please contact the theme developer.

## License

This theme is licensed under the GNU General Public License v2 or later.
