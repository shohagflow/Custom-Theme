<?php
/**
 * Services archive template
 *
 * @package GlowGridGrace
 */

get_header();
?>

<div class="relative">
    <main>
        <!-- Hero Section -->
        <section class="relative min-h-[50vh] surface-light grid-pattern flex items-end overflow-hidden pt-32 pb-16 md:pb-24">
            <div class="relative z-10 container px-6 md:px-12 max-w-[1800px] mx-auto">
                <span class="text-xs font-medium tracking-widest text-muted-foreground uppercase mb-6 block">
                    Nuestros servicios
                </span>
                <h1 class="headline-massive mb-6">
                    Soluciones
                    <br />
                    <span class="text-neon">tecnológicas</span>
                </h1>
                <p class="text-xl md:text-2xl text-muted-foreground max-w-2xl">
                    Servicios integrales de tecnología para impulsar la transformación digital de tu organización.
                </p>
            </div>
        </section>

        <!-- Services Grid -->
        <section class="surface-dark py-24 md:py-32 lg:py-40">
            <div class="container px-6 md:px-12 max-w-[1800px] mx-auto">
                <?php 
                $services = glow_grid_grace_get_services();
                foreach ($services as $index => $service): 
                    $service_number = get_post_meta($service->ID, '_service_number', true);
                    $service_description = get_post_meta($service->ID, '_service_description', true);
                    $hero_image = get_the_post_thumbnail_url($service->ID, 'large') ?: get_template_directory_uri() . '/assets/images/hero-tech.jpg';
                ?>
                    <div class="group block border-t py-12 md:py-16 transition-all duration-500" style="border-color: rgba(255,255,255,0.1);">
                        <a href="<?php echo esc_url(get_permalink($service->ID)); ?>" class="block">
                            <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
                                <!-- Number -->
                                <div class="lg:col-span-1">
                                    <span class="text-sm font-medium transition-colors duration-300 group-hover:text-accent" style="color: rgba(255,255,255,0.4);">
                                        <?php echo esc_html($service_number ?: '0' . ($index + 1)); ?>
                                    </span>
                                </div>

                                <!-- Title -->
                                <div class="lg:col-span-5">
                                    <h2 class="text-3xl md:text-4xl lg:text-5xl font-display font-bold transition-colors duration-300 group-hover:text-accent" style="color: white;">
                                        <?php echo esc_html($service->post_title); ?>
                                    </h2>
                                </div>

                                <!-- Description -->
                                <div class="lg:col-span-5">
                                    <p class="text-lg leading-relaxed" style="color: rgba(255,255,255,0.6);">
                                        <?php echo esc_html($service_description ?: $service->post_excerpt); ?>
                                    </p>
                                </div>

                                <!-- Arrow -->
                                <div class="lg:col-span-1 flex justify-end">
                                    <div class="opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                                        <svg class="w-8 h-8" style="color: #A3F861;" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 17l9.2-9.2M17 8v9m-9-9h9"></path>
                                        </svg>
                                    </div>
                                </div>
                            </div>

                            <!-- Preview Image on Hover -->
                            <div class="mt-8 overflow-hidden rounded-lg max-h-0 group-hover:max-h-64 transition-all duration-500">
                                <img src="<?php echo esc_url($hero_image); ?>" alt="<?php echo esc_attr($service->post_title); ?>" class="w-full h-64 object-cover">
                            </div>
                        </a>
                    </div>
                <?php endforeach; ?>
                
                <!-- Last border -->
                <div class="border-t" style="border-color: rgba(255,255,255,0.1);"></div>
            </div>
        </section>

        <!-- CTA Section -->
        <section class="surface-light section-premium">
            <div class="container px-6 md:px-12 max-w-[1800px] mx-auto text-center">
                <h2 class="headline-large mb-8">
                    ¿No sabes qué servicio necesitas?
                </h2>
                <p class="text-xl text-muted-foreground mb-12 max-w-2xl mx-auto">
                    Cuéntanos tu proyecto y te asesoraremos sobre la mejor solución para tu organización.
                </p>
                <a href="<?php echo esc_url(home_url('/#contact')); ?>" class="inline-flex items-center gap-3 px-8 py-4 bg-primary text-primary-foreground font-medium rounded-full hover:opacity-90 transition-opacity">
                    Hablar con un experto
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 17l9.2-9.2M17 8v9m-9-9h9"></path>
                    </svg>
                </a>
            </div>
        </section>
    </main>
</div>

<?php
get_footer();
