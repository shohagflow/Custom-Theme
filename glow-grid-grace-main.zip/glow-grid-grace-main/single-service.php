<?php
/**
 * Single service template
 *
 * @package GlowGridGrace
 */

get_header();

$service_number = get_post_meta(get_the_ID(), '_service_number', true);
$service_short_title = get_post_meta(get_the_ID(), '_service_short_title', true);
$service_tagline = get_post_meta(get_the_ID(), '_service_tagline', true);
$service_description = get_post_meta(get_the_ID(), '_service_description', true);
$service_features = get_post_meta(get_the_ID(), '_service_features', true);
$service_technologies = get_post_meta(get_the_ID(), '_service_technologies', true);
$hero_image = get_the_post_thumbnail_url(get_the_ID(), 'full') ?: get_template_directory_uri() . '/assets/images/hero-tech.jpg';

$other_services = glow_grid_grace_get_services(array('post__not_in' => array(get_the_ID())));
$features_array = !empty($service_features) ? explode("\n", $service_features) : array();
$technologies_array = !empty($service_technologies) ? json_decode($service_technologies, true) : array();
?>

<div class="relative">
    <main>
        <!-- Hero Section -->
        <section class="relative min-h-[70vh] surface-dark flex items-end overflow-hidden pt-32 pb-16 md:pb-24">
            <!-- Background Image -->
            <div class="absolute inset-0 z-0">
                <img src="<?php echo esc_url($hero_image); ?>" alt="<?php echo esc_attr(get_the_title()); ?>" class="w-full h-full object-cover opacity-30">
                <div class="absolute inset-0 bg-gradient-to-t from-black via-black/80 to-black/40"></div>
            </div>

            <div class="relative z-10 container px-6 md:px-12 max-w-[1800px] mx-auto">
                <!-- Back Link -->
                <div class="mb-8">
                    <a href="<?php echo esc_url(get_post_type_archive_link('service')); ?>" class="inline-flex items-center gap-2 text-sm font-medium transition-colors" style="color: rgba(255,255,255,0.6);">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
                        </svg>
                        Todos los servicios
                    </a>
                </div>

                <!-- Number & Title -->
                <div>
                    <span class="block text-sm font-medium mb-4" style="color: #A3F861;">
                        <?php echo esc_html($service_number ?: '01'); ?>
                    </span>
                    <h1 class="headline-massive mb-6" style="color: white;">
                        <?php echo esc_html(get_the_title()); ?>
                    </h1>
                    <p class="text-xl md:text-2xl font-display max-w-2xl" style="color: rgba(255,255,255,0.7);">
                        <?php echo esc_html($service_tagline ?: get_the_excerpt()); ?>
                    </p>
                </div>
            </div>
        </section>

        <!-- Description Section -->
        <section class="surface-light section-premium">
            <div class="container px-6 md:px-12 max-w-[1800px] mx-auto">
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-24">
                    <!-- Left Column -->
                    <div>
                        <span class="text-xs font-medium tracking-widest text-muted-foreground uppercase mb-6 block">
                            Descripción
                        </span>
                        <p class="text-xl md:text-2xl lg:text-3xl font-display leading-relaxed">
                            <?php echo wp_kses_post(get_the_content()); ?>
                        </p>
                    </div>

                    <!-- Right Column - Features -->
                    <div>
                        <span class="text-xs font-medium tracking-widest text-muted-foreground uppercase mb-6 block">
                            Qué incluye
                        </span>
                        <ul class="space-y-4">
                            <?php foreach ($features_array as $feature): 
                                $feature = trim($feature);
                                if (!empty($feature)):
                            ?>
                                <li class="flex items-start gap-4">
                                    <div class="w-6 h-6 rounded-full bg-neon flex items-center justify-center flex-shrink-0 mt-0.5">
                                        <svg class="w-4 h-4 text-accent-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                                        </svg>
                                    </div>
                                    <span class="text-lg"><?php echo esc_html($feature); ?></span>
                                </li>
                            <?php 
                                endif;
                            endforeach; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </section>

        <!-- Technology Stack Section -->
        <?php if (!empty($technologies_array)): ?>
        <section class="surface-dark py-24 md:py-32">
            <div class="container px-6 md:px-12 max-w-[1800px] mx-auto">
                <div class="mb-12">
                    <span class="text-xs font-medium tracking-widest uppercase mb-4 block" style="color: rgba(255,255,255,0.5);">
                        Stack Tecnológico
                    </span>
                    <h2 class="text-3xl md:text-4xl lg:text-5xl font-display font-bold" style="color: white;">
                        Tecnologías que utilizamos
                    </h2>
                </div>

                <div class="flex flex-wrap gap-4">
                    <?php foreach ($technologies_array as $tech): ?>
                        <div class="group px-6 py-4 rounded-full border transition-all duration-300 cursor-default" style="border-color: rgba(255,255,255,0.2);">
                            <span class="text-sm font-medium transition-colors duration-300 group-hover:text-accent" style="color: white;">
                                <?php echo esc_html($tech['name'] ?? ''); ?>
                            </span>
                            <span class="text-xs ml-2" style="color: rgba(255,255,255,0.4);">
                                <?php echo esc_html($tech['category'] ?? ''); ?>
                            </span>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>
        <?php endif; ?>

        <!-- Other Services Section -->
        <section class="surface-dark py-24 md:py-32">
            <div class="container px-6 md:px-12 max-w-[1800px] mx-auto">
                <div class="mb-12">
                    <span class="text-xs font-medium tracking-widest uppercase mb-4 block" style="color: rgba(255,255,255,0.5);">
                        Explorar más
                    </span>
                    <h2 class="text-3xl md:text-4xl lg:text-5xl font-display font-bold" style="color: white;">
                        Otros servicios
                    </h2>
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                    <?php foreach (array_slice($other_services, 0, 4) as $index => $other_service): 
                        $other_number = get_post_meta($other_service->ID, '_service_number', true);
                        $other_short = get_post_meta($other_service->ID, '_service_short_title', true);
                    ?>
                        <a href="<?php echo esc_url(get_permalink($other_service->ID)); ?>" class="group block p-6 rounded-2xl border transition-all duration-300 hover:border-accent" style="border-color: rgba(255,255,255,0.1);">
                            <span class="text-xs font-medium mb-3 block transition-colors duration-300 group-hover:text-accent" style="color: rgba(255,255,255,0.4);">
                                <?php echo esc_html($other_number ?: '0' . ($index + 1)); ?>
                            </span>
                            <h3 class="text-xl font-display font-bold transition-colors duration-300 group-hover:text-accent" style="color: white;">
                                <?php echo esc_html($other_short ?: $other_service->post_title); ?>
                            </h3>
                            <svg class="w-5 h-5 mt-4 transition-all duration-300 opacity-0 group-hover:opacity-100 group-hover:translate-x-1 group-hover:-translate-y-1" style="color: #A3F861;" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 17l9.2-9.2M17 8v9m-9-9h9"></path>
                            </svg>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>

        <!-- CTA Section -->
        <section class="surface-light section-premium">
            <div class="container px-6 md:px-12 max-w-[1800px] mx-auto">
                <div class="bg-primary text-primary-foreground rounded-3xl p-8 md:p-16 lg:p-24 relative overflow-hidden">
                    <div class="absolute -right-20 -bottom-20 w-64 h-64 bg-neon rounded-full opacity-20"></div>
                    
                    <div class="relative z-10 max-w-3xl">
                        <h2 class="headline-large mb-6">
                            ¿Listo para impulsar tu <?php echo esc_html(strtolower($service_short_title ?: get_the_title())); ?>?
                        </h2>
                        <p class="text-lg opacity-70 mb-8">
                            Hablemos sobre cómo podemos ayudarte a alcanzar tus objetivos.
                        </p>
                        <a href="<?php echo esc_url(home_url('/#contact')); ?>" class="inline-flex items-center gap-3 px-8 py-4 bg-neon text-accent-foreground font-medium rounded-full hover:opacity-90 transition-opacity">
                            Contactar ahora
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 17l9.2-9.2M17 8v9m-9-9h9"></path>
                            </svg>
                        </a>
                    </div>
                </div>
            </div>
        </section>
    </main>
</div>

<?php
get_footer();
