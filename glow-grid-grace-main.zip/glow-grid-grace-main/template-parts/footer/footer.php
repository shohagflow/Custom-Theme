<?php
/**
 * Footer template
 *
 * @package GlowGridGrace
 */

$current_year = date('Y');
?>

<footer class="surface-light border-t border-border py-16 md:py-24">
    <div class="container px-6 md:px-12 max-w-[1800px] mx-auto">
        <!-- Tagline -->
        <div class="mb-16">
            <p class="text-lg md:text-xl text-muted-foreground max-w-md">
                We care about your business in the open source way.
            </p>
        </div>

        <!-- Logo Large -->
        <div class="mb-16">
            <h2 class="text-[15vw] md:text-[12vw] font-display font-black tracking-tighter leading-none">
                Irontec<span class="text-neon">.</span>
            </h2>
        </div>

        <!-- Bottom Bar -->
        <div class="flex flex-col md:flex-row items-start md:items-center justify-between gap-8 pt-8 border-t border-border">
            <!-- Links -->
            <nav class="flex flex-wrap gap-6 text-sm text-muted-foreground">
                <a href="#" class="hover:text-foreground transition-colors">LinkedIn</a>
                <a href="#" class="hover:text-foreground transition-colors">Twitter</a>
                <a href="#" class="hover:text-foreground transition-colors">GitHub</a>
                <a href="#" class="hover:text-foreground transition-colors">YouTube</a>
            </nav>

            <!-- Copyright -->
            <p class="text-sm text-muted-foreground">
                © <?php echo esc_html($current_year); ?> Irontec. Todos los derechos reservados.
            </p>
        </div>
    </div>
</footer>
