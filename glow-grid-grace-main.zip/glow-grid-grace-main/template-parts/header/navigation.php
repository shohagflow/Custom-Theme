<?php
/**
 * Navigation template
 *
 * @package GlowGridGrace
 */

$services = glow_grid_grace_get_services();
$current_url = $_SERVER['REQUEST_URI'];
?>

<header class="glass-header fixed top-0 left-0 right-0 z-50 px-6 md:px-12 py-4" id="masthead">
    <div class="flex items-center justify-between max-w-[1800px] mx-auto">
        <a href="<?php echo esc_url(home_url('/')); ?>" class="font-display text-2xl md:text-3xl font-bold tracking-tight">
            Irontec<span class="text-neon">.</span>
        </a>

        <nav class="hidden lg:flex items-center gap-8">
            <a href="<?php echo esc_url(home_url('/')); ?>" class="link-underline text-sm font-medium tracking-wide transition-colors <?php echo is_front_page() ? 'text-foreground' : 'text-foreground/60 hover:text-foreground'; ?>">
                Inicio
            </a>
            <a href="<?php echo esc_url(get_post_type_archive_link('service')); ?>" class="link-underline text-sm font-medium tracking-wide transition-colors <?php echo is_post_type_archive('service') ? 'text-foreground' : 'text-foreground/60 hover:text-foreground'; ?>">
                Servicios
            </a>
            <a href="<?php echo esc_url(home_url('/#cases')); ?>" class="link-underline text-sm font-medium tracking-wide transition-colors text-foreground/60 hover:text-foreground">
                Casos de Éxito
            </a>
            <a href="<?php echo esc_url(home_url('/#about')); ?>" class="link-underline text-sm font-medium tracking-wide transition-colors text-foreground/60 hover:text-foreground">
                Nosotros
            </a>
            <a href="<?php echo esc_url(home_url('/#contact')); ?>" class="link-underline text-sm font-medium tracking-wide transition-colors text-foreground/60 hover:text-foreground">
                Contacto
            </a>
        </nav>

        <button id="menu-toggle" class="flex items-center gap-2 text-sm font-medium tracking-wide" aria-label="Toggle menu">
            <span class="hidden md:block">Menu</span>
            <span id="menu-icon">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path>
                </svg>
            </span>
        </button>
    </div>
</header>

<!-- Full Screen Menu -->
<div id="full-screen-menu" class="fixed inset-0 z-40 surface-dark overflow-y-auto hidden">
    <div class="min-h-screen pt-24 pb-12 px-6 md:px-12">
        <div class="max-w-[1800px] mx-auto grid grid-cols-1 lg:grid-cols-2 gap-16">
            <!-- Left Column - Main Navigation -->
            <div>
                <span class="text-xs font-medium tracking-widest uppercase mb-8 block" style="color: rgba(255,255,255,0.5);">
                    Navegación
                </span>
                <nav class="space-y-4">
                    <a href="<?php echo esc_url(home_url('/')); ?>" class="group flex items-center justify-between py-3 border-b transition-colors duration-300" style="border-color: rgba(255,255,255,0.1); color: white;">
                        <span class="text-4xl md:text-5xl lg:text-6xl font-display font-bold group-hover:text-accent transition-colors duration-300">Inicio</span>
                        <svg class="w-6 h-6 opacity-0 group-hover:opacity-100 transition-opacity duration-300" style="color: #A3F861;" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 17l9.2-9.2M17 8v9m-9-9h9"></path>
                        </svg>
                    </a>
                    <a href="<?php echo esc_url(get_post_type_archive_link('service')); ?>" class="group flex items-center justify-between py-3 border-b transition-colors duration-300" style="border-color: rgba(255,255,255,0.1); color: white;">
                        <span class="text-4xl md:text-5xl lg:text-6xl font-display font-bold group-hover:text-accent transition-colors duration-300">Servicios</span>
                        <svg class="w-6 h-6 opacity-0 group-hover:opacity-100 transition-opacity duration-300" style="color: #A3F861;" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 17l9.2-9.2M17 8v9m-9-9h9"></path>
                        </svg>
                    </a>
                    <a href="<?php echo esc_url(home_url('/#cases')); ?>" class="group flex items-center justify-between py-3 border-b transition-colors duration-300" style="border-color: rgba(255,255,255,0.1); color: white;">
                        <span class="text-4xl md:text-5xl lg:text-6xl font-display font-bold group-hover:text-accent transition-colors duration-300">Casos de Éxito</span>
                        <svg class="w-6 h-6 opacity-0 group-hover:opacity-100 transition-opacity duration-300" style="color: #A3F861;" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 17l9.2-9.2M17 8v9m-9-9h9"></path>
                        </svg>
                    </a>
                    <a href="<?php echo esc_url(home_url('/#about')); ?>" class="group flex items-center justify-between py-3 border-b transition-colors duration-300" style="border-color: rgba(255,255,255,0.1); color: white;">
                        <span class="text-4xl md:text-5xl lg:text-6xl font-display font-bold group-hover:text-accent transition-colors duration-300">Nosotros</span>
                        <svg class="w-6 h-6 opacity-0 group-hover:opacity-100 transition-opacity duration-300" style="color: #A3F861;" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 17l9.2-9.2M17 8v9m-9-9h9"></path>
                        </svg>
                    </a>
                    <a href="<?php echo esc_url(home_url('/#contact')); ?>" class="group flex items-center justify-between py-3 border-b transition-colors duration-300" style="border-color: rgba(255,255,255,0.1); color: white;">
                        <span class="text-4xl md:text-5xl lg:text-6xl font-display font-bold group-hover:text-accent transition-colors duration-300">Contacto</span>
                        <svg class="w-6 h-6 opacity-0 group-hover:opacity-100 transition-opacity duration-300" style="color: #A3F861;" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 17l9.2-9.2M17 8v9m-9-9h9"></path>
                        </svg>
                    </a>
                </nav>
            </div>

            <!-- Right Column - Services -->
            <div>
                <span class="text-xs font-medium tracking-widest uppercase mb-8 block" style="color: rgba(255,255,255,0.5);">
                    Servicios
                </span>
                <nav class="space-y-3">
                    <?php foreach ($services as $index => $service): 
                        $service_number = get_post_meta($service->ID, '_service_number', true);
                    ?>
                        <a href="<?php echo esc_url(get_permalink($service->ID)); ?>" class="group flex items-center gap-4 py-3 transition-colors duration-300">
                            <span class="text-sm font-medium group-hover:text-accent transition-colors duration-300" style="color: rgba(255,255,255,0.4);">
                                <?php echo esc_html($service_number ?: '0' . ($index + 1)); ?>
                            </span>
                            <span class="text-xl md:text-2xl font-display font-medium group-hover:text-accent transition-colors duration-300" style="color: white;">
                                <?php echo esc_html($service->post_title); ?>
                            </span>
                            <svg class="w-5 h-5 opacity-0 group-hover:opacity-100 transition-all duration-300 group-hover:translate-x-1 group-hover:-translate-y-1" style="color: #A3F861;" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 17l9.2-9.2M17 8v9m-9-9h9"></path>
                            </svg>
                        </a>
                    <?php endforeach; ?>
                </nav>

                <!-- Contact Info -->
                <div class="mt-16 pt-8 border-t" style="border-color: rgba(255,255,255,0.1);">
                    <span class="text-xs font-medium tracking-widest uppercase mb-4 block" style="color: rgba(255,255,255,0.5);">
                        Contacto
                    </span>
                    <a href="mailto:info@irontec.com" class="block text-xl font-display mb-2 hover:text-accent transition-colors" style="color: white;">
                        info@irontec.com
                    </a>
                    <a href="tel:+34944048182" class="block text-xl font-display hover:text-accent transition-colors" style="color: white;">
                        +34 944 048 182
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
