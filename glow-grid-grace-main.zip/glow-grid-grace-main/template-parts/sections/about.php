<?php
/**
 * About section template
 *
 * @package GlowGridGrace
 */

$stats = array(
    array('value' => '20+', 'label' => 'Años de experiencia'),
    array('value' => '500+', 'label' => 'Proyectos completados'),
    array('value' => '100+', 'label' => 'Profesionales'),
    array('value' => '98%', 'label' => 'Clientes satisfechos'),
);
?>

<section id="about" class="surface-dark py-24 md:py-32 lg:py-40 relative overflow-hidden">
    <div class="container px-6 md:px-12 max-w-[1800px] mx-auto">
        <!-- Section Label -->
        <div class="mb-16">
            <span class="text-xs font-medium tracking-widest uppercase" style="color: rgba(255,255,255,0.5);">
                Sobre nosotros
            </span>
        </div>

        <!-- Main Content -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-24">
            <!-- Left Column - Big Quote -->
            <div>
                <h2 class="text-3xl md:text-4xl lg:text-5xl font-display font-bold leading-tight" style="color: white;">
                    La suma de nuestro conocimiento y experiencia dan como resultado un servicio único,
                    <span style="color: #A3F861;"> estratégicamente orientado a conseguir la consecución de tus objetivos y los de tu compañía.</span>
                </h2>
            </div>

            <!-- Right Column - Description & Stats -->
            <div>
                <p class="text-lg leading-relaxed mb-12" style="color: rgba(255,255,255,0.7);">
                    Somos una ingeniería tecnológica con más de 20 años de experiencia, 
                    especializados en soluciones avanzadas open source. Nuestro equipo 
                    de profesionales altamente cualificados trabaja para transformar 
                    digitalmente tu negocio con las mejores tecnologías del mercado.
                </p>

                <!-- Stats Grid -->
                <div class="grid grid-cols-2 gap-8">
                    <?php foreach ($stats as $index => $stat): ?>
                        <div class="border-t pt-6" style="border-color: rgba(255,255,255,0.1);">
                            <span class="block text-4xl md:text-5xl font-display font-bold mb-2" style="color: #A3F861;">
                                <?php echo esc_html($stat['value']); ?>
                            </span>
                            <span class="text-sm" style="color: rgba(255,255,255,0.5);">
                                <?php echo esc_html($stat['label']); ?>
                            </span>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</section>
