<?php
/**
 * Services section template
 *
 * @package GlowGridGrace
 */

$services = glow_grid_grace_get_services(array('posts_per_page' => 5));
?>

<section id="services" class="surface-dark py-24 md:py-32 lg:py-40 relative overflow-hidden">
    <!-- Section Label -->
    <div class="container px-6 md:px-12 mb-16">
        <span class="text-xs font-medium tracking-widest text-muted-foreground uppercase" style="color: rgba(255,255,255,0.5);">
            Servicios
        </span>
    </div>

    <!-- Services List -->
    <div class="container px-6 md:px-12 max-w-[1800px] mx-auto">
        <?php foreach ($services as $index => $service): 
            $service_number = get_post_meta($service->ID, '_service_number', true);
            $service_description = get_post_meta($service->ID, '_service_description', true);
            $hero_image = get_the_post_thumbnail_url($service->ID, 'large') ?: get_template_directory_uri() . '/assets/images/hero-tech.jpg';
        ?>
            <div class="service-item group relative border-t py-8 md:py-12 cursor-pointer transition-all duration-500" style="border-color: rgba(255,255,255,0.1);" data-index="<?php echo $index; ?>">
                <a href="<?php echo esc_url(get_permalink($service->ID)); ?>" class="block">
                    <div class="flex items-center justify-between">
                        <div class="flex items-start gap-6 md:gap-12">
                            <!-- Number -->
                            <span class="service-number text-sm font-medium transition-colors duration-300" style="color: rgba(255,255,255,0.4);">
                                <?php echo esc_html($service_number ?: '0' . ($index + 1)); ?>
                            </span>

                            <!-- Title & Description -->
                            <div>
                                <h3 class="service-title text-3xl md:text-4xl lg:text-5xl font-display font-bold tracking-tight transition-colors duration-300" style="color: white;">
                                    <?php echo esc_html($service->post_title); ?>
                                </h3>
                                <p class="service-description mt-4 text-base md:text-lg max-w-md overflow-hidden opacity-0 max-h-0 transition-all duration-300" style="color: rgba(255,255,255,0.6);">
                                    <?php echo esc_html($service_description ?: $service->post_excerpt); ?>
                                </p>
                            </div>
                        </div>

                        <!-- Arrow -->
                        <div class="service-arrow opacity-0 -translate-x-2 transition-all duration-300">
                            <svg class="w-8 h-8 md:w-10 md:h-10" style="color: #A3F861;" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 17l9.2-9.2M17 8v9m-9-9h9"></path>
                            </svg>
                        </div>
                    </div>

                    <!-- Hover Image -->
                    <div class="service-image absolute right-12 md:right-24 top-1/2 -translate-y-1/2 w-48 md:w-64 h-32 md:h-40 rounded-lg overflow-hidden pointer-events-none hidden lg:block opacity-0 scale-90 transition-all duration-400">
                        <img src="<?php echo esc_url($hero_image); ?>" alt="<?php echo esc_attr($service->post_title); ?>" class="w-full h-full object-cover">
                    </div>
                </a>
            </div>
        <?php endforeach; ?>

        <!-- Last border -->
        <div class="border-t" style="border-color: rgba(255,255,255,0.1);"></div>

        <!-- View All Link -->
        <div class="mt-12 text-center">
            <a href="<?php echo esc_url(get_post_type_archive_link('service')); ?>" class="inline-flex items-center gap-3 text-lg font-medium group" style="color: white;">
                <span class="group-hover:text-accent transition-colors duration-300">
                    Ver todos los servicios
                </span>
                <svg class="w-5 h-5 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" style="color: #A3F861;" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 17l9.2-9.2M17 8v9m-9-9h9"></path>
                </svg>
            </a>
        </div>
    </div>
</section>
