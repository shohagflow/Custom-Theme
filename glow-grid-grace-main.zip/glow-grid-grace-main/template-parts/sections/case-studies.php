<?php
/**
 * Case Studies section template
 *
 * @package GlowGridGrace
 */

$case_studies = glow_grid_grace_get_case_studies(array('posts_per_page' => 4));
$default_images = array(
    get_template_directory_uri() . '/assets/images/hero-tech.jpg',
    get_template_directory_uri() . '/assets/images/case-study-1.jpg',
    get_template_directory_uri() . '/assets/images/case-study-2.jpg',
    get_template_directory_uri() . '/assets/images/case-study-4.jpg',
);
?>

<section id="cases" class="relative surface-light section-premium overflow-hidden" data-parallax-section>
    <!-- Parallax Background Text -->
    <div class="absolute top-0 left-0 w-full pointer-events-none select-none parallax-bg-text">
        <span class="parallax-text block">CASOS</span>
        <span class="parallax-text block text-right">DE ÉXITO</span>
    </div>

    <div class="relative z-10 container px-6 md:px-12">
        <!-- Section Header -->
        <div class="mb-16 md:mb-24">
            <span class="text-xs font-medium tracking-widest text-muted-foreground uppercase">
                Casos de éxito
            </span>
        </div>

        <!-- Cases Grid -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12">
            <?php 
            $case_index = 0;
            foreach ($case_studies as $case_study): 
                $case_image = get_the_post_thumbnail_url($case_study->ID, 'large') ?: ($default_images[$case_index] ?? $default_images[0]);
                $case_category = get_post_meta($case_study->ID, '_case_category', true) ?: 'Proyecto';
            ?>
                <article class="group cursor-pointer case-study-item">
                    <!-- Image Container -->
                    <div class="image-zoom aspect-[4/3] rounded-lg mb-6 relative overflow-hidden bg-muted">
                        <img src="<?php echo esc_url($case_image); ?>" alt="<?php echo esc_attr($case_study->post_title); ?>" class="w-full h-full object-cover">
                        <!-- Overlay -->
                        <div class="absolute inset-0 bg-gradient-to-t from-foreground/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                        
                        <!-- Arrow -->
                        <div class="absolute top-4 right-4 w-12 h-12 bg-background rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 17l9.2-9.2M17 8v9m-9-9h9"></path>
                            </svg>
                        </div>
                    </div>

                    <!-- Content -->
                    <div class="flex items-start justify-between">
                        <div>
                            <h3 class="text-xl md:text-2xl font-display font-bold mb-1 group-hover:text-neon-lime transition-colors duration-300">
                                <?php echo esc_html($case_study->post_title); ?>
                            </h3>
                            <p class="text-sm text-muted-foreground">
                                <?php echo esc_html($case_category); ?>
                            </p>
                        </div>
                    </div>
                </article>
            <?php 
                $case_index++;
            endforeach; 
            
            // If less than 4 case studies, show placeholder cases
            if (count($case_studies) < 4):
                $placeholder_cases = array(
                    array('title' => 'Irontela', 'category' => 'Telecomunicaciones', 'image' => $default_images[0]),
                    array('title' => 'GM Food', 'category' => 'Distribución alimentaria', 'image' => $default_images[1]),
                    array('title' => 'Grupo Euskaltel', 'category' => 'Telecomunicaciones', 'image' => $default_images[2]),
                    array('title' => 'Euskalmet', 'category' => 'Gobierno Vasco', 'image' => $default_images[3]),
                );
                
                for ($i = count($case_studies); $i < 4; $i++):
                    $placeholder = $placeholder_cases[$i];
            ?>
                <article class="group cursor-pointer case-study-item">
                    <div class="image-zoom aspect-[4/3] rounded-lg mb-6 relative overflow-hidden bg-muted">
                        <img src="<?php echo esc_url($placeholder['image']); ?>" alt="<?php echo esc_attr($placeholder['title']); ?>" class="w-full h-full object-cover">
                        <div class="absolute inset-0 bg-gradient-to-t from-foreground/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                        <div class="absolute top-4 right-4 w-12 h-12 bg-background rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 17l9.2-9.2M17 8v9m-9-9h9"></path>
                            </svg>
                        </div>
                    </div>
                    <div class="flex items-start justify-between">
                        <div>
                            <h3 class="text-xl md:text-2xl font-display font-bold mb-1 group-hover:text-neon-lime transition-colors duration-300">
                                <?php echo esc_html($placeholder['title']); ?>
                            </h3>
                            <p class="text-sm text-muted-foreground">
                                <?php echo esc_html($placeholder['category']); ?>
                            </p>
                        </div>
                    </div>
                </article>
            <?php 
                endfor;
            endif;
            ?>
        </div>

        <!-- View All Link -->
        <div class="mt-16 md:mt-24 text-center">
            <a href="<?php echo esc_url(get_post_type_archive_link('case_study')); ?>" class="inline-flex items-center gap-3 text-lg font-medium link-underline group">
                Ver todos los casos
                <svg class="w-5 h-5 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 17l9.2-9.2M17 8v9m-9-9h9"></path>
                </svg>
            </a>
        </div>
    </div>
</section>
