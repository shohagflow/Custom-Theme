<?php
/**
 * Hero section template
 *
 * @package GlowGridGrace
 */
?>

<section class="relative min-h-screen surface-light grid-pattern flex items-center justify-center overflow-hidden">
    <!-- Animated Grid Lines -->
    <div class="absolute inset-0 pointer-events-none">
        <div class="absolute inset-0 grid-pattern opacity-50 animate-grid-flow"></div>
    </div>

    <!-- Green Accent Element - Square/Rectangular Type -->
    <div class="absolute top-[30%] right-[15%] w-64 h-80 md:w-48 md:h-72 hero-accent" style="background-color: #A3F861; transform: rotate(-5deg); z-index: 1;"></div>

    <div class="relative z-10 container px-6 md:px-12 pt-24 md:pt-32">
        <div class="max-w-[1400px] mx-auto">
            <div class="hero-child-heading">
                <!-- Label -->
                <div class="mb-8 md:mb-10 animate-fade-up" style="animation-delay: 0.1s;">
                    <span class="text-xs md:text-sm font-medium tracking-widest uppercase" style="color: rgb(13, 13, 13);">Advanced technological engineering</span>
                </div>

                <!-- Main Headline - Single Paragraph with Spans -->
                <p class="hero-home__description--desktop hero-headlines-container">
                    <span data-speed="1" class="hero-heading-span hero-heading-1 animate-fade-up" style="animation-delay: 0.3s;">
                        <span>We promote the</span>
                    </span>
                    <span data-speed="1.25" class="hero-heading-span hero-heading-2 animate-fade-up" style="animation-delay: 0.4s;">
                        <span>competitiveness of the</span>
                    </span>
                    <span data-speed="1.15" class="hero-heading-span hero-heading-3 animate-fade-up" style="animation-delay: 0.5s;">
                        <span>organizations with</span>
                    </span>
                    <span data-speed="1.05" class="hero-heading-span hero-heading-4 animate-fade-up" style="animation-delay: 0.6s;">
                        <span>open technologies</span>
                    </span>
                    <span data-speed="1.2" class="hero-heading-span hero-heading-5 animate-fade-up" style="animation-delay: 0.7s;">
                        <span>and innovative</span>
                    </span>
                </p>
            </div>

            <!-- CTA Section - Marquee -->
            <div class="mt-16 md:mt-20 cintillo animate-slide-right" style="animation-delay: 0.9s; width: 35%;">
                <div class="marquee marquee--left marquee--row" style="--marquee-item-width: 739.453125px;">
                    <a href="#" class="marquee-link" title="Boost your company's digital transformation with Irontec and the Digital Industry 2024 grants">
                        <div class="marquee__orientation">
                            <div class="marquee__wrapper">
                                <div class="marquee__content">
                                    <span class="marquee__inner">Boost your company's digital transformation with Irontec and the Digital Industry 2024 grants</span>
                                </div>
                                <div class="marquee__content">
                                    <span class="marquee__inner">Boost your company's digital transformation with Irontec and the Digital Industry 2024 grants</span>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <a href="#" class="link" target="_blank">Learn more</a>
            </div>
        </div>
    </div>
</section>
