<?php
/**
 * 404 template
 *
 * @package GlowGridGrace
 */

get_header();
?>

<div class="flex min-h-screen items-center justify-center bg-muted">
    <div class="text-center">
        <h1 class="mb-4 text-4xl font-bold">404</h1>
        <p class="mb-4 text-xl text-muted-foreground">Oops! Page not found</p>
        <a href="<?php echo esc_url(home_url('/')); ?>" class="text-primary underline hover:text-primary/90">
            Return to Home
        </a>
    </div>
</div>

<?php
get_footer();
