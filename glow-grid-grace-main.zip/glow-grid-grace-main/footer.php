<?php
/**
 * Footer template
 *
 * @package GlowGridGrace
 */
?>

    <?php get_template_part('template-parts/footer/footer'); ?>

</div><!-- #page -->

<?php wp_footer(); ?>
</body>
</html>
