<?php
/**
 * Front Page Template
 *
 * @package NIDFIL_Connect
 */

get_header();
?>

<main id="main" class="site-main">
    <!-- Hero Section -->
    <section class="hero-section">
        <h1 class="hero-title">
            <span class="hero-title-highlight">
                <?php echo esc_html(nidfil_get_option('hero_highlight', 'TU REFORMA ESTÁ MUY CERCA')); ?>
            </span>
        </h1>
        <p class="hero-subtitle">
            <?php echo esc_html(nidfil_get_option('hero_subtitle', 'Encuentra a tu especialista de confianza')); ?>
        </p>
        
        <div class="hero-image-container">
            <img src="https://img.freepik.com/free-photo/handyman-process-drilling-wall-with-perforator_169016-51134.jpg?t=st=1765455683~exp=1765459283~hmac=35a304e732aeebdcbafe28793963b0d113d82950211ccd6913410fda0ce8c962&w=1480" alt="Brick and Concrete Construction" class="hero-image">
        </div>
        
        <!-- Search Section -->
        <div class="search-container">
            <form class="search-form" method="get" action="<?php echo esc_url(home_url('/')); ?>">
                <div class="search-field">
                    <select name="specialist" id="specialist">
                        <option value="">Selecciona un especialista</option>
                        <option value="arquitecto">Arquitecto / Topógrafo</option>
                        <option value="excavaciones">Excavaciones y Cimentaciones</option>
                        <option value="estructuras">Estructuras y Hormigón</option>
                        <option value="albanil">Albañil</option>
                        <option value="pladur">Pladur</option>
                        <option value="azulejos">Azulejos y Solados</option>
                        <option value="pintor">Pintor</option>
                        <option value="carpintero">Carpintero</option>
                        <option value="fontanero">Fontanero</option>
                        <option value="electricista">Electricista</option>
                        <option value="aire-acondicionado">Aire Acondicionado</option>
                        <option value="energia-solar">Energía Solar</option>
                        <option value="carpinteria-aluminio">Carpintería Aluminio/PVC</option>
                        <option value="jardineria">Jardinería</option>
                        <option value="piscinas">Piscinas</option>
                        <option value="interiorista">Interiorista / Decorador</option>
                        <option value="limpieza">Limpieza del Hogar y Post-obra</option>
                    </select>
                </div>
                
                <div class="search-field">
                    <input type="text" name="name" id="name" placeholder="Buscar por nombre">
                </div>
                
                <div class="search-field location-field">
                    <input type="text" name="location" id="location" placeholder="Introduce tu ubicación">
                    <svg class="location-icon" width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M10 10C11.3807 10 12.5 8.88071 12.5 7.5C12.5 6.11929 11.3807 5 10 5C8.61929 5 7.5 6.11929 7.5 7.5C7.5 8.88071 8.61929 10 10 10Z" fill="#666666"/>
                        <path d="M10 2C6.68629 2 4 4.68629 4 8C4 12.5 10 18 10 18C10 18 16 12.5 16 8C16 4.68629 13.3137 2 10 2ZM10 10.5C8.61929 10.5 7.5 9.38071 7.5 8C7.5 6.61929 8.61929 5.5 10 5.5C11.3807 5.5 12.5 6.61929 12.5 8C12.5 9.38071 11.3807 10.5 10 10.5Z" fill="#666666"/>
                    </svg>
                </div>
                
                <button type="submit" class="search-button">
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M9 2C5.68629 2 3 4.68629 3 8C3 11.3137 5.68629 14 9 14C10.2958 14 11.4957 13.5892 12.4765 12.8906L16.293 16.7071C16.6835 17.0976 17.3165 17.0976 17.707 16.7071C18.0976 16.3165 18.0976 15.6835 17.707 15.293L13.8906 11.4765C14.5892 10.4957 15 9.29584 15 8C15 4.68629 12.3137 2 9 2ZM9 4C11.2091 4 13 5.79086 13 8C13 10.2091 11.2091 12 9 12C6.79086 12 5 10.2091 5 8C5 5.79086 6.79086 4 9 4Z" fill="currentColor"/>
                    </svg>
                    Buscar
                </button>
            </form>
        </div>
        
        <!-- Specialists Content Section -->
            <div class="specialists-content">
                <!-- Map Container (Left Side) -->
                <div class="map-container">
                    <div class="map-placeholder">
                        <div class="map-pins">
                            <div class="map-pin-large">
                                <svg width="32" height="40" viewBox="0 0 24 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M12 0C5.37258 0 0 5.37258 0 12C0 18 12 32 12 32C12 32 24 18 24 12C24 5.37258 18.6274 0 12 0Z" fill="#f97015"/>
                                    <circle cx="12" cy="12" r="4" fill="white"/>
                                </svg>
                            </div>
                            <div class="map-pin-small" style="top: 25%; left: 35%;">
                                <svg width="24" height="30" viewBox="0 0 24 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M12 0C5.37258 0 0 5.37258 0 12C0 18 12 30 12 30C12 30 24 18 24 12C24 5.37258 18.6274 0 12 0Z" fill="#f97015"/>
                                </svg>
                            </div>
                            <div class="map-pin-small" style="top: 60%; left: 65%;">
                                <svg width="24" height="30" viewBox="0 0 24 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M12 0C5.37258 0 0 5.37258 0 12C0 18 12 30 12 30C12 30 24 18 24 12C24 5.37258 18.6274 0 12 0Z" fill="#f97015"/>
                                </svg>
                            </div>
                        </div>
                        <div class="map-text-content">
                            <p class="map-label">Mapa interactivo</p>
                            <p class="map-coming-soon">Próximamente con integración Mapbox</p>
                        </div>
                    </div>
                </div>
                
                <!-- Specialists List (Right Side) -->
                <div class="specialists-list">
                    <div class="specialist-card" onclick="openSpecialistModal(this)" data-name="Antonio García" data-profession="Electricista" data-rating="4.9" data-reviews="127" data-location="Madrid Centro" data-distance="1.2" data-verified="true" data-avatar="AG" data-whatsapp="34900123456" data-phone="+34900123456" data-description="Profesional con más de 10 años de experiencia en instalaciones eléctricas. Especializado en reformas y nuevas instalaciones. Trabajo garantizado y presupuestos sin compromiso.">
                        <div class="specialist-avatar">
                        <img src="https://i.pravatar.cc/56?img=1" alt="Antonio García" class="specialist-avatar-img">
                        </div>
                        <div class="specialist-details">
                            <div class="specialist-header">
                                <div class="specialist-name-row">
                                    <h3 class="specialist-name">Antonio García</h3>
                                    <span class="verified-badge">
                                        <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M10 3L4.5 8.5L2 6" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                        </svg>
                                        Verificado
                                    </span>
                                </div>
                                <p class="specialist-category">Electricista</p>
                            </div>
                            <div class="specialist-rating">
                                <svg width="16" height="16" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="#FFD700"/>
                                </svg>
                                <span class="rating-value">4.9</span>
                                <span class="reviews-count">(127 opiniones)</span>
                            </div>
                            <div class="specialist-location-row">
                                <div class="specialist-location">
                                    <svg width="14" height="14" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M8 8C9.10457 8 10 7.10457 10 6C10 4.89543 9.10457 4 8 4C6.89543 4 6 4.89543 6 6C6 7.10457 6.89543 8 8 8Z" fill="#666666"/>
                                        <path d="M8 0C3.58172 0 0 3.58172 0 8C0 12 8 16 8 16C8 16 16 12 16 8C16 3.58172 12.4183 0 8 0ZM8 9C6.34315 9 5 7.65685 5 6C5 4.34315 6.34315 3 8 3C9.65685 3 11 4.34315 11 6C11 7.65685 9.65685 9 8 9Z" fill="#666666"/>
                                    </svg>
                                    <span>Madrid Centro</span>
                                </div>
                                <span class="distance">1.2 km</span>
                            </div>
                        <div class="specialist-services">
                            <div class="service-icon" title="Instalaciones eléctricas">
                                <svg width="16" height="16" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M13 2L7 8H10L7 18L13 12H10L13 2Z" fill="#f97015"/>
                                </svg>
                            </div>
                            <div class="service-icon" title="Reparaciones">
                                <svg width="16" height="16" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M10 2L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 2Z" fill="#f97015"/>
                                </svg>
                            </div>
                            <div class="service-icon" title="Iluminación">
                                <svg width="16" height="16" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <circle cx="10" cy="10" r="4" fill="#f97015"/>
                                    <path d="M10 2V4M10 16V18M18 10H16M4 10H2M16.364 3.636L15.364 4.636M4.636 15.364L3.636 16.364M16.364 16.364L15.364 15.364M4.636 4.636L3.636 3.636" stroke="#f97015" stroke-width="1.5" stroke-linecap="round"/>
                                </svg>
                            </div>
                        </div>
                        </div>
                    </div>
                    
                    <div class="specialist-card" onclick="openSpecialistModal(this)" data-name="María López" data-profession="Pintora" data-rating="4.8" data-reviews="89" data-location="Salamanca" data-distance="2.5" data-verified="true" data-avatar="ML" data-whatsapp="34900123457" data-phone="+34900123457" data-description="Pintora profesional con amplia experiencia en pintura de interiores y exteriores. Trabajos de calidad con materiales de primera línea.">
                        <div class="specialist-avatar">
                        <img src="https://i.pravatar.cc/56?img=5" alt="María López" class="specialist-avatar-img">
                        </div>
                        <div class="specialist-details">
                            <div class="specialist-header">
                                <div class="specialist-name-row">
                                    <h3 class="specialist-name">María López</h3>
                                    <span class="verified-badge">
                                        <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M10 3L4.5 8.5L2 6" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                        </svg>
                                        Verificado
                                    </span>
                                </div>
                                <p class="specialist-category">Pintora</p>
                            </div>
                            <div class="specialist-rating">
                                <svg width="16" height="16" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="#FFD700"/>
                                </svg>
                                <span class="rating-value">4.8</span>
                                <span class="reviews-count">(89 opiniones)</span>
                            </div>
                            <div class="specialist-location-row">
                                <div class="specialist-location">
                                    <svg width="14" height="14" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M8 8C9.10457 8 10 7.10457 10 6C10 4.89543 9.10457 4 8 4C6.89543 4 6 4.89543 6 6C6 7.10457 6.89543 8 8 8Z" fill="#666666"/>
                                        <path d="M8 0C3.58172 0 0 3.58172 0 8C0 12 8 16 8 16C8 16 16 12 16 8C16 3.58172 12.4183 0 8 0ZM8 9C6.34315 9 5 7.65685 5 6C5 4.34315 6.34315 3 8 3C9.65685 3 11 4.34315 11 6C11 7.65685 9.65685 9 8 9Z" fill="#666666"/>
                                    </svg>
                                    <span>Salamanca</span>
                                </div>
                                <span class="distance">2.5 km</span>
                            </div>
                        <div class="specialist-services">
                            <div class="service-icon" title="Pintura interior">
                                <svg width="16" height="16" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M10 2L12 6L10 10L8 6L10 2Z" fill="#f97015"/>
                                    <path d="M4 12L6 16L4 20L2 16L4 12Z" fill="#f97015"/>
                                    <path d="M16 12L18 16L16 20L14 16L16 12Z" fill="#f97015"/>
                                </svg>
                            </div>
                            <div class="service-icon" title="Pintura exterior">
                                <svg width="16" height="16" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <rect x="4" y="6" width="12" height="10" rx="1" fill="#f97015"/>
                                    <path d="M6 6V4C6 3.44772 6.44772 3 7 3H13C13.5523 3 14 3.44772 14 4V6" stroke="#f97015" stroke-width="1.5"/>
                                </svg>
                            </div>
                            <div class="service-icon" title="Acabados">
                                <svg width="16" height="16" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M10 4L12 8L10 12L8 8L10 4Z" fill="#f97015"/>
                                    <circle cx="10" cy="14" r="2" fill="#f97015"/>
                                </svg>
                            </div>
                        </div>
                        </div>
                    </div>
                    
                    <div class="specialist-card" onclick="openSpecialistModal(this)" data-name="Carlos Ruiz" data-profession="Fontanero" data-rating="4.7" data-reviews="203" data-location="Chamberí" data-distance="3.1" data-verified="false" data-avatar="CR" data-whatsapp="34900123458" data-phone="+34900123458" data-description="Fontanero con más de 15 años de experiencia. Especializado en reparaciones urgentes, instalaciones y mantenimiento.">
                        <div class="specialist-avatar">
                        <img src="https://i.pravatar.cc/56?img=12" alt="Carlos Ruiz" class="specialist-avatar-img">
                        </div>
                        <div class="specialist-details">
                            <div class="specialist-header">
                                <div class="specialist-name-row">
                                    <h3 class="specialist-name">Carlos Ruiz</h3>
                                </div>
                                <p class="specialist-category">Fontanero</p>
                            </div>
                            <div class="specialist-rating">
                                <svg width="16" height="16" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="#FFD700"/>
                                </svg>
                                <span class="rating-value">4.7</span>
                                <span class="reviews-count">(203 opiniones)</span>
                            </div>
                            <div class="specialist-location-row">
                                <div class="specialist-location">
                                    <svg width="14" height="14" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M8 8C9.10457 8 10 7.10457 10 6C10 4.89543 9.10457 4 8 4C6.89543 4 6 4.89543 6 6C6 7.10457 6.89543 8 8 8Z" fill="#666666"/>
                                        <path d="M8 0C3.58172 0 0 3.58172 0 8C0 12 8 16 8 16C8 16 16 12 16 8C16 3.58172 12.4183 0 8 0ZM8 9C6.34315 9 5 7.65685 5 6C5 4.34315 6.34315 3 8 3C9.65685 3 11 4.34315 11 6C11 7.65685 9.65685 9 8 9Z" fill="#666666"/>
                                    </svg>
                                    <span>Chamberí</span>
                                </div>
                                <span class="distance">3.1 km</span>
                            </div>
                        <div class="specialist-services">
                            <div class="service-icon" title="Reparaciones urgentes">
                                <svg width="16" height="16" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M10 2C5.58172 2 2 5.58172 2 10C2 14.4183 5.58172 18 10 18C14.4183 18 18 14.4183 18 10C18 5.58172 14.4183 2 10 2Z" stroke="#f97015" stroke-width="1.5"/>
                                    <path d="M10 5V10L14 12" stroke="#f97015" stroke-width="1.5" stroke-linecap="round"/>
                                </svg>
                            </div>
                            <div class="service-icon" title="Instalaciones">
                                <svg width="16" height="16" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M8 8H12V10H8V8Z" fill="#f97015"/>
                                    <path d="M10 4V6M10 14V16M16 10H14M6 10H4" stroke="#f97015" stroke-width="1.5" stroke-linecap="round"/>
                                    <circle cx="10" cy="10" r="3" stroke="#f97015" stroke-width="1.5"/>
                                </svg>
                            </div>
                            <div class="service-icon" title="Mantenimiento">
                                <svg width="16" height="16" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M10 2L12 6L10 10L8 6L10 2Z" fill="#f97015"/>
                                    <path d="M4 12L6 16L4 20L2 16L4 12Z" fill="#f97015"/>
                                    <path d="M16 12L18 16L16 20L14 16L16 12Z" fill="#f97015"/>
                                </svg>
                            </div>
                        </div>
                        </div>
                    </div>
                    
                    <div class="specialist-card" onclick="openSpecialistModal(this)" data-name="Laura Martín" data-profession="Interiorista" data-rating="5.0" data-reviews="45" data-location="Retiro" data-distance="4.0" data-verified="true" data-avatar="LM" data-whatsapp="34900123459" data-phone="+34900123459" data-description="Interiorista creativa especializada en diseño de espacios modernos y funcionales. Transformo tu hogar con estilo y elegancia.">
                        <div class="specialist-avatar">
                        <img src="https://i.pravatar.cc/56?img=9" alt="Laura Martín" class="specialist-avatar-img">
                        </div>
                        <div class="specialist-details">
                            <div class="specialist-header">
                                <div class="specialist-name-row">
                                    <h3 class="specialist-name">Laura Martín</h3>
                                    <span class="verified-badge">
                                        <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M10 3L4.5 8.5L2 6" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                        </svg>
                                        Verificado
                                    </span>
                                </div>
                                <p class="specialist-category">Interiorista</p>
                            </div>
                            <div class="specialist-rating">
                                <svg width="16" height="16" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="#FFD700"/>
                                </svg>
                                <span class="rating-value">5.0</span>
                                <span class="reviews-count">(45 opiniones)</span>
                            </div>
                            <div class="specialist-location-row">
                                <div class="specialist-location">
                                    <svg width="14" height="14" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M8 8C9.10457 8 10 7.10457 10 6C10 4.89543 9.10457 4 8 4C6.89543 4 6 4.89543 6 6C6 7.10457 6.89543 8 8 8Z" fill="#666666"/>
                                        <path d="M8 0C3.58172 0 0 3.58172 0 8C0 12 8 16 8 16C8 16 16 12 16 8C16 3.58172 12.4183 0 8 0ZM8 9C6.34315 9 5 7.65685 5 6C5 4.34315 6.34315 3 8 3C9.65685 3 11 4.34315 11 6C11 7.65685 9.65685 9 8 9Z" fill="#666666"/>
                                    </svg>
                                    <span>Retiro</span>
                                </div>
                                <span class="distance">4.0 km</span>
                            </div>
                        <div class="specialist-services">
                            <div class="service-icon" title="Diseño de espacios">
                                <svg width="16" height="16" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <rect x="4" y="4" width="12" height="12" rx="1" stroke="#f97015" stroke-width="1.5"/>
                                    <path d="M4 8H16M8 4V16" stroke="#f97015" stroke-width="1.5"/>
                                </svg>
                            </div>
                            <div class="service-icon" title="Decoración">
                                <svg width="16" height="16" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M10 2L12 6L10 10L8 6L10 2Z" fill="#f97015"/>
                                    <circle cx="10" cy="14" r="2" fill="#f97015"/>
                                </svg>
                            </div>
                            <div class="service-icon" title="Consultoría">
                                <svg width="16" height="16" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <circle cx="10" cy="10" r="7" stroke="#f97015" stroke-width="1.5"/>
                                    <path d="M10 6V10L13 13" stroke="#f97015" stroke-width="1.5" stroke-linecap="round"/>
                                </svg>
                            </div>
                        </div>
                        </div>
                    </div>
                    
                    <a href="#" class="view-more-link">
                        Ver más especialistas
                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M6 4L10 8L6 12" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </a>
            </div>
        </div>
    </section>
    
    <!-- Specialist Details Modal -->
    <div id="specialistModal" class="specialist-modal">
        <div class="modal-overlay" id="specialistModalOverlay"></div>
        <div class="modal-content">
            <button class="modal-close" id="specialistModalClose">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M18 6L6 18M6 6L18 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </button>
            
            <div class="modal-body">
                <div class="modal-header">
                    <div class="modal-avatar">
                        <img id="modalAvatarImg" src="https://i.pravatar.cc/120?img=1" alt="Specialist" class="modal-avatar-img">
                        <div class="avatar-placeholder-large" id="modalAvatar" style="display: none;">AG</div>
                    </div>
                    <div class="modal-header-info">
                        <div class="modal-name-row">
                            <h2 class="modal-name" id="modalName">Antonio García</h2>
                            <span class="verified-badge" id="modalVerified" style="display: none;">
                                <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M10 3L4.5 8.5L2 6" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                                Verificado
                            </span>
                        </div>
                        <p class="modal-profession" id="modalProfession">Electricista</p>
                        <div class="modal-rating" id="modalRating">
                            <svg width="18" height="18" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="#FFD700"/>
                            </svg>
                            <span class="rating-value">4.9</span>
                            <span class="reviews-count">(127 opiniones)</span>
                        </div>
                    </div>
                </div>
                
                <div class="modal-details">
                    <div class="detail-item">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M10 10C11.3807 10 12.5 8.88071 12.5 7.5C12.5 6.11929 11.3807 5 10 5C8.61929 5 7.5 6.11929 7.5 7.5C7.5 8.88071 8.61929 10 10 10Z" fill="#666666"/>
                            <path d="M10 2C6.68629 2 4 4.68629 4 8C4 12.5 10 18 10 18C10 18 16 12.5 16 8C16 4.68629 13.3137 2 10 2ZM10 10.5C8.61929 10.5 7.5 9.38071 7.5 8C7.5 6.61929 8.61929 5.5 10 5.5C11.3807 5.5 12.5 6.61929 12.5 8C12.5 9.38071 11.3807 10.5 10 10.5Z" fill="#666666"/>
                        </svg>
                        <div>
                            <span class="detail-label">Ubicación</span>
                            <span class="detail-value" id="modalLocation">Madrid Centro</span>
                        </div>
                    </div>
                    
                    <div class="detail-item">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M10 2C6.68629 2 4 4.68629 4 8C4 12.5 10 18 10 18C10 18 16 12.5 16 8C16 4.68629 13.3137 2 10 2Z" fill="#f97015"/>
                            <circle cx="10" cy="8" r="2" fill="white"/>
                        </svg>
                        <div>
                            <span class="detail-label">Distancia</span>
                            <span class="detail-value" id="modalDistance">1.2 km</span>
                        </div>
                    </div>
                    
                    <div class="detail-item">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M10 2C5.58172 2 2 5.58172 2 10C2 14.4183 5.58172 18 10 18C14.4183 18 18 14.4183 18 10C18 5.58172 14.4183 2 10 2ZM10 16C6.68629 16 4 13.3137 4 10C4 6.68629 6.68629 4 10 4C13.3137 4 16 6.68629 16 10C16 13.3137 13.3137 16 10 16Z" fill="#666666"/>
                            <path d="M10 5V10L14 12" stroke="#666666" stroke-width="2" stroke-linecap="round"/>
                        </svg>
                        <div>
                            <span class="detail-label">Tiempo de respuesta</span>
                            <span class="detail-value">24 horas</span>
                        </div>
                    </div>
                </div>
                
                <div class="modal-description">
                    <h3>Acerca de</h3>
                    <p id="modalDescription">Profesional con más de 10 años de experiencia en instalaciones eléctricas. Especializado en reformas y nuevas instalaciones. Trabajo garantizado y presupuestos sin compromiso.</p>
                </div>
                
                <div class="modal-services">
                    <h3>Servicios</h3>
                    <div class="modal-services-icons" id="modalServicesIcons">
                        <div class="service-icon-large" title="Instalaciones eléctricas">
                            <svg width="24" height="24" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M13 2L7 8H10L7 18L13 12H10L13 2Z" fill="#f97015"/>
                            </svg>
                            <span>Instalaciones eléctricas</span>
                        </div>
                        <div class="service-icon-large" title="Reparaciones">
                            <svg width="24" height="24" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M10 2L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 2Z" fill="#f97015"/>
                            </svg>
                            <span>Reparaciones</span>
                        </div>
                        <div class="service-icon-large" title="Iluminación">
                            <svg width="24" height="24" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <circle cx="10" cy="10" r="4" fill="#f97015"/>
                                <path d="M10 2V4M10 16V18M18 10H16M4 10H2M16.364 3.636L15.364 4.636M4.636 15.364L3.636 16.364M16.364 16.364L15.364 15.364M4.636 4.636L3.636 3.636" stroke="#f97015" stroke-width="1.5" stroke-linecap="round"/>
                            </svg>
                            <span>Iluminación</span>
                        </div>
                    </div>
                    <div class="services-list">
                        <span class="service-tag">Instalaciones eléctricas</span>
                        <span class="service-tag">Reparaciones</span>
                        <span class="service-tag">Iluminación</span>
                        <span class="service-tag">Cuadros eléctricos</span>
                    </div>
                </div>
                
                <div class="modal-actions">
                    <a href="#" id="modalWhatsApp" target="_blank" class="action-btn whatsapp-btn">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z" fill="white"/>
                        </svg>
                        WhatsApp
                    </a>
                    <a href="#" id="modalCall" class="action-btn call-btn">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M20.01 15.38c-1.23 0-2.42-.2-3.53-.56-.35-.12-.74-.03-1.01.24l-1.57 1.97c-2.83-1.35-5.48-3.9-6.89-6.83l1.95-1.66c.27-.28.35-.67.24-1.02-.37-1.11-.56-2.3-.56-3.53 0-.54-.45-.99-.99-.99H4.19C3.65 3 3 3.24 3 3.99 3 13.28 10.73 21 20.01 21c.71 0 .99-.63.99-1.18v-3.45c0-.54-.45-.99-.99-.99z" fill="white"/>
                        </svg>
                        Llamar
                    </a>
                </div>
            </div>
        </div>
    </div>
    
    <!-- How It Works Section -->
    <section class="how-it-works-section">
        <div class="section-container">
            <h2 class="section-title">¿Cómo Funciona?</h2>
            <p class="section-subtitle">Encuentra y contrata especialistas en solo 3 pasos</p>
            
            <div class="steps-grid">
                <div class="step-card">
                    <div class="step-number">1</div>
                    <div class="step-icon">
                        <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M21 21L15 15M17 10C17 13.866 13.866 17 10 17C6.13401 17 3 13.866 3 10C3 6.13401 6.13401 3 10 3C13.866 3 17 6.13401 17 10Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </div>
                    <h3 class="step-title">Busca</h3>
                    <p class="step-description">Encuentra el especialista que necesitas según tu proyecto y ubicación</p>
                </div>
                
                <div class="step-card">
                    <div class="step-number">2</div>
                    <div class="step-icon">
                        <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M9 12L11 14L15 10M21 12C21 16.9706 16.9706 21 12 21C7.02944 21 3 16.9706 3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </div>
                    <h3 class="step-title">Compara</h3>
                    <p class="step-description">Revisa perfiles, valoraciones y presupuestos de diferentes especialistas</p>
                </div>
                
                <div class="step-card">
                    <div class="step-number">3</div>
                    <div class="step-icon">
                        <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M9 12L11 14L15 10M21 12C21 16.9706 16.9706 21 12 21C7.02944 21 3 16.9706 3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </div>
                    <h3 class="step-title">Contrata</h3>
                    <p class="step-description">Contacta directamente con el especialista y comienza tu proyecto</p>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Why Choose NIDFIL Section -->
    <section class="why-choose-section">
        <div class="section-container">
            <h2 class="section-title">¿Por qué elegir NIDFIL?</h2>
            <p class="section-subtitle">Conectamos propietarios con los mejores profesionales de la construcción y reforma</p>
            
            <div class="why-choose-grid">
                <div class="why-choose-card">
                    <div class="why-choose-image">
                        <img src="https://img.freepik.com/free-photo/tiler-working-renovation-apartment_23-2149278557.jpg?semt=ais_hybrid&w=740&q=80" alt="Profesionales verificados" class="why-choose-img">
                        <div class="why-choose-overlay">
                            <h3 class="why-choose-card-title">Profesionales verificados</h3>
                            <p class="why-choose-card-text">Todos nuestros especialistas pasan por un proceso de verificación para garantizar su experiencia.</p>
                        </div>
                    </div>
                </div>
                
                <div class="why-choose-card">
                    <div class="why-choose-image">
                        <img src="https://img.freepik.com/premium-photo/renovation-progress-construction-workers-transforming-apartment-hallway-with-natural-light_937679-66466.jpg?semt=ais_hybrid&w=740&q=80" alt="Presupuestos sin compromiso" class="why-choose-img">
                        <div class="why-choose-overlay">
                            <h3 class="why-choose-card-title">Presupuestos sin compromiso</h3>
                            <p class="why-choose-card-text">Recibe presupuestos claros y detallados antes de comenzar cualquier proyecto.</p>
                        </div>
                    </div>
                </div>
                
                <div class="why-choose-card">
                    <div class="why-choose-image">
                        <img src="https://img.freepik.com/free-photo/civil-engineer-construction-worker-architects-wearing-hardhats-safety-vests-are-working-together-construction-site-building-home-cooperation-teamwork-concept_640221-172.jpg?semt=ais_hybrid&w=740&q=80" alt="Resultados garantizados" class="why-choose-img">
                        <div class="why-choose-overlay">
                            <h3 class="why-choose-card-title">Resultados garantizados</h3>
                            <p class="why-choose-card-text">Transforma tu hogar con la tranquilidad de trabajar con los mejores del sector.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Testimonials Section -->
    <section class="testimonials-section">
        <div class="section-container">
            <h2 class="section-title">Lo Que Dicen Nuestros Clientes</h2>
            <p class="section-subtitle">Experiencias reales de quienes han confiado en nosotros</p>
            
            <div class="testimonials-grid">
                <div class="testimonial-card">
                    <div class="testimonial-rating">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="#f97015"/>
                        </svg>
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="#f97015"/>
                        </svg>
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="#f97015"/>
                        </svg>
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="#f97015"/>
                        </svg>
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="#f97015"/>
                        </svg>
                    </div>
                    <p class="testimonial-text">"Encontré al arquitecto perfecto para mi proyecto. El proceso fue muy sencillo y el resultado superó mis expectativas."</p>
                    <div class="testimonial-author">
                        <div class="author-avatar">M</div>
                        <div class="author-info">
                            <div class="author-name">María González</div>
                            <div class="author-location">Madrid</div>
                        </div>
                    </div>
                </div>
                
                <div class="testimonial-card">
                    <div class="testimonial-rating">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="#f97015"/>
                        </svg>
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="#f97015"/>
                        </svg>
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="#f97015"/>
                        </svg>
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="#f97015"/>
                        </svg>
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="#f97015"/>
                        </svg>
                    </div>
                    <p class="testimonial-text">"Excelente plataforma. Pude comparar varios presupuestos y elegir el que mejor se adaptaba a mi presupuesto."</p>
                    <div class="testimonial-author">
                        <div class="author-avatar">J</div>
                        <div class="author-info">
                            <div class="author-name">Juan Martínez</div>
                            <div class="author-location">Barcelona</div>
                        </div>
                    </div>
                </div>
                
                <div class="testimonial-card">
                    <div class="testimonial-rating">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="#f97015"/>
                        </svg>
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="#f97015"/>
                        </svg>
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="#f97015"/>
                        </svg>
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="#f97015"/>
                        </svg>
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="#f97015"/>
                        </svg>
                    </div>
                    <p class="testimonial-text">"Muy profesional y fácil de usar. Encontré un albañil excelente que terminó mi reforma a tiempo y con calidad."</p>
                    <div class="testimonial-author">
                        <div class="author-avatar">A</div>
                        <div class="author-info">
                            <div class="author-name">Ana Rodríguez</div>
                            <div class="author-location">Valencia</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- CTA for Professionals Section -->
    <section class="cta-professionals-section">
        <div class="section-container">
            <div class="cta-professionals-content">
                <h2 class="cta-professionals-title">¿Eres un profesional del sector?</h2>
                <p class="cta-professionals-subtitle">Únete a NIDFIL y conecta con clientes que buscan exactamente tus servicios. Aumenta tu visibilidad y haz crecer tu negocio.</p>
                <a href="#" class="btn btn-white btn-large">
                    Registrarme como Especialista
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M4 10H16M16 10L11 5M16 10L11 15" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                </a>
                
                <div class="cta-statistics">
                    <div class="stat-item">
                        <div class="stat-number">500+</div>
                        <div class="stat-label">Especialistas activos</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-number">10K+</div>
                        <div class="stat-label">Proyectos completados</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-number">4.8★</div>
                        <div class="stat-label">Valoración media</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-number">24h</div>
                        <div class="stat-label">Tiempo de respuesta</div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<script>
// Ensure specialist card clicks work - Direct implementation
(function() {
    function initSpecialistCardClicks() {
        const cards = document.querySelectorAll('.specialist-card');
        console.log('Initializing specialist cards:', cards.length);
        
        cards.forEach(function(card) {
            // Remove onclick attribute to prevent conflicts
            if (card.hasAttribute('onclick')) {
                card.removeAttribute('onclick');
            }
            
            // Remove any existing listeners by cloning
            const newCard = card.cloneNode(true);
            card.parentNode.replaceChild(newCard, card);
            
            // Add fresh click listener
            newCard.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                
                console.log('Card clicked, opening modal...');
                
                // Get data attributes
                const data = {
                    name: newCard.getAttribute('data-name') || '',
                    profession: newCard.getAttribute('data-profession') || '',
                    rating: newCard.getAttribute('data-rating') || '0',
                    reviews: newCard.getAttribute('data-reviews') || '0',
                    location: newCard.getAttribute('data-location') || '',
                    distance: newCard.getAttribute('data-distance') || '0',
                    verified: newCard.getAttribute('data-verified') === 'true',
                    avatar: newCard.getAttribute('data-avatar') || '',
                    whatsapp: newCard.getAttribute('data-whatsapp') || '',
                    phone: newCard.getAttribute('data-phone') || '',
                    description: newCard.getAttribute('data-description') || ''
                };
                
                // Get modal
                const modal = document.getElementById('specialistModal');
                if (!modal) {
                    console.error('Modal not found!');
                    return;
                }
                
                // Update modal content
                const modalAvatar = document.getElementById('modalAvatar');
                const modalAvatarImg = document.getElementById('modalAvatarImg');
                const modalName = document.getElementById('modalName');
                const modalProfession = document.getElementById('modalProfession');
                const modalRating = document.getElementById('modalRating');
                const modalLocation = document.getElementById('modalLocation');
                const modalDistance = document.getElementById('modalDistance');
                const modalDescription = document.getElementById('modalDescription');
                const verifiedBadge = document.getElementById('modalVerified');
                const whatsappBtn = document.getElementById('modalWhatsApp');
                const callBtn = document.getElementById('modalCall');
                
                // Update avatar image based on specialist name
                if (modalAvatarImg) {
                    const avatarMap = {
                        'Antonio García': 'https://i.pravatar.cc/120?img=1',
                        'María López': 'https://i.pravatar.cc/120?img=5',
                        'Carlos Ruiz': 'https://i.pravatar.cc/120?img=12',
                        'Laura Martín': 'https://i.pravatar.cc/120?img=9'
                    };
                    modalAvatarImg.src = avatarMap[data.name] || 'https://i.pravatar.cc/120?img=1';
                    modalAvatarImg.alt = data.name;
                }
                if (modalAvatar) modalAvatar.textContent = data.avatar;
                if (modalName) modalName.textContent = data.name;
                if (modalProfession) modalProfession.textContent = data.profession;
                if (modalRating) {
                    modalRating.innerHTML = `
                        <svg width="18" height="18" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="#FFD700"/>
                        </svg>
                        <span class="rating-value">${data.rating}</span>
                        <span class="reviews-count">(${data.reviews} opiniones)</span>
                    `;
                }
                if (modalLocation) modalLocation.textContent = data.location;
                if (modalDistance) modalDistance.textContent = data.distance + ' km';
                if (modalDescription) modalDescription.textContent = data.description;
                
                // Update service icons based on profession
                const modalServicesIcons = document.getElementById('modalServicesIcons');
                if (modalServicesIcons) {
                    const serviceIconsMap = {
                        'Electricista': `
                            <div class="service-icon-large" title="Instalaciones eléctricas">
                                <svg width="24" height="24" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M13 2L7 8H10L7 18L13 12H10L13 2Z" fill="#f97015"/>
                                </svg>
                                <span>Instalaciones eléctricas</span>
                            </div>
                            <div class="service-icon-large" title="Reparaciones">
                                <svg width="24" height="24" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M10 2L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 2Z" fill="#f97015"/>
                                </svg>
                                <span>Reparaciones</span>
                            </div>
                            <div class="service-icon-large" title="Iluminación">
                                <svg width="24" height="24" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <circle cx="10" cy="10" r="4" fill="#f97015"/>
                                    <path d="M10 2V4M10 16V18M18 10H16M4 10H2M16.364 3.636L15.364 4.636M4.636 15.364L3.636 16.364M16.364 16.364L15.364 15.364M4.636 4.636L3.636 3.636" stroke="#f97015" stroke-width="1.5" stroke-linecap="round"/>
                                </svg>
                                <span>Iluminación</span>
                            </div>
                        `,
                        'Pintora': `
                            <div class="service-icon-large" title="Pintura interior">
                                <svg width="24" height="24" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M10 2L12 6L10 10L8 6L10 2Z" fill="#f97015"/>
                                    <path d="M4 12L6 16L4 20L2 16L4 12Z" fill="#f97015"/>
                                    <path d="M16 12L18 16L16 20L14 16L16 12Z" fill="#f97015"/>
                                </svg>
                                <span>Pintura interior</span>
                            </div>
                            <div class="service-icon-large" title="Pintura exterior">
                                <svg width="24" height="24" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <rect x="4" y="6" width="12" height="10" rx="1" fill="#f97015"/>
                                    <path d="M6 6V4C6 3.44772 6.44772 3 7 3H13C13.5523 3 14 3.44772 14 4V6" stroke="#f97015" stroke-width="1.5"/>
                                </svg>
                                <span>Pintura exterior</span>
                            </div>
                            <div class="service-icon-large" title="Acabados">
                                <svg width="24" height="24" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M10 4L12 8L10 12L8 8L10 4Z" fill="#f97015"/>
                                    <circle cx="10" cy="14" r="2" fill="#f97015"/>
                                </svg>
                                <span>Acabados</span>
                            </div>
                        `,
                        'Fontanero': `
                            <div class="service-icon-large" title="Reparaciones urgentes">
                                <svg width="24" height="24" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M10 2C5.58172 2 2 5.58172 2 10C2 14.4183 5.58172 18 10 18C14.4183 18 18 14.4183 18 10C18 5.58172 14.4183 2 10 2Z" stroke="#f97015" stroke-width="1.5"/>
                                    <path d="M10 5V10L14 12" stroke="#f97015" stroke-width="1.5" stroke-linecap="round"/>
                                </svg>
                                <span>Reparaciones urgentes</span>
                            </div>
                            <div class="service-icon-large" title="Instalaciones">
                                <svg width="24" height="24" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M8 8H12V10H8V8Z" fill="#f97015"/>
                                    <path d="M10 4V6M10 14V16M16 10H14M6 10H4" stroke="#f97015" stroke-width="1.5" stroke-linecap="round"/>
                                    <circle cx="10" cy="10" r="3" stroke="#f97015" stroke-width="1.5"/>
                                </svg>
                                <span>Instalaciones</span>
                            </div>
                            <div class="service-icon-large" title="Mantenimiento">
                                <svg width="24" height="24" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M10 2L12 6L10 10L8 6L10 2Z" fill="#f97015"/>
                                    <path d="M4 12L6 16L4 20L2 16L4 12Z" fill="#f97015"/>
                                    <path d="M16 12L18 16L16 20L14 16L16 12Z" fill="#f97015"/>
                                </svg>
                                <span>Mantenimiento</span>
                            </div>
                        `,
                        'Interiorista': `
                            <div class="service-icon-large" title="Diseño de espacios">
                                <svg width="24" height="24" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <rect x="4" y="4" width="12" height="12" rx="1" stroke="#f97015" stroke-width="1.5"/>
                                    <path d="M4 8H16M8 4V16" stroke="#f97015" stroke-width="1.5"/>
                                </svg>
                                <span>Diseño de espacios</span>
                            </div>
                            <div class="service-icon-large" title="Decoración">
                                <svg width="24" height="24" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M10 2L12 6L10 10L8 6L10 2Z" fill="#f97015"/>
                                    <circle cx="10" cy="14" r="2" fill="#f97015"/>
                                </svg>
                                <span>Decoración</span>
                            </div>
                            <div class="service-icon-large" title="Consultoría">
                                <svg width="24" height="24" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <circle cx="10" cy="10" r="7" stroke="#f97015" stroke-width="1.5"/>
                                    <path d="M10 6V10L13 13" stroke="#f97015" stroke-width="1.5" stroke-linecap="round"/>
                                </svg>
                                <span>Consultoría</span>
                            </div>
                        `
                    };
                    modalServicesIcons.innerHTML = serviceIconsMap[data.profession] || serviceIconsMap['Electricista'];
                }
                
                if (verifiedBadge) {
                    verifiedBadge.style.display = data.verified ? 'inline-flex' : 'none';
                }
                
                if (whatsappBtn && data.whatsapp) {
                    whatsappBtn.href = `https://wa.me/${data.whatsapp}?text=Hola%20${encodeURIComponent(data.name.split(' ')[0])},%20me%20interesa%20tu%20servicio%20de%20${encodeURIComponent(data.profession.toLowerCase())}`;
                }
                if (callBtn && data.phone) {
                    callBtn.href = `tel:${data.phone}`;
                }
                
                // Show modal
                modal.classList.add('modal-active');
                document.body.style.overflow = 'hidden';
                
                console.log('Modal opened successfully');
            });
        });
    }
    
    // Close modal function
    function closeSpecialistModal() {
        const modal = document.getElementById('specialistModal');
        if (modal) {
            modal.classList.remove('modal-active');
            document.body.style.overflow = '';
            console.log('Modal closed');
        }
    }
    
    // Make close function globally accessible
    window.closeSpecialistModal = closeSpecialistModal;
    
    // Initialize close button and overlay listeners
    let closeButtonInitialized = false;
    function initModalCloseButtons() {
        if (closeButtonInitialized) return;
        
        const closeBtn = document.getElementById('specialistModalClose');
        const overlay = document.getElementById('specialistModalOverlay');
        
        if (closeBtn) {
            // Remove any existing listeners by cloning
            const newCloseBtn = closeBtn.cloneNode(true);
            closeBtn.parentNode.replaceChild(newCloseBtn, closeBtn);
            
            newCloseBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                console.log('Close button clicked');
                closeSpecialistModal();
            });
            console.log('Close button listener added');
        } else {
            console.error('Close button not found');
        }
        
        if (overlay) {
            // Remove any existing listeners by cloning
            const newOverlay = overlay.cloneNode(true);
            overlay.parentNode.replaceChild(newOverlay, overlay);
            
            newOverlay.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                console.log('Overlay clicked');
                closeSpecialistModal();
            });
            console.log('Overlay listener added');
        }
        
        // ESC key support (only add once)
        if (!window.escKeyListenerAdded) {
            document.addEventListener('keydown', function(e) {
                const modal = document.getElementById('specialistModal');
                if (e.key === 'Escape' && modal && modal.classList.contains('modal-active')) {
                    console.log('ESC key pressed');
                    closeSpecialistModal();
                }
            });
            window.escKeyListenerAdded = true;
        }
        
        closeButtonInitialized = true;
    }
    
    // Initialize when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function() {
            initSpecialistCardClicks();
            initModalCloseButtons();
        });
    } else {
        initSpecialistCardClicks();
        initModalCloseButtons();
    }
    
    // Also try after delays
    setTimeout(function() {
        initSpecialistCardClicks();
        initModalCloseButtons();
    }, 500);
    setTimeout(function() {
        initSpecialistCardClicks();
        initModalCloseButtons();
    }, 1000);
})();
</script>

<?php
get_footer();

