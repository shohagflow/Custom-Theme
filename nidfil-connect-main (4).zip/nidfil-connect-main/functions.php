<?php
/**
 * NIDFIL Connect Theme Functions
 *
 * @package NIDFIL_Connect
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

/**
 * Theme Setup
 */
function nidfil_connect_setup() {
    // Add theme support
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
    ));
    
    // Add custom logo support
    add_theme_support('custom-logo', array(
        'height'      => 100,
        'width'       => 400,
        'flex-height' => true,
        'flex-width'  => true,
        'header-text' => array('site-title', 'site-description'),
    ));
    
    // Register navigation menus
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'nidfil-connect'),
        'footer' => __('Footer Menu', 'nidfil-connect'),
    ));
    
    // Set content width
    $GLOBALS['content_width'] = 1200;
}
add_action('after_setup_theme', 'nidfil_connect_setup');

/**
 * Auto-create Client Profile page if it doesn't exist
 */
function nidfil_create_client_profile_page() {
    // Check if page already exists with correct template
    $client_profile_page = get_pages(array(
        'meta_key' => '_wp_page_template',
        'meta_value' => 'page-client-profile.php',
        'number' => 1,
        'post_status' => 'publish'
    ));
    
    if (!empty($client_profile_page)) {
        $page = $client_profile_page[0];
        // Ensure page is published
        if ($page->post_status !== 'publish') {
            wp_update_post(array(
                'ID' => $page->ID,
                'post_status' => 'publish'
            ));
        }
        return $page->ID;
    }
    
    // Check if a page with slug 'client-profile' exists
    $existing_page = get_page_by_path('client-profile');
    
    if ($existing_page) {
        // Update existing page to use the template and ensure it's published
        update_post_meta($existing_page->ID, '_wp_page_template', 'page-client-profile.php');
        if ($existing_page->post_status !== 'publish') {
            wp_update_post(array(
                'ID' => $existing_page->ID,
                'post_status' => 'publish'
            ));
        }
        clean_post_cache($existing_page->ID);
        return $existing_page->ID;
    }
    
    // Create the page
    $page_data = array(
        'post_title'    => 'Client Profile',
        'post_name'     => 'client-profile',
        'post_content'  => '<!-- This page uses the Client Profile template -->',
        'post_status'   => 'publish',
        'post_type'     => 'page',
        'post_author'   => 1,
    );
    
    $page_id = wp_insert_post($page_data);
    
    if ($page_id && !is_wp_error($page_id)) {
        // Set the page template
        update_post_meta($page_id, '_wp_page_template', 'page-client-profile.php');
        // Clear cache
        clean_post_cache($page_id);
        // Flush rewrite rules
        flush_rewrite_rules(false);
        return $page_id;
    }
    
    return false;
}

/**
 * Create Specialist Profile Page
 */
function nidfil_create_specialist_profile_page() {
    // Check if page already exists with correct template
    $specialist_profile_page = get_pages(array(
        'meta_key' => '_wp_page_template',
        'meta_value' => 'page-specialist-profile.php',
        'number' => 1,
        'post_status' => 'publish'
    ));
    
    if (!empty($specialist_profile_page)) {
        $page = $specialist_profile_page[0];
        // Ensure page is published
        if ($page->post_status !== 'publish') {
            wp_update_post(array(
                'ID' => $page->ID,
                'post_status' => 'publish'
            ));
        }
        return $page->ID;
    }
    
    // Check if a page with slug 'specialist-profile' exists
    $existing_page = get_page_by_path('specialist-profile');
    
    if ($existing_page) {
        // Update existing page to use the template and ensure it's published
        update_post_meta($existing_page->ID, '_wp_page_template', 'page-specialist-profile.php');
        if ($existing_page->post_status !== 'publish') {
            wp_update_post(array(
                'ID' => $existing_page->ID,
                'post_status' => 'publish'
            ));
        }
        clean_post_cache($existing_page->ID);
        return $existing_page->ID;
    }
    
    // Create the page
    $page_data = array(
        'post_title'    => 'Specialist Profile',
        'post_name'     => 'specialist-profile',
        'post_content'  => '<!-- This page uses the Specialist Profile template -->',
        'post_status'   => 'publish',
        'post_type'     => 'page',
        'post_author'   => 1,
    );
    
    $page_id = wp_insert_post($page_data);
    
    if ($page_id && !is_wp_error($page_id)) {
        // Set the page template
        update_post_meta($page_id, '_wp_page_template', 'page-specialist-profile.php');
        // Clear cache
        clean_post_cache($page_id);
        // Flush rewrite rules
        flush_rewrite_rules(false);
        return $page_id;
    }
    
    return false;
}

/**
 * Flush rewrite rules on theme activation
 */
function nidfil_theme_activation() {
    nidfil_create_client_profile_page();
    nidfil_create_specialist_profile_page();
    flush_rewrite_rules();
}
add_action('after_switch_theme', 'nidfil_theme_activation');

// Also try to create the page on theme setup
add_action('after_setup_theme', 'nidfil_create_client_profile_page');

/**
 * Ensure Client Profile page exists when template is loaded
 */
function nidfil_ensure_client_profile_page() {
    // Only run on frontend
    if (is_admin() || wp_doing_ajax()) {
        return;
    }
    
    global $wp_query, $post;
    
    // Check if we're on the client-profile page or trying to access it
    $is_client_profile = false;
    $request_uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
    
    // Check various ways the page might be accessed
    if (isset($wp_query->query_vars['pagename']) && $wp_query->query_vars['pagename'] === 'client-profile') {
        $is_client_profile = true;
    } elseif (strpos($request_uri, '/client-profile') !== false || strpos($request_uri, 'client-profile') !== false) {
        $is_client_profile = true;
    } elseif (isset($wp_query->query_vars['name']) && $wp_query->query_vars['name'] === 'client-profile') {
        $is_client_profile = true;
    }
    
    if ($is_client_profile) {
        // Ensure page exists
        $page_id = nidfil_create_client_profile_page();
        
        if ($page_id) {
            // Get the page object
            $page = get_post($page_id);
            
            if ($page && $page->post_status === 'publish') {
                // Ensure template is assigned
                $current_template = get_post_meta($page_id, '_wp_page_template', true);
                if ($current_template !== 'page-client-profile.php') {
                    update_post_meta($page_id, '_wp_page_template', 'page-client-profile.php');
                }
                
                // Set up the global post object
                $post = $page;
                setup_postdata($post);
                
                // Fix the query
                $wp_query->queried_object = $post;
                $wp_query->queried_object_id = $post->ID;
                $wp_query->is_page = true;
                $wp_query->is_singular = true;
                $wp_query->is_404 = false;
                $wp_query->posts = array($post);
                $wp_query->post_count = 1;
                $wp_query->found_posts = 1;
                
                // Set the template
                $wp_query->is_page_template = true;
            }
        }
    }
}
add_action('template_redirect', 'nidfil_ensure_client_profile_page', 1);

/**
 * Prevent 404 on client-profile page
 */
function nidfil_prevent_client_profile_404($query) {
    if (is_admin() || !$query->is_main_query()) {
        return;
    }
    
    $request_uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
    
    if (strpos($request_uri, '/client-profile') !== false || strpos($request_uri, 'client-profile') !== false) {
        $page = get_page_by_path('client-profile');
        
        if ($page && $page->post_status === 'publish') {
            $query->is_404 = false;
            $query->is_page = true;
            $query->is_singular = true;
            $query->queried_object = $page;
            $query->queried_object_id = $page->ID;
            $query->posts = array($page);
            $query->post_count = 1;
            $query->found_posts = 1;
        }
    }
}
add_action('parse_query', 'nidfil_prevent_client_profile_404');

/**
 * Ensure correct template is used for client-profile page
 */
function nidfil_force_client_profile_template($template) {
    global $wp_query, $post;
    
    // Check if we're on the client-profile page
    $is_client_profile = false;
    $request_uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
    
    // Check various ways the page might be accessed
    if (isset($wp_query->query_vars['pagename']) && $wp_query->query_vars['pagename'] === 'client-profile') {
        $is_client_profile = true;
    } elseif (strpos($request_uri, '/client-profile') !== false || strpos($request_uri, 'client-profile') !== false) {
        $is_client_profile = true;
    } elseif (isset($wp_query->query_vars['name']) && $wp_query->query_vars['name'] === 'client-profile') {
        $is_client_profile = true;
    } elseif (is_page() && isset($post) && $post->post_name === 'client-profile') {
        $is_client_profile = true;
    }
    
    if ($is_client_profile) {
        // Ensure page exists first
        $page_id = nidfil_create_client_profile_page();
        
        if (!$page_id) {
            // Try to find the page
            $page = get_page_by_path('client-profile');
            if ($page) {
                $page_id = $page->ID;
            }
        }
        
        if ($page_id) {
            $page = get_post($page_id);
            
            if ($page) {
                // Ensure template is assigned
                $current_template = get_post_meta($page_id, '_wp_page_template', true);
                if ($current_template !== 'page-client-profile.php') {
                    update_post_meta($page_id, '_wp_page_template', 'page-client-profile.php');
                }
                
                // Set up the post object
                $post = $page;
                setup_postdata($post);
                
                // Fix the query
                $wp_query->queried_object = $post;
                $wp_query->queried_object_id = $post->ID;
                $wp_query->is_page = true;
                $wp_query->is_singular = true;
                $wp_query->is_404 = false;
                $wp_query->posts = array($post);
                $wp_query->post_count = 1;
                $wp_query->found_posts = 1;
                
                // Load the template file
                $template_file = get_template_directory() . '/page-client-profile.php';
                if (file_exists($template_file)) {
                    return $template_file;
                }
            }
        }
    }
    
    return $template;
}
add_filter('template_include', 'nidfil_force_client_profile_template', 99);

/**
 * Ensure specialist profile page exists and is set up correctly
 */
function nidfil_ensure_specialist_profile_page() {
    global $wp_query, $post;
    
    $request_uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
    
    // Check if we're accessing the specialist-profile page
    $is_specialist_profile = false;
    if (isset($wp_query->query_vars['pagename']) && $wp_query->query_vars['pagename'] === 'specialist-profile') {
        $is_specialist_profile = true;
    } elseif (strpos($request_uri, '/specialist-profile') !== false || strpos($request_uri, 'specialist-profile') !== false) {
        $is_specialist_profile = true;
    } elseif (isset($wp_query->query_vars['name']) && $wp_query->query_vars['name'] === 'specialist-profile') {
        $is_specialist_profile = true;
    }
    
    if ($is_specialist_profile) {
        // Ensure page exists
        $page_id = nidfil_create_specialist_profile_page();
        
        if ($page_id) {
            // Get the page object
            $page = get_post($page_id);
            
            if ($page && $page->post_status === 'publish') {
                // Ensure template is assigned
                $current_template = get_post_meta($page_id, '_wp_page_template', true);
                if ($current_template !== 'page-specialist-profile.php') {
                    update_post_meta($page_id, '_wp_page_template', 'page-specialist-profile.php');
                }
                
                // Set up the global post object
                $post = $page;
                setup_postdata($post);
                
                // Fix the query
                $wp_query->queried_object = $post;
                $wp_query->queried_object_id = $post->ID;
                $wp_query->is_page = true;
                $wp_query->is_singular = true;
                $wp_query->is_404 = false;
                $wp_query->posts = array($post);
                $wp_query->post_count = 1;
                $wp_query->found_posts = 1;
                
                // Set the template
                $wp_query->is_page_template = true;
            }
        }
    }
}
add_action('template_redirect', 'nidfil_ensure_specialist_profile_page', 1);

/**
 * Prevent 404 on specialist-profile page
 */
function nidfil_prevent_specialist_profile_404($query) {
    if (is_admin() || !$query->is_main_query()) {
        return;
    }
    
    $request_uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
    
    if (strpos($request_uri, '/specialist-profile') !== false || strpos($request_uri, 'specialist-profile') !== false) {
        $page = get_page_by_path('specialist-profile');
        
        if ($page && $page->post_status === 'publish') {
            $query->is_404 = false;
            $query->is_page = true;
            $query->is_singular = true;
            $query->queried_object = $page;
            $query->queried_object_id = $page->ID;
            $query->posts = array($page);
            $query->post_count = 1;
            $query->found_posts = 1;
        }
    }
}
add_action('parse_query', 'nidfil_prevent_specialist_profile_404');

/**
 * Ensure correct template is used for specialist-profile page
 */
function nidfil_force_specialist_profile_template($template) {
    global $wp_query, $post;
    
    // Check if we're on the specialist-profile page
    $is_specialist_profile = false;
    $request_uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
    
    // Check various ways the page might be accessed
    if (isset($wp_query->query_vars['pagename']) && $wp_query->query_vars['pagename'] === 'specialist-profile') {
        $is_specialist_profile = true;
    } elseif (strpos($request_uri, '/specialist-profile') !== false || strpos($request_uri, 'specialist-profile') !== false) {
        $is_specialist_profile = true;
    } elseif (isset($wp_query->query_vars['name']) && $wp_query->query_vars['name'] === 'specialist-profile') {
        $is_specialist_profile = true;
    } elseif (is_page() && isset($post) && $post->post_name === 'specialist-profile') {
        $is_specialist_profile = true;
    }
    
    if ($is_specialist_profile) {
        // Ensure page exists first
        $page_id = nidfil_create_specialist_profile_page();
        
        if (!$page_id) {
            // Try to find the page
            $page = get_page_by_path('specialist-profile');
            if ($page) {
                $page_id = $page->ID;
            }
        }
        
        if ($page_id) {
            $page = get_post($page_id);
            
            if ($page) {
                // Ensure template is assigned
                $current_template = get_post_meta($page_id, '_wp_page_template', true);
                if ($current_template !== 'page-specialist-profile.php') {
                    update_post_meta($page_id, '_wp_page_template', 'page-specialist-profile.php');
                }
                
                // Set up the post object
                $post = $page;
                setup_postdata($post);
                
                // Fix the query
                $wp_query->queried_object = $post;
                $wp_query->queried_object_id = $post->ID;
                $wp_query->is_page = true;
                $wp_query->is_singular = true;
                $wp_query->is_404 = false;
                $wp_query->posts = array($post);
                $wp_query->post_count = 1;
                $wp_query->found_posts = 1;
                
                // Load the template file
                $template_file = get_template_directory() . '/page-specialist-profile.php';
                if (file_exists($template_file)) {
                    return $template_file;
                }
            }
        }
    }
    
    return $template;
}
add_filter('template_include', 'nidfil_force_specialist_profile_template', 99);

/**
 * Helper function to get client profile URL (main redirect after login)
 */
function nidfil_get_dashboard_url() {
    // Ensure page exists first
    $page_id = nidfil_create_client_profile_page();
    
    if ($page_id) {
        $url = get_permalink($page_id);
        if ($url) {
            return $url;
        }
    }
    
    // Try to find Client Profile page
    $client_profile_page = get_pages(array(
        'meta_key' => '_wp_page_template',
        'meta_value' => 'page-client-profile.php',
        'number' => 1,
        'post_status' => 'publish'
    ));
    
    if (!empty($client_profile_page)) {
        $url = get_permalink($client_profile_page[0]->ID);
        if ($url) {
            return $url;
        }
    }
    
    // Last resort fallback - create page and return URL
    $page_id = nidfil_create_client_profile_page();
    if ($page_id) {
        $url = get_permalink($page_id);
        if ($url) {
            return $url;
        }
    }
    
    // Final fallback
    return home_url('/client-profile/');
}

/**
 * Enqueue Scripts and Styles
 */
function nidfil_connect_scripts() {
    // Enqueue theme stylesheet
    wp_enqueue_style('nidfil-connect-style', get_stylesheet_uri(), array(), '1.0.0');
    
    // Enqueue Google Fonts
    wp_enqueue_style('google-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap', array(), null);
    
    // Enqueue theme JavaScript
    wp_enqueue_script('nidfil-connect-script', get_template_directory_uri() . '/js/main.js', array(), '1.0.0', true);
    
    // Get dashboard URL using helper function
    $dashboard_url = nidfil_get_dashboard_url();
    $specialist_dashboard_url = nidfil_get_specialist_dashboard_url();
    
    // Localize script for AJAX
    wp_localize_script('nidfil-connect-script', 'nidfilAjax', array(
        'ajaxurl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('nidfil_nonce'),
        'dashboard_url' => $dashboard_url,
        'specialist_dashboard_url' => $specialist_dashboard_url,
    ));
}
add_action('wp_enqueue_scripts', 'nidfil_connect_scripts');

/**
 * Register Widget Areas
 */
function nidfil_connect_widgets_init() {
    register_sidebar(array(
        'name' => __('Sidebar', 'nidfil-connect'),
        'id' => 'sidebar-1',
        'description' => __('Add widgets here.', 'nidfil-connect'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget' => '</section>',
        'before_title' => '<h2 class="widget-title">',
        'after_title' => '</h2>',
    ));
}
add_action('widgets_init', 'nidfil_connect_widgets_init');

/**
 * Customizer Settings
 */
function nidfil_connect_customize_register($wp_customize) {
    // Add section for theme options
    $wp_customize->add_section('nidfil_theme_options', array(
        'title' => __('Theme Options', 'nidfil-connect'),
        'priority' => 30,
    ));
    
    // Add setting for hero title
    $wp_customize->add_setting('hero_title', array(
        'default' => 'Un espacio digital para',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('hero_title', array(
        'label' => __('Hero Title', 'nidfil-connect'),
        'section' => 'nidfil_theme_options',
        'type' => 'text',
    ));
    
    // Add setting for hero highlight
    $wp_customize->add_setting('hero_highlight', array(
        'default' => 'YOUR REFORM IS VERY CLOSE',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('hero_highlight', array(
        'label' => __('Hero Highlight Text', 'nidfil-connect'),
        'section' => 'nidfil_theme_options',
        'type' => 'text',
    ));
    
    // Add setting for hero subtitle
    $wp_customize->add_setting('hero_subtitle', array(
        'default' => 'Encuentra a tu especialista de confianza',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('hero_subtitle', array(
        'label' => __('Hero Subtitle', 'nidfil-connect'),
        'section' => 'nidfil_theme_options',
        'type' => 'text',
    ));
}
add_action('customize_register', 'nidfil_connect_customize_register');

/**
 * Get Theme Option Helper
 */
function nidfil_get_option($option_name, $default = '') {
    return get_theme_mod($option_name, $default);
}

/**
 * Include additional files
 */
require_once get_template_directory() . '/inc/template-functions.php';

/**
 * Dashboard AJAX Handlers
 */

// Save Profile Image
function nidfil_save_profile_image() {
    check_ajax_referer('nidfil_nonce', 'nonce');
    
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'User not logged in'));
        return;
    }
    
    if (!isset($_FILES['profile_image'])) {
        wp_send_json_error(array('message' => 'No file uploaded'));
        return;
    }
    
    require_once(ABSPATH . 'wp-admin/includes/image.php');
    require_once(ABSPATH . 'wp-admin/includes/file.php');
    require_once(ABSPATH . 'wp-admin/includes/media.php');
    
    $attachment_id = media_handle_upload('profile_image', 0);
    
    if (is_wp_error($attachment_id)) {
        wp_send_json_error(array('message' => $attachment_id->get_error_message()));
        return;
    }
    
    // Update user meta
    $user_id = get_current_user_id();
    update_user_meta($user_id, 'profile_image', $attachment_id);
    
    // Get different image sizes
    $thumbnail_url = wp_get_attachment_image_url($attachment_id, 'thumbnail');
    $medium_url = wp_get_attachment_image_url($attachment_id, 'medium');
    $full_url = wp_get_attachment_image_url($attachment_id, 'full');
    
    wp_send_json_success(array(
        'image_url' => $thumbnail_url,
        'medium_url' => $medium_url,
        'full_url' => $full_url,
        'message' => 'Imagen guardada correctamente'
    ));
}
add_action('wp_ajax_nidfil_save_profile_image', 'nidfil_save_profile_image');

// Save Bio
function nidfil_save_bio() {
    check_ajax_referer('nidfil_nonce', 'nonce');
    
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'User not logged in'));
        return;
    }
    
    $bio = sanitize_textarea_field($_POST['bio']);
    update_user_meta(get_current_user_id(), 'user_bio', $bio);
    
    wp_send_json_success(array('message' => 'Bio saved successfully'));
}
add_action('wp_ajax_nidfil_save_bio', 'nidfil_save_bio');

// Save Personal Info
function nidfil_save_personal_info() {
    check_ajax_referer('nidfil_nonce', 'nonce');
    
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'User not logged in'));
        return;
    }
    
    $user_id = get_current_user_id();
    $data = array();
    
    if (isset($_POST['full_name'])) {
        $data['display_name'] = sanitize_text_field($_POST['full_name']);
    }
    if (isset($_POST['email'])) {
        $data['user_email'] = sanitize_email($_POST['email']);
    }
    if (isset($_POST['phone'])) {
        update_user_meta($user_id, 'user_phone', sanitize_text_field($_POST['phone']));
    }
    if (isset($_POST['location'])) {
        update_user_meta($user_id, 'user_location', sanitize_text_field($_POST['location']));
    }
    
    if (!empty($data)) {
        $data['ID'] = $user_id;
        wp_update_user($data);
    }
    
    wp_send_json_success(array('message' => 'Information saved successfully'));
}
add_action('wp_ajax_nidfil_save_personal_info', 'nidfil_save_personal_info');

// Save Skills
function nidfil_save_skills() {
    check_ajax_referer('nidfil_nonce', 'nonce');
    
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'User not logged in'));
        return;
    }
    
    $skills = sanitize_text_field($_POST['skills']);
    update_user_meta(get_current_user_id(), 'user_skills', $skills);
    
    wp_send_json_success(array('message' => 'Skills saved successfully'));
}
add_action('wp_ajax_nidfil_save_skills', 'nidfil_save_skills');

// Save Social Media Links
function nidfil_save_social_links() {
    check_ajax_referer('nidfil_nonce', 'nonce');
    
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'User not logged in'));
        return;
    }
    
    $user_id = get_current_user_id();
    
    if (isset($_POST['facebook'])) {
        update_user_meta($user_id, 'social_facebook', sanitize_text_field($_POST['facebook']));
    }
    if (isset($_POST['twitter'])) {
        update_user_meta($user_id, 'social_twitter', sanitize_text_field($_POST['twitter']));
    }
    if (isset($_POST['instagram'])) {
        update_user_meta($user_id, 'social_instagram', sanitize_text_field($_POST['instagram']));
    }
    if (isset($_POST['linkedin'])) {
        update_user_meta($user_id, 'social_linkedin', sanitize_text_field($_POST['linkedin']));
    }
    
    wp_send_json_success(array('message' => 'Social links saved successfully'));
}
add_action('wp_ajax_nidfil_save_social_links', 'nidfil_save_social_links');

// Save Review
function nidfil_save_review() {
    check_ajax_referer('nidfil_nonce', 'nonce');
    
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'User not logged in'));
        return;
    }
    
    $rating = intval($_POST['rating']);
    $review = sanitize_textarea_field($_POST['review']);
    $user_id = get_current_user_id();
    
    // You can save this to a custom post type or user meta
    // Example: Save as user meta
    $reviews = get_user_meta($user_id, 'user_reviews', true) ?: array();
    $reviews[] = array(
        'rating' => $rating,
        'review' => $review,
        'date' => current_time('mysql')
    );
    update_user_meta($user_id, 'user_reviews', $reviews);
    
    wp_send_json_success(array('message' => 'Review saved successfully'));
}
add_action('wp_ajax_nidfil_save_review', 'nidfil_save_review');

/**
 * User Registration Handler
 */
function nidfil_register_user() {
    check_ajax_referer('nidfil_nonce', 'nonce');
    
    $name = sanitize_text_field($_POST['name']);
    $email = sanitize_email($_POST['email']);
    $phone = sanitize_text_field($_POST['phone']);
    $password = $_POST['password'];
    
    // Validate required fields
    if (empty($name) || empty($email) || empty($password)) {
        wp_send_json_error(array('message' => 'Por favor, completa todos los campos requeridos.'));
        return;
    }
    
    // Check if email already exists
    if (email_exists($email)) {
        wp_send_json_error(array('message' => 'Este email ya está registrado.'));
        return;
    }
    
    // Check if username already exists
    $username = sanitize_user($email);
    if (username_exists($username)) {
        $username = sanitize_user($name) . '_' . rand(1000, 9999);
    }
    
    // Create user
    $user_id = wp_create_user($username, $password, $email);
    
    if (is_wp_error($user_id)) {
        wp_send_json_error(array('message' => $user_id->get_error_message()));
        return;
    }
    
    // Update user display name
    wp_update_user(array(
        'ID' => $user_id,
        'display_name' => $name
    ));
    
    // Save phone number
    if (!empty($phone)) {
        update_user_meta($user_id, 'user_phone', $phone);
    }
    
    // Ensure client profile page exists before redirecting
    $page_id = nidfil_create_client_profile_page();
    if ($page_id) {
        // Flush rewrite rules to ensure URL works
        flush_rewrite_rules(false);
        // Clear any caches
        clean_post_cache($page_id);
    }
    
    // Auto login the user using wp_signon for proper authentication
    wp_clear_auth_cookie();
    wp_set_current_user($user_id);
    wp_set_auth_cookie($user_id, true);
    do_action('wp_login', $username, get_userdata($user_id));
    
    // Get dashboard URL using helper function
    $dashboard_url = nidfil_get_dashboard_url();
    
    // Ensure URL is absolute and valid
    if (!filter_var($dashboard_url, FILTER_VALIDATE_URL)) {
        if ($page_id) {
            $dashboard_url = get_permalink($page_id);
        } else {
            $dashboard_url = home_url('/client-profile/');
        }
    }
    
    // Verify the URL exists
    if (empty($dashboard_url)) {
        $dashboard_url = home_url('/client-profile/');
    }
    
    wp_send_json_success(array(
        'message' => 'Registro exitoso. Redirigiendo...',
        'redirect_url' => $dashboard_url,
        'page_id' => $page_id
    ));
}
add_action('wp_ajax_nidfil_register', 'nidfil_register_user');
add_action('wp_ajax_nopriv_nidfil_register', 'nidfil_register_user');

/**
 * User Login Handler
 */
function nidfil_login_user() {
    check_ajax_referer('nidfil_nonce', 'nonce');
    
    $email = sanitize_email($_POST['email']);
    $password = $_POST['password'];
    $remember = isset($_POST['remember']) && $_POST['remember'] === '1' ? true : false;
    
    // Validate required fields
    if (empty($email) || empty($password)) {
        wp_send_json_error(array('message' => 'Por favor, ingresa tu email y contraseña.'));
        return;
    }
    
    // Get user by email
    $user = get_user_by('email', $email);
    
    if (!$user) {
        wp_send_json_error(array('message' => 'Email o contraseña incorrectos.'));
        return;
    }
    
    // Use WordPress signon function for proper authentication
    $credentials = array(
        'user_login'    => $user->user_login,
        'user_password' => $password,
        'remember'      => $remember
    );
    
    $user_signon = wp_signon($credentials, false);
    
    if (is_wp_error($user_signon)) {
        wp_send_json_error(array('message' => 'Email o contraseña incorrectos.'));
        return;
    }
    
    // Ensure client profile page exists before redirecting
    $page_id = nidfil_create_client_profile_page();
    if ($page_id) {
        // Flush rewrite rules to ensure URL works
        flush_rewrite_rules(false);
        // Clear any caches
        clean_post_cache($page_id);
    }
    
    // Get dashboard URL using helper function
    $dashboard_url = nidfil_get_dashboard_url();
    
    // Ensure URL is absolute and valid
    if (empty($dashboard_url) || !filter_var($dashboard_url, FILTER_VALIDATE_URL)) {
        if ($page_id) {
            $dashboard_url = get_permalink($page_id);
        }
        if (empty($dashboard_url) || !filter_var($dashboard_url, FILTER_VALIDATE_URL)) {
            $dashboard_url = home_url('/client-profile/');
        }
    }
    
    wp_send_json_success(array(
        'message' => 'Inicio de sesión exitoso. Redirigiendo...',
        'redirect_url' => $dashboard_url,
        'page_id' => $page_id
    ));
}
add_action('wp_ajax_nidfil_login', 'nidfil_login_user');
add_action('wp_ajax_nopriv_nidfil_login', 'nidfil_login_user');

/**
 * Specialist Registration Handler
 */
function nidfil_register_specialist() {
    check_ajax_referer('nidfil_nonce', 'nonce');
    
    $name = sanitize_text_field($_POST['name']);
    $email = sanitize_email($_POST['email']);
    $phone = sanitize_text_field($_POST['phone']);
    $profession = sanitize_text_field($_POST['profession']);
    $experience = intval($_POST['experience']);
    $password = $_POST['password'];
    
    // Validate required fields
    if (empty($name) || empty($email) || empty($password) || empty($profession) || empty($experience)) {
        wp_send_json_error(array('message' => 'Por favor, completa todos los campos requeridos.'));
        return;
    }
    
    // Check if email already exists
    if (email_exists($email)) {
        wp_send_json_error(array('message' => 'Este email ya está registrado.'));
        return;
    }
    
    // Check if username already exists
    $username = sanitize_user($email);
    if (username_exists($username)) {
        $username = sanitize_user($name) . '_' . rand(1000, 9999);
    }
    
    // Create user
    $user_id = wp_create_user($username, $password, $email);
    
    if (is_wp_error($user_id)) {
        wp_send_json_error(array('message' => $user_id->get_error_message()));
        return;
    }
    
    // Update user display name
    wp_update_user(array(
        'ID' => $user_id,
        'display_name' => $name
    ));
    
    // Save specialist-specific meta data
    update_user_meta($user_id, 'user_phone', $phone);
    update_user_meta($user_id, 'user_type', 'specialist');
    update_user_meta($user_id, 'profession', $profession);
    update_user_meta($user_id, 'experience_years', $experience);
    
    // Ensure specialist profile page exists before redirecting
    $page_id = nidfil_create_specialist_profile_page();
    if ($page_id) {
        flush_rewrite_rules(false);
        clean_post_cache($page_id);
    }
    
    // Auto login the user
    wp_clear_auth_cookie();
    wp_set_current_user($user_id);
    wp_set_auth_cookie($user_id, true);
    do_action('wp_login', $username, get_userdata($user_id));
    
    // Get specialist dashboard URL
    $dashboard_url = '';
    if ($page_id) {
        $dashboard_url = get_permalink($page_id);
        // Ensure URL is absolute
        if (!filter_var($dashboard_url, FILTER_VALIDATE_URL)) {
            $dashboard_url = home_url('/specialist-profile/');
        }
    } else {
        $dashboard_url = home_url('/specialist-profile/');
    }
    
    // Ensure URL is absolute
    if (!filter_var($dashboard_url, FILTER_VALIDATE_URL)) {
        $dashboard_url = home_url('/specialist-profile/');
    }
    
    wp_send_json_success(array(
        'message' => 'Registro exitoso. Redirigiendo...',
        'redirect_url' => $dashboard_url,
        'page_id' => $page_id
    ));
}
add_action('wp_ajax_nidfil_register_specialist', 'nidfil_register_specialist');
add_action('wp_ajax_nopriv_nidfil_register_specialist', 'nidfil_register_specialist');

/**
 * Specialist Login Handler
 */
function nidfil_login_specialist() {
    check_ajax_referer('nidfil_nonce', 'nonce');
    
    $email = sanitize_email($_POST['email']);
    $password = $_POST['password'];
    $remember = isset($_POST['remember']) && $_POST['remember'] === '1';
    
    if (empty($email) || empty($password)) {
        wp_send_json_error(array('message' => 'Por favor, completa todos los campos.'));
        return;
    }
    
    // Try to get user by email
    $user = get_user_by('email', $email);
    
    if (!$user) {
        wp_send_json_error(array('message' => 'Email o contraseña incorrectos.'));
        return;
    }
    
    // Check if user is a specialist
    $user_type = get_user_meta($user->ID, 'user_type', true);
    if ($user_type !== 'specialist') {
        wp_send_json_error(array('message' => 'Esta cuenta no es de especialista. Por favor, usa el acceso de cliente.'));
        return;
    }
    
    // Authenticate user
    $creds = array(
        'user_login' => $user->user_login,
        'user_password' => $password,
        'remember' => $remember
    );
    
    $user_signon = wp_signon($creds, false);
    
    if (is_wp_error($user_signon)) {
        wp_send_json_error(array('message' => 'Email o contraseña incorrectos.'));
        return;
    }
    
    // Ensure specialist profile page exists
    $page_id = nidfil_create_specialist_profile_page();
    if ($page_id) {
        flush_rewrite_rules(false);
        clean_post_cache($page_id);
    }
    
    // Get specialist dashboard URL
    $dashboard_url = '';
    if ($page_id) {
        $dashboard_url = get_permalink($page_id);
    } else {
        $dashboard_url = home_url('/specialist-profile/');
    }
    
    wp_send_json_success(array(
        'message' => 'Inicio de sesión exitoso. Redirigiendo...',
        'redirect_url' => $dashboard_url
    ));
}
add_action('wp_ajax_nidfil_login_specialist', 'nidfil_login_specialist');
add_action('wp_ajax_nopriv_nidfil_login_specialist', 'nidfil_login_specialist');

/**
 * Save Professional Information (Specialist)
 */
function nidfil_save_professional_info() {
    check_ajax_referer('nidfil_nonce', 'nonce');
    
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'User not logged in'));
        return;
    }
    
    $user_id = get_current_user_id();
    $profession = sanitize_text_field($_POST['profession'] ?? '');
    $experience = intval($_POST['experience'] ?? 0);
    $service_area = sanitize_text_field($_POST['service_area'] ?? '');
    $languages = sanitize_text_field($_POST['languages'] ?? '');
    
    update_user_meta($user_id, 'profession', $profession);
    update_user_meta($user_id, 'experience_years', $experience);
    update_user_meta($user_id, 'service_area', $service_area);
    update_user_meta($user_id, 'languages', $languages);
    
    wp_send_json_success(array('message' => 'Información profesional guardada correctamente'));
}
add_action('wp_ajax_nidfil_save_professional_info', 'nidfil_save_professional_info');

/**
 * Save Services Offered (Specialist)
 */
function nidfil_save_services() {
    check_ajax_referer('nidfil_nonce', 'nonce');
    
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'User not logged in'));
        return;
    }
    
    $user_id = get_current_user_id();
    $services_text = sanitize_textarea_field($_POST['services'] ?? '');
    
    // Convert textarea lines to array
    $services = array_filter(array_map('trim', explode("\n", $services_text)));
    
    update_user_meta($user_id, 'services_offered', $services);
    
    wp_send_json_success(array('message' => 'Servicios guardados correctamente', 'services' => $services));
}
add_action('wp_ajax_nidfil_save_services', 'nidfil_save_services');

/**
 * Save Certifications (Specialist)
 */
function nidfil_save_certifications() {
    check_ajax_referer('nidfil_nonce', 'nonce');
    
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'User not logged in'));
        return;
    }
    
    $user_id = get_current_user_id();
    $certifications_text = sanitize_textarea_field($_POST['certifications'] ?? '');
    
    // Convert textarea lines to array
    $certifications = array_filter(array_map('trim', explode("\n", $certifications_text)));
    
    update_user_meta($user_id, 'certifications', $certifications);
    
    wp_send_json_success(array('message' => 'Certificaciones guardadas correctamente', 'certifications' => $certifications));
}
add_action('wp_ajax_nidfil_save_certifications', 'nidfil_save_certifications');

/**
 * Save Pricing/Rates (Specialist)
 */
function nidfil_save_pricing() {
    check_ajax_referer('nidfil_nonce', 'nonce');
    
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'User not logged in'));
        return;
    }
    
    $user_id = get_current_user_id();
    $hourly_rate = floatval($_POST['hourly_rate'] ?? 0);
    $project_rate = floatval($_POST['project_rate'] ?? 0);
    
    update_user_meta($user_id, 'hourly_rate', $hourly_rate);
    update_user_meta($user_id, 'project_rate', $project_rate);
    
    wp_send_json_success(array('message' => 'Tarifas guardadas correctamente'));
}
add_action('wp_ajax_nidfil_save_pricing', 'nidfil_save_pricing');

/**
 * Save Business Video (Specialist)
 */
function nidfil_save_business_video() {
    check_ajax_referer('nidfil_nonce', 'nonce');
    
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'User not logged in'));
        return;
    }
    
    $user_id = get_current_user_id();
    
    // Check if file was uploaded
    if (!isset($_FILES['business_video']) || $_FILES['business_video']['error'] !== UPLOAD_ERR_OK) {
        wp_send_json_error(array('message' => 'Error al subir el video. Por favor, intenta de nuevo.'));
        return;
    }
    
    // Validate file type
    $allowed_types = array('video/mp4', 'video/webm', 'video/ogg', 'video/quicktime');
    $file_type = wp_check_filetype($_FILES['business_video']['name']);
    $mime_type = $_FILES['business_video']['type'];
    
    if (!in_array($mime_type, $allowed_types) && !in_array($file_type['type'], $allowed_types)) {
        wp_send_json_error(array('message' => 'Formato de video no válido. Usa MP4, WEBM, OGG o MOV.'));
        return;
    }
    
    // Validate file size (max 100MB)
    $max_size = 100 * 1024 * 1024; // 100MB
    if ($_FILES['business_video']['size'] > $max_size) {
        wp_send_json_error(array('message' => 'El video es demasiado grande. Máximo 100MB.'));
        return;
    }
    
    // Delete old video if exists
    $old_video_id = get_user_meta($user_id, 'business_video', true);
    if ($old_video_id) {
        wp_delete_attachment($old_video_id, true);
    }
    
    // Upload the video
    require_once(ABSPATH . 'wp-admin/includes/file.php');
    require_once(ABSPATH . 'wp-admin/includes/media.php');
    require_once(ABSPATH . 'wp-admin/includes/image.php');
    
    $upload = wp_handle_upload($_FILES['business_video'], array('test_form' => false));
    
    if (isset($upload['error'])) {
        wp_send_json_error(array('message' => $upload['error']));
        return;
    }
    
    // Create attachment
    $attachment = array(
        'post_mime_type' => $upload['type'],
        'post_title' => sanitize_file_name(pathinfo($_FILES['business_video']['name'], PATHINFO_FILENAME)),
        'post_content' => '',
        'post_status' => 'inherit'
    );
    
    $attach_id = wp_insert_attachment($attachment, $upload['file']);
    
    if (is_wp_error($attach_id)) {
        wp_send_json_error(array('message' => 'Error al crear el archivo adjunto.'));
        return;
    }
    
    // Generate attachment metadata
    $attach_data = wp_generate_attachment_metadata($attach_id, $upload['file']);
    wp_update_attachment_metadata($attach_id, $attach_data);
    
    // Save video ID to user meta
    update_user_meta($user_id, 'business_video', $attach_id);
    
    wp_send_json_success(array(
        'message' => 'Video guardado correctamente',
        'video_url' => wp_get_attachment_url($attach_id)
    ));
}
add_action('wp_ajax_nidfil_save_business_video', 'nidfil_save_business_video');

/**
 * Remove Business Video (Specialist)
 */
function nidfil_remove_business_video() {
    check_ajax_referer('nidfil_nonce', 'nonce');
    
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'User not logged in'));
        return;
    }
    
    $user_id = get_current_user_id();
    $video_id = get_user_meta($user_id, 'business_video', true);
    
    if ($video_id) {
        wp_delete_attachment($video_id, true);
        delete_user_meta($user_id, 'business_video');
    }
    
    wp_send_json_success(array('message' => 'Video eliminado correctamente'));
}
add_action('wp_ajax_nidfil_remove_business_video', 'nidfil_remove_business_video');

/**
 * Save Business Data (Specialist)
 */
function nidfil_save_business_data() {
    check_ajax_referer('nidfil_nonce', 'nonce');
    
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'User not logged in'));
        return;
    }
    
    $user_id = get_current_user_id();
    
    $business_name = sanitize_text_field($_POST['business_name'] ?? '');
    $office_address = sanitize_text_field($_POST['office_address'] ?? '');
    $business_city = sanitize_text_field($_POST['business_city'] ?? '');
    $business_postal_code = sanitize_text_field($_POST['business_postal_code'] ?? '');
    $business_country = sanitize_text_field($_POST['business_country'] ?? '');
    $business_phone = sanitize_text_field($_POST['business_phone'] ?? '');
    $business_email = sanitize_email($_POST['business_email'] ?? '');
    $business_website = esc_url_raw($_POST['business_website'] ?? '');
    
    update_user_meta($user_id, 'business_name', $business_name);
    update_user_meta($user_id, 'office_address', $office_address);
    update_user_meta($user_id, 'business_city', $business_city);
    update_user_meta($user_id, 'business_postal_code', $business_postal_code);
    update_user_meta($user_id, 'business_country', $business_country);
    update_user_meta($user_id, 'business_phone', $business_phone);
    update_user_meta($user_id, 'business_email', $business_email);
    update_user_meta($user_id, 'business_website', $business_website);
    
    wp_send_json_success(array('message' => 'Datos del negocio guardados correctamente'));
}
add_action('wp_ajax_nidfil_save_business_data', 'nidfil_save_business_data');

/**
 * Helper function to get specialist profile URL
 */
function nidfil_get_specialist_dashboard_url() {
    $page_id = nidfil_create_specialist_profile_page();
    
    if ($page_id) {
        $url = get_permalink($page_id);
        if ($url) {
            return $url;
        }
    }
    
    // Try to find Specialist Profile page
    $specialist_profile_page = get_pages(array(
        'meta_key' => '_wp_page_template',
        'meta_value' => 'page-specialist-profile.php',
        'number' => 1,
        'post_status' => 'publish'
    ));
    
    if (!empty($specialist_profile_page)) {
        $url = get_permalink($specialist_profile_page[0]->ID);
        if ($url) {
            return $url;
        }
    }
    
    // Fallback
    return home_url('/specialist-profile/');
}

/**
 * Redirect users to custom dashboard after login (not WordPress admin)
 */
function nidfil_login_redirect($redirect_to, $request, $user) {
    if (is_wp_error($user) || !$user) {
        return $redirect_to;
    }
    
    // Check if user is a specialist
    $user_type = get_user_meta($user->ID, 'user_type', true);
    if ($user_type === 'specialist') {
        return nidfil_get_specialist_dashboard_url();
    }
    
    // Default to client profile
    return nidfil_get_dashboard_url();
}
add_filter('login_redirect', 'nidfil_login_redirect', 10, 3);

/**
 * Prevent non-admin users from accessing WordPress admin
 */
function nidfil_redirect_admin() {
    if (is_admin() && !current_user_can('administrator') && !wp_doing_ajax()) {
        // Use helper function to get client profile URL
        wp_redirect(nidfil_get_dashboard_url());
        exit;
    }
}
add_action('admin_init', 'nidfil_redirect_admin');


