/**
 * NIDFIL Connect Theme JavaScript
 */

(function() {
    'use strict';

    // Search form handling
    const searchForm = document.querySelector('.search-form');
    if (searchForm) {
        searchForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const specialist = document.getElementById('specialist').value;
            const location = document.getElementById('location').value;
            
            // You can add AJAX search functionality here
            console.log('Searching for:', specialist, 'in', location);
        });
    }

    // Category card click handling
    const categoryCards = document.querySelectorAll('.category-card');
    categoryCards.forEach(card => {
        card.addEventListener('click', function() {
            const categoryName = this.querySelector('.category-name').textContent;
            // Add navigation logic here
            console.log('Selected category:', categoryName);
        });
    });

    // Language Switcher functionality
    function initLanguageSwitcher() {
        const languageSwitcher = document.querySelector('.language-switcher');
        const languageSwitcherBtn = document.getElementById('languageSwitcherBtn');
        const languageDropdown = document.getElementById('languageDropdown');
        const currentLanguageSpan = document.getElementById('currentLanguage');
        const languageOptions = document.querySelectorAll('.language-option');

        if (!languageSwitcher || !languageSwitcherBtn) {
            console.log('Language switcher elements not found');
            return;
        }

        console.log('Language switcher initialized');

        // Get saved language from localStorage or default to ES
        let currentLang = localStorage.getItem('selectedLanguage') || 'ES';
        updateCurrentLanguage(currentLang);

        // Toggle dropdown - Multiple event handlers for reliability
        languageSwitcherBtn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            console.log('Language button clicked');
            languageSwitcher.classList.toggle('active');
            console.log('Language switcher active:', languageSwitcher.classList.contains('active'));
        });

        // Also handle clicks on the button container
        languageSwitcher.addEventListener('click', function(e) {
            if (e.target.closest('.language-switcher-button')) {
                e.stopPropagation();
            }
        });

        // Handle language selection
        if (languageOptions.length > 0) {
            languageOptions.forEach(option => {
                option.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    const langCode = this.getAttribute('data-code');
                    const lang = this.getAttribute('data-lang');
                    
                    // Update current language display
                    updateCurrentLanguage(langCode);
                    
                    // Update active state
                    languageOptions.forEach(opt => opt.classList.remove('active'));
                    this.classList.add('active');
                    
                    // Save to localStorage
                    localStorage.setItem('selectedLanguage', langCode);
                    
                    // Close dropdown
                    languageSwitcher.classList.remove('active');
                    
                    console.log('Language changed to:', lang, langCode);
                });
            });
        }

        // Close dropdown when clicking outside
        document.addEventListener('click', function(e) {
            if (languageSwitcher && !languageSwitcher.contains(e.target)) {
                languageSwitcher.classList.remove('active');
            }
        });

        // Function to update current language display
        function updateCurrentLanguage(langCode) {
            if (currentLanguageSpan) {
                currentLanguageSpan.textContent = langCode;
            }
            
            // Update active state in dropdown
            languageOptions.forEach(option => {
                if (option.getAttribute('data-code') === langCode) {
                    option.classList.add('active');
                } else {
                    option.classList.remove('active');
                }
            });
        }
    }

    // Initialize language switcher immediately
    initLanguageSwitcher();
    
    // Also initialize on DOM ready as fallback
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initLanguageSwitcher);
    }
    
    // Additional fallback initialization
    setTimeout(initLanguageSwitcher, 500);

    // Handle language selection
    languageOptions.forEach(option => {
        option.addEventListener('click', function(e) {
            e.preventDefault();
            const langCode = this.getAttribute('data-code');
            const lang = this.getAttribute('data-lang');
            
            // Update current language display
            updateCurrentLanguage(langCode);
            
            // Update active state
            languageOptions.forEach(opt => opt.classList.remove('active'));
            this.classList.add('active');
            
            // Save to localStorage
            localStorage.setItem('selectedLanguage', langCode);
            
            // Close dropdown
            languageSwitcher.classList.remove('active');
            
            // Here you can add actual language switching logic
            // For example, redirect to language-specific URL or reload page with language parameter
            console.log('Language changed to:', lang, langCode);
            
            // Example: Reload page with language parameter
            // window.location.href = window.location.pathname + '?lang=' + lang;
        });
    });

    // Close dropdown when clicking outside
    document.addEventListener('click', function(e) {
        if (languageSwitcher && !languageSwitcher.contains(e.target)) {
            languageSwitcher.classList.remove('active');
        }
    });

    // Function to update current language display
    function updateCurrentLanguage(langCode) {
        if (currentLanguageSpan) {
            currentLanguageSpan.textContent = langCode;
        }
        
        // Update active state in dropdown
        languageOptions.forEach(option => {
            if (option.getAttribute('data-code') === langCode) {
                option.classList.add('active');
            } else {
                option.classList.remove('active');
            }
        });
    }

})();

// Open Specialist Modal - Make globally accessible
window.openSpecialistModal = function(card) {
    const modal = document.getElementById('specialistModal');
    if (!modal) {
        console.error('Specialist modal not found');
        return;
    }
    
    const data = {
        name: card.getAttribute('data-name') || '',
        profession: card.getAttribute('data-profession') || '',
        rating: card.getAttribute('data-rating') || '0',
        reviews: card.getAttribute('data-reviews') || '0',
        location: card.getAttribute('data-location') || '',
        distance: card.getAttribute('data-distance') || '0',
        verified: card.getAttribute('data-verified') === 'true',
        avatar: card.getAttribute('data-avatar') || '',
        whatsapp: card.getAttribute('data-whatsapp') || '',
        phone: card.getAttribute('data-phone') || '',
        description: card.getAttribute('data-description') || ''
    };
    
    // Update modal content
    const modalAvatar = document.getElementById('modalAvatar');
    const modalName = document.getElementById('modalName');
    const modalProfession = document.getElementById('modalProfession');
    const modalRating = document.getElementById('modalRating');
    const modalLocation = document.getElementById('modalLocation');
    const modalDistance = document.getElementById('modalDistance');
    const modalDescription = document.getElementById('modalDescription');
    const verifiedBadge = document.getElementById('modalVerified');
    const whatsappBtn = document.getElementById('modalWhatsApp');
    const callBtn = document.getElementById('modalCall');
    
    if (modalAvatar) modalAvatar.textContent = data.avatar;
    if (modalName) modalName.textContent = data.name;
    if (modalProfession) modalProfession.textContent = data.profession;
    if (modalRating) {
        modalRating.innerHTML = `
            <svg width="18" height="18" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="#FFD700"/>
            </svg>
            <span class="rating-value">${data.rating}</span>
            <span class="reviews-count">(${data.reviews} opiniones)</span>
        `;
    }
    if (modalLocation) modalLocation.textContent = data.location;
    if (modalDistance) modalDistance.textContent = data.distance + ' km';
    if (modalDescription) modalDescription.textContent = data.description;
    
    // Show/hide verified badge
    if (verifiedBadge) {
        if (data.verified) {
            verifiedBadge.style.display = 'inline-flex';
        } else {
            verifiedBadge.style.display = 'none';
        }
    }
    
    // Update action buttons
    if (whatsappBtn && data.whatsapp) {
        whatsappBtn.href = `https://wa.me/${data.whatsapp}?text=Hola%20${encodeURIComponent(data.name.split(' ')[0])},%20me%20interesa%20tu%20servicio%20de%20${encodeURIComponent(data.profession.toLowerCase())}`;
    }
    if (callBtn && data.phone) {
        callBtn.href = `tel:${data.phone}`;
    }
    
    // Show modal
    modal.classList.add('modal-active');
    document.body.style.overflow = 'hidden';
};

// Close Specialist Modal - Make globally accessible
window.closeSpecialistModal = function() {
    const modal = document.getElementById('specialistModal');
    if (modal) {
        modal.classList.remove('modal-active');
        document.body.style.overflow = '';
    }
};

// Add ESC key support to close modal and ensure click handlers work
document.addEventListener('DOMContentLoaded', function() {
    // ESC key to close modal
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            const modal = document.getElementById('specialistModal');
            if (modal && modal.classList.contains('modal-active')) {
                window.closeSpecialistModal();
            }
        }
    });
    
    // Add event listener for specialist cards - PRIMARY METHOD
    function initSpecialistCards() {
        const specialistCards = document.querySelectorAll('.specialist-card');
        console.log('Found specialist cards:', specialistCards.length);
        
        specialistCards.forEach(function(card) {
            // Remove existing onclick and add proper event listener
            card.removeAttribute('onclick');
            
            // Add click event listener
            card.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                
                console.log('Specialist card clicked:', card);
                
                // Call the modal function
                if (typeof window.openSpecialistModal === 'function') {
                    window.openSpecialistModal(card);
                } else {
                    console.error('openSpecialistModal function not available');
                }
            });
        });
    }
    
    // Initialize immediately and also after a delay
    initSpecialistCards();
    setTimeout(initSpecialistCards, 500);
    setTimeout(initSpecialistCards, 1000);
});

// Access Dropdown functionality
(function() {
    'use strict';

    const accessDropdown = document.querySelector('.access-dropdown');
    const accessButton = document.getElementById('accessButton');
    const accessDropdownMenu = document.getElementById('accessDropdown');
    const soyClienteBtn = document.getElementById('soyClienteBtn');
    const soyEspecialistaBtn = document.getElementById('soyEspecialistaBtn');

    // Toggle access dropdown
    if (accessButton) {
        accessButton.addEventListener('click', function(e) {
            e.stopPropagation();
            accessDropdown.classList.toggle('active');
        });
    }

    // Handle "Soy Cliente" click
    if (soyClienteBtn) {
        soyClienteBtn.addEventListener('click', function(e) {
            e.preventDefault();
            accessDropdown.classList.remove('active');
            openClienteModal();
        });
    }

    // Handle "Soy Especialista" click
    if (soyEspecialistaBtn) {
        soyEspecialistaBtn.addEventListener('click', function(e) {
            e.preventDefault();
            accessDropdown.classList.remove('active');
            // Add functionality for "Soy Especialista" here
            console.log('Soy Especialista clicked');
        });
    }

    // Close dropdown when clicking outside
    document.addEventListener('click', function(e) {
        if (accessDropdown && !accessDropdown.contains(e.target)) {
            accessDropdown.classList.remove('active');
        }
    });
})();

// Open Cliente Modal - Make globally accessible
function openClienteModal() {
    const modal = document.getElementById('clienteModal');
    if (modal) {
        modal.classList.add('modal-active');
        document.body.style.overflow = 'hidden';
        // Show login form by default
        if (typeof switchFormTab === 'function') {
            switchFormTab('login');
        } else if (window.switchFormTab) {
            window.switchFormTab('login');
        }
    }
}
window.openClienteModal = openClienteModal;

// Close Cliente Modal - Make it globally accessible (multiple ways)
function closeClienteModal() {
    const modal = document.getElementById('clienteModal');
    if (modal) {
        modal.classList.remove('modal-active');
        document.body.style.overflow = '';
        // Reset forms
        const loginForm = document.getElementById('loginForm');
        const registerForm = document.getElementById('registerForm');
        if (loginForm) loginForm.reset();
        if (registerForm) registerForm.reset();
        // Reset to login tab
        if (typeof switchFormTab === 'function') {
            switchFormTab('login');
        } else if (window.switchFormTab) {
            window.switchFormTab('login');
        }
    }
}
// Make it available on window object as well
window.closeClienteModal = closeClienteModal;

// Form Tab Switching - Make it globally accessible
function switchFormTab(tabName) {
    console.log('Switching to tab:', tabName);
    const tabs = document.querySelectorAll('.form-tab');
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    
    // Update tabs
    tabs.forEach(tab => {
        if (tab.getAttribute('data-tab') === tabName) {
            tab.classList.add('active');
        } else {
            tab.classList.remove('active');
        }
    });
    
    // Show/hide forms based on tab
    if (tabName === 'login') {
        if (loginForm) {
            loginForm.classList.add('active-form');
            loginForm.style.display = 'block';
            console.log('Showing login form');
        }
        if (registerForm) {
            registerForm.classList.remove('active-form');
            registerForm.style.display = 'none';
            console.log('Hiding register form');
        }
    } else if (tabName === 'register') {
        if (registerForm) {
            registerForm.classList.add('active-form');
            registerForm.style.display = 'block';
            console.log('Showing register form');
        }
        if (loginForm) {
            loginForm.classList.remove('active-form');
            loginForm.style.display = 'none';
            console.log('Hiding login form');
        }
    }
}
// Make it globally accessible
window.switchFormTab = switchFormTab;

// Initialize form tabs and close button
(function() {
    'use strict';

    function initModalFeatures() {
        // Initialize form tabs
        const formTabs = document.querySelectorAll('.form-tab');
        
        if (formTabs.length > 0) {
            formTabs.forEach(tab => {
                // Remove existing listeners by cloning
                const newTab = tab.cloneNode(true);
                tab.parentNode.replaceChild(newTab, tab);
                
                newTab.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    const tabName = this.getAttribute('data-tab');
                    console.log('Tab clicked:', tabName);
                    if (window.switchFormTab) {
                        window.switchFormTab(tabName);
                    }
                });
            });
        }
        
        // Initialize close button with event listener (fallback)
        const closeBtn = document.querySelector('.modal-close');
        if (closeBtn) {
            // Remove existing listeners by cloning
            const newCloseBtn = closeBtn.cloneNode(true);
            closeBtn.parentNode.replaceChild(newCloseBtn, closeBtn);
            
            newCloseBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                console.log('Close button clicked via event listener');
                if (window.closeClienteModal) {
                    window.closeClienteModal();
                }
            });
        }
        
        // Initialize overlay click (fallback)
        const overlay = document.querySelector('.modal-overlay');
        if (overlay) {
            overlay.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                console.log('Overlay clicked');
                if (window.closeClienteModal) {
                    window.closeClienteModal();
                }
            });
        }
        
        // ESC key to close
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                const modal = document.getElementById('clienteModal');
                if (modal && modal.classList.contains('modal-active')) {
                    if (window.closeClienteModal) {
                        window.closeClienteModal();
                    }
                }
            }
        });
    }
    
    // Initialize when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initModalFeatures);
    } else {
        initModalFeatures();
    }
    
    // Fallback initialization
    setTimeout(initModalFeatures, 300);

    // Handle login form submission
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const email = document.getElementById('loginEmail').value;
            const password = document.getElementById('loginPassword').value;
            const remember = document.querySelector('#loginForm input[name="remember"]').checked;
            
            if (!email || !password) {
                alert('Por favor, completa todos los campos.');
                return;
            }
            
            // Show loading state
            const submitBtn = loginForm.querySelector('.form-submit');
            const originalText = submitBtn.textContent;
            submitBtn.disabled = true;
            submitBtn.textContent = 'Iniciando sesión...';
            
            // AJAX call to login
            fetch(nidfilAjax.ajaxurl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    action: 'nidfil_login',
                    email: email,
                    password: password,
                    remember: remember ? '1' : '0',
                    nonce: nidfilAjax.nonce
                })
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                if (data.success) {
                    // Show success message briefly
                    submitBtn.textContent = '¡Éxito! Redirigiendo...';
                    
                    // Close modal after a short delay
                    setTimeout(function() {
                        if (typeof closeClienteModal === 'function') {
                            closeClienteModal();
                        } else if (window.closeClienteModal) {
                            window.closeClienteModal();
                        }
                        
                        // Redirect to dashboard
                        let redirectUrl = null;
                        if (data.data && data.data.redirect_url) {
                            redirectUrl = data.data.redirect_url;
                        } else if (nidfilAjax && nidfilAjax.dashboard_url) {
                            redirectUrl = nidfilAjax.dashboard_url;
                        } else {
                            redirectUrl = '/client-profile/';
                        }
                        
                        // Ensure URL is absolute
                        if (redirectUrl && !redirectUrl.startsWith('http')) {
                            redirectUrl = window.location.origin + (redirectUrl.startsWith('/') ? '' : '/') + redirectUrl;
                        }
                        
                        console.log('Login - Redirecting to:', redirectUrl);
                        if (redirectUrl) {
                            window.location.href = redirectUrl;
                        } else {
                            window.location.href = '/client-profile/';
                        }
                    }, 500);
                } else {
                    // Show error message
                    const errorMsg = data.data && data.data.message ? data.data.message : 'Error al iniciar sesión';
                    alert(errorMsg);
                    submitBtn.disabled = false;
                    submitBtn.textContent = originalText;
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Error al iniciar sesión. Por favor, intenta de nuevo.');
                submitBtn.disabled = false;
                submitBtn.textContent = originalText;
            });
        });
    }

    // Handle register form submission
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const name = document.getElementById('registerName').value;
            const email = document.getElementById('registerEmail').value;
            const phone = document.getElementById('registerPhone').value;
            const password = document.getElementById('registerPassword').value;
            const passwordConfirm = document.getElementById('registerPasswordConfirm').value;
            const terms = document.querySelector('#registerForm input[name="terms"]').checked;
            
            // Validate required fields
            if (!name || !email || !password || !passwordConfirm) {
                alert('Por favor, completa todos los campos requeridos.');
                return;
            }
            
            // Validate terms checkbox
            if (!terms) {
                alert('Por favor, acepta los términos y condiciones para continuar.');
                return;
            }
            
            // Validate passwords match
            if (password !== passwordConfirm) {
                alert('Las contraseñas no coinciden');
                return;
            }
            
            // Validate password strength (optional - minimum 6 characters)
            if (password.length < 6) {
                alert('La contraseña debe tener al menos 6 caracteres.');
                return;
            }
            
            // Show loading state
            const submitBtn = registerForm.querySelector('.form-submit');
            const originalText = submitBtn.textContent;
            submitBtn.disabled = true;
            submitBtn.textContent = 'Registrando...';
            
            // AJAX call to register
            fetch(nidfilAjax.ajaxurl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    action: 'nidfil_register',
                    name: name,
                    email: email,
                    phone: phone,
                    password: password,
                    nonce: nidfilAjax.nonce
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Show success message
                    submitBtn.textContent = '¡Éxito! Redirigiendo...';
                    
                    // Close modal after short delay
                    setTimeout(function() {
                        if (typeof closeClienteModal === 'function') {
                            closeClienteModal();
                        } else if (window.closeClienteModal) {
                            window.closeClienteModal();
                        }
                        
                        // Redirect to dashboard
                        let redirectUrl = null;
                        if (data.data && data.data.redirect_url) {
                            redirectUrl = data.data.redirect_url;
                        } else if (nidfilAjax && nidfilAjax.dashboard_url) {
                            redirectUrl = nidfilAjax.dashboard_url;
                        } else {
                            redirectUrl = '/client-profile/';
                        }
                        
                        // Ensure URL is absolute
                        if (redirectUrl && !redirectUrl.startsWith('http')) {
                            redirectUrl = window.location.origin + (redirectUrl.startsWith('/') ? '' : '/') + redirectUrl;
                        }
                        
                        console.log('Redirecting to:', redirectUrl);
                        if (redirectUrl) {
                            window.location.href = redirectUrl;
                        } else {
                            // Fallback: reload page
                            window.location.reload();
                        }
                    }, 500);
                } else {
                    alert(data.data && data.data.message ? data.data.message : 'Error al registrarse');
                    submitBtn.disabled = false;
                    submitBtn.textContent = originalText;
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Error al registrarse. Por favor, intenta de nuevo.');
                submitBtn.disabled = false;
                submitBtn.textContent = originalText;
            });
        });
    }
})();

// Dashboard Functionality
(function() {
    'use strict';

    // Only run on dashboard/client profile pages
    if (!document.querySelector('.dashboard-main') && !document.querySelector('.dashboard-container')) {
        return;
    }
    
    // Wait for DOM to be fully loaded
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function() {
            initDashboardFeatures();
        });
    } else {
        initDashboardFeatures();
    }
})();

function initDashboardFeatures() {
    'use strict';

    console.log('Initializing dashboard features...'); // Debug

    // Navigation between sections
    const navItems = document.querySelectorAll('.nav-item');
    const sections = document.querySelectorAll('.dashboard-section');
    
    console.log('Found nav items:', navItems.length); // Debug
    console.log('Found sections:', sections.length); // Debug

    function switchSection(sectionName) {
        if (!sectionName) {
            console.error('No section name provided');
            return;
        }
        
        const sectionId = sectionName + 'Section';
        console.log('Switching to section ID:', sectionId); // Debug
        
        // Update active nav item
        navItems.forEach(nav => {
            const navSection = nav.getAttribute('data-section');
            if (navSection === sectionName) {
                nav.classList.add('active');
            } else {
                nav.classList.remove('active');
            }
        });
        
        // Hide all sections first
        sections.forEach(section => {
            section.classList.remove('active');
            section.style.display = 'none';
        });
        
        // Show target section
        const targetSection = document.getElementById(sectionId);
        if (targetSection) {
            targetSection.classList.add('active');
            targetSection.style.display = 'block';
            console.log('Section activated:', sectionId); // Debug
            // Smooth scroll to top
            setTimeout(() => {
                window.scrollTo({ top: 0, behavior: 'smooth' });
            }, 100);
        } else {
            console.error('Section not found:', sectionId);
        }
    }

    // Add click handlers to navigation items - Direct approach
    if (navItems.length > 0) {
        navItems.forEach((item, index) => {
            // Remove any existing listeners by cloning
            const newItem = item.cloneNode(true);
            item.parentNode.replaceChild(newItem, item);
            
            // Add fresh event listener
            newItem.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                const sectionName = this.getAttribute('data-section');
                console.log('Nav clicked - Section:', sectionName); // Debug
                if (sectionName) {
                    switchSection(sectionName);
                }
                return false;
            });
        });
    } else {
        console.warn('No navigation items found');
    }
    
    // Alternative: Use event delegation on the nav container
    const navContainer = document.querySelector('.dashboard-nav');
    if (navContainer) {
        navContainer.addEventListener('click', function(e) {
            const clickedItem = e.target.closest('.nav-item');
            if (clickedItem) {
                e.preventDefault();
                e.stopPropagation();
                const sectionName = clickedItem.getAttribute('data-section');
                console.log('Delegation - Section:', sectionName); // Debug
                if (sectionName) {
                    switchSection(sectionName);
                }
                return false;
            }
        }, true);
    }

    // Handle nav-link clicks (like view-all-link) using event delegation
    document.addEventListener('click', function(e) {
        const navLink = e.target.closest('.nav-link');
        if (navLink) {
            e.preventDefault();
            const sectionName = navLink.getAttribute('data-section');
            if (sectionName) {
                switchSection(sectionName);
            }
        }
    });

    // Also use event delegation for nav-items as fallback
    document.addEventListener('click', function(e) {
        const navItem = e.target.closest('.nav-item');
        if (navItem && !navItem.classList.contains('active')) {
            e.preventDefault();
            e.stopPropagation();
            const sectionName = navItem.getAttribute('data-section');
            if (sectionName) {
                console.log('Event delegation triggered for:', sectionName); // Debug
                switchSection(sectionName);
            }
        }
    }, true);

    // Projects Filter Functionality
    const filterBtns = document.querySelectorAll('.filter-btn');
    const projectCards = document.querySelectorAll('.project-card');

    if (filterBtns.length > 0) {
        filterBtns.forEach(btn => {
            btn.addEventListener('click', function() {
                const filter = this.getAttribute('data-filter');
                
                // Update active filter button
                filterBtns.forEach(b => b.classList.remove('active'));
                this.classList.add('active');
                
                // Filter projects
                projectCards.forEach(card => {
                    if (filter === 'all' || card.getAttribute('data-status') === filter) {
                        card.style.display = 'block';
                        setTimeout(() => {
                            card.style.opacity = '1';
                            card.style.transform = 'translateY(0)';
                        }, 10);
                    } else {
                        card.style.opacity = '0';
                        card.style.transform = 'translateY(-10px)';
                        setTimeout(() => {
                            card.style.display = 'none';
                        }, 300);
                    }
                });
            });
        });
    }

    // Mark All Notifications as Read
    const markAllReadBtn = document.getElementById('markAllReadBtn');
    const notificationItems = document.querySelectorAll('.notification-item.unread');

    if (markAllReadBtn) {
        markAllReadBtn.addEventListener('click', function() {
            notificationItems.forEach(item => {
                item.classList.remove('unread');
                const dot = item.querySelector('.notification-dot');
                if (dot) {
                    dot.remove();
                }
            });
            
            // Update badge
            const notificationsBadge = document.getElementById('notificationsBadge');
            if (notificationsBadge) {
                notificationsBadge.textContent = '0';
                notificationsBadge.classList.remove('badge-new');
            }
            
            alert('Todas las notificaciones han sido marcadas como leídas.');
        });
    }

    // Main Edit Profile Button - Opens all edit modes
    const editProfileBtn = document.getElementById('editProfileBtn');
    if (editProfileBtn) {
        editProfileBtn.addEventListener('click', function() {
            // Trigger bio edit
            if (editBioBtn) {
                editBioBtn.click();
            }
            // Trigger personal info edit
            if (editInfoBtn) {
                editInfoBtn.click();
            }
        });
    }

    // Profile Image Upload
    const editImageBtn = document.getElementById('editImageBtn');
    const profileImageInput = document.getElementById('profileImageInput');
    const profileImage = document.getElementById('profileImage');
    const imageUploadActions = document.getElementById('imageUploadActions');
    const saveImageBtn = document.getElementById('saveImageBtn');
    const cancelImageBtn = document.getElementById('cancelImageBtn');
    
    // Debug: Check if elements exist
    console.log('Profile image elements:', {
        editImageBtn: !!editImageBtn,
        profileImageInput: !!profileImageInput,
        profileImage: !!profileImage,
        imageUploadActions: !!imageUploadActions,
        saveImageBtn: !!saveImageBtn,
        cancelImageBtn: !!cancelImageBtn
    });
    
    let selectedImageFile = null;
    let originalImageSrc = profileImage ? profileImage.src : '';

    if (editImageBtn && profileImageInput) {
        editImageBtn.addEventListener('click', function() {
            profileImageInput.click();
        });

        profileImageInput.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                // Validate file type
                if (!file.type.match('image.*')) {
                    alert('Por favor, selecciona una imagen válida.');
                    return;
                }
                
                // Validate file size (max 5MB)
                if (file.size > 5 * 1024 * 1024) {
                    alert('La imagen es demasiado grande. Por favor, selecciona una imagen menor a 5MB.');
                    return;
                }
                
                selectedImageFile = file;
                const reader = new FileReader();
                reader.onload = function(e) {
                    if (profileImage) {
                        profileImage.src = e.target.result;
                    }
                    // Show save/cancel buttons
                    if (imageUploadActions) {
                        imageUploadActions.style.display = 'flex';
                        imageUploadActions.style.visibility = 'visible';
                        imageUploadActions.classList.add('show');
                        console.log('Image selected - showing save/cancel buttons');
                    } else {
                        console.error('imageUploadActions element not found in DOM');
                    }
                };
                reader.readAsDataURL(file);
            }
        });
    } else {
        console.log('Edit image button or input not found');
    }

    // Save image
    if (saveImageBtn) {
        saveImageBtn.addEventListener('click', function() {
            if (!selectedImageFile) {
                alert('Por favor, selecciona una imagen primero.');
                return;
            }

            // Show loading state
            const originalText = saveImageBtn.innerHTML;
            saveImageBtn.disabled = true;
            saveImageBtn.innerHTML = '<svg width="16" height="16" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="10" cy="10" r="8" stroke="currentColor" stroke-width="2"/><path d="M10 6V10L13 13" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg> Guardando...';

            // Create FormData for file upload
            const formData = new FormData();
            formData.append('action', 'nidfil_save_profile_image');
            formData.append('profile_image', selectedImageFile);
            formData.append('nonce', nidfilAjax.nonce);

            // Upload image via AJAX
            fetch(nidfilAjax.ajaxurl, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Update image source if new URL provided
                    if (data.data && data.data.image_url) {
                        profileImage.src = data.data.image_url;
                        // Add cache busting to ensure new image loads
                        profileImage.src = data.data.image_url + '?t=' + new Date().getTime();
                    }
                    // Hide save/cancel buttons
                    if (imageUploadActions) {
                        imageUploadActions.style.display = 'none';
                        imageUploadActions.classList.remove('show');
                    }
                    // Reset file input
                    profileImageInput.value = '';
                    selectedImageFile = null;
                    originalImageSrc = profileImage.src;
                    
                    // Show success message briefly
                    const successMsg = data.data && data.data.message ? data.data.message : 'Imagen de perfil actualizada correctamente.';
                    alert(successMsg);
                } else {
                    const errorMsg = data.data && data.data.message ? data.data.message : 'Error al guardar la imagen.';
                    alert(errorMsg);
                    // Restore original image
                    profileImage.src = originalImageSrc;
                }
                saveImageBtn.disabled = false;
                saveImageBtn.innerHTML = originalText;
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Error al guardar la imagen. Por favor, intenta de nuevo.');
                // Restore original image
                profileImage.src = originalImageSrc;
                saveImageBtn.disabled = false;
                saveImageBtn.innerHTML = originalText;
            });
        });
    }

    // Cancel image upload
    if (cancelImageBtn) {
        cancelImageBtn.addEventListener('click', function() {
            // Restore original image
            profileImage.src = originalImageSrc;
            // Hide save/cancel buttons
            if (imageUploadActions) {
                imageUploadActions.style.display = 'none';
                imageUploadActions.classList.remove('show');
            }
            // Reset file input
            profileImageInput.value = '';
            selectedImageFile = null;
        });
    }

    // Bio Edit Functionality
    const editBioBtn = document.getElementById('editBioBtn');
    const bioText = document.getElementById('bioText');
    const bioEditForm = document.getElementById('bioEditForm');
    const bioTextarea = document.getElementById('bioTextarea');
    const saveBioBtn = document.getElementById('saveBioBtn');
    const cancelBioBtn = document.getElementById('cancelBioBtn');

    if (editBioBtn) {
        editBioBtn.addEventListener('click', function() {
            const currentBio = bioText.textContent.trim();
            const defaultText = 'Aún no has agregado una biografía. Haz clic en editar para agregar una.';
            bioText.style.display = 'none';
            bioEditForm.style.display = 'block';
            // Set the actual bio text, not the default message
            if (currentBio !== defaultText) {
                bioTextarea.value = currentBio;
            } else {
                bioTextarea.value = '';
            }
            bioTextarea.focus();
        });
    }

    if (saveBioBtn) {
        saveBioBtn.addEventListener('click', function(e) {
            e.preventDefault();
            const newBio = bioTextarea.value.trim();
            
            // Show loading state
            const originalText = saveBioBtn.textContent;
            saveBioBtn.disabled = true;
            saveBioBtn.textContent = 'Guardando...';
            
            // Save bio via AJAX
            fetch(nidfilAjax.ajaxurl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    action: 'nidfil_save_bio',
                    bio: newBio,
                    nonce: nidfilAjax.nonce
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    bioText.textContent = newBio || 'Aún no has agregado una biografía. Haz clic en editar para agregar una.';
                    bioText.style.display = 'block';
                    bioEditForm.style.display = 'none';
                    alert('Biografía guardada correctamente.');
                } else {
                    alert(data.data && data.data.message ? data.data.message : 'Error al guardar la biografía.');
                }
                saveBioBtn.disabled = false;
                saveBioBtn.textContent = originalText;
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Error al guardar la biografía. Por favor, intenta de nuevo.');
                saveBioBtn.disabled = false;
                saveBioBtn.textContent = originalText;
            });
        });
    }

    if (cancelBioBtn) {
        cancelBioBtn.addEventListener('click', function(e) {
            e.preventDefault();
            bioText.style.display = 'block';
            bioEditForm.style.display = 'none';
        });
    }

    // Personal Information Edit
    const editInfoBtn = document.getElementById('editInfoBtn');
    const infoFormActions = document.getElementById('infoFormActions');
    const saveInfoBtn = document.getElementById('saveInfoBtn');
    const cancelInfoBtn = document.getElementById('cancelInfoBtn');

    const infoFields = {
        fullName: { value: 'fullNameValue', input: 'fullNameInput' },
        email: { value: 'emailValue', input: 'emailInput' },
        phone: { value: 'phoneValue', input: 'phoneInput' },
        location: { value: 'locationValue', input: 'locationInput' }
    };

    if (editInfoBtn) {
        editInfoBtn.addEventListener('click', function() {
            Object.keys(infoFields).forEach(key => {
                const valueEl = document.getElementById(infoFields[key].value);
                const inputEl = document.getElementById(infoFields[key].input);
                if (valueEl && inputEl) {
                    valueEl.style.display = 'none';
                    inputEl.style.display = 'block';
                    if (!inputEl.value && valueEl.textContent !== 'No agregado') {
                        inputEl.value = valueEl.textContent;
                    }
                }
            });
            infoFormActions.style.display = 'flex';
        });
    }

    if (saveInfoBtn) {
        saveInfoBtn.addEventListener('click', function(e) {
            e.preventDefault();
            const data = {};
            
            Object.keys(infoFields).forEach(key => {
                const inputEl = document.getElementById(infoFields[key].input);
                if (inputEl) {
                    data[key] = inputEl.value.trim();
                }
            });
            
            // Show loading state
            const originalText = saveInfoBtn.textContent;
            saveInfoBtn.disabled = true;
            saveInfoBtn.textContent = 'Guardando...';
            
            // Save personal info via AJAX
            fetch(nidfilAjax.ajaxurl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    action: 'nidfil_save_personal_info',
                    full_name: data.fullName || '',
                    email: data.email || '',
                    phone: data.phone || '',
                    location: data.location || '',
                    nonce: nidfilAjax.nonce
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Update display values
                    Object.keys(infoFields).forEach(key => {
                        const inputEl = document.getElementById(infoFields[key].input);
                        const valueEl = document.getElementById(infoFields[key].value);
                        if (inputEl && valueEl) {
                            const value = inputEl.value.trim();
                            valueEl.textContent = value || 'No agregado';
                            valueEl.style.display = 'block';
                            inputEl.style.display = 'none';
                        }
                    });
                    
                    infoFormActions.style.display = 'none';
                    
                    // Update profile name if full name changed
                    const fullNameInput = document.getElementById('fullNameInput');
                    if (fullNameInput) {
                        const profileName = document.getElementById('profileName');
                        if (profileName) {
                            profileName.textContent = fullNameInput.value.trim();
                        }
                    }
                    
                    alert('Información guardada correctamente.');
                } else {
                    alert(data.data && data.data.message ? data.data.message : 'Error al guardar la información.');
                }
                saveInfoBtn.disabled = false;
                saveInfoBtn.textContent = originalText;
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Error al guardar la información. Por favor, intenta de nuevo.');
                saveInfoBtn.disabled = false;
                saveInfoBtn.textContent = originalText;
            });
        });
    }

    if (cancelInfoBtn) {
        cancelInfoBtn.addEventListener('click', function(e) {
            e.preventDefault();
            Object.keys(infoFields).forEach(key => {
                const valueEl = document.getElementById(infoFields[key].value);
                const inputEl = document.getElementById(infoFields[key].input);
                if (valueEl && inputEl) {
                    valueEl.style.display = 'block';
                    inputEl.style.display = 'none';
                }
            });
            infoFormActions.style.display = 'none';
        });
    }

    // Skills Edit Functionality
    const editSkillsBtn = document.getElementById('editSkillsBtn');
    const skillsContainer = document.getElementById('skillsContainer');
    const skillsEditForm = document.getElementById('skillsEditForm');
    const skillsInput = document.getElementById('skillsInput');
    const saveSkillsBtn = document.getElementById('saveSkillsBtn');
    const cancelSkillsBtn = document.getElementById('cancelSkillsBtn');

    if (editSkillsBtn) {
        editSkillsBtn.addEventListener('click', function() {
            const currentSkills = Array.from(skillsContainer.querySelectorAll('.skill-tag'))
                .map(tag => tag.textContent.trim())
                .join(', ');
            skillsContainer.style.display = 'none';
            skillsEditForm.style.display = 'block';
            if (skillsInput) {
                skillsInput.value = currentSkills;
                skillsInput.focus();
            }
        });
    }

    if (saveSkillsBtn && skillsInput) {
        saveSkillsBtn.addEventListener('click', function(e) {
            e.preventDefault();
            const skills = skillsInput.value.trim();
            
            const originalText = saveSkillsBtn.textContent;
            saveSkillsBtn.disabled = true;
            saveSkillsBtn.textContent = 'Guardando...';
            
            fetch(nidfilAjax.ajaxurl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    action: 'nidfil_save_skills',
                    skills: skills,
                    nonce: nidfilAjax.nonce
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Update skills display
                    skillsContainer.innerHTML = '';
                    if (skills) {
                        const skillsArray = skills.split(',').map(s => s.trim()).filter(s => s);
                        skillsArray.forEach(skill => {
                            const tag = document.createElement('span');
                            tag.className = 'skill-tag';
                            tag.textContent = skill;
                            skillsContainer.appendChild(tag);
                        });
                    } else {
                        skillsContainer.innerHTML = '<p class="empty-state">No has agregado habilidades aún. Haz clic en editar para agregar.</p>';
                    }
                    skillsContainer.style.display = 'flex';
                    skillsEditForm.style.display = 'none';
                    alert('Habilidades guardadas correctamente.');
                } else {
                    alert(data.data && data.data.message ? data.data.message : 'Error al guardar las habilidades.');
                }
                saveSkillsBtn.disabled = false;
                saveSkillsBtn.textContent = originalText;
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Error al guardar las habilidades. Por favor, intenta de nuevo.');
                saveSkillsBtn.disabled = false;
                saveSkillsBtn.textContent = originalText;
            });
        });
    }

    if (cancelSkillsBtn) {
        cancelSkillsBtn.addEventListener('click', function(e) {
            e.preventDefault();
            skillsContainer.style.display = 'flex';
            skillsEditForm.style.display = 'none';
        });
    }

    // Social Media Edit Functionality
    const editSocialBtn = document.getElementById('editSocialBtn');
    const socialFormActions = document.getElementById('socialFormActions');
    const saveSocialBtn = document.getElementById('saveSocialBtn');
    const cancelSocialBtn = document.getElementById('cancelSocialBtn');

    const socialFields = {
        facebook: { value: 'facebookValue', input: 'facebookInput' },
        twitter: { value: 'twitterValue', input: 'twitterInput' },
        instagram: { value: 'instagramValue', input: 'instagramInput' },
        linkedin: { value: 'linkedinValue', input: 'linkedinInput' }
    };

    if (editSocialBtn) {
        editSocialBtn.addEventListener('click', function() {
            Object.keys(socialFields).forEach(key => {
                const valueEl = document.getElementById(socialFields[key].value);
                const inputEl = document.getElementById(socialFields[key].input);
                if (valueEl && inputEl) {
                    valueEl.style.display = 'none';
                    inputEl.style.display = 'block';
                    if (!inputEl.value && valueEl.textContent !== 'No agregado') {
                        inputEl.value = valueEl.textContent;
                    }
                }
            });
            if (socialFormActions) {
                socialFormActions.style.display = 'flex';
            }
        });
    }

    if (saveSocialBtn) {
        saveSocialBtn.addEventListener('click', function(e) {
            e.preventDefault();
            const data = {};
            
            Object.keys(socialFields).forEach(key => {
                const inputEl = document.getElementById(socialFields[key].input);
                if (inputEl) {
                    data[key] = inputEl.value.trim();
                }
            });
            
            const originalText = saveSocialBtn.textContent;
            saveSocialBtn.disabled = true;
            saveSocialBtn.textContent = 'Guardando...';
            
            fetch(nidfilAjax.ajaxurl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    action: 'nidfil_save_social_links',
                    facebook: data.facebook || '',
                    twitter: data.twitter || '',
                    instagram: data.instagram || '',
                    linkedin: data.linkedin || '',
                    nonce: nidfilAjax.nonce
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    Object.keys(socialFields).forEach(key => {
                        const inputEl = document.getElementById(socialFields[key].input);
                        const valueEl = document.getElementById(socialFields[key].value);
                        if (inputEl && valueEl) {
                            const value = inputEl.value.trim();
                            valueEl.textContent = value || 'No agregado';
                            valueEl.style.display = 'block';
                            inputEl.style.display = 'none';
                        }
                    });
                    if (socialFormActions) {
                        socialFormActions.style.display = 'none';
                    }
                    alert('Redes sociales guardadas correctamente.');
                } else {
                    alert(data.data && data.data.message ? data.data.message : 'Error al guardar las redes sociales.');
                }
                saveSocialBtn.disabled = false;
                saveSocialBtn.textContent = originalText;
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Error al guardar las redes sociales. Por favor, intenta de nuevo.');
                saveSocialBtn.disabled = false;
                saveSocialBtn.textContent = originalText;
            });
        });
    }

    if (cancelSocialBtn) {
        cancelSocialBtn.addEventListener('click', function(e) {
            e.preventDefault();
            Object.keys(socialFields).forEach(key => {
                const valueEl = document.getElementById(socialFields[key].value);
                const inputEl = document.getElementById(socialFields[key].input);
                if (valueEl && inputEl) {
                    valueEl.style.display = 'block';
                    inputEl.style.display = 'none';
                }
            });
            if (socialFormActions) {
                socialFormActions.style.display = 'none';
            }
        });
    }

    // Messages Functionality
    const messageInput = document.getElementById('messageInput');
    const sendMessageBtn = document.getElementById('sendMessageBtn');
    const chatMessages = document.getElementById('chatMessages');

    function addMessage(text, isSent = true) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${isSent ? 'sent' : 'received'}`;
        const now = new Date();
        const time = now.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' });
        messageDiv.innerHTML = `
            <p>${text}</p>
            <span class="message-time">${time}</span>
        `;
        chatMessages.appendChild(messageDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    if (sendMessageBtn && messageInput) {
        sendMessageBtn.addEventListener('click', function() {
            const message = messageInput.value.trim();
            if (message) {
                addMessage(message, true);
                messageInput.value = '';
                // Add AJAX call to send message
                // sendMessage(message);
            }
        });

        messageInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                sendMessageBtn.click();
            }
        });
    }

    // Reviews Functionality
    const addReviewBtn = document.getElementById('addReviewBtn');
    const addReviewModal = document.getElementById('addReviewModal');
    const addReviewForm = document.getElementById('addReviewForm');
    const ratingInput = document.getElementById('ratingInput');
    const selectedRating = document.getElementById('selectedRating');
    const ratingStars = ratingInput ? ratingInput.querySelectorAll('.rating-star') : [];

    // Rating star interaction
    ratingStars.forEach(star => {
        star.addEventListener('click', function() {
            const rating = parseInt(this.getAttribute('data-rating'));
            selectedRating.value = rating;
            
            ratingStars.forEach((s, index) => {
                if (index < rating) {
                    s.classList.add('active');
                    s.querySelector('path').setAttribute('fill', '#FFD700');
                } else {
                    s.classList.remove('active');
                    s.querySelector('path').setAttribute('fill', '#E5E5E5');
                }
            });
        });

        star.addEventListener('mouseenter', function() {
            const rating = parseInt(this.getAttribute('data-rating'));
            ratingStars.forEach((s, index) => {
                if (index < rating) {
                    s.querySelector('path').setAttribute('fill', '#FFD700');
                }
            });
        });
    });

    if (ratingInput) {
        ratingInput.addEventListener('mouseleave', function() {
            const currentRating = parseInt(selectedRating.value) || 0;
            ratingStars.forEach((s, index) => {
                if (index < currentRating) {
                    s.querySelector('path').setAttribute('fill', '#FFD700');
                } else {
                    s.querySelector('path').setAttribute('fill', '#E5E5E5');
                }
            });
        });
    }

    if (addReviewBtn) {
        addReviewBtn.addEventListener('click', function() {
            if (addReviewModal) {
                addReviewModal.classList.add('modal-active');
                document.body.style.overflow = 'hidden';
            }
        });
    }

    if (addReviewForm) {
        addReviewForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const rating = selectedRating.value;
            const reviewText = document.getElementById('reviewText').value;
            
            if (!rating || rating === '0') {
                alert('Por favor, selecciona una calificación');
                return;
            }
            
            // Add review to list
            addReviewToList(rating, reviewText);
            
            // Close modal
            closeAddReviewModal();
            
            // Add AJAX call to save review
            // saveReview({ rating, review: reviewText });
        });
    }

    function addReviewToList(rating, text) {
        const reviewsList = document.getElementById('reviewsList');
        if (!reviewsList) return;
        
        const reviewCard = document.createElement('div');
        reviewCard.className = 'review-card';
        const now = new Date();
        const dateStr = 'Hace unos momentos';
        
        let starsHtml = '';
        for (let i = 1; i <= 5; i++) {
            const filled = i <= rating ? 'filled' : 'empty';
            starsHtml += `
                <svg width="16" height="16" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" class="star ${filled}">
                    <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="${i <= rating ? '#FFD700' : '#E5E5E5'}"/>
                </svg>
            `;
        }
        
        reviewCard.innerHTML = `
            <div class="review-header">
                <div class="reviewer-info">
                    <div class="reviewer-avatar">TU</div>
                    <div>
                        <h4>Tú</h4>
                        <div class="review-rating editable-rating" data-rating="${rating}">
                            ${starsHtml}
                        </div>
                    </div>
                </div>
                <button class="icon-btn edit-review-btn">
                    <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M13.5 2.5L15.5 4.5M14 1L17 4L9 12H6V9L14 1Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                </button>
            </div>
            <p class="review-text">${text}</p>
            <span class="review-date">${dateStr}</span>
        `;
        
        reviewsList.insertBefore(reviewCard, reviewsList.firstChild);
    }

    // Editable rating in review cards
    document.addEventListener('click', function(e) {
        if (e.target.closest('.editable-rating .star')) {
            const ratingContainer = e.target.closest('.editable-rating');
            const stars = ratingContainer.querySelectorAll('.star');
            const clickedStar = e.target.closest('.star');
            const newRating = Array.from(stars).indexOf(clickedStar) + 1;
            
            ratingContainer.setAttribute('data-rating', newRating);
            
            stars.forEach((star, index) => {
                if (index < newRating) {
                    star.classList.add('filled');
                    star.classList.remove('empty');
                    star.querySelector('path').setAttribute('fill', '#FFD700');
                } else {
                    star.classList.add('empty');
                    star.classList.remove('filled');
                    star.querySelector('path').setAttribute('fill', '#E5E5E5');
                }
            });
            
            // Add AJAX call to update rating
            // updateReviewRating(ratingContainer.closest('.review-card'), newRating);
        }
    });
})();

// Close Add Review Modal
function closeAddReviewModal() {
    const modal = document.getElementById('addReviewModal');
    if (modal) {
        modal.classList.remove('modal-active');
        document.body.style.overflow = '';
        // Reset form
        const form = document.getElementById('addReviewForm');
        if (form) {
            form.reset();
            const ratingStars = document.querySelectorAll('#ratingInput .rating-star');
            ratingStars.forEach(star => {
                star.classList.remove('active');
                star.querySelector('path').setAttribute('fill', '#E5E5E5');
            });
            document.getElementById('selectedRating').value = '0';
        }
    }
}

