<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header id="masthead" class="site-header">
    <div class="header-container">
        <a href="<?php echo esc_url(home_url('/')); ?>" class="site-logo" rel="home">
            <?php
            // Check for custom logo first
            $custom_logo = get_theme_mod('custom_logo');
            if ($custom_logo) {
                echo wp_get_attachment_image($custom_logo, 'full', false, array('class' => 'logo-image', 'alt' => get_bloginfo('name')));
            } else {
                // Check for logo files in order of preference
                $logo_paths = array(
                    get_template_directory() . '/assets/images/logo.png',
                    get_template_directory() . '/assets/images/logo.svg',
                    get_template_directory() . '/assets/images/nidfil-logo.png',
                    get_template_directory() . '/assets/images/nidfil-logo.svg',
                );
                
                $logo_found = false;
                foreach ($logo_paths as $logo_path) {
                    if (file_exists($logo_path)) {
                        $logo_url = get_template_directory_uri() . '/assets/images/' . basename($logo_path);
                        echo '<img src="' . esc_url($logo_url) . '" alt="' . esc_attr(get_bloginfo('name')) . '" class="logo-image" />';
                        $logo_found = true;
                        break;
                    }
                }
                
                // Fallback to SVG if no file found
                if (!$logo_found) {
                    echo '<img src="' . esc_url(get_template_directory_uri() . '/assets/images/nidfil-logo.svg') . '" alt="' . esc_attr(get_bloginfo('name')) . '" class="logo-image" />';
                }
            }
            ?>
        </a>
        
        <a href="#" class="header-specialist-link" id="headerSpecialistLink">
            <span class="header-specialist-highlight">PUBLICA TU SERVICIO GRATIS</span>
        </a>
        
        <div class="header-right">
            <div class="header-dropdown language-switcher">
                <button class="language-switcher-button" id="languageSwitcherBtn">
                    <span class="current-language" id="currentLanguage">ES</span>
                    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg" class="dropdown-arrow">
                        <path d="M6 9L1 4H11L6 9Z" fill="#2C2C2C"/>
                    </svg>
                </button>
                <div class="language-dropdown-menu" id="languageDropdown">
                    <a href="#" class="language-option" data-lang="es" data-code="ES">
                        <span class="language-name">Español</span>
                        <span class="language-code">ES</span>
                    </a>
                    <a href="#" class="language-option" data-lang="en" data-code="EN">
                        <span class="language-name">English</span>
                        <span class="language-code">EN</span>
                    </a>
                    <a href="#" class="language-option" data-lang="pt" data-code="PT">
                        <span class="language-name">Português</span>
                        <span class="language-code">PT</span>
                    </a>
                    <a href="#" class="language-option" data-lang="fr" data-code="FR">
                        <span class="language-name">Français</span>
                        <span class="language-code">FR</span>
                    </a>
                    <a href="#" class="language-option" data-lang="it" data-code="IT">
                        <span class="language-name">Italiano</span>
                        <span class="language-code">IT</span>
                    </a>
                </div>
            </div>
            
            <div class="header-dropdown access-dropdown">
                <button class="access-button" id="accessButton">
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M8 8C10.2091 8 12 6.20914 12 4C12 1.79086 10.2091 0 8 0C5.79086 0 4 1.79086 4 4C4 6.20914 5.79086 8 8 8Z" fill="#F97015"/>
                        <path d="M0 16C0 12.6863 2.68629 10 6 10H10C13.3137 10 16 12.6863 16 16V16H0V16Z" fill="#F97015"/>
                    </svg>
                    <span>Acceso</span>
                    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg" class="dropdown-arrow">
                        <path d="M6 9L1 4H11L6 9Z" fill="#2C2C2C"/>
                    </svg>
                </button>
                <div class="access-dropdown-menu" id="accessDropdown">
                    <a href="#" class="access-option" id="soyClienteBtn">
                        <span>Soy Cliente</span>
                    </a>
                    <a href="#" class="access-option" id="soyEspecialistaBtn">
                        <span>Soy Especialista</span>
                    </a>
                </div>
            </div>
        </div>
    </div>
</header>

<script>
// Simple Language Switcher Toggle - Direct Implementation
(function() {
    'use strict';
    
    function initLangSwitcher() {
        const langBtn = document.getElementById('languageSwitcherBtn');
        const langSwitcher = document.querySelector('.language-switcher');
        const langOptions = document.querySelectorAll('.language-option');
        const currentLang = document.getElementById('currentLanguage');
        
        if (!langBtn || !langSwitcher) {
            return;
        }
        
        // Remove existing listeners by cloning
        const newBtn = langBtn.cloneNode(true);
        langBtn.parentNode.replaceChild(newBtn, langBtn);
        
        // Toggle dropdown
        newBtn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            langSwitcher.classList.toggle('active');
        });
        
        // Handle language selection
        langOptions.forEach(option => {
            option.addEventListener('click', function(e) {
                e.preventDefault();
                const code = this.getAttribute('data-code');
                if (currentLang) {
                    currentLang.textContent = code;
                }
                localStorage.setItem('selectedLanguage', code);
                langSwitcher.classList.remove('active');
            });
        });
        
        // Close on outside click
        document.addEventListener('click', function(e) {
            if (!langSwitcher.contains(e.target)) {
                langSwitcher.classList.remove('active');
            }
        });
    }
    
    // Initialize
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initLangSwitcher);
    } else {
        initLangSwitcher();
    }
    setTimeout(initLangSwitcher, 200);
})();

// Simple Acceso Dropdown Toggle - Direct Implementation
(function() {
    'use strict';
    
    function initAccesoDropdown() {
        const accesoBtn = document.getElementById('accessButton');
        const accesoDropdown = document.querySelector('.access-dropdown');
        const soyClienteBtn = document.getElementById('soyClienteBtn');
        const soyEspecialistaBtn = document.getElementById('soyEspecialistaBtn');
        
        if (!accesoBtn || !accesoDropdown) {
            console.log('Acceso dropdown elements not found');
            return;
        }
        
        console.log('Acceso dropdown initialized');
        
        // Handle Soy Cliente button
        if (soyClienteBtn) {
            soyClienteBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                accesoDropdown.classList.remove('active');
                if (typeof openClienteModal === 'function') {
                    openClienteModal();
                } else if (window.openClienteModal) {
                    window.openClienteModal();
                }
            });
        }
        
        // Handle Soy Especialista button
        if (soyEspecialistaBtn) {
            soyEspecialistaBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                accesoDropdown.classList.remove('active');
                if (typeof openEspecialistaModal === 'function') {
                    openEspecialistaModal();
                } else if (window.openEspecialistaModal) {
                    window.openEspecialistaModal();
                }
            });
        }
        
        // Remove existing listeners by cloning
        const newBtn = accesoBtn.cloneNode(true);
        accesoBtn.parentNode.replaceChild(newBtn, accesoBtn);
        
        // Toggle dropdown
        newBtn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            console.log('Acceso button clicked');
            accesoDropdown.classList.toggle('active');
            console.log('Acceso dropdown active:', accesoDropdown.classList.contains('active'));
        });
        
        // Handle option clicks
        if (soyClienteBtn) {
            soyClienteBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                console.log('Soy Cliente clicked');
                accesoDropdown.classList.remove('active');
                if (typeof openClienteModal === 'function') {
                    openClienteModal();
                } else if (window.openClienteModal) {
                    window.openClienteModal();
                } else {
                    const clienteModal = document.getElementById('clienteModal');
                    if (clienteModal) {
                        clienteModal.classList.add('modal-active');
                        document.body.style.overflow = 'hidden';
                    }
                }
            });
        }
        
        if (soyEspecialistaBtn) {
            soyEspecialistaBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                console.log('Soy Especialista clicked');
                accesoDropdown.classList.remove('active');
                if (typeof openEspecialistaModal === 'function') {
                    openEspecialistaModal();
                } else if (window.openEspecialistaModal) {
                    window.openEspecialistaModal();
                } else {
                    const especialistaModal = document.getElementById('especialistaModal');
                    if (especialistaModal) {
                        especialistaModal.classList.add('modal-active');
                        document.body.style.overflow = 'hidden';
                    }
                }
            });
        }
        
        if (soyEspecialistaBtn) {
            soyEspecialistaBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                console.log('Soy Especialista clicked');
                accesoDropdown.classList.remove('active');
                // Add specialist modal logic here if needed
            });
        }
        
        // Close on outside click
        document.addEventListener('click', function(e) {
            if (!accesoDropdown.contains(e.target)) {
                accesoDropdown.classList.remove('active');
            }
        });
    }
    
    // Initialize
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initAccesoDropdown);
    } else {
        initAccesoDropdown();
    }
    setTimeout(initAccesoDropdown, 200);
})();

// Header Specialist Link Handler
(function() {
    'use strict';
    
    function initHeaderSpecialistLink() {
        const headerSpecialistLink = document.getElementById('headerSpecialistLink');
        
        if (!headerSpecialistLink) {
            return;
        }
        
        headerSpecialistLink.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            // Open specialist modal
            if (typeof openEspecialistaModal === 'function') {
                openEspecialistaModal();
                // Switch to register tab after a short delay to ensure modal is open
                setTimeout(function() {
                    if (typeof switchEspecialistaTab === 'function') {
                        switchEspecialistaTab('register');
                    }
                }, 100);
            } else if (window.openEspecialistaModal) {
                window.openEspecialistaModal();
                setTimeout(function() {
                    if (window.switchEspecialistaTab) {
                        window.switchEspecialistaTab('register');
                    }
                }, 100);
            } else {
                const especialistaModal = document.getElementById('especialistaModal');
                if (especialistaModal) {
                    especialistaModal.classList.add('modal-active');
                    document.body.style.overflow = 'hidden';
                    setTimeout(function() {
                        if (typeof switchEspecialistaTab === 'function') {
                            switchEspecialistaTab('register');
                        } else if (window.switchEspecialistaTab) {
                            window.switchEspecialistaTab('register');
                        }
                    }, 100);
                }
            }
        });
    }
    
    // Initialize
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initHeaderSpecialistLink);
    } else {
        initHeaderSpecialistLink();
    }
    setTimeout(initHeaderSpecialistLink, 200);
})();
</script>

<div id="page" class="site">

