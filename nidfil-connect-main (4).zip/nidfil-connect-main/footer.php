</div><!-- #page -->

<footer id="colophon" class="site-footer">
    <div class="footer-container">
        <div class="footer-content">
            <div class="footer-column">
                <div class="footer-logo">
                    <?php
                    // Check for custom logo first
                    $custom_logo = get_theme_mod('custom_logo');
                    if ($custom_logo) {
                        echo wp_get_attachment_image($custom_logo, 'full', false, array('class' => 'footer-logo-image', 'alt' => get_bloginfo('name')));
                    } else {
                        // Check for logo files in order of preference
                        $logo_paths = array(
                            get_template_directory() . '/assets/images/logo.png',
                            get_template_directory() . '/assets/images/logo.svg',
                            get_template_directory() . '/assets/images/nidfil-logo.png',
                            get_template_directory() . '/assets/images/nidfil-logo.svg',
                        );
                        
                        $logo_found = false;
                        foreach ($logo_paths as $logo_path) {
                            if (file_exists($logo_path)) {
                                $logo_url = get_template_directory_uri() . '/assets/images/' . basename($logo_path);
                                echo '<img src="' . esc_url($logo_url) . '" alt="' . esc_attr(get_bloginfo('name')) . '" class="footer-logo-image" />';
                                $logo_found = true;
                                break;
                            }
                        }
                        
                        // Fallback to SVG if no file found
                        if (!$logo_found) {
                            echo '<img src="' . esc_url(get_template_directory_uri() . '/assets/images/nidfil-logo.svg') . '" alt="' . esc_attr(get_bloginfo('name')) . '" class="footer-logo-image" />';
                        }
                    }
                    ?>
                </div>
                <p class="footer-description">El espacio digital donde propietarios y especialistas de la construcción se encuentran.</p>
                <div class="social-links">
                    <a href="#" class="social-link" aria-label="Instagram">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M10 2C7.23858 2 6.875 2.01 5.8125 2.06C4.75 2.11 4.0625 2.27 3.4375 2.5C2.75 2.75 2.1875 3.0625 1.625 3.625C1.0625 4.1875 0.75 4.75 0.5 5.4375C0.27 6.0625 0.11 6.75 0.06 7.8125C0.01 8.875 0 9.23858 0 12C0 14.7614 0.01 15.125 0.06 16.1875C0.11 17.25 0.27 17.9375 0.5 18.5625C0.75 19.25 1.0625 19.8125 1.625 20.375C2.1875 20.9375 2.75 21.25 3.4375 21.5C4.0625 21.73 4.75 21.89 5.8125 21.94C6.875 21.99 7.23858 22 10 22C12.7614 22 13.125 21.99 14.1875 21.94C15.25 21.89 15.9375 21.73 16.5625 21.5C17.25 21.25 17.8125 20.9375 18.375 20.375C18.9375 19.8125 19.25 19.25 19.5 18.5625C19.73 17.9375 19.89 17.25 19.94 16.1875C19.99 15.125 20 14.7614 20 12C20 9.23858 19.99 8.875 19.94 7.8125C19.89 6.75 19.73 6.0625 19.5 5.4375C19.25 4.75 18.9375 4.1875 18.375 3.625C17.8125 3.0625 17.25 2.75 16.5625 2.5C15.9375 2.27 15.25 2.11 14.1875 2.06C13.125 2.01 12.7614 2 10 2ZM10 4.375C12.7614 4.375 13.125 4.375 14.1875 4.4375C15.1875 4.5 15.75 4.625 16.125 4.75C16.625 4.9375 17 5.125 17.375 5.5C17.75 5.875 17.9375 6.25 18.125 6.75C18.25 7.125 18.375 7.6875 18.4375 8.6875C18.5 9.75 18.5 10.1136 18.5 12.875C18.5 15.6364 18.5 16 18.4375 17.0625C18.375 18.0625 18.25 18.625 18.125 19C17.9375 19.5 17.75 19.875 17.375 20.25C17 20.625 16.625 20.8125 16.125 21C15.75 21.125 15.1875 21.25 14.1875 21.3125C13.125 21.375 12.7614 21.375 10 21.375C7.23858 21.375 6.875 21.375 5.8125 21.3125C4.8125 21.25 4.25 21.125 3.875 21C3.375 20.8125 3 20.625 2.625 20.25C2.25 19.875 2.0625 19.5 1.875 19C1.75 18.625 1.625 18.0625 1.5625 17.0625C1.5 16 1.5 15.6364 1.5 12.875C1.5 10.1136 1.5 9.75 1.5625 8.6875C1.625 7.6875 1.75 7.125 1.875 6.75C2.0625 6.25 2.25 5.875 2.625 5.5C3 5.125 3.375 4.9375 3.875 4.75C4.25 4.625 4.8125 4.5 5.8125 4.4375C6.875 4.375 7.23858 4.375 10 4.375ZM10 6.25C7.92893 6.25 6.25 7.92893 6.25 10C6.25 12.0711 7.92893 13.75 10 13.75C12.0711 13.75 13.75 12.0711 13.75 10C13.75 7.92893 12.0711 6.25 10 6.25ZM10 12C8.89543 12 8 11.1046 8 10C8 8.89543 8.89543 8 10 8C11.1046 8 12 8.89543 12 10C12 11.1046 11.1046 12 10 12ZM15.375 6.625C15.375 7.24632 14.8713 7.75 14.25 7.75C13.6287 7.75 13.125 7.24632 13.125 6.625C13.125 6.00368 13.6287 5.5 14.25 5.5C14.8713 5.5 15.375 6.00368 15.375 6.625Z" fill="currentColor"/>
                        </svg>
                    </a>
                    <a href="#" class="social-link" aria-label="LinkedIn">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M18 0H2C0.895431 0 0 0.895431 0 2V18C0 19.1046 0.895431 20 2 20H18C19.1046 20 20 19.1046 20 18V2C20 0.895431 19.1046 0 18 0ZM6 17H3V7H6V17ZM4.5 5.5C3.67157 5.5 3 4.82843 3 4C3 3.17157 3.67157 2.5 4.5 2.5C5.32843 2.5 6 3.17157 6 4C6 4.82843 5.32843 5.5 4.5 5.5ZM17 17H14V12.5C14 11.3954 13.1046 10.5 12 10.5C10.8954 10.5 10 11.3954 10 12.5V17H7V7H10V8.5C10.6046 7.67157 11.6716 7 13 7C15.2091 7 17 8.79086 17 11V17Z" fill="currentColor"/>
                        </svg>
                    </a>
                </div>
            </div>
            
            <div class="footer-column">
                <h3 class="footer-title">Especialistas</h3>
                <ul class="footer-links">
                    <li><a href="#">Arquitectos</a></li>
                    <li><a href="#">Electricistas</a></li>
                    <li><a href="#">Fontaneros</a></li>
                    <li><a href="#">Pintores</a></li>
                    <li><a href="#">Ver todos</a></li>
                </ul>
            </div>
            
            <div class="footer-column">
                <h3 class="footer-title">Empresa</h3>
                <ul class="footer-links">
                    <li><a href="#">Sobre nosotros</a></li>
                    <li><a href="#">Blog</a></li>
                    <li><a href="#">Contacto</a></li>
                    <li><a href="#">Privacidad</a></li>
                    <li><a href="#">Términos</a></li>
                </ul>
            </div>
            
            <div class="footer-column">
                <h3 class="footer-title">Contacto</h3>
                <ul class="footer-contact">
                    <li>
                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M3.5 2C2.67157 2 2 2.67157 2 3.5V12.5C2 13.3284 2.67157 14 3.5 14H12.5C13.3284 14 14 13.3284 14 12.5V3.5C14 2.67157 13.3284 2 12.5 2H3.5ZM3.5 3H12.5C12.7761 3 13 3.22386 13 3.5V4.5L8 7.5L3 4.5V3.5C3 3.22386 3.22386 3 3.5 3ZM3 5.5L8 8.5L13 5.5V12.5C13 12.7761 12.7761 13 12.5 13H3.5C3.22386 13 3 12.7761 3 12.5V5.5Z" fill="currentColor"/>
                        </svg>
                        <span>info@nidfil.com</span>
                    </li>
                    <li>
                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M3.5 1C2.67157 1 2 1.67157 2 2.5V13.5C2 14.3284 2.67157 15 3.5 15H12.5C13.3284 15 14 14.3284 14 13.5V2.5C14 1.67157 13.3284 1 12.5 1H3.5ZM3.5 2H12.5C12.7761 2 13 2.22386 13 2.5V3.5L8 6.5L3 3.5V2.5C3 2.22386 3.22386 2 3.5 2ZM3 4.5L8 7.5L13 4.5V13.5C13 13.7761 12.7761 14 12.5 14H3.5C3.22386 14 3 13.7761 3 13.5V4.5Z" fill="currentColor"/>
                        </svg>
                        <span>+34 900 123 456</span>
                    </li>
                    <li>
                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M8 0C5.23858 0 3 2.23858 3 5C3 9 8 16 8 16C8 16 13 9 13 5C13 2.23858 10.7614 0 8 0ZM8 6.5C7.17157 6.5 6.5 5.82843 6.5 5C6.5 4.17157 7.17157 3.5 8 3.5C8.82843 3.5 9.5 4.17157 9.5 5C9.5 5.82843 8.82843 6.5 8 6.5Z" fill="currentColor"/>
                        </svg>
                        <span>Madrid, España</span>
                    </li>
                </ul>
            </div>
        </div>
        
        <div class="footer-bottom">
            <p>&copy; <?php echo date('Y'); ?> NIDFIL. Todos los derechos reservados.</p>
        </div>
    </div>
</footer>

<!-- Soy Cliente Modal -->
<div id="clienteModal" class="access-modal">
    <div class="modal-overlay" onclick="closeClienteModal()"></div>
    <div class="modal-content access-modal-content">
        <button class="modal-close" onclick="closeClienteModal()">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M18 6L6 18M6 6L18 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
        </button>
        
        <div class="modal-body">
            <div class="modal-header">
                <h2 class="modal-title">Soy Cliente</h2>
                <p class="modal-subtitle">Accede a tu cuenta o regístrate</p>
            </div>
            
            <div class="form-tabs">
                <button class="form-tab active" data-tab="login">Iniciar Sesión</button>
                <button class="form-tab" data-tab="register">Registrarse</button>
            </div>
            
            <!-- Login Form -->
            <form id="loginForm" class="access-form active-form" method="post" action="" novalidate>
                <div class="form-group">
                    <label for="loginEmail">Email</label>
                    <input type="email" id="loginEmail" name="email" placeholder="tu@email.com" required>
                </div>
                
                <div class="form-group">
                    <label for="loginPassword">Contraseña</label>
                    <input type="password" id="loginPassword" name="password" placeholder="••••••••" required>
                </div>
                
                <div class="form-options">
                    <label class="checkbox-label">
                        <input type="checkbox" name="remember">
                        <span>Recordarme</span>
                    </label>
                    <a href="#" class="forgot-password">¿Olvidaste tu contraseña?</a>
                </div>
                
                <button type="submit" class="btn btn-primary form-submit">Iniciar Sesión</button>
                
                <div class="form-divider">
                    <span>o</span>
                </div>
                
                <button type="button" class="btn btn-outline social-login">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                        <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                        <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                        <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
                    </svg>
                    Continuar con Google
                </button>
            </form>
            
            <!-- Register Form -->
            <form id="registerForm" class="access-form" method="post" action="" novalidate>
                <div class="form-group">
                    <label for="registerName">Nombre completo</label>
                    <input type="text" id="registerName" name="name" placeholder="Juan Pérez" required>
                </div>
                
                <div class="form-group">
                    <label for="registerEmail">Email</label>
                    <input type="email" id="registerEmail" name="email" placeholder="tu@email.com" required>
                </div>
                
                <div class="form-group">
                    <label for="registerPhone">Teléfono</label>
                    <input type="tel" id="registerPhone" name="phone" placeholder="+34 600 000 000" required>
                </div>
                
                <div class="form-group">
                    <label for="registerPassword">Contraseña</label>
                    <input type="password" id="registerPassword" name="password" placeholder="••••••••" required>
                </div>
                
                <div class="form-group">
                    <label for="registerPasswordConfirm">Confirmar contraseña</label>
                    <input type="password" id="registerPasswordConfirm" name="password_confirm" placeholder="••••••••" required>
                </div>
                
                <div class="form-group">
                    <label class="checkbox-label">
                        <input type="checkbox" name="terms" required>
                        <span>Acepto los <a href="#">términos y condiciones</a> y la <a href="#">política de privacidad</a></span>
                    </label>
                </div>
                
                <button type="submit" class="btn btn-primary form-submit">Registrarse</button>
                
                <div class="form-divider">
                    <span>o</span>
                </div>
                
                <button type="button" class="btn btn-outline social-login">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                        <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                        <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                        <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
                    </svg>
                    Continuar con Google
                </button>
            </form>
        </div>
    </div>
</div>

<!-- Soy Especialista Modal -->
<div id="especialistaModal" class="access-modal">
    <div class="modal-overlay" onclick="closeEspecialistaModal()"></div>
    <div class="modal-content access-modal-content">
        <button class="modal-close" onclick="closeEspecialistaModal()">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M18 6L6 18M6 6L18 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
        </button>
        
        <div class="modal-body">
            <div class="modal-header">
                <h2 class="modal-title">Soy Especialista</h2>
                <p class="modal-subtitle">Accede a tu cuenta profesional o regístrate</p>
            </div>
            
            <div class="form-tabs">
                <button class="form-tab active" data-tab="login" onclick="switchEspecialistaTab('login')">Iniciar Sesión</button>
                <button class="form-tab" data-tab="register" onclick="switchEspecialistaTab('register')">Registrarse</button>
            </div>
            
            <!-- Login Form -->
            <form id="especialistaLoginForm" class="access-form active-form" method="post" action="" novalidate>
                <div class="form-group">
                    <label for="especialistaLoginEmail">Email</label>
                    <input type="email" id="especialistaLoginEmail" name="email" placeholder="tu@email.com" required>
                </div>
                
                <div class="form-group">
                    <label for="especialistaLoginPassword">Contraseña</label>
                    <input type="password" id="especialistaLoginPassword" name="password" placeholder="••••••••" required>
                </div>
                
                <div class="form-options">
                    <label class="checkbox-label">
                        <input type="checkbox" name="remember">
                        <span>Recordarme</span>
                    </label>
                    <a href="#" class="forgot-password">¿Olvidaste tu contraseña?</a>
                </div>
                
                <button type="submit" class="btn btn-primary form-submit">Iniciar Sesión</button>
                
                <div class="form-divider">
                    <span>o</span>
                </div>
                
                <button type="button" class="btn btn-outline social-login">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                        <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                        <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                        <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
                    </svg>
                    Continuar con Google
                </button>
            </form>
            
            <!-- Register Form -->
            <form id="especialistaRegisterForm" class="access-form" method="post" action="" novalidate>
                <div class="form-group">
                    <label for="especialistaRegisterName">Nombre completo</label>
                    <input type="text" id="especialistaRegisterName" name="name" placeholder="Juan Pérez" required>
                </div>
                
                <div class="form-group">
                    <label for="especialistaRegisterEmail">Email</label>
                    <input type="email" id="especialistaRegisterEmail" name="email" placeholder="tu@email.com" required>
                </div>
                
                <div class="form-group">
                    <label for="especialistaRegisterPhone">Teléfono</label>
                    <input type="tel" id="especialistaRegisterPhone" name="phone" placeholder="+34 600 000 000" required>
                </div>
                
                <div class="form-group">
                    <label for="especialistaRegisterProfession">Profesión/Especialidad</label>
                    <input type="text" id="especialistaRegisterProfession" name="profession" placeholder="Ej: Electricista, Fontanero, Carpintero" required>
                </div>
                
                <div class="form-group">
                    <label for="especialistaRegisterExperience">Años de Experiencia</label>
                    <input type="number" id="especialistaRegisterExperience" name="experience" placeholder="Ej: 5" min="0" max="50" step="1" required>
                </div>
                
                <div class="form-group">
                    <label for="especialistaRegisterPassword">Contraseña</label>
                    <input type="password" id="especialistaRegisterPassword" name="password" placeholder="••••••••" required>
                </div>
                
                <div class="form-group">
                    <label for="especialistaRegisterPasswordConfirm">Confirmar contraseña</label>
                    <input type="password" id="especialistaRegisterPasswordConfirm" name="password_confirm" placeholder="••••••••" required>
                </div>
                
                <div class="form-group">
                    <label class="checkbox-label">
                        <input type="checkbox" name="terms" required>
                        <span>Acepto los <a href="#">términos y condiciones</a> y la <a href="#">política de privacidad</a></span>
                    </label>
                </div>
                
                <button type="submit" class="btn btn-primary form-submit">Registrarse como Especialista</button>
                
                <div class="form-divider">
                    <span>o</span>
                </div>
                
                <button type="button" class="btn btn-outline social-login">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                        <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                        <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                        <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
                    </svg>
                    Continuar con Google
                </button>
            </form>
        </div>
    </div>
</div>

<script>
// Ensure closeClienteModal is available globally
if (typeof closeClienteModal === 'undefined') {
    function closeClienteModal() {
        const modal = document.getElementById('clienteModal');
        if (modal) {
            modal.classList.remove('modal-active');
            document.body.style.overflow = '';
            // Reset forms
            const loginForm = document.getElementById('loginForm');
            const registerForm = document.getElementById('registerForm');
            if (loginForm) loginForm.reset();
            if (registerForm) registerForm.reset();
        }
    }
    window.closeClienteModal = closeClienteModal;
}

// Ensure switchFormTab is available globally
if (typeof switchFormTab === 'undefined') {
    function switchFormTab(tabName) {
        console.log('Footer script - Switching to tab:', tabName);
        const tabs = document.querySelectorAll('.form-tab');
        const loginForm = document.getElementById('loginForm');
        const registerForm = document.getElementById('registerForm');
        
        // Update tabs
        tabs.forEach(tab => {
            if (tab.getAttribute('data-tab') === tabName) {
                tab.classList.add('active');
            } else {
                tab.classList.remove('active');
            }
        });
        
        // Show/hide forms based on tab
        if (tabName === 'login') {
            if (loginForm) {
                loginForm.classList.add('active-form');
                loginForm.style.display = 'block';
                console.log('Footer - Showing login form');
            }
            if (registerForm) {
                registerForm.classList.remove('active-form');
                registerForm.style.display = 'none';
                console.log('Footer - Hiding register form');
            }
        } else if (tabName === 'register') {
            if (registerForm) {
                registerForm.classList.add('active-form');
                registerForm.style.display = 'block';
                console.log('Footer - Showing register form');
            }
            if (loginForm) {
                loginForm.classList.remove('active-form');
                loginForm.style.display = 'none';
                console.log('Footer - Hiding login form');
            }
        }
    }
    window.switchFormTab = switchFormTab;
}

// Also add direct event listener as fallback
document.addEventListener('DOMContentLoaded', function() {
    // Close button handler
    const closeBtn = document.querySelector('#clienteModal .modal-close');
    if (closeBtn) {
        closeBtn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            if (typeof closeClienteModal === 'function') {
                closeClienteModal();
            } else if (window.closeClienteModal) {
                window.closeClienteModal();
            }
        });
    }
    
    // Overlay click handler
    const overlay = document.querySelector('#clienteModal .modal-overlay');
    if (overlay) {
        overlay.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            if (typeof closeClienteModal === 'function') {
                closeClienteModal();
            } else if (window.closeClienteModal) {
                window.closeClienteModal();
            }
        });
    }
    
    // Form tab handlers - Direct implementation with fallback
    const formTabs = document.querySelectorAll('.form-tab');
    console.log('Footer script - Found tabs:', formTabs.length);
    
    formTabs.forEach(tab => {
        tab.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            const tabName = this.getAttribute('data-tab');
            console.log('Footer script - Tab clicked:', tabName);
            
            // Try to use the function if available
            if (typeof switchFormTab === 'function') {
                switchFormTab(tabName);
            } else if (window.switchFormTab) {
                window.switchFormTab(tabName);
            } else {
                // Direct fallback implementation
                console.log('Using direct fallback for tab switching');
                const loginForm = document.getElementById('loginForm');
                const registerForm = document.getElementById('registerForm');
                const allTabs = document.querySelectorAll('.form-tab');
                
                // Update tab active states
                allTabs.forEach(t => {
                    if (t.getAttribute('data-tab') === tabName) {
                        t.classList.add('active');
                    } else {
                        t.classList.remove('active');
                    }
                });
                
                // Show/hide forms
                if (tabName === 'login') {
                    if (loginForm) {
                        loginForm.classList.add('active-form');
                        loginForm.style.display = 'block';
                        console.log('Fallback - Showing login form');
                    }
                    if (registerForm) {
                        registerForm.classList.remove('active-form');
                        registerForm.style.display = 'none';
                        console.log('Fallback - Hiding register form');
                    }
                } else if (tabName === 'register') {
                    if (registerForm) {
                        registerForm.classList.add('active-form');
                        registerForm.style.display = 'block';
                        console.log('Fallback - Showing register form');
                    }
                    if (loginForm) {
                        loginForm.classList.remove('active-form');
                        loginForm.style.display = 'none';
                        console.log('Fallback - Hiding login form');
                    }
                }
            }
        });
    });
    
    // Ensure login form uses AJAX - Direct implementation in footer
    const loginFormFooter = document.getElementById('loginForm');
    if (loginFormFooter) {
        // Clone to remove existing listeners
        const newLoginForm = loginFormFooter.cloneNode(true);
        loginFormFooter.parentNode.replaceChild(newLoginForm, loginFormFooter);
        
        newLoginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            e.stopPropagation();
            console.log('Login form submitted via AJAX (footer script)');
            
            const email = document.getElementById('loginEmail');
            const password = document.getElementById('loginPassword');
            const remember = document.querySelector('#loginForm input[name="remember"]');
            
            if (!email || !password) {
                alert('Error: Campos no encontrados. Por favor, recarga la página.');
                return false;
            }
            
            const emailVal = email.value.trim();
            const passwordVal = password.value;
            const rememberChecked = remember ? remember.checked : false;
            
            if (!emailVal || !passwordVal) {
                alert('Por favor, completa todos los campos.');
                return false;
            }
            
            const submitBtn = newLoginForm.querySelector('.form-submit');
            const originalText = submitBtn ? submitBtn.textContent : 'Iniciar Sesión';
            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.textContent = 'Iniciando sesión...';
            }
            
            if (typeof nidfilAjax === 'undefined') {
                alert('Error: Sistema no disponible. Por favor, recarga la página.');
                if (submitBtn) {
                    submitBtn.disabled = false;
                    submitBtn.textContent = originalText;
                }
                return false;
            }
            
            fetch(nidfilAjax.ajaxurl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    action: 'nidfil_login',
                    email: emailVal,
                    password: passwordVal,
                    remember: rememberChecked ? '1' : '0',
                    nonce: nidfilAjax.nonce
                })
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                console.log('Login response:', data);
                if (data.success) {
                    if (submitBtn) {
                        submitBtn.textContent = '¡Éxito! Redirigiendo...';
                    }
                    
                    setTimeout(function() {
                        if (typeof closeClienteModal === 'function') {
                            closeClienteModal();
                        } else if (window.closeClienteModal) {
                            window.closeClienteModal();
                        }
                        
                        let redirectUrl = null;
                        if (data.data && data.data.redirect_url) {
                            redirectUrl = data.data.redirect_url;
                        } else if (nidfilAjax && nidfilAjax.dashboard_url) {
                            redirectUrl = nidfilAjax.dashboard_url;
                        } else {
                            redirectUrl = '/client-profile/';
                        }
                        
                        if (redirectUrl && !redirectUrl.startsWith('http')) {
                            redirectUrl = window.location.origin + (redirectUrl.startsWith('/') ? '' : '/') + redirectUrl;
                        }
                        
                        console.log('Login - Redirecting to:', redirectUrl);
                        if (redirectUrl) {
                            window.location.href = redirectUrl;
                        } else {
                            window.location.href = '/client-profile/';
                        }
                    }, 500);
                } else {
                    alert(data.data && data.data.message ? data.data.message : 'Error al iniciar sesión');
                    if (submitBtn) {
                        submitBtn.disabled = false;
                        submitBtn.textContent = originalText;
                    }
                }
            })
            .catch(error => {
                console.error('Login error:', error);
                alert('Error al iniciar sesión. Por favor, intenta de nuevo.');
                if (submitBtn) {
                    submitBtn.disabled = false;
                    submitBtn.textContent = originalText;
                }
            });
            
            return false;
        });
    }
    
    // Ensure registration form uses AJAX - Direct implementation in footer
    const registerFormFooter = document.getElementById('registerForm');
    if (registerFormFooter) {
        // Clone to remove existing listeners
        const newForm = registerFormFooter.cloneNode(true);
        registerFormFooter.parentNode.replaceChild(newForm, registerFormFooter);
        
        newForm.addEventListener('submit', function(e) {
            e.preventDefault();
            e.stopPropagation();
            console.log('Register form submitted via AJAX (footer script)');
            
            const name = document.getElementById('registerName');
            const email = document.getElementById('registerEmail');
            const phone = document.getElementById('registerPhone');
            const password = document.getElementById('registerPassword');
            const passwordConfirm = document.getElementById('registerPasswordConfirm');
            const terms = document.querySelector('#registerForm input[name="terms"]');
            
            if (!name || !email || !password || !passwordConfirm) {
                alert('Error: Campos no encontrados. Por favor, recarga la página.');
                return false;
            }
            
            const nameVal = name.value.trim();
            const emailVal = email.value.trim();
            const phoneVal = phone ? phone.value.trim() : '';
            const passwordVal = password.value;
            const passwordConfirmVal = passwordConfirm.value;
            const termsChecked = terms ? terms.checked : false;
            
            if (!nameVal || !emailVal || !passwordVal || !passwordConfirmVal) {
                alert('Por favor, completa todos los campos requeridos.');
                return false;
            }
            
            if (!termsChecked) {
                alert('Por favor, acepta los términos y condiciones para continuar.');
                return false;
            }
            
            if (passwordVal !== passwordConfirmVal) {
                alert('Las contraseñas no coinciden');
                return false;
            }
            
            if (passwordVal.length < 6) {
                alert('La contraseña debe tener al menos 6 caracteres.');
                return false;
            }
            
            const submitBtn = newForm.querySelector('.form-submit');
            const originalText = submitBtn ? submitBtn.textContent : 'Registrarse';
            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.textContent = 'Registrando...';
            }
            
            if (typeof nidfilAjax === 'undefined') {
                alert('Error: Sistema no disponible. Por favor, recarga la página.');
                if (submitBtn) {
                    submitBtn.disabled = false;
                    submitBtn.textContent = originalText;
                }
                return false;
            }
            
            fetch(nidfilAjax.ajaxurl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    action: 'nidfil_register',
                    name: nameVal,
                    email: emailVal,
                    phone: phoneVal,
                    password: passwordVal,
                    nonce: nidfilAjax.nonce
                })
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                console.log('Registration response:', data);
                if (data.success) {
                    if (submitBtn) {
                        submitBtn.textContent = '¡Éxito! Redirigiendo...';
                    }
                    
                    setTimeout(function() {
                        if (typeof closeClienteModal === 'function') {
                            closeClienteModal();
                        } else if (window.closeClienteModal) {
                            window.closeClienteModal();
                        }
                        
                        let redirectUrl = null;
                        if (data.data && data.data.redirect_url) {
                            redirectUrl = data.data.redirect_url;
                        } else if (nidfilAjax && nidfilAjax.dashboard_url) {
                            redirectUrl = nidfilAjax.dashboard_url;
                        } else {
                            redirectUrl = '/client-profile/';
                        }
                        
                        if (redirectUrl && !redirectUrl.startsWith('http')) {
                            redirectUrl = window.location.origin + (redirectUrl.startsWith('/') ? '' : '/') + redirectUrl;
                        }
                        
                        console.log('Redirecting to:', redirectUrl);
                        if (redirectUrl) {
                            window.location.href = redirectUrl;
                        } else {
                            window.location.href = '/client-profile/';
                        }
                    }, 500);
                } else {
                    alert(data.data && data.data.message ? data.data.message : 'Error al registrarse');
                    if (submitBtn) {
                        submitBtn.disabled = false;
                        submitBtn.textContent = originalText;
                    }
                }
            })
            .catch(error => {
                console.error('Registration error:', error);
                alert('Error al registrarse. Por favor, intenta de nuevo.');
                if (submitBtn) {
                    submitBtn.disabled = false;
                    submitBtn.textContent = originalText;
                }
            });
            
            return false;
        });
    }
});

// Specialist Modal Functions
function openEspecialistaModal() {
    const modal = document.getElementById('especialistaModal');
    if (modal) {
        modal.classList.add('modal-active');
        document.body.style.overflow = 'hidden';
        switchEspecialistaTab('login');
    }
}
window.openEspecialistaModal = openEspecialistaModal;

function closeEspecialistaModal() {
    const modal = document.getElementById('especialistaModal');
    if (modal) {
        modal.classList.remove('modal-active');
        document.body.style.overflow = '';
        const loginForm = document.getElementById('especialistaLoginForm');
        const registerForm = document.getElementById('especialistaRegisterForm');
        if (loginForm) loginForm.reset();
        if (registerForm) registerForm.reset();
        switchEspecialistaTab('login');
    }
}
window.closeEspecialistaModal = closeEspecialistaModal;

function switchEspecialistaTab(tabName) {
    const tabs = document.querySelectorAll('#especialistaModal .form-tab');
    const loginForm = document.getElementById('especialistaLoginForm');
    const registerForm = document.getElementById('especialistaRegisterForm');
    
    tabs.forEach(tab => {
        if (tab.getAttribute('data-tab') === tabName) {
            tab.classList.add('active');
        } else {
            tab.classList.remove('active');
        }
    });
    
    if (tabName === 'login') {
        if (loginForm) {
            loginForm.classList.add('active-form');
            loginForm.style.display = 'block';
        }
        if (registerForm) {
            registerForm.classList.remove('active-form');
            registerForm.style.display = 'none';
        }
    } else if (tabName === 'register') {
        if (registerForm) {
            registerForm.classList.add('active-form');
            registerForm.style.display = 'block';
        }
        if (loginForm) {
            loginForm.classList.remove('active-form');
            loginForm.style.display = 'none';
        }
    }
}
window.switchEspecialistaTab = switchEspecialistaTab;

// Specialist Login Form Handler
const especialistaLoginForm = document.getElementById('especialistaLoginForm');
if (especialistaLoginForm) {
    const newForm = especialistaLoginForm.cloneNode(true);
    especialistaLoginForm.parentNode.replaceChild(newForm, especialistaLoginForm);
    
    newForm.addEventListener('submit', function(e) {
        e.preventDefault();
        e.stopPropagation();
        
        const email = document.getElementById('especialistaLoginEmail').value;
        const password = document.getElementById('especialistaLoginPassword').value;
        const remember = document.querySelector('#especialistaLoginForm input[name="remember"]').checked;
        
        if (!email || !password) {
            alert('Por favor, completa todos los campos.');
            return;
        }
        
        const submitBtn = newForm.querySelector('.form-submit');
        const originalText = submitBtn.textContent;
        submitBtn.disabled = true;
        submitBtn.textContent = 'Iniciando sesión...';
        
        fetch(nidfilAjax.ajaxurl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({
                action: 'nidfil_login_specialist',
                email: email,
                password: password,
                remember: remember ? '1' : '0',
                nonce: nidfilAjax.nonce
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                submitBtn.textContent = '¡Éxito! Redirigiendo...';
                setTimeout(function() {
                    closeEspecialistaModal();
                    let redirectUrl = '/specialist-profile/';
                    if (data.data && data.data.redirect_url) {
                        redirectUrl = data.data.redirect_url;
                    }
                    if (!redirectUrl.startsWith('http')) {
                        redirectUrl = window.location.origin + (redirectUrl.startsWith('/') ? '' : '/') + redirectUrl;
                    }
                    window.location.href = redirectUrl;
                }, 500);
            } else {
                const errorMsg = data.data && data.data.message ? data.data.message : 'Error al iniciar sesión';
                alert(errorMsg);
                submitBtn.disabled = false;
                submitBtn.textContent = originalText;
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error al iniciar sesión. Por favor, intenta de nuevo.');
            submitBtn.disabled = false;
            submitBtn.textContent = originalText;
        });
    });
}

// Specialist Registration Form Handler
const especialistaRegisterForm = document.getElementById('especialistaRegisterForm');
if (especialistaRegisterForm) {
    const newForm = especialistaRegisterForm.cloneNode(true);
    especialistaRegisterForm.parentNode.replaceChild(newForm, especialistaRegisterForm);
    
    newForm.addEventListener('submit', function(e) {
        e.preventDefault();
        e.stopPropagation();
        
        const name = document.getElementById('especialistaRegisterName').value.trim();
        const email = document.getElementById('especialistaRegisterEmail').value.trim();
        const phone = document.getElementById('especialistaRegisterPhone').value.trim();
        const profession = document.getElementById('especialistaRegisterProfession').value.trim();
        const experience = document.getElementById('especialistaRegisterExperience').value;
        const password = document.getElementById('especialistaRegisterPassword').value;
        const passwordConfirm = document.getElementById('especialistaRegisterPasswordConfirm').value;
        const terms = document.querySelector('#especialistaRegisterForm input[name="terms"]').checked;
        
        if (!name || !email || !phone || !profession || !experience || !password || !passwordConfirm) {
            alert('Por favor, completa todos los campos.');
            return;
        }
        
        if (password !== passwordConfirm) {
            alert('Las contraseñas no coinciden.');
            return;
        }
        
        if (!terms) {
            alert('Debes aceptar los términos y condiciones.');
            return;
        }
        
        const submitBtn = newForm.querySelector('.form-submit');
        const originalText = submitBtn.textContent;
        submitBtn.disabled = true;
        submitBtn.textContent = 'Registrando...';
        
        if (typeof nidfilAjax === 'undefined' || !nidfilAjax.ajaxurl || !nidfilAjax.nonce) {
            console.error('nidfilAjax is not defined or missing properties.');
            alert('Error de configuración. Por favor, recarga la página.');
            submitBtn.disabled = false;
            submitBtn.textContent = originalText;
            return;
        }
        
        fetch(nidfilAjax.ajaxurl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({
                action: 'nidfil_register_specialist',
                name: name,
                email: email,
                phone: phone,
                profession: profession,
                experience: experience,
                password: password,
                password_confirm: passwordConfirm,
                terms: terms ? '1' : '0',
                nonce: nidfilAjax.nonce
            })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            console.log('Registration response:', data);
            if (data && data.success) {
                submitBtn.textContent = '¡Éxito! Redirigiendo...';
                setTimeout(function() {
                    if (typeof closeEspecialistaModal === 'function') {
                        closeEspecialistaModal();
                    } else if (window.closeEspecialistaModal) {
                        window.closeEspecialistaModal();
                    }
                    
                    let redirectUrl = null;
                    
                    // Priority 1: Use redirect_url from response
                    if (data.data && data.data.redirect_url) {
                        redirectUrl = data.data.redirect_url;
                    }
                    // Priority 2: Use specialist_dashboard_url from localized script
                    else if (nidfilAjax && nidfilAjax.specialist_dashboard_url) {
                        redirectUrl = nidfilAjax.specialist_dashboard_url;
                    }
                    // Priority 3: Fallback to relative URL
                    else {
                        redirectUrl = '/specialist-profile/';
                    }
                    
                    // Ensure URL is absolute
                    if (redirectUrl && !redirectUrl.startsWith('http') && !redirectUrl.startsWith('//')) {
                        redirectUrl = window.location.origin + (redirectUrl.startsWith('/') ? '' : '/') + redirectUrl;
                    }
                    
                    console.log('Registration successful. Redirecting to:', redirectUrl);
                    
                    if (redirectUrl) {
                        window.location.href = redirectUrl;
                    } else {
                        console.error('No redirect URL available');
                        alert('Error: URL de redirección no encontrada. Redirigiendo a la página principal...');
                        window.location.href = window.location.origin;
                    }
                }, 500);
            } else {
                const errorMsg = data && data.data && data.data.message ? data.data.message : 'Error al registrarse';
                console.error('Registration error:', errorMsg);
                alert(errorMsg);
                submitBtn.disabled = false;
                submitBtn.textContent = originalText;
            }
        })
        .catch(error => {
            console.error('Registration fetch error:', error);
            alert('Error al registrarse. Por favor, intenta de nuevo.');
            submitBtn.disabled = false;
            submitBtn.textContent = originalText;
        });
    });
}
</script>

<?php wp_footer(); ?>
</body>
</html>

