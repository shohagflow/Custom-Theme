<?php
/**
 * The template for displaying tag archive pages
 *
 * @package Cambridge_Independent
 */

get_header();
?>

<main id="main" class="site-main">
    <div class="ci-container">
        <div class="content-area">
            <div class="primary-content">
                <header class="page-header">
                    <?php
                    // Display tag name and description
                    $tag = get_queried_object();
                    if ( $tag ) {
                        echo '<div class="archive-description">';
                        echo '<h1 class="archive-title">' . esc_html( $tag->name ) . '</h1>';
                        if ( ! empty( $tag->description ) ) {
                            echo '<p>' . esc_html( $tag->description ) . '</p>';
                        }
                        echo '</div>';
                    }
                    ?>
                </header>

                <?php
                if ( have_posts() ) :
                    while ( have_posts() ) :
                        the_post();
                        get_template_part( 'template-parts/content/content' );
                    endwhile;

                    // Pagination
                    the_posts_pagination( array(
                        'mid_size'  => 2,
                        'prev_text' => __( 'Previous', 'cambridge-independent' ),
                        'next_text' => __( 'Next', 'cambridge-independent' ),
                    ) );

                else :
                    get_template_part( 'template-parts/content/content-none' );
                endif;
                ?>
            </div>

            <?php get_sidebar(); ?>
        </div>
    </div>
</main>

<?php
get_footer();

