<?php
/**
 * Template Name: Events Page
 * 
 * Custom page template for displaying event archive
 *
 * @package Cambridge_Independent
 */

get_header();
?>

<main id="main" class="site-main">
    <div class="ci-container">
        <div class="content-area">
            <div class="primary-content">
                <?php
                // Display page content if any
                while ( have_posts() ) :
                    the_post();
                    if ( get_the_content() ) :
                        ?>
                        <article id="post-<?php the_ID(); ?>" <?php post_class( 'post' ); ?>>
                            <div class="post-content">
                                <?php the_content(); ?>
                            </div>
                        </article>
                        <?php
                    endif;
                endwhile;
                wp_reset_postdata();
                
                // Query for upcoming events using The Events Calendar functions
                // Check if The Events Calendar is active
                if ( function_exists( 'tribe_get_events' ) ) {
                    $events = tribe_get_events( array(
                        'posts_per_page' => 10,
                        'start_date'     => 'now',
                        'orderby'         => 'event_date',
                        'order'           => 'ASC',
                    ) );
                    
                    if ( ! empty( $events ) ) :
                        foreach ( $events as $event_post ) :
                            setup_postdata( $event_post );
                            get_template_part( 'template-parts/content/content-event-archive' );
                        endforeach;
                        wp_reset_postdata();
                        
                        // Simple pagination link to full archive
                        ?>
                        <div class="events-pagination">
                            <a href="<?php echo esc_url( tribe_get_events_link() ); ?>" class="read-more">View All Events</a>
                        </div>
                        <?php
                    else :
                        ?>
                        <article class="post">
                            <div class="post-content">
                                <p><?php esc_html_e( 'No upcoming events found.', 'cambridge-independent' ); ?></p>
                            </div>
                        </article>
                        <?php
                    endif;
                } else {
                    // Fallback if The Events Calendar is not active
                    $events_query = new WP_Query( array(
                        'post_type'      => 'tribe_events',
                        'posts_per_page' => 10,
                        'orderby'        => 'meta_value',
                        'meta_key'       => '_EventStartDate',
                        'order'          => 'ASC',
                        'meta_query'     => array(
                            array(
                                'key'     => '_EventStartDate',
                                'value'   => date( 'Y-m-d H:i:s' ),
                                'compare' => '>=',
                            ),
                        ),
                    ) );
                    
                    if ( $events_query->have_posts() ) :
                        while ( $events_query->have_posts() ) :
                            $events_query->the_post();
                            get_template_part( 'template-parts/content/content-event-archive' );
                        endwhile;
                        
                        // Pagination
                        the_posts_pagination( array(
                            'mid_size'  => 2,
                            'prev_text' => __( 'Previous', 'cambridge-independent' ),
                            'next_text' => __( 'Next', 'cambridge-independent' ),
                        ) );
                        
                        wp_reset_postdata();
                    else :
                        ?>
                        <article class="post">
                            <div class="post-content">
                                <p><?php esc_html_e( 'No upcoming events found.', 'cambridge-independent' ); ?></p>
                            </div>
                        </article>
                        <?php
                    endif;
                }
                
                if ( $events_query->have_posts() ) :
                    while ( $events_query->have_posts() ) :
                        $events_query->the_post();
                        get_template_part( 'template-parts/content/content-event-archive' );
                    endwhile;
                    
                    // Pagination
                    the_posts_pagination( array(
                        'mid_size'  => 2,
                        'prev_text' => __( 'Previous', 'cambridge-independent' ),
                        'next_text' => __( 'Next', 'cambridge-independent' ),
                    ) );
                    
                    wp_reset_postdata();
                else :
                    ?>
                    <article class="post">
                        <div class="post-content">
                            <p><?php esc_html_e( 'No upcoming events found.', 'cambridge-independent' ); ?></p>
                        </div>
                    </article>
                    <?php
                endif;
                ?>
            </div>

            <?php get_sidebar(); ?>
        </div>
    </div>
</main>

<?php
get_footer();

