<?php
/**
 * Template Name: Front Page
 *
 * @package Cambridge_Independent
 */

get_header();
?>

<main id="main" class="site-main">
    <div class="ci-container">
        <!-- Top Row: Hero Section + ADVERTISEMENTS -->
        <div class="homepage-top-row">
            <div class="hero-section-wrapper">
                <?php get_template_part( 'template-parts/hero/hero-feature' ); ?>
            </div>
            
            <!-- Right Sidebar with Advertisements -->
            <aside class="homepage-ads-sidebar">
                <?php get_sidebar(); ?>
            </aside>
        </div>

    </div>
</main>

<?php
get_footer();

