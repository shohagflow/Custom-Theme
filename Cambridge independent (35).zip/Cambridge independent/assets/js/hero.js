/**
 * Hero Feature Navigation
 */
(function () {
    'use strict';

    const heroSection = document.querySelector('.hero-feature');
    if (!heroSection) return;

    const heroPrev = heroSection.querySelector('.hero-prev');
    const heroNext = heroSection.querySelector('.hero-next');
    const heroCta = heroSection.querySelector('.hero-cta');
    let currentPostIndex = 0;
    let heroPosts = [];
    let originalEventsUrl = '';

    // Store original events URL from data attribute
    if (heroCta) {
        originalEventsUrl = heroCta.getAttribute('data-events-url') || heroCta.href;
    }

    // Get posts data from data attribute
    try {
        const postsData = heroSection.getAttribute('data-posts');
        if (postsData) {
            heroPosts = JSON.parse(postsData);
        }
    } catch (e) {
        console.error('Error parsing hero posts data:', e);
        return;
    }

    function updateHeroControls() {
        if (heroPrev) {
            heroPrev.disabled = currentPostIndex === 0;
        }
        if (heroNext) {
            heroNext.disabled = currentPostIndex >= heroPosts.length - 1;
        }
    }

    function loadHeroPost(index) {
        if (index < 0 || index >= heroPosts.length) return;

        const post = heroPosts[index];
        currentPostIndex = index;

        // Update hero content
        const heroTitle = heroSection.querySelector('.hero-title a');
        const heroExcerpt = heroSection.querySelector('.hero-excerpt');
        const heroMedia = heroSection.querySelector('.hero-media');

        if (heroTitle) {
            heroTitle.textContent = post.title;
            heroTitle.href = post.permalink;
        }

        if (heroExcerpt) {
            heroExcerpt.textContent = post.excerpt;
        }

        if (heroMedia) {
            if (post.thumbnail) {
                heroMedia.innerHTML = '<img src="' + post.thumbnail + '" alt="' + post.title + '" class="hero-image" />';
            } else {
                heroMedia.innerHTML = '<div class="hero-image-placeholder"></div>';
            }
        }

        // Keep CTA button pointing to events page (don't change it)
        if (heroCta && originalEventsUrl) {
            heroCta.href = originalEventsUrl;
        }

        updateHeroControls();
    }

    if (heroPrev) {
        heroPrev.addEventListener('click', function () {
            if (currentPostIndex > 0) {
                loadHeroPost(currentPostIndex - 1);
            }
        });
    }

    if (heroNext) {
        heroNext.addEventListener('click', function () {
            if (currentPostIndex < heroPosts.length - 1) {
                loadHeroPost(currentPostIndex + 1);
            }
        });
    }

    // Initialize controls
    updateHeroControls();
})();

