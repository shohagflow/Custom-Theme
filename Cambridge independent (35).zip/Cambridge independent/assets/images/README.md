# Logo Image Directory

## Adding the Logo

Place your "INDEPENDENT" logo image in this directory with the filename:

**`independent-logo.png`**

The theme will automatically detect and use this logo if:
1. No WordPress custom logo is set (via Appearance > Customize > Site Identity)
2. No logo is set in the theme settings (Independent > Header Settings)

## Supported Formats

- PNG (recommended for transparency)
- JPG/JPEG
- SVG
- WebP

## Recommended Dimensions

- Width: 400px or larger
- Height: Auto (maintains aspect ratio)
- Format: PNG with transparent background (if needed)

## Alternative Methods

You can also set the logo via:
1. **WordPress Customizer**: Appearance > Customize > Site Identity > Logo
2. **Theme Settings**: Independent > Header Settings > Logo Image


