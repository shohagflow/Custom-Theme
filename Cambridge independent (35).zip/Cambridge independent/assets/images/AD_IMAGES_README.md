# Advertisement Images

Place the following image files in this directory (`assets/images/`):

## Required Image Files:

1. **eugenia-schraa-huh.jpg** - Eugenia Schraa Huh for Cambridge School Committee
2. **jivan-sobrinho-wheeler.jpg** - Jivan Sobrinho-Wheeler for Cambridge City Council
3. **jess-goetz.jpg** - Jess Goetz for School Committee
4. **avantor-hiring.jpg** - Avantor - Now Hiring Across Massachusetts
5. **zion-sherin.jpg** - Zion Sherin for Cambridge City Council

## Supported Formats:
- JPG/JPEG (recommended)
- PNG
- WebP

## Recommended Dimensions:
- Width: 300px (matches sidebar width)
- Height: Auto (maintains aspect ratio)
- Format: JPG or PNG

## Notes:
- Images will only display if the files exist in this directory
- Ads will automatically hide if image files are missing
- Update the links in `template-parts/sidebar/advertisements.php` to add actual URLs

