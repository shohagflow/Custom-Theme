<?php
/**
 * The header template file
 *
 * @package Cambridge_Independent
 */

get_template_part( 'template-parts/header/header' );
