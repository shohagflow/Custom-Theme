# Cambridge Independent WordPress Theme

A modern, responsive WordPress theme for Cambridge Independent with organized folder structure.

## Theme Structure

```
Cambridge independent/
├── assets/
│   ├── css/
│   │   └── main.css          # Additional CSS styles
│   └── js/
│       └── navigation.js     # Navigation JavaScript
├── inc/
│   ├── theme-setup.php       # Theme setup and configuration
│   ├── enqueue.php           # Script and style enqueues
│   ├── widgets.php           # Widget area registration
│   └── template-functions.php # Template helper functions
├── template-parts/
│   ├── header/
│   │   └── header.php        # Header template
│   ├── footer/
│   │   └── footer.php        # Footer template
│   ├── sidebar/
│   │   └── sidebar.php       # Sidebar template
│   ├── content/
│   │   ├── content.php       # Post content template
│   │   ├── content-single.php # Single post content
│   │   ├── content-page.php  # Page content template
│   │   └── content-none.php  # No content found template
│   ├── comments/
│   │   └── comments.php      # Comments template
│   └── search/
│       └── searchform.php    # Search form template
├── style.css                 # Main stylesheet (required)
├── index.php                 # Main template file (required)
├── functions.php             # Main functions file (loads inc files)
├── header.php                # Header loader
├── footer.php                # Footer loader
├── sidebar.php               # Sidebar loader
├── single.php                # Single post template
├── page.php                  # Page template
├── archive.php               # Archive template
├── search.php                # Search results template
├── 404.php                   # 404 error template
├── comments.php              # Comments loader
└── searchform.php            # Search form loader
```

## Features

- **Organized Folder Structure**: Clean separation of concerns
- **Responsive Design**: Mobile-first approach
- **Custom Navigation Menus**: Primary and Footer menus
- **Widget Areas**: Sidebar and Footer widget areas
- **Post Thumbnails**: Featured image support
- **HTML5 Markup**: Modern semantic HTML
- **Translation Ready**: Prepared for internationalization
- **Template Parts**: Reusable template components

## Installation

1. Upload the theme folder to `/wp-content/themes/`
2. Activate the theme through the 'Appearance' menu in WordPress
3. Customize the theme through 'Appearance > Customize'

## Folder Organization

### `/inc/` - Includes
Contains all PHP includes organized by functionality:
- `theme-setup.php` - Theme support, menus, content width
- `enqueue.php` - Script and style enqueues
- `widgets.php` - Widget area registration
- `template-functions.php` - Helper functions

### `/template-parts/` - Template Parts
Reusable template components organized by type:
- `header/` - Header templates
- `footer/` - Footer templates
- `sidebar/` - Sidebar templates
- `content/` - Content templates (post, page, single, none)
- `comments/` - Comment templates
- `search/` - Search form templates

### `/assets/` - Assets
Static assets organized by type:
- `css/` - Stylesheets
- `js/` - JavaScript files
- `images/` - Image files (add as needed)

## Customization

The theme supports:
- Custom menus (Primary and Footer)
- Widget areas (Sidebar and Footer)
- Featured images
- Custom logo (can be added via `inc/theme-setup.php`)

## Development

To add new functionality:
1. Add theme setup code to `inc/theme-setup.php`
2. Add enqueue code to `inc/enqueue.php`
3. Add widget areas to `inc/widgets.php`
4. Add helper functions to `inc/template-functions.php`
5. Create new template parts in `template-parts/` as needed

## License

This theme is licensed under the GPL v2 or later.
