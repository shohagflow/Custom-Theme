<?php
/**
 * Enqueue Scripts and Styles
 *
 * @package Cambridge_Independent
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Add preconnect links for Google Fonts and Font Awesome CDN (performance optimization)
 */
function cambridge_independent_fonts_preconnect() {
    echo '<link rel="preconnect" href="https://fonts.googleapis.com">' . "\n";
    echo '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>' . "\n";
    // Preconnect for Font Awesome CDN (jsDelivr) and font files
    if ( ! is_admin() ) {
        echo '<link rel="preconnect" href="https://cdn.jsdelivr.net" crossorigin>' . "\n";
        echo '<link rel="dns-prefetch" href="https://cdn.jsdelivr.net">' . "\n";
        // Preload Font Awesome font files for faster loading
        echo '<link rel="preload" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.5.1/webfonts/fa-solid-900.woff2" as="font" type="font/woff2" crossorigin="anonymous">' . "\n";
        echo '<link rel="preload" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.5.1/webfonts/fa-regular-400.woff2" as="font" type="font/woff2" crossorigin="anonymous">' . "\n";
        echo '<link rel="preload" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.5.1/webfonts/fa-brands-400.woff2" as="font" type="font/woff2" crossorigin="anonymous">' . "\n";
    }
}
add_action( 'wp_head', 'cambridge_independent_fonts_preconnect', 1 );

/**
 * Load Font Awesome directly in head (for icons - must load early)
 * This ensures Font Awesome is available for WPAdverts and other plugins on frontend
 */
function cambridge_independent_load_font_awesome() {
    // Only load on frontend (not in admin)
    if ( ! is_admin() ) {
        // Try multiple CDN sources for maximum reliability
        // Primary: jsDelivr (often more reliable than cdnjs)
        echo '<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.5.1/css/all.min.css" crossorigin="anonymous" />' . "\n";
    }
}
add_action( 'wp_head', 'cambridge_independent_load_font_awesome', 2 );

/**
 * Enqueue scripts and styles
 */
function cambridge_independent_scripts() {
    // Also enqueue Font Awesome via wp_enqueue_style as backup (in case wp_head doesn't work)
    // Font Awesome is also loaded via wp_head action (priority 2) for early loading
    // Using jsDelivr CDN (same as wp_head) for consistency
    wp_enqueue_style( 
        'font-awesome', 
        'https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.5.1/css/all.min.css', 
        array(), 
        '6.5.1',
        'all' // Media type
    );

    // Enqueue Google Fonts: Newsreader (400, 600) and Fira Sans (Light 300, Regular 400, Heavy 800/900)
    // Using the exact Google Fonts URL for Newsreader: https://fonts.google.com/specimen/Newsreader
    wp_enqueue_style( 
        'cambridge-independent-fonts', 
        'https://fonts.googleapis.com/css2?family=Newsreader:ital,wght@0,400;0,600;1,400;1,600&family=Fira+Sans:wght@300;400;500;600;700;800;900&display=swap', 
        array(), 
        null // Remove version to ensure fresh load
    );

    // Enqueue theme stylesheet - Use file modification time for automatic cache busting
    $style_version = file_exists( get_stylesheet_directory() . '/style.css' ) 
        ? filemtime( get_stylesheet_directory() . '/style.css' ) 
        : '1.0.5';
    wp_enqueue_style( 'cambridge-independent-style', get_stylesheet_uri(), array( 'cambridge-independent-fonts' ), $style_version );

    // Enqueue additional CSS if exists
    if ( file_exists( get_template_directory() . '/assets/css/main.css' ) ) {
        wp_enqueue_style( 'cambridge-independent-main', get_template_directory_uri() . '/assets/css/main.css', array( 'cambridge-independent-style' ), '1.0.0' );
    }

    // Enqueue navigation script
    wp_enqueue_script( 'cambridge-independent-navigation', get_template_directory_uri() . '/assets/js/navigation.js', array(), '1.0.0', true );
	wp_enqueue_script( 'cambridge-independent-timeline', get_template_directory_uri() . '/assets/js/timeline.js', array(), '1.0.0', true );
	
	// Enqueue city preference script
	wp_enqueue_script( 'cambridge-independent-city-preference', get_template_directory_uri() . '/assets/js/city-preference.js', array(), '1.0.1', true );
	wp_localize_script( 'cambridge-independent-city-preference', 'ciCityPreference', array(
		'ajaxUrl' => admin_url( 'admin-ajax.php' ),
		'nonce' => wp_create_nonce( 'ci_city_preference_nonce' ),
	) );
	
	// Enqueue sidebar ads gap script (force gap between ads)
	wp_enqueue_script( 'cambridge-independent-sidebar-ads-gap', get_template_directory_uri() . '/assets/js/sidebar-ads-gap.js', array(), '1.0.0', true );

    // Enqueue hero script on homepage
    if ( is_home() || is_front_page() ) {
        wp_enqueue_script( 'cambridge-independent-hero', get_template_directory_uri() . '/assets/js/hero.js', array(), '1.0.0', true );
    }

    // Enqueue timeline script on single post pages
    if ( is_single() ) {
        wp_enqueue_script( 'cambridge-independent-timeline', get_template_directory_uri() . '/assets/js/timeline.js', array(), '1.0.0', true );
    }

    // Enqueue script to remove inline styles from event images
    if ( is_singular( 'tribe_events' ) ) {
        wp_enqueue_script( 'jquery' );
        wp_add_inline_script( 'jquery', '
            jQuery(document).ready(function($) {
                $(".single-tribe_events .post-thumbnail img, .single-tribe_events .event-featured-image").each(function() {
                    $(this).removeAttr("style");
                    $(this).removeAttr("width");
                    $(this).removeAttr("height");
                    $(this).css({
                        "width": "100%",
                        "max-width": "100%",
                        "height": "auto"
                    });
                });
            });
        ' );
    }

    // Enqueue comment reply script
    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
        wp_enqueue_script( 'comment-reply' );
    }

    // Add inline script to verify Font Awesome is loaded
    if ( ! is_admin() ) {
        wp_add_inline_script( 'jquery', '
        jQuery(document).ready(function($) {
            // Check if Font Awesome is loaded
            if (typeof window.FontAwesome === "undefined" && !document.querySelector("link[href*=\"fontawesome\"]")) {
                console.error("Font Awesome CSS not loaded!");
                // Try to load as fallback
                var link = document.createElement("link");
                link.rel = "stylesheet";
                link.href = "https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.5.1/css/all.min.css";
                link.crossOrigin = "anonymous";
                document.head.appendChild(link);
            } else {
                console.log("Font Awesome CSS loaded successfully");
            }
        });
        ', 'after' );
    }
}
add_action( 'wp_enqueue_scripts', 'cambridge_independent_scripts', 999 );

