<?php
/**
 * Theme Settings Page
 *
 * @package Cambridge_Independent
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

// Verify the file is loaded (for debugging - remove in production)
if ( ! function_exists( 'cambridge_independent_add_settings_page' ) ) {
    // File is loaded correctly
}

/**
 * Add theme settings menu as main sidebar item
 */
function cambridge_independent_add_settings_page() {
    // Main menu
    add_menu_page(
        __( 'Theme Settings', 'cambridge-independent' ),
        __( 'Independent', 'cambridge-independent' ),
        'manage_options',
        'cambridge-independent-settings',
        'cambridge_independent_settings_page',
        'dashicons-media-document',
        30
    );
    
    // Header Settings submenu
    add_submenu_page(
        'cambridge-independent-settings',
        __( 'Header Settings', 'cambridge-independent' ),
        __( 'Header Settings', 'cambridge-independent' ),
        'manage_options',
        'cambridge-independent-header',
        'cambridge_independent_header_settings_page'
    );
    
    // Footer Settings submenu
    add_submenu_page(
        'cambridge-independent-settings',
        __( 'Footer Settings', 'cambridge-independent' ),
        __( 'Footer Settings', 'cambridge-independent' ),
        'manage_options',
        'cambridge-independent-footer',
        'cambridge_independent_footer_settings_page'
    );
    
    // Generate Dummy Posts submenu
    add_submenu_page(
        'cambridge-independent-settings',
        __( 'Generate Dummy Posts', 'cambridge-independent' ),
        __( 'Generate Posts', 'cambridge-independent' ),
        'manage_options',
        'cambridge-independent-generate-posts',
        'cambridge_independent_generate_posts_page'
    );
    
    // Category Settings submenu
    add_submenu_page(
        'cambridge-independent-settings',
        __( 'Category Settings', 'cambridge-independent' ),
        __( 'Category Settings', 'cambridge-independent' ),
        'manage_options',
        'cambridge-independent-categories',
        'cambridge_independent_category_settings_page'
    );
    
    // Givers Settings submenu
    add_submenu_page(
        'cambridge-independent-settings',
        __( 'Givers Settings', 'cambridge-independent' ),
        __( 'Givers Settings', 'cambridge-independent' ),
        'manage_options',
        'cambridge-independent-givers',
        'cambridge_independent_givers_settings_page'
    );
    
    // Shortcode Guide submenu
    add_submenu_page(
        'cambridge-independent-settings',
        __( 'Shortcode Guide', 'cambridge-independent' ),
        __( 'Shortcode Guide', 'cambridge-independent' ),
        'manage_options',
        'cambridge-independent-shortcodes',
        'cambridge_independent_shortcode_guide_page'
    );
}
add_action( 'admin_menu', 'cambridge_independent_add_settings_page', 10 );

/**
 * Register settings
 */
function cambridge_independent_register_settings() {
    // General Settings
    register_setting( 'ci_general_settings', 'ci_location_text', 'sanitize_text_field' );
    register_setting( 'ci_general_settings', 'ci_site_logo_text', 'sanitize_text_field' );
    
    // Social Media Settings
    register_setting( 'ci_social_settings', 'ci_facebook_url', 'esc_url_raw' );
    register_setting( 'ci_social_settings', 'ci_twitter_url', 'esc_url_raw' );
    register_setting( 'ci_social_settings', 'ci_instagram_url', 'esc_url_raw' );
    register_setting( 'ci_social_settings', 'ci_linkedin_url', 'esc_url_raw' );
    register_setting( 'ci_social_settings', 'ci_youtube_url', 'esc_url_raw' );
    
    // Footer Settings
    register_setting( 'ci_footer_settings', 'ci_footer_text', 'wp_kses_post' );
    register_setting( 'ci_footer_settings', 'ci_copyright_text', 'sanitize_text_field' );
    
    // Classifieds Settings
    register_setting( 'ci_footer_settings', 'ci_classified_job', 'sanitize_text_field' );
    register_setting( 'ci_footer_settings', 'ci_classified_place', 'sanitize_text_field' );
    register_setting( 'ci_footer_settings', 'ci_classified_hey', 'sanitize_text_field' );
    register_setting( 'ci_footer_settings', 'ci_classified_see_all_url', 'esc_url_raw' );
    register_setting( 'ci_footer_settings', 'ci_classified_buy_url', 'esc_url_raw' );
    register_setting( 'ci_footer_settings', 'ci_classified_donate_url', 'esc_url_raw' );
    
    // Social Media Settings (also register for footer page)
    register_setting( 'ci_footer_settings', 'ci_facebook_url', 'esc_url_raw' );
    register_setting( 'ci_footer_settings', 'ci_twitter_url', 'esc_url_raw' );
    register_setting( 'ci_footer_settings', 'ci_instagram_url', 'esc_url_raw' );
    register_setting( 'ci_footer_settings', 'ci_linkedin_url', 'esc_url_raw' );
    register_setting( 'ci_footer_settings', 'ci_youtube_url', 'esc_url_raw' );
    
    // Custom CSS
    register_setting( 'ci_custom_settings', 'ci_custom_css', 'wp_strip_all_tags' );
    
    // Category Settings
    register_setting( 'ci_category_settings', 'ci_news_business_categories', array(
        'sanitize_callback' => 'cambridge_independent_sanitize_category_array',
    ) );
    register_setting( 'ci_category_settings', 'ci_arts_culture_categories', array(
        'sanitize_callback' => 'cambridge_independent_sanitize_category_array',
    ) );
    register_setting( 'ci_category_settings', 'ci_homepage_posts_per_column', array(
        'sanitize_callback' => 'absint',
    ) );
    register_setting( 'ci_category_settings', 'ci_hero_posts_count', array(
        'sanitize_callback' => 'absint',
    ) );
    register_setting( 'ci_category_settings', 'ci_hero_posts_unlimited', array(
        'sanitize_callback' => 'absint',
    ) );
    
    // Header Settings
    register_setting( 'ci_header_settings', 'ci_logo_image', 'esc_url_raw' );
    register_setting( 'ci_header_settings', 'ci_logo_width', 'sanitize_text_field' );
    register_setting( 'ci_header_settings', 'ci_logo_height', 'sanitize_text_field' );
    
    // Top Bar Settings
    register_setting( 'ci_header_settings', 'ci_topbar_text', 'sanitize_text_field' );
    register_setting( 'ci_header_settings', 'ci_topbar_font_size', 'sanitize_text_field' );
    register_setting( 'ci_header_settings', 'ci_topbar_font_color', 'sanitize_hex_color' );
    register_setting( 'ci_header_settings', 'ci_topbar_font_weight', 'sanitize_text_field' );
    register_setting( 'ci_header_settings', 'ci_topbar_line_height', 'sanitize_text_field' );
    register_setting( 'ci_header_settings', 'ci_topbar_letter_spacing', 'sanitize_text_field' );
    register_setting( 'ci_header_settings', 'ci_topbar_bg_color', 'sanitize_hex_color' );
    
    // Logo Text Settings
    register_setting( 'ci_header_settings', 'ci_logo_font_size', 'sanitize_text_field' );
    register_setting( 'ci_header_settings', 'ci_logo_font_color', 'sanitize_hex_color' );
    register_setting( 'ci_header_settings', 'ci_logo_font_weight', 'sanitize_text_field' );
    register_setting( 'ci_header_settings', 'ci_logo_line_height', 'sanitize_text_field' );
    register_setting( 'ci_header_settings', 'ci_logo_letter_spacing', 'sanitize_text_field' );
    
    // Hamburger Menu Settings
    register_setting( 'ci_header_settings', 'ci_hamburger_menu_items', array(
        'sanitize_callback' => 'cambridge_independent_sanitize_menu_items',
    ) );
    
    // Givers Settings
    register_setting( 'ci_givers_settings', 'ci_public_givers_list', 'wp_kses_post' );
}
add_action( 'admin_init', 'cambridge_independent_register_settings' );

/**
 * Sanitize category array
 */
function cambridge_independent_sanitize_category_array( $input ) {
    if ( ! is_array( $input ) ) {
        return array();
    }
    
    $sanitized = array();
    foreach ( $input as $category_id ) {
        $category_id = absint( $category_id );
        if ( $category_id > 0 ) {
            $sanitized[] = $category_id;
        }
    }
    
    return $sanitized;
}

/**
 * Sanitize hamburger menu items
 */
function cambridge_independent_sanitize_menu_items( $input ) {
    if ( ! is_array( $input ) ) {
        return array();
    }
    
    $sanitized = array();
    foreach ( $input as $item ) {
        if ( isset( $item['type'] ) && $item['type'] === 'separator' ) {
            $sanitized[] = array( 'type' => 'separator' );
        } elseif ( isset( $item['type'] ) && $item['type'] === 'link' ) {
            $sanitized[] = array(
                'type' => 'link',
                'label' => isset( $item['label'] ) ? sanitize_text_field( $item['label'] ) : '',
                'url' => isset( $item['url'] ) ? esc_url_raw( $item['url'] ) : '',
                'highlight' => isset( $item['highlight'] ) ? (bool) $item['highlight'] : false,
                'bold_parts' => isset( $item['bold_parts'] ) ? sanitize_text_field( $item['bold_parts'] ) : '',
            );
        }
    }
    
    return $sanitized;
}

/**
 * Settings page HTML
 */
function cambridge_independent_settings_page() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }
    
    // Handle tab navigation
    $active_tab = isset( $_GET['tab'] ) ? sanitize_text_field( $_GET['tab'] ) : 'general';
    ?>
    <div class="wrap">
        <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
        
        <nav class="nav-tab-wrapper">
            <a href="?page=cambridge-independent-settings&tab=general" class="nav-tab <?php echo $active_tab === 'general' ? 'nav-tab-active' : ''; ?>">
                <?php _e( 'General', 'cambridge-independent' ); ?>
            </a>
            <a href="?page=cambridge-independent-settings&tab=social" class="nav-tab <?php echo $active_tab === 'social' ? 'nav-tab-active' : ''; ?>">
                <?php _e( 'Social Media', 'cambridge-independent' ); ?>
            </a>
            <a href="?page=cambridge-independent-settings&tab=footer" class="nav-tab <?php echo $active_tab === 'footer' ? 'nav-tab-active' : ''; ?>">
                <?php _e( 'Footer', 'cambridge-independent' ); ?>
            </a>
            <a href="?page=cambridge-independent-settings&tab=custom" class="nav-tab <?php echo $active_tab === 'custom' ? 'nav-tab-active' : ''; ?>">
                <?php _e( 'Custom CSS', 'cambridge-independent' ); ?>
            </a>
        </nav>
        
        <form action="options.php" method="post">
            <?php
            if ( $active_tab === 'general' ) {
                settings_fields( 'ci_general_settings' );
                do_settings_sections( 'ci_general_settings' );
                ?>
                <div class="ci-settings-card">
                    <div class="ci-settings-card-header">
                        <h2><?php _e( 'General Settings', 'cambridge-independent' ); ?></h2>
                    </div>
                    <div class="ci-settings-card-body">
                        <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="ci_location_text"><?php _e( 'Location Text', 'cambridge-independent' ); ?></label>
                        </th>
                        <td>
                            <input type="text" 
                                   id="ci_location_text" 
                                   name="ci_location_text" 
                                   value="<?php echo esc_attr( get_option( 'ci_location_text', 'Cambridge | Somerville' ) ); ?>" 
                                   class="regular-text" />
                            <p class="description"><?php _e( 'Text displayed at the top of the header (e.g., "Cambridge | Somerville")', 'cambridge-independent' ); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="ci_site_logo_text"><?php _e( 'Site Logo Text', 'cambridge-independent' ); ?></label>
                        </th>
                        <td>
                            <input type="text" 
                                   id="ci_site_logo_text" 
                                   name="ci_site_logo_text" 
                                   value="<?php echo esc_attr( get_option( 'ci_site_logo_text', 'INDEPENDENT' ) ); ?>" 
                                   class="regular-text" />
                            <p class="description"><?php _e( 'Main logo text displayed in the header', 'cambridge-independent' ); ?></p>
                        </td>
                    </tr>
                        </table>
                    </div>
                </div>
                <?php
            } elseif ( $active_tab === 'social' ) {
                settings_fields( 'ci_social_settings' );
                do_settings_sections( 'ci_social_settings' );
                ?>
                <div class="ci-settings-card">
                    <div class="ci-settings-card-header">
                        <h2><?php _e( 'Social Media Settings', 'cambridge-independent' ); ?></h2>
                    </div>
                    <div class="ci-settings-card-body">
                        <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="ci_facebook_url"><?php _e( 'Facebook URL', 'cambridge-independent' ); ?></label>
                        </th>
                        <td>
                            <input type="url" 
                                   id="ci_facebook_url" 
                                   name="ci_facebook_url" 
                                   value="<?php echo esc_url( get_option( 'ci_facebook_url' ) ); ?>" 
                                   class="regular-text" />
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="ci_twitter_url"><?php _e( 'Twitter URL', 'cambridge-independent' ); ?></label>
                        </th>
                        <td>
                            <input type="url" 
                                   id="ci_twitter_url" 
                                   name="ci_twitter_url" 
                                   value="<?php echo esc_url( get_option( 'ci_twitter_url' ) ); ?>" 
                                   class="regular-text" />
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="ci_instagram_url"><?php _e( 'Instagram URL', 'cambridge-independent' ); ?></label>
                        </th>
                        <td>
                            <input type="url" 
                                   id="ci_instagram_url" 
                                   name="ci_instagram_url" 
                                   value="<?php echo esc_url( get_option( 'ci_instagram_url' ) ); ?>" 
                                   class="regular-text" />
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="ci_linkedin_url"><?php _e( 'LinkedIn URL', 'cambridge-independent' ); ?></label>
                        </th>
                        <td>
                            <input type="url" 
                                   id="ci_linkedin_url" 
                                   name="ci_linkedin_url" 
                                   value="<?php echo esc_url( get_option( 'ci_linkedin_url' ) ); ?>" 
                                   class="regular-text" />
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="ci_youtube_url"><?php _e( 'YouTube URL', 'cambridge-independent' ); ?></label>
                        </th>
                        <td>
                            <input type="url" 
                                   id="ci_youtube_url" 
                                   name="ci_youtube_url" 
                                   value="<?php echo esc_url( get_option( 'ci_youtube_url' ) ); ?>" 
                                   class="regular-text" />
                        </td>
                    </tr>
                        </table>
                    </div>
                </div>
                <?php
            } elseif ( $active_tab === 'footer' ) {
                settings_fields( 'ci_footer_settings' );
                do_settings_sections( 'ci_footer_settings' );
                ?>
                <div class="ci-settings-card">
                    <div class="ci-settings-card-header">
                        <h2><?php _e( 'Footer Settings', 'cambridge-independent' ); ?></h2>
                    </div>
                    <div class="ci-settings-card-body">
                        <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="ci_footer_text"><?php _e( 'Footer Text', 'cambridge-independent' ); ?></label>
                        </th>
                        <td>
                            <?php
                            $footer_text = get_option( 'ci_footer_text', '' );
                            wp_editor( $footer_text, 'ci_footer_text', array(
                                'textarea_name' => 'ci_footer_text',
                                'textarea_rows' => 5,
                                'media_buttons' => false,
                            ) );
                            ?>
                            <p class="description"><?php _e( 'Custom footer text (HTML allowed)', 'cambridge-independent' ); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="ci_copyright_text"><?php _e( 'Copyright Text', 'cambridge-independent' ); ?></label>
                        </th>
                        <td>
                            <input type="text" 
                                   id="ci_copyright_text" 
                                   name="ci_copyright_text" 
                                   value="<?php echo esc_attr( get_option( 'ci_copyright_text', '' ) ); ?>" 
                                   class="regular-text" />
                            <p class="description"><?php _e( 'Copyright text (leave empty to use default)', 'cambridge-independent' ); ?></p>
                        </td>
                    </tr>
                        </table>
                    </div>
                </div>
                
                <div class="ci-settings-card" style="margin-top: 20px;">
                    <div class="ci-settings-card-header">
                        <h2><?php _e( 'Classifieds Section', 'cambridge-independent' ); ?></h2>
                    </div>
                    <div class="ci-settings-card-body">
                        <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="ci_classified_job"><?php _e( 'JOB Text', 'cambridge-independent' ); ?></label>
                        </th>
                        <td>
                            <input type="text" 
                                   id="ci_classified_job" 
                                   name="ci_classified_job" 
                                   value="<?php echo esc_attr( get_option( 'ci_classified_job', 'Elder Care Needed in Cambridge ...' ) ); ?>" 
                                   class="regular-text" />
                            <p class="description"><?php _e( 'Text for the JOB classified section', 'cambridge-independent' ); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="ci_classified_place"><?php _e( 'PLACE Text', 'cambridge-independent' ); ?></label>
                        </th>
                        <td>
                            <input type="text" 
                                   id="ci_classified_place" 
                                   name="ci_classified_place" 
                                   value="<?php echo esc_attr( get_option( 'ci_classified_place', 'Spacious 1 BR Apartment in Somerville/Cambridge Line (Somerville) $2,425 ...' ) ); ?>" 
                                   class="regular-text" />
                            <p class="description"><?php _e( 'Text for the PLACE classified section', 'cambridge-independent' ); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="ci_classified_hey"><?php _e( 'HEY Text', 'cambridge-independent' ); ?></label>
                        </th>
                        <td>
                            <input type="text" 
                                   id="ci_classified_hey" 
                                   name="ci_classified_hey" 
                                   value="<?php echo esc_attr( get_option( 'ci_classified_hey', 'Do you live in Cambridge/Somerville & get the New Yorker in print? ...' ) ); ?>" 
                                   class="regular-text" />
                            <p class="description"><?php _e( 'Text for the HEY classified section', 'cambridge-independent' ); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="ci_classified_see_all_url"><?php _e( 'See All Ads URL', 'cambridge-independent' ); ?></label>
                        </th>
                        <td>
                            <input type="url" 
                                   id="ci_classified_see_all_url" 
                                   name="ci_classified_see_all_url" 
                                   value="<?php echo esc_url( get_option( 'ci_classified_see_all_url', home_url( '/classifieds' ) ) ); ?>" 
                                   class="regular-text" />
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="ci_classified_buy_url"><?php _e( 'Buy an Ad URL', 'cambridge-independent' ); ?></label>
                        </th>
                        <td>
                            <input type="url" 
                                   id="ci_classified_buy_url" 
                                   name="ci_classified_buy_url" 
                                   value="<?php echo esc_url( get_option( 'ci_classified_buy_url', home_url( '/buy-ad' ) ) ); ?>" 
                                   class="regular-text" />
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="ci_classified_donate_url"><?php _e( 'Donate URL', 'cambridge-independent' ); ?></label>
                        </th>
                        <td>
                            <input type="url" 
                                   id="ci_classified_donate_url" 
                                   name="ci_classified_donate_url" 
                                   value="<?php echo esc_url( get_option( 'ci_classified_donate_url', home_url( '/donate' ) ) ); ?>" 
                                   class="regular-text" />
                        </td>
                    </tr>
                        </table>
                    </div>
                </div>
                <?php
            } elseif ( $active_tab === 'custom' ) {
                settings_fields( 'ci_custom_settings' );
                do_settings_sections( 'ci_custom_settings' );
                ?>
                <div class="ci-settings-card">
                    <div class="ci-settings-card-header">
                        <h2><?php _e( 'Custom CSS', 'cambridge-independent' ); ?></h2>
                    </div>
                    <div class="ci-settings-card-body">
                        <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="ci_custom_css"><?php _e( 'Custom CSS', 'cambridge-independent' ); ?></label>
                        </th>
                        <td>
                            <textarea id="ci_custom_css" 
                                      name="ci_custom_css" 
                                      rows="15" 
                                      class="large-text code"><?php echo esc_textarea( get_option( 'ci_custom_css' ) ); ?></textarea>
                            <p class="description"><?php _e( 'Add custom CSS code here. It will be added to the theme stylesheet.', 'cambridge-independent' ); ?></p>
                        </td>
                    </tr>
                        </table>
                    </div>
                </div>
                <?php
            }
            ?>
            <div style="margin-top: 30px;">
                <?php submit_button(); ?>
            </div>
        </form>
    </div>
    <?php
}

/**
 * Enqueue admin scripts and styles
 */
function cambridge_independent_admin_scripts( $hook ) {
    // Enqueue admin CSS for modern black & white theme
    wp_enqueue_style(
        'cambridge-independent-admin',
        get_template_directory_uri() . '/assets/css/admin.css',
        array(),
        '1.0.0'
    );
    
    // Enqueue media uploader for header settings page
    if ( 'independent_page_cambridge-independent-header' === $hook ) {
        wp_enqueue_media();
    }
}
add_action( 'admin_enqueue_scripts', 'cambridge_independent_admin_scripts' );

/**
 * AJAX handler to get post count
 */
function cambridge_independent_ajax_get_post_count() {
    // Check permissions
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( array( 'message' => 'Permission denied' ) );
    }
    
    $total_posts = wp_count_posts();
    $published_count = $total_posts->publish;
    
    wp_send_json_success( array( 'count' => $published_count ) );
}
add_action( 'wp_ajax_cambridge_independent_get_post_count', 'cambridge_independent_ajax_get_post_count' );

/**
 * Header Settings Page
 */
function cambridge_independent_header_settings_page() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }
    
    settings_fields( 'ci_header_settings' );
    ?>
    <div class="wrap">
        <h1><?php _e( 'Header Settings', 'cambridge-independent' ); ?></h1>
        
        <form action="options.php" method="post">
            <?php settings_fields( 'ci_header_settings' ); ?>
            
            <div class="ci-settings-card">
                <div class="ci-settings-card-header">
                    <h2><?php _e( 'Logo Settings', 'cambridge-independent' ); ?></h2>
                </div>
                <div class="ci-settings-card-body">
                    <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="ci_logo_image"><?php _e( 'Logo Image', 'cambridge-independent' ); ?></label>
                    </th>
                    <td>
                        <input type="url" 
                               id="ci_logo_image" 
                               name="ci_logo_image" 
                               value="<?php echo esc_url( get_option( 'ci_logo_image' ) ); ?>" 
                               class="regular-text" />
                        <button type="button" class="button ci-upload-logo"><?php _e( 'Upload Logo', 'cambridge-independent' ); ?></button>
                        <?php
                            $logo_url = get_option( 'ci_logo_image' );
                            if ( ! empty( $logo_url ) ) {
                                echo '<div class="ci-logo-preview"><img src="' . esc_url( $logo_url ) . '" alt="Logo Preview" /></div>';
                            }
                        ?>
                    </td>
                </tr>
                
                <tr class="logo-size-row">
                    <th scope="row">
                        <label for="ci_logo_width"><?php _e( 'Logo Width', 'cambridge-independent' ); ?></label>
                    </th>
                    <td>
                        <input type="text" 
                               id="ci_logo_width" 
                               name="ci_logo_width" 
                               value="<?php echo esc_attr( get_option( 'ci_logo_width', '' ) ); ?>" 
                               class="small-text" />
                        <span>px</span>
                        <p class="description"><?php _e( 'Leave empty for auto width', 'cambridge-independent' ); ?></p>
                    </td>
                </tr>
                
                <tr class="logo-size-row">
                    <th scope="row">
                        <label for="ci_logo_height"><?php _e( 'Logo Height', 'cambridge-independent' ); ?></label>
                    </th>
                    <td>
                        <input type="text" 
                               id="ci_logo_height" 
                               name="ci_logo_height" 
                               value="<?php echo esc_attr( get_option( 'ci_logo_height', '' ) ); ?>" 
                               class="small-text" />
                        <span>px</span>
                        <p class="description"><?php _e( 'Leave empty for auto height', 'cambridge-independent' ); ?></p>
                    </td>
                </tr>
                    </table>
                </div>
            </div>
            
            <div class="ci-settings-card">
                <div class="ci-settings-card-header">
                    <h2><?php _e( 'Top Bar Settings', 'cambridge-independent' ); ?></h2>
                </div>
                <div class="ci-settings-card-body">
                    <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="ci_topbar_text"><?php _e( 'Top Bar Text', 'cambridge-independent' ); ?></label>
                    </th>
                    <td>
                        <input type="text" 
                               id="ci_topbar_text" 
                               name="ci_topbar_text" 
                               value="<?php echo esc_attr( get_option( 'ci_topbar_text', 'Cambridge | Somerville' ) ); ?>" 
                               class="regular-text" />
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="ci_topbar_font_size"><?php _e( 'Font Size', 'cambridge-independent' ); ?></label>
                    </th>
                    <td>
                        <input type="text" 
                               id="ci_topbar_font_size" 
                               name="ci_topbar_font_size" 
                               value="<?php echo esc_attr( get_option( 'ci_topbar_font_size', '14' ) ); ?>" 
                               class="small-text" />
                        <span>px</span>
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="ci_topbar_font_color"><?php _e( 'Font Color', 'cambridge-independent' ); ?></label>
                    </th>
                    <td>
                        <input type="color" 
                               id="ci_topbar_font_color" 
                               name="ci_topbar_font_color" 
                               value="<?php echo esc_attr( get_option( 'ci_topbar_font_color', '#333333' ) ); ?>" />
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="ci_topbar_font_weight"><?php _e( 'Font Weight', 'cambridge-independent' ); ?></label>
                    </th>
                    <td>
                        <select id="ci_topbar_font_weight" name="ci_topbar_font_weight">
                            <option value="100" <?php selected( get_option( 'ci_topbar_font_weight', '400' ), '100' ); ?>>100 - Thin</option>
                            <option value="200" <?php selected( get_option( 'ci_topbar_font_weight', '400' ), '200' ); ?>>200 - Extra Light</option>
                            <option value="300" <?php selected( get_option( 'ci_topbar_font_weight', '400' ), '300' ); ?>>300 - Light</option>
                            <option value="400" <?php selected( get_option( 'ci_topbar_font_weight', '400' ), '400' ); ?>>400 - Normal</option>
                            <option value="500" <?php selected( get_option( 'ci_topbar_font_weight', '400' ), '500' ); ?>>500 - Medium</option>
                            <option value="600" <?php selected( get_option( 'ci_topbar_font_weight', '400' ), '600' ); ?>>600 - Semi Bold</option>
                            <option value="700" <?php selected( get_option( 'ci_topbar_font_weight', '400' ), '700' ); ?>>700 - Bold</option>
                            <option value="800" <?php selected( get_option( 'ci_topbar_font_weight', '400' ), '800' ); ?>>800 - Extra Bold</option>
                            <option value="900" <?php selected( get_option( 'ci_topbar_font_weight', '400' ), '900' ); ?>>900 - Black</option>
                        </select>
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="ci_topbar_line_height"><?php _e( 'Line Height', 'cambridge-independent' ); ?></label>
                    </th>
                    <td>
                        <input type="text" 
                               id="ci_topbar_line_height" 
                               name="ci_topbar_line_height" 
                               value="<?php echo esc_attr( get_option( 'ci_topbar_line_height', '1.6' ) ); ?>" 
                               class="small-text" />
                        <p class="description"><?php _e( 'e.g., 1.6 or 24px', 'cambridge-independent' ); ?></p>
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="ci_topbar_letter_spacing"><?php _e( 'Letter Spacing', 'cambridge-independent' ); ?></label>
                    </th>
                    <td>
                        <input type="text" 
                               id="ci_topbar_letter_spacing" 
                               name="ci_topbar_letter_spacing" 
                               value="<?php echo esc_attr( get_option( 'ci_topbar_letter_spacing', '0.5' ) ); ?>" 
                               class="small-text" />
                        <span>px</span>
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="ci_topbar_bg_color"><?php _e( 'Background Color', 'cambridge-independent' ); ?></label>
                    </th>
                    <td>
                        <input type="color" 
                               id="ci_topbar_bg_color" 
                               name="ci_topbar_bg_color" 
                               value="<?php echo esc_attr( get_option( 'ci_topbar_bg_color', '#ffffff' ) ); ?>" />
                    </td>
                    </tr>
                    </table>
                </div>
            </div>
            
            <div class="ci-settings-card">
                <div class="ci-settings-card-header">
                    <h2><?php _e( 'Logo Text Settings', 'cambridge-independent' ); ?></h2>
                </div>
                <div class="ci-settings-card-body">
                    <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="ci_logo_font_size"><?php _e( 'Font Size', 'cambridge-independent' ); ?></label>
                    </th>
                    <td>
                        <input type="text" 
                               id="ci_logo_font_size" 
                               name="ci_logo_font_size" 
                               value="<?php echo esc_attr( get_option( 'ci_logo_font_size', '48' ) ); ?>" 
                               class="small-text" />
                        <span>px</span>
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="ci_logo_font_color"><?php _e( 'Font Color', 'cambridge-independent' ); ?></label>
                    </th>
                    <td>
                        <input type="color" 
                               id="ci_logo_font_color" 
                               name="ci_logo_font_color" 
                               value="<?php echo esc_attr( get_option( 'ci_logo_font_color', '#000000' ) ); ?>" />
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="ci_logo_font_weight"><?php _e( 'Font Weight', 'cambridge-independent' ); ?></label>
                    </th>
                    <td>
                        <select id="ci_logo_font_weight" name="ci_logo_font_weight">
                            <option value="100" <?php selected( get_option( 'ci_logo_font_weight', '900' ), '100' ); ?>>100 - Thin</option>
                            <option value="200" <?php selected( get_option( 'ci_logo_font_weight', '900' ), '200' ); ?>>200 - Extra Light</option>
                            <option value="300" <?php selected( get_option( 'ci_logo_font_weight', '900' ), '300' ); ?>>300 - Light</option>
                            <option value="400" <?php selected( get_option( 'ci_logo_font_weight', '900' ), '400' ); ?>>400 - Normal</option>
                            <option value="500" <?php selected( get_option( 'ci_logo_font_weight', '900' ), '500' ); ?>>500 - Medium</option>
                            <option value="600" <?php selected( get_option( 'ci_logo_font_weight', '900' ), '600' ); ?>>600 - Semi Bold</option>
                            <option value="700" <?php selected( get_option( 'ci_logo_font_weight', '900' ), '700' ); ?>>700 - Bold</option>
                            <option value="800" <?php selected( get_option( 'ci_logo_font_weight', '900' ), '800' ); ?>>800 - Extra Bold</option>
                            <option value="900" <?php selected( get_option( 'ci_logo_font_weight', '900' ), '900' ); ?>>900 - Black</option>
                        </select>
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="ci_logo_line_height"><?php _e( 'Line Height', 'cambridge-independent' ); ?></label>
                    </th>
                    <td>
                        <input type="text" 
                               id="ci_logo_line_height" 
                               name="ci_logo_line_height" 
                               value="<?php echo esc_attr( get_option( 'ci_logo_line_height', '1' ) ); ?>" 
                               class="small-text" />
                        <p class="description"><?php _e( 'e.g., 1 or 48px', 'cambridge-independent' ); ?></p>
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="ci_logo_letter_spacing"><?php _e( 'Letter Spacing', 'cambridge-independent' ); ?></label>
                    </th>
                    <td>
                        <input type="text" 
                               id="ci_logo_letter_spacing" 
                               name="ci_logo_letter_spacing" 
                               value="<?php echo esc_attr( get_option( 'ci_logo_letter_spacing', '2' ) ); ?>" 
                               class="small-text" />
                        <span>px</span>
                    </td>
                    </tr>
                    </table>
                </div>
            </div>
            
            <div class="ci-settings-card" style="margin-top: 20px;">
                <div class="ci-settings-card-header">
                    <h2><?php _e( 'Hamburger Menu Items', 'cambridge-independent' ); ?></h2>
                </div>
                <div class="ci-settings-card-body">
                    <p class="description"><?php _e( 'Manage hamburger menu items. Menu items are currently managed through code. To customize, edit the default items in template-functions.php or use the default menu items.', 'cambridge-independent' ); ?></p>
                    <p class="description"><?php _e( 'Note: Dynamic menu management interface coming soon. For now, menu items use default values if no custom items are saved.', 'cambridge-independent' ); ?></p>
                    <?php
                    $menu_items = get_option( 'ci_hamburger_menu_items', array() );
                    if ( empty( $menu_items ) ) {
                        echo '<p><strong>' . __( 'Using default menu items.', 'cambridge-independent' ) . '</strong></p>';
                    } else {
                        echo '<p><strong>' . sprintf( __( 'Using %d custom menu item(s).', 'cambridge-independent' ), count( $menu_items ) ) . '</strong></p>';
                    }
                    ?>
                    <input type="hidden" name="ci_hamburger_menu_items" value="<?php echo esc_attr( json_encode( $menu_items ) ); ?>" />
                </div>
            </div>
            
            <div style="margin-top: 30px;">
                <?php submit_button(); ?>
            </div>
        </form>
    </div>
    
    <script>
    jQuery(document).ready(function($) {
        // Media uploader for logo
        $('.ci-upload-logo').on('click', function(e) {
            e.preventDefault();
            var button = $(this);
            var input = $('#ci_logo_image');
            
            var frame = wp.media({
                title: 'Select Logo Image',
                button: {
                    text: 'Use this image'
                },
                multiple: false
            });
            
            frame.on('select', function() {
                var attachment = frame.state().get('selection').first().toJSON();
                input.val(attachment.url);
                if ($('img[src="' + attachment.url + '"]').length === 0) {
                    input.after('<p><img src="' + attachment.url + '" style="max-width: 200px; height: auto; margin-top: 10px;" /></p>');
                }
            });
            
            frame.open();
        });
        
        // Show logo preview when image is selected
        $('#ci_logo_image').on('change', function() {
            var logoUrl = $(this).val();
            if (logoUrl) {
                var existingPreview = $(this).next('button').next('p');
                if (existingPreview.length === 0) {
                    $(this).next('button').after('<p><img src="' + logoUrl + '" style="max-width: 200px; height: auto; margin-top: 10px;" /></p>');
                } else {
                    existingPreview.find('img').attr('src', logoUrl);
                }
            }
        });
    });
    </script>
    <?php
}

/**
 * Enqueue custom CSS from settings
 */
function cambridge_independent_enqueue_custom_css() {
    $custom_css = get_option( 'ci_custom_css' );
    if ( ! empty( $custom_css ) ) {
        wp_add_inline_style( 'cambridge-independent-style', $custom_css );
    }
    
    // Header custom styles
    $header_css = '';
    
    // Top bar styles
    $topbar_font_size = get_option( 'ci_topbar_font_size', '14' );
    $topbar_font_color = get_option( 'ci_topbar_font_color', '#333333' );
    $topbar_font_weight = get_option( 'ci_topbar_font_weight', '400' );
    $topbar_line_height = get_option( 'ci_topbar_line_height', '1.6' );
    $topbar_letter_spacing = get_option( 'ci_topbar_letter_spacing', '0.5' );
    $topbar_bg_color = get_option( 'ci_topbar_bg_color', '#ffffff' );
    
    if ( ! empty( $topbar_font_size ) || ! empty( $topbar_font_color ) || ! empty( $topbar_font_weight ) ) {
        $header_css .= '.location-text {';
        if ( ! empty( $topbar_font_size ) ) $header_css .= 'font-size: ' . esc_attr( $topbar_font_size ) . 'px; ';
        if ( ! empty( $topbar_font_color ) ) $header_css .= 'color: ' . esc_attr( $topbar_font_color ) . '; ';
        if ( ! empty( $topbar_font_weight ) ) $header_css .= 'font-weight: ' . esc_attr( $topbar_font_weight ) . '; ';
        if ( ! empty( $topbar_line_height ) ) $header_css .= 'line-height: ' . esc_attr( $topbar_line_height ) . '; ';
        if ( ! empty( $topbar_letter_spacing ) ) $header_css .= 'letter-spacing: ' . esc_attr( $topbar_letter_spacing ) . 'px; ';
        $header_css .= '}';
    }
    
    if ( ! empty( $topbar_bg_color ) ) {
        $header_css .= '.header-top { background-color: ' . esc_attr( $topbar_bg_color ) . '; }';
    }
    
    // Logo text styles
    $logo_font_size = get_option( 'ci_logo_font_size', '48' );
    $logo_font_color = get_option( 'ci_logo_font_color', '#000000' );
    $logo_font_weight = get_option( 'ci_logo_font_weight', '900' );
    $logo_line_height = get_option( 'ci_logo_line_height', '1' );
    $logo_letter_spacing = get_option( 'ci_logo_letter_spacing', '2' );
    
    if ( ! empty( $logo_font_size ) || ! empty( $logo_font_color ) || ! empty( $logo_font_weight ) ) {
        $header_css .= '.site-title {';
        if ( ! empty( $logo_font_size ) ) $header_css .= 'font-size: ' . esc_attr( $logo_font_size ) . 'px; ';
        if ( ! empty( $logo_font_weight ) ) $header_css .= 'font-weight: ' . esc_attr( $logo_font_weight ) . '; ';
        if ( ! empty( $logo_line_height ) ) $header_css .= 'line-height: ' . esc_attr( $logo_line_height ) . '; ';
        if ( ! empty( $logo_letter_spacing ) ) $header_css .= 'letter-spacing: ' . esc_attr( $logo_letter_spacing ) . 'px; ';
        $header_css .= '}';
        
        $header_css .= '.site-title a {';
        if ( ! empty( $logo_font_color ) ) $header_css .= 'color: ' . esc_attr( $logo_font_color ) . '; ';
        $header_css .= '}';
    }
    
    // Logo image styles
    $logo_image = get_option( 'ci_logo_image' );
    $logo_width = get_option( 'ci_logo_width' );
    $logo_height = get_option( 'ci_logo_height' );
    
    if ( ! empty( $logo_image ) ) {
        $header_css .= '.site-title a img { display: block; ';
        if ( ! empty( $logo_width ) ) $header_css .= 'width: ' . esc_attr( $logo_width ) . 'px; ';
        if ( ! empty( $logo_height ) ) $header_css .= 'height: ' . esc_attr( $logo_height ) . 'px; ';
        $header_css .= 'object-fit: contain; }';
    }
    
    if ( ! empty( $header_css ) ) {
        wp_add_inline_style( 'cambridge-independent-style', $header_css );
    }
}
add_action( 'wp_enqueue_scripts', 'cambridge_independent_enqueue_custom_css', 20 );

/**
 * Generate Dummy Posts Admin Page
 */
function cambridge_independent_generate_posts_page() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }
    
    $message = '';
    $message_type = 'info';
    
    // Handle generate posts form submission
    // Handle create pages action
    // Handle create default menu
    if ( isset( $_POST['create_default_menu'] ) && check_admin_referer( 'create_default_menu_action', 'create_default_menu_nonce' ) ) {
        cambridge_independent_create_default_menu();
        echo '<div class="notice notice-success is-dismissible"><p>' . __( 'Default menu created/updated successfully!', 'cambridge-independent' ) . '</p></div>';
    }
    
    if ( isset( $_POST['create_pages'] ) && check_admin_referer( 'create_pages_action', 'create_pages_nonce' ) ) {
        $pages_result = cambridge_independent_create_hamburger_pages();
        if ( $pages_result['created'] > 0 || $pages_result['updated'] > 0 ) {
            $message = sprintf( 
                __( 'Successfully created %d page(s) and updated %d page(s).', 'cambridge-independent' ),
                $pages_result['created'],
                $pages_result['updated']
            );
            $message_type = 'success';
        } else {
            $message = __( 'No pages were created or updated.', 'cambridge-independent' );
            $message_type = 'warning';
        }
        if ( ! empty( $pages_result['errors'] ) ) {
            $message .= ' ' . __( 'Some errors occurred:', 'cambridge-independent' ) . ' ' . implode( ', ', $pages_result['errors'] );
            $message_type = 'error';
        }
    }
    
    if ( isset( $_POST['generate_posts'] ) && check_admin_referer( 'generate_posts_action', 'generate_posts_nonce' ) ) {
        $result = cambridge_independent_generate_dummy_posts();
        
        if ( $result['success'] ) {
            $message = sprintf( 
                __( 'Successfully created %d out of %d posts.', 'cambridge-independent' ),
                $result['created'],
                $result['total']
            );
            $message_type = 'success';
            
            if ( ! empty( $result['errors'] ) ) {
                $message .= '<br><strong>' . __( 'Errors:', 'cambridge-independent' ) . '</strong><ul>';
                foreach ( $result['errors'] as $error ) {
                    $message .= '<li>' . esc_html( $error ) . '</li>';
                }
                $message .= '</ul>';
                $message_type = 'warning';
            }
        } else {
            $message = __( 'Failed to generate posts. Please try again.', 'cambridge-independent' );
            $message_type = 'error';
        }
    }
    
    // Handle add thumbnails form submission
    if ( isset( $_POST['add_thumbnails'] ) && check_admin_referer( 'add_thumbnails_action', 'add_thumbnails_nonce' ) ) {
        $result = cambridge_independent_add_thumbnails_to_existing_posts();
        
        if ( $result['success'] ) {
            $message = sprintf( 
                __( 'Successfully added thumbnails to %d posts. %d posts already had thumbnails and were skipped.', 'cambridge-independent' ),
                $result['processed'],
                $result['skipped']
            );
            $message_type = 'success';
            
            if ( ! empty( $result['errors'] ) ) {
                $message .= '<br><strong>' . __( 'Errors:', 'cambridge-independent' ) . '</strong><ul>';
                foreach ( $result['errors'] as $error ) {
                    $message .= '<li>' . esc_html( $error ) . '</li>';
                }
                $message .= '</ul>';
                $message_type = 'warning';
            }
        } else {
            $message = __( 'Failed to add thumbnails. Please try again.', 'cambridge-independent' );
            $message_type = 'error';
        }
    }
    
    // Handle delete posts form submission
    if ( isset( $_POST['delete_posts'] ) && check_admin_referer( 'delete_posts_action', 'delete_posts_nonce' ) ) {
        $keep_recent = isset( $_POST['keep_recent'] ) ? absint( $_POST['keep_recent'] ) : 0;
        $result = cambridge_independent_delete_all_posts( $keep_recent );
        
        if ( $result['success'] ) {
            $message = sprintf( 
                __( 'Successfully deleted %d posts.', 'cambridge-independent' ),
                $result['deleted']
            );
            if ( $result['kept'] > 0 ) {
                $message .= ' ' . sprintf( __( '%d most recent posts were kept.', 'cambridge-independent' ), $result['kept'] );
            }
            $message_type = 'success';
            
            if ( ! empty( $result['errors'] ) ) {
                $message .= '<br><strong>' . __( 'Errors:', 'cambridge-independent' ) . '</strong><ul>';
                foreach ( $result['errors'] as $error ) {
                    $message .= '<li>' . esc_html( $error ) . '</li>';
                }
                $message .= '</ul>';
                $message_type = 'warning';
            }
        } else {
            $message = __( 'Failed to delete posts. Please try again.', 'cambridge-independent' );
            $message_type = 'error';
        }
    }
    ?>
    <div class="wrap">
        <h1><?php _e( 'Generate Dummy Posts', 'cambridge-independent' ); ?></h1>
        
        <?php if ( $message ) : ?>
            <div class="notice notice-<?php echo esc_attr( $message_type ); ?> is-dismissible">
                <p><?php echo $message; ?></p>
            </div>
        <?php endif; ?>
        
        <div class="card" style="max-width: 800px;">
            <h2><?php _e( 'Create Sample Content', 'cambridge-independent' ); ?></h2>
            <p><?php _e( 'This tool will create 20 sample posts with realistic content for testing the theme. Posts will be created in the following categories:', 'cambridge-independent' ); ?></p>
            <ul>
                <li><strong>News</strong> - 6 posts</li>
                <li><strong>Business</strong> - 3 posts</li>
                <li><strong>Arts</strong> - 3 posts</li>
                <li><strong>Culture</strong> - 4 posts</li>
                <li><strong>Food</strong> - 4 posts</li>
            </ul>
            <p><strong><?php _e( 'Note:', 'cambridge-independent' ); ?></strong> <?php _e( 'If categories don\'t exist, they will be created automatically. Posts will be published with dates spread over the past 9 days.', 'cambridge-independent' ); ?></p>
            
            <form method="post" action="">
                <?php wp_nonce_field( 'generate_posts_action', 'generate_posts_nonce' ); ?>
                <p class="submit">
                    <input type="submit" 
                           name="generate_posts" 
                           class="button button-primary" 
                           value="<?php esc_attr_e( 'Generate Posts', 'cambridge-independent' ); ?>" 
                           onclick="return confirm('<?php esc_attr_e( 'This will create 20 new posts. Continue?', 'cambridge-independent' ); ?>');" />
                </p>
            </form>
        </div>
        
        <div class="card" style="max-width: 800px; margin-top: 20px;">
            <h2><?php _e( 'Create Default Menu', 'cambridge-independent' ); ?></h2>
            <p><?php _e( 'This will create or update the default navigation menu with standard items (NEWS, ARTS, COMMUNITY, RESOURCES, EVENTS). After creation, you can customize it in Appearance > Menus.', 'cambridge-independent' ); ?></p>
            <form method="post" action="">
                <?php wp_nonce_field( 'create_default_menu_action', 'create_default_menu_nonce' ); ?>
                <p>
                    <input type="submit" 
                           name="create_default_menu" 
                           class="button button-secondary" 
                           value="<?php esc_attr_e( 'Create/Update Default Menu', 'cambridge-independent' ); ?>" 
                           onclick="return confirm('<?php esc_attr_e( 'This will create or update the default menu. Continue?', 'cambridge-independent' ); ?>');" />
                </p>
            </form>
        </div>
        
        <div class="card" style="max-width: 800px; margin-top: 20px;">
            <h2><?php _e( 'Create Hamburger Menu Pages', 'cambridge-independent' ); ?></h2>
            <p><?php _e( 'This will create or update all pages linked in the hamburger menu dropdown, including:', 'cambridge-independent' ); ?></p>
            <ul style="list-style: disc; margin-left: 20px;">
                <li><?php _e( 'About the site', 'cambridge-independent' ); ?></li>
                <li><?php _e( 'Send us a news tip', 'cambridge-independent' ); ?></li>
                <li><?php _e( 'Send us a letter for publication online', 'cambridge-independent' ); ?></li>
                <li><?php _e( 'Advertise through us', 'cambridge-independent' ); ?></li>
                <li><?php _e( 'Donate to keep local journalism alive', 'cambridge-independent' ); ?></li>
                <li><?php _e( 'Reuse material from The Independent', 'cambridge-independent' ); ?></li>
            </ul>
            <p><strong><?php _e( 'Note:', 'cambridge-independent' ); ?></strong> <?php _e( 'If pages already exist, they will be updated with the default content. You can edit them later in the Pages section.', 'cambridge-independent' ); ?></p>
            <form method="post" action="">
                <?php wp_nonce_field( 'create_pages_action', 'create_pages_nonce' ); ?>
                <p>
                    <input type="submit" 
                           name="create_pages" 
                           class="button button-primary" 
                           value="<?php esc_attr_e( 'Create/Update Pages', 'cambridge-independent' ); ?>" 
                           onclick="return confirm('<?php esc_attr_e( 'This will create or update 6 pages. Continue?', 'cambridge-independent' ); ?>');" />
                </p>
            </form>
        </div>
        
        <div class="card" style="max-width: 800px; margin-top: 20px;">
            <h2><?php _e( 'Add Thumbnails to Existing Posts', 'cambridge-independent' ); ?></h2>
            <p><?php _e( 'This tool will add featured images (thumbnails) to all existing posts that don\'t have them. Images will be automatically selected based on each post\'s category.', 'cambridge-independent' ); ?></p>
            <p><strong><?php _e( 'Note:', 'cambridge-independent' ); ?></strong> <?php _e( 'This process may take a few minutes if you have many posts. Images are downloaded from a placeholder service.', 'cambridge-independent' ); ?></p>
            
            <form method="post" action="">
                <?php wp_nonce_field( 'add_thumbnails_action', 'add_thumbnails_nonce' ); ?>
                <p class="submit">
                    <input type="submit" 
                           name="add_thumbnails" 
                           class="button button-primary" 
                           value="<?php esc_attr_e( 'Add Thumbnails to Existing Posts', 'cambridge-independent' ); ?>" 
                           onclick="return confirm('<?php esc_attr_e( 'This will add thumbnails to all posts without featured images. Continue?', 'cambridge-independent' ); ?>');" />
                </p>
            </form>
        </div>
        
        <div class="card" style="max-width: 800px; margin-top: 20px; border-left: 4px solid #dc3232;">
            <h2 style="color: #dc3232;"><?php _e( 'Delete Posts', 'cambridge-independent' ); ?></h2>
            <p><strong><?php _e( 'Warning:', 'cambridge-independent' ); ?></strong> <?php _e( 'This action cannot be undone. All deleted posts will be permanently removed from your site.', 'cambridge-independent' ); ?></p>
            
            <p><?php _e( 'Currently, you have <strong><span id="post-count-dynamic">Loading...</span> published posts</strong>.', 'cambridge-independent' ); ?></p>
            
            <form method="post" action="">
                <?php wp_nonce_field( 'delete_posts_action', 'delete_posts_nonce' ); ?>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="keep_recent"><?php _e( 'Keep Most Recent Posts', 'cambridge-independent' ); ?></label>
                        </th>
                        <td>
                            <input type="number" 
                                   id="keep_recent" 
                                   name="keep_recent" 
                                   value="0" 
                                   min="0" 
                                   class="small-text" />
                            <p class="description">
                                <?php _e( 'Enter the number of most recent posts to keep (0 to delete all posts).', 'cambridge-independent' ); ?>
                            </p>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <input type="submit" 
                           name="delete_posts" 
                           class="button button-secondary" 
                           style="background-color: #dc3232; border-color: #dc3232; color: #fff;"
                           value="<?php esc_attr_e( 'Delete Posts', 'cambridge-independent' ); ?>" 
                           onclick="return confirm('<?php esc_attr_e( 'WARNING: This will permanently delete posts. This action cannot be undone. Are you absolutely sure?', 'cambridge-independent' ); ?>');" />
                </p>
            </form>
        </div>
        
        <script type="text/javascript">
        jQuery(document).ready(function($) {
            // Function to update post count
            function updatePostCount() {
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'cambridge_independent_get_post_count'
                    },
                    success: function(response) {
                        if (response.success) {
                            var count = response.data.count;
                            $('#post-count-dynamic').text(count);
                            $('#keep_recent').attr('max', count);
                        } else {
                            $('#post-count-dynamic').text('0');
                        }
                    },
                    error: function() {
                        $('#post-count-dynamic').text('Error');
                    }
                });
            }
            
            // Update count on page load
            updatePostCount();
            
            // Update count after form submissions (if page doesn't reload)
            $('form').on('submit', function() {
                setTimeout(function() {
                    updatePostCount();
                }, 1000);
            });
        });
        </script>
        
        <div class="card" style="max-width: 800px; margin-top: 20px;">
            <h2><?php _e( 'Alternative Methods', 'cambridge-independent' ); ?></h2>
            <p><?php _e( 'You can also generate posts using:', 'cambridge-independent' ); ?></p>
            <ul>
                <li><strong>WP-CLI:</strong> <code>wp eval-file wp-content/themes/Cambridge\ independent/inc/generate-dummy-posts.php</code></li>
                <li><strong>Direct URL:</strong> <code><?php echo esc_url( get_template_directory_uri() . '/inc/generate-dummy-posts.php' ); ?></code></li>
            </ul>
        </div>
    </div>
    <?php
}

/**
 * Category Settings Page
 */
function cambridge_independent_category_settings_page() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }
    
    // Handle form submission
    if ( isset( $_POST['save_categories'] ) && check_admin_referer( 'category_settings_action', 'category_settings_nonce' ) ) {
        // Save News & Business categories
        $news_business_cats = isset( $_POST['ci_news_business_categories'] ) ? array_map( 'absint', $_POST['ci_news_business_categories'] ) : array();
        update_option( 'ci_news_business_categories', $news_business_cats );
        
        // Save Arts, Culture & Media categories
        $arts_culture_cats = isset( $_POST['ci_arts_culture_categories'] ) ? array_map( 'absint', $_POST['ci_arts_culture_categories'] ) : array();
        update_option( 'ci_arts_culture_categories', $arts_culture_cats );
        
        // Save posts per column
        $posts_per_column = isset( $_POST['ci_homepage_posts_per_column'] ) ? absint( $_POST['ci_homepage_posts_per_column'] ) : 15;
        update_option( 'ci_homepage_posts_per_column', $posts_per_column );
        
        // Save hero posts count
        $hero_posts_count = isset( $_POST['ci_hero_posts_count'] ) ? absint( $_POST['ci_hero_posts_count'] ) : 5;
        update_option( 'ci_hero_posts_count', $hero_posts_count );
        
        // Save hero posts unlimited option
        $hero_posts_unlimited = isset( $_POST['ci_hero_posts_unlimited'] ) ? 1 : 0;
        update_option( 'ci_hero_posts_unlimited', $hero_posts_unlimited );
        
        $message = __( 'Category settings saved successfully!', 'cambridge-independent' );
        $message_type = 'success';
    } elseif ( isset( $_POST['create_menu_categories'] ) && check_admin_referer( 'create_menu_categories_action', 'create_menu_categories_nonce' ) ) {
        // Create/Update menu categories
        cambridge_independent_create_menu_categories();
        $message = __( 'Menu categories (NEWS, ARTS, COMMUNITY, RESOURCES, EVENTS) created/updated successfully!', 'cambridge-independent' );
        $message_type = 'success';
    } else {
        $message = '';
        $message_type = 'info';
    }
    
    // Get all categories
    $categories = get_categories( array(
        'hide_empty' => false,
        'orderby'    => 'name',
        'order'      => 'ASC',
    ) );
    
    // Get saved category settings
    $news_business_cats = get_option( 'ci_news_business_categories', array() );
    $arts_culture_cats = get_option( 'ci_arts_culture_categories', array() );
    $posts_per_column = get_option( 'ci_homepage_posts_per_column', 15 );
    $hero_posts_count = get_option( 'ci_hero_posts_count', 5 );
    $hero_posts_unlimited = get_option( 'ci_hero_posts_unlimited', 0 );
    
    if ( ! is_array( $news_business_cats ) ) {
        $news_business_cats = array();
    }
    if ( ! is_array( $arts_culture_cats ) ) {
        $arts_culture_cats = array();
    }
    ?>
    <div class="wrap">
        <h1><?php _e( 'Category Settings', 'cambridge-independent' ); ?></h1>
        
        <?php if ( $message ) : ?>
            <div class="notice notice-<?php echo esc_attr( $message_type ); ?> is-dismissible">
                <p><?php echo esc_html( $message ); ?></p>
            </div>
        <?php endif; ?>
        
        <form method="post" action="">
            <?php
            wp_nonce_field( 'category_settings_action', 'category_settings_nonce' );
            ?>
            
            <div class="card" style="max-width: 900px;">
                <h2><?php _e( 'Homepage Column Categories', 'cambridge-independent' ); ?></h2>
                <p><?php _e( 'Select which categories should appear in each column on the homepage. If no categories are selected, all posts will be shown.', 'cambridge-independent' ); ?></p>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label><?php _e( 'News & Business Column', 'cambridge-independent' ); ?></label>
                        </th>
                        <td>
                            <div style="max-height: 200px; overflow-y: auto; border: 1px solid #ddd; padding: 10px; background: #fff;">
                                <?php if ( ! empty( $categories ) ) : ?>
                                    <?php foreach ( $categories as $category ) : ?>
                                        <label style="display: block; margin-bottom: 8px;">
                                            <input type="checkbox" 
                                                   name="ci_news_business_categories[]" 
                                                   value="<?php echo esc_attr( $category->term_id ); ?>"
                                                   <?php checked( in_array( $category->term_id, $news_business_cats ), true ); ?> />
                                            <?php echo esc_html( $category->name ); ?>
                                            <span style="color: #666; font-size: 12px;">(<?php echo esc_html( $category->count ); ?> posts)</span>
                                        </label>
                                    <?php endforeach; ?>
                                <?php else : ?>
                                    <p><?php _e( 'No categories found. Create some categories first.', 'cambridge-independent' ); ?></p>
                                <?php endif; ?>
                            </div>
                            <p class="description">
                                <?php _e( 'Select categories to display in the "News and Business" column on the homepage.', 'cambridge-independent' ); ?>
                            </p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label><?php _e( 'Arts, Culture & Media Column', 'cambridge-independent' ); ?></label>
                        </th>
                        <td>
                            <div style="max-height: 200px; overflow-y: auto; border: 1px solid #ddd; padding: 10px; background: #fff;">
                                <?php if ( ! empty( $categories ) ) : ?>
                                    <?php foreach ( $categories as $category ) : ?>
                                        <label style="display: block; margin-bottom: 8px;">
                                            <input type="checkbox" 
                                                   name="ci_arts_culture_categories[]" 
                                                   value="<?php echo esc_attr( $category->term_id ); ?>"
                                                   <?php checked( in_array( $category->term_id, $arts_culture_cats ), true ); ?> />
                                            <?php echo esc_html( $category->name ); ?>
                                            <span style="color: #666; font-size: 12px;">(<?php echo esc_html( $category->count ); ?> posts)</span>
                                        </label>
                                    <?php endforeach; ?>
                                <?php else : ?>
                                    <p><?php _e( 'No categories found. Create some categories first.', 'cambridge-independent' ); ?></p>
                                <?php endif; ?>
                            </div>
                            <p class="description">
                                <?php _e( 'Select categories to display in the "Arts, Culture and Media" column on the homepage.', 'cambridge-independent' ); ?></p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="ci_homepage_posts_per_column"><?php _e( 'Posts Per Column', 'cambridge-independent' ); ?></label>
                        </th>
                        <td>
                            <input type="number" 
                                   id="ci_homepage_posts_per_column" 
                                   name="ci_homepage_posts_per_column" 
                                   value="<?php echo esc_attr( $posts_per_column ); ?>" 
                                   min="1" 
                                   max="50" 
                                   class="small-text" />
                            <p class="description">
                                <?php _e( 'Number of posts to display in each column on the homepage.', 'cambridge-independent' ); ?>
                            </p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="ci_hero_posts_count"><?php _e( 'Hero Section Posts', 'cambridge-independent' ); ?></label>
                        </th>
                        <td>
                            <fieldset>
                                <label for="ci_hero_posts_unlimited">
                                    <input type="checkbox" 
                                           id="ci_hero_posts_unlimited" 
                                           name="ci_hero_posts_unlimited" 
                                           value="1" 
                                           <?php checked( $hero_posts_unlimited, 1 ); ?>
                                           onchange="document.getElementById('ci_hero_posts_count').disabled = this.checked;" />
                                    <?php _e( 'Show all recent posts (unlimited)', 'cambridge-independent' ); ?>
                                </label>
                            </fieldset>
                            <br>
                            <input type="number" 
                                   id="ci_hero_posts_count" 
                                   name="ci_hero_posts_count" 
                                   value="<?php echo esc_attr( $hero_posts_count ); ?>" 
                                   min="1" 
                                   max="100" 
                                   class="small-text" 
                                   <?php echo $hero_posts_unlimited ? 'disabled' : ''; ?> />
                            <p class="description">
                                <?php _e( 'Number of posts to display in the hero section slider. Users can navigate between these posts using the previous/next buttons. Check "Show all recent posts" to display unlimited posts.', 'cambridge-independent' ); ?>
                            </p>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <input type="submit" 
                           name="save_categories" 
                           class="button button-primary" 
                           value="<?php esc_attr_e( 'Save Category Settings', 'cambridge-independent' ); ?>" />
                </p>
            </div>
        </form>
        
        <!-- Menu Categories Section -->
        <div class="card" style="max-width: 900px; margin-top: 20px;">
            <h2><?php _e( 'Menu Categories', 'cambridge-independent' ); ?></h2>
            <p><?php _e( 'Create or update the menu categories used in the navigation menu: NEWS, ARTS, COMMUNITY, RESOURCES, EVENTS', 'cambridge-independent' ); ?></p>
            
            <?php
            // Check if menu categories exist
            $menu_categories = array( 'news', 'arts', 'community', 'resources', 'events' );
            $existing_categories = array();
            foreach ( $menu_categories as $slug ) {
                $cat = get_category_by_slug( $slug );
                if ( $cat ) {
                    $existing_categories[] = $cat->name;
                }
            }
            ?>
            
            <?php if ( ! empty( $existing_categories ) ) : ?>
                <div class="notice notice-info" style="margin: 15px 0;">
                    <p><strong><?php _e( 'Existing Menu Categories:', 'cambridge-independent' ); ?></strong></p>
                    <ul style="margin: 10px 0; padding-left: 20px;">
                        <?php foreach ( $existing_categories as $cat_name ) : ?>
                            <li><?php echo esc_html( $cat_name ); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php else : ?>
                <div class="notice notice-warning" style="margin: 15px 0;">
                    <p><?php _e( 'Menu categories have not been created yet. Click the button below to create them.', 'cambridge-independent' ); ?></p>
                </div>
            <?php endif; ?>
            
            <form method="post" action="">
                <?php wp_nonce_field( 'create_menu_categories_action', 'create_menu_categories_nonce' ); ?>
                <p class="submit">
                    <input type="submit" 
                           name="create_menu_categories" 
                           class="button button-secondary" 
                           value="<?php esc_attr_e( 'Create/Update Menu Categories', 'cambridge-independent' ); ?>" 
                           onclick="return confirm('<?php esc_attr_e( 'This will create or update the menu categories: NEWS, ARTS, COMMUNITY, RESOURCES, EVENTS. Continue?', 'cambridge-independent' ); ?>');" />
                </p>
            </form>
        </div>
        
        <div class="card" style="max-width: 900px; margin-top: 20px;">
            <h2><?php _e( 'How It Works', 'cambridge-independent' ); ?></h2>
            <ul style="list-style: disc; margin-left: 20px;">
                <li><?php _e( 'If you select categories for a column, only posts from those categories will appear in that column.', 'cambridge-independent' ); ?></li>
                <li><?php _e( 'If you leave all categories unchecked for a column, all posts will appear in that column (excluding the hero post).', 'cambridge-independent' ); ?></li>
                <li><?php _e( 'Categories can be selected for both columns, or you can keep them separate.', 'cambridge-independent' ); ?></li>
                <li><?php _e( 'The "Posts Per Column" setting controls how many posts are shown in each column.', 'cambridge-independent' ); ?></li>
            </ul>
        </div>
    </div>
    <?php
}

/**
 * Footer Settings Page
 */
function cambridge_independent_footer_settings_page() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }
    
    settings_fields( 'ci_footer_settings' );
    ?>
    <div class="wrap">
        <h1><?php _e( 'Footer Settings', 'cambridge-independent' ); ?></h1>
        
        <form action="options.php" method="post">
            <?php settings_fields( 'ci_footer_settings' ); ?>
            
            <!-- Footer Text Section -->
            <div class="ci-settings-card">
                <div class="ci-settings-card-header">
                    <h2><?php _e( 'Footer Text', 'cambridge-independent' ); ?></h2>
                </div>
                <div class="ci-settings-card-body">
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="ci_footer_text"><?php _e( 'Footer Text', 'cambridge-independent' ); ?></label>
                            </th>
                            <td>
                                <?php
                                $footer_text = get_option( 'ci_footer_text', '' );
                                wp_editor( $footer_text, 'ci_footer_text', array(
                                    'textarea_name' => 'ci_footer_text',
                                    'textarea_rows' => 5,
                                    'media_buttons' => false,
                                ) );
                                ?>
                                <p class="description"><?php _e( 'Custom footer text (HTML allowed). This will appear above the classifieds section.', 'cambridge-independent' ); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="ci_copyright_text"><?php _e( 'Copyright Text', 'cambridge-independent' ); ?></label>
                            </th>
                            <td>
                                <input type="text" 
                                       id="ci_copyright_text" 
                                       name="ci_copyright_text" 
                                       value="<?php echo esc_attr( get_option( 'ci_copyright_text', '' ) ); ?>" 
                                       class="regular-text" />
                                <p class="description"><?php _e( 'Copyright text displayed in the footer. Leave empty to use default: "© [Year] [Site Name]"', 'cambridge-independent' ); ?></p>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
            
            <!-- Classifieds Section -->
            <div class="ci-settings-card" style="margin-top: 20px;">
                <div class="ci-settings-card-header">
                    <h2><?php _e( 'Classifieds Section', 'cambridge-independent' ); ?></h2>
                </div>
                <div class="ci-settings-card-body">
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="ci_classified_job"><?php _e( 'JOB Text', 'cambridge-independent' ); ?></label>
                            </th>
                            <td>
                                <textarea 
                                    id="ci_classified_job" 
                                    name="ci_classified_job" 
                                    rows="3"
                                    class="large-text"><?php echo esc_textarea( get_option( 'ci_classified_job', 'Elder Care Needed in Cambridge ...' ) ); ?></textarea>
                                <p class="description"><?php _e( 'Text for the JOB classified section', 'cambridge-independent' ); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="ci_classified_place"><?php _e( 'PLACE Text', 'cambridge-independent' ); ?></label>
                            </th>
                            <td>
                                <textarea 
                                    id="ci_classified_place" 
                                    name="ci_classified_place" 
                                    rows="3"
                                    class="large-text"><?php echo esc_textarea( get_option( 'ci_classified_place', 'Spacious 1 BR Apartment in Somerville/Cambridge Line (Somerville) $2,425 ...' ) ); ?></textarea>
                                <p class="description"><?php _e( 'Text for the PLACE classified section', 'cambridge-independent' ); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="ci_classified_hey"><?php _e( 'HEY Text', 'cambridge-independent' ); ?></label>
                            </th>
                            <td>
                                <textarea 
                                    id="ci_classified_hey" 
                                    name="ci_classified_hey" 
                                    rows="3"
                                    class="large-text"><?php echo esc_textarea( get_option( 'ci_classified_hey', 'Do you live in Cambridge/Somerville & get the New Yorker in print? ...' ) ); ?></textarea>
                                <p class="description"><?php _e( 'Text for the HEY classified section', 'cambridge-independent' ); ?></p>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
            
            <!-- Classifieds Links Section -->
            <div class="ci-settings-card" style="margin-top: 20px;">
                <div class="ci-settings-card-header">
                    <h2><?php _e( 'Classifieds Links', 'cambridge-independent' ); ?></h2>
                </div>
                <div class="ci-settings-card-body">
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="ci_classified_see_all_url"><?php _e( 'See All Ads URL', 'cambridge-independent' ); ?></label>
                            </th>
                            <td>
                                <input type="url" 
                                       id="ci_classified_see_all_url" 
                                       name="ci_classified_see_all_url" 
                                       value="<?php echo esc_url( get_option( 'ci_classified_see_all_url', home_url( '/classifieds' ) ) ); ?>" 
                                       class="regular-text" />
                                <p class="description"><?php _e( 'URL for the "See all ads" link', 'cambridge-independent' ); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="ci_classified_buy_url"><?php _e( 'Buy an Ad URL', 'cambridge-independent' ); ?></label>
                            </th>
                            <td>
                                <input type="url" 
                                       id="ci_classified_buy_url" 
                                       name="ci_classified_buy_url" 
                                       value="<?php echo esc_url( get_option( 'ci_classified_buy_url', home_url( '/buy-ad' ) ) ); ?>" 
                                       class="regular-text" />
                                <p class="description"><?php _e( 'URL for the "Buy an ad" link', 'cambridge-independent' ); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="ci_classified_donate_url"><?php _e( 'Donate URL', 'cambridge-independent' ); ?></label>
                            </th>
                            <td>
                                <input type="url" 
                                       id="ci_classified_donate_url" 
                                       name="ci_classified_donate_url" 
                                       value="<?php echo esc_url( get_option( 'ci_classified_donate_url', home_url( '/donate' ) ) ); ?>" 
                                       class="regular-text" />
                                <p class="description"><?php _e( 'URL for the "Donate to the Independent" link', 'cambridge-independent' ); ?></p>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
            
            <!-- Social Media Links Section -->
            <div class="ci-settings-card" style="margin-top: 20px;">
                <div class="ci-settings-card-header">
                    <h2><?php _e( 'Social Media Links', 'cambridge-independent' ); ?></h2>
                </div>
                <div class="ci-settings-card-body">
                    <p class="description"><?php _e( 'Social media links will appear in the footer if URLs are provided.', 'cambridge-independent' ); ?></p>
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="ci_facebook_url"><?php _e( 'Facebook URL', 'cambridge-independent' ); ?></label>
                            </th>
                            <td>
                                <input type="url" 
                                       id="ci_facebook_url" 
                                       name="ci_facebook_url" 
                                       value="<?php echo esc_url( get_option( 'ci_facebook_url' ) ); ?>" 
                                       class="regular-text" />
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="ci_twitter_url"><?php _e( 'Twitter URL', 'cambridge-independent' ); ?></label>
                            </th>
                            <td>
                                <input type="url" 
                                       id="ci_twitter_url" 
                                       name="ci_twitter_url" 
                                       value="<?php echo esc_url( get_option( 'ci_twitter_url' ) ); ?>" 
                                       class="regular-text" />
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="ci_instagram_url"><?php _e( 'Instagram URL', 'cambridge-independent' ); ?></label>
                            </th>
                            <td>
                                <input type="url" 
                                       id="ci_instagram_url" 
                                       name="ci_instagram_url" 
                                       value="<?php echo esc_url( get_option( 'ci_instagram_url' ) ); ?>" 
                                       class="regular-text" />
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="ci_linkedin_url"><?php _e( 'LinkedIn URL', 'cambridge-independent' ); ?></label>
                            </th>
                            <td>
                                <input type="url" 
                                       id="ci_linkedin_url" 
                                       name="ci_linkedin_url" 
                                       value="<?php echo esc_url( get_option( 'ci_linkedin_url' ) ); ?>" 
                                       class="regular-text" />
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="ci_youtube_url"><?php _e( 'YouTube URL', 'cambridge-independent' ); ?></label>
                            </th>
                            <td>
                                <input type="url" 
                                       id="ci_youtube_url" 
                                       name="ci_youtube_url" 
                                       value="<?php echo esc_url( get_option( 'ci_youtube_url' ) ); ?>" 
                                       class="regular-text" />
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
            
            <?php submit_button( __( 'Save Footer Settings', 'cambridge-independent' ) ); ?>
        </form>
    </div>
    <?php
}

/**
 * Givers Settings Page
 */
function cambridge_independent_givers_settings_page() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }
    
    settings_fields( 'ci_givers_settings' );
    ?>
    <div class="wrap">
        <h1><?php _e( 'Givers Settings', 'cambridge-independent' ); ?></h1>
        <p class="description"><?php _e( 'Manage the list of public givers/donors that will be displayed on the Givers page. This page is linked from the "See a list of public givers" link in the donor credit box.', 'cambridge-independent' ); ?></p>
        
        <form action="options.php" method="post">
            <?php settings_fields( 'ci_givers_settings' ); ?>
            
            <div class="ci-settings-card">
                <div class="ci-settings-card-header">
                    <h2><?php _e( 'Public Givers List', 'cambridge-independent' ); ?></h2>
                </div>
                <div class="ci-settings-card-body">
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="ci_public_givers_list"><?php _e( 'Givers List Content', 'cambridge-independent' ); ?></label>
                            </th>
                            <td>
                                <?php
                                $givers_list = get_option( 'ci_public_givers_list', '' );
                                wp_editor( $givers_list, 'ci_public_givers_list', array(
                                    'textarea_name' => 'ci_public_givers_list',
                                    'textarea_rows' => 20,
                                    'media_buttons' => false,
                                    'teeny' => false,
                                    'tinymce' => array(
                                        'toolbar1' => 'bold,italic,underline,bullist,numlist,link,unlink',
                                        'toolbar2' => '',
                                    ),
                                ) );
                                ?>
                                <p class="description">
                                    <?php _e( 'Enter the list of public givers/donors. You can format this with names, donation amounts, or any other information you want to display. HTML formatting is allowed.', 'cambridge-independent' ); ?>
                                </p>
                                <p class="description">
                                    <strong><?php _e( 'Example format:', 'cambridge-independent' ); ?></strong><br>
                                    <?php _e( '• BioMed Realty - $10,000', 'cambridge-independent' ); ?><br>
                                    <?php _e( '• John Smith - $5,000', 'cambridge-independent' ); ?><br>
                                    <?php _e( '• Jane Doe - $2,500', 'cambridge-independent' ); ?>
                                </p>
                                <p class="description">
                                    <strong><?php _e( 'Note:', 'cambridge-independent' ); ?></strong> <?php _e( 'To create the Givers page, go to Pages > Add New, set the page slug to "givers", and select "Givers Page" as the template.', 'cambridge-independent' ); ?>
                                </p>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
            
            <?php submit_button( __( 'Save Givers Settings', 'cambridge-independent' ) ); ?>
        </form>
    </div>
    <?php
}

/**
 * Shortcode Guide Page
 */
function cambridge_independent_shortcode_guide_page() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }
    ?>
    <div class="wrap">
        <h1><?php _e( 'Shortcode Guide', 'cambridge-independent' ); ?></h1>
        
        <div class="ci-settings-card" style="max-width: 900px; margin-top: 20px;">
            <div class="ci-settings-card-header">
                <h2><?php _e( 'SIDEBAR and RELATED Section Shortcodes', 'cambridge-independent' ); ?></h2>
            </div>
            <div class="ci-settings-card-body">
                <p><?php _e( 'This theme includes two shortcodes that can be used anywhere in your post content to display related content sections:', 'cambridge-independent' ); ?></p>
                
                <h3 style="margin-top: 30px;">1. SIDEBAR Shortcode</h3>
                <p><strong><?php _e( 'Shortcode:', 'cambridge-independent' ); ?></strong> <code>[sidebar]</code></p>
                <p><?php _e( 'Usage: Place [sidebar] anywhere in your post editor content area. This will display a related story box showing the title of one related post from the same category.', 'cambridge-independent' ); ?></p>
                
                <div style="background: #f5f5f5; padding: 15px; margin: 15px 0; border-left: 4px solid #2271b1;">
                    <strong><?php _e( 'Example:', 'cambridge-independent' ); ?></strong>
                    <pre style="background: #fff; padding: 10px; margin-top: 10px; border: 1px solid #ddd;">This is paragraph 1.

[sidebar]

This is paragraph 2.</pre>
                </div>
                
                <h3 style="margin-top: 30px;">2. RELATED Shortcode</h3>
                <p><strong><?php _e( 'Shortcode:', 'cambridge-independent' ); ?></strong> <code>[related]</code></p>
                <p><?php _e( 'Usage: Place [related] anywhere in your post editor content area. This will display a RELATED posts section showing a list of multiple related posts from the same category (up to 5 posts).', 'cambridge-independent' ); ?></p>
                
                <div style="background: #f5f5f5; padding: 15px; margin: 15px 0; border-left: 4px solid #2271b1;">
                    <strong><?php _e( 'Example:', 'cambridge-independent' ); ?></strong>
                    <pre style="background: #fff; padding: 10px; margin-top: 10px; border: 1px solid #ddd;">This is paragraph 1.

[related]

This is paragraph 2.</pre>
                </div>
                
                <h3 style="margin-top: 30px;"><?php _e( 'How to Use:', 'cambridge-independent' ); ?></h3>
                <ol style="line-height: 2;">
                    <li><strong><?php _e( 'Go to Post Editor:', 'cambridge-independent' ); ?></strong> <?php _e( 'Navigate to WordPress Admin Dashboard → Posts → Add New (for a new post) or All Posts → Edit an existing post', 'cambridge-independent' ); ?></li>
                    <li><strong><?php _e( 'Add Shortcode to Content:', 'cambridge-independent' ); ?></strong> <?php _e( 'In the post editor content area, place your cursor where you want the section to appear and type one of the following shortcodes:', 'cambridge-independent' ); ?>
                        <ul style="margin-top: 10px;">
                            <li><?php _e( 'For SIDEBAR:', 'cambridge-independent' ); ?> <code>[sidebar]</code></li>
                            <li><?php _e( 'For RELATED:', 'cambridge-independent' ); ?> <code>[related]</code></li>
                        </ul>
                    </li>
                    <li><strong><?php _e( 'Save the Post:', 'cambridge-independent' ); ?></strong> <?php _e( 'Click the Publish or Update button to save your changes', 'cambridge-independent' ); ?></li>
                </ol>
                
                <h3 style="margin-top: 30px;"><?php _e( 'Important Notes:', 'cambridge-independent' ); ?></h3>
                <ul style="line-height: 2;">
                    <li><strong><?php _e( 'Shortcode Detection:', 'cambridge-independent' ); ?></strong> <?php _e( 'If shortcodes are present in the content, automatic insertion will be disabled. Shortcodes provide manual control over where sections appear.', 'cambridge-independent' ); ?></li>
                    <li><strong><?php _e( 'Single Posts Only:', 'cambridge-independent' ); ?></strong> <?php _e( 'These shortcodes work only on single post pages. They will not work on homepage, archive pages, or other page types.', 'cambridge-independent' ); ?></li>
                    <li><strong><?php _e( 'Related Posts Requirement:', 'cambridge-independent' ); ?></strong> <?php _e( 'The shortcodes will display related posts from the same category as the current post. If no related posts exist in the same category, the sections will not be displayed.', 'cambridge-independent' ); ?></li>
                    <li><strong><?php _e( 'Multiple Usage:', 'cambridge-independent' ); ?></strong> <?php _e( 'You can use these shortcodes multiple times in a single post. Each instance will show a different related post (for sidebar) or the same related posts list (for related section).', 'cambridge-independent' ); ?></li>
                </ul>
                
                <h3 style="margin-top: 30px;"><?php _e( 'Example Layout:', 'cambridge-independent' ); ?></h3>
                <div style="background: #f5f5f5; padding: 15px; margin: 15px 0; border-left: 4px solid #2271b1;">
                    <p style="margin-top: 0;"><strong><?php _e( 'Complete example showing how to structure your content:', 'cambridge-independent' ); ?></strong></p>
                    <pre style="background: #fff; padding: 10px; margin: 0; border: 1px solid #ddd;">Paragraph 1 content here...

[sidebar]

Paragraph 2 content here...

[related]

Paragraph 3 content here...</pre>
                </div>
                
                <h3 style="margin-top: 30px;"><?php _e( 'Visual Preview:', 'cambridge-independent' ); ?></h3>
                <div style="background: #f9f9f9; padding: 20px; margin: 15px 0; border: 1px solid #ddd;">
                    <p><strong><?php _e( 'SIDEBAR Section:', 'cambridge-independent' ); ?></strong></p>
                    <div style="background: #e1dcc7; padding: 15px; margin: 10px 0; border: 1px solid #ccc;">
                        <div style="font-weight: bold; font-size: 22px; margin-bottom: 10px;">SIDEBAR</div>
                        <div><a href="#" style="color: #000; text-decoration: none;">Related Post Title</a></div>
                    </div>
                    
                    <p style="margin-top: 20px;"><strong><?php _e( 'RELATED Section:', 'cambridge-independent' ); ?></strong></p>
                    <div style="background: #e1dcc7; padding: 15px; margin: 10px 0; border: 1px solid #ccc;">
                        <div style="font-weight: bold; font-size: 18px; margin-bottom: 10px;">RELATED</div>
                        <ul style="list-style: none; padding-left: 0; margin: 0;">
                            <li style="margin-bottom: 8px;">• <a href="#" style="color: rgb(51, 51, 51);">Related Post 1</a></li>
                            <li style="margin-bottom: 8px;">• <a href="#" style="color: rgb(51, 51, 51);">Related Post 2</a></li>
                            <li style="margin-bottom: 8px;">• <a href="#" style="color: rgb(51, 51, 51);">Related Post 3</a></li>
                        </ul>
                    </div>
                </div>
                
                <h3 style="margin-top: 30px;"><?php _e( 'Troubleshooting:', 'cambridge-independent' ); ?></h3>
                <ul style="line-height: 2;">
                    <li><strong><?php _e( 'Problem: Shortcode is not working', 'cambridge-independent' ); ?></strong>
                        <ul style="margin-top: 5px;">
                            <li><strong><?php _e( 'Solution:', 'cambridge-independent' ); ?></strong> <?php _e( 'Make sure you are viewing a single post page, not the homepage or archive page', 'cambridge-independent' ); ?></li>
                            <li><strong><?php _e( 'Solution:', 'cambridge-independent' ); ?></strong> <?php _e( 'Check that the post has at least one category assigned', 'cambridge-independent' ); ?></li>
                            <li><strong><?php _e( 'Solution:', 'cambridge-independent' ); ?></strong> <?php _e( 'Verify the post is published, not in draft status', 'cambridge-independent' ); ?></li>
                        </ul>
                    </li>
                    <li><strong><?php _e( 'Problem: Section is not displaying', 'cambridge-independent' ); ?></strong>
                        <ul style="margin-top: 5px;">
                            <li><strong><?php _e( 'Solution:', 'cambridge-independent' ); ?></strong> <?php _e( 'Check if there are related posts in the same category. If no related posts exist, the section will not appear', 'cambridge-independent' ); ?></li>
                            <li><strong><?php _e( 'Solution:', 'cambridge-independent' ); ?></strong> <?php _e( 'Verify the shortcode spelling is correct: [sidebar] or [related] (all lowercase, with square brackets)', 'cambridge-independent' ); ?></li>
                            <li><strong><?php _e( 'Solution:', 'cambridge-independent' ); ?></strong> <?php _e( 'Make sure there are no extra spaces or characters in the shortcode', 'cambridge-independent' ); ?></li>
                        </ul>
                    </li>
                    <li><strong><?php _e( 'Problem: Section appears in wrong location', 'cambridge-independent' ); ?></strong>
                        <ul style="margin-top: 5px;">
                            <li><strong><?php _e( 'Solution:', 'cambridge-independent' ); ?></strong> <?php _e( 'The shortcode must be placed exactly where you want the section to appear in the content', 'cambridge-independent' ); ?></li>
                            <li><strong><?php _e( 'Solution:', 'cambridge-independent' ); ?></strong> <?php _e( 'Check if automatic insertion is interfering. If shortcodes are present, automatic insertion is disabled', 'cambridge-independent' ); ?></li>
                        </ul>
                    </li>
                </ul>
                
                <h3 style="margin-top: 30px;"><?php _e( 'Tips & Best Practices:', 'cambridge-independent' ); ?></h3>
                <ul style="line-height: 2;">
                    <li><?php _e( 'Use shortcodes strategically to break up long content and provide related reading suggestions', 'cambridge-independent' ); ?></li>
                    <li><?php _e( 'Place [sidebar] after every 2-3 paragraphs to provide contextually relevant content', 'cambridge-independent' ); ?></li>
                    <li><?php _e( 'Use [related] near the end of your post to encourage readers to explore more content', 'cambridge-independent' ); ?></li>
                    <li><?php _e( 'Shortcodes work in both the Classic Editor and Gutenberg/Block Editor (Text mode)', 'cambridge-independent' ); ?></li>
                    <li><?php _e( 'You can preview how the sections will look by using the WordPress Preview feature before publishing', 'cambridge-independent' ); ?></li>
                </ul>
            </div>
        </div>
    </div>
    <?php
}


