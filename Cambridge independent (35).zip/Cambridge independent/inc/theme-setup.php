<?php
/**
 * Theme Setup Functions
 *
 * @package Cambridge_Independent
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Theme Setup
 */
function cambridge_independent_setup() {
    // Add theme support for title tag
    add_theme_support( 'title-tag' );

    // Add theme support for post thumbnails
    add_theme_support( 'post-thumbnails' );

    // Add theme support for automatic feed links
    add_theme_support( 'automatic-feed-links' );

    // Add theme support for HTML5 markup
    add_theme_support( 'html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
    ) );

    // Add theme support for custom logo
    add_theme_support( 'custom-logo', array(
        'height'      => 100,
        'width'       => 400,
        'flex-height' => true,
        'flex-width'  => true,
        'header-text' => array( 'site-title', 'site-description' ),
    ) );

    // Register navigation menus
    register_nav_menus( array(
        'primary' => esc_html__( 'Primary Menu', 'cambridge-independent' ),
        'footer'  => esc_html__( 'Footer Menu', 'cambridge-independent' ),
    ) );

    // Set content width
    $GLOBALS['content_width'] = 1200;
    
    // Create/Update menu categories on theme activation
    cambridge_independent_create_menu_categories();
    
    // Create/Update location tags on theme activation
    cambridge_independent_create_location_tags();
    
    // Create default menu on theme activation
    cambridge_independent_create_default_menu();
}
add_action( 'after_setup_theme', 'cambridge_independent_setup' );

/**
 * Create/Update menu categories: NEWS, ARTS, COMMUNITY, RESOURCES, EVENTS
 */
function cambridge_independent_create_menu_categories() {
    // Define the menu categories
    $menu_categories = array(
        array(
            'name' => 'News',
            'slug' => 'news',
            'description' => 'News articles and updates',
        ),
        array(
            'name' => 'Arts',
            'slug' => 'arts',
            'description' => 'Arts and culture content',
        ),
        array(
            'name' => 'Community',
            'slug' => 'community',
            'description' => 'Community news and events',
        ),
        array(
            'name' => 'Resources',
            'slug' => 'resources',
            'description' => 'Resources and information',
        ),
        array(
            'name' => 'Events',
            'slug' => 'events',
            'description' => 'Events and happenings',
        ),
    );
    
    foreach ( $menu_categories as $category ) {
        // Check if category exists by slug
        $existing_category = get_category_by_slug( $category['slug'] );
        
        if ( $existing_category ) {
            // Update existing category
            wp_update_term( $existing_category->term_id, 'category', array(
                'name'        => $category['name'],
                'description' => $category['description'],
            ) );
        } else {
            // Create new category
            wp_insert_term(
                $category['name'],
                'category',
                array(
                    'slug'        => $category['slug'],
                    'description' => $category['description'],
                )
            );
        }
    }
}

/**
 * Create/Update location tags: Cambridge and Somerville
 */
function cambridge_independent_create_location_tags() {
    // Define the location tags
    $location_tags = array(
        array(
            'name' => 'Cambridge',
            'slug' => 'cambridge',
            'description' => 'Posts related to Cambridge',
        ),
        array(
            'name' => 'Somerville',
            'slug' => 'somerville',
            'description' => 'Posts related to Somerville',
        ),
    );
    
    foreach ( $location_tags as $tag ) {
        // Check if tag exists by slug
        $existing_tag = get_term_by( 'slug', $tag['slug'], 'post_tag' );
        
        if ( $existing_tag ) {
            // Update existing tag
            wp_update_term( $existing_tag->term_id, 'post_tag', array(
                'name'        => $tag['name'],
                'description' => $tag['description'],
            ) );
        } else {
            // Create new tag
            wp_insert_term(
                $tag['name'],
                'post_tag',
                array(
                    'slug'        => $tag['slug'],
                    'description' => $tag['description'],
                )
            );
        }
    }
}

/**
 * Create default menu with standard menu items
 * This creates a menu that can be managed from Appearance > Menus
 */
function cambridge_independent_create_default_menu() {
    // Check if a menu already exists for primary location
    $menu_locations = get_nav_menu_locations();
    if ( isset( $menu_locations['primary'] ) && $menu_locations['primary'] > 0 ) {
        // Menu already assigned, skip
        return;
    }
    
    // Check if default menu already exists
    $menu_name = 'Primary Menu';
    $menu_exists = wp_get_nav_menu_object( $menu_name );
    
    if ( ! $menu_exists ) {
        // Create the menu
        $menu_id = wp_create_nav_menu( $menu_name );
        
        if ( is_wp_error( $menu_id ) ) {
            return;
        }
        
        // Define menu items
        $menu_items = array(
            array(
                'title' => 'NEWS',
                'type'  => 'category',
                'slug'  => 'news',
            ),
            array(
                'title' => 'ARTS',
                'type'  => 'category',
                'slug'  => 'arts',
            ),
            array(
                'title' => 'COMMUNITY',
                'type'  => 'category',
                'slug'  => 'community',
            ),
            array(
                'title' => 'RESOURCES',
                'type'  => 'category',
                'slug'  => 'resources',
            ),
            array(
                'title' => 'EVENTS',
                'type'  => 'page',
                'slug'  => 'events',
            ),
        );
        
        // Add menu items
        foreach ( $menu_items as $item ) {
            $menu_item_data = array(
                'menu-item-title'  => $item['title'],
                'menu-item-status' => 'publish',
            );
            
            if ( $item['type'] === 'category' ) {
                $category = get_category_by_slug( $item['slug'] );
                if ( $category ) {
                    $menu_item_data['menu-item-type']      = 'taxonomy';
                    $menu_item_data['menu-item-object']     = 'category';
                    $menu_item_data['menu-item-object-id'] = $category->term_id;
                } else {
                    // Fallback to custom link
                    $menu_item_data['menu-item-type'] = 'custom';
                    $menu_item_data['menu-item-url']  = home_url( '/category/' . $item['slug'] );
                }
            } elseif ( $item['type'] === 'page' ) {
                $page = get_page_by_path( $item['slug'] );
                if ( $page ) {
                    $menu_item_data['menu-item-type']      = 'post_type';
                    $menu_item_data['menu-item-object']     = 'page';
                    $menu_item_data['menu-item-object-id'] = $page->ID;
                } else {
                    // Fallback to custom link
                    $menu_item_data['menu-item-type'] = 'custom';
                    $menu_item_data['menu-item-url']  = home_url( '/' . $item['slug'] );
                }
            }
            
            wp_update_nav_menu_item( $menu_id, 0, $menu_item_data );
        }
        
        // Assign menu to primary location
        $locations = get_theme_mod( 'nav_menu_locations' );
        if ( ! is_array( $locations ) ) {
            $locations = array();
        }
        $locations['primary'] = $menu_id;
        set_theme_mod( 'nav_menu_locations', $locations );
    } else {
        // Menu exists but might not be assigned to location
        $menu_locations = get_nav_menu_locations();
        if ( ! isset( $menu_locations['primary'] ) || $menu_locations['primary'] == 0 ) {
            $locations = get_theme_mod( 'nav_menu_locations' );
            if ( ! is_array( $locations ) ) {
                $locations = array();
            }
            $locations['primary'] = $menu_exists->term_id;
            set_theme_mod( 'nav_menu_locations', $locations );
        }
    }
}

