<?php
/**
 * Template Functions
 *
 * @package Cambridge_Independent
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Get site admin email address
 * Returns the site contact email
 */
function cambridge_independent_get_admin_email() {
    return 'editor@csindie.com';
}

/**
 * Get site editor email address
 * Returns the editor contact email
 */
function cambridge_independent_get_editor_email() {
    return 'editor@csindie.com';
}

/**
 * Get site advertising email address
 * Returns the advertising contact email
 */
function cambridge_independent_get_advertising_email() {
    return 'advertising@csindie.com';
}

/**
 * Custom excerpt length
 */
function cambridge_independent_excerpt_length( $length ) {
    return 47;
}
add_filter( 'excerpt_length', 'cambridge_independent_excerpt_length', 999 );

/**
 * Custom excerpt more
 */
function cambridge_independent_excerpt_more( $more ) {
    return '...';
}
add_filter( 'excerpt_more', 'cambridge_independent_excerpt_more' );

/**
 * Get excerpt limited to 170 characters for homepage articles
 */
function cambridge_independent_get_excerpt_130_chars( $post_id = null ) {
    if ( ! $post_id ) {
        $post_id = get_the_ID();
    }
    
    $excerpt = get_the_excerpt( $post_id );
    
    // If no excerpt, get content
    if ( empty( $excerpt ) ) {
        $post = get_post( $post_id );
        $excerpt = $post->post_content;
    }
    
    // Strip HTML tags and decode entities
    $excerpt = wp_strip_all_tags( $excerpt );
    $excerpt = html_entity_decode( $excerpt, ENT_QUOTES, 'UTF-8' );
    
    // Trim to 170 characters
    if ( mb_strlen( $excerpt ) > 170 ) {
        $excerpt = mb_substr( $excerpt, 0, 170 );
        // Find last space to avoid cutting words
        $last_space = mb_strrpos( $excerpt, ' ' );
        if ( $last_space !== false ) {
            $excerpt = mb_substr( $excerpt, 0, $last_space );
        }
        $excerpt .= '...';
    }
    
    return $excerpt;
}

/**
 * Get excerpt limited to 250 characters for hero section
 */
function cambridge_independent_get_hero_excerpt_183_chars( $post_id = null ) {
    if ( ! $post_id ) {
        $post_id = get_the_ID();
    }
    
    $excerpt = get_the_excerpt( $post_id );
    
    // If no excerpt, get content
    if ( empty( $excerpt ) ) {
        $post = get_post( $post_id );
        $excerpt = $post->post_content;
    }
    
    // Strip HTML tags and decode entities
    $excerpt = wp_strip_all_tags( $excerpt );
    $excerpt = html_entity_decode( $excerpt, ENT_QUOTES, 'UTF-8' );
    
    // Trim to 250 characters
    if ( mb_strlen( $excerpt ) > 250 ) {
        $excerpt = mb_substr( $excerpt, 0, 250 );
        // Find last space to avoid cutting words
        $last_space = mb_strrpos( $excerpt, ' ' );
        if ( $last_space !== false ) {
            $excerpt = mb_substr( $excerpt, 0, $last_space );
        }
        $excerpt .= '...';
    }
    
    return $excerpt;
}

/**
 * Get excerpt limited to 400 characters for category/archive pages
 */
function cambridge_independent_get_excerpt_400_chars( $post_id = null ) {
    if ( ! $post_id ) {
        $post_id = get_the_ID();
    }
    
    $excerpt = get_the_excerpt( $post_id );
    
    // If no excerpt, get content
    if ( empty( $excerpt ) ) {
        $post = get_post( $post_id );
        $excerpt = $post->post_content;
    }
    
    // Strip HTML tags and decode entities
    $excerpt = wp_strip_all_tags( $excerpt );
    $excerpt = html_entity_decode( $excerpt, ENT_QUOTES, 'UTF-8' );
    
    // Trim to 400 characters
    if ( mb_strlen( $excerpt ) > 400 ) {
        $excerpt = mb_substr( $excerpt, 0, 400 );
        // Find last space to avoid cutting words
        $last_space = mb_strrpos( $excerpt, ' ' );
        if ( $last_space !== false ) {
            $excerpt = mb_substr( $excerpt, 0, $last_space );
        }
        $excerpt .= '...';
    }
    
    return $excerpt;
}

/**
 * Fallback menu for primary navigation
 * Shows specific categories: NEWS | ARTS | COMMUNITY | RESOURCES | EVENTS
 */
function cambridge_independent_fallback_menu() {
    // Define the menu items in order
    $menu_items = array(
        'NEWS'      => array( 'slug' => 'news', 'url' => home_url( '/category/news' ) ),
        'ARTS'      => array( 'slug' => 'arts', 'url' => home_url( '/category/arts' ) ),
        'COMMUNITY' => array( 'slug' => 'community', 'url' => home_url( '/category/community' ) ),
        'RESOURCES' => array( 'slug' => 'resources', 'url' => home_url( '/category/resources' ) ),
        'EVENTS'    => array( 'slug' => 'events', 'url' => home_url( '/events' ) ),
    );
    
    echo '<ul class="nav-menu">';
    foreach ( $menu_items as $label => $item ) {
        // Try to get category by slug first
        $category = get_category_by_slug( $item['slug'] );
        if ( $category ) {
            $url = get_category_link( $category->term_id );
        } else {
            // Fallback to URL if category doesn't exist
            $url = $item['url'];
        }
        echo '<li><a href="' . esc_url( $url ) . '">' . esc_html( $label ) . '</a></li>';
    }
    echo '</ul>';
}

/**
 * Get posts for homepage columns
 * Excludes hero post and organizes by category
 * Also respects city preference filtering
 */
function cambridge_independent_get_homepage_posts( $exclude_ids = array(), $category_slug = '', $posts_per_page = 10, $category_ids = array(), $exclude_category_ids = array() ) {
    $args = array(
        'posts_per_page' => $posts_per_page,
        'post_status'    => 'publish',
        'orderby'        => 'date',
        'order'          => 'DESC',
        'post__not_in'   => $exclude_ids,
    );
    
    // Use category IDs if provided (from settings)
    if ( ! empty( $category_ids ) && is_array( $category_ids ) ) {
        $args['category__in'] = array_map( 'absint', $category_ids );
    } elseif ( ! empty( $category_slug ) ) {
        // Fallback to category slug if no IDs provided
        $args['category_name'] = $category_slug;
    }
    
    // Exclude specific categories if provided
    if ( ! empty( $exclude_category_ids ) && is_array( $exclude_category_ids ) ) {
        $args['category__not_in'] = array_map( 'absint', $exclude_category_ids );
    }
    
    // Apply city preference filtering
    $preference = cambridge_independent_get_user_city_preference();
    if ( $preference !== 'all' ) {
        // Get existing meta query
        $meta_query = isset( $args['meta_query'] ) ? $args['meta_query'] : array();
        if ( ! is_array( $meta_query ) ) {
            $meta_query = array();
        }
        
        $other_city = ( $preference === 'cambridge' ) ? 'somerville' : 'cambridge';
        
        $city_meta_query = array(
            'relation' => 'OR',
            // Preferred city posts
            array(
                'key' => '_ci_city_designation',
                'value' => $preference,
                'compare' => '=',
            ),
            // Regional posts
            array(
                'key' => '_ci_city_designation',
                'value' => 'regional',
                'compare' => '=',
            ),
            // Posts without designation
            array(
                'key' => '_ci_city_designation',
                'compare' => 'NOT EXISTS',
            ),
        );
        
        // Combine with existing meta query
        if ( ! empty( $meta_query ) ) {
            $meta_query = array(
                'relation' => 'AND',
                $meta_query,
                $city_meta_query,
            );
        } else {
            $meta_query = $city_meta_query;
        }
        
        $args['meta_query'] = $meta_query;
        
        // Store for post-filtering
        $args['ci_city_preference'] = $preference;
        $args['ci_exclude_city'] = $other_city;
    }
    
    $query = new WP_Query( $args );
    
    // Filter out excluded city posts
    if ( $preference !== 'all' && $query->have_posts() ) {
        $filtered_posts = array();
        $other_city = ( $preference === 'cambridge' ) ? 'somerville' : 'cambridge';
        
        foreach ( $query->posts as $post ) {
            $city_designation = get_post_meta( $post->ID, '_ci_city_designation', true );
            // Include: preferred city, regional, or no designation
            // Exclude: other city
            if ( $city_designation !== $other_city ) {
                $filtered_posts[] = $post;
            }
        }
        
        // Update query results
        $query->posts = $filtered_posts;
        $query->post_count = count( $filtered_posts );
        $query->found_posts = count( $filtered_posts );
    }
    
    return $query;
}

/**
 * Check if ad should be inserted at current position
 * Ads appear randomly every 2-4 posts
 */
function cambridge_independent_should_insert_ad( $post_index ) {
    // Generate random ad interval (2-4 posts)
    $ad_interval = rand( 2, 4 );
    
    // Insert ad after every interval
    if ( $post_index > 0 && $post_index % $ad_interval === 0 ) {
        return true;
    }
    
    return false;
}

/**
 * Get random advertisement
 * Returns ad HTML or false if no ads available
 * Uses static counter to ensure each ad shows only once across all columns
 */
function cambridge_independent_get_random_ad() {
    // Static variable to track ad call count (shared across all columns)
    static $ad_call_count = 0;
    
    // Check if Advanced Ads plugin is active
    if ( function_exists( 'the_ad_placement' ) ) {
        // Increment counter for each call
        $ad_call_count++;
        
        // Use Advanced Ads plugin with 'column-inline' placement
        // Advanced Ads will automatically rotate through ads in the group
        // Each call will get the next ad in sequence
    ob_start();
        the_ad_placement( 'column-inline' );
        $ad_content = ob_get_clean();
        
        // Return ad content if it's not empty, wrapped with ADVERTISEMENT heading
        if ( ! empty( trim( $ad_content ) ) ) {
            $output = '<div class="inline-advertisement-wrapper">';
            $output .= '<h3 class="inline-advertisement-heading">ADVERTISEMENT</h3>';
            $output .= $ad_content;
            $output .= '</div>';
            return $output;
        }
    }
    
    // Fallback: return nothing (no dummy ads)
    // If you want to keep dummy ads as fallback, uncomment the lines below:
    // ob_start();
    // get_template_part( 'template-parts/homepage/ad-inline' );
    // return ob_get_clean();
    
    return false;
}

/**
 * Get latest WPAdverts ad by category
 * Returns HTML with image and text, or fallback text
 */
function cambridge_independent_get_wpadverts_ad_by_category( $category_slug, $fallback_text = '', $include_image = true ) {
    // Check if WPAdverts is active
    if ( ! class_exists( 'Adverts' ) && ! function_exists( 'adverts_list' ) ) {
        return $fallback_text;
    }
    
    // Query for latest ad in category
    $args = array(
        'post_type'      => 'advert',
        'post_status'    => 'publish',
        'posts_per_page' => 1,
        'orderby'        => 'date',
        'order'          => 'DESC',
    );
    
    // Add taxonomy filter if category slug is provided
    if ( ! empty( $category_slug ) ) {
        $args['tax_query'] = array(
            array(
                'taxonomy' => 'advert_category',
                'field'    => 'slug',
                'terms'    => $category_slug,
            ),
        );
    }
    
    $query = new WP_Query( $args );
    
    if ( $query->have_posts() ) {
        $query->the_post();
        $ad_id = get_the_ID();
        $ad_title = get_the_title();
        $ad_excerpt = get_the_excerpt();
        $ad_permalink = get_permalink();
        
        // Use title if available, otherwise excerpt
        $ad_text = ! empty( $ad_title ) ? $ad_title : $ad_excerpt;
        
        // Trim to reasonable length if needed
        if ( mb_strlen( $ad_text ) > 150 ) {
            $ad_text = mb_substr( $ad_text, 0, 150 );
            $last_space = mb_strrpos( $ad_text, ' ' );
            if ( $last_space !== false ) {
                $ad_text = mb_substr( $ad_text, 0, $last_space );
            }
            $ad_text .= '...';
        }
        
        // Build HTML output
        $output = '';
        
        // Get image if available - try multiple methods
        if ( $include_image ) {
            $image_url = null;
            
            // Method 1: Featured image (standard WordPress)
            if ( has_post_thumbnail( $ad_id ) ) {
                $thumbnail_id = get_post_thumbnail_id( $ad_id );
                $thumbnail_url = wp_get_attachment_image_src( $thumbnail_id, 'thumbnail' );
                if ( $thumbnail_url && ! empty( $thumbnail_url[0] ) ) {
                    $image_url = $thumbnail_url[0];
                }
            }
            
            // Method 2: Get first attachment (WPAdverts gallery)
            if ( ! $image_url ) {
                $attachments = get_attached_media( 'image', $ad_id );
                if ( ! empty( $attachments ) ) {
                    $first_attachment = reset( $attachments );
                    $attachment_url = wp_get_attachment_image_src( $first_attachment->ID, 'thumbnail' );
                    if ( $attachment_url && ! empty( $attachment_url[0] ) ) {
                        $image_url = $attachment_url[0];
                    }
                }
            }
            
            // Method 3: Check for WPAdverts gallery meta
            if ( ! $image_url ) {
                $gallery = get_post_meta( $ad_id, 'adverts_gallery', true );
                if ( ! empty( $gallery ) && is_array( $gallery ) ) {
                    $first_image_id = reset( $gallery );
                    if ( $first_image_id ) {
                        $gallery_url = wp_get_attachment_image_src( $first_image_id, 'thumbnail' );
                        if ( $gallery_url && ! empty( $gallery_url[0] ) ) {
                            $image_url = $gallery_url[0];
                        }
                    }
                }
            }
            
            // Display image if found
            if ( $image_url ) {
                $output .= '<a href="' . esc_url( $ad_permalink ) . '" class="classified-ad-link">';
                $output .= '<img src="' . esc_url( $image_url ) . '" alt="' . esc_attr( $ad_title ) . '" class="classified-ad-icon" />';
                $output .= '</a>';
            }
        }
        
        // Add text
        $output .= '<span class="classified-ad-text">' . esc_html( $ad_text ) . '</span>';
        
        wp_reset_postdata();
        
        return $output;
    }
    
    wp_reset_postdata();
    return $fallback_text;
}

/**
 * Get WPAdverts list page URL
 */
function cambridge_independent_get_wpadverts_list_url() {
    // Check if WPAdverts is active
    if ( ! class_exists( 'Adverts' ) ) {
        return get_option( 'ci_classified_see_all_url', home_url( '/classifieds' ) );
    }
    
    // Get WPAdverts options
    $adverts_config = get_option( 'adverts_config' );
    
    if ( ! empty( $adverts_config['ads_list_id'] ) ) {
        return get_permalink( $adverts_config['ads_list_id'] );
    }
    
    // Fallback: try to find page with [adverts_list] shortcode
    $pages = get_pages();
    foreach ( $pages as $page ) {
        if ( has_shortcode( $page->post_content, 'adverts_list' ) ) {
            return get_permalink( $page->ID );
        }
    }
    
    return get_option( 'ci_classified_see_all_url', home_url( '/classifieds' ) );
}

/**
 * Get WPAdverts add page URL
 */
function cambridge_independent_get_wpadverts_add_url() {
    // Check if WPAdverts is active
    if ( ! class_exists( 'Adverts' ) ) {
        return get_option( 'ci_classified_buy_url', home_url( '/buy-ad' ) );
    }
    
    // Get WPAdverts options
    $adverts_config = get_option( 'adverts_config' );
    
    if ( ! empty( $adverts_config['ads_list_id'] ) ) {
        // WPAdverts typically uses the list page URL with ?advert_id=0 or /add/ suffix
        $list_url = get_permalink( $adverts_config['ads_list_id'] );
        return trailingslashit( $list_url ) . 'add/';
    }
    
    // Fallback: try to find page with [adverts_add] shortcode
    $pages = get_pages();
    foreach ( $pages as $page ) {
        if ( has_shortcode( $page->post_content, 'adverts_add' ) ) {
            return get_permalink( $page->ID );
        }
    }
    
    return get_option( 'ci_classified_buy_url', home_url( '/buy-ad' ) );
}

/**
 * Render hamburger menu items
 * Gets menu items from settings or uses defaults
 */
function cambridge_independent_render_hamburger_menu_items() {
    $menu_items = get_option( 'ci_hamburger_menu_items', array() );
    
    // If no menu items set, use defaults
    if ( empty( $menu_items ) ) {
        $menu_items = array(
            array(
                'type' => 'city_preference',
                'label' => 'See all',
                'preference' => 'all',
                'highlight' => true,
                'bold_parts' => '',
            ),
            array(
                'type' => 'city_preference',
                'label' => 'I want mostly Cambridge news',
                'preference' => 'cambridge',
                'highlight' => false,
                'bold_parts' => '',
            ),
            array(
                'type' => 'city_preference',
                'label' => 'I want mostly Somerville news',
                'preference' => 'somerville',
                'highlight' => false,
                'bold_parts' => '',
            ),
            array( 'type' => 'separator' ),
            array(
                'type' => 'link',
                'label' => "We're all in this together: About the site",
                'url' => home_url( '/about' ),
                'highlight' => false,
                'bold_parts' => "We're all in this together",
            ),
            array(
                'type' => 'link',
                'label' => 'Email the editor',
                'url' => 'mailto:editor@csindie.com',
                'highlight' => false,
                'bold_parts' => '',
            ),
            array(
                'type' => 'link',
                'label' => 'Send us a news tip',
                'url' => 'mailto:editor@csindie.com?subject=News%20tip',
                'highlight' => false,
                'bold_parts' => '',
            ),
            array(
                'type' => 'link',
                'label' => 'Send us a letter for publication online',
                'url' => 'mailto:editor@csindie.com?subject=Letter%20for%20publication',
                'highlight' => false,
                'bold_parts' => '',
            ),
            array( 'type' => 'separator' ),
            array(
                'type' => 'link',
                'label' => 'Advertise through us',
                'url' => home_url( '/advertise' ),
                'highlight' => false,
                'bold_parts' => '',
            ),
            array(
                'type' => 'link',
                'label' => 'Donate to keep local journalism alive and improving (WooCommerce and Gravity) or give tax free (T/K)',
                'url' => home_url( '/donate' ),
                'highlight' => false,
                'bold_parts' => 'Donate,give tax',
            ),
            array(
                'type' => 'link',
                'label' => 'Reuse material from The Independent in your own publication',
                'url' => home_url( '/reuse' ),
                'highlight' => false,
                'bold_parts' => '',
            ),
        );
    }
    
    // Render menu items
    foreach ( $menu_items as $item ) {
        if ( isset( $item['type'] ) && $item['type'] === 'separator' ) {
            echo '<div class="hamburger-menu-separator"></div>';
        } elseif ( isset( $item['type'] ) && $item['type'] === 'city_preference' ) {
            // City preference items - set preference via JavaScript
            $label = isset( $item['label'] ) ? $item['label'] : '';
            $preference = isset( $item['preference'] ) ? $item['preference'] : 'all';
            $highlight = isset( $item['highlight'] ) && $item['highlight'] ? true : false;
            $bold_parts = isset( $item['bold_parts'] ) ? $item['bold_parts'] : '';
            
            // Check if this is the current preference
            $current_preference = cambridge_independent_get_user_city_preference();
            $is_current = ( $preference === $current_preference );
            
            $class = 'hamburger-menu-item hamburger-menu-city-preference';
            if ( $highlight || $is_current ) {
                $class .= ' hamburger-menu-highlight active';
            }
            
            // Process bold parts
            $display_label = esc_html( $label );
            if ( ! empty( $bold_parts ) ) {
                $bold_array = array_map( 'trim', explode( ',', $bold_parts ) );
                foreach ( $bold_array as $bold_part ) {
                    if ( ! empty( $bold_part ) && strpos( $label, $bold_part ) !== false ) {
                        $display_label = str_replace( esc_html( $bold_part ), '<strong>' . esc_html( $bold_part ) . '</strong>', $display_label );
                    }
                }
            }
            
            echo '<a href="#" class="' . esc_attr( $class ) . '" data-preference="' . esc_attr( $preference ) . '">' . $display_label . '</a>';
        } elseif ( isset( $item['type'] ) && $item['type'] === 'link' ) {
            $label = isset( $item['label'] ) ? $item['label'] : '';
            $url = isset( $item['url'] ) ? $item['url'] : '#';
            $highlight = isset( $item['highlight'] ) && $item['highlight'] ? true : false;
            $bold_parts = isset( $item['bold_parts'] ) ? $item['bold_parts'] : '';
            
            $class = 'hamburger-menu-item';
            if ( $highlight ) {
                $class .= ' hamburger-menu-highlight';
            }
            
            // Process bold parts
            $display_label = esc_html( $label );
            if ( ! empty( $bold_parts ) ) {
                $bold_array = array_map( 'trim', explode( ',', $bold_parts ) );
                foreach ( $bold_array as $bold_part ) {
                    if ( ! empty( $bold_part ) && strpos( $label, $bold_part ) !== false ) {
                        $display_label = str_replace( esc_html( $bold_part ), '<strong>' . esc_html( $bold_part ) . '</strong>', $display_label );
                    }
                }
            }
            
            echo '<a href="' . esc_url( $url ) . '" class="' . esc_attr( $class ) . '">' . $display_label . '</a>';
        }
    }
}

/**
 * Get tag archive URL, creating tag if it doesn't exist
 */
function cambridge_independent_get_tag_archive_url( $tag_slug ) {
    $tag = get_term_by( 'slug', $tag_slug, 'post_tag' );
    
    if ( ! $tag || is_wp_error( $tag ) ) {
        // Tag doesn't exist, create it
        $tag_result = wp_insert_term(
            ucfirst( $tag_slug ),
            'post_tag',
            array(
                'slug' => $tag_slug,
            )
        );
        
        if ( ! is_wp_error( $tag_result ) ) {
            $tag = get_term( $tag_result['term_id'], 'post_tag' );
        } else {
            // Fallback to home URL if tag creation fails
            return home_url( '/' );
        }
    }
    
    $tag_link = get_term_link( $tag );
    
    // If get_term_link fails, return home URL
    if ( is_wp_error( $tag_link ) ) {
        return home_url( '/' );
    }
    
    return $tag_link;
}

