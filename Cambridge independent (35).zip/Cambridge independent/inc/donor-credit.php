<?php
/**
 * Donor Credit Box System
 * Per-post and default donor credit box functionality
 *
 * @package Cambridge_Independent
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Add Donor Credit Meta Box to Post Editor
 */
function cambridge_independent_add_donor_credit_meta_box() {
    add_meta_box(
        'ci_donor_credit',
        __( 'Donor Credit Box', 'cambridge-independent' ),
        'cambridge_independent_donor_credit_meta_box_callback',
        'post',
        'normal',
        'high' // High priority to show near top
    );
}
add_action( 'add_meta_boxes', 'cambridge_independent_add_donor_credit_meta_box' );

/**
 * Ensure Donor Credit Meta Box is visible by default
 */
function cambridge_independent_donor_credit_default_hidden( $hidden, $screen ) {
    if ( $screen && $screen->id === 'post' ) {
        // Remove 'ci_donor_credit' from hidden meta boxes
        $hidden = array_diff( $hidden, array( 'ci_donor_credit' ) );
    }
    return $hidden;
}
add_filter( 'default_hidden_meta_boxes', 'cambridge_independent_donor_credit_default_hidden', 10, 2 );

/**
 * Meta Box Callback
 */
function cambridge_independent_donor_credit_meta_box_callback( $post ) {
    wp_nonce_field( 'cambridge_independent_donor_credit_meta_box', 'cambridge_independent_donor_credit_meta_box_nonce' );
    
    $use_custom = get_post_meta( $post->ID, '_ci_donor_credit_use_custom', true );
    $custom_intro = get_post_meta( $post->ID, '_ci_donor_credit_intro', true );
    $custom_names = get_post_meta( $post->ID, '_ci_donor_credit_names', true );
    $custom_link_text = get_post_meta( $post->ID, '_ci_donor_credit_link_text', true );
    $custom_link_url = get_post_meta( $post->ID, '_ci_donor_credit_link_url', true );
    
    // Default values (hardcoded - can be customized per post)
    $default_intro = 'The Independent is made possible by giving from';
    $default_names = 'BioMed Realty and others';
    $default_link_text = 'See a list of public givers';
    $default_link_url = home_url( '/givers' );
    ?>
    <div style="background: #fff; padding: 15px; border: 1px solid #c3c4c7; margin-bottom: 15px;">
        <h3 style="margin-top: 0;"><?php _e( 'Donor Credit Box Settings', 'cambridge-independent' ); ?></h3>
        <p>
            <label>
                <input type="checkbox" 
                       name="ci_donor_credit_use_custom" 
                       value="1" 
                       id="ci_donor_credit_use_custom"
                       <?php checked( $use_custom, '1' ); ?> />
                <strong><?php _e( 'Use custom donor credit for this post', 'cambridge-independent' ); ?></strong>
            </label>
        </p>
        <p class="description">
            <?php _e( '✓ Check this box to customize the donor credit text for this specific post.', 'cambridge-independent'); ?><br>
            <?php _e( '✓ If unchecked, the default donor credit text will be used.', 'cambridge-independent' ); ?>
        </p>
    </div>
    
    <div id="ci-donor-credit-custom-fields" style="<?php echo $use_custom ? '' : 'display: none;'; ?> margin-top: 20px; padding: 15px; background: #f9f9f9; border: 1px solid #ddd;">
        <h4 style="margin-top: 0;"><?php _e( 'Custom Donor Credit Text', 'cambridge-independent' ); ?></h4>
        <table class="form-table" style="margin-top: 10px;">
            <tr>
                <th scope="row">
                    <label for="ci_donor_credit_intro"><?php _e( 'Intro Text', 'cambridge-independent' ); ?></label>
                </th>
                <td>
                    <input type="text" 
                           id="ci_donor_credit_intro" 
                           name="ci_donor_credit_intro" 
                           value="<?php echo esc_attr( $custom_intro ); ?>" 
                           class="regular-text" 
                           placeholder="<?php echo esc_attr( $default_intro ); ?>" />
                    <p class="description"><?php _e( 'Example: "The Independent is made possible by giving from"', 'cambridge-independent' ); ?></p>
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="ci_donor_credit_names"><?php _e( 'Donor Names', 'cambridge-independent' ); ?></label>
                </th>
                <td>
                    <textarea id="ci_donor_credit_names" 
                              name="ci_donor_credit_names" 
                              rows="3" 
                              class="large-text" 
                              placeholder="<?php echo esc_attr( $default_names ); ?>"><?php echo esc_textarea( $custom_names ); ?></textarea>
                    <p class="description">
                        <?php _e( 'Enter donor names. Multiple donors can be separated by commas (e.g., "BioMed Realty, Company A, Company B"). Names will appear in bold.', 'cambridge-independent' ); ?>
                    </p>
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="ci_donor_credit_link_text"><?php _e( 'Link Text (Optional)', 'cambridge-independent' ); ?></label>
                </th>
                <td>
                    <input type="text" 
                           id="ci_donor_credit_link_text" 
                           name="ci_donor_credit_link_text" 
                           value="<?php echo esc_attr( $custom_link_text ); ?>" 
                           class="regular-text" 
                           placeholder="<?php echo esc_attr( $default_link_text ); ?>" />
                    <p class="description"><?php _e( 'Example: "See a list of public givers"', 'cambridge-independent' ); ?></p>
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="ci_donor_credit_link_url"><?php _e( 'Link URL (Optional)', 'cambridge-independent' ); ?></label>
                </th>
                <td>
                    <input type="url" 
                           id="ci_donor_credit_link_url" 
                           name="ci_donor_credit_link_url" 
                           value="<?php echo esc_url( $custom_link_url ); ?>" 
                           class="regular-text" 
                           placeholder="<?php echo esc_url( $default_link_url ); ?>" />
                    <p class="description"><?php _e( 'Example: "/givers" or full URL', 'cambridge-independent' ); ?></p>
                </td>
            </tr>
        </table>
        
        <div style="margin-top: 15px; padding: 10px; background: #fff; border-left: 4px solid #2271b1;">
            <strong><?php _e( 'Preview:', 'cambridge-independent' ); ?></strong>
            <p style="margin: 5px 0 0 0; font-style: italic; color: #666;">
                <?php 
                $preview_intro = ! empty( $custom_intro ) ? $custom_intro : $default_intro;
                $preview_names = ! empty( $custom_names ) ? $custom_names : $default_names;
                $preview_link = ! empty( $custom_link_text ) ? $custom_link_text : $default_link_text;
                echo esc_html( $preview_intro . ' ' . $preview_names . '. ' . $preview_link );
                ?>
            </p>
        </div>
    </div>
    
    <script>
    (function() {
        const checkbox = document.getElementById('ci_donor_credit_use_custom');
        const fields = document.getElementById('ci-donor-credit-custom-fields');
        
        if (checkbox && fields) {
            checkbox.addEventListener('change', function() {
                fields.style.display = this.checked ? 'block' : 'none';
            });
        }
    })();
    </script>
    <?php
}

/**
 * Save Donor Credit Meta Box Data
 */
function cambridge_independent_save_donor_credit_meta_box( $post_id ) {
    // Check nonce
    if ( ! isset( $_POST['cambridge_independent_donor_credit_meta_box_nonce'] ) || 
         ! wp_verify_nonce( $_POST['cambridge_independent_donor_credit_meta_box_nonce'], 'cambridge_independent_donor_credit_meta_box' ) ) {
        return;
    }
    
    // Check autosave
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }
    
    // Check permissions
    if ( ! current_user_can( 'edit_post', $post_id ) ) {
        return;
    }
    
    // Save use custom checkbox
    $use_custom = isset( $_POST['ci_donor_credit_use_custom'] ) ? '1' : '0';
    update_post_meta( $post_id, '_ci_donor_credit_use_custom', $use_custom );
    
    // Save custom fields if use custom is checked
    if ( $use_custom === '1' ) {
        if ( isset( $_POST['ci_donor_credit_intro'] ) ) {
            update_post_meta( $post_id, '_ci_donor_credit_intro', sanitize_text_field( $_POST['ci_donor_credit_intro'] ) );
        }
        if ( isset( $_POST['ci_donor_credit_names'] ) ) {
            update_post_meta( $post_id, '_ci_donor_credit_names', sanitize_textarea_field( $_POST['ci_donor_credit_names'] ) );
        }
        if ( isset( $_POST['ci_donor_credit_link_text'] ) ) {
            update_post_meta( $post_id, '_ci_donor_credit_link_text', sanitize_text_field( $_POST['ci_donor_credit_link_text'] ) );
        }
        if ( isset( $_POST['ci_donor_credit_link_url'] ) ) {
            update_post_meta( $post_id, '_ci_donor_credit_link_url', esc_url_raw( $_POST['ci_donor_credit_link_url'] ) );
        }
    } else {
        // Remove custom fields if not using custom
        delete_post_meta( $post_id, '_ci_donor_credit_intro' );
        delete_post_meta( $post_id, '_ci_donor_credit_names' );
        delete_post_meta( $post_id, '_ci_donor_credit_link_text' );
        delete_post_meta( $post_id, '_ci_donor_credit_link_url' );
    }
}
add_action( 'save_post', 'cambridge_independent_save_donor_credit_meta_box' );

/**
 * Get Donor Credit Data for Post
 * Returns custom post data if available, otherwise returns default settings
 */
function cambridge_independent_get_donor_credit_data( $post_id = null ) {
    if ( ! $post_id ) {
        $post_id = get_the_ID();
    }
    
    $use_custom = get_post_meta( $post_id, '_ci_donor_credit_use_custom', true );
    
    if ( $use_custom === '1' ) {
        // Use custom post data
        $intro = get_post_meta( $post_id, '_ci_donor_credit_intro', true );
        $names = get_post_meta( $post_id, '_ci_donor_credit_names', true );
        $link_text = get_post_meta( $post_id, '_ci_donor_credit_link_text', true );
        $link_url = get_post_meta( $post_id, '_ci_donor_credit_link_url', true );
        
        // Fallback to defaults if custom fields are empty
        if ( empty( $intro ) ) {
            $intro = 'The Independent is made possible by giving from';
        }
        if ( empty( $names ) ) {
            $names = 'BioMed Realty and others';
        }
        if ( empty( $link_text ) ) {
            $link_text = 'See a list of public givers';
        }
        if ( empty( $link_url ) ) {
            $link_url = home_url( '/givers' );
        }
    } else {
        // Use default values (hardcoded)
        $intro = 'The Independent is made possible by giving from';
        $names = 'BioMed Realty and others';
        $link_text = 'See a list of public givers';
        $link_url = home_url( '/givers' );
    }
    
    return array(
        'intro' => $intro,
        'names' => $names,
        'link_text' => $link_text,
        'link_url' => $link_url,
    );
}

/**
 * Shortcode for SIDEBAR section
 * Usage: [sidebar]
 */
function cambridge_independent_sidebar_shortcode( $atts ) {
    // Only work on single posts
    if ( ! is_singular( 'post' ) ) {
        return '';
    }
    
    return cambridge_independent_build_single_related_story_html();
}
add_shortcode( 'sidebar', 'cambridge_independent_sidebar_shortcode' );

/**
 * Shortcode for RELATED section
 * Usage: [related]
 */
function cambridge_independent_related_shortcode( $atts ) {
    // Only work on single posts
    if ( ! is_singular( 'post' ) ) {
        return '';
    }
    
    return cambridge_independent_build_related_posts_html();
}
add_shortcode( 'related', 'cambridge_independent_related_shortcode' );

/**
 * Build Single Related Story Box HTML
 */
function cambridge_independent_build_single_related_story_html( $post_id = null ) {
    if ( ! $post_id ) {
        $post_id = get_the_ID();
    }
    
    $categories = wp_get_post_categories( $post_id );
    
    if ( empty( $categories ) ) {
        return '';
    }
    
    $related_query = new WP_Query( array(
        'post_type'      => 'post',
        'posts_per_page' => 1,
        'category__in'   => $categories,
        'post__not_in'   => array( $post_id ),
        'orderby'         => 'date',
        'order'           => 'DESC',
    ) );
    
    if ( ! $related_query->have_posts() ) {
        wp_reset_postdata();
        return '';
    }
    
    $related_query->the_post();
    $story_html = '<div class="related-story-box">';
    $story_html .= '<div class="related-story-heading">SIDEBAR</div>';
    $story_html .= '<div class="related-story-title">';
    $story_html .= '<a href="' . esc_url( get_permalink() ) . '" class="related-story-link">';
    $story_html .= esc_html( get_the_title() );
    $story_html .= '</a>';
    $story_html .= '</div>';
    $story_html .= '</div>';
    
    wp_reset_postdata();
    
    return $story_html;
}

/**
 * Build RELATED Posts Section HTML
 */
function cambridge_independent_build_related_posts_html( $post_id = null ) {
    if ( ! $post_id ) {
        $post_id = get_the_ID();
    }
    
    $categories = wp_get_post_categories( $post_id );
    
    if ( empty( $categories ) ) {
        return '';
    }
    
    $related_query = new WP_Query( array(
        'post_type'      => 'post',
        'posts_per_page' => 5,
        'category__in'   => $categories,
        'post__not_in'   => array( $post_id ),
        'orderby'         => 'date',
        'order'           => 'DESC',
    ) );
    
    if ( ! $related_query->have_posts() ) {
        wp_reset_postdata();
        return '';
    }
    
    $related_html = '<div class="related-posts-section">';
    $related_html .= '<h3 class="related-posts-heading">RELATED</h3>';
    $related_html .= '<ul class="related-posts-list">';
    
    while ( $related_query->have_posts() ) {
        $related_query->the_post();
        $related_html .= '<li class="related-post-item">';
        $related_html .= '<a href="' . esc_url( get_permalink() ) . '" class="related-post-link">';
        $related_html .= esc_html( get_the_title() );
        $related_html .= '</a>';
        $related_html .= '</li>';
    }
    
    wp_reset_postdata();
    
    $related_html .= '</ul>';
    $related_html .= '</div>';
    
    return $related_html;
}

/**
 * Insert Donor Credit Box and RELATED Posts in the middle of post content
 */
function cambridge_independent_insert_donor_credit_in_content( $content ) {
    // Only on single posts
    if ( ! is_singular( 'post' ) || is_admin() ) {
        return $content;
    }
    
    $post_id = get_the_ID();
    
    // Get donor data
    $donor_data = cambridge_independent_get_donor_credit_data( $post_id );
    
    // Build donor box HTML
    $donor_box = '';
    if ( ! empty( $donor_data['intro'] ) && ! empty( $donor_data['names'] ) ) {
        $donor_box = '<div class="donor-credit-box">';
        $donor_box .= '<div class="donor-intro">' . esc_html( $donor_data['intro'] ) . ' ';
        
        // Support multiple donors (comma-separated)
        $donor_names_array = array_map( 'trim', explode( ',', $donor_data['names'] ) );
        $donor_names_html = array();
        foreach ( $donor_names_array as $name ) {
            if ( ! empty( $name ) ) {
                $donor_names_html[] = '<span class="donor-name">' . esc_html( $name ) . '</span>';
            }
        }
        
        if ( ! empty( $donor_names_html ) ) {
            // Join multiple donors with commas and "and" for last one
            if ( count( $donor_names_html ) > 1 ) {
                $last_name = array_pop( $donor_names_html );
                $donor_box .= implode( ', ', $donor_names_html ) . ' <span class="donor-and-text">and</span> ' . $last_name;
            } else {
                // Check if the name contains "and others" or similar
                $name_text = strip_tags( $donor_names_html[0] );
                if ( preg_match( '/^(.+?)\s+(and\s+others?)$/i', $name_text, $matches ) ) {
                    // Split donor name and "and others" part
                    $donor_box .= '<span class="donor-name">' . esc_html( trim( $matches[1] ) ) . '</span> <span class="donor-and-text">' . esc_html( trim( $matches[2] ) ) . '</span>';
                } else {
                    $donor_box .= $donor_names_html[0];
                }
            }
        }
        
        $donor_box .= '.';
        
        if ( ! empty( $donor_data['link_text'] ) && ! empty( $donor_data['link_url'] ) ) {
            $donor_box .= '<br><a href="' . esc_url( $donor_data['link_url'] ) . '" class="donor-link">' . esc_html( $donor_data['link_text'] ) . '</a>';
        }
        $donor_box .= '</div>';
        $donor_box .= '</div>';
    }
    
    // Check if shortcodes are already in content - if yes, skip automatic insertion
    $has_sidebar_shortcode = has_shortcode( $content, 'sidebar' );
    $has_related_shortcode = has_shortcode( $content, 'related' );
    
    // If shortcodes exist, process them and return (no automatic insertion)
    if ( $has_sidebar_shortcode || $has_related_shortcode ) {
        // Shortcodes will be processed by WordPress automatically
        return $content;
    }
    
    // Build single related story box HTML
    $single_story_box = cambridge_independent_build_single_related_story_html( $post_id );
    
    // Build RELATED posts HTML
    $related_html = cambridge_independent_build_related_posts_html( $post_id );
    
    if ( empty( $donor_box ) && empty( $single_story_box ) && empty( $related_html ) ) {
        return $content;
    }
    
    // Split content into paragraphs for insertion
    $paragraphs = preg_split( '/(<\/p>)/', $content, -1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY );
    
    // Count actual paragraphs
    $para_count = 0;
    foreach ( $paragraphs as $para ) {
        if ( preg_match( '/<p[^>]*>/', $para ) ) {
            $para_count++;
        }
    }
    
    if ( $para_count > 2 ) {
        // Insert donor box after approximately 40% of paragraphs (middle)
        if ( ! empty( $donor_box ) ) {
            $donor_target_para = max( 1, floor( $para_count * 0.4 ) ); // 40% position
            $current_para = 0;
            $donor_insert_pos = -1;
            
            for ( $i = 0; $i < count( $paragraphs ); $i++ ) {
                if ( preg_match( '/<p[^>]*>/', $paragraphs[$i] ) ) {
                    $current_para++;
                    if ( $current_para === $donor_target_para && strpos( $paragraphs[$i], '</p>' ) !== false ) {
                        $donor_insert_pos = $i + 1;
                        break;
                    }
                }
            }
            
            if ( $donor_insert_pos > 0 && $donor_insert_pos < count( $paragraphs ) ) {
                array_splice( $paragraphs, $donor_insert_pos, 0, $donor_box );
                $content = implode( '', $paragraphs );
            } else {
                // Fallback: insert after first paragraph
                $content = preg_replace( '/(<\/p>)/', '$1' . $donor_box, $content, 1 );
            }
        }
        
        // Re-split content if donor box was inserted (to get updated paragraph positions)
        if ( ! empty( $donor_box ) ) {
            $paragraphs = preg_split( '/(<\/p>)/', $content, -1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY );
            // Recount paragraphs after donor box insertion
            $para_count = 0;
            foreach ( $paragraphs as $para ) {
                if ( preg_match( '/<p[^>]*>/', $para ) ) {
                    $para_count++;
                }
            }
        }
        
        // Insert SIDEBAR and RELATED sections after every 3 paragraphs dynamically
        // First, find all positions where we need to insert sections
        $insert_positions = array();
        $current_para = 0;
        $section_counter = 0; // To alternate between SIDEBAR and RELATED
        
        // Find all paragraph closing positions for insertion
        for ( $i = 0; $i < count( $paragraphs ); $i++ ) {
            if ( preg_match( '/<p[^>]*>/', $paragraphs[$i] ) ) {
                $current_para++;
                // After every 3rd paragraph (3, 6, 9, 12, etc.) but not the last paragraph
                if ( $current_para % 3 === 0 && $current_para < $para_count ) {
                    // Check if this paragraph has a closing tag
                    if ( strpos( $paragraphs[$i], '</p>' ) !== false ) {
                        $insert_positions[] = array(
                            'position' => $i + 1,
                            'para_num' => $current_para,
                            'section_type' => ( $section_counter % 2 === 0 ) ? 'sidebar' : 'related'
                        );
                        $section_counter++;
                    }
                }
            }
        }
        
        // Insert sections in REVERSE order to maintain correct positions
        // This prevents position shifting when we insert elements
        if ( ! empty( $insert_positions ) ) {
            for ( $i = count( $insert_positions ) - 1; $i >= 0; $i-- ) {
                $insert_info = $insert_positions[$i];
                $insert_pos = $insert_info['position'];
                $section_type = $insert_info['section_type'];
                
                if ( $insert_pos > 0 && $insert_pos < count( $paragraphs ) ) {
                    if ( $section_type === 'sidebar' && ! empty( $single_story_box ) ) {
                        array_splice( $paragraphs, $insert_pos, 0, $single_story_box );
                    } elseif ( $section_type === 'related' && ! empty( $related_html ) ) {
                        array_splice( $paragraphs, $insert_pos, 0, $related_html );
                    }
                }
            }
            $content = implode( '', $paragraphs );
        }
    } elseif ( $para_count > 0 ) {
        // If 1-2 paragraphs, insert donor box after first paragraph
        if ( ! empty( $donor_box ) && $para_count >= 1 ) {
            $content = preg_replace( '/(<\/p>)/', '$1' . $donor_box, $content, 1 );
        }
        // Insert single related story box after donor box or after first paragraph
        if ( ! empty( $single_story_box ) ) {
            if ( ! empty( $donor_box ) ) {
                // Insert after donor box
                $content = preg_replace( '/(<\/div><\/div>)/', '$1' . $single_story_box, $content, 1 );
            } else {
                // Insert after first paragraph
                $content = preg_replace( '/(<\/p>)/', '$1' . $single_story_box, $content, 1 );
            }
        }
        // Insert RELATED section right before the last paragraph
        if ( ! empty( $related_html ) ) {
            // For 1-2 paragraphs, insert before the last paragraph
            if ( $para_count > 1 ) {
                // Find the last paragraph opening tag
                $matches = array();
                preg_match_all( '/<p[^>]*>/', $content, $matches, PREG_OFFSET_CAPTURE );
                if ( ! empty( $matches[0] ) && count( $matches[0] ) >= 2 ) {
                    // Get position of last paragraph opening tag
                    $last_para_tag = end( $matches[0] );
                    $last_para_pos = $last_para_tag[1];
                    // Insert RELATED section before the last paragraph
                    $content = substr_replace( $content, $related_html, $last_para_pos, 0 );
                } else {
                    // Fallback: append at end
                    $content .= $related_html;
                }
            } else {
                // If only 1 paragraph, insert before it
                $content = preg_replace( '/(<p[^>]*>)/', $related_html . '$1', $content, 1 );
            }
        }
    } else {
        // If no paragraphs, append all at the end
        if ( ! empty( $donor_box ) ) {
            $content .= $donor_box;
        }
        if ( ! empty( $single_story_box ) ) {
            $content .= $single_story_box;
        }
        if ( ! empty( $related_html ) ) {
            $content .= $related_html;
        }
    }
    
    return $content;
}
add_filter( 'the_content', 'cambridge_independent_insert_donor_credit_in_content', 20 );

