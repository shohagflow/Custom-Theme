<?php
/**
 * City Preference System
 * IP-based geolocation and content filtering for Cambridge/Somerville news
 *
 * @package Cambridge_Independent
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Add City Designation Meta Box to Post Editor
 */
function cambridge_independent_add_city_meta_box() {
    add_meta_box(
        'ci_city_designation',
        __( 'City Designation', 'cambridge-independent' ),
        'cambridge_independent_city_meta_box_callback',
        'post',
        'side',
        'default'
    );
}
add_action( 'add_meta_boxes', 'cambridge_independent_add_city_meta_box' );

/**
 * Meta Box Callback
 */
function cambridge_independent_city_meta_box_callback( $post ) {
    wp_nonce_field( 'cambridge_independent_city_meta_box', 'cambridge_independent_city_meta_box_nonce' );
    
    $city_designation = get_post_meta( $post->ID, '_ci_city_designation', true );
    if ( empty( $city_designation ) ) {
        $city_designation = 'regional'; // Default to regional
    }
    ?>
    <p>
        <label for="ci_city_designation">
            <strong><?php _e( 'Select City Designation:', 'cambridge-independent' ); ?></strong>
        </label>
    </p>
    <p>
        <select name="ci_city_designation" id="ci_city_designation" style="width: 100%;">
            <option value="cambridge" <?php selected( $city_designation, 'cambridge' ); ?>>
                <?php _e( 'Cambridge', 'cambridge-independent' ); ?>
            </option>
            <option value="somerville" <?php selected( $city_designation, 'somerville' ); ?>>
                <?php _e( 'Somerville', 'cambridge-independent' ); ?>
            </option>
            <option value="regional" <?php selected( $city_designation, 'regional' ); ?>>
                <?php _e( 'Regional (Both Cities)', 'cambridge-independent' ); ?>
            </option>
        </select>
    </p>
    <p class="description">
        <?php _e( 'Mark this post as Cambridge news, Somerville news, or Regional (applies to both cities). This is used for IP-based content filtering.', 'cambridge-independent' ); ?>
    </p>
    <?php
}

/**
 * Save City Designation Meta Box Data
 */
function cambridge_independent_save_city_meta_box( $post_id ) {
    // Check if nonce is set
    if ( ! isset( $_POST['cambridge_independent_city_meta_box_nonce'] ) ) {
        return;
    }
    
    // Verify nonce
    if ( ! wp_verify_nonce( $_POST['cambridge_independent_city_meta_box_nonce'], 'cambridge_independent_city_meta_box' ) ) {
        return;
    }
    
    // Check if autosave
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }
    
    // Check user permissions
    if ( ! current_user_can( 'edit_post', $post_id ) ) {
        return;
    }
    
    // Save city designation
    if ( isset( $_POST['ci_city_designation'] ) ) {
        $city_designation = sanitize_text_field( $_POST['ci_city_designation'] );
        if ( in_array( $city_designation, array( 'cambridge', 'somerville', 'regional' ) ) ) {
            update_post_meta( $post_id, '_ci_city_designation', $city_designation );
        }
    }
}
add_action( 'save_post', 'cambridge_independent_save_city_meta_box' );

/**
 * Get User's City Preference
 * Checks cookie/localStorage preference, falls back to IP geolocation
 */
function cambridge_independent_get_user_city_preference() {
    // First check if user has set a preference (via cookie)
    // Check both $_COOKIE and filter_input for better compatibility
    $cookie_value = '';
    if ( isset( $_COOKIE['ci_city_preference'] ) ) {
        $cookie_value = $_COOKIE['ci_city_preference'];
    } elseif ( filter_input( INPUT_COOKIE, 'ci_city_preference' ) ) {
        $cookie_value = filter_input( INPUT_COOKIE, 'ci_city_preference' );
    }
    
    if ( ! empty( $cookie_value ) ) {
        $preference = sanitize_text_field( $cookie_value );
        if ( in_array( $preference, array( 'cambridge', 'somerville', 'all' ) ) ) {
            // Debug log (remove in production)
            if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
                error_log( 'City Preference: Found in cookie - ' . $preference );
            }
            return $preference;
        }
    }
    
    // Fallback to IP-based geolocation
    $detected_city = cambridge_independent_detect_city_by_ip();
    if ( $detected_city ) {
        if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
            error_log( 'City Preference: Detected from IP - ' . $detected_city );
        }
        return $detected_city;
    }
    
    // Default to 'all' if nothing detected
    if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
        error_log( 'City Preference: Using default - all' );
    }
    return 'all';
}

/**
 * Detect City by IP Address
 * Uses free IP geolocation API
 */
function cambridge_independent_detect_city_by_ip() {
    $user_ip = cambridge_independent_get_user_ip();
    
    if ( empty( $user_ip ) || $user_ip === '127.0.0.1' || $user_ip === '::1' ) {
        return false; // Localhost, can't detect
    }
    
    // Use ipapi.co free API (no key required for basic usage)
    $api_url = 'https://ipapi.co/' . $user_ip . '/json/';
    
    $response = wp_remote_get( $api_url, array(
        'timeout' => 5,
        'sslverify' => true,
    ) );
    
    if ( is_wp_error( $response ) ) {
        return false;
    }
    
    $body = wp_remote_retrieve_body( $response );
    $data = json_decode( $body, true );
    
    if ( isset( $data['city'] ) ) {
        $city = strtolower( $data['city'] );
        
        // Check if city is Cambridge or Somerville
        if ( strpos( $city, 'cambridge' ) !== false ) {
            return 'cambridge';
        } elseif ( strpos( $city, 'somerville' ) !== false ) {
            return 'somerville';
        }
    }
    
    // Check state/region as fallback
    if ( isset( $data['region'] ) ) {
        $region = strtolower( $data['region'] );
        // Massachusetts - default to Cambridge area
        if ( $region === 'massachusetts' || $region === 'ma' ) {
            return 'cambridge'; // Default to Cambridge for MA residents
        }
    }
    
    return false;
}

/**
 * Get User IP Address
 */
function cambridge_independent_get_user_ip() {
    $ip_keys = array(
        'HTTP_CLIENT_IP',
        'HTTP_X_FORWARDED_FOR',
        'HTTP_X_FORWARDED',
        'HTTP_X_CLUSTER_CLIENT_IP',
        'HTTP_FORWARDED_FOR',
        'HTTP_FORWARDED',
        'REMOTE_ADDR',
    );
    
    foreach ( $ip_keys as $key ) {
        if ( array_key_exists( $key, $_SERVER ) === true ) {
            foreach ( explode( ',', $_SERVER[ $key ] ) as $ip ) {
                $ip = trim( $ip );
                if ( filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE ) !== false ) {
                    return $ip;
                }
            }
        }
    }
    
    return isset( $_SERVER['REMOTE_ADDR'] ) ? $_SERVER['REMOTE_ADDR'] : '';
}

/**
 * Filter Posts by City Preference
 * Modifies WP_Query to show posts based on user preference
 */
function cambridge_independent_filter_posts_by_city( $query ) {
    // Only on frontend, main query, and not admin
    if ( is_admin() || ! $query->is_main_query() ) {
        return;
    }
    
    // Don't filter single posts, pages, or events
    if ( is_singular() || is_page() ) {
        return;
    }
    
    // Only on homepage, archive, or category pages
    if ( ! ( is_home() || is_front_page() || is_archive() || is_category() || is_tag() ) ) {
        return;
    }
    
    $preference = cambridge_independent_get_user_city_preference();
    
    // If preference is 'all', show everything
    if ( $preference === 'all' ) {
        return;
    }
    
    // Get existing meta query
    $meta_query = $query->get( 'meta_query' );
    if ( ! is_array( $meta_query ) ) {
        $meta_query = array();
    }
    
    // Filter: Show only preferred city + regional posts (exclude other city)
    // Use meta_query to include preferred city and regional, exclude other city
    $other_city = ( $preference === 'cambridge' ) ? 'somerville' : 'cambridge';
    
    $city_meta_query = array(
        'relation' => 'OR',
        // Preferred city posts only
        array(
            'key' => '_ci_city_designation',
            'value' => $preference,
            'compare' => '=',
        ),
        // Regional posts (applies to both cities)
        array(
            'key' => '_ci_city_designation',
            'value' => 'regional',
            'compare' => '=',
        ),
        // Posts without city designation (backward compatibility - treat as regional)
        array(
            'key' => '_ci_city_designation',
            'compare' => 'NOT EXISTS',
        ),
    );
    
    // Add exclusion for other city using a separate meta_query
    // WordPress doesn't support != directly in OR, so we'll use a different approach
    // We'll filter after query using posts_results filter
    
    // If there are existing meta queries, combine them
    if ( ! empty( $meta_query ) ) {
        $meta_query = array(
            'relation' => 'AND',
            $meta_query,
            $city_meta_query,
        );
    } else {
        $meta_query = $city_meta_query;
    }
    
    $query->set( 'meta_query', $meta_query );
    
    // Store preference for post-filtering
    $query->set( 'ci_city_preference', $preference );
    $query->set( 'ci_exclude_city', $other_city );
    
    // Filter out excluded city posts after query runs
    add_filter( 'the_posts', 'cambridge_independent_exclude_other_city_posts', 10, 2 );
}
add_action( 'pre_get_posts', 'cambridge_independent_filter_posts_by_city' );

/**
 * Exclude other city posts from results
 */
function cambridge_independent_exclude_other_city_posts( $posts, $query ) {
    if ( is_admin() ) {
        return $posts;
    }
    
    // Get exclude city from query or check preference directly
    $exclude_city = $query->get( 'ci_exclude_city' );
    if ( ! $exclude_city ) {
        // Try to get from preference
        $preference = cambridge_independent_get_user_city_preference();
        if ( $preference === 'all' ) {
            return $posts;
        }
        $exclude_city = ( $preference === 'cambridge' ) ? 'somerville' : 'cambridge';
    }
    
    // Filter out posts marked for the excluded city
    $filtered_posts = array();
    foreach ( $posts as $post ) {
        $city_designation = get_post_meta( $post->ID, '_ci_city_designation', true );
        
        // Include if: preferred city, regional, or no designation
        // Exclude if: other city
        if ( $city_designation !== $exclude_city ) {
            $filtered_posts[] = $post;
        }
    }
    
    return $filtered_posts;
}

/**
 * Set City Preference Cookie
 * Called via AJAX when user selects preference
 */
function cambridge_independent_set_city_preference() {
    check_ajax_referer( 'ci_city_preference_nonce', 'nonce' );
    
    $preference = isset( $_POST['preference'] ) ? sanitize_text_field( $_POST['preference'] ) : 'all';
    
    if ( ! in_array( $preference, array( 'cambridge', 'somerville', 'all' ) ) ) {
        wp_send_json_error( array( 'message' => 'Invalid preference' ) );
    }
    
    // Set cookie for 30 days with proper path and domain
    $cookie_path = '/';
    $cookie_domain = '';
    $cookie_expire = time() + ( 30 * DAY_IN_SECONDS );
    $cookie_secure = is_ssl();
    $cookie_httponly = false;
    
    setcookie( 'ci_city_preference', $preference, $cookie_expire, $cookie_path, $cookie_domain, $cookie_secure, $cookie_httponly );
    
    // Also set in $_COOKIE for immediate access
    $_COOKIE['ci_city_preference'] = $preference;
    
    wp_send_json_success( array( 
        'preference' => $preference,
        'message' => 'Preference set successfully'
    ) );
}
add_action( 'wp_ajax_set_city_preference', 'cambridge_independent_set_city_preference' );
add_action( 'wp_ajax_nopriv_set_city_preference', 'cambridge_independent_set_city_preference' );

/**
 * Get detected city preference (for first visit auto-detection)
 * Returns the preference detected from IP or cookie, without setting it
 */
function cambridge_independent_get_detected_preference() {
    check_ajax_referer( 'ci_city_preference_nonce', 'nonce' );
    
    // Get detected preference (this will use IP detection if no cookie exists)
    $preference = cambridge_independent_get_user_city_preference();
    
    wp_send_json_success( array( 
        'preference' => $preference,
        'message' => 'Preference detected successfully'
    ) );
}
add_action( 'wp_ajax_get_detected_preference', 'cambridge_independent_get_detected_preference' );
add_action( 'wp_ajax_nopriv_get_detected_preference', 'cambridge_independent_get_detected_preference' );

