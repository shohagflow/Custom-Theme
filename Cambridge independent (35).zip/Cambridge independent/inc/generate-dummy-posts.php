<?php
/**
 * Generate Dummy Posts
 * 
 * This file can be accessed via: wp-admin/admin.php?page=cambridge-independent-generate-posts
 * Or run directly via WP-CLI: wp eval-file inc/generate-dummy-posts.php
 *
 * @package Cambridge_Independent
 */

if ( ! defined( 'ABSPATH' ) ) {
    // If running via WP-CLI or direct access
    if ( ! defined( 'WP_CLI' ) && ! current_user_can( 'manage_options' ) ) {
        die( 'Access denied.' );
    }
}

/**
 * Download and attach a featured image to a post
 */
function cambridge_independent_attach_featured_image( $post_id, $image_url, $title ) {
    require_once( ABSPATH . 'wp-admin/includes/file.php' );
    require_once( ABSPATH . 'wp-admin/includes/media.php' );
    require_once( ABSPATH . 'wp-admin/includes/image.php' );
    
    // Download image
    $tmp = download_url( $image_url );
    
    if ( is_wp_error( $tmp ) ) {
        return false;
    }
    
    // Prepare file array
    $file_array = array(
        'name'     => sanitize_file_name( $title ) . '.jpg',
        'tmp_name' => $tmp,
    );
    
    // Upload image
    $attachment_id = media_handle_sideload( $file_array, $post_id );
    
    // Clean up temp file
    @unlink( $tmp );
    
    if ( is_wp_error( $attachment_id ) ) {
        return false;
    }
    
    // Set as featured image
    set_post_thumbnail( $post_id, $attachment_id );
    
    return $attachment_id;
}

/**
 * Get placeholder image URL based on category
 */
function cambridge_independent_get_placeholder_image( $category, $width = 800, $height = 600, $post_id = null ) {
    // Use Picsum for reliable placeholder images with random seed
    // Create unique seed based on category and post ID (if provided)
    $seed_string = $category;
    if ( $post_id ) {
        $seed_string .= '_' . $post_id;
    } else {
        $seed_string .= '_' . time() . '_' . rand( 1000, 9999 );
    }
    $seed = md5( $seed_string );
    return "https://picsum.photos/seed/{$seed}/{$width}/{$height}";
}

/**
 * Get post's primary category name
 */
function cambridge_independent_get_post_category( $post_id ) {
    $categories = get_the_category( $post_id );
    
    if ( ! empty( $categories ) ) {
        // Return the first category name
        return $categories[0]->name;
    }
    
    // Default to News if no category
    return 'News';
}

/**
 * Add thumbnails to existing posts without featured images
 */
function cambridge_independent_add_thumbnails_to_existing_posts() {
    // Check if user has permission
    if ( ! current_user_can( 'manage_options' ) ) {
        return new WP_Error( 'no_permission', 'You do not have permission to add thumbnails.' );
    }

    // Get all published posts without featured images
    $args = array(
        'post_type'      => 'post',
        'post_status'    => 'publish',
        'posts_per_page' => -1,
        'meta_query'     => array(
            array(
                'key'     => '_thumbnail_id',
                'compare' => 'NOT EXISTS',
            ),
        ),
    );

    $query = new WP_Query( $args );
    
    $processed = 0;
    $errors = array();
    $skipped = 0;

    if ( $query->have_posts() ) {
        while ( $query->have_posts() ) {
            $query->the_post();
            $post_id = get_the_ID();
            
            // Skip if already has thumbnail
            if ( has_post_thumbnail( $post_id ) ) {
                $skipped++;
                continue;
            }
            
            // Get post category
            $category = cambridge_independent_get_post_category( $post_id );
            
            // Get placeholder image URL
            $image_url = cambridge_independent_get_placeholder_image( $category, 800, 600, $post_id );
            
            // Attach featured image
            $image_attached = cambridge_independent_attach_featured_image( $post_id, $image_url, get_the_title() );
            
            if ( $image_attached ) {
                $processed++;
            } else {
                $errors[] = "Failed to attach image to post: " . get_the_title() . " (ID: {$post_id})";
            }
        }
        wp_reset_postdata();
    }

    // Return results
    $result = array(
        'success'  => true,
        'processed' => $processed,
        'skipped'   => $skipped,
        'total'     => $query->found_posts,
        'errors'    => $errors,
    );

    return $result;
}

/**
 * Delete all posts (with option to keep certain posts)
 */
function cambridge_independent_delete_all_posts( $keep_recent = 0 ) {
    // Check if user has permission
    if ( ! current_user_can( 'manage_options' ) ) {
        return new WP_Error( 'no_permission', 'You do not have permission to delete posts.' );
    }

    // Get all published posts
    $args = array(
        'post_type'      => 'post',
        'post_status'    => 'publish',
        'posts_per_page' => -1,
        'orderby'        => 'date',
        'order'          => 'DESC',
    );

    $query = new WP_Query( $args );
    
    $deleted = 0;
    $errors = array();
    $kept = 0;

    if ( $query->have_posts() ) {
        $post_count = 0;
        while ( $query->have_posts() ) {
            $query->the_post();
            $post_id = get_the_ID();
            
            // Keep the most recent posts if specified
            if ( $keep_recent > 0 && $post_count < $keep_recent ) {
                $kept++;
                $post_count++;
                continue;
            }
            
            // Delete post (this also deletes attachments and meta)
            $result = wp_delete_post( $post_id, true );
            
            if ( $result ) {
                $deleted++;
            } else {
                $errors[] = "Failed to delete post: " . get_the_title() . " (ID: {$post_id})";
            }
        }
        wp_reset_postdata();
    }

    // Return results
    $result = array(
        'success'  => true,
        'deleted'  => $deleted,
        'kept'     => $kept,
        'total'    => $query->found_posts,
        'errors'   => $errors,
    );

    return $result;
}

/**
 * Generate dummy posts for Cambridge Independent
 */
function cambridge_independent_generate_dummy_posts() {
    // Check if user has permission
    if ( ! current_user_can( 'manage_options' ) ) {
        return new WP_Error( 'no_permission', 'You do not have permission to generate posts.' );
    }

    // Sample posts data - Updated to use menu categories: News, Arts, Community, Resources, Events
    $dummy_posts = array(
        // News Posts
        array(
            'title' => 'New Development Project Approved for Central Square',
            'content' => 'The Cambridge Planning Board has approved a major mixed-use development project in Central Square. The $50 million project will include residential units, retail space, and community facilities. Local residents have expressed mixed reactions to the proposal, with some welcoming the economic boost and others concerned about gentrification and increased traffic.',
            'excerpt' => 'The Cambridge Planning Board has approved a major mixed-use development project in Central Square that will transform the area.',
            'category' => 'News',
            'date' => '-1 day',
        ),
        array(
            'title' => 'City Council Votes on Affordable Housing Initiative',
            'content' => 'The Cambridge City Council voted 7-2 in favor of a new affordable housing initiative that will allocate $20 million over the next five years. The program aims to create 500 new affordable housing units and provide rental assistance to low-income families. Council members debated the funding sources and implementation timeline during a three-hour session.',
            'excerpt' => 'Cambridge City Council approves $20 million affordable housing initiative to create 500 new units.',
            'category' => 'News',
            'date' => '-2 days',
        ),
        array(
            'title' => 'New Bike Lane Project Connects Cambridge to Somerville',
            'content' => 'Construction has begun on a new protected bike lane that will connect Cambridge to Somerville, providing safer cycling routes for commuters. The project, funded by a state grant, includes new bike parking facilities and improved intersections. Cyclists and transportation advocates have praised the initiative as a step toward more sustainable transportation.',
            'excerpt' => 'Construction begins on protected bike lane connecting Cambridge to Somerville, improving cycling infrastructure.',
            'category' => 'News',
            'date' => '-3 days',
        ),
        array(
            'title' => 'Local School District Receives Grant for Arts Education',
            'content' => 'The Cambridge Public Schools have received a $500,000 grant to expand arts education programs across the district. The funding will support music, visual arts, theater, and dance programs in elementary and middle schools. The grant comes from a national foundation focused on arts education.',
            'excerpt' => 'Cambridge Public Schools receive $500,000 grant to expand arts education programs.',
            'category' => 'News',
            'date' => '-4 days',
        ),
        array(
            'title' => 'Tech Startup Raises $10M in Series A Funding',
            'content' => 'A Cambridge-based AI startup has successfully raised $10 million in Series A funding from local venture capital firms. The company, which specializes in healthcare technology, plans to use the funds to expand its team and develop new products. The funding round was led by prominent Boston-area investors.',
            'excerpt' => 'Local AI startup secures $10 million in Series A funding to expand healthcare technology offerings.',
            'category' => 'News',
            'date' => '-5 days',
        ),
        
        // Arts Posts
        array(
            'title' => 'Local Gallery Opens Exhibition Featuring Cambridge Artists',
            'content' => 'The Cambridge Arts Council Gallery has opened a new exhibition featuring works by 15 local artists. The show, titled "Urban Perspectives," explores themes of city life, community, and change. The exhibition runs through March and includes paintings, sculptures, and mixed-media installations. An opening reception will be held this Friday evening.',
            'excerpt' => 'New exhibition "Urban Perspectives" opens at Cambridge Arts Council Gallery featuring 15 local artists.',
            'category' => 'Arts',
            'date' => '-1 day',
        ),
        array(
            'title' => 'New Public Art Installation Unveiled in Harvard Square',
            'content' => 'A new public art installation has been unveiled in Harvard Square, created by a collaborative team of local artists. The sculpture, made from recycled materials, represents themes of community and sustainability. The installation is part of the city\'s ongoing public art program and will remain in place for the next two years.',
            'excerpt' => 'New public art installation unveiled in Harvard Square, created by local artists using recycled materials.',
            'category' => 'Arts',
            'date' => '-2 days',
        ),
        array(
            'title' => 'Local Theater Company Announces New Season',
            'content' => 'A Cambridge-based theater company has announced its upcoming season, featuring a mix of classic plays and contemporary works. The season includes productions of Shakespeare, modern dramas, and original works by local playwrights. The company, which performs at a historic theater, has been a fixture in the local arts scene for over 20 years.',
            'excerpt' => 'Local theater company announces new season featuring classic and contemporary plays.',
            'category' => 'Arts',
            'date' => '-3 days',
        ),
        array(
            'title' => 'Somerville Theatre Announces Spring Film Series',
            'content' => 'The historic Somerville Theatre has announced its spring film series, featuring classic films, independent cinema, and special events. The series includes screenings of restored films, director Q&A sessions, and themed movie nights. The theatre, which opened in 1914, continues to be a cultural hub for the community.',
            'excerpt' => 'Somerville Theatre announces spring film series with classic films, independent cinema, and special events.',
            'category' => 'Arts',
            'date' => '-4 days',
        ),
        array(
            'title' => 'Poetry Reading Event at Local Bookstore',
            'content' => 'A poetry reading event featuring local poets will be held this Saturday at an independent bookstore in Cambridge. The event, part of the store\'s monthly literary series, will include readings, book signings, and an open mic session. The bookstore has become a gathering place for writers and readers in the community.',
            'excerpt' => 'Local poets gather for reading event at independent bookstore, featuring readings and open mic session.',
            'category' => 'Arts',
            'date' => '-5 days',
        ),
        
        // Community Posts
        array(
            'title' => 'Community Garden Initiative Expands to New Neighborhoods',
            'content' => 'The Cambridge Community Garden program is expanding to three new neighborhoods, providing residents with space to grow their own food. The initiative, supported by the city and local organizations, aims to increase access to fresh produce and strengthen community connections. Applications for garden plots are now being accepted.',
            'excerpt' => 'Community garden program expands to three new neighborhoods, offering residents space to grow food.',
            'category' => 'Community',
            'date' => '-1 day',
        ),
        array(
            'title' => 'Local Business Owners Rally for Support During Winter Season',
            'content' => 'Small business owners in Cambridge and Somerville are coming together to support each other during the challenging winter months. A new initiative called "Shop Local Cambridge" has launched to encourage residents to support neighborhood businesses. The campaign includes special events, discounts, and a directory of participating businesses.',
            'excerpt' => 'Small business owners launch "Shop Local Cambridge" initiative to support neighborhood businesses during winter.',
            'category' => 'Community',
            'date' => '-2 days',
        ),
        array(
            'title' => 'Local Musicians Perform at Community Concert Series',
            'content' => 'The Cambridge Community Concert Series continues this weekend with performances by local musicians at various venues throughout the city. The series, now in its third year, showcases diverse musical genres from jazz to folk to electronic. All concerts are free and open to the public, with donations accepted to support the program.',
            'excerpt' => 'Cambridge Community Concert Series features local musicians performing at venues throughout the city.',
            'category' => 'Community',
            'date' => '-3 days',
        ),
        array(
            'title' => 'New Bookstore Opens in Porter Square',
            'content' => 'A new independent bookstore has opened in Porter Square, offering a curated selection of books, author events, and a cozy reading space. The store, owned by a former librarian, aims to be a community gathering place for book lovers. The opening has been welcomed by residents who have been without a local bookstore for several years.',
            'excerpt' => 'New independent bookstore opens in Porter Square, offering curated books and community events.',
            'category' => 'Community',
            'date' => '-4 days',
        ),
        array(
            'title' => 'Tech Companies Partner on Workforce Development Program',
            'content' => 'Several Cambridge-based tech companies have partnered with local community colleges to create a workforce development program. The initiative will provide training in technology skills and connect graduates with job opportunities. The program aims to address the skills gap in the tech industry while providing career pathways for local residents.',
            'excerpt' => 'Tech companies partner with community colleges on workforce development program for local residents.',
            'category' => 'Community',
            'date' => '-5 days',
        ),
        
        // Resources Posts
        array(
            'title' => 'New Farm-to-Table Restaurant Opens in Inman Square',
            'content' => 'A new farm-to-table restaurant has opened in Inman Square, focusing on locally sourced ingredients and seasonal menus. The restaurant, owned by a Cambridge native, features dishes inspired by New England cuisine with modern twists. The opening has generated excitement among food enthusiasts and supporters of local agriculture.',
            'excerpt' => 'New farm-to-table restaurant opens in Inman Square, featuring locally sourced ingredients and seasonal menus.',
            'category' => 'Resources',
            'date' => '-1 day',
        ),
        array(
            'title' => 'Local Farmers Market Returns for Winter Season',
            'content' => 'The Cambridge Winter Farmers Market has returned, offering fresh produce, baked goods, and artisanal products every Saturday. The indoor market, held at a community center, provides a space for local farmers and vendors to sell their products year-round. Shoppers can find everything from fresh vegetables to handmade cheeses to prepared foods.',
            'excerpt' => 'Cambridge Winter Farmers Market returns, offering fresh produce and local products every Saturday.',
            'category' => 'Resources',
            'date' => '-2 days',
        ),
        array(
            'title' => 'Coffee Shop Expands to Second Location',
            'content' => 'A popular local coffee shop has announced plans to open a second location in Somerville. The expansion comes after five years of success at their original Cambridge location. The new location will feature the same commitment to quality coffee, locally sourced pastries, and community atmosphere that has made the original shop a neighborhood favorite.',
            'excerpt' => 'Popular local coffee shop announces expansion to second location in Somerville.',
            'category' => 'Resources',
            'date' => '-3 days',
        ),
        array(
            'title' => 'Restaurant Week Returns to Cambridge and Somerville',
            'content' => 'Cambridge and Somerville Restaurant Week is back, featuring special prix-fixe menus at dozens of local restaurants. The event, which runs for two weeks, gives diners the opportunity to try new restaurants or revisit favorites at discounted prices. Participating restaurants range from casual cafes to upscale dining establishments.',
            'excerpt' => 'Restaurant Week returns to Cambridge and Somerville with special prix-fixe menus at local restaurants.',
            'category' => 'Resources',
            'date' => '-4 days',
        ),
        
        // Events Posts
        array(
            'title' => 'Food Truck Festival Coming to Cambridge',
            'content' => 'The annual Cambridge Food Truck Festival will return next month, featuring over 30 food trucks from across New England. The event, held in a city park, will include live music, family activities, and a wide variety of cuisines. The festival has become a popular summer tradition, drawing thousands of visitors each year.',
            'excerpt' => 'Annual Cambridge Food Truck Festival returns next month with over 30 food trucks and live entertainment.',
            'category' => 'Events',
            'date' => '-1 day',
        ),
        array(
            'title' => 'Spring Arts Festival Announced for Harvard Square',
            'content' => 'The annual Spring Arts Festival will take place in Harvard Square next month, featuring local artists, musicians, and performers. The festival includes art installations, live music stages, and interactive workshops for all ages. The event celebrates the vibrant arts community in Cambridge and Somerville.',
            'excerpt' => 'Spring Arts Festival announced for Harvard Square featuring local artists, musicians, and performers.',
            'category' => 'Events',
            'date' => '-2 days',
        ),
        array(
            'title' => 'Community Health Fair Scheduled for Next Weekend',
            'content' => 'A community health fair will be held next weekend at a local community center, offering free health screenings, wellness information, and resources for residents. The event is organized by local healthcare providers and community organizations. Services include blood pressure checks, nutrition counseling, and information about local health programs.',
            'excerpt' => 'Community health fair scheduled for next weekend offering free health screenings and wellness resources.',
            'category' => 'Events',
            'date' => '-3 days',
        ),
        array(
            'title' => 'Annual Neighborhood Block Party Returns',
            'content' => 'The annual neighborhood block party is returning to Central Square this summer, bringing together residents, local businesses, and community organizations. The event features food vendors, live entertainment, children\'s activities, and opportunities to connect with neighbors. The block party has become a beloved community tradition.',
            'excerpt' => 'Annual neighborhood block party returns to Central Square with food, entertainment, and community activities.',
            'category' => 'Events',
            'date' => '-4 days',
        ),
    );

    $created_posts = 0;
    $errors = array();

    // Get or create categories - Use menu categories: NEWS, ARTS, COMMUNITY, RESOURCES, EVENTS
    $categories = array();
    $category_names = array( 'News', 'Arts', 'Community', 'Resources', 'Events' );
    
    foreach ( $category_names as $cat_name ) {
        // Try to get category by slug (lowercase)
        $category = get_category_by_slug( strtolower( $cat_name ) );
        if ( ! $category ) {
            // Create category if it doesn't exist
            $category_id = wp_create_category( $cat_name );
            if ( is_wp_error( $category_id ) ) {
                $errors[] = "Failed to create category: {$cat_name}";
                continue;
            }
            $category = get_category( $category_id );
        }
        $categories[ $cat_name ] = $category->term_id;
    }

    // Create posts
    foreach ( $dummy_posts as $post_data ) {
        // Calculate post date
        $post_date = date( 'Y-m-d H:i:s', strtotime( $post_data['date'] ) );
        
        $post_args = array(
            'post_title'    => $post_data['title'],
            'post_content'  => $post_data['content'],
            'post_excerpt'  => $post_data['excerpt'],
            'post_status'   => 'publish',
            'post_date'     => $post_date,
            'post_author'   => 1, // Use first admin user
            'post_category' => array( $categories[ $post_data['category'] ] ),
        );

        $post_id = wp_insert_post( $post_args, true );

        if ( is_wp_error( $post_id ) ) {
            $errors[] = "Failed to create post: {$post_data['title']} - " . $post_id->get_error_message();
        } else {
            $created_posts++;
            
            // Attach featured image/thumbnail
            $image_url = cambridge_independent_get_placeholder_image( $post_data['category'], 800, 600, $post_id );
            $image_attached = cambridge_independent_attach_featured_image( $post_id, $image_url, $post_data['title'] );
            
            if ( ! $image_attached ) {
                $errors[] = "Failed to attach image to post: {$post_data['title']}";
            }
        }
    }

    // Return results
    $result = array(
        'success' => true,
        'created' => $created_posts,
        'total' => count( $dummy_posts ),
        'errors' => $errors,
    );

    return $result;
}

// If running directly (not via function call)
if ( basename( $_SERVER['PHP_SELF'] ) === basename( __FILE__ ) || ( defined( 'WP_CLI' ) && WP_CLI ) ) {
    // Load WordPress if not already loaded
    if ( ! defined( 'ABSPATH' ) ) {
        require_once( dirname( dirname( dirname( dirname( __FILE__ ) ) ) ) . '/wp-load.php' );
    }
    
    // Check for action parameter
    $action = isset( $_GET['action'] ) ? $_GET['action'] : 'generate';
    
    if ( $action === 'add_thumbnails' ) {
        $result = cambridge_independent_add_thumbnails_to_existing_posts();
        
        if ( defined( 'WP_CLI' ) && WP_CLI ) {
            if ( $result['success'] ) {
                WP_CLI::success( "Added thumbnails to {$result['processed']} posts. {$result['skipped']} posts already had thumbnails." );
                if ( ! empty( $result['errors'] ) ) {
                    foreach ( $result['errors'] as $error ) {
                        WP_CLI::warning( $error );
                    }
                }
            } else {
                WP_CLI::error( 'Failed to add thumbnails.' );
            }
        } else {
            // Direct access - return JSON
            header( 'Content-Type: application/json' );
            echo json_encode( $result );
            exit;
        }
    } else {
        $result = cambridge_independent_generate_dummy_posts();
        
        if ( defined( 'WP_CLI' ) && WP_CLI ) {
            if ( $result['success'] ) {
                WP_CLI::success( "Created {$result['created']} out of {$result['total']} posts." );
                if ( ! empty( $result['errors'] ) ) {
                    foreach ( $result['errors'] as $error ) {
                        WP_CLI::warning( $error );
                    }
                }
            } else {
                WP_CLI::error( 'Failed to generate posts.' );
            }
        } else {
            // Direct access - return JSON
            header( 'Content-Type: application/json' );
            echo json_encode( $result );
            exit;
        }
    }
}

