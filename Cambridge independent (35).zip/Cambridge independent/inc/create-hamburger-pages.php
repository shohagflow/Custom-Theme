<?php
/**
 * Create Hamburger Menu Pages
 * 
 * This file creates pages for all hamburger menu items
 * Can be accessed via: wp-admin/admin.php?page=cambridge-independent-generate-posts&action=create_pages
 * Or run directly via WP-CLI: wp eval-file inc/create-hamburger-pages.php
 *
 * @package Cambridge_Independent
 */

if ( ! defined( 'ABSPATH' ) ) {
    // If running via WP-CLI or direct access
    if ( ! defined( 'WP_CLI' ) && ! current_user_can( 'manage_options' ) ) {
        die( 'Access denied.' );
    }
}

/**
 * Create all hamburger menu pages
 */
function cambridge_independent_create_hamburger_pages() {
    $pages = array(
        array(
            'post_title'   => 'About the site',
            'post_name'    => 'about',
            'post_content' => '<h2>We\'re all in this together: About the site</h2>
            
<p>The Independent is intended to be an active part of an ecosystem that keeps Cambridge and Somerville thriving, especially in rough times. We believe in partnerships, mutual aid, connections and signal boosting. We want to help readers find what they need and organizations and businesses communicate with their audiences. We intend to have fun, share the delightful and joyous, and sometimes be a little weird. We want the arts to flourish and for people to feel heard. We want to be nimble, bringing items of interest to people as quickly as we responsibly can.</p>

<p>We would love The Independent to pay contributors what they need to help them live and stay in these expensive cities – but also have a cooperative aspect, inviting in those who want to offer their skills to the site because it brings them pleasure, or because it is their form of civic engagement.</p>

<p>A lot of these efforts will be modest and perhaps halting, because we have limited resources and only so many hours in the day. We want to do it all, but won\'t be able to. We will have to prioritize and evolve. You can support our mission: Please donate or give tax free, the bigger the donation the better! We also encourage people to take out classified and personal ads, and for businesses and organizations to take out display ads. We have special rates for people within the community.</p>

<p>To talk about any of these things, you can email the editor or call 617.230.9632. If there is no immediate pickup, your call will be returned as soon as possible.</p>',
            'post_status'  => 'publish',
            'post_type'    => 'page',
        ),
        array(
            'post_title'   => 'Send us a news tip',
            'post_name'    => 'news-tip',
            'post_content' => '<h2>Send us a news tip</h2>
            
<p>Do you have a story idea or news tip? We want to hear from you!</p>

<p>Our reporters are always looking for important stories happening in Cambridge and Somerville. Whether it\'s a breaking news event, a community issue, or an interesting local story, your tip could help us cover what matters most to our communities.</p>

<h3>How to submit a tip</h3>
<p>You can reach us at: <a href="mailto:editor@csindie.com?subject=News%20tip">editor@csindie.com</a> with the subject header "News tip."</p>

<p>When submitting a tip, please include:</p>
<ul>
    <li>What happened or what the story is about</li>
    <li>When and where it occurred</li>
    <li>Who is involved (if appropriate to share)</li>
    <li>Any relevant documents, photos, or links</li>
    <li>Your contact information (we will keep this confidential)</li>
</ul>

<h3>Confidentiality</h3>
<p>We respect the confidentiality of our sources. If you prefer to remain anonymous, please let us know, and we will protect your identity.</p>

<p>Thank you for helping us keep our communities informed!</p>',
            'post_status'  => 'publish',
            'post_type'    => 'page',
        ),
        array(
            'post_title'   => 'Send us a letter for publication online',
            'post_name'    => 'letter',
            'post_content' => '<h2>Send us a letter for publication online</h2>
            
<p>We welcome letters to the editor from our readers. Your voice matters, and we want to hear your perspective on issues affecting Cambridge and Somerville.</p>

<h3>Submission Guidelines</h3>
<ul>
    <li><strong>Length:</strong> Letters should be no more than 300 words.</li>
    <li><strong>Topic:</strong> Letters should address issues relevant to Cambridge, Somerville, or the broader community.</li>
    <li><strong>Contact Information:</strong> Please include your full name, city/town, and a phone number for verification (we will not publish your phone number).</li>
    <li><strong>Format:</strong> Submit your letter via email to: <a href="mailto:editor@csindie.com?subject=Letter%20for%20publication">editor@csindie.com</a> with the subject header "Letter for publication."</li>
</ul>

<h3>Editorial Policy</h3>
<p>We reserve the right to edit letters for length, clarity, and style. We may also choose not to publish letters that contain:</p>
<ul>
    <li>Personal attacks or defamatory statements</li>
    <li>Factual inaccuracies</li>
    <li>Content that is libelous or violates our community standards</li>
</ul>

<h3>Publication</h3>
<p>Letters selected for publication will appear on our website. Due to the volume of submissions, we cannot respond to every letter or guarantee publication.</p>

<p>Thank you for contributing to the community conversation!</p>',
            'post_status'  => 'publish',
            'post_type'    => 'page',
        ),
        array(
            'post_title'   => 'Advertise through us',
            'post_name'    => 'advertise',
            'post_content' => '<h2>Advertise through us</h2>
            
<p>Reach engaged readers in Cambridge and Somerville by advertising with The Cambridge Independent.</p>

<p>We offer an <strong>ad wizard</strong> to help you create and place your advertisement. Whether you\'re a business, organization, or individual, we can help you reach our community.</p>

<h3>Why Advertise With Us?</h3>
<ul>
    <li><strong>Local Audience:</strong> Connect with residents who are actively engaged in their communities.</li>
    <li><strong>Trusted Platform:</strong> Your message appears alongside trusted, independent journalism.</li>
    <li><strong>Targeted Reach:</strong> Reach readers who care about local news and community issues.</li>
    <li><strong>Flexible Options:</strong> We offer various advertising formats to fit your needs and budget.</li>
    <li><strong>Special Rates:</strong> We have special rates for people within the community.</li>
</ul>

<h3>Advertising Options</h3>
<p>We offer several advertising options including:</p>
<ul>
    <li>Display advertisements</li>
    <li>Classified ads</li>
    <li>Personal ads</li>
    <li>Banner advertisements</li>
    <li>Sponsored content</li>
    <li>Newsletter advertising</li>
    <li>Event listings</li>
    <li>Custom packages</li>
</ul>

<h3>Get Started</h3>
<p>To learn more about advertising opportunities, rates, and availability, please contact us at:</p>
<p><strong>Email:</strong> <a href="mailto:advertising@csindie.com">advertising@csindie.com</a></p>

<p>Or use our ad wizard to get started with creating and placing your advertisement.</p>

<p>We look forward to helping you reach our community!</p>',
            'post_status'  => 'publish',
            'post_type'    => 'page',
        ),
        array(
            'post_title'   => 'Donate to keep local journalism alive and improving or give tax free',
            'post_name'    => 'donate',
            'post_content' => '<h2>Donate to keep local journalism alive and improving (using WooCommerce and Gravity) or give tax free (T/K)</h2>
            
<p>Independent local journalism is essential to a healthy democracy. Your support helps us continue providing quality reporting for Cambridge and Somerville.</p>

<h3>Why Your Support Matters</h3>
<p>Local journalism faces significant challenges. Your donation helps us:</p>
<ul>
    <li>Maintain editorial independence</li>
    <li>Cover important local stories that might otherwise go unreported</li>
    <li>Keep our content accessible to all community members</li>
    <li>Support investigative reporting and in-depth coverage</li>
    <li>Invest in new tools and resources to better serve our readers</li>
</ul>

<h3>How to Donate Online</h3>
<p>You can make your donation online using our secure donation system powered by <strong>WooCommerce</strong> and <strong>Gravity Forms</strong>. These trusted platforms allow you to:</p>
<ul>
    <li>Make secure online donations</li>
    <li>Choose your donation amount</li>
    <li>Complete the donation process quickly and easily</li>
    <li>Receive immediate confirmation of your contribution</li>
</ul>

<div class="donation-form-container">
<form class="cambridge-donation-form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">
    <input type="hidden" name="action" value="cambridge_donation_submit" />
    ' . wp_nonce_field( 'cambridge_donation_nonce', 'donation_nonce', true, false ) . '
    
    <div class="donation-form-row">
        <div class="donation-form-field">
            <label for="donation_name">Full Name <span class="required">*</span></label>
            <input type="text" id="donation_name" name="donation_name" required />
        </div>
    </div>
    
    <div class="donation-form-row">
        <div class="donation-form-field">
            <label for="donation_email">Email Address <span class="required">*</span></label>
            <input type="email" id="donation_email" name="donation_email" required />
        </div>
    </div>
    
    <div class="donation-form-row">
        <div class="donation-form-field">
            <label for="donation_phone">Phone Number</label>
            <input type="tel" id="donation_phone" name="donation_phone" />
        </div>
    </div>
    
    <div class="donation-form-row">
        <div class="donation-form-field">
            <label for="donation_amount">Donation Amount <span class="required">*</span></label>
            <div class="donation-amount-options">
                <label class="amount-option"><input type="radio" name="donation_amount" value="25" required /> $25</label>
                <label class="amount-option"><input type="radio" name="donation_amount" value="50" /> $50</label>
                <label class="amount-option"><input type="radio" name="donation_amount" value="100" /> $100</label>
                <label class="amount-option"><input type="radio" name="donation_amount" value="250" /> $250</label>
                <label class="amount-option"><input type="radio" name="donation_amount" value="500" /> $500</label>
                <label class="amount-option"><input type="radio" name="donation_amount" value="custom" /> Custom</label>
            </div>
            <input type="number" id="donation_custom_amount" name="donation_custom_amount" placeholder="Enter custom amount" min="1" step="0.01" style="display: none; margin-top: 10px; width: 100%; padding: 10px; border: 2px solid #dadadada; border-radius: 4px;" />
        </div>
    </div>
    
    <div class="donation-form-row">
        <div class="donation-form-field">
            <label for="donation_message">Message (Optional)</label>
            <textarea id="donation_message" name="donation_message" rows="4"></textarea>
        </div>
    </div>
    
    <div class="donation-form-row">
        <div class="donation-form-field">
            <label class="checkbox-label">
                <input type="checkbox" name="donation_tax_free" value="1" />
                I would like this to be a tax-free donation (T/K)
            </label>
        </div>
    </div>
    
    <div class="donation-form-row">
        <button type="submit" class="donation-submit-btn">Submit Donation Request</button>
    </div>
    
    <p class="donation-form-note">After submitting, we will contact you to complete the donation process and provide payment instructions.</p>
</form>

<script>
(function() {
    const customRadio = document.querySelector(\'input[name="donation_amount"][value="custom"]\');
    const customAmountInput = document.getElementById(\'donation_custom_amount\');
    
    if (customRadio && customAmountInput) {
        customRadio.addEventListener(\'change\', function() {
            if (this.checked) {
                customAmountInput.style.display = \'block\';
                customAmountInput.required = true;
            } else {
                customAmountInput.style.display = \'none\';
                customAmountInput.required = false;
            }
        });
        
        document.querySelectorAll(\'input[name="donation_amount"]:not([value="custom"])\').forEach(function(radio) {
            radio.addEventListener(\'change\', function() {
                customAmountInput.style.display = \'none\';
                customAmountInput.required = false;
                customAmountInput.value = \'\';
            });
        });
    }
})();
</script>
</div>

<h3>Tax-Free Donations</h3>
<p>Your contribution to The Cambridge Independent may be <strong>tax-free</strong>. Tax-free donations mean that your donation is not subject to tax, and you will not be required to pay any tax for making this donation. We are committed to transparency and will provide appropriate documentation for your records.</p>

<p>You can give tax-free to support local journalism and help us continue our important work in the community.</p>

<h3>Alternative Donation Methods</h3>
<p>If you prefer to donate by other means, please contact us at:</p>
<p><strong>Email:</strong> <a href="mailto:admin@csindie.com">admin@csindie.com</a></p>

<p>Include "Donation" in your subject line, and we\'ll provide you with information on how to contribute.</p>

<h3>Recognition</h3>
<p>We are grateful for every contribution, regardless of size. Your support makes our work possible, and we thank you for investing in local journalism.</p>

<p><strong>Together, we can keep local journalism alive and improving.</strong></p>',
            'post_status'  => 'publish',
            'post_type'    => 'page',
        ),
        array(
            'post_title'   => 'Events',
            'post_name'    => 'events',
            'post_content' => '<h2>Events Calendar</h2>
            
<p>Discover upcoming events in Cambridge and Somerville. From community gatherings to cultural celebrations, find what\'s happening in your neighborhood.</p>

<p>Browse our calendar to see all upcoming events, or use the filters to find events by category, date, or location.</p>',
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'page_template' => 'page-events.php',
        ),
        array(
            'post_title'   => 'Reuse material from The Independent',
            'post_name'    => 'reuse',
            'post_content' => '<h2>Reuse material from The Independent in your own publication</h2>
            
<p>Feel free to republish text from The Independent in your own publication at no charge, so long as you begin that republished content with <strong>"From csindie.com."</strong></p>

<p>We believe in the power of sharing information and making quality journalism accessible. We welcome other publications to republish our content, with proper attribution.</p>

<h3>Republishing Guidelines</h3>
<ul>
    <li><strong>Attribution Required:</strong> All republished content must begin with <strong>"From csindie.com."</strong></li>
    <li><strong>Free to Republish:</strong> You may republish text from The Independent at no charge, as long as proper attribution is included.</li>
    <li><strong>Link Back (Recommended):</strong> While not required, we appreciate including a link back to the original article on our website when republishing online.</li>
    <li><strong>Content Integrity:</strong> We appreciate when republished content maintains the integrity and meaning of the original article.</li>
</ul>

<h3>What You Can Republish</h3>
<ul>
    <li>Full articles (with proper attribution: "From csindie.com.")</li>
    <li>Excerpts or quotes (with proper attribution: "From csindie.com.")</li>
    <li>Text content (with proper attribution: "From csindie.com.")</li>
</ul>

<h3>Photographs and Graphics</h3>
<p>For photographs and graphics, please contact us for permission, as these may have separate copyright considerations. Email us at <a href="mailto:editor@csindie.com">editor@csindie.com</a> for inquiries about reusing images.</p>

<h3>Contact</h3>
<p>If you have questions about republishing our content, please contact us at:</p>
<p><strong>Email:</strong> <a href="mailto:editor@csindie.com">editor@csindie.com</a></p>

<p>Thank you for sharing our content with your readers!</p>',
            'post_status'  => 'publish',
            'post_type'    => 'page',
        ),
    );

    $created = 0;
    $updated = 0;
    $errors = array();

    foreach ( $pages as $page_data ) {
        // Check if page already exists
        $existing_page = get_page_by_path( $page_data['post_name'] );
        
        // Store page template if set
        $page_template = isset( $page_data['page_template'] ) ? $page_data['page_template'] : null;
        unset( $page_data['page_template'] ); // Remove from post data
        
        if ( $existing_page ) {
            // Update existing page
            $page_data['ID'] = $existing_page->ID;
            $result = wp_update_post( $page_data, true );
            
            if ( is_wp_error( $result ) ) {
                $errors[] = 'Error updating "' . $page_data['post_title'] . '": ' . $result->get_error_message();
            } else {
                $updated++;
                // Set page template
                if ( $page_template ) {
                    update_post_meta( $existing_page->ID, '_wp_page_template', $page_template );
                }
            }
        } else {
            // Create new page
            $result = wp_insert_post( $page_data, true );
            
            if ( is_wp_error( $result ) ) {
                $errors[] = 'Error creating "' . $page_data['post_title'] . '": ' . $result->get_error_message();
            } else {
                $created++;
                // Set page template
                if ( $page_template && $result ) {
                    update_post_meta( $result, '_wp_page_template', $page_template );
                }
            }
        }
    }

    return array(
        'created' => $created,
        'updated' => $updated,
        'errors'  => $errors,
    );
}

// If running directly (not via include)
if ( ! function_exists( 'add_action' ) || ( isset( $_GET['action'] ) && $_GET['action'] === 'create_pages' && current_user_can( 'manage_options' ) ) ) {
    $result = cambridge_independent_create_hamburger_pages();
    
    if ( defined( 'WP_CLI' ) ) {
        WP_CLI::success( "Created {$result['created']} pages and updated {$result['updated']} pages." );
        if ( ! empty( $result['errors'] ) ) {
            foreach ( $result['errors'] as $error ) {
                WP_CLI::warning( $error );
            }
        }
    } else {
        // For browser access
        echo '<div class="wrap">';
        echo '<h1>Create Hamburger Menu Pages</h1>';
        echo '<p>Created: ' . $result['created'] . ' pages</p>';
        echo '<p>Updated: ' . $result['updated'] . ' pages</p>';
        if ( ! empty( $result['errors'] ) ) {
            echo '<div class="error"><p><strong>Errors:</strong></p><ul>';
            foreach ( $result['errors'] as $error ) {
                echo '<li>' . esc_html( $error ) . '</li>';
            }
            echo '</ul></div>';
        }
        echo '</div>';
    }
}

