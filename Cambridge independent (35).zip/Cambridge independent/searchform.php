<?php
/**
 * Template for displaying search form
 *
 * @package Cambridge_Independent
 */

get_template_part( 'template-parts/search/searchform' );
