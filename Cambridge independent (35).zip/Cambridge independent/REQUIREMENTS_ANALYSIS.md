# Cambridge Independent - Requirements Analysis

**Analysis Date:** January 2025  
**Document:** Design & Content Specifications  
**Status:** Comparing Requirements vs Current Implementation

---

## ✅ Implemented Features

### 1. Typography
- ✅ **Newsreader font** - Regular 400 and Semibold 600 at 17px (close to 17pt)
- ✅ **Fira Sans** - Implemented for sans-serif elements
- ⚠️ **Logo font** - Currently using Fira Sans, should be "Veneer regular with 10pt letterspacing" (logo file to be provided)

### 2. Homepage Layout - Desktop
- ✅ **Three-column layout** - Implemented with gap and separator
- ✅ **Column 1** - News/Business content
- ✅ **Column 2** - Arts/Culture content
- ✅ **Sidebar** - Advertisement column on right
- ✅ **Hero/Top Stories section** - Implemented with navigation arrows
- ✅ **Vertical rule** - Separator between content and ads (light gray)

### 3. Homepage Layout - Mobile
- ✅ **Endless scroll** - Posts load with pagination
- ⚠️ **Ad placement** - Ads mixed between articles (needs verification of random placement)

### 4. Header/Flag Area
- ✅ **Location text** - "Cambridge | Somerville" displayed
- ✅ **Site title/logo** - Implemented
- ✅ **Hamburger menu** - Implemented
- ✅ **Search box** - Implemented
- ✅ **Category links** - Navigation menu implemented

### 5. Hamburger Menu Structure
- ✅ **See all / City selection** - Menu items present
- ⚠️ **IP-based preferences** - NOT IMPLEMENTED (needs development)
- ✅ **Menu items** - All required items present:
  - About the site
  - Email the editor
  - Send us a news tip
  - Send us a letter
  - Advertise
  - Donate
  - Reuse material

### 6. Categories
- ✅ **Category structure** - Categories can be created
- ⚠️ **Child categories** - Need to verify invisible until content exists
- ⚠️ **Crossposting logic** - Need to verify no duplicate posts on homepage

---

## ❌ Missing / Incomplete Features

### 1. Typography Specifications

#### Missing Text Styles:
- ❌ **Paragraph lead-ins**: Fira Heavy, 13pt, 10pt letterspacing
- ❌ **Quote text**: Newsreader Regular 400, 14pt, 80% black, less leading
- ❌ **Quote paragraph lead-ins**: Fira Heavy, 10pt, 10pt letterspacing
- ❌ **Paragraph lead-ins with padding above**: Fira Heavy, 13pt, 10pt letterspacing
- ❌ **Interview style**: Fira Heavy, 13pt, 10pt letterspacing

#### Partially Implemented:
- ⚠️ **Breadcrumbs**: Need Fira Light, 10pt, 20pt letterspacing, uppercase, centered
- ⚠️ **Photo credits**: Need Fira Light, 9pt, right-justified
- ⚠️ **Short-item taglines**: Need Fira Light, 9pt, left-justified
- ⚠️ **Photo captions**: Need Newsreader Semibold 600, 13pt, tighter leading
- ⚠️ **Top headlines**: Need centered (currently left-justified?)
- ⚠️ **Body paragraph with extra padding above**: For section breaks

### 2. Logo
- ❌ **Veneer font** - Not implemented (using Fira Sans currently)
- ❌ **10pt letterspacing** - Not configured
- ℹ️ Waiting for logo file from client

### 3. IP-Based City Preference
- ❌ **NOT IMPLEMENTED** - This is a critical feature
- **Required**: Store IP-based preferences for Cambridge/Somerville news filtering
- **Required**: Update homepage content based on preference
- **Required**: Allow preference changes via hamburger menu

### 4. Backend CMS Options

#### Missing Options:
- ❌ **"Hide post info" box** with options:
  - Hide author
  - Hide post date
  - Hide revision
  - Hide thumbnail from desktop homepage
- ❌ **"Small mobile box"** with options:
  - Top sticky
  - No. 2 sticky (semipermanent secondary position)
  - Hide excerpt
  - Hide category
  - Hide thumbnail

### 5. Top Stories System
- ⚠️ **Partially implemented** - Hero section exists but needs:
  - Backend designation checkbox/field
  - Shows 3 most recent top stories
  - Navigation between top stories (arrows exist)

### 6. Datelines/City Selection
- ❌ **NOT IMPLEMENTED**
- **Required**: Backend checkboxes for:
  - Most interest to Cambridge readers
  - Most interest to Somerville readers
  - Regional/important (appears to all)
- **Required**: Auto-generate dateline at story start based on selection
- **Required**: Filter homepage content based on user preference + story designation

### 7. Republish Feature
- ❌ **NOT IMPLEMENTED**
- Client notes: May need to manually update publish date with original date note
- Keep idea top of mind for better solution

### 8. Regular Contributor Checkbox
- ❌ **NOT IMPLEMENTED**
- **Required**: Checkbox in backend
- **Required**: Group regular contributors at top of byline list
- **Required**: Group occasional/one-time writers below

### 9. Ad System Enhancements
- ⚠️ **Partially implemented** - Ads exist but need:
  - ❌ Sponsor identification on individual posts (tan boxes)
  - ❌ Calendar item sponsorship
  - ❌ Random ad placement between articles (verify implementation)
  - ❌ Advanced Ads + Square integration for retail

### 10. Donation System
- ❌ **NOT IMPLEMENTED**
- **Required**: WooCommerce + Gravity Forms for for-profit donations
- **Required**: Fiscal sponsorship setup for tax-free donations
- **Required**: Integration with Blink or alternative

### 11. Author Pages/Biographies
- ⚠️ **Basic implementation** - WordPress default exists
- ❌ **Required enhancements**:
  - Author bio at top of author page
  - Author photo on author page
  - Contact information
  - Option to show bio at bottom of articles (per author/post)

### 12. Video/GIF Handling
- ⚠️ **Basic implementation**
- **Considerations**: 
  - Link out to videos (reskin option?)
  - GIF support
  - Performance optimization

### 13. Pinterest-style Picture Links
- ❌ **NOT IMPLEMENTED**
- Future feature: Clickable portions of images for affiliate links

### 14. AI Crawling Block
- ❌ **NOT IMPLEMENTED**
- Client wants code to block AI crawling
- Consider CloudFlare integration

---

## 🔧 Technical Implementation Needed

### High Priority

1. **IP-Based City Preference System**
   - Cookie/localStorage for preference
   - PHP/JavaScript to filter content
   - Hamburger menu preference selector
   - Backend city designation fields

2. **Backend CMS Custom Fields**
   - Hide post info meta box
   - Small mobile box meta box
   - Top stories checkbox
   - City designation (Cambridge/Somerville/Regional)
   - Regular contributor checkbox
   - Sponsor/advertiser fields

3. **Typography CSS Classes**
   - Paragraph lead-ins
   - Quote text styles
   - Breadcrumbs
   - Photo credits
   - Short-item taglines
   - Photo captions
   - Interview style
   - Body paragraph with extra padding

4. **Logo Font Implementation**
   - Install Veneer font
   - Configure 10pt letterspacing
   - Replace Fira Sans in logo

5. **Content Filtering Logic**
   - Filter by city preference
   - Ensure no duplicate posts on homepage
   - Cross-category posting logic

### Medium Priority

1. **Top Stories System**
   - Backend designation
   - Query for 3 most recent
   - Navigation functionality (partially exists)

2. **Dateline Generation**
   - Auto-add dateline based on city selection
   - Display logic

3. **Regular Contributor System**
   - Backend checkbox
   - Bylines sorting logic
   - Author page grouping

4. **Ad System Integration**
   - Advanced Ads plugin
   - Square integration
   - Sponsor post association

### Low Priority

1. **Republish Feature**
   - Manual date update with note
   - Future automated solution

2. **Author Biography Enhancements**
   - Bio fields
   - Photo upload
   - Contact information
   - Per-post bio display option

3. **Video/GIF Optimization**
   - External linking
   - Performance considerations

4. **AI Crawling Block**
   - robots.txt rules
   - Meta tags
   - CloudFlare consideration

---

## 📋 Category Structure Verification Needed

### News (with child categories)
- News
- News analysis
- News opinion
- Business
- Business analysis
- Business opinion
- Business names
- Development
- Development analysis
- Development opinion
- Education
- Education analysis
- Education opinion
- Politics
- Politics analysis
- Politics opinion
- Transportation
- Transportation analysis
- Transportation opinion
- Take note

### Arts
- Art
- Books
- Comedy
- Dance
- Fashion
- Film
- Food and drink
- Media
- Music
- Poetry
- Theater

### Community
- Your contributed stories
- Opinions (parent for crossposting)
- Deaths
- Names (crosspost with business names)

### Resources
- Wild Things
- Cambridge (community profile)
- Somerville (community profile)
- Additional entries (not ready yet)

### Events
- Events calendar (The Events Calendar plugin)

**Verification Needed:**
- Are these categories created?
- Are child categories set up correctly?
- Is crossposting logic working?
- Are categories hidden until content exists?

---

## 🎯 Action Items Summary

### Immediate (Critical)
1. Implement IP-based city preference system
2. Add backend CMS custom fields (hide options, mobile options, city designation)
3. Create typography CSS classes for all specified text styles
4. Set up logo font (Veneer) when provided
5. Implement content filtering based on city preference

### Short Term
1. Top stories backend designation
2. Dateline auto-generation
3. Regular contributor checkbox and sorting
4. Ad system enhancements (sponsor association)
5. Category structure verification and setup

### Long Term
1. Donation system integration
2. Author biography enhancements
3. Republish feature
4. Video/GIF optimization
5. AI crawling block
6. Pinterest-style image links (future)

---

## 📝 Notes

1. **Performance**: Client wants fast, frictionless experience
   - Minimize homepage queries ✅ (partially done)
   - Avoid third-party layers ✅ (WordPress native)
   - Consider AI blocking impact

2. **CloudFlare**: May handle AI blocking, consider this

3. **Logo**: Client will provide Veneer font file

4. **Events**: Using The Events Calendar plugin

5. **Comments**: Client not super excited, minimal implementation OK

6. **No Login**: Preference system should use cookies/localStorage, not user accounts

---

**Next Steps:**
1. Review this analysis with client
2. Prioritize missing features
3. Begin implementation of high-priority items
4. Verify category structure matches requirements

