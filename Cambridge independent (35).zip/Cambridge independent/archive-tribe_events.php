<?php
/**
 * The template for displaying event archive pages
 *
 * @package Cambridge_Independent
 */

get_header();
?>

<main id="main" class="site-main">
    <div class="ci-container">
        <div class="content-area">
            <div class="primary-content">
                <?php
                if ( have_posts() ) :
                    while ( have_posts() ) :
                        the_post();
                        get_template_part( 'template-parts/content/content-event-archive' );
                    endwhile;

                    // Pagination
                    the_posts_pagination( array(
                        'mid_size'  => 2,
                        'prev_text' => __( 'Previous', 'cambridge-independent' ),
                        'next_text' => __( 'Next', 'cambridge-independent' ),
                    ) );

                else :
                    get_template_part( 'template-parts/content/content-none' );
                endif;
                ?>
            </div>

            <?php get_sidebar(); ?>
        </div>
    </div>
</main>

<?php
get_footer();

