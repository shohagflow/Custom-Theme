<?php
/**
 * The sidebar template file
 *
 * @package Cambridge_Independent
 */

get_template_part( 'template-parts/sidebar/sidebar' );
