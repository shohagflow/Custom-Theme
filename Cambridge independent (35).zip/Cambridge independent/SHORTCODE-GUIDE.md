# Shortcode Usage Guide

## SIDEBAR and RELATED Section Shortcodes

This theme includes two shortcodes that can be used anywhere in your post content to display related content sections:

### 1. SIDEBAR Shortcode
**Shortcode:** `[sidebar]`

**Usage:**
- Place `[sidebar]` anywhere in your post editor content area
- This will display a related story box showing the title of one related post from the same category

**Example:**
```
This is paragraph 1.

[sidebar]

This is paragraph 2.
```

### 2. RELATED Shortcode
**Shortcode:** `[related]`

**Usage:**
- Place `[related]` anywhere in your post editor content area
- This will display a RELATED posts section showing a list of multiple related posts from the same category (up to 5 posts)

**Example:**
```
This is paragraph 1.

[related]

This is paragraph 2.
```

## How to Use:

### Step 1: Go to Post Editor
1. Navigate to WordPress Admin Dashboard → **Posts** → **Add New** (for a new post) or **All Posts** → Edit an existing post

### Step 2: Add Shortcode to Content
1. In the post editor content area, place your cursor where you want the section to appear
2. Type one of the following shortcodes:
   - For SIDEBAR: `[sidebar]`
   - For RELATED: `[related]`

### Step 3: Save the Post
1. Click the **Publish** or **Update** button to save your changes

## Important Notes:

✅ **Shortcode Detection:** 
- If shortcodes are present in the content, automatic insertion will be disabled
- Shortcodes provide manual control over where sections appear

✅ **Single Posts Only:**
- These shortcodes work only on single post pages
- They will not work on homepage, archive pages, or other page types

✅ **Related Posts:**
- The shortcodes will display related posts from the same category as the current post
- If no related posts exist in the same category, the sections will not be displayed

✅ **Multiple Usage:**
- You can use these shortcodes multiple times in a single post
- Each instance will show different related content based on availability

## Example Layout:

```
Paragraph 1 content here...

[sidebar]

Paragraph 2 content here...

[related]

Paragraph 3 content here...
```

## Visual Preview:

**SIDEBAR Section:**
- Displays in a box with background color #e1dcc7
- Shows "SIDEBAR" heading (bold, 22px)
- Displays one related post title as a link

**RELATED Section:**
- Displays in a box with background color #e1dcc7
- Shows "RELATED" heading (bold, 18px)
- Lists up to 5 related posts with bullet points

## Troubleshooting:

**Problem:** Shortcode is not working
- **Solution:** Make sure you are viewing a single post page, not the homepage or archive page
- **Solution:** Check that the post has at least one category assigned
- **Solution:** Verify the post is published, not in draft status

**Problem:** Section is not displaying
- **Solution:** Check if there are related posts in the same category. If no related posts exist, the section will not appear
- **Solution:** Verify the shortcode spelling is correct: `[sidebar]` or `[related]` (all lowercase, with square brackets)
- **Solution:** Make sure there are no extra spaces or characters in the shortcode

**Problem:** Section appears in wrong location
- **Solution:** The shortcode must be placed exactly where you want the section to appear in the content
- **Solution:** Check if automatic insertion is interfering. If shortcodes are present, automatic insertion is disabled

## Tips & Best Practices:

- Use shortcodes strategically to break up long content and provide related reading suggestions
- Place `[sidebar]` after every 2-3 paragraphs to provide contextually relevant content
- Use `[related]` near the end of your post to encourage readers to explore more content
- Shortcodes work in both the Classic Editor and Gutenberg/Block Editor (Text mode)
- You can preview how the sections will look by using the WordPress Preview feature before publishing

## Support:

If you encounter any issues, please contact the theme developer.

