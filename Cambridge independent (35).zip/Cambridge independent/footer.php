<?php
/**
 * The footer template file
 *
 * @package Cambridge_Independent
 */

get_template_part( 'template-parts/footer/footer' );
