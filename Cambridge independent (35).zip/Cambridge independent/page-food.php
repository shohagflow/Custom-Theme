<?php
/**
 * Template Name: Food Page
 * 
 * Custom page template for displaying food-related content
 *
 * @package Cambridge_Independent
 */

get_header();
?>

<main id="main" class="site-main">
    <div class="ci-container">
        <div class="food-page-header">
            <h1 class="food-page-title">Food & Dining</h1>
            <p class="food-page-description">Discover the best restaurants, food events, and culinary experiences in Cambridge and Somerville.</p>
        </div>
        
        <div class="food-content-wrapper">
            <div class="food-main-content">
                <?php
                // Get food-related categories
                // First try to get from arts/culture settings (food is often grouped with arts)
                $food_cats = get_option( 'ci_arts_culture_categories', array() );
                
                // If no categories set, try to find food-related categories
                if ( empty( $food_cats ) ) {
                    $all_categories = get_categories( array(
                        'orderby' => 'name',
                        'order'   => 'ASC',
                    ) );
                    
                    foreach ( $all_categories as $cat ) {
                        $cat_slug = strtolower( $cat->slug );
                        if ( strpos( $cat_slug, 'food' ) !== false || 
                             strpos( $cat_slug, 'dining' ) !== false || 
                             strpos( $cat_slug, 'restaurant' ) !== false ||
                             strpos( $cat_slug, 'culinary' ) !== false ||
                             strpos( $cat_slug, 'bite' ) !== false ||
                             strpos( $cat_slug, 'recipe' ) !== false ) {
                            $food_cats[] = $cat->term_id;
                        }
                    }
                }
                
                // Query for food posts
                $food_args = array(
                    'posts_per_page' => 20,
                    'post_status'    => 'publish',
                    'orderby'        => 'date',
                    'order'          => 'DESC',
                    'paged'          => get_query_var( 'paged' ) ? get_query_var( 'paged' ) : 1,
                );
                
                if ( ! empty( $food_cats ) && is_array( $food_cats ) ) {
                    $food_args['category__in'] = array_map( 'absint', $food_cats );
                }
                
                $food_query = new WP_Query( $food_args );
                
                if ( $food_query->have_posts() ) :
                    $post_index = 0;
                    $current_section = '';
                    
                    while ( $food_query->have_posts() ) :
                        $food_query->the_post();
                        $post_index++;
                        
                        // Get post categories to determine section
                        $categories = get_the_category();
                        $post_section = '';
                        
                        if ( ! empty( $categories ) ) {
                            foreach ( $categories as $category ) {
                                $cat_slug = strtolower( $category->slug );
                                if ( strpos( $cat_slug, 'restaurant' ) !== false || 
                                     strpos( $cat_slug, 'dining' ) !== false ) {
                                    $post_section = 'restaurants';
                                    break;
                                } elseif ( strpos( $cat_slug, 'recipe' ) !== false || 
                                          strpos( $cat_slug, 'cooking' ) !== false ) {
                                    $post_section = 'recipes';
                                    break;
                                } elseif ( strpos( $cat_slug, 'food' ) !== false || 
                                          strpos( $cat_slug, 'bite' ) !== false ) {
                                    $post_section = 'food';
                                    break;
                                }
                            }
                        }
                        
                        // Display section header if changed
                        if ( $post_section && $post_section !== $current_section ) {
                            $current_section = $post_section;
                            $section_title = '';
                            
                            switch ( $post_section ) {
                                case 'restaurants':
                                    $section_title = 'RESTAURANTS';
                                    break;
                                case 'recipes':
                                    $section_title = 'RECIPES';
                                    break;
                                case 'food':
                                    $section_title = 'FOOD';
                                    break;
                            }
                            
                            if ( $section_title ) {
                                echo '<div class="section-header"><h3 class="section-title">' . esc_html( $section_title ) . '</h3></div>';
                            }
                        }
                        
                        // Check if we should insert an ad
                        if ( $post_index > 0 && $post_index % 5 === 0 ) {
                            $ad_content = cambridge_independent_get_random_ad();
                            if ( $ad_content ) {
                                echo $ad_content;
                            }
                        }
                        
                        // Display the post
                        get_template_part( 'template-parts/homepage/article-item' );
                        
                    endwhile;
                    
                    // Pagination
                    echo '<div class="food-pagination">';
                    the_posts_pagination( array(
                        'mid_size'  => 2,
                        'prev_text' => __( '← Previous', 'cambridge-independent' ),
                        'next_text' => __( 'Next →', 'cambridge-independent' ),
                    ) );
                    echo '</div>';
                    
                    wp_reset_postdata();
                else :
                    ?>
                    <div class="no-posts-message">
                        <p><?php _e( 'No food posts found.', 'cambridge-independent' ); ?></p>
                        <p><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php _e( 'Return to homepage', 'cambridge-independent' ); ?></a></p>
                    </div>
                    <?php
                endif;
                ?>
            </div>
            
            <?php get_sidebar(); ?>
        </div>
    </div>
</main>

<?php
get_footer();

