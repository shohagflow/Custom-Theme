<?php
/**
 * Template Name: Business Page
 * 
 * Custom page template for displaying business-related content
 *
 * @package Cambridge_Independent
 */

get_header();
?>

<main id="main" class="site-main">
    <div class="ci-container">
        <div class="business-page-header">
            <h1 class="business-page-title">News & Business</h1>
            <p class="business-page-description">Stay informed with the latest news, business updates, and economic developments in Cambridge and Somerville.</p>
        </div>
        
        <div class="business-content-wrapper">
            <div class="business-main-content">
                <?php
                // Get news/business category IDs from settings
                $news_business_cats = get_option( 'ci_news_business_categories', array() );
                
                // If no categories set, try to find business-related categories
                if ( empty( $news_business_cats ) ) {
                    $business_categories = get_categories( array(
                        'orderby' => 'name',
                        'order'   => 'ASC',
                    ) );
                    
                    foreach ( $business_categories as $cat ) {
                        $cat_slug = strtolower( $cat->slug );
                        if ( strpos( $cat_slug, 'news' ) !== false || 
                             strpos( $cat_slug, 'business' ) !== false || 
                             strpos( $cat_slug, 'economy' ) !== false ||
                             strpos( $cat_slug, 'finance' ) !== false ||
                             strpos( $cat_slug, 'politics' ) !== false ) {
                            $news_business_cats[] = $cat->term_id;
                        }
                    }
                }
                
                // Query for business posts
                $business_args = array(
                    'posts_per_page' => 20,
                    'post_status'    => 'publish',
                    'orderby'        => 'date',
                    'order'          => 'DESC',
                );
                
                if ( ! empty( $news_business_cats ) && is_array( $news_business_cats ) ) {
                    $business_args['category__in'] = array_map( 'absint', $news_business_cats );
                }
                
                $business_query = new WP_Query( $business_args );
                
                if ( $business_query->have_posts() ) :
                    $post_index = 0;
                    $current_section = '';
                    
                    while ( $business_query->have_posts() ) :
                        $business_query->the_post();
                        $post_index++;
                        
                        // Get post categories to determine section
                        $categories = get_the_category();
                        $post_section = '';
                        
                        if ( ! empty( $categories ) ) {
                            foreach ( $categories as $category ) {
                                $cat_slug = strtolower( $category->slug );
                                if ( strpos( $cat_slug, 'business' ) !== false || 
                                     strpos( $cat_slug, 'economy' ) !== false ||
                                     strpos( $cat_slug, 'finance' ) !== false ) {
                                    $post_section = 'business';
                                    break;
                                } elseif ( strpos( $cat_slug, 'news' ) !== false || 
                                          strpos( $cat_slug, 'politics' ) !== false ) {
                                    $post_section = 'news';
                                    break;
                                }
                            }
                        }
                        
                        // Display section header if changed
                        if ( $post_section && $post_section !== $current_section ) {
                            $current_section = $post_section;
                            $section_title = '';
                            
                            switch ( $post_section ) {
                                case 'business':
                                    $section_title = 'BUSINESS';
                                    break;
                                case 'news':
                                    $section_title = 'NEWS';
                                    break;
                            }
                            
                            if ( $section_title ) {
                                echo '<div class="section-header"><h3 class="section-title">' . esc_html( $section_title ) . '</h3></div>';
                            }
                        }
                        
                        // Check if we should insert an ad
                        if ( $post_index > 0 && $post_index % 5 === 0 ) {
                            $ad_content = cambridge_independent_get_random_ad();
                            if ( $ad_content ) {
                                echo $ad_content;
                            }
                        }
                        
                        // Display the post
                        get_template_part( 'template-parts/homepage/article-item' );
                        
                    endwhile;
                    
                    // Pagination
                    echo '<div class="business-pagination">';
                    the_posts_pagination( array(
                        'mid_size'  => 2,
                        'prev_text' => __( '← Previous', 'cambridge-independent' ),
                        'next_text' => __( 'Next →', 'cambridge-independent' ),
                    ) );
                    echo '</div>';
                    
                    wp_reset_postdata();
                else :
                    ?>
                    <div class="no-posts-message">
                        <p><?php _e( 'No business posts found.', 'cambridge-independent' ); ?></p>
                        <p><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php _e( 'Return to homepage', 'cambridge-independent' ); ?></a></p>
                    </div>
                    <?php
                endif;
                ?>
            </div>
            
            <?php get_sidebar(); ?>
        </div>
    </div>
</main>

<?php
get_footer();

