<?php
/**
 * The main template file
 *
 * @package Cambridge_Independent
 */

get_header();
?>

<main id="main" class="site-main">
    <?php
    // Get hero post ID to skip it in main loop
    $hero_post_id = 0;
    if ( is_home() || is_front_page() ) {
        $hero_query = new WP_Query( array(
            'posts_per_page' => 1,
            'post_status'    => 'publish',
            'orderby'        => 'date',
            'order'          => 'DESC',
        ) );
        if ( $hero_query->have_posts() ) {
            $hero_query->the_post();
            $hero_post_id = get_the_ID();
            wp_reset_postdata();
        }
    }
    ?>
    
    <div class="ci-container">
        <div class="content-area">
            <div class="primary-content">
                <?php get_template_part( 'template-parts/hero/hero-feature' ); ?>
                
                <?php
                if ( have_posts() ) :
                    while ( have_posts() ) :
                        the_post();
                        
                        // Skip hero post in main loop
                        if ( $hero_post_id && get_the_ID() === $hero_post_id ) {
                            continue;
                        }
                        
                        get_template_part( 'template-parts/content/content' );
                    endwhile;

                    // Pagination
                    the_posts_pagination( array(
                        'mid_size'  => 2,
                        'prev_text' => __( 'Previous', 'cambridge-independent' ),
                        'next_text' => __( 'Next', 'cambridge-independent' ),
                    ) );

                else :
                    get_template_part( 'template-parts/content/content-none' );
                endif;
                ?>
            </div>

            <?php get_sidebar(); ?>
        </div>
    </div>
</main>

<?php
get_footer();
