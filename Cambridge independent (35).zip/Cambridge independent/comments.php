<?php
/**
 * The template for displaying comments
 *
 * @package Cambridge_Independent
 */

get_template_part( 'template-parts/comments/comments' );
