# Hamburger Menu Dropdown Design Analysis

## Screenshot Requirements

### Design Structure
- **Layout**: Vertical sidebar menu that appears when hamburger is clicked
- **Background**: Light grey background
- **Position**: Appears as a dropdown/sidebar overlay

### Menu Sections

#### 1. Content Filtering Options
- **"See all"** - Displayed in **RED** text (highlighted/primary option)
- **"I want mostly Cambridge news"** - Grey text
- **"I want mostly Somerville news"** - Grey text
- Horizontal separator line below

#### 2. About/Contact Options
- Horizontal separator line above
- **"We're all in this together: About the site"** - "We're all in this together" in **BOLD**
- **"Email the editor"** - Grey text
- **"Send us a news tip"** - Grey text
- **"Send us a letter for publication online"** - Grey text
- Horizontal separator line below

#### 3. Support/Engagement Options
- Horizontal separator line above
- **"Advertise through us"** - Grey text
- **"Donate to keep local journalism alive and improving or give tax free"** - "Donate" and "give tax" in **BOLD**
- **"Reuse material from The Independent in your own publication"** - Grey text

### Typography & Styling
- **Font**: Fira Sans (sans-serif) for menu items
- **Highlighted text**: Red color (#ff0000 or similar)
- **Regular text**: Grey color (#666 or similar)
- **Bold phrases**: Font-weight 700
- **Separators**: Thin horizontal lines (1px solid #e0e0e0 or similar)
- **Layout**: Vertical list, each item on its own line
- **Spacing**: Adequate padding between items

### Functionality
- Toggles when hamburger icon is clicked
- Should overlay or slide in from the side
- Close when clicking outside or on hamburger again
- Smooth transitions

## Implementation Plan

1. Create a custom menu template part for the hamburger dropdown
2. Add menu items with proper structure and classes
3. Style the dropdown to match the screenshot design
4. Add JavaScript to handle toggle functionality
5. Ensure responsive behavior

