<?php
/**
 * Template Name: Arts Page
 * 
 * Custom page template for displaying arts-related content
 *
 * @package Cambridge_Independent
 */

get_header();
?>

<main id="main" class="site-main">
    <div class="ci-container">
        <div class="arts-page-header">
            <h1 class="arts-page-title">Arts, Culture & Media</h1>
            <p class="arts-page-description">Exploring the vibrant arts scene, cultural events, and media coverage in Cambridge and Somerville.</p>
        </div>
        
        <div class="arts-content-wrapper">
            <div class="arts-main-content">
                <?php
                // Get arts/culture category IDs from settings
                $arts_culture_cats = get_option( 'ci_arts_culture_categories', array() );
                
                // If no categories set, try to find arts-related categories
                if ( empty( $arts_culture_cats ) ) {
                    $arts_categories = get_categories( array(
                        'orderby' => 'name',
                        'order'   => 'ASC',
                    ) );
                    
                    foreach ( $arts_categories as $cat ) {
                        $cat_slug = strtolower( $cat->slug );
                        if ( strpos( $cat_slug, 'arts' ) !== false || 
                             strpos( $cat_slug, 'culture' ) !== false || 
                             strpos( $cat_slug, 'media' ) !== false ||
                             strpos( $cat_slug, 'food' ) !== false ) {
                            $arts_culture_cats[] = $cat->term_id;
                        }
                    }
                }
                
                // Query for arts posts
                $arts_args = array(
                    'posts_per_page' => 20,
                    'post_status'    => 'publish',
                    'orderby'        => 'date',
                    'order'          => 'DESC',
                );
                
                if ( ! empty( $arts_culture_cats ) && is_array( $arts_culture_cats ) ) {
                    $arts_args['category__in'] = array_map( 'absint', $arts_culture_cats );
                }
                
                $arts_query = new WP_Query( $arts_args );
                
                if ( $arts_query->have_posts() ) :
                    $post_index = 0;
                    $current_section = '';
                    
                    while ( $arts_query->have_posts() ) :
                        $arts_query->the_post();
                        $post_index++;
                        
                        // Get post categories to determine section
                        $categories = get_the_category();
                        $post_section = '';
                        
                        if ( ! empty( $categories ) ) {
                            foreach ( $categories as $category ) {
                                $cat_slug = strtolower( $category->slug );
                                if ( strpos( $cat_slug, 'food' ) !== false || strpos( $cat_slug, 'bite' ) !== false ) {
                                    $post_section = 'food';
                                    break;
                                } elseif ( strpos( $cat_slug, 'arts' ) !== false || strpos( $cat_slug, 'culture' ) !== false ) {
                                    $post_section = 'arts';
                                    break;
                                } elseif ( strpos( $cat_slug, 'media' ) !== false ) {
                                    $post_section = 'media';
                                    break;
                                }
                            }
                        }
                        
                        // Display section header if changed
                        if ( $post_section && $post_section !== $current_section ) {
                            $current_section = $post_section;
                            $section_title = '';
                            
                            switch ( $post_section ) {
                                case 'food':
                                    $section_title = 'FOOD';
                                    break;
                                case 'arts':
                                    $section_title = 'ARTS';
                                    break;
                                case 'media':
                                    $section_title = 'MEDIA';
                                    break;
                            }
                            
                            if ( $section_title ) {
                                echo '<div class="section-header"><h3 class="section-title">' . esc_html( $section_title ) . '</h3></div>';
                            }
                        }
                        
                        // Check if we should insert an ad
                        if ( $post_index > 0 && $post_index % 5 === 0 ) {
                            $ad_content = cambridge_independent_get_random_ad();
                            if ( $ad_content ) {
                                echo $ad_content;
                            }
                        }
                        
                        // Display the post
                        get_template_part( 'template-parts/homepage/article-item' );
                        
                    endwhile;
                    
                    // Pagination
                    echo '<div class="arts-pagination">';
                    the_posts_pagination( array(
                        'mid_size'  => 2,
                        'prev_text' => __( '← Previous', 'cambridge-independent' ),
                        'next_text' => __( 'Next →', 'cambridge-independent' ),
                    ) );
                    echo '</div>';
                    
                    wp_reset_postdata();
                else :
                    ?>
                    <div class="no-posts-message">
                        <p><?php _e( 'No arts posts found.', 'cambridge-independent' ); ?></p>
                        <p><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php _e( 'Return to homepage', 'cambridge-independent' ); ?></a></p>
                    </div>
                    <?php
                endif;
                ?>
            </div>
            
            <?php get_sidebar(); ?>
        </div>
    </div>
</main>

<?php
get_footer();

