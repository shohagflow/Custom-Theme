<?php
/**
 * Cambridge Independent Theme Functions
 *
 * @package Cambridge_Independent
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Load theme includes
 */
require get_template_directory() . '/inc/theme-setup.php';
require get_template_directory() . '/inc/enqueue.php';
require get_template_directory() . '/inc/widgets.php';
require get_template_directory() . '/inc/template-functions.php';
require get_template_directory() . '/inc/theme-settings.php';
require get_template_directory() . '/inc/generate-dummy-posts.php';
require get_template_directory() . '/inc/create-hamburger-pages.php';
require get_template_directory() . '/inc/city-preference.php';
require get_template_directory() . '/inc/donor-credit.php';

/**
 * Ensure tag archive pages work correctly
 * WordPress handles tag archives automatically, but we can customize if needed
 */
function cambridge_independent_tag_archive_setup( $query ) {
    // Only modify the main query on the frontend for tag archives
    if ( is_admin() || ! $query->is_main_query() ) {
        return;
    }
    
    // If this is a tag archive, ensure proper ordering
    if ( is_tag() ) {
        $query->set( 'orderby', 'date' );
        $query->set( 'order', 'DESC' );
    }
}
add_action( 'pre_get_posts', 'cambridge_independent_tag_archive_setup' );

/**
 * Shortcode to display donation form
 * Usage: [cambridge_donation_form]
 * Automatically detects and displays Gravity Forms or WooCommerce donation form
 */
function cambridge_independent_donation_form_shortcode( $atts ) {
    $form_html = '';
    
    // Check for Gravity Forms first (preferred for donations)
    if ( function_exists( 'gravity_form' ) ) {
        // Gravity Forms is active - return shortcode
        // Note: Admin needs to create a donation form with ID 1, or change this ID
        // You can also use: [gravityform id="YOUR_FORM_ID" title="false" description="false" ajax="true"]
        $form_id = isset( $atts['form_id'] ) ? intval( $atts['form_id'] ) : 1;
        $form_html = do_shortcode( '[gravityform id="' . $form_id . '" title="false" description="false" ajax="true"]' );
    }
    // Check for WooCommerce as alternative
    elseif ( class_exists( 'WooCommerce' ) ) {
        // WooCommerce is active - can use product purchase or custom checkout
        // Admin needs to create a donation product
        $form_html = '<div class="woocommerce-donation-notice">
            <p><strong>WooCommerce is active.</strong> To enable donations:</p>
            <ol>
                <li>Create a "Donation" product in WooCommerce</li>
                <li>Set it as a variable product with suggested donation amounts</li>
                <li>Configure payment gateways (Stripe, PayPal, etc.)</li>
                <li>Add the product to cart and checkout, or use Gravity Forms for a better donation experience</li>
            </ol>
            <p>For assistance, contact us at: <a href="mailto:admin@csindie.com">admin@csindie.com</a></p>
        </div>';
    }
    // No donation plugins active - show basic donation form
    else {
        $admin_email = 'admin@csindie.com';
        $form_html = '<form class="cambridge-donation-form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">
            <input type="hidden" name="action" value="cambridge_donation_submit" />
            ' . wp_nonce_field( 'cambridge_donation_nonce', 'donation_nonce', true, false ) . '
            
            <div class="donation-form-row">
                <div class="donation-form-field">
                    <label for="donation_name">Full Name <span class="required">*</span></label>
                    <input type="text" id="donation_name" name="donation_name" required />
                </div>
            </div>
            
            <div class="donation-form-row">
                <div class="donation-form-field">
                    <label for="donation_email">Email Address <span class="required">*</span></label>
                    <input type="email" id="donation_email" name="donation_email" required />
                </div>
            </div>
            
            <div class="donation-form-row">
                <div class="donation-form-field">
                    <label for="donation_phone">Phone Number</label>
                    <input type="tel" id="donation_phone" name="donation_phone" />
                </div>
            </div>
            
            <div class="donation-form-row">
                <div class="donation-form-field">
                    <label for="donation_amount">Donation Amount <span class="required">*</span></label>
                    <div class="donation-amount-options">
                        <label class="amount-option"><input type="radio" name="donation_amount" value="25" required /> $25</label>
                        <label class="amount-option"><input type="radio" name="donation_amount" value="50" /> $50</label>
                        <label class="amount-option"><input type="radio" name="donation_amount" value="100" /> $100</label>
                        <label class="amount-option"><input type="radio" name="donation_amount" value="250" /> $250</label>
                        <label class="amount-option"><input type="radio" name="donation_amount" value="500" /> $500</label>
                        <label class="amount-option"><input type="radio" name="donation_amount" value="custom" /> Custom</label>
                    </div>
                    <input type="number" id="donation_custom_amount" name="donation_custom_amount" placeholder="Enter custom amount" min="1" step="0.01" style="display: none; margin-top: 10px; width: 100%; padding: 10px;" />
                </div>
            </div>
            
            <div class="donation-form-row">
                <div class="donation-form-field">
                    <label for="donation_message">Message (Optional)</label>
                    <textarea id="donation_message" name="donation_message" rows="4"></textarea>
                </div>
            </div>
            
            <div class="donation-form-row">
                <div class="donation-form-field">
                    <label class="checkbox-label">
                        <input type="checkbox" name="donation_tax_free" value="1" />
                        I would like this to be a tax-free donation (T/K)
                    </label>
                </div>
            </div>
            
            <div class="donation-form-row">
                <button type="submit" class="donation-submit-btn">Submit Donation Request</button>
            </div>
            
            <p class="donation-form-note">After submitting, we will contact you to complete the donation process and provide payment instructions.</p>
        </form>
        
        <script>
        (function() {
            const customRadio = document.querySelector(\'input[name="donation_amount"][value="custom"]\');
            const customAmountInput = document.getElementById(\'donation_custom_amount\');
            
            if (customRadio && customAmountInput) {
                customRadio.addEventListener(\'change\', function() {
                    if (this.checked) {
                        customAmountInput.style.display = \'block\';
                        customAmountInput.required = true;
                    } else {
                        customAmountInput.style.display = \'none\';
                        customAmountInput.required = false;
                    }
                });
                
                document.querySelectorAll(\'input[name="donation_amount"]:not([value="custom"])\').forEach(function(radio) {
                    radio.addEventListener(\'change\', function() {
                        customAmountInput.style.display = \'none\';
                        customAmountInput.required = false;
                        customAmountInput.value = \'\';
                    });
                });
            }
        })();
        </script>';
    }
    
    return $form_html;
}
add_shortcode( 'cambridge_donation_form', 'cambridge_independent_donation_form_shortcode' );

/**
 * Check if donation plugins are active and display appropriate form
 * This function can be used in templates to conditionally show donation forms
 */
function cambridge_independent_get_donation_form() {
    return cambridge_independent_donation_form_shortcode( array() );
}

/**
 * Handle donation form submission
 */
function cambridge_independent_handle_donation_submit() {
    // Verify nonce
    if ( ! isset( $_POST['donation_nonce'] ) || ! wp_verify_nonce( $_POST['donation_nonce'], 'cambridge_donation_nonce' ) ) {
        wp_die( 'Security check failed' );
    }
    
    // Get form data
    $name = isset( $_POST['donation_name'] ) ? sanitize_text_field( $_POST['donation_name'] ) : '';
    $email = isset( $_POST['donation_email'] ) ? sanitize_email( $_POST['donation_email'] ) : '';
    $phone = isset( $_POST['donation_phone'] ) ? sanitize_text_field( $_POST['donation_phone'] ) : '';
    $amount_type = isset( $_POST['donation_amount'] ) ? sanitize_text_field( $_POST['donation_amount'] ) : '';
    $custom_amount = isset( $_POST['donation_custom_amount'] ) ? floatval( $_POST['donation_custom_amount'] ) : 0;
    $message = isset( $_POST['donation_message'] ) ? sanitize_textarea_field( $_POST['donation_message'] ) : '';
    $tax_free = isset( $_POST['donation_tax_free'] ) ? 'Yes' : 'No';
    
    // Calculate amount
    $amount = ( $amount_type === 'custom' && $custom_amount > 0 ) ? $custom_amount : floatval( $amount_type );
    
    // Validate required fields
    if ( empty( $name ) || empty( $email ) || $amount <= 0 ) {
        wp_redirect( add_query_arg( 'donation', 'error', home_url( '/donate/' ) ) );
        exit;
    }
    
    // Prepare email
    $admin_email = 'admin@csindie.com';
    $subject = 'New Donation Request - ' . get_bloginfo( 'name' );
    
    $email_body = "New donation request received:\n\n";
    $email_body .= "Name: {$name}\n";
    $email_body .= "Email: {$email}\n";
    $email_body .= "Phone: " . ( $phone ? $phone : 'Not provided' ) . "\n";
    $email_body .= "Amount: $" . number_format( $amount, 2 ) . "\n";
    $email_body .= "Tax-Free Donation: {$tax_free}\n";
    if ( $message ) {
        $email_body .= "Message: {$message}\n";
    }
    $email_body .= "\nPlease contact the donor to complete the payment process.";
    
    // Send email
    $headers = array( 'Content-Type: text/plain; charset=UTF-8', 'From: ' . get_bloginfo( 'name' ) . ' <' . $admin_email . '>' );
    wp_mail( $admin_email, $subject, $email_body, $headers );
    
    // Send confirmation to donor
    $donor_subject = 'Thank you for your donation request - ' . get_bloginfo( 'name' );
    $donor_body = "Dear {$name},\n\n";
    $donor_body .= "Thank you for your donation request of $" . number_format( $amount, 2 ) . ".\n\n";
    $donor_body .= "We have received your request and will contact you shortly to complete the donation process.\n\n";
    $donor_body .= "If you requested a tax-free donation, we will provide the necessary documentation.\n\n";
    $donor_body .= "Thank you for supporting local journalism!\n\n";
    $donor_body .= "Best regards,\n" . get_bloginfo( 'name' );
    
    wp_mail( $email, $donor_subject, $donor_body, $headers );
    
    // Redirect with success message
    wp_redirect( add_query_arg( 'donation', 'success', home_url( '/donate/' ) ) );
    exit;
}
add_action( 'admin_post_cambridge_donation_submit', 'cambridge_independent_handle_donation_submit' );
add_action( 'admin_post_nopriv_cambridge_donation_submit', 'cambridge_independent_handle_donation_submit' );
