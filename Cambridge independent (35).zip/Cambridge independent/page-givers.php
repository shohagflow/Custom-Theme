<?php
/**
 * Template Name: Givers Page
 * 
 * Custom page template for displaying public givers/donors list
 *
 * @package Cambridge_Independent
 */

get_header();
?>

<main id="main" class="site-main">
    <div class="ci-container">
        <div class="content-area">
            <div class="primary-content">
                <article id="post-<?php the_ID(); ?>" <?php post_class( 'post' ); ?>>
                    <header class="entry-header">
                        <h1 class="page-title"><?php the_title(); ?></h1>
                    </header>

                    <div class="post-content">
                        <?php
                        // Display page content if any
                        if ( have_posts() ) {
                            while ( have_posts() ) {
                                the_post();
                                if ( ! empty( get_the_content() ) ) {
                                    the_content();
                                }
                            }
                        }
                        
                        // Get givers list from settings
                        $givers_list = get_option( 'ci_public_givers_list', '' );
                        
                        if ( ! empty( $givers_list ) ) {
                            echo '<div class="givers-list-container">';
                            echo '<div class="givers-list">';
                            echo wp_kses_post( wpautop( $givers_list ) );
                            echo '</div>';
                            echo '</div>';
                        } else {
                            echo '<div class="givers-list-empty">';
                            echo '<p>' . esc_html__( 'No public givers list has been configured yet. Please add givers information in Theme Settings > Givers Settings.', 'cambridge-independent' ) . '</p>';
                            echo '</div>';
                        }
                        ?>
                    </div>
                </article>
            </div>

            <?php get_sidebar(); ?>
        </div>
    </div>
</main>

<?php
get_footer();

