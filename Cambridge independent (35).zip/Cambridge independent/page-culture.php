<?php
/**
 * Template Name: Culture Page
 * 
 * Custom page template for displaying culture-related content
 *
 * @package Cambridge_Independent
 */

get_header();
?>

<main id="main" class="site-main">
    <div class="ci-container">
        <div class="culture-page-header">
            <h1 class="culture-page-title">Culture & Community</h1>
            <p class="culture-page-description">Discover the rich cultural heritage, community events, and local traditions that shape life in Cambridge and Somerville.</p>
        </div>
        
        <div class="culture-content-wrapper">
            <div class="culture-main-content">
                <?php
                // Get culture-related categories
                // First try to get from arts/culture settings
                $culture_cats = get_option( 'ci_arts_culture_categories', array() );
                
                // If no categories set, try to find culture-related categories
                if ( empty( $culture_cats ) ) {
                    $all_categories = get_categories( array(
                        'orderby' => 'name',
                        'order'   => 'ASC',
                    ) );
                    
                    foreach ( $all_categories as $cat ) {
                        $cat_slug = strtolower( $cat->slug );
                        if ( strpos( $cat_slug, 'culture' ) !== false || 
                             strpos( $cat_slug, 'community' ) !== false || 
                             strpos( $cat_slug, 'heritage' ) !== false ||
                             strpos( $cat_slug, 'tradition' ) !== false ||
                             strpos( $cat_slug, 'local' ) !== false ||
                             strpos( $cat_slug, 'events' ) !== false ) {
                            $culture_cats[] = $cat->term_id;
                        }
                    }
                }
                
                // Query for culture posts
                $culture_args = array(
                    'posts_per_page' => 20,
                    'post_status'    => 'publish',
                    'orderby'        => 'date',
                    'order'          => 'DESC',
                );
                
                if ( ! empty( $culture_cats ) && is_array( $culture_cats ) ) {
                    $culture_args['category__in'] = array_map( 'absint', $culture_cats );
                }
                
                $culture_query = new WP_Query( $culture_args );
                
                if ( $culture_query->have_posts() ) :
                    $post_index = 0;
                    $current_section = '';
                    
                    while ( $culture_query->have_posts() ) :
                        $culture_query->the_post();
                        $post_index++;
                        
                        // Get post categories to determine section
                        $categories = get_the_category();
                        $post_section = '';
                        
                        if ( ! empty( $categories ) ) {
                            foreach ( $categories as $category ) {
                                $cat_slug = strtolower( $category->slug );
                                if ( strpos( $cat_slug, 'community' ) !== false || 
                                     strpos( $cat_slug, 'local' ) !== false ) {
                                    $post_section = 'community';
                                    break;
                                } elseif ( strpos( $cat_slug, 'culture' ) !== false || 
                                          strpos( $cat_slug, 'heritage' ) !== false ||
                                          strpos( $cat_slug, 'tradition' ) !== false ) {
                                    $post_section = 'culture';
                                    break;
                                } elseif ( strpos( $cat_slug, 'events' ) !== false ) {
                                    $post_section = 'events';
                                    break;
                                }
                            }
                        }
                        
                        // Display section header if changed
                        if ( $post_section && $post_section !== $current_section ) {
                            $current_section = $post_section;
                            $section_title = '';
                            
                            switch ( $post_section ) {
                                case 'community':
                                    $section_title = 'COMMUNITY';
                                    break;
                                case 'culture':
                                    $section_title = 'CULTURE';
                                    break;
                                case 'events':
                                    $section_title = 'EVENTS';
                                    break;
                            }
                            
                            if ( $section_title ) {
                                echo '<div class="section-header"><h3 class="section-title">' . esc_html( $section_title ) . '</h3></div>';
                            }
                        }
                        
                        // Check if we should insert an ad
                        if ( $post_index > 0 && $post_index % 5 === 0 ) {
                            $ad_content = cambridge_independent_get_random_ad();
                            if ( $ad_content ) {
                                echo $ad_content;
                            }
                        }
                        
                        // Display the post
                        get_template_part( 'template-parts/homepage/article-item' );
                        
                    endwhile;
                    
                    // Pagination
                    echo '<div class="culture-pagination">';
                    the_posts_pagination( array(
                        'mid_size'  => 2,
                        'prev_text' => __( '← Previous', 'cambridge-independent' ),
                        'next_text' => __( 'Next →', 'cambridge-independent' ),
                    ) );
                    echo '</div>';
                    
                    wp_reset_postdata();
                else :
                    ?>
                    <div class="no-posts-message">
                        <p><?php _e( 'No culture posts found.', 'cambridge-independent' ); ?></p>
                        <p><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php _e( 'Return to homepage', 'cambridge-independent' ); ?></a></p>
                    </div>
                    <?php
                endif;
                ?>
            </div>
            
            <?php get_sidebar(); ?>
        </div>
    </div>
</main>

<?php
get_footer();

