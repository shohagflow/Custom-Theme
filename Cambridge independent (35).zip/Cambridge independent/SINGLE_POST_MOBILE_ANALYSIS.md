# Single Post Mobile Design Analysis

## Screenshot Requirements vs Current Implementation

### 1. **Category Tag**
**Screenshot:** 
- Displayed BEFORE the article title
- Text: "A BITE" (example)
- Font: Fira Sans (Light or Bold)
- Style: Uppercase, sans-serif
- Position: Above the title

**Current Implementation:**
- Category is shown in post-meta AFTER title
- Format: "in [category]"
- Not styled as Fira Sans
- Not positioned before title

**Required Changes:**
- Move category tag before title
- Style as Fira Sans (Light or Bold)
- Make it uppercase
- Position it above the title

---

### 2. **Article Title**
**Screenshot:**
- Font: Newsreader Semibold 600
- Size: 21 point (not 2em)
- No hyphenation
- Example: "Croissant bread pudding at Café Saint-Germain"

**Current Implementation:**
- Font: Newsreader (correct)
- Font-weight: 600 (correct)
- Size: 2em (needs to be 21pt)
- Hyphenation: Not specified (needs to be disabled)

**Required Changes:**
- Change font-size from `2em` to `21pt` (or `21px` for web)
- Add `hyphens: none;` to prevent hyphenation

---

### 3. **Author and Date**
**Screenshot:**
- Format: "By Marc Levy" (separate line)
- Format: "Wednesday, November 12, 2025" (full date format, separate line)
- Displayed below title, before image

**Current Implementation:**
- Format: Date first, then "by [author]", then "in [category]"
- Date format: Uses WordPress default (may not be full format)
- All in one line/block

**Required Changes:**
- Reorder to: Author first ("By [Author]"), then Date
- Use full date format: "l, F j, Y" (e.g., "Wednesday, November 12, 2025")
- Display on separate lines
- Remove category from this section (it's now above title)

---

### 4. **Featured Image**
**Screenshot:**
- Large, high-resolution image
- Displayed after title/author/date
- Full width
- High quality

**Current Implementation:**
- Image is displayed after header (correct position)
- Uses 'large' size
- Full width (correct)

**Required Changes:**
- Ensure image quality is high
- Verify sizing is appropriate for mobile

---

### 5. **Price Field**
**Screenshot:**
- Text: "Price $8" (example)
- Displayed below featured image
- Before body content

**Current Implementation:**
- Price field does not exist
- No custom field support for price

**Required Changes:**
- Add support for custom field "price" or "post_price"
- Display below featured image
- Format: "Price $[amount]"

---

### 6. **Body Content**
**Screenshot:**
- Font: Newsreader Regular 400
- Size: 17 point
- Displayed after price

**Current Implementation:**
- Font: Newsreader (correct family)
- Font-weight: Inherits from body (should be 400)
- Size: Inherits from body (17px - correct)
- Line-height: 1.7

**Required Changes:**
- Ensure font-weight is 400 (Regular)
- Verify font-size is exactly 17pt/17px
- Ensure proper line-height for readability

---

## Required Template Structure (Order)

1. **Category Tag** (Fira Sans, uppercase, before title)
2. **Article Title** (Newsreader Semibold 600, 21pt, no hyphenation)
3. **Author** ("By [Author]")
4. **Date** (Full format: "Wednesday, November 12, 2025")
5. **Featured Image** (Full width, high quality)
6. **Price** (If available: "Price $[amount]")
7. **Body Content** (Newsreader Regular 400, 17pt)

---

## Typography Summary

- **Category Tag:** Fira Sans (Light 300 or Bold 700), uppercase
- **Title:** Newsreader Semibold 600, 21pt, no hyphenation
- **Author/Date:** Fira Sans (likely Regular 400), standard size
- **Body Text:** Newsreader Regular 400, 17pt

---

## Mobile-Specific Considerations

- All elements should be full width
- Proper spacing between sections
- Readable font sizes for mobile
- Images should be responsive
- No horizontal scrolling

