<?php
/**
 * The template for displaying single posts
 *
 * @package Cambridge_Independent
 */

get_header();
?>

<main id="main" class="site-main">
    <div class="ci-container">
        <div class="content-area">
            <div class="primary-content">
                <?php
                while ( have_posts() ) :
                    the_post();
                    get_template_part( 'template-parts/content/content-single' );

                endwhile;
                ?>
            </div>

            <?php get_sidebar(); ?>
        </div>
    </div>
</main>

<?php
get_footer();
