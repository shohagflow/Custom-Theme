<?php
/**
 * The sidebar template file
 *
 * @package Cambridge_Independent
 */

// Check if Advanced Ads plugin is active
if ( function_exists( 'the_ad_placement' ) ) {
    // Use Advanced Ads plugin
    // Display all ads assigned to sidebar placement (multiple ads)
    ?>
    <aside id="secondary" class="advertisements-area">
        <h2 class="advertisements-heading">ADVERTISEMENTS</h2>
        <div class="advertisements-container">
            <?php
            // Display all ads assigned to sidebar placement
            // Advanced Ads will show all ads if multiple are assigned
            // Gap between ads is handled by CSS and JavaScript
            the_ad_placement( 'sidebar' );
            ?>
        </div>
    </aside>
    <?php
} else {
    // Fallback to default advertisements template
get_template_part( 'template-parts/sidebar/advertisements' );
}
