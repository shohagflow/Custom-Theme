<?php
/**
 * Advertisements Section Template
 *
 * @package Cambridge_Independent
 */
?>

<aside id="secondary" class="advertisements-area">
    <h2 class="advertisements-heading">ADVERTISEMENTS</h2>
    
    <div class="advertisements-container">
        <!-- Advertisement 1: Eugenia Schraa Huh for School Committee -->
        <div class="advertisement ad-eugenia">
            <div class="ad-eugenia-graphic">
                <div class="ad-eugenia-paper">
                    <span class="ad-eugenia-number">#1</span>
                </div>
                <div class="ad-eugenia-ruler"></div>
                <div class="ad-eugenia-pencil"></div>
            </div>
            <div class="ad-eugenia-text">
                <div class="ad-eugenia-name">
                    <span class="ad-eugenia-name-blue">EUGENIA SCHRAA</span>
                    <span class="ad-eugenia-name-red"> HUH</span>
                </div>
                <div class="ad-eugenia-office">
                    <span class="ad-eugenia-cambridge">CAMBRIDGE</span>
                    <span class="ad-eugenia-committee">SCHOOL COMMITTEE</span>
                </div>
                <div class="ad-eugenia-slogan">
                    <div class="ad-eugenia-slogan-line1">Real Rigor. Real Results.</div>
                    <div class="ad-eugenia-slogan-line2">From a Real Teacher.</div>
                </div>
            </div>
        </div>
        
        <!-- Advertisement 2: Jivan Sobrinho-Wheeler for City Council -->
        <div class="advertisement ad-jivan">
            <div class="ad-jivan-header">
                <div class="ad-jivan-buildings">🏢🏢</div>
                <div class="ad-jivan-name-section">
                    <div class="ad-jivan-name">JIVAN</div>
                    <div class="ad-jivan-subtitle">SOBRINHO-WHEELER</div>
                    <div class="ad-jivan-office">CAMBRIDGE<br>CITY COUNCIL</div>
                </div>
            </div>
            <div class="ad-jivan-body">
                <div class="ad-jivan-photo">
                    <div class="ad-jivan-photo-circle"></div>
                </div>
                <div class="ad-jivan-policies">
                    <div class="ad-jivan-policy">
                        <div class="ad-jivan-policy-icon">🏠</div>
                        <div class="ad-jivan-policy-text">AFFORDABLE<br>HOUSING</div>
                    </div>
                    <div class="ad-jivan-policy">
                        <div class="ad-jivan-policy-icon">🚴</div>
                        <div class="ad-jivan-policy-text">SAFE<br>STREETS</div>
                    </div>
                    <div class="ad-jivan-policy">
                        <div class="ad-jivan-policy-icon">🎓</div>
                        <div class="ad-jivan-policy-text">UNIVERSAL<br>AFTER-SCHOOL</div>
                    </div>
                </div>
            </div>
            <div class="ad-jivan-endorsements">
                <div class="ad-jivan-endorsed">ENDORSED BY</div>
                <div class="ad-jivan-logos">BC • AMOR • DSA • 🚴 • 🌿 • ORC</div>
            </div>
            <div class="ad-jivan-vote">
                <div class="ad-jivan-vote-text">VOTE #1 BY</div>
                <div class="ad-jivan-vote-date">NOVEMBER 4</div>
            </div>
        </div>
        
        <!-- Advertisement 3: Jess Goetz for School Committee -->
        <div class="advertisement ad-jess">
            <div class="ad-jess-header">
                <div class="ad-jess-name">JESS GOETZ</div>
                <div class="ad-jess-banner">#1 for School Committee</div>
            </div>
            <div class="ad-jess-body">
                <div class="ad-jess-slogan">BECAUSE PROCESS MATTERS</div>
                <div class="ad-jess-content">
                    <div class="ad-jess-vote-stamp">VOTE</div>
                    <div class="ad-jess-photo">
                        <div class="ad-jess-photo-placeholder">Photo</div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Advertisement 4: Avantor - Now Hiring -->
        <div class="advertisement ad-avantor">
            <div class="ad-avantor-header">
                <div class="ad-avantor-logo">
                    <span class="ad-avantor-icon">V</span>
                    <span class="ad-avantor-text">avantor</span>
                </div>
            </div>
            <div class="ad-avantor-body">
                <div class="ad-avantor-headline">Now Hiring Across Massachusetts!</div>
                <div class="ad-avantor-details">From scientific support to site operations — grow your career with us.</div>
                <div class="ad-avantor-button">
                    <span>APPLY NOW</span>
                    <span class="ad-avantor-arrow">→</span>
                </div>
            </div>
        </div>
        
        <!-- Advertisement 5: Zion Sherin for City Council -->
        <div class="advertisement ad-zion">
            <div class="ad-zion-header">
                <div class="ad-zion-waves">~~</div>
            </div>
            <div class="ad-zion-content">
                <div class="ad-zion-left">
                    <div class="ad-zion-keywords">
                        <div class="ad-zion-keyword">ZONING</div>
                        <div class="ad-zion-stars">★★★</div>
                        <div class="ad-zion-keyword">ENVIRONMENT</div>
                        <div class="ad-zion-keyword">LIVABILITY</div>
                        <div class="ad-zion-vote">Vote #1</div>
                    </div>
                    <div class="ad-zion-name">ZION SHERIN</div>
                    <div class="ad-zion-office">Cambridge City Council</div>
                </div>
                <div class="ad-zion-right">
                    <div class="ad-zion-photo">
                        <div class="ad-zion-photo-placeholder">Photo</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</aside>
