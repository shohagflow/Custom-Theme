<?php
/**
 * Template part for displaying page content
 *
 * @package Cambridge_Independent
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class( 'post' ); ?>>
    <?php
    if ( has_post_thumbnail() ) {
        ?>
        <div class="post-thumbnail">
            <?php the_post_thumbnail( 'large' ); ?>
        </div>
        <?php
    }
    ?>

    <div class="post-content">
        <?php 
        // Show donation success/error messages
        if ( isset( $_GET['donation'] ) ) {
            if ( $_GET['donation'] === 'success' ) {
                echo '<div class="donation-message success">';
                echo '<p><strong>Thank you!</strong> Your donation request has been submitted successfully. We will contact you shortly to complete the donation process.</p>';
                echo '</div>';
            } elseif ( $_GET['donation'] === 'error' ) {
                echo '<div class="donation-message error">';
                echo '<p><strong>Error:</strong> Please fill in all required fields and try again.</p>';
                echo '</div>';
            }
        }
        
        the_content(); 
        ?>
    </div>

    <?php
    wp_link_pages( array(
        'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'cambridge-independent' ),
        'after'  => '</div>',
    ) );
    ?>
</article>

