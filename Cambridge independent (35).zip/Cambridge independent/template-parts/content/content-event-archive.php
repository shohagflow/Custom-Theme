<?php
/**
 * Template part for displaying event content in archive
 *
 * @package Cambridge_Independent
 */

// Get event object
$event = tribe_get_event( get_the_ID() );
?>

<article id="post-<?php the_ID(); ?>" <?php post_class( 'post event-post' ); ?>>
    <header class="entry-header">
        <?php
        // Event category tag - displayed BEFORE title
        $event_categories = get_the_terms( get_the_ID(), 'tribe_events_cat' );
        if ( ! empty( $event_categories ) && ! is_wp_error( $event_categories ) ) {
            $event_category = $event_categories[0];
            echo '<div class="post-category-tag">' . esc_html( strtoupper( $event_category->name ) ) . '</div>';
        } else {
            // Fallback to EVENTS if no category
            echo '<div class="post-category-tag">EVENTS</div>';
        }
        ?>
        <h2 class="post-title">
            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
        </h2>
    </header>

    <div class="post-content-wrapper">
        <div class="post-image-column">
            <div class="post-thumbnail">
                <?php
                if ( has_post_thumbnail() ) {
                    the_post_thumbnail( 'large' );
                } else {
                    echo '<div class="post-thumbnail-placeholder"></div>';
                }
                ?>
            </div>
        </div>
        
        <div class="post-description-column">
            <div class="post-meta">
                <?php if ( $event ) : ?>
                    <div class="event-date">
                        <?php
                        $start_date = tribe_get_start_date( $event->ID, false, 'F j, Y' );
                        $start_time = tribe_get_start_date( $event->ID, false, 'g:i A' );
                        $end_date = tribe_get_end_date( $event->ID, false, 'F j, Y' );
                        $end_time = tribe_get_end_date( $event->ID, false, 'g:i A' );
                        
                        if ( $start_date === $end_date ) {
                            // Same day event
                            echo esc_html( $start_date );
                            if ( $start_time !== $end_time ) {
                                echo ' • ' . esc_html( $start_time ) . ' - ' . esc_html( $end_time );
                            } else {
                                echo ' • ' . esc_html( $start_time );
                            }
                        } else {
                            // Multi-day event
                            echo esc_html( $start_date ) . ' - ' . esc_html( $end_date );
                        }
                        ?>
                    </div>
                    
                    <?php
                    $venue = tribe_get_venue( $event->ID );
                    if ( $venue ) :
                        ?>
                        <div class="event-venue">
                            <?php echo esc_html( $venue ); ?>
                        </div>
                    <?php endif; ?>
                    
                    <?php
                    $cost = tribe_get_cost( $event->ID );
                    if ( $cost ) :
                        ?>
                        <div class="event-cost">
                            <?php echo esc_html( $cost ); ?>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>

            <div class="post-content">
                <?php echo esc_html( cambridge_independent_get_excerpt_400_chars() ); ?>
                <a href="<?php the_permalink(); ?>" class="read-more">Read More</a>
            </div>
        </div>
    </div>
</article>

