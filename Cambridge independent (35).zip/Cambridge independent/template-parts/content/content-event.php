<?php
/**
 * Template part for displaying single event content
 *
 * @package Cambridge_Independent
 */

// Get event object
$event = tribe_get_event( get_the_ID() );
?>

<article id="post-<?php the_ID(); ?>" <?php post_class( 'post event-post' ); ?>>
    <header class="entry-header">
        <?php
        // Event category tag - displayed BEFORE title
        $event_categories = get_the_terms( get_the_ID(), 'tribe_events_cat' );
        if ( ! empty( $event_categories ) && ! is_wp_error( $event_categories ) ) {
            $event_category = $event_categories[0];
            echo '<div class="post-category-tag">' . esc_html( strtoupper( $event_category->name ) ) . '</div>';
        } else {
            // Fallback to EVENTS if no category
            echo '<div class="post-category-tag">EVENTS</div>';
        }
        ?>
        
        <h1 class="post-title"><?php the_title(); ?></h1>

        <div class="post-meta">
            <?php if ( $event ) : ?>
                <div class="event-date">
                    <?php
                    $start_date = tribe_get_start_date( $event->ID, false, 'F j, Y' );
                    $start_time = tribe_get_start_date( $event->ID, false, 'g:i A' );
                    $end_date = tribe_get_end_date( $event->ID, false, 'F j, Y' );
                    $end_time = tribe_get_end_date( $event->ID, false, 'g:i A' );
                    
                    if ( $start_date === $end_date ) {
                        // Same day event
                        echo esc_html( $start_date );
                        if ( $start_time !== $end_time ) {
                            echo ' • ' . esc_html( $start_time ) . ' - ' . esc_html( $end_time );
                        } else {
                            echo ' • ' . esc_html( $start_time );
                        }
                    } else {
                        // Multi-day event
                        echo esc_html( $start_date ) . ' - ' . esc_html( $end_date );
                    }
                    ?>
                </div>
                
                <?php
                $venue = tribe_get_venue( $event->ID );
                if ( $venue ) :
                    ?>
                    <div class="event-venue">
                        <?php echo esc_html( $venue ); ?>
                        <?php
                        $address = tribe_get_address( $event->ID );
                        if ( $address ) {
                            echo ', ' . esc_html( $address );
                        }
                        ?>
                    </div>
                <?php endif; ?>
                
                <?php
                $cost = tribe_get_cost( $event->ID );
                if ( $cost ) :
                    ?>
                    <div class="event-cost">
                        <?php echo esc_html( $cost ); ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </header>

    <div class="post-thumbnail">
        <?php
        if ( has_post_thumbnail() ) {
            // Get image without width/height attributes for full width
            $thumbnail_id = get_post_thumbnail_id();
            $image = wp_get_attachment_image_src( $thumbnail_id, 'full' );
            if ( $image ) {
                echo '<img src="' . esc_url( $image[0] ) . '" alt="' . esc_attr( get_the_title() ) . '" class="event-featured-image" />';
            }
        } else {
            echo '<div class="post-thumbnail-placeholder"></div>';
        }
        ?>
    </div>

    <div class="post-content">
        <?php 
        // Display content exactly as written in editor
        // Get raw content without any modifications
        $content = get_post_field( 'post_content', get_the_ID() );
        // Apply WordPress content filters to process shortcodes, etc., but preserve formatting
        $content = apply_filters( 'the_content', $content );
        echo $content;
        ?>
    </div>

    <?php
    // Event details
    if ( $event ) :
        ?>
        <div class="event-details">
            <?php
            // Full event date/time details
            $full_start = tribe_get_start_date( $event->ID, false, 'l, F j, Y' );
            $full_start_time = tribe_get_start_date( $event->ID, false, 'g:i A' );
            $full_end = tribe_get_end_date( $event->ID, false, 'l, F j, Y' );
            $full_end_time = tribe_get_end_date( $event->ID, false, 'g:i A' );
            
            if ( $full_start === $full_end ) {
                echo '<div class="event-detail-item"><strong>Date:</strong> ' . esc_html( $full_start ) . '</div>';
                if ( $full_start_time !== $full_end_time ) {
                    echo '<div class="event-detail-item"><strong>Time:</strong> ' . esc_html( $full_start_time ) . ' - ' . esc_html( $full_end_time ) . '</div>';
                } else {
                    echo '<div class="event-detail-item"><strong>Time:</strong> ' . esc_html( $full_start_time ) . '</div>';
                }
            } else {
                echo '<div class="event-detail-item"><strong>Start:</strong> ' . esc_html( $full_start ) . ' at ' . esc_html( $full_start_time ) . '</div>';
                echo '<div class="event-detail-item"><strong>End:</strong> ' . esc_html( $full_end ) . ' at ' . esc_html( $full_end_time ) . '</div>';
            }
            
            // Venue details
            $venue_id = tribe_get_venue_id( $event->ID );
            if ( $venue_id ) {
                $venue_name = tribe_get_venue( $event->ID );
                $venue_address = tribe_get_address( $event->ID );
                $venue_city = tribe_get_city( $event->ID );
                $venue_state = tribe_get_stateprovince( $event->ID );
                $venue_zip = tribe_get_zip( $event->ID );
                $venue_phone = tribe_get_phone( $event->ID );
                $venue_website = tribe_get_venue_website_url( $event->ID );
                
                if ( $venue_name ) {
                    echo '<div class="event-detail-item"><strong>Venue:</strong> ' . esc_html( $venue_name ) . '</div>';
                }
                
                if ( $venue_address || $venue_city || $venue_state || $venue_zip ) {
                    $address_parts = array_filter( array( $venue_address, $venue_city, $venue_state, $venue_zip ) );
                    if ( ! empty( $address_parts ) ) {
                        echo '<div class="event-detail-item"><strong>Address:</strong> ' . esc_html( implode( ', ', $address_parts ) ) . '</div>';
                    }
                }
                
                if ( $venue_phone ) {
                    echo '<div class="event-detail-item"><strong>Phone:</strong> ' . esc_html( $venue_phone ) . '</div>';
                }
                
                if ( $venue_website ) {
                    echo '<div class="event-detail-item"><strong>Website:</strong> <a href="' . esc_url( $venue_website ) . '" target="_blank">' . esc_html( $venue_website ) . '</a></div>';
                }
            }
            
            // Cost
            if ( $cost ) {
                echo '<div class="event-detail-item"><strong>Cost:</strong> ' . esc_html( $cost ) . '</div>';
            }
            
            // Organizer
            $organizer = tribe_get_organizer( $event->ID );
            if ( $organizer ) {
                echo '<div class="event-detail-item"><strong>Organizer:</strong> ' . esc_html( $organizer ) . '</div>';
                $organizer_phone = tribe_get_organizer_phone( $event->ID );
                $organizer_email = tribe_get_organizer_email( $event->ID );
                $organizer_website = tribe_get_organizer_website_url( $event->ID );
                
                if ( $organizer_phone ) {
                    echo '<div class="event-detail-item"><strong>Organizer Phone:</strong> ' . esc_html( $organizer_phone ) . '</div>';
                }
                if ( $organizer_email ) {
                    echo '<div class="event-detail-item"><strong>Organizer Email:</strong> <a href="mailto:' . esc_attr( $organizer_email ) . '">' . esc_html( $organizer_email ) . '</a></div>';
                }
                if ( $organizer_website ) {
                    echo '<div class="event-detail-item"><strong>Organizer Website:</strong> <a href="' . esc_url( $organizer_website ) . '" target="_blank">' . esc_html( $organizer_website ) . '</a></div>';
                }
            }
            ?>
        </div>
    <?php endif; ?>

    <footer class="entry-footer">
        <?php
        $tags = get_the_tags();
        if ( $tags ) {
            echo '<div class="post-tags">';
            the_tags( 'Tags: ', ', ', '' );
            echo '</div>';
        }
        ?>
    </footer>
</article>

