<?php
/**
 * Template part for displaying single post content
 *
 * @package Cambridge_Independent
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class( 'post' ); ?>>
    <header class="entry-header">
        <?php
        // Category tag - displayed BEFORE title
        $categories = get_the_category();
        if ( ! empty( $categories ) ) {
            $category = $categories[0]; // Get first category
            echo '<div class="post-category-tag">' . esc_html( strtoupper( $category->name ) ) . '</div>';
        }
        ?>
        
        <h1 class="post-title"><?php the_title(); ?></h1>

        <div class="post-meta">
            <div class="post-author">
                By <?php the_author(); ?>
            </div>
            <div class="post-date">
                <?php echo get_the_date( 'l, F j, Y' ); ?>
            </div>
        </div>
    </header>

    <?php
    // Hide thumbnail for classifieds (advert post type)
    if ( get_post_type() !== 'advert' ) : ?>
    <div class="post-thumbnail">
    <?php
    if ( has_post_thumbnail() ) {
            the_post_thumbnail( 'large' );
        } else {
            echo '<div class="post-thumbnail-placeholder"></div>';
        }
        ?>
        </div>
        
        <?php
        // Author name - displayed below featured image
        echo '<div class="post-author-below-image">' . esc_html( get_the_author() ) . '</div>';
        ?>
    <?php endif; ?>
    
    <?php
    // Price field - displayed after featured image
    $price = get_post_meta( get_the_ID(), 'price', true );
    if ( ! empty( $price ) ) {
        echo '<div class="post-price">Price $' . esc_html( $price ) . '</div>';
    }
    ?>

    <div class="post-content">
        <?php
        // Display featured image caption before content
        if ( has_post_thumbnail() ) {
            $thumbnail_id = get_post_thumbnail_id();
            $caption = get_post_field( 'post_excerpt', $thumbnail_id );
            if ( ! empty( $caption ) ) {
                echo '<div class="post-image-caption">' . esc_html( $caption ) . '</div>';
            }
        }
        ?>

        <?php the_content(); ?>
    </div>

    <?php
    wp_link_pages( array(
        'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'cambridge-independent' ),
        'after'  => '</div>',
    ) );
    ?>

    <footer class="entry-footer">
        <?php
        $tags = get_the_tags();
        if ( $tags ) {
            echo '<div class="post-tags">';
            the_tags( '', ', ', '' );
            echo '</div>';
        }
        ?>
    </footer>
</article>

<?php
// Previous/next post navigation with custom separator
$prev_post = get_previous_post();
$next_post = get_next_post();
?>
<?php if ( $prev_post || $next_post ) : ?>
    <nav class="post-navigation">
        <?php
        // Check if timeline should be shown (3 or more posts in same category)
        $current_post_id = get_the_ID();
        $categories = wp_get_post_categories( $current_post_id );
        $show_timeline = false;
        
        if ( ! empty( $categories ) ) {
            $timeline_query = new WP_Query( array(
                'post_type'      => 'post',
                'posts_per_page' => -1, // Get all posts to count
                'category__in'   => $categories,
                'post__not_in'   => array( $current_post_id ),
                'orderby'         => 'date',
                'order'           => 'DESC',
                'fields'          => 'ids', // Only get IDs for faster counting
            ) );
            
            // Show timeline only if 3 or more posts exist
            if ( $timeline_query->found_posts >= 3 ) {
                $show_timeline = true;
            }
        }
        ?>
        
        <?php if ( $show_timeline ) : ?>
            <div class="timeline-button-wrapper">
                <button class="timeline-button" id="timeline-toggle">Timeline</button>
            </div>
            <div class="timeline-container" id="timeline-container" style="display: none;">
                <div class="timeline-content">
                    <?php
                    // Reset query to get full post data for display
                    wp_reset_postdata();
                    $timeline_display_query = new WP_Query( array(
                        'post_type'      => 'post',
                        'posts_per_page' => 8,
                        'category__in'   => $categories,
                        'post__not_in'   => array( $current_post_id ),
                        'orderby'         => 'date',
                        'order'           => 'DESC',
                    ) );
                    
                    if ( $timeline_display_query->have_posts() ) :
                        while ( $timeline_display_query->have_posts() ) : $timeline_display_query->the_post();
                            ?>
                            <div class="timeline-item">
                                <a href="<?php the_permalink(); ?>" class="timeline-link">
                                    <div class="timeline-title"><?php the_title(); ?></div>
                                    <div class="timeline-date"><?php echo get_the_date( 'l, F j, Y' ); ?></div>
                                </a>
                            </div>
                            <?php
                        endwhile;
                        wp_reset_postdata();
                    endif;
                    ?>
                </div>
            </div>
        <?php endif; ?>
        <div class="nav-links">
            <!-- Previous Button - Always visible -->
            <div class="nav-previous <?php echo ! $prev_post ? 'nav-disabled' : ''; ?>">
                <?php if ( $prev_post ) : ?>
                    <a href="<?php echo esc_url( get_permalink( $prev_post->ID ) ); ?>" rel="prev">
                        <span class="nav-subtitle"><?php esc_html_e( 'Previous story', 'cambridge-independent' ); ?></span>
                        <span class="nav-title"><?php echo esc_html( get_the_title( $prev_post->ID ) ); ?></span>
                        <span class="nav-date"><?php echo esc_html( get_the_date( 'F j, Y', $prev_post->ID ) ); ?></span>
                    </a>
                <?php else : ?>
                    <span class="nav-disabled-content">
                        <span class="nav-subtitle"><?php esc_html_e( 'Previous story', 'cambridge-independent' ); ?></span>
                        <span class="nav-title">—</span>
                        <span class="nav-date">—</span>
                    </span>
                <?php endif; ?>
            </div>
            
            <!-- Separator - Always visible -->
            <div class="nav-separator"></div>
            
            <!-- Next Button - Always visible -->
            <div class="nav-next <?php echo ! $next_post ? 'nav-disabled' : ''; ?>">
                <?php if ( $next_post ) : ?>
                    <a href="<?php echo esc_url( get_permalink( $next_post->ID ) ); ?>" rel="next">
                        <span class="nav-subtitle"><?php esc_html_e( 'Next story', 'cambridge-independent' ); ?></span>
                        <span class="nav-title"><?php echo esc_html( get_the_title( $next_post->ID ) ); ?></span>
                        <span class="nav-date"><?php echo esc_html( get_the_date( 'F j, Y', $next_post->ID ) ); ?></span>
                    </a>
                <?php else : ?>
                    <span class="nav-disabled-content">
                        <span class="nav-subtitle"><?php esc_html_e( 'Next story', 'cambridge-independent' ); ?></span>
                        <span class="nav-title">—</span>
                        <span class="nav-date">—</span>
                    </span>
                <?php endif; ?>
            </div>
        </div>
        
        <?php
        // Display Edit credit using post author
        $author = get_the_author();
        if ( ! empty( $author ) ) {
            echo '<div class="post-navigation-edit">';
            echo '<span class="edit-label">Edit:</span> ';
            echo '<span class="edit-name">' . esc_html( $author ) . '</span>';
            echo '</div>';
        }
        ?>
    </nav>
<?php endif; ?>

