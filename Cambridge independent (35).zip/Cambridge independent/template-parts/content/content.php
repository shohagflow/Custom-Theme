<?php
/**
 * Template part for displaying post content
 *
 * @package Cambridge_Independent
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class( 'post' ); ?>>
    <header class="entry-header">
        <?php
        // Category tag - displayed BEFORE title
        $categories = get_the_category();
        if ( ! empty( $categories ) ) {
            $category = $categories[0]; // Get first category
            echo '<div class="post-category-tag">' . esc_html( strtoupper( $category->name ) ) . '</div>';
        }
        ?>
        <h2 class="post-title">
            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
        </h2>
    </header>

    <div class="post-content-wrapper">
        <div class="post-image-column">
            <div class="post-thumbnail">
                <?php
                if ( has_post_thumbnail() ) : ?>
                    <a href="<?php the_permalink(); ?>">
                        <?php the_post_thumbnail( 'large', array( 'alt' => get_the_title() ) ); ?>
                    </a>
                <?php else :
                    echo '<div class="post-thumbnail-placeholder"></div>';
                endif;
                ?>
            </div>
        </div>
        
        <div class="post-description-column">
        <div class="post-meta">
            <span class="byline">
                by <?php the_author(); ?>
            </span>
            <span class="post-date">
                <?php echo get_the_date(); ?>
            </span>
        </div>

    <div class="post-content">
                <?php echo esc_html( cambridge_independent_get_excerpt_400_chars() ); ?>
        <?php if ( ! is_category() && ! is_archive() && ! is_tag() ) : ?>
            <a href="<?php the_permalink(); ?>" class="read-more">Read More</a>
        <?php endif; ?>
            </div>
        </div>
    </div>
</article>

