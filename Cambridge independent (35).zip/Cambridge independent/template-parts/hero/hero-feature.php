<?php
/**
 * Hero Feature Section Template
 * Displays featured post with image on left, content on right
 *
 * @package Cambridge_Independent
 */

// Get recent posts for hero section
// Get hero posts count from settings, default to 5
$hero_posts_unlimited = get_option( 'ci_hero_posts_unlimited', 0 );
$hero_posts_count = get_option( 'ci_hero_posts_count', 5 );

// If unlimited is enabled, use -1 to get all posts
$posts_per_page = $hero_posts_unlimited ? -1 : absint( $hero_posts_count );

// Apply city preference filtering
$preference = cambridge_independent_get_user_city_preference();
$hero_args = array(
    'posts_per_page' => $posts_per_page,
    'post_status'    => 'publish',
    'orderby'        => 'date',
    'order'          => 'DESC',
);

// Add city filtering if preference is set
if ( $preference !== 'all' ) {
    $other_city = ( $preference === 'cambridge' ) ? 'somerville' : 'cambridge';
    $hero_args['meta_query'] = array(
        'relation' => 'OR',
        array(
            'key' => '_ci_city_designation',
            'value' => $preference,
            'compare' => '=',
        ),
        array(
            'key' => '_ci_city_designation',
            'value' => 'regional',
            'compare' => '=',
        ),
        array(
            'key' => '_ci_city_designation',
            'compare' => 'NOT EXISTS',
        ),
    );
}

$hero_query = new WP_Query( $hero_args );

// Filter out excluded city posts
if ( $preference !== 'all' && $hero_query->have_posts() ) {
    $filtered_posts = array();
    $other_city = ( $preference === 'cambridge' ) ? 'somerville' : 'cambridge';
    
    foreach ( $hero_query->posts as $post ) {
        $city_designation = get_post_meta( $post->ID, '_ci_city_designation', true );
        if ( $city_designation !== $other_city ) {
            $filtered_posts[] = $post;
        }
    }
    
    $hero_query->posts = $filtered_posts;
    $hero_query->post_count = count( $filtered_posts );
}

if ( $hero_query->have_posts() ) :
    $hero_posts = array();
    $post_index = 0;
    
    while ( $hero_query->have_posts() ) :
        $hero_query->the_post();
        $hero_posts[] = array(
            'id'        => get_the_ID(),
            'title'     => get_the_title(),
            'permalink' => get_permalink(),
            'excerpt'   => cambridge_independent_get_hero_excerpt_183_chars( get_the_ID() ),
            'thumbnail' => has_post_thumbnail() ? get_the_post_thumbnail_url( get_the_ID(), 'large' ) : '',
        );
    endwhile;
    
    wp_reset_postdata();
    
    // Display first post
    $current_post = $hero_posts[0];
    ?>
    <section class="hero-feature" data-posts='<?php echo esc_attr( json_encode( $hero_posts ) ); ?>'>
        <div class="hero-inner">
            <div class="hero-left-column">
                <div class="hero-media">
                    <?php
                    if ( ! empty( $current_post['thumbnail'] ) ) {
                        echo '<img src="' . esc_url( $current_post['thumbnail'] ) . '" alt="' . esc_attr( $current_post['title'] ) . '" class="hero-image" />';
                    } else {
                        echo '<div class="hero-image-placeholder"></div>';
                    }
                    ?>
                </div>
            </div>
            
            <div class="hero-content">
                <div>
                <h1 class="hero-title">
                    <a href="<?php echo esc_url( $current_post['permalink'] ); ?>"><?php echo esc_html( $current_post['title'] ); ?></a>
                </h1>
                
                <p class="hero-excerpt" style="margin-top: 20px;">
                    <?php echo esc_html( $current_post['excerpt'] ); ?>
                </p>
                </div>
                
                <div class="hero-controls">
                    <button class="hero-control hero-prev" aria-label="Previous" disabled>
                        <span class="hero-arrow hero-arrow-left"></span>
                    </button>
                    <span class="hero-divider-vertical">|</span>
                    <button class="hero-control hero-next" aria-label="Next" <?php echo count( $hero_posts ) <= 1 ? 'disabled' : ''; ?>>
                        <span class="hero-arrow hero-arrow-right"></span>
                    </button>
                </div>
            </div>
        </div>
        
        <div class="hero-footer">
            <div class="hero-footer-lines-top">
                <div class="hero-footer-line hero-line-light"></div>
                <div class="hero-footer-line hero-line-dark"></div>
            </div>
            <a href="<?php echo esc_url( home_url( '/events' ) ); ?>" class="hero-cta" data-events-url="<?php echo esc_url( home_url( '/events' ) ); ?>">
                See the event calendar
            </a>
            <div class="hero-footer-lines-bottom">
                <div class="hero-footer-line hero-line-dark"></div>
                <div class="hero-footer-line hero-line-light"></div>
            </div>
        </div>
        <div class="homepage-columns">
            <!-- News and Business Column -->
            <div class="homepage-column column-news-business">
                <?php get_template_part( 'template-parts/homepage/column-news-business' ); ?>
            </div>
            
            <!-- Arts, Culture, Media, Food Column -->
            <div class="homepage-column column-arts-culture">
                <?php get_template_part( 'template-parts/homepage/column-arts-culture' ); ?>
            </div>
        </div>
    </section>
    <?php
endif;

