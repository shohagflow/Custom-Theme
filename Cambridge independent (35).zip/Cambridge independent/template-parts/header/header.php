<?php
/**
 * The header template file
 *
 * @package Cambridge_Independent
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<div id="page" class="site">
    <!-- Desktop Classifieds Section at Top -->
    <div class="desktop-classifieds-top">
        <div class="ci-container">
            <div class="classifieds-section">
                <div class="classifieds-content">
                    <div class="classifieds-content-grid">
                        <!-- JOB Column -->
                        <div class="classified-item">
                            <h3 class="classified-category">JOB</h3>
                            <div class="classified-description">
                                <?php
                                // Use WPAdverts if active, otherwise fallback to theme settings
                                $job_content = cambridge_independent_get_wpadverts_ad_by_category(
                                    'job',
                                    get_option( 'ci_classified_job', 'Elder Care Needed in Cambridge ...' ),
                                    true // Include image
                                );
                                // Check if it's HTML (from WPAdverts) or plain text (fallback)
                                if ( strpos( $job_content, '<' ) !== false ) {
                                    echo $job_content; // HTML output
                                } else {
                                    echo '<span class="classified-ad-text">' . esc_html( $job_content ) . '</span>';
                                }
                                ?>
                            </div>
                        </div>
                        
                        <!-- PLACE Column -->
                        <div class="classified-item">
                            <h3 class="classified-category">PLACE</h3>
                            <div class="classified-description">
                                <?php
                                // Use WPAdverts if active, otherwise fallback to theme settings
                                $place_content = cambridge_independent_get_wpadverts_ad_by_category(
                                    'place',
                                    get_option( 'ci_classified_place', 'Spacious 1 BR Apartment in Somerville/Cambridge Line (Somerville) $2,425 ...' ),
                                    true // Include image
                                );
                                // Check if it's HTML (from WPAdverts) or plain text (fallback)
                                if ( strpos( $place_content, '<' ) !== false ) {
                                    echo $place_content; // HTML output
                                } else {
                                    echo '<span class="classified-ad-text">' . esc_html( $place_content ) . '</span>';
                                }
                                ?>
                            </div>
                        </div>

                        <!-- HEY Column -->
                        <div class="classified-item">
                            <h3 class="classified-category">HEY</h3>
                            <div class="classified-description">
                                <?php
                                // Use WPAdverts if active, otherwise fallback to theme settings
                                $hey_content = cambridge_independent_get_wpadverts_ad_by_category(
                                    'hey',
                                    get_option( 'ci_classified_hey', 'Do you live in Cambridge/Somerville & get the New Yorker in print? ...' ),
                                    true // Include image
                                );
                                // Check if it's HTML (from WPAdverts) or plain text (fallback)
                                if ( strpos( $hey_content, '<' ) !== false ) {
                                    echo $hey_content; // HTML output
                                } else {
                                    echo '<span class="classified-ad-text">' . esc_html( $hey_content ) . '</span>';
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Footer Links -->
                    <div class="footer-links-and-copyright-text">
                        <div class="classifieds-footer">
                            <a href="<?php echo esc_url( cambridge_independent_get_wpadverts_list_url() ); ?>" class="classifieds-link">See all ads</a>
                            <span class="classifieds-separator">|</span>
                            <a href="<?php echo esc_url( cambridge_independent_get_wpadverts_add_url() ); ?>" class="classifieds-link">Buy an ad</a>
                            <span class="classifieds-separator">|</span>
                            <a href="<?php echo esc_url( get_option( 'ci_classified_donate_url', home_url( '/donate' ) ) ); ?>" class="classifieds-link">Donate to the Independent</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Mobile Classifieds Section at Top -->
    <div class="mobile-classifieds-top">
        <div class="ci-container">
            <div class="classifieds-section">
                <div class="classifieds-content">
                    <div class="classifieds-content-grid">
                        <!-- JOB Column -->
                        <div class="classified-item">
                            <h3 class="classified-category">JOB</h3>
                            <div class="classified-description">
                                <?php
                                // Use WPAdverts if active, otherwise fallback to theme settings
                                $job_content = cambridge_independent_get_wpadverts_ad_by_category(
                                    'job',
                                    get_option( 'ci_classified_job', 'Elder Care Needed in Cambridge ...' ),
                                    true // Include image
                                );
                                // Check if it's HTML (from WPAdverts) or plain text (fallback)
                                if ( strpos( $job_content, '<' ) !== false ) {
                                    echo $job_content; // HTML output
                                } else {
                                    echo '<span class="classified-ad-text">' . esc_html( $job_content ) . '</span>';
                                }
                                ?>
                            </div>
                        </div>
                        
                        <!-- PLACE Column -->
                        <div class="classified-item">
                            <h3 class="classified-category">PLACE</h3>
                            <div class="classified-description">
                                <?php
                                // Use WPAdverts if active, otherwise fallback to theme settings
                                $place_content = cambridge_independent_get_wpadverts_ad_by_category(
                                    'place',
                                    get_option( 'ci_classified_place', 'Spacious 1 BR Apartment in Somerville/Cambridge Line (Somerville) $2,425 ...' ),
                                    true // Include image
                                );
                                // Check if it's HTML (from WPAdverts) or plain text (fallback)
                                if ( strpos( $place_content, '<' ) !== false ) {
                                    echo $place_content; // HTML output
                                } else {
                                    echo '<span class="classified-ad-text">' . esc_html( $place_content ) . '</span>';
                                }
                                ?>
                            </div>
                        </div>

                        <!-- HEY Column -->
                        <div class="classified-item">
                            <h3 class="classified-category">HEY</h3>
                            <div class="classified-description">
                                <?php
                                // Use WPAdverts if active, otherwise fallback to theme settings
                                $hey_content = cambridge_independent_get_wpadverts_ad_by_category(
                                    'hey',
                                    get_option( 'ci_classified_hey', 'Do you live in Cambridge/Somerville & get the New Yorker in print? ...' ),
                                    true // Include image
                                );
                                // Check if it's HTML (from WPAdverts) or plain text (fallback)
                                if ( strpos( $hey_content, '<' ) !== false ) {
                                    echo $hey_content; // HTML output
                                } else {
                                    echo '<span class="classified-ad-text">' . esc_html( $hey_content ) . '</span>';
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Footer Links -->
                    <div class="footer-links-and-copyright-text">
                        <div class="classifieds-footer">
                            <a href="<?php echo esc_url( cambridge_independent_get_wpadverts_list_url() ); ?>" class="classifieds-link">See all ads</a>
                            <span class="classifieds-separator">|</span>
                            <a href="<?php echo esc_url( cambridge_independent_get_wpadverts_add_url() ); ?>" class="classifieds-link">Buy an ad</a>
                            <span class="classifieds-separator">|</span>
                            <a href="<?php echo esc_url( get_option( 'ci_classified_donate_url', home_url( '/donate' ) ) ); ?>" class="classifieds-link">Donate to the Independent</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <header id="masthead" class="site-header">
        <div class="header-main">
            <div class="ci-container">
                <div class="site-branding">
                    <h1 class="site-title">
                        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
                            <div class="site-logo-wrapper">
                                <div class="site-location"><?php echo esc_html( get_option( 'ci_topbar_text', get_option( 'ci_location_text', 'Cambridge | Somerville' ) ) ); ?></div>
                            <?php
                            // Check for WordPress custom logo first
                            if ( has_custom_logo() ) {
                                the_custom_logo();
                            } else {
                                // Check for theme option logo
                            $logo_image = get_option( 'ci_logo_image' );
                            $logo_width = get_option( 'ci_logo_width' );
                            $logo_height = get_option( 'ci_logo_height' );
                                
                                // Check for default logo in assets/images
                                $default_logo = get_template_directory_uri() . '/assets/images/independent-logo.png';
                                $default_logo_path = get_template_directory() . '/assets/images/independent-logo.png';
                            
                            if ( ! empty( $logo_image ) ) {
                                $logo_style = '';
                                if ( ! empty( $logo_width ) ) $logo_style .= 'width: ' . esc_attr( $logo_width ) . 'px; ';
                                if ( ! empty( $logo_height ) ) $logo_style .= 'height: ' . esc_attr( $logo_height ) . 'px; ';
                                echo '<img src="' . esc_url( $logo_image ) . '" alt="' . esc_attr( get_bloginfo( 'name' ) ) . '" style="' . $logo_style . '" />';
                                } elseif ( file_exists( $default_logo_path ) ) {
                                    // Use default logo if it exists
                                    echo '<img src="' . esc_url( $default_logo ) . '" alt="' . esc_attr( get_bloginfo( 'name' ) ) . '" class="site-logo" />';
                            } else {
                                    // Fallback to text
                                        echo '<div class="site-title-text">' . esc_html( get_option( 'ci_site_logo_text', 'INDEPENDENT' ) ) . '</div>';
                                }
                            }
                            ?>
                            </div>
                        </a>
                    </h1>
        
                    <!-- Hamburger Menu on Right -->
                    <div class="menu-toggle-wrapper">
                        <button class="menu-toggle" aria-controls="primary-menu" aria-expanded="false" aria-label="<?php esc_attr_e( 'Toggle navigation menu', 'cambridge-independent' ); ?>">
                            <span class="screen-reader-text"><?php _e( 'Menu', 'cambridge-independent' ); ?></span>
                            <span class="menu-toggle-icon">
                                <span></span>
                                <span></span>
                                <span></span>
                            </span>
                        </button>
                        
                        <!-- Hamburger Dropdown Menu -->
                        <div class="hamburger-menu-content" id="hamburger-menu-content">
                            <?php cambridge_independent_render_hamburger_menu_items(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="header-navigation">
            <div class="ci-container">
                <!-- Mobile: Hamburger Menu (Left) -->
                <div class="menu-toggle-wrapper mobile-hamburger">
                    <button class="menu-toggle" aria-controls="primary-menu" aria-expanded="false" aria-label="<?php esc_attr_e( 'Toggle navigation menu', 'cambridge-independent' ); ?>">
                        <span class="screen-reader-text"><?php _e( 'Menu', 'cambridge-independent' ); ?></span>
                        <span class="menu-toggle-icon">
                            <span></span>
                            <span></span>
                            <span></span>
                        </span>
                    </button>
                    
                    <!-- Hamburger Dropdown Menu -->
                    <div class="hamburger-menu-content" id="hamburger-menu-content-mobile">
                        <?php cambridge_independent_render_hamburger_menu_items(); ?>
                    </div>
                </div>
                
                <!-- Navigation Menu (Center) -->
                    <nav id="site-navigation" class="main-navigation">
                        <?php
                        wp_nav_menu( array(
                            'theme_location' => 'primary',
                            'menu_id'        => 'primary-menu',
                            'fallback_cb'    => 'cambridge_independent_fallback_menu',
                            'container'      => false,
                            'menu_class'     => 'nav-menu',
                            'depth'          => 2, // Allow sub-menus
                        ) );
                        ?>
                    </nav>
                    
                <!-- Search Bar (Right) - Mobile only -->
                <div class="header-search mobile-search">
                    <div class="ci-container">
                            <?php get_search_form(); ?>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="header-search desktop-search">
            <div class="ci-container">
                <?php get_search_form(); ?>
            </div>
        </div>
        
        <div class="ci-container">
            <div class="search-lines-bottom">
                <div class="search-line-bottom"></div>
                <div class="search-line-bottom"></div>
            </div>
        </div>
        
        <!-- Hamburger Menu Overlay (Background) -->
        <div class="hamburger-menu-overlay" id="hamburger-menu-overlay"></div>
    </header>
