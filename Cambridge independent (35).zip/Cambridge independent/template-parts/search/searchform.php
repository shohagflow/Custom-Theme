<?php
/**
 * Template for displaying search form
 *
 * @package Cambridge_Independent
 */
?>

<form role="search" method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
    <div class="search-line-top"></div>
    <div class="search-wrapper">
        <div class="search-separator"></div>
        <span class="search-icon">
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M11.4351 10.0629H10.7124L10.4562 9.81589C11.3528 8.77301 11.8925 7.4191 11.8925 5.94626C11.8925 2.66209 9.23042 0 5.94626 0C2.66209 0 0 2.66209 0 5.94626C0 9.23042 2.66209 11.8925 5.94626 11.8925C7.4191 11.8925 8.77301 11.3528 9.81589 10.4562L10.0629 10.7124V11.4351L14.6369 16L16 14.6369L11.4351 10.0629ZM5.94626 10.0629C3.66838 10.0629 1.82962 8.22414 1.82962 5.94626C1.82962 3.66838 3.66838 1.82962 5.94626 1.82962C8.22414 1.82962 10.0629 3.66838 10.0629 5.94626C10.0629 8.22414 8.22414 10.0629 5.94626 10.0629Z" fill="#d1d1d1"/>
            </svg>
        </span>
        <input type="search" class="search-field" placeholder="SEARCH" value="<?php echo get_search_query(); ?>" name="s" />
    </div>
</form>
