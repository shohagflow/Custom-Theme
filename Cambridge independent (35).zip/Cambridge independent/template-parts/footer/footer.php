<?php
/**
 * The footer template file
 *
 * @package Cambridge_Independent
 */
?>

    <footer id="colophon" class="site-footer">
        <div class="ci-container">
            <!-- Copyright Text -->
                    <div class="footer-links-and-copyright-text">
                        <div class="copyright-text">
                            <?php echo get_option( 'ci_copyright_text', '© ' . date( 'Y' ) . ' Cambridge Somerville Independent.' ); ?>
                </div>
            </div>
            
            <?php
            // Display social media links if any are set
            $social_links = array(
                'facebook'  => get_option( 'ci_facebook_url' ),
                'twitter'   => get_option( 'ci_twitter_url' ),
                'instagram' => get_option( 'ci_instagram_url' ),
                'linkedin'  => get_option( 'ci_linkedin_url' ),
                'youtube'   => get_option( 'ci_youtube_url' ),
            );
            
            $has_social = false;
            foreach ( $social_links as $link ) {
                if ( ! empty( $link ) ) {
                    $has_social = true;
                    break;
                }
            }
            
            if ( $has_social ) {
                echo '<div class="social-links">';
                if ( ! empty( $social_links['facebook'] ) ) {
                    echo '<a href="' . esc_url( $social_links['facebook'] ) . '" target="_blank" rel="noopener noreferrer" class="social-link facebook">Facebook</a>';
                }
                if ( ! empty( $social_links['twitter'] ) ) {
                    echo '<a href="' . esc_url( $social_links['twitter'] ) . '" target="_blank" rel="noopener noreferrer" class="social-link twitter">Twitter</a>';
                }
                if ( ! empty( $social_links['instagram'] ) ) {
                    echo '<a href="' . esc_url( $social_links['instagram'] ) . '" target="_blank" rel="noopener noreferrer" class="social-link instagram">Instagram</a>';
                }
                if ( ! empty( $social_links['linkedin'] ) ) {
                    echo '<a href="' . esc_url( $social_links['linkedin'] ) . '" target="_blank" rel="noopener noreferrer" class="social-link linkedin">LinkedIn</a>';
                }
                if ( ! empty( $social_links['youtube'] ) ) {
                    echo '<a href="' . esc_url( $social_links['youtube'] ) . '" target="_blank" rel="noopener noreferrer" class="social-link youtube">YouTube</a>';
                }
                echo '</div>';
            }
            ?>
        </div>
    </footer>
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>

