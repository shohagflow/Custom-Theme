<?php
/**
 * Inline Advertisement Template
 * Used for ads that appear within content columns
 *
 * @package Cambridge_Independent
 */

// Get image URLs
$ad_images_url = get_template_directory_uri() . '/assets/images/';
$image1_url = $ad_images_url . 'image.png';
$image2_url = $ad_images_url . '12121.png';

// Randomly pick one image
$random_image = ( rand( 0, 1 ) === 0 ) ? $image1_url : $image2_url;
?>

<div class="inline-advertisement">
    
    <div class="inline-ads-container">
        <div class="inline-ad-image-wrapper">
            <a href="#" class="inline-ad-image-link">
                <img src="<?php echo esc_url( $random_image ); ?>" alt="Advertisement" class="inline-ad-image" />
            </a>
        </div>
    </div>
</div>

