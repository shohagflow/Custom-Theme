<?php
/**
 * Arts, Culture, Media, Food Column Template
 *
 * @package Cambridge_Independent
 */

// Get hero post ID to exclude
$hero_post_id = 0;
$hero_query = new WP_Query( array(
    'posts_per_page' => 1,
    'post_status'    => 'publish',
    'orderby'        => 'date',
    'order'          => 'DESC',
) );
if ( $hero_query->have_posts() ) {
    $hero_query->the_post();
    $hero_post_id = get_the_ID();
    wp_reset_postdata();
}

// Get posts for arts/culture column
// Get Arts, Culture & Media category IDs from settings
$arts_culture_cats = get_option( 'ci_arts_culture_categories', array() );
$posts_per_column = get_option( 'ci_homepage_posts_per_column', 15 );

// Get posts from selected Arts, Culture & Media categories
$arts_query = cambridge_independent_get_homepage_posts( 
    array( $hero_post_id ), 
    '', // category slug - not used if category IDs are set
    $posts_per_column, // number of posts
    $arts_culture_cats // category IDs from settings
);

if ( $arts_query->have_posts() ) :
    $post_index = 0;
    
    while ( $arts_query->have_posts() ) :
        $arts_query->the_post();
        $post_index++;
        
        // Display the post
        get_template_part( 'template-parts/homepage/article-item' );
        
        // Check if we should insert an ad (randomly every 2-4 posts)
        if ( cambridge_independent_should_insert_ad( $post_index ) ) {
            $ad_content = cambridge_independent_get_random_ad();
            if ( $ad_content ) {
                echo $ad_content;
            }
        }
        
    endwhile;
    
    wp_reset_postdata();
endif;

