<?php
/**
 * Homepage Article Item Template
 * Displays article in column layout with image and excerpt
 *
 * @package Cambridge_Independent
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class( 'homepage-article' ); ?>>
    <?php
    // Category tag - displayed FIRST
    $categories = get_the_category();
    if ( ! empty( $categories ) ) {
        $category = $categories[0]; // Get first category
        echo '<div class="article-category-tag">' . esc_html( strtoupper( $category->name ) ) . '</div>';
    }
    ?>
    
    <h3 class="article-title">
        <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
    </h3>
    
    <div class="article-meta">
        <span class="article-date"><?php echo get_the_date(); ?></span>
    </div>
    
    <div class="article-content-wrapper">
        <div class="article-image-column">
            <div class="article-thumbnail">
                <?php if ( has_post_thumbnail() ) : ?>
                    <a href="<?php the_permalink(); ?>">
                        <?php the_post_thumbnail( 'medium', array( 'alt' => get_the_title() ) ); ?>
                    </a>
                <?php else : ?>
                    <div class="article-thumbnail-placeholder"></div>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="article-description-column">
            <div class="article-excerpt">
                <?php echo esc_html( cambridge_independent_get_excerpt_130_chars() ); ?>
            </div>
        </div>
    </div>
</article>

