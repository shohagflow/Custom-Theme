<?php
/**
 * The template for displaying archive pages
 *
 * @package Wheelfy
 */

get_header();
?>

<div class="container mx-auto px-4 lg:px-8 py-16">
    <header class="mb-12">
        <?php
        the_archive_title('<h1 class="text-4xl md:text-5xl font-bold text-foreground mb-4">', '</h1>');
        the_archive_description('<div class="text-lg text-muted-foreground">', '</div>');
        ?>
    </header>

    <?php
    if (have_posts()) {
        ?>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <?php
            while (have_posts()) {
                the_post();
                get_template_part('template-parts/content', get_post_type());
            }
            ?>
        </div>

        <div class="mt-12">
            <?php
            the_posts_pagination(array(
                'mid_size' => 2,
                'prev_text' => __('Previous', 'wheelfy'),
                'next_text' => __('Next', 'wheelfy'),
            ));
            ?>
        </div>
        <?php
    } else {
        get_template_part('template-parts/content', 'none');
    }
    ?>
</div>

<?php
get_footer();


