<?php
/**
 * The template for displaying all pages
 *
 * @package Wheelfy
 */

get_header();
?>

<div class="container mx-auto px-4 lg:px-8 py-16">
    <?php
    while (have_posts()) {
        the_post();
        ?>
        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <header class="mb-8">
                <?php the_title('<h1 class="text-4xl md:text-5xl font-bold text-foreground mb-4">', '</h1>'); ?>
            </header>

            <div class="prose prose-invert max-w-none">
                <?php
                the_content();
                wp_link_pages(array(
                    'before' => '<div class="page-links mt-8 pt-8 border-t border-border">' . esc_html__('Pages:', 'wheelfy'),
                    'after'  => '</div>',
                ));
                ?>
            </div>

            <?php
            // If comments are open or we have at least one comment, load up the comment template.
            if (comments_open() || get_comments_number()) {
                comments_template();
            }
            ?>
        </article>
        <?php
    }
    ?>
</div>

<?php
get_footer();


