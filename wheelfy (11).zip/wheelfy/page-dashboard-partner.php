<?php
/**
 * Template Name: Partner Dashboard
 *
 * Professional partner profile dashboard shown after login/registration.
 *
 * @package Wheelfy
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Require login
if ( ! is_user_logged_in() ) {
    wp_redirect( wp_login_url( home_url( '/partner-dashboard' ) ) );
    exit;
}

$current_user = wp_get_current_user();

// STRICT: Check user role directly - must be 'partner'
// Partner dashboard is ONLY for partners, not admins or customers
// EXCEPTION: Administrators can view partner dashboards for management purposes
$user_roles = $current_user->roles;

// Check if admin is viewing a partner's dashboard
$viewing_user_id = $current_user->ID;
$is_admin_viewing = false;

if ( in_array('administrator', $user_roles) && current_user_can('manage_options') ) {
    // If admin is viewing, allow access but check if viewing specific user
    if ( isset($_GET['user_id']) && intval($_GET['user_id']) > 0 ) {
        $viewing_user_id = intval($_GET['user_id']);
        $viewing_user = get_userdata($viewing_user_id);
        if ( $viewing_user && in_array('partner', $viewing_user->roles) ) {
            $is_admin_viewing = true;
            // Allow admin to view partner dashboard
        } else {
            // Invalid user or not a partner, redirect
            wp_redirect( admin_url('admin.php?page=wheelfy-users&tab=partners') );
    exit;
        }
    } else {
        // Admin accessing without user_id, redirect to admin
        wp_redirect( admin_url() );
        exit;
    }
}

// If user is customer, redirect to customer dashboard
if ( in_array('customer', $user_roles) && !$is_admin_viewing ) {
    wp_redirect( home_url( '/customer-dashboard' ) );
    exit;
}

// If user is not partner role and not admin viewing, redirect to customer dashboard (fix role)
if ( !in_array('partner', $user_roles) && !$is_admin_viewing ) {
    // User has wrong role - redirect to customer dashboard
    wp_redirect( home_url( '/customer-dashboard' ) );
    exit;
}

// Get user data - use viewing_user_id (partner's ID if admin is viewing, current user's ID otherwise)
$viewing_user_obj = $is_admin_viewing ? get_userdata($viewing_user_id) : $current_user;
$user_type    = get_user_meta( $viewing_user_id, 'user_type', true );

$user_name    = $viewing_user_obj->display_name ? $viewing_user_obj->display_name : $viewing_user_obj->user_login;
$user_email   = $viewing_user_obj->user_email;
$business_name = get_user_meta( $viewing_user_id, 'business_name', true );
$user_registered = $viewing_user_obj->user_registered;

// Get user's first letter for avatar
$user_initials = strtoupper( substr( $user_name, 0, 1 ) );

// Check for custom profile image first
$profile_image_id = get_user_meta( $viewing_user_id, 'profile_image_id', true );
if ( $profile_image_id && is_numeric( $profile_image_id ) ) {
    $user_avatar = wp_get_attachment_image_url( $profile_image_id, 'full' );
} else {
    // Fall back to Gravatar
    $user_avatar = get_avatar_url( $viewing_user_id, array( 'size' => 150 ) );
}

// Get user meta data
$user_bio = get_user_meta( $viewing_user_id, 'user_bio', true );
$user_phone = get_user_meta( $viewing_user_id, 'phone_number', true );
$user_location = get_user_meta( $viewing_user_id, 'user_location', true );
$user_facebook = get_user_meta( $viewing_user_id, 'user_facebook', true );
$user_twitter = get_user_meta( $viewing_user_id, 'user_twitter', true );
$user_instagram = get_user_meta( $viewing_user_id, 'user_instagram', true );
$user_linkedin = get_user_meta( $viewing_user_id, 'user_linkedin', true );
$partner_profession = get_user_meta( $viewing_user_id, 'partner_profession', true );
$partner_price = get_user_meta( $viewing_user_id, 'partner_price', true );
$partner_experience = get_user_meta( $viewing_user_id, 'partner_experience', true );
$partner_type = get_user_meta( $viewing_user_id, 'partner_type', true );
$is_car_dealership = ($partner_type === 'car_dealership');

// Get verification status
$is_verified = get_user_meta( $viewing_user_id, 'partner_verified', true );

// Get partner statistics
$active_requests = wheelfy_get_partner_active_requests_count($viewing_user_id); // Active service requests (accepted/in-progress)
$quotes_sent = 24; // Quotes/proposals sent to customers
$completed_jobs = wheelfy_get_partner_completed_jobs_count($viewing_user_id); // Completed services
// For Car Dealership: Get cars purchased count, for others: use completed jobs
$cars_purchased = $is_car_dealership ? (function_exists('wheelfy_get_partner_cars_purchased_count') ? wheelfy_get_partner_cars_purchased_count($viewing_user_id) : 0) : $completed_jobs;
$total_revenue = 12500; // Total revenue earned
$total_reviews = wheelfy_get_partner_reviews_count($viewing_user_id); // Reviews received (approved/published only)
$total_messages = wheelfy_get_messages_received_count($viewing_user_id); // Dynamic: active conversations count
$response_rate = wheelfy_get_partner_response_rate($viewing_user_id); // Response rate percentage

// Dummy requests data for Requests section
$dummy_requests = array(
    array(
        'id' => 'req_' . uniqid(),
        'customer_name' => 'John Doe',
        'customer_email' => 'john.doe@example.com',
        'request_type' => 'premium',
        'request_details' => '2021 BMW 3 Series - Car Accessories Request (GPS Navigation, Leather Seats, Premium Sound System)',
        'request_date' => date('Y-m-d H:i:s', strtotime('-2 hours')),
        'status' => 'pending'
    ),
    array(
        'id' => 'req_' . uniqid(),
        'customer_name' => 'Jane Smith',
        'customer_email' => 'jane.smith@example.com',
        'request_type' => 'normal',
        'request_details' => '2020 Toyota Camry - Service Request (Oil Change, Tire Rotation)',
        'request_date' => date('Y-m-d H:i:s', strtotime('-1 day')),
        'status' => 'pending'
    ),
    array(
        'id' => 'req_' . uniqid(),
        'customer_name' => 'Mike Johnson',
        'customer_email' => 'mike.j@example.com',
        'request_type' => 'premium',
        'request_details' => '2019 Mercedes C-Class - Premium Service (Full Service Package)',
        'request_date' => date('Y-m-d H:i:s', strtotime('-3 days')),
        'status' => 'accepted'
    ),
    array(
        'id' => 'req_' . uniqid(),
        'customer_name' => 'Sarah Williams',
        'customer_email' => 'sarah.williams@example.com',
        'request_type' => 'normal',
        'request_details' => '2022 Honda Accord - Brake Service Request',
        'request_date' => date('Y-m-d H:i:s', strtotime('-5 hours')),
        'status' => 'pending'
    ),
    array(
        'id' => 'req_' . uniqid(),
        'customer_name' => 'David Brown',
        'customer_email' => 'david.brown@example.com',
        'request_type' => 'premium',
        'request_details' => '2023 Audi A4 - Car Accessories (Sunroof, Heated Seats, Safety Package)',
        'request_date' => date('Y-m-d H:i:s', strtotime('-12 hours')),
        'status' => 'pending'
    ),
    array(
        'id' => 'req_' . uniqid(),
        'customer_name' => 'Emily Davis',
        'customer_email' => 'emily.davis@example.com',
        'request_type' => 'normal',
        'request_details' => '2018 Ford Focus - Battery Replacement Request',
        'request_date' => date('Y-m-d H:i:s', strtotime('-2 days')),
        'status' => 'pending'
    ),
    array(
        'id' => 'req_' . uniqid(),
        'customer_name' => 'Robert Taylor',
        'customer_email' => 'robert.taylor@example.com',
        'request_type' => 'premium',
        'request_details' => '2021 Tesla Model 3 - Premium Maintenance Service',
        'request_date' => date('Y-m-d H:i:s', strtotime('-4 days')),
        'status' => 'accepted'
    )
);

// Get subscription plans from database (only active plans)
$subscription_plans = wheelfy_get_subscription_plans_db(true, 'display_order', 'ASC');

// Get partner's current subscription from database
$current_subscription = wheelfy_get_partner_subscription($viewing_user_id);
$current_plan_id = $current_subscription ? $current_subscription->plan_id : 0;
$current_plan_slug = $current_subscription ? $current_subscription->plan_slug : 'basic';

// Get current plan details
$current_plan = $current_subscription ? wheelfy_get_subscription_plan_by_id($current_subscription->plan_id) : wheelfy_get_subscription_plan_by_slug('basic');

// Get recent activities (get more for pagination)
$recent_activities = wheelfy_get_partner_recent_activities($viewing_user_id, 50);

// Calculate profile completion for partners
// Required fields: Name, Business Name, Email, Phone, Location, Biography
$completion_fields = 0;
$total_fields = 6; // name, business_name, email, phone, location, bio

// Check each required field
if ( !empty($user_name) && $user_name !== 'Not added' ) $completion_fields++;
if ( !empty($business_name) && $business_name !== 'Not added' ) $completion_fields++;
if ( !empty($user_email) ) $completion_fields++;
if ( !empty($user_phone) && $user_phone !== 'Not added' ) $completion_fields++;
if ( !empty($user_location) && $user_location !== 'Not added' ) $completion_fields++;
if ( !empty($user_bio) && $user_bio !== 'Not added' ) $completion_fields++;

$completion_percentage = round( ( $completion_fields / $total_fields ) * 100 );

get_header();
?>

<style>
.dashboard-container {
    display: flex;
    min-height: calc(100vh - 200px);
    background: hsl(var(--background));
    max-width: 1280px;
    margin: 0 auto; 
    width: 100%;
    gap: 30px;
    padding: 30px 0px;
    align-items: flex-start;
}

.dashboard-sidebar {
    width: 280px;
    min-width: 280px;
    background: hsl(var(--card));
    border: 1px solid hsl(var(--border));
    border-radius: 1rem;
    padding: 0;
    position: sticky;
    top: 1rem;
    height: fit-content;
    max-height: calc(100vh - 120px);
    overflow: visible;
    flex-shrink: 0;
    box-shadow: 0 2px 8px hsl(var(--background) / 0.3);
    display: flex; 
    flex-direction: column; 
    margin: 0;
}

.sidebar-header {
    padding: 2rem 1.75rem 1.75rem;
    border-bottom: 1px solid hsl(var(--border));
    background: hsl(var(--card));
    position: relative;
    text-align: center;
}

.profile-image-container {
    position: relative;
    width: 100px;
    height: 100px;
    margin: 0 auto 1.5rem;
}

.profile-image {
    width: 100px;
    height: 100px;
    border-radius: 50%;
    object-fit: cover;
    border: 4px solid transparent;
    background: linear-gradient(135deg, hsl(60 96% 79%), hsl(186 80% 19%));
    padding: 4px;
    box-shadow: 0 8px 24px hsl(var(--primary) / 0.25), 0 0 0 1px hsl(var(--primary) / 0.2);
    transition: transform 0.3s ease;
}

.profile-image:hover {
    transform: scale(1.05);
}

.profile-initials {
    width: 100px;
    height: 100px;
    border-radius: 50%;
    background: linear-gradient(135deg, hsl(60 96% 79%), hsl(186 80% 19%));
    display: flex;
    align-items: center; 
    justify-center;
    font-size: 2.5rem;
    font-weight: 800;
    color: hsl(var(--primary-foreground));
    border: 4px solid hsl(var(--card));
    box-shadow: 0 8px 24px hsl(var(--primary) / 0.25), 0 0 0 1px hsl(var(--primary) / 0.2), inset 0 2px 4px hsl(var(--primary) / 0.3);
    position: relative;
    transition: transform 0.3s ease;
}

.profile-initials:hover {
    transform: scale(1.05);
}

.profile-initials::before {
    content: '';
    position: absolute;
    inset: -4px;
    border-radius: 50%;
    padding: 4px;
    background: linear-gradient(135deg, hsl(60 96% 79%), hsl(186 80% 19%));
    -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
    -webkit-mask-composite: xor;
    mask-composite: exclude;
    z-index: -1;
}

.profile-name {
    text-align: center;
    font-size: 1.125rem;
    font-weight: 700;
    color: hsl(var(--foreground));
    margin-bottom: 0.375rem;
    letter-spacing: -0.02em;
    line-height: 1.3;
    justify-content: center;
}

/* Verified Badge in Dashboard Sidebar */
.verified-badge-dashboard {
    position: relative;
    animation: verifiedPulseDashboard 2s ease-in-out infinite;
    transition: transform 0.2s ease;
}

.verified-badge-dashboard:hover {
    transform: scale(1.1);
}

.verified-badge-dashboard::after {
    content: attr(data-tooltip);
    position: absolute;
    bottom: calc(100% + 8px);
    left: 50%;
    transform: translateX(-50%);
    padding: 0.5rem 0.75rem;
    background: rgba(0, 0, 0, 0.9);
    color: white;
    font-size: 0.75rem;
    font-weight: 600;
    white-space: nowrap;
    border-radius: 0.5rem;
    opacity: 0;
    visibility: hidden;
    transition: all 0.2s ease;
    pointer-events: none;
    z-index: 1000;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
}

.verified-badge-dashboard::before {
    content: '';
    position: absolute;
    bottom: calc(100% + 2px);
    left: 50%;
    transform: translateX(-50%);
    border: 6px solid transparent;
    border-top-color: rgba(0, 0, 0, 0.9);
    opacity: 0;
    visibility: hidden;
    transition: all 0.2s ease;
    z-index: 1001;
}

.verified-badge-dashboard:hover::after,
.verified-badge-dashboard:hover::before {
    opacity: 1;
    visibility: visible;
}

@keyframes verifiedPulseDashboard {
    0%, 100% {
        box-shadow: 0 2px 8px rgba(0, 200, 83, 0.4);
    }
    50% {
        box-shadow: 0 2px 12px rgba(0, 200, 83, 0.6);
    }
}

.profile-email {
    text-align: center;
    font-size: 0.8125rem;
    color: hsl(var(--muted-foreground));
    word-break: break-all;
    padding: 0.375rem 0.75rem;
    background: hsl(var(--background) / 0.5);
    border-radius: 0.5rem;
    display: block;
    margin: 0.25rem auto 0;
    width: fit-content;
    max-width: 100%;
}

/* Upgrade Plan Section */
.sidebar-upgrade-section {
    padding: 1rem 1.25rem;
    border-top: 1px solid hsl(var(--border));
    border-bottom: 1px solid hsl(var(--border));
    background: hsl(var(--background) / 0.3);
}

.upgrade-plan-card {
    background: linear-gradient(135deg, hsl(var(--primary) / 0.1), hsl(var(--primary) / 0.05));
    border: 1px solid hsl(var(--primary) / 0.2);
    border-radius: 0.875rem;
    padding: 1rem;
    transition: all 0.3s ease;
}

.upgrade-plan-card:hover {
    border-color: hsl(var(--primary) / 0.4);
    box-shadow: 0 4px 12px hsl(var(--primary) / 0.15);
    transform: translateY(-2px);
}

.upgrade-plan-header {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    margin-bottom: 0.75rem;
}

.upgrade-plan-header svg {
    width: 20px;
    height: 20px;
    color: hsl(var(--primary));
    flex-shrink: 0;
}

.upgrade-plan-info {
    flex: 1;
}

.upgrade-plan-label {
    font-size: 0.75rem;
    color: hsl(var(--muted-foreground));
    margin: 0 0 0.25rem 0;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    font-weight: 600;
}

.upgrade-plan-name {
    font-size: 0.9375rem;
    font-weight: 700;
    color: hsl(var(--foreground));
    margin: 0;
}

.upgrade-plan-btn {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
    width: 100%;
    padding: 0.625rem 1rem;
    background: linear-gradient(135deg, hsl(60 96% 79%), hsl(186 80% 19%));
    color: hsl(var(--primary-foreground));
    border: none;
    border-radius: 0.625rem;
    font-size: 0.875rem;
    font-weight: 600;
    text-decoration: none;
    transition: all 0.3s ease;
    cursor: pointer;
    box-shadow: 0 2px 8px hsl(var(--primary) / 0.2);
}

.upgrade-plan-btn:hover {
    transform: translateY(-1px);
    box-shadow: 0 4px 12px hsl(var(--primary) / 0.3);
    background: linear-gradient(135deg, hsl(60 96% 75%), hsl(186 80% 15%));
}

.upgrade-plan-btn svg {
    width: 16px;
    height: 16px;
    transition: transform 0.3s ease;
}

.upgrade-plan-btn:hover svg {
    transform: translateX(2px);
}

.dashboard-nav {
    padding: 1.25rem 1rem 1.5rem;
    flex: 1;
    display: flex;
    flex-direction: column;
    gap: 0;
    overflow-y: auto;
    overflow-x: hidden;
    min-height: 0;
    scrollbar-width: thin;
    scrollbar-color: hsl(var(--border)) transparent;
}

.dashboard-nav::-webkit-scrollbar {
    width: 6px;
}

.dashboard-nav::-webkit-scrollbar-track {
    background: transparent;
}

.dashboard-nav::-webkit-scrollbar-thumb {
    background: hsl(var(--border));
    border-radius: 3px;
}

.dashboard-nav::-webkit-scrollbar-thumb:hover {
    background: hsl(var(--muted-foreground) / 0.5);
}

.nav-item {
    display: flex;
    align-items: center;
    gap: 1rem;
    padding: 1rem 1.25rem;
    margin-bottom: 0.5rem;
    border-radius: 0.875rem;
    color: hsl(var(--muted-foreground));
    text-decoration: none;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    position: relative;
    font-size: 0.9375rem;
    font-weight: 500;
    border: 1px solid transparent;
}

.nav-item:last-of-type {
    margin-bottom: 0;
}

.nav-item[data-section="settings"] {
    margin-bottom: 1.5rem;
}

.nav-item:hover {
    background: hsl(var(--secondary) / 0.4);
    color: hsl(var(--foreground));
    transform: translateX(6px);
    border-color: hsl(var(--border));
}

.nav-item.active {
    background: linear-gradient(90deg, hsl(var(--primary) / 0.2), hsl(var(--primary) / 0.08));
    color: hsl(var(--primary));
    font-weight: 600;
    box-shadow: 0 4px 12px hsl(var(--primary) / 0.15), inset 0 0 0 1px hsl(var(--primary) / 0.2);
    transform: translateX(0);
}

.nav-item.active::before {
    content: '';
    position: absolute;
    left: 0;
    top: 50%;
    transform: translateY(-50%);
    width: 4px;
    height: 75%;
    background: linear-gradient(180deg, hsl(60 96% 79%), hsl(186 80% 19%));
    border-radius: 0 4px 4px 0;
    box-shadow: 0 0 12px hsl(var(--primary) / 0.6);
}

.nav-item svg {
    width: 21px;
    height: 21px;
    flex-shrink: 0;
    transition: transform 0.3s ease;
}

.nav-item:hover svg {
    transform: scale(1.1);
}

.nav-item.active svg {
    transform: scale(1.05);
    filter: drop-shadow(0 0 4px hsl(var(--primary) / 0.5));
}

.nav-item .badge {
    margin-left: auto;
    background: hsl(var(--primary));
    color: hsl(var(--primary-foreground));
    font-size: 0.75rem;
    font-weight: 600;
    padding: 0.25rem 0.5rem;
    border-radius: 9999px;
    min-width: 1.5rem;
    text-align: center;
}

.nav-item .badge.badge-new {
    background: hsl(var(--destructive));
    color: white;
}

.nav-item-logout {
    display: flex;
    align-items: center;
    gap: 1rem;
    padding: 1rem 1.25rem;
    margin-top: auto;
    margin-bottom: 0;
    border-radius: 0.875rem;
    color: hsl(var(--destructive));
    text-decoration: none;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    border-top: 1px solid hsl(var(--border));
    padding-top: 1.5rem;
    font-weight: 500;
    border-left: 1px solid transparent;
    border-right: 1px solid transparent;
    border-bottom: 1px solid transparent;
    background: hsl(var(--destructive) / 0.05);
    flex-shrink: 0;
}

.nav-item-logout:hover {
    background: hsl(var(--destructive) / 0.12);
    border-color: hsl(var(--destructive) / 0.3);
    transform: translateX(4px);
    box-shadow: 0 2px 8px hsl(var(--destructive) / 0.15);
}

.nav-item-logout svg {
    width: 21px;
    height: 21px;
    flex-shrink: 0;
    transition: transform 0.3s ease;
}

.nav-item-logout:hover svg {
    transform: translateX(2px);
}

.dashboard-content {
    flex: 1;
    padding: 0;
    overflow-x: hidden;
    max-width: calc(1280px - 280px - 30px);
    width: 100%;
    min-width: 0;
    margin: 0;
    display: flex;
    flex-direction: column;
    gap: 0;
}

.dashboard-section {
    display: none;
    background: hsl(var(--card));
    border: 1px solid hsl(var(--border));
    border-radius: 1rem;
    margin-bottom: 0;
    margin-left: 0;
    margin-right: 0;
    overflow: hidden;
    opacity: 0;
    transform: translateY(20px);
    transition: opacity 0.3s ease, transform 0.3s ease;
    width: 100%;
    max-width: 100%;
    box-sizing: border-box;
    box-shadow: 0 1px 3px hsl(var(--background) / 0.2);
}

.dashboard-section.active {
    display: block;
    opacity: 1;
    transform: translateY(0);
    animation: fadeInUp 0.4s ease-out;
}

@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.section-header {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    margin-top: 0;
    margin-bottom: 0;
    padding: 2.5rem 2.5rem 2rem;
    border-bottom: 1px solid hsl(var(--border));
    background: linear-gradient(135deg, hsl(var(--card)), hsl(var(--card) / 0.98));
    border-radius: 1rem 1rem 0 0;
    width: 100%;
    max-width: 100%;
    box-sizing: border-box;
    position: relative;
    overflow: hidden;
}

.section-header::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: linear-gradient(90deg, hsl(60 96% 79%), hsl(186 80% 19%));
    opacity: 0.8;
}

.dashboard-overview,
.profile-content,
.settings-content {
    padding: 2.5rem 2.5rem 3rem;
    width: 100%;
    max-width: 100%;
    box-sizing: border-box;
    margin: 0;
    background: hsl(var(--card));
}

.section-header h1 {
    font-size: 2.5rem;
    font-weight: 800;
    color: hsl(var(--foreground));
    margin: 0 0 0.75rem;
    letter-spacing: -0.04em;
    line-height: 1.2;
    background: linear-gradient(135deg, hsl(var(--foreground)), hsl(var(--foreground) / 0.8));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.welcome-text {
    color: hsl(var(--muted-foreground));
    font-size: 1rem;
    font-weight: 500;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.welcome-text::before {
    content: '👋';
    font-size: 1.125rem;
}

.dashboard-overview {
    display: grid; 
    grid-template-columns: 1fr; 
    gap: 0;
    background: hsl(var(--card));
}

.overview-cards {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
    gap: 1.75rem;
    margin-bottom: 2.5rem;
}

.overview-card {
    background: linear-gradient(135deg, hsl(var(--card)), hsl(var(--card) / 0.95));
    border: 1.5px solid hsl(var(--border));
    border-radius: 1.5rem;
    padding: 2.25rem 2rem;
    display: flex;
    align-items: center;
    gap: 1.75rem;
    transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
    position: relative;
    overflow: hidden;
    box-shadow: 0 2px 8px hsl(var(--background) / 0.1);
}

.overview-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: linear-gradient(90deg, hsl(60 96% 79%), hsl(186 80% 19%));
    opacity: 0;
    transition: opacity 0.4s ease;
}

.overview-card::after {
    content: '';
    position: absolute;
    top: -50%;
    right: -50%;
    width: 200%;
    height: 200%;
    background: radial-gradient(circle, hsl(var(--primary) / 0.05) 0%, transparent 70%);
    opacity: 0;
    transition: opacity 0.4s ease;
}

.overview-card:hover {
    border-color: hsl(var(--primary) / 0.5);
    transform: translateY(-6px);
    box-shadow: 0 12px 32px hsl(var(--primary) / 0.2), 0 0 0 1px hsl(var(--primary) / 0.3);
    background: linear-gradient(135deg, hsl(var(--card)), hsl(var(--card) / 0.98));
}

.overview-card:hover::before {
    opacity: 1;
}

.overview-card:hover::after {
    opacity: 1;
}

.overview-icon {
    width: 72px;
    height: 72px;
    border-radius: 1.25rem;
    display: flex; 
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
    position: relative;
    box-shadow: 0 4px 12px hsl(var(--primary) / 0.15);
}

.overview-icon svg {
    width: 32px;
    height: 32px;
    display: block;
    transition: transform 0.4s ease;
}

.overview-card:hover .overview-icon {
    transform: scale(1.1) rotate(5deg);
    box-shadow: 0 6px 16px hsl(var(--primary) / 0.25);
}

.overview-card:hover .overview-icon svg {
    transform: scale(1.1);
}

.overview-icon-info {
    background: linear-gradient(135deg, hsl(var(--primary) / 0.15), hsl(var(--primary) / 0.1));
    color: hsl(var(--primary));
    border: 2px solid hsl(var(--primary) / 0.2);
}

.overview-content h3 {
    font-size: 2.75rem;
    font-weight: 800;
    color: hsl(var(--foreground));
    margin: 0 0 0.5rem;
    letter-spacing: -0.03em;
    line-height: 1;
    background: linear-gradient(135deg, hsl(var(--foreground)), hsl(var(--foreground) / 0.7));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    transition: all 0.3s ease;
}

.overview-card:hover .overview-content h3 {
    transform: scale(1.05);
}

.overview-content p {
    font-size: 0.9375rem;
    color: hsl(var(--muted-foreground));
    margin: 0;
    font-weight: 500;
    letter-spacing: 0.01em;
}

.recent-activity-summary {
    background: linear-gradient(135deg, hsl(var(--card) / 0.5), hsl(var(--card) / 0.3));
    border: 1.5px solid hsl(var(--border));
    border-radius: 1.25rem;
    padding: 2rem;
    transition: all 0.3s ease;
    margin-top: 0;
    box-shadow: 0 2px 8px hsl(var(--background) / 0.05);
    position: relative;
    overflow: hidden;
}

.recent-activity-summary::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 4px;
    height: 100%;
    background: linear-gradient(180deg, hsl(60 96% 79%), hsl(186 80% 19%));
    opacity: 0.6;
}

.recent-activity-summary:hover {
    border-color: hsl(var(--primary) / 0.3);
    box-shadow: 0 4px 16px hsl(var(--primary) / 0.1);
    transform: translateY(-2px);
}

.recent-activity-summary h2 {
    font-size: 1.5rem;
    font-weight: 700;
    color: hsl(var(--foreground));
    margin: 0 0 2rem;
    letter-spacing: -0.02em;
    display: flex;
    align-items: center;
    gap: 0.75rem;
}

.recent-activity-summary h2::before {
    content: '📊';
    font-size: 1.5rem;
}

.activity-summary-list {
    margin-bottom: 1.5rem;
}

.activity-summary-item {
    display: flex;
    align-items: flex-start;
    gap: 1.25rem;
    padding: 1.25rem;
    margin-bottom: 0.75rem;
    border-radius: 0.875rem;
    border: 1px solid transparent;
    background: hsl(var(--card) / 0.5);
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    cursor: pointer;
}

.activity-summary-item.activity-hidden {
    display: none;
}

.activity-summary-item:hover {
    padding-left: 1.5rem;
    border-color: hsl(var(--primary) / 0.2);
    background: hsl(var(--card) / 0.8);
    box-shadow: 0 2px 8px hsl(var(--primary) / 0.1);
    transform: translateX(4px);
}

.activity-summary-item:last-child:not(.activity-hidden) {
    border-bottom: none;
}

.load-more-activities-btn {
    display: block;
    width: 100%;
    padding: 0.875rem;
    margin-top: 1rem;
    background: hsl(var(--secondary));
    border: 1px solid hsl(var(--border));
    border-radius: 0.5rem;
    color: hsl(var(--foreground));
    cursor: pointer;
    font-size: 0.875rem;
    transition: all 0.2s;
    text-align: center;
}

.load-more-activities-btn:hover {
    background: hsl(var(--primary) / 0.1);
    border-color: hsl(var(--primary) / 0.5);
}

.activity-summary-icon {
    width: 14px;
    height: 14px;
    border-radius: 50%;
    flex-shrink: 0;
    margin-top: 0.5rem;
    box-shadow: 0 0 0 4px hsl(var(--card)), 0 3px 6px hsl(var(--background) / 0.4);
    transition: all 0.3s ease;
}

.activity-summary-item:hover .activity-summary-icon {
    transform: scale(1.2);
    box-shadow: 0 0 0 4px hsl(var(--card)), 0 4px 8px hsl(var(--background) / 0.5);
}

.activity-icon-info {
    background: hsl(var(--primary));
}

.activity-icon-success {
    background: hsl(142 76% 36%);
}

.activity-icon-warning {
    background: hsl(var(--warning));
}

.activity-summary-content p {
    margin: 0 0 0.25rem;
    color: hsl(var(--foreground));
    font-size: 0.875rem;
}

.activity-summary-content p strong {
    font-weight: 600;
}

.activity-summary-content span {
    font-size: 0.75rem;
    color: hsl(var(--muted-foreground));
}

.view-all-link {
    color: hsl(var(--primary));
    text-decoration: none;
    font-size: 0.9375rem;
    font-weight: 600;
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    transition: all 0.3s ease;
    padding: 0.75rem 1.25rem;
    border-radius: 0.75rem;
    background: hsl(var(--primary) / 0.05);
    border: 1px solid hsl(var(--primary) / 0.1);
    margin-top: 0.5rem;
}

.view-all-link:hover {
    gap: 0.75rem;
    background: hsl(var(--primary) / 0.1);
    border-color: hsl(var(--primary) / 0.3);
    transform: translateX(4px);
    box-shadow: 0 2px 8px hsl(var(--primary) / 0.15);
}

/* Mobile First Responsive Styles */
@media (max-width: 768px) {
    .dashboard-container {
        flex-direction: column;
        gap: 1rem;
        padding: 0 0.75rem;
        min-height: auto;
    }
    
    .dashboard-sidebar {
        width: 100%;
        min-width: 100%;
        height: auto;
        position: relative;
        top: 0;
        border-right: none;
        border-bottom: 1px solid hsl(var(--border));
        border-radius: 0.75rem;
        margin: 0.5rem 0;
        max-height: none;
        box-shadow: 0 2px 8px hsl(var(--background) / 0.3);
    }
    
    .sidebar-header {
        padding: 1.5rem 1rem 1.25rem;
    }
    
    .profile-image-container {
        width: 80px;
        height: 80px;
        margin: 0 auto 1rem;
    }
    
    .profile-image,
    .profile-initials {
        width: 80px;
        height: 80px;
        font-size: 2rem;
    }
    
    .edit-image-btn {
        width: 28px;
        height: 28px;
    }
    
    .edit-image-btn svg {
        width: 14px;
        height: 14px;
    }
    
    .profile-name {
        font-size: 1rem;
    }
    
    .profile-email {
        font-size: 0.75rem;
        padding: 0.25rem 0.5rem;
    }
    
    .dashboard-nav {
        display: flex;
        flex-direction: column;
        overflow: visible;
        overflow-x: hidden;
        padding: 0.75rem 0.75rem 0.75rem;
        gap: 0;
        width: 100%;
    }
    
    .nav-item {
        white-space: normal;
        word-wrap: break-word;
        margin-bottom: 0.5rem;
        padding: 0.75rem 1rem;
        font-size: 0.875rem;
        width: 100%;
        max-width: 100%;
        flex-shrink: 0;
        box-sizing: border-box;
    }
    
    .nav-item svg {
        width: 18px;
        height: 18px;
    }
    
    .nav-item[data-section="settings"] {
        margin-bottom: 1.5rem;
    }
    
    .nav-item-logout {
        margin-top: 0;
        border-top: 1px solid hsl(var(--border));
        padding-top: 0.75rem;
        padding-bottom: 0.75rem;
        margin-bottom: 0.5rem;
        width: 100%;
        max-width: 100%;
        box-sizing: border-box;
        white-space: normal;
        word-wrap: break-word;
    }
    
    .nav-item-logout svg {
        width: 18px;
        height: 18px;
    }
    
    .dashboard-content {
        max-width: 100%;
        padding: 0;
        margin: 0.5rem 0;
    }
    
    .dashboard-section {
        margin-bottom: 1.5rem;
        border-radius: 0.75rem;
    }
    
    .section-header {
        padding: 1.25rem 1rem 1rem;
        flex-direction: column;
        gap: 0.75rem;
        align-items: flex-start;
    }
    
    .section-header h1 {
        font-size: 1.5rem;
    }
    
    .welcome-text {
        font-size: 0.875rem;
    }
    
    .dashboard-overview {
        padding: 1.25rem 1rem 1.5rem;
    }
    
    .overview-cards {
    grid-template-columns: 1fr; 
        gap: 1rem;
        margin-bottom: 1.5rem;
    }
    
    .overview-card {
        padding: 1.25rem;
        gap: 1rem;
    }
    
    .overview-icon {
        width: 48px;
        height: 48px;
    }
    
    .overview-icon svg {
        width: 22px;
        height: 22px;
    }
    
    .overview-content h3 {
        font-size: 2rem;
    }
    
    .overview-content p {
        font-size: 0.8125rem;
    }
    
    .recent-activity-summary {
        padding: 1.25rem;
    }
    
    .recent-activity-summary h2 {
        font-size: 1.125rem;
        margin-bottom: 1.25rem;
    }
    
    .activity-summary-item {
        padding: 0.875rem 0;
        gap: 0.875rem;
    }
    
    .profile-content {
        padding: 1.25rem 1rem 1.5rem;
    }
    
    .profile-card {
        padding: 1.5rem;
        margin-bottom: 1.5rem;
        border-radius: 0.75rem;
    }
    
    .card-header {
        margin-bottom: 1rem;
        padding-bottom: 0.875rem;
        flex-wrap: wrap;
        gap: 0.5rem;
    }
    
    .card-header h3 {
        font-size: 1.125rem;
    }
    
    .stats-grid {
        grid-template-columns: 1fr;
        gap: 1rem;
    }
    
    .stat-card {
        padding: 1.25rem;
    }
    
    .stat-icon {
        width: 40px;
        height: 40px;
    }
    
    .stat-icon svg {
        width: 20px;
        height: 20px;
    }
    
    .stat-value {
        font-size: 1.5rem;
    }
    
    .quick-actions-grid {
        grid-template-columns: 1fr;
        gap: 0.75rem;
    }
    
    .quick-action-btn {
        padding: 0.875rem;
        font-size: 0.875rem;
    }
    
    .info-grid {
        grid-template-columns: 1fr;
        gap: 1.5rem;
    }
    
    .info-item label {
        margin-bottom: 0.75rem;
    }
    
    .info-value {
        padding: 0.75rem 0;
    }
    
    .social-links-container {
        gap: 0.75rem;
    }
    
    .social-link-item {
        padding: 0.875rem;
    }
    
    .activity-timeline {
        gap: 1.25rem;
    }
    
    .activity-item {
        padding-left: 3rem;
        gap: 1rem;
        padding-bottom: 1.25rem;
    }
    
    .activity-item::before {
        left: 18px;
        top: 36px;
    }
    
    .activity-icon {
        width: 36px;
        height: 36px;
        border-radius: 0.5rem;
    }
    
    .activity-icon svg {
        width: 18px;
        height: 18px;
    }
    
    .form-actions {
        flex-direction: column;
        gap: 0.5rem;
    }
    
    .btn {
        width: 100%;
        justify-content: center;
        padding: 0.75rem 1.25rem;
        font-size: 0.875rem;
    }
    
    .edit-btn {
        padding: 0.5rem 1rem;
        font-size: 0.8125rem;
    }
    
    .settings-content {
        padding: 1.25rem 1rem 1.5rem;
    }
    
    .settings-item {
        flex-direction: column;
        align-items: flex-start;
        gap: 0.75rem;
        padding: 1rem 0;
    }
    
    .image-upload-actions {
        padding: 0.5rem;
        margin-top: 0.75rem;
    }
    
    .image-upload-buttons {
        flex-direction: column;
        gap: 0.5rem;
    }
    
    .btn-sm {
        width: 100%;
        padding: 0.625rem 1rem;
    }
    
    .completion-badge {
        font-size: 0.8125rem;
        padding: 0.25rem 0.75rem;
    }
    
    .bio-edit-form textarea {
        font-size: 0.875rem;
        padding: 0.75rem;
    }
    
    .info-input,
    .social-link-input {
        font-size: 0.875rem;
        padding: 0.625rem;
    }
}

@media (min-width: 769px) and (max-width: 1024px) {
    .dashboard-container {
        flex-direction: column;
        gap: 1.5rem;
        padding: 0 1rem;
    }
    
    .dashboard-sidebar {
        width: 100%;
        min-width: 100%;
        height: auto;
        position: relative;
        border-right: none;
        border-bottom: 1px solid hsl(var(--border));
    }
    
    .dashboard-content {
        max-width: 100%;
        padding: 0;
    }
    
    .dashboard-nav {
    display: flex; 
    flex-direction: column; 
        overflow: visible;
        overflow-x: hidden;
        padding: 1rem;
        gap: 0;
        width: 100%;
    }
    
    .nav-item {
        white-space: normal;
        word-wrap: break-word;
        margin-bottom: 0.5rem;
        width: 100%;
        max-width: 100%;
        box-sizing: border-box;
    }
    
    .nav-item[data-section="settings"] {
        margin-bottom: 1.5rem;
    }
    
    .nav-item-logout {
        margin-top: 0;
        border-top: 1px solid hsl(var(--border));
        padding-top: 1rem;
        margin-bottom: 0.5rem;
        width: 100%;
        max-width: 100%;
        box-sizing: border-box;
        white-space: normal;
        word-wrap: break-word;
    }
    
    .overview-cards {
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    }
    
    .stats-grid {
        grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
    }
}

@media (min-width: 1025px) and (max-width: 1280px) {
    .dashboard-container {
        max-width: 100%;
        padding: 0 1rem;
    }
    
    .dashboard-sidebar {
        top: 0.5rem;
        margin: 0.5rem 0;
        height: fit-content;
        max-height: calc(100vh - 80px);
        overflow: visible;
    }
    
    .dashboard-content {
        margin: 0;
        max-width: calc(100% - 280px - 30px);
        width: 100%;
        min-width: 0;
    }
    
    .dashboard-container {
        gap: 30px;
    }
    
    .dashboard-section {
        width: 100%;
        max-width: 100%;
    }
    
    .profile-content,
    .settings-content {
        width: 100%;
        max-width: 100%;
    }
    
    .profile-card {
        width: 100%;
        max-width: 100%;
    }
    
    .section-header {
        padding: 1.5rem 1.75rem 1.25rem;
        width: 100%;
        max-width: 100%;
    }
    
    .dashboard-overview {
        padding: 1.5rem 1.75rem 2rem;
    }
}

/* Profile Image Edit Button */
.edit-image-btn {
    position: absolute;
    bottom: 0;
    right: 0;
    width: 36px;
    height: 36px;
    border-radius: 50%;
    background: linear-gradient(135deg, hsl(60 96% 79%), hsl(186 80% 19%));
    border: 3px solid hsl(var(--card));
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all 0.3s;
    color: hsl(var(--primary-foreground));
    box-shadow: 0 2px 8px hsl(var(--primary) / 0.3);
}

.edit-image-btn:hover {
    transform: scale(1.1);
    box-shadow: 0 4px 12px hsl(var(--primary) / 0.4);
}

.profile-image-container {
    position: relative;
}

/* Image Upload Actions */
.image-upload-actions {
    margin-top: 1rem;
    text-align: center;
    padding: 0.75rem;
    border-radius: 0.75rem;

}

.image-upload-buttons {
    display: flex;
    gap: 0.5rem;
    justify-content: center;
    align-items: center;
}

.btn-sm {
    padding: 0.5rem 1rem;
    font-size: 0.875rem;
    border-radius: 0.5rem;
}

.image-upload-status {
    margin-top: 0.5rem;
    font-size: 0.875rem;
    color: hsl(var(--muted-foreground));
    padding: 0.5rem;
    border-radius: 0.5rem;
    text-align: center;
    font-weight: 500;
}

/* Profile Content Styles */
.profile-card {
    background: hsl(var(--card));
    border: 1px solid hsl(var(--border));
    border-radius: 1rem;
    padding: 1.75rem;
    margin-bottom: 1.5rem;
    margin-left: 0;
    margin-right: 0;
    width: 100%;
    max-width: 100%;
    box-sizing: border-box;
}

.card-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 1.5rem;
    padding-bottom: 1rem;
    border-bottom: 1px solid hsl(var(--border));
}

.card-header h3 {
    font-size: 1.25rem;
    font-weight: 700;
    color: hsl(var(--foreground));
    margin: 0;
}

.card-body {
    margin-top: 1.25rem;
    padding-top: 0;
}

/* Profile Completion */
.completion-card {
    background: linear-gradient(135deg, hsl(var(--primary) / 0.1), hsl(var(--primary) / 0.05));
    border-color: hsl(var(--primary) / 0.3);
}

.completion-badge {
    background: linear-gradient(135deg, hsl(60 96% 79%), hsl(186 80% 19%));
    color: hsl(var(--primary-foreground));
    padding: 0.375rem 0.875rem;
    border-radius: 9999px;
    font-size: 0.875rem;
    font-weight: 700;
}

.completion-bar {
    width: 100%;
    height: 8px;
    background: hsl(var(--secondary));
    border-radius: 9999px;
    overflow: hidden;
    margin-bottom: 0.75rem;
}

.completion-fill {
    height: 100%;
    background: linear-gradient(90deg, hsl(60 96% 79%), hsl(186 80% 19%));
    transition: width 0.5s ease;
    border-radius: 9999px;
}

.completion-text {
    font-size: 0.875rem;
    color: hsl(var(--muted-foreground));
    margin: 0;
}

/* Statistics Grid */
.stats-grid {
    display: grid; 
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 1.5rem;
    margin-bottom: 1.5rem;
}

.stat-card {
    background: hsl(var(--card));
    border: 1px solid hsl(var(--border));
    border-radius: 1rem;
    padding: 1.5rem;
    display: flex;
    align-items: center;
    gap: 1rem;
    transition: all 0.3s;
}

.stat-card:hover {
    border-color: hsl(var(--primary) / 0.5);
    transform: translateY(-2px);
    box-shadow: 0 4px 12px hsl(var(--primary) / 0.1);
}

.stat-icon {
    width: 48px;
    height: 48px;
    border-radius: 0.75rem;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.stat-card-primary .stat-icon {
    background: hsl(var(--primary) / 0.1);
    color: hsl(var(--primary));
}

.stat-card-info .stat-icon {
    background: hsl(var(--primary) / 0.1);
    color: hsl(var(--primary));
}

.stat-value {
    font-size: 1.75rem;
    font-weight: 700;
    color: hsl(var(--foreground));
    margin: 0 0 0.25rem;
}

.stat-label {
    font-size: 0.875rem;
    color: hsl(var(--muted-foreground));
    margin: 0;
}

/* Quick Actions */
.quick-actions-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 1rem;
}

.quick-action-btn {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    padding: 1rem;
    background: hsl(var(--secondary));
    border: 1px solid hsl(var(--border));
    border-radius: 0.75rem;
    color: hsl(var(--foreground));
    cursor: pointer;
    transition: all 0.3s;
    font-size: 0.9375rem;
    font-weight: 500;
}

.quick-action-btn:hover {
    background: hsl(var(--secondary) / 0.8);
    border-color: hsl(var(--primary) / 0.5);
    transform: translateY(-2px);
    box-shadow: 0 4px 12px hsl(var(--primary) / 0.15);
}

.quick-action-btn.nav-link {
    text-align: left;
    width: 100%;
}

.quick-action-btn svg {
    width: 20px;
    height: 20px;
    flex-shrink: 0;
}

/* Bio Section */
.bio-text {
    color: hsl(var(--muted-foreground));
    font-size: 0.9375rem;
    line-height: 1.6;
    margin: 0;
    min-height: 3rem;
}

.bio-edit-form {
    display: none;
}

.bio-edit-form textarea {
    width: 100%;
    padding: 0.875rem;
    background: hsl(var(--secondary));
    border: 1px solid hsl(var(--border));
    border-radius: 0.5rem;
    color: hsl(var(--foreground));
    font-size: 0.9375rem;
    font-family: inherit;
    resize: vertical;
    margin-bottom: 1rem;
}

.bio-edit-form textarea:focus {
    outline: none;
    border-color: hsl(var(--primary));
    box-shadow: 0 0 0 3px hsl(var(--primary) / 0.1);
}

/* Personal Information */
.info-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 2rem;
}

@media (max-width: 1024px) {
    .info-grid {
        grid-template-columns: repeat(2, 1fr);
        gap: 1.5rem;
    }
}

@media (max-width: 640px) {
    .info-grid {
        grid-template-columns: 1fr;
        gap: 1.5rem;
    }
}

.info-item {
    display: flex;
    flex-direction: column;
}

.info-item label {
    font-size: 0.75rem;
    font-weight: 600;
    color: hsl(var(--muted-foreground));
    text-transform: uppercase;
    letter-spacing: 0.05em;
    margin-bottom: 0.75rem;
}

.info-price-wrapper {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    width: 100%;
}

.info-price-wrapper .info-input {
    flex: 1;
    width: auto;
    display: block !important;
}

.info-value {
    font-size: 0.9375rem;
    color: hsl(var(--foreground));
    margin: 0;
    padding: 0.75rem 0;
    font-weight: 500;
    min-height: 1.5rem;
    display: flex;
    align-items: center;
}

.info-input {
    display: none;
    width: 100%;
    padding: 0.875rem 1rem;
    background: hsl(var(--secondary));
    border: 1px solid hsl(var(--border));
    border-radius: 0.5rem;
    color: hsl(var(--foreground));
    font-size: 0.9375rem;
    transition: all 0.2s ease;
}

.info-input:focus {
    outline: none;
    border-color: hsl(var(--primary));
    box-shadow: 0 0 0 3px hsl(var(--primary) / 0.1);
}

/* Social Media Links */
.social-links-container {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}

.social-link-item {
    display: flex;
    align-items: center;
    gap: 1rem;
    padding: 1rem;
    background: hsl(var(--secondary));
    border: 1px solid hsl(var(--border));
    border-radius: 0.75rem;
    transition: all 0.3s;
}

.social-link-item:hover {
    border-color: hsl(var(--primary) / 0.5);
}

.social-link-item svg {
    width: 24px;
    height: 24px;
    flex-shrink: 0;
    color: hsl(var(--muted-foreground));
}

.social-link-value {
    flex: 1;
    font-size: 0.9375rem;
    color: hsl(var(--muted-foreground));
}

.social-link-input {
    display: none;
    flex: 1;
    padding: 0.75rem;
    background: hsl(var(--card));
    border: 1px solid hsl(var(--border));
    border-radius: 0.5rem;
    color: hsl(var(--foreground));
    font-size: 0.9375rem;
}

.social-link-input:focus {
    outline: none;
    border-color: hsl(var(--primary));
    box-shadow: 0 0 0 3px hsl(var(--primary) / 0.1);
}

/* Activity Timeline */
.activity-timeline {
    display: flex;
    flex-direction: column;
    gap: 0;
    padding-top: 0;
}

.activity-item {
    display: flex;
    gap: 1.25rem;
    position: relative;
    padding-left: 3.5rem;
    padding-bottom: 1.5rem;
    padding-top: 0;
    align-items: flex-start;
    transition: transform 0.2s ease;
}

.activity-item:hover {
    transform: translateX(4px);
}

.activity-item:hover .activity-icon {
    transform: scale(1.05);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
}

.activity-item:last-child {
    padding-bottom: 0;
}

.activity-item::before {
    content: '';
    position: absolute;
    left: 24px;
    top: 48px;
    bottom: -1.5rem;
    width: 2px;
    background: hsl(var(--border));
    opacity: 0.5;
    z-index: 0;
}

.activity-item:last-child::before {
    display: none;
}

.activity-icon {
    position: absolute;
    left: 0;
    top: 0;
    width: 48px;
    height: 48px;
    border-radius: 0.75rem;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    border: 3px solid hsl(var(--card));
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
    transition: transform 0.2s ease, box-shadow 0.2s ease;
}

.activity-icon svg {
    width: 24px;
    height: 24px;
}

.activity-icon-success {
    background: #10b981;
    color: white;
}

.activity-icon-info {
    background: #3b82f6;
    color: white;
}

.activity-icon-warning {
    background: #f59e0b;
    color: white;
}

.activity-icon-error {
    background: #ef4444;
    color: white;
}

.notification-unread {
    background: hsl(var(--primary) / 0.05);
    border-left: 3px solid hsl(var(--primary));
}

.notification-unread .activity-text {
    font-weight: 600;
}

/* VIP/Fast Track Priority Notifications */
.notification-priority {
    background: linear-gradient(135deg, rgba(255, 215, 0, 0.1), rgba(255, 140, 0, 0.1)) !important;
    border-left: 4px solid #ffd700 !important;
    position: relative;
    animation: priorityPulse 2s ease-in-out 3;
}

.notification-priority::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(135deg, rgba(255, 215, 0, 0.05), transparent);
    pointer-events: none;
}

.notification-priority .activity-icon.priority-icon {
    background: linear-gradient(135deg, #ffd700, #ff8c00);
    box-shadow: 0 2px 12px rgba(255, 215, 0, 0.4);
}

@keyframes priorityPulse {
    0%, 100% {
        box-shadow: 0 0 0 0 rgba(255, 215, 0, 0);
    }
    50% {
        box-shadow: 0 0 15px 3px rgba(255, 215, 0, 0.3);
    }
}

.vip-badge {
    animation: badgeShine 3s ease-in-out infinite;
}

@keyframes badgeShine {
    0%, 100% {
        filter: brightness(1);
    }
    50% {
        filter: brightness(1.2);
    }
}

.notification-mark-read:hover {
    opacity: 1 !important;
}

.activity-content {
    flex: 1;
    min-width: 0;
    padding-top: 0;
    position: relative;
    z-index: 1;
}

.activity-text {
    font-size: 1rem;
    color: hsl(var(--foreground));
    margin: 0 0 0.5rem;
    line-height: 1.5;
}

.activity-text strong {
    font-weight: 700;
    font-size: 1.0625rem;
    display: block;
    margin-bottom: 0.375rem;
}

.activity-description {
    font-size: 0.875rem;
    color: hsl(var(--muted-foreground));
    margin: 0 0 0.5rem;
    line-height: 1.5;
}

.activity-time {
    font-size: 0.8125rem;
    color: hsl(var(--muted-foreground));
    display: block;
    margin-top: 0.25rem;
}

/* Form Actions */
.form-actions {
    display: flex;
    gap: 0.75rem;
    margin-top: 1.5rem;
    padding-top: 1.5rem;
    border-top: 1px solid hsl(var(--border));
}

.btn {
    padding: 0.75rem 1.5rem;
    border-radius: 0.5rem;
    font-size: 0.9375rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s;
    border: none;
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
}

.btn-primary {
    background: linear-gradient(135deg, hsl(60 96% 79%), hsl(186 80% 19%));
    color: hsl(var(--primary-foreground));
}

.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px hsl(var(--primary) / 0.3);
}

.btn-outline {
    background: hsl(var(--secondary));
    border: 1px solid hsl(var(--border));
    color: hsl(var(--foreground));
}

.btn-outline:hover {
    background: hsl(var(--secondary) / 0.8);
    border-color: hsl(var(--border));
}

.btn-danger {
    color: hsl(var(--destructive));
    border-color: hsl(var(--destructive));
}

.btn-danger:hover {
    background: hsl(var(--destructive) / 0.1);
}

.icon-btn {
    background: transparent;
    border: none;
    color: hsl(var(--muted-foreground));
    cursor: pointer;
    padding: 0.5rem;
    border-radius: 0.5rem;
    transition: all 0.2s;
    display: inline-flex;
    align-items: center;
    justify-content: center;
}

.icon-btn:hover {
    background: hsl(var(--secondary));
    color: hsl(var(--foreground));
}

.edit-btn {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    padding: 0.625rem 1.25rem;
    background: hsl(var(--secondary));
    border: 1px solid hsl(var(--border));
    border-radius: 0.5rem;
    color: hsl(var(--foreground));
    font-size: 0.875rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s;
}

.edit-btn:hover {
    background: hsl(var(--secondary) / 0.8);
    border-color: hsl(var(--primary) / 0.5);
}

/* Settings Section */
.settings-item {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 1.25rem 0;
    border-bottom: 1px solid hsl(var(--border));
}

.settings-item:last-child {
    border-bottom: none;
}

.settings-label label {
    font-size: 0.9375rem;
    font-weight: 600;
    color: hsl(var(--foreground));
    display: block;
    margin-bottom: 0.25rem;
}

.settings-description {
    font-size: 0.8125rem;
    color: hsl(var(--muted-foreground));
    margin: 0;
}

/* Toggle Switch */
.toggle-switch {
    position: relative;
    display: inline-block;
    width: 48px;
    height: 26px;
}

.toggle-switch input {
    opacity: 0;
    width: 0;
    height: 0;
}

.toggle-slider {
    position: absolute;
    cursor: pointer;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: hsl(var(--secondary));
    transition: 0.3s;
    border-radius: 26px;
}

.toggle-slider:before {
    position: absolute;
    content: "";
    height: 20px;
    width: 20px;
    left: 3px;
    bottom: 3px;
    background-color: hsl(var(--foreground));
    transition: 0.3s;
    border-radius: 50%;
}

.toggle-switch input:checked + .toggle-slider {
    background: linear-gradient(135deg, hsl(60 96% 79%), hsl(186 80% 19%));
}

.toggle-switch input:checked + .toggle-slider:before {
    transform: translateX(22px);
}

.danger-zone {
    border-color: hsl(var(--destructive) / 0.3);
}

.danger-zone .card-header h3 {
    color: hsl(var(--destructive));
}

.danger-actions {
    display: flex;
    gap: 1rem;
}

/* Empty States */
.empty-state {
    text-align: center;
    padding: 4rem 2rem;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
}

.empty-state-icon {
    width: 80px;
    height: 80px;
    border-radius: 50%;
    background: hsl(var(--secondary));
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 1.5rem auto;
    color: hsl(var(--muted-foreground));
    opacity: 0.6;
}

.empty-state-icon svg {
    width: 40px;
    height: 40px;
}

.empty-state-title {
    font-size: 1.25rem;
    font-weight: 700;
    color: hsl(var(--foreground));
    margin: 0 0 0.75rem;
}

.empty-state-description {
    font-size: 0.9375rem;
    color: hsl(var(--muted-foreground));
    margin: 0;
    max-width: 400px;
    line-height: 1.6;
}

/* Subscription Plans Section */
.section-description {
    font-size: 0.9375rem;
    color: hsl(var(--muted-foreground));
    margin: 0.5rem 0 0 0;
}

.subscription-plans-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 2rem;
    margin-top: 2rem;
}

.subscription-plan-card {
    background: hsl(var(--card));
    border: 2px solid hsl(var(--border));
    border-radius: 1rem;
    padding: 2rem;
    position: relative;
    transition: all 0.3s ease;
    display: flex;
    flex-direction: column;
}

.subscription-plan-card:hover {
    border-color: hsl(var(--primary) / 0.5);
    transform: translateY(-4px);
    box-shadow: 0 8px 24px hsl(var(--primary) / 0.15);
}

.subscription-plan-card.popular-plan {
    border-color: hsl(var(--primary));
    box-shadow: 0 4px 16px hsl(var(--primary) / 0.2);
}

.subscription-plan-card.current-plan {
    border-color: hsl(var(--primary));
    background: linear-gradient(135deg, hsl(var(--primary) / 0.05), hsl(var(--card)));
}

.plan-badge-popular {
    position: absolute;
    top: -12px;
    right: 1.5rem;
    background: linear-gradient(135deg, hsl(60 96% 79%), hsl(186 80% 19%));
    color: hsl(var(--primary-foreground));
    padding: 0.375rem 1rem;
    border-radius: 9999px;
    font-size: 0.75rem;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    box-shadow: 0 2px 8px hsl(var(--primary) / 0.3);
}

.plan-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 1.5rem;
}

.plan-name {
    font-size: 1.5rem;
    font-weight: 700;
    color: hsl(var(--foreground));
    margin: 0;
}

.current-plan-badge {
    background: hsl(var(--primary));
    color: hsl(var(--primary-foreground));
    padding: 0.25rem 0.75rem;
    border-radius: 9999px;
    font-size: 0.75rem;
    font-weight: 600;
    white-space: nowrap;
}

.plan-price {
    margin-bottom: 2rem;
    padding-bottom: 1.5rem;
    border-bottom: 1px solid hsl(var(--border));
}

.price-currency {
    font-size: 1.5rem;
    font-weight: 600;
    color: hsl(var(--muted-foreground));
    vertical-align: top;
}

.price-amount {
    font-size: 3rem;
    font-weight: 800;
    color: hsl(var(--foreground));
    line-height: 1;
}

.price-period {
    font-size: 1rem;
    color: hsl(var(--muted-foreground));
    font-weight: 500;
}

.plan-features {
    flex: 1;
    margin-bottom: 2rem;
}

.features-list {
    list-style: none;
    padding: 0;
    margin: 0;
}

.features-list li {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    padding: 0.75rem 0;
    color: hsl(var(--foreground));
    font-size: 0.9375rem;
}

.features-list li svg {
    width: 16px;
    height: 16px;
    color: hsl(var(--primary));
    flex-shrink: 0;
}

.plan-action {
    margin-top: auto;
}

.upgrade-plan-btn {
    width: 100%;
    padding: 0.875rem 1.5rem;
    font-weight: 600;
}

.upgrade-plan-btn:disabled {
    opacity: 0.6;
    cursor: not-allowed;
}

@media (max-width: 768px) {
    .subscription-plans-grid {
        grid-template-columns: 1fr;
        gap: 1.5rem;
    }
}

/* Free Plan Notification Banner */
.free-plan-notification-banner {
    background: linear-gradient(135deg, hsl(var(--primary) / 0.1), hsl(var(--primary) / 0.05));
    border: 2px solid hsl(var(--primary) / 0.3);
    border-radius: 1rem;
    padding: 0.5rem;
    margin-bottom: 2rem;
    animation: slideDown 0.5s ease-out;
}

@keyframes slideDown {
    from {
        opacity: 0;
        transform: translateY(-20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.notification-content {
    display: flex;
    align-items: center;
    gap: 1.5rem;
    flex-wrap: wrap;
}

.notification-icon {
    width: 48px;
    height: 48px;
    background: hsl(var(--primary));
    color: hsl(var(--primary-foreground));
    border-radius: 0.75rem;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.notification-icon svg {
    width: 24px;
    height: 24px;
}

.notification-text {
    flex: 1;
    min-width: 200px;
}

.notification-text h3 {
    margin: 0 0 0.5rem 0;
    font-size: 1.125rem;
    font-weight: 700;
    color: hsl(var(--foreground));
}

.notification-text p {
    margin: 0;
    font-size: 0.9375rem;
    color: hsl(var(--muted-foreground));
    line-height: 1.5;
}

.notification-actions {
    display: flex;
    gap: 0.75rem;
    flex-shrink: 0;
}

.dismiss-notification {
    padding: 0.625rem 1rem;
    font-size: 0.875rem;
}

/* Sidebar Free Plan Reminder */
.sidebar-upgrade-section.free-plan-reminder {
    background: linear-gradient(135deg, hsl(var(--primary) / 0.1), hsl(var(--primary) / 0.05));
    border-top: 2px solid hsl(var(--primary) / 0.3);
    border-bottom: 2px solid hsl(var(--primary) / 0.3);
}

.free-plan-alert {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    background: hsl(var(--primary));
    color: hsl(var(--primary-foreground));
    padding: 0.5rem 0.75rem;
    border-radius: 0.5rem;
    margin-bottom: 0.75rem;
    font-size: 0.75rem;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.free-plan-alert svg {
    width: 18px;
    height: 18px;
}

.upgrade-plan-message {
    margin: 0.5rem 0 0.75rem 0;
    font-size: 0.8125rem;
    color: hsl(var(--muted-foreground));
    text-align: center;
    font-style: italic;
}

/* Notification Activity Item */
.activity-item-upgrade {
    border-left: 3px solid hsl(var(--primary));
    background: linear-gradient(90deg, hsl(var(--primary) / 0.05), transparent);
}

.activity-icon-upgrade {
    background: hsl(var(--primary));
    color: hsl(var(--primary-foreground));
}

.activity-actions {
    margin-top: 0.75rem;
}

.activity-actions .btn {
    padding: 0.5rem 1rem;
    font-size: 0.875rem;
}

@media (max-width: 768px) {
    .notification-content {
        flex-direction: column;
        align-items: flex-start;
    }
    
    .notification-actions {
        width: 100%;
        flex-direction: column;
    }
    
    .notification-actions .btn {
        width: 100%;
    }
}

/* Reviews Section */
.reviews-summary {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 1.5rem;
    margin-bottom: 2rem;
}

.summary-card {
    background: hsl(var(--card));
    border: 1px solid hsl(var(--border));
    border-radius: 1rem;
    padding: 1.5rem;
    text-align: center;
    transition: all 0.3s ease;
}

.summary-card:hover {
    border-color: hsl(var(--primary) / 0.5);
    transform: translateY(-2px);
    box-shadow: 0 4px 12px hsl(var(--primary) / 0.1);
}

.summary-value {
    font-size: 2rem;
    font-weight: 700;
    color: hsl(var(--foreground));
    margin-bottom: 0.5rem;
}

.summary-label {
    font-size: 0.875rem;
    color: hsl(var(--muted-foreground));
}

.reviews-list {
    display: flex;
    flex-direction: column;
    gap: 1.5rem;
}

.review-card {
    background: hsl(var(--card));
    border: 1px solid hsl(var(--border));
    border-radius: 1rem;
    padding: 1.5rem;
    transition: all 0.3s ease;
}

.review-card:hover {
    border-color: hsl(var(--primary) / 0.5);
    box-shadow: 0 4px 12px hsl(var(--primary) / 0.1);
}

.review-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 1rem;
    gap: 1rem;
}

.review-customer {
    display: flex;
    gap: 1rem;
    align-items: flex-start;
    flex: 1;
}

.customer-avatar {
    width: 48px;
    height: 48px;
    border-radius: 50%;
    background: linear-gradient(135deg, hsl(60 96% 79%), hsl(186 80% 19%));
    color: hsl(var(--primary-foreground));
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 700;
    font-size: 1.125rem;
    flex-shrink: 0;
}

.customer-info {
    flex: 1;
}

.customer-name {
    margin: 0 0 0.25rem 0;
    font-size: 1rem;
    font-weight: 600;
    color: hsl(var(--foreground));
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.verified-badge {
    display: inline-flex;
    align-items: center;
    color: hsl(var(--primary));
    width: 18px;
    height: 18px;
}

.verified-badge svg {
    width: 18px;
    height: 18px;
}

.review-service {
    margin: 0;
    font-size: 0.8125rem;
    color: hsl(var(--muted-foreground));
}

.review-rating {
    display: flex;
    gap: 0.25rem;
    align-items: center;
    flex-shrink: 0;
}

.star {
    width: 20px;
    height: 20px;
    color: hsl(var(--primary));
}

.star-empty {
    color: hsl(var(--muted-foreground) / 0.3);
}

.review-content {
    margin-top: 1rem;
}

.review-text {
    margin: 0 0 1rem 0;
    font-size: 0.9375rem;
    line-height: 1.6;
    color: hsl(var(--foreground));
}

.review-footer {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding-top: 1rem;
    border-top: 1px solid hsl(var(--border));
}

.review-date {
    font-size: 0.8125rem;
    color: hsl(var(--muted-foreground));
}

.filter-select {
    padding: 0.5rem 1rem;
    border: 1px solid hsl(var(--border));
    border-radius: 0.5rem;
    background: hsl(var(--background));
    color: hsl(var(--foreground));
    font-size: 0.875rem;
    cursor: pointer;
}

.filter-select:focus {
    outline: none;
    border-color: hsl(var(--primary));
}

.header-actions {
    display: flex;
    gap: 1rem;
    align-items: center;
}

@media (max-width: 768px) {
    .reviews-summary {
        grid-template-columns: 1fr;
    }
    
    .review-header {
        flex-direction: column;
    }
    
    .review-rating {
        align-self: flex-start;
    }
    
    .header-actions {
        flex-direction: column;
        width: 100%;
    }
    
    .header-actions .search-input,
    .header-actions .filter-select {
        width: 100%;
    }
}

/* Messaging Container */
.messaging-container {
    display: grid;
    grid-template-columns: 350px 1fr;
    gap: 1.5rem;
    height: calc(100vh - 300px);
    min-height: 600px;
    background: hsl(var(--card));
    border: 1px solid hsl(var(--border));
    border-radius: 1rem;
    overflow: hidden;
    box-shadow: 0 2px 8px hsl(var(--background) / 0.1);
}

.conversations-panel {
    display: flex;
    flex-direction: column;
    background: hsl(var(--card));
    border-right: 1px solid hsl(var(--border));
    overflow: hidden;
}

.conversations-header {
    padding: 1.5rem;
    border-bottom: 1px solid hsl(var(--border));
    background: hsl(var(--card));
}

.conversations-header h2 {
    margin: 0 0 1rem;
    font-size: 1.25rem;
    font-weight: 700;
    color: hsl(var(--foreground));
    letter-spacing: -0.02em;
}

.conversations-header .search-input {
    width: 100%;
    padding: 0.625rem 1rem;
    border: 1px solid hsl(var(--border));
    border-radius: 0.75rem;
    background: hsl(var(--background));
    color: hsl(var(--foreground));
    font-size: 0.875rem;
    transition: all 0.3s ease;
}

.conversations-header .search-input:focus {
    outline: none;
    border-color: hsl(var(--primary));
    box-shadow: 0 0 0 3px hsl(var(--primary) / 0.1);
}

.conversations-list {
    flex: 1;
    overflow-y: auto;
    display: flex;
    flex-direction: column;
    background: hsl(var(--card));
    padding: 0.5rem 0;
}

.conversations-list::-webkit-scrollbar {
    width: 6px;
}

.conversations-list::-webkit-scrollbar-track {
    background: hsl(var(--background));
}

.conversations-list::-webkit-scrollbar-thumb {
    background: hsl(var(--border));
    border-radius: 3px;
}

.conversations-list::-webkit-scrollbar-thumb:hover {
    background: hsl(var(--muted-foreground) / 0.3);
}

.conversation-item {
    display: flex;
    align-items: flex-start;
    gap: 1rem;
    padding: 1rem 1.5rem;
    cursor: pointer;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    border-left: 3px solid transparent;
    position: relative;
}

.conversation-item:hover {
    background: hsl(var(--secondary) / 0.5);
}

.conversation-item.active {
    background: linear-gradient(90deg, hsl(var(--primary) / 0.1), transparent);
    border-left-color: hsl(var(--primary));
}

.conversation-item.active::before {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    bottom: 0;
    width: 3px;
    background: linear-gradient(180deg, hsl(60 96% 79%), hsl(186 80% 19%));
}

.conversation-avatar {
    width: 48px;
    height: 48px;
    border-radius: 50%;
    background: linear-gradient(135deg, hsl(60 96% 79%), hsl(186 80% 19%));
    color: hsl(var(--primary-foreground));
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 700;
    font-size: 1.125rem;
    flex-shrink: 0;
    overflow: hidden;
    position: relative;
    box-shadow: 0 2px 8px hsl(var(--primary) / 0.2);
}

.conversation-avatar-image {
    background: transparent;
    padding: 0;
}

.conversation-avatar-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    border-radius: 50%;
}

.conversation-content,
.conversation-info {
    flex: 1;
    min-width: 0;
    display: flex;
    flex-direction: column;
    gap: 0.25rem;
}

.conversation-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 0.25rem;
}

.conversation-name {
    margin: 0;
    font-size: 0.9375rem;
    font-weight: 600;
    color: hsl(var(--foreground));
    line-height: 1.3;
}

.conversation-time {
    font-size: 0.75rem;
    color: hsl(var(--muted-foreground));
    white-space: nowrap;
    font-weight: 500;
}

.conversation-preview {
    margin: 0;
    font-size: 0.875rem;
    color: hsl(var(--muted-foreground));
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    line-height: 1.4;
}

.conversation-meta {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 0.5rem;
    margin-top: 0.25rem;
}

.service-badge {
    font-size: 0.75rem;
    padding: 0.25rem 0.5rem;
    background: hsl(var(--secondary));
    color: hsl(var(--muted-foreground));
    border-radius: 0.375rem;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    max-width: 150px;
}

.unread-badge {
    background: hsl(var(--primary));
    color: hsl(var(--primary-foreground));
    font-size: 0.75rem;
    font-weight: 700;
    padding: 0.125rem 0.5rem;
    border-radius: 9999px;
    margin-left: auto;
}

.chat-view,
.chat-panel {
    background: hsl(var(--card));
    display: flex;
    flex-direction: column;
    overflow: hidden;
    height: 100%;
}

.chat-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    position: relative;
    justify-content: space-between;
    align-items: center;
    padding: 1.25rem 1.5rem;
    border-bottom: 1px solid hsl(var(--border));
    background: hsl(var(--card));
    flex-shrink: 0;
    box-shadow: 0 2px 4px hsl(var(--background) / 0.05);
}

.chat-partner-info {
    display: flex;
    align-items: center;
    gap: 1rem;
}

.chat-header-info {
    display: flex;
    align-items: center;
    gap: 1rem;
}

.chat-avatar-large,
.chat-partner-avatar {
    width: 48px;
    height: 48px;
    border-radius: 50%;
    background: linear-gradient(135deg, hsl(60 96% 79%), hsl(186 80% 19%));
    color: hsl(var(--primary-foreground));
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 700;
    font-size: 1.25rem;
    flex-shrink: 0;
    box-shadow: 0 2px 8px hsl(var(--primary) / 0.2);
    overflow: hidden;
    position: relative;
}

.chat-partner-avatar-image {
    background: transparent;
    padding: 0;
}

.chat-partner-avatar-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    border-radius: 50%;
}

.chat-header-info h3,
.chat-partner-name {
    margin: 0;
    font-size: 1rem;
    font-weight: 600;
    color: hsl(var(--foreground));
    line-height: 1.3;
}

.chat-status {
    margin: 0.25rem 0 0 0;
    font-size: 0.8125rem;
    color: hsl(var(--muted-foreground));
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.chat-status.status-active {
    color: hsl(142 76% 36%);
}

.chat-status.status-active::before {
    content: '';
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: hsl(142 76% 36%);
    display: inline-block;
    animation: pulse 2s infinite;
}

@keyframes pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.5; }
}

.chat-header-actions {
    display: flex;
    gap: 0.5rem;
}

.icon-btn {
    width: 36px;
    height: 36px;
    border-radius: 0.5rem;
    border: 1px solid hsl(var(--border));
    background: transparent;
    color: hsl(var(--foreground));
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all 0.3s ease;
}

.icon-btn:hover {
    background: hsl(var(--secondary));
    border-color: hsl(var(--primary) / 0.5);
}

.chat-messages {
    flex: 1;
    overflow-y: auto;
    padding: 1.5rem;
    display: flex;
    flex-direction: column;
    gap: 0.75rem;
    background: hsl(var(--background) / 0.5);
    background-image: 
        radial-gradient(circle at 1px 1px, hsl(var(--border) / 0.1) 1px, transparent 0);
    background-size: 24px 24px;
    min-height: 0;
    scroll-behavior: smooth;
    -webkit-overflow-scrolling: touch;
    will-change: scroll-position;
}

.chat-messages::-webkit-scrollbar {
    width: 8px;
}

.chat-messages::-webkit-scrollbar-track {
    background: transparent;
}

.chat-messages::-webkit-scrollbar-thumb {
    background: hsl(var(--border));
    border-radius: 4px;
}

.chat-messages::-webkit-scrollbar-thumb:hover {
    background: hsl(var(--muted-foreground) / 0.4);
}

.chat-messages::-webkit-scrollbar {
    width: 8px;
}

.chat-messages::-webkit-scrollbar-track {
    background: transparent;
}

.chat-messages::-webkit-scrollbar-thumb {
    background: hsl(var(--border));
    border-radius: 4px;
}

.chat-messages::-webkit-scrollbar-thumb:hover {
    background: hsl(var(--muted-foreground) / 0.3);
}

/* Screen reader only class for accessibility */
.sr-only {
    position: absolute;
    width: 1px;
    height: 1px;
    padding: 0;
    margin: -1px;
    overflow: hidden;
    clip: rect(0, 0, 0, 0);
    white-space: nowrap;
    border-width: 0;
}

/* Focus styles for accessibility */
.chat-messages:focus {
    outline: 2px solid hsl(var(--primary));
    outline-offset: -2px;
}

.conversation-item:focus,
.messageInput:focus,
#sendBtn:focus,
#attachmentBtn:focus {
    outline: 2px solid hsl(var(--primary));
    outline-offset: 2px;
}


.message-sent {
    flex-direction: row-reverse;
    align-self: flex-end;
}

.message-received {
    align-self: flex-start;
}

.message-avatar {
    width: 32px;
    height: 32px;
    border-radius: 50%;
    background: linear-gradient(135deg, hsl(60 96% 79%), hsl(186 80% 19%));
    color: hsl(var(--primary-foreground));
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 600;
    font-size: 0.875rem;
    flex-shrink: 0;
}

.message-content {
    max-width: 100%;
}

.message-bubble {
    display: flex;
    flex-direction: column;
    max-width: 70%;
    min-width: 120px;
    margin-bottom: 0.5rem;
    padding: 0.875rem 1.125rem;
    border-radius: 1.125rem;
    position: relative;
    word-wrap: break-word;
    box-shadow: 0 2px 8px hsl(var(--background) / 0.15);
    transition: transform 0.2s ease, box-shadow 0.2s ease;
    will-change: transform, opacity;
    animation: slideInMessage 0.3s ease-out;
    backface-visibility: hidden;
    transform: translateZ(0);
}

.message-bubble:hover {
    transform: translateY(-1px) translateZ(0);
    box-shadow: 0 4px 12px hsl(var(--background) / 0.2);
}

.message-bubble[style*="animation: none"] {
    animation: none !important;
}

@keyframes slideInMessage {
    from {
        opacity: 0;
        transform: translateY(8px) scale(0.98) translateZ(0);
    }
    to {
        opacity: 1;
        transform: translateY(0) scale(1) translateZ(0);
    }
}

/* Logged-in user's messages = RIGHT side */
.message-bubble.own-message {
    align-self: flex-end;
    margin-left: auto;
    margin-right: 0;
    background: linear-gradient(135deg, hsl(60 96% 79%), hsl(186 80% 19%));
    color: hsl(var(--primary-foreground));
    border-bottom-right-radius: 0.25rem;
    box-shadow: 0 2px 8px hsl(var(--primary) / 0.25);
}

/* Other user's messages = LEFT side */
.message-bubble.other-message {
    align-self: flex-start;
    background: hsl(var(--card));
    border: 1px solid hsl(var(--border) / 0.5);
    border-bottom-left-radius: 0.25rem;
    color: hsl(var(--foreground));
    margin-right: auto;
    margin-left: 0;
}

.message-bubble p {
    margin: 0;
    font-size: 0.9375rem;
    line-height: 1.5;
    color: inherit;
    white-space: pre-wrap;
    word-break: break-word;
}

.message-time {
    font-size: 0.75rem;
    opacity: 0.7;
    margin-top: 0.375rem;
    display: flex;
    align-items: center;
    gap: 0.25rem;
}

/* Reply Preview Bar */
.reply-preview-bar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0.75rem 1rem;
    background: hsl(var(--muted) / 0.5);
    border-top: 1px solid hsl(var(--border));
    border-bottom: 1px solid hsl(var(--border));
    gap: 0.75rem;
}

.reply-preview-content {
    flex: 1;
    min-width: 0;
    display: flex;
    flex-direction: column;
    gap: 0.25rem;
}

.reply-preview-info {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    font-size: 0.75rem;
    color: hsl(var(--muted-foreground));
}

.reply-preview-label {
    font-weight: 500;
}

.reply-preview-name {
    font-weight: 600;
    color: hsl(var(--primary));
}

.reply-preview-text {
    font-size: 0.8125rem;
    color: hsl(var(--foreground));
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    max-width: 100%;
}

.reply-preview-close {
    flex-shrink: 0;
    background: transparent;
    border: none;
    padding: 0.25rem;
    cursor: pointer;
    color: hsl(var(--muted-foreground));
    border-radius: 0.25rem;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: background-color 0.2s, color 0.2s;
}

.reply-preview-close:hover {
    background: hsl(var(--muted));
    color: hsl(var(--foreground));
}

.reply-preview-close:focus {
    outline: 2px solid hsl(var(--primary));
    outline-offset: 2px;
}

/* Message Reply Container */
.message-reply-container {
    padding: 0.5rem 0.75rem;
    margin-bottom: 0.5rem;
    background: hsl(var(--muted) / 0.3);
    border-left: 3px solid hsl(var(--primary));
    border-radius: 0.375rem;
    cursor: pointer;
    transition: background-color 0.2s;
}

.message-reply-container:hover {
    background: hsl(var(--muted) / 0.5);
}

.message-reply-container:focus {
    outline: 2px solid hsl(var(--primary));
    outline-offset: 2px;
}

.message-reply-sender {
    font-size: 0.75rem;
    font-weight: 600;
    color: hsl(var(--primary));
    margin-bottom: 0.25rem;
}

.message-reply-text {
    font-size: 0.8125rem;
    color: hsl(var(--foreground) / 0.8);
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    line-height: 1.4;
}

.message-reply-unavailable {
    font-size: 0.75rem;
    color: hsl(var(--muted-foreground));
    font-style: italic;
}

/* Message Bubble Reply Button - Hidden, using context menu instead */
.message-reply-btn {
    display: none !important;
}

/* Message Delete Button - Hidden, using context menu instead */
.message-delete-btn {
    display: none !important;
}

/* Message highlight for scroll-to */
.message-bubble.highlight-message {
    animation: highlightMessage 2s ease-out;
}

@keyframes highlightMessage {
    0% {
        background-color: hsl(var(--primary) / 0.3);
        box-shadow: 0 0 0 0 hsl(var(--primary) / 0.5);
    }
    50% {
        background-color: hsl(var(--primary) / 0.2);
        box-shadow: 0 0 0 4px hsl(var(--primary) / 0.3);
    }
    100% {
        background-color: transparent;
        box-shadow: 0 0 0 0 transparent;
    }
}

/* Message Context Menu (Right-click menu) */
.message-context-menu {
    position: fixed;
    z-index: 9999;
    background: hsl(var(--card));
    border: 1px solid hsl(var(--border));
    border-radius: 0.5rem;
    box-shadow: 0 10px 40px hsl(var(--foreground) / 0.15), 0 4px 12px hsl(var(--foreground) / 0.1);
    padding: 0.375rem;
    min-width: 140px;
    animation: contextMenuFadeIn 0.15s ease-out;
}

@keyframes contextMenuFadeIn {
    from {
        opacity: 0;
        transform: scale(0.95);
    }
    to {
        opacity: 1;
        transform: scale(1);
    }
}

.message-context-menu-item {
    display: flex;
    align-items: center;
    gap: 0.625rem;
    padding: 0.5rem 0.75rem;
    border: none;
    background: transparent;
    width: 100%;
    text-align: left;
    cursor: pointer;
    border-radius: 0.375rem;
    font-size: 0.875rem;
    color: hsl(var(--foreground));
    transition: background-color 0.15s ease;
}

.message-context-menu-item:hover {
    background: hsl(var(--muted));
}

.message-context-menu-item svg {
    width: 16px;
    height: 16px;
    flex-shrink: 0;
}

.message-context-menu-item.reply-item svg {
    color: hsl(var(--primary));
}

.message-context-menu-item.delete-item {
    color: hsl(var(--destructive));
}

.message-context-menu-item.delete-item:hover {
    background: hsl(var(--destructive) / 0.1);
}

.message-context-menu-item.delete-item svg {
    color: hsl(var(--destructive));
}

/* Deleted Message State */
.message-bubble.message-deleted {
    opacity: 0.7;
}

.message-deleted-text {
    font-style: italic;
    color: hsl(var(--muted-foreground));
    font-size: 0.875rem;
}

/* Conversation Delete Button */
.conversation-delete-btn {
    position: absolute;
    top: 0.5rem;
    right: 0.5rem;
    background: transparent;
    border: none;
    padding: 0.25rem;
    cursor: pointer;
    opacity: 0;
    transition: opacity 0.2s, background-color 0.2s;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 0.25rem;
    z-index: 10;
}

.conversation-item:hover .conversation-delete-btn {
    opacity: 1;
}

.conversation-delete-btn:hover {
    background: hsl(var(--destructive) / 0.1);
}

.conversation-delete-btn svg {
    width: 18px;
    height: 18px;
    color: hsl(var(--muted-foreground));
    pointer-events: none;
}

.conversation-delete-btn:hover svg {
    color: hsl(var(--destructive));
}

.chat-input-container,
.chat-composer {
    padding: 1.25rem 1.5rem;
    border-top: 1px solid hsl(var(--border));
    background: hsl(var(--card));
    flex-shrink: 0;
    box-shadow: 0 -2px 4px hsl(var(--background) / 0.05);
}

.chat-input-wrapper,
.composer-input-wrapper {
    display: flex;
    gap: 0.75rem;
    align-items: flex-end;
    background: hsl(var(--background));
    border: 1px solid hsl(var(--border));
    border-radius: 1.25rem;
    padding: 0.5rem;
    transition: all 0.3s ease;
}

.composer-input-wrapper:focus-within {
    border-color: hsl(var(--primary));
    box-shadow: 0 0 0 3px hsl(var(--primary) / 0.1);
}

.chat-input,
.composer-input {
    flex: 1;
    padding: 0.75rem 1rem;
    border: none;
    border-radius: 0.75rem;
    background: transparent;
    color: hsl(var(--foreground));
    font-size: 0.9375rem;
    resize: none;
    max-height: 120px;
    min-height: 44px;
    font-family: inherit;
}

.chat-input:focus,
.composer-input:focus {
    outline: none;
}

.chat-send-btn,
.send-btn {
    width: 44px;
    height: 44px;
    border-radius: 0.75rem;
    background: linear-gradient(135deg, hsl(60 96% 79%), hsl(186 80% 19%));
    color: hsl(var(--primary-foreground));
    border: none;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all 0.3s ease;
    flex-shrink: 0;
}

.chat-send-btn:hover,
.send-btn:hover {
    transform: scale(1.05);
    box-shadow: 0 4px 12px hsl(var(--primary) / 0.3);
}

.chat-send-btn:disabled,
.send-btn:disabled {
    opacity: 0.5;
    cursor: not-allowed;
    transform: none;
}

.attachment-btn {
    width: 44px;
    height: 44px;
    border-radius: 0.75rem;
    background: transparent;
    color: hsl(var(--muted-foreground));
    border: none;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all 0.3s ease;
    flex-shrink: 0;
}

.attachment-btn:hover {
    background: hsl(var(--secondary));
    color: hsl(var(--foreground));
}

.composer-attachments {
    padding: 0.75rem;
    border-bottom: 1px solid hsl(var(--border));
    display: flex;
    flex-wrap: wrap;
    gap: 0.5rem;
}

.chat-placeholder {
    display: flex;
    align-items: center;
    justify-content: center;
    flex: 1;
    background: hsl(var(--background) / 0.3);
}

.placeholder-content {
    text-align: center;
    color: hsl(var(--muted-foreground));
}

.placeholder-content svg {
    margin: 0 auto 1rem;
    opacity: 0.5;
}

.placeholder-content h3 {
    margin: 0 0 0.5rem;
    font-size: 1.25rem;
    font-weight: 600;
    color: hsl(var(--foreground));
}

.placeholder-content p {
    margin: 0;
    font-size: 0.9375rem;
}

.search-input {
    padding: 0.5rem 1rem;
    border: 1px solid hsl(var(--border));
    border-radius: 0.5rem;
    background: hsl(var(--background));
    color: hsl(var(--foreground));
    font-size: 0.875rem;
    min-width: 250px;
}

.search-input:focus {
    outline: none;
    border-color: hsl(var(--primary));
}

@media (max-width: 1024px) {
    .messaging-container {
        grid-template-columns: 1fr;
        height: auto;
        min-height: 500px;
    }
    
    .conversations-panel {
        border-right: none;
        border-bottom: 1px solid hsl(var(--border));
        max-height: 400px;
    }
    
    .conversations-list {
        max-height: 350px;
    }
    
    .chat-view,
    .chat-panel {
        min-height: 500px;
    }
    
    .message-bubble {
        max-width: 85%;
    }
}

@media (max-width: 768px) {
    .messaging-container {
        border-radius: 0;
        min-height: calc(100vh - 200px);
    }
    
    .conversations-header {
        padding: 1rem;
    }
    
    .conversations-header h2 {
        font-size: 1.125rem;
    }
    
    .conversation-item {
        padding: 0.875rem 1rem;
    }
    
    .chat-header {
        padding: 1rem;
    }
    
    .chat-messages {
        padding: 1rem;
    }
    
    .chat-composer {
        padding: 1rem;
    }
    
    .message-bubble {
        max-width: 90%;
    }
}

/* Services Section */
.services-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(400px, 1fr));
    gap: 1.5rem;
}

.service-card {
    background: hsl(var(--card));
    border: 1px solid hsl(var(--border));
    border-radius: 1rem;
    padding: 1.5rem;
    transition: all 0.3s ease;
    display: flex;
    flex-direction: column;
}

.service-card:hover {
    border-color: hsl(var(--primary) / 0.5);
    transform: translateY(-2px);
    box-shadow: 0 4px 12px hsl(var(--primary) / 0.1);
}

.service-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1rem;
}

.service-icon {
    width: 48px;
    height: 48px;
    border-radius: 0.75rem;
    background: hsl(var(--primary) / 0.1);
    color: hsl(var(--primary));
    display: flex;
    align-items: center;
    justify-content: center;
}

.service-status-badge {
    padding: 0.375rem 0.75rem;
    border-radius: 9999px;
    font-size: 0.75rem;
    font-weight: 600;
    text-transform: uppercase;
}

.status-active {
    background: hsl(var(--primary) / 0.1);
    color: hsl(var(--primary));
}

.service-content {
    flex: 1;
}

.service-title {
    margin: 0 0 0.75rem 0;
    font-size: 1.25rem;
    font-weight: 700;
    color: hsl(var(--foreground));
}

.service-description {
    margin: 0 0 1.5rem 0;
    font-size: 0.9375rem;
    line-height: 1.6;
    color: hsl(var(--muted-foreground));
}

.service-meta {
    display: flex;
    gap: 1.5rem;
    margin-bottom: 1.5rem;
    padding-bottom: 1.5rem;
    border-bottom: 1px solid hsl(var(--border));
    flex-wrap: wrap;
}

.meta-item {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    font-size: 0.875rem;
    color: hsl(var(--muted-foreground));
}

.meta-item svg {
    width: 16px;
    height: 16px;
    color: hsl(var(--primary));
}

.service-stats {
    display: flex;
    gap: 2rem;
    margin-bottom: 1.5rem;
}

.service-stats .stat-item {
    display: flex;
    flex-direction: column;
    gap: 0.25rem;
}

.service-stats .stat-value {
    font-size: 1.125rem;
    font-weight: 700;
    color: hsl(var(--foreground));
}

.service-stats .stat-label {
    font-size: 0.75rem;
    color: hsl(var(--muted-foreground));
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.service-actions {
    display: flex;
    gap: 0.75rem;
    margin-top: auto;
    padding-top: 1rem;
    border-top: 1px solid hsl(var(--border));
}

.service-actions .btn {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
}

.btn-sm {
    padding: 0.5rem 1rem;
    font-size: 0.875rem;
}

@media (max-width: 768px) {
    .services-grid {
        grid-template-columns: 1fr;
    }
    
    .service-meta {
        flex-direction: column;
        gap: 0.75rem;
    }
    
    .service-stats {
        flex-direction: column;
        gap: 1rem;
    }
}

/* Premium/Direct Request Styling */
/* Request Tabs */
.request-tabs {
    display: flex;
    gap: 0.5rem;
    background: hsl(var(--muted) / 0.3);
    padding: 0.25rem;
    border-radius: 0.75rem;
}

.tab-btn {
    padding: 0.5rem 1rem;
    border: none;
    background: transparent;
    color: hsl(var(--muted-foreground));
    font-size: 0.875rem;
    font-weight: 600;
    border-radius: 0.5rem;
    cursor: pointer;
    transition: all 0.2s;
}

.tab-btn:hover {
    color: hsl(var(--foreground));
    background: hsl(var(--muted) / 0.5);
}

.tab-btn.active {
    background: hsl(var(--primary));
    color: hsl(var(--primary-foreground));
    box-shadow: 0 2px 4px hsl(var(--primary) / 0.3);
}

.request-card {
    background: hsl(var(--card));
    border: 1px solid hsl(var(--border));
    border-radius: 0.75rem;
    padding: 1.5rem;
    margin-bottom: 1rem;
    transition: all 0.3s ease;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
}

.request-card:hover {
    box-shadow: 0 4px 12px hsl(var(--primary) / 0.1);
    transform: translateY(-2px);
}

.request-actions {
    margin-top: 1rem;
    display: flex;
    gap: 0.75rem;
    padding-top: 1rem;
    border-top: 1px solid hsl(var(--border));
}

.request-card:hover {
    box-shadow: 0 4px 12px hsl(var(--primary) / 0.1);
    transform: translateY(-2px);
}

/* Normal Request - Standard Styling */
.request-card.normal {
    background: hsl(var(--card));
    border-color: hsl(var(--border));
}

.request-label-normal {
    display: inline-block;
    padding: 0.25rem 0.75rem;
    background: hsl(var(--secondary));
    color: hsl(var(--muted-foreground));
    border-radius: 9999px;
    font-size: 0.75rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    margin-bottom: 0.75rem;
}

/* Premium/Direct Request - Golden Styling */
.request-card.premium {
    background: linear-gradient(135deg, hsl(45 96% 55% / 0.05), hsl(45 96% 45% / 0.05));
    border: 2px solid hsl(45 96% 55%);
    box-shadow: 0 4px 16px hsl(45 96% 55% / 0.2);
    position: relative;
}

.request-card.premium::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: linear-gradient(90deg, hsl(45 96% 55%), hsl(45 96% 45%));
    border-radius: 0.75rem 0.75rem 0 0;
}

.request-label-premium {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    padding: 0.375rem 0.875rem;
    background: linear-gradient(135deg, hsl(45 96% 55%), hsl(45 96% 45%));
    color: hsl(var(--primary-foreground));
    border-radius: 9999px;
    font-size: 0.75rem;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    margin-bottom: 0.75rem;
    box-shadow: 0 2px 8px hsl(45 96% 55% / 0.3);
}

.request-label-premium::before {
    content: '⭐';
    font-size: 0.875rem;
}

/* VIP/Fast Track Request Label */
.request-label-vip {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    padding: 0.375rem 0.875rem;
    background: linear-gradient(135deg, #ffd700, #ff8c00);
    color: #1a1a1a;
    border-radius: 9999px;
    font-size: 0.75rem;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    margin-bottom: 0.75rem;
    box-shadow: 0 2px 12px rgba(255, 215, 0, 0.5);
    animation: vipLabelShine 2s ease-in-out infinite;
}

@keyframes vipLabelShine {
    0%, 100% { filter: brightness(1); }
    50% { filter: brightness(1.15); }
}

/* VIP/Fast Track Request Card */
.request-card.request-priority {
    background: linear-gradient(135deg, rgba(255, 215, 0, 0.08), rgba(255, 140, 0, 0.08));
    border: 2px solid rgba(255, 215, 0, 0.4);
    position: relative;
}

.request-card.request-priority::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: linear-gradient(90deg, #ffd700, #ff8c00);
    border-radius: 0.75rem 0.75rem 0 0;
}

.request-card.request-priority:hover {
    border-color: rgba(255, 215, 0, 0.7);
    box-shadow: 0 4px 20px rgba(255, 215, 0, 0.3);
}

.request-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 1rem;
}

.request-title {
    font-size: 1.125rem;
    font-weight: 600;
    color: hsl(var(--foreground));
    margin: 0;
}

.request-meta {
    display: flex;
    gap: 1rem;
    flex-wrap: wrap;
    color: hsl(var(--muted-foreground));
    font-size: 0.875rem;
    margin-top: 0.5rem;
}

.request-description {
    color: hsl(var(--foreground));
    font-size: 0.9375rem;
    line-height: 1.6;
    margin: 0.75rem 0;
}

.request-actions {
    display: flex;
    gap: 0.75rem;
    margin-top: 1rem;
}

.request-btn {
    padding: 0.625rem 1.25rem;
    border-radius: 0.5rem;
    font-size: 0.875rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.2s;
    border: none;
}

.request-btn-primary {
    background: linear-gradient(135deg, hsl(var(--brand-yellow)), hsl(var(--brand-green)));
    color: hsl(var(--primary-foreground));
}

.request-btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px hsl(220 40% 4% / 0.4);
}

.request-btn-secondary {
    background: hsl(var(--secondary));
    color: hsl(var(--foreground));
    border: 1px solid hsl(var(--border));
}

.request-btn-secondary:hover {
    background: hsl(var(--secondary) / 0.8);
    border-color: hsl(var(--primary) / 0.5);
}

/* Requests List */
.requests-list {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}

.status-badge {
    display: inline-block;
    padding: 0.375rem 0.75rem;
    border-radius: 9999px;
    font-size: 0.75rem;
    font-weight: 600;
    text-transform: capitalize;
}

.status-badge.status-in-progress {
    background: hsl(45 96% 55% / 0.2);
    color: hsl(45 96% 45%);
    border: 1px solid hsl(45 96% 55% / 0.3);
}

.status-badge.status-accepted {
    padding: 0.25rem 0.75rem;
    border-radius: 9999px;
    font-size: 0.75rem;
    font-weight: 600;
    text-transform: uppercase;
}

.status-badge.status-accepted {
    background: hsl(var(--brand-green) / 0.2);
    color: hsl(var(--brand-green));
}

.status-badge.status-deleted {
    background: hsl(var(--destructive) / 0.2);
    color: hsl(var(--destructive));
}

/* Service Modal Form Styles */
#serviceModal .form-input,
#serviceModal .form-textarea,
#serviceModal .form-select {
    width: 100%;
    padding: 0.75rem 1rem;
    border: 1px solid hsl(var(--border));
    border-radius: 0.5rem;
    background: hsl(var(--background));
    color: hsl(var(--foreground));
    font-size: 0.9375rem;
    font-family: inherit;
    transition: all 0.2s ease;
}

#serviceModal .form-input:focus,
#serviceModal .form-textarea:focus,
#serviceModal .form-select:focus {
    outline: none;
    border-color: hsl(var(--primary));
    box-shadow: 0 0 0 3px hsl(var(--primary) / 0.1);
}

#serviceModal .form-textarea {
    resize: vertical;
    min-height: 100px;
}

#serviceModal .form-label {
    display: block;
    margin-bottom: 0.5rem;
    font-size: 0.875rem;
    font-weight: 600;
    color: hsl(var(--foreground));
}

#serviceModal .form-select {
    cursor: pointer;
    appearance: none;
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23666' d='M6 9L1 4h10z'/%3E%3C/svg%3E");
    background-repeat: no-repeat;
    background-position: right 0.75rem center;
    padding-right: 2.5rem;
}

#serviceModal .form-select option {
    background: hsl(var(--background));
    color: hsl(var(--foreground));
}

#serviceModal input::placeholder,
#serviceModal textarea::placeholder {
    color: hsl(var(--muted-foreground));
    opacity: 0.7;
}
}

.status-badge.status-pending {
    background: hsl(var(--primary) / 0.2);
    color: hsl(var(--primary));
}

/* Request Modal/Popup */
.request-modal-overlay {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.7);
    backdrop-filter: blur(4px);
    z-index: 9999;
    align-items: center;
    justify-content: center;
    padding: 1rem;
    overflow-y: auto;
}

.request-modal-overlay.active {
    display: flex;
}

.request-modal {
    background: hsl(var(--card));
    border: 1px solid hsl(var(--border));
    border-radius: 1rem;
    max-width: 800px;
    width: 100%;
    max-height: 90vh;
    overflow-y: auto;
    position: relative;
    box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
    animation: modalFadeIn 0.3s ease;
}

@keyframes modalFadeIn {
    from {
        opacity: 0;
        transform: scale(0.95) translateY(-20px);
    }
    to {
        opacity: 1;
        transform: scale(1) translateY(0);
    }
}

.request-modal-header {
    padding: 1.5rem;
    border-bottom: 1px solid hsl(var(--border));
    display: flex;
    justify-content: space-between;
    align-items: center;
    position: sticky;
    top: 0;
    background: hsl(var(--card));
    z-index: 10;
}

.request-modal-title {
    font-size: 1.5rem;
    font-weight: 700;
    color: hsl(var(--foreground));
    margin: 0;
}

.request-modal-close {
    width: 32px;
    height: 32px;
    border-radius: 0.5rem;
    background: transparent;
    border: 1px solid hsl(var(--border));
    color: hsl(var(--foreground));
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.2s;
}

.request-modal-close:hover {
    background: hsl(var(--secondary));
    border-color: hsl(var(--primary));
}

.request-modal-body {
    padding: 1.5rem;
}

.request-modal-section {
    margin-bottom: 1.5rem;
}

.request-modal-section:last-child {
    margin-bottom: 0;
}

.request-modal-section-title {
    font-size: 1rem;
    font-weight: 600;
    color: hsl(var(--foreground));
    margin-bottom: 1rem;
    padding-bottom: 0.5rem;
    border-bottom: 1px solid hsl(var(--border));
}

.request-detail-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 1rem;
}

.request-detail-item {
    display: flex;
    flex-direction: column;
    gap: 0.25rem;
}

.request-detail-label {
    font-size: 0.75rem;
    font-weight: 600;
    color: hsl(var(--muted-foreground));
    text-transform: uppercase;
    letter-spacing: 0.05em;
}

.request-detail-value {
    font-size: 0.9375rem;
    color: hsl(var(--foreground));
}

.request-actions-modal {
    display: flex;
    gap: 1rem;
    padding-top: 1.5rem;
    border-top: 1px solid hsl(var(--border));
    margin-top: 1.5rem;
}

.request-card-compact {
    cursor: pointer;
}

.request-card-compact:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px hsl(var(--primary) / 0.15);
}

/* Enhanced Request Modal Styles */
.request-modal-customer-header {
    display: flex;
    align-items: center;
    gap: 1rem;
    padding-bottom: 1.25rem;
    border-bottom: 1px solid hsl(var(--border));
    margin-bottom: 1.5rem;
}

.request-modal-customer-header .customer-avatar {
    width: 64px;
    height: 64px;
    border-radius: 50%;
    background: linear-gradient(135deg, hsl(60 96% 79%), hsl(186 80% 19%));
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.5rem;
    font-weight: 700;
    color: hsl(var(--primary-foreground));
    flex-shrink: 0;
}

.request-modal-customer-header .customer-details {
    flex: 1;
}

.request-modal-customer-header .customer-name {
    font-size: 1.25rem;
    font-weight: 700;
    color: hsl(var(--foreground));
    margin: 0 0 0.5rem 0;
}

.request-modal-customer-header .request-meta {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    flex-wrap: wrap;
}

.request-modal-customer-header .request-time {
    font-size: 0.875rem;
    color: hsl(var(--muted-foreground));
}

.request-type-badge {
    display: inline-flex;
    align-items: center;
    padding: 0.25rem 0.75rem;
    border-radius: 1rem;
    font-size: 0.75rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.05em;
}

.request-type-badge.premium {
    background: linear-gradient(135deg, hsl(45 100% 50% / 0.2), hsl(45 100% 50% / 0.1));
    color: hsl(45 100% 50%);
    border: 1px solid hsl(45 100% 50% / 0.3);
}

.request-type-badge.normal {
    background: hsl(var(--muted));
    color: hsl(var(--muted-foreground));
    border: 1px solid hsl(var(--border));
}

.request-modal-content-wrapper {
    display: flex;
    flex-direction: column;
    gap: 1.5rem;
}

.request-modal-section {
    background: hsl(var(--muted) / 0.3);
    border: 1px solid hsl(var(--border));
    border-radius: 0.75rem;
    padding: 1.25rem;
}

.request-modal-section .section-title,
.request-modal-section h4.section-title,
.request-modal-body .request-modal-section .section-title {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    font-size: 0.75rem !important;
    font-weight: 600;
    color: hsl(var(--foreground));
    margin: 0 0 0.75rem 0;
    line-height: 1.4;
}

.request-modal-body .request-modal-section .section-title {
    font-size: 1.2rem !important;
}

.request-modal-section .section-title svg,
.request-modal-body .request-modal-section .section-title svg {
    color: hsl(var(--primary));
    flex-shrink: 0;
    width: 14px !important;
    height: 14px !important;
}

.request-modal-section .info-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 1rem;
}

.request-modal-section .info-item {
    display: flex;
    flex-direction: column;
    gap: 0.25rem;
}

.request-modal-section .info-label {
    font-size: 0.75rem;
    font-weight: 600;
    color: hsl(var(--muted-foreground));
    text-transform: uppercase;
    letter-spacing: 0.05em;
}

.request-modal-section .info-value {
    font-size: 0.9375rem;
    color: hsl(var(--foreground));
    font-weight: 500;
}

.request-modal-section .services-list {
    list-style: none;
    padding: 0;
    margin: 0;
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 0.5rem;
}

.request-modal-section .services-list li {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    padding: 0.625rem 0.875rem;
    background: hsl(var(--card));
    border: 1px solid hsl(var(--border));
    border-radius: 0.5rem;
    font-size: 0.875rem;
    color: hsl(var(--foreground));
}

.request-modal-section .services-list li::before {
    content: '✓';
    color: hsl(var(--primary));
    font-weight: 700;
}

.request-modal-section .description-text,
.request-modal-section .location-text {
    font-size: 0.9375rem;
    color: hsl(var(--foreground));
    line-height: 1.6;
    margin: 0;
}

.modal-actions {
    display: flex;
    gap: 1rem;
    padding-top: 1.5rem;
    border-top: 1px solid hsl(var(--border));
    margin-top: 1.5rem;
}

.modal-actions .btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
    padding: 0.75rem 1.5rem;
    border-radius: 0.5rem;
    font-size: 0.9375rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.2s;
    min-width: 140px;
}

.modal-actions .btn-primary {
    background: linear-gradient(135deg, hsl(60 96% 79%), hsl(186 80% 19%));
    color: hsl(var(--primary-foreground));
    border: none;
}

.modal-actions .btn-primary:hover {
    transform: translateY(-1px);
    box-shadow: 0 4px 12px hsl(var(--primary) / 0.3);
}

.modal-actions .btn-primary:disabled {
    opacity: 0.6;
    cursor: not-allowed;
    transform: none;
}

.modal-actions .btn-outline {
    background: transparent;
    border: 1px solid hsl(var(--border));
    color: hsl(var(--foreground));
}

.modal-actions .btn-outline:hover {
    background: hsl(var(--muted));
    border-color: hsl(var(--primary));
}

.modal-actions .modal-delete-btn {
    color: hsl(var(--destructive));
    border-color: hsl(var(--destructive) / 0.3);
}

.modal-actions .modal-delete-btn:hover {
    background: hsl(var(--destructive) / 0.1);
    border-color: hsl(var(--destructive));
}

.modal-actions .spinner {
    display: inline-block;
    width: 16px;
    height: 16px;
    border: 2px solid transparent;
    border-top-color: currentColor;
    border-radius: 50%;
    animation: spin 0.8s linear infinite;
}

@keyframes spin {
    to { transform: rotate(360deg); }
}

/* Status badges in modal */
.request-modal-customer-header .status-badge {
    display: inline-flex;
    align-items: center;
    padding: 0.25rem 0.75rem;
    border-radius: 1rem;
    font-size: 0.75rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.05em;
}

.request-modal-customer-header .status-pending {
    background: hsl(45 100% 50% / 0.1);
    color: hsl(45 100% 40%);
    border: 1px solid hsl(45 100% 50% / 0.3);
}

.request-modal-customer-header .status-accepted {
    background: hsl(142 76% 36% / 0.1);
    color: hsl(142 76% 36%);
    border: 1px solid hsl(142 76% 36% / 0.3);
}

.request-modal-customer-header .status-in-progress {
    background: hsl(217 91% 60% / 0.1);
    color: hsl(217 91% 60%);
    border: 1px solid hsl(217 91% 60% / 0.3);
}

.request-modal-customer-header .status-pending-completion {
    background: hsl(35 100% 50% / 0.1);
    color: hsl(35 100% 50%);
    border: 1px solid hsl(35 100% 50% / 0.3);
}

.request-modal-customer-header .status-waiting-approval,
.status-badge.status-waiting-approval {
    background: hsl(280 70% 50% / 0.1);
    color: hsl(280 70% 50%);
    border: 1px solid hsl(280 70% 50% / 0.3);
}

.request-modal-customer-header .status-complete {
    background: hsl(142 76% 36% / 0.1);
    color: hsl(142 76% 36%);
    border: 1px solid hsl(142 76% 36% / 0.3);
}

@media (max-width: 768px) {
    .request-modal-customer-header {
        flex-direction: column;
        text-align: center;
    }
    
    .request-modal-customer-header .request-meta {
        justify-content: center;
    }
    
    .modal-actions {
        flex-direction: column;
    }
    
    .modal-actions .btn {
        width: 100%;
    }
}

@media (max-width: 768px) {
    .request-detail-grid {
        grid-template-columns: 1fr;
    }
    
    .request-modal {
        max-width: 100%;
        margin: 0;
        border-radius: 0;
        max-height: 100vh;
    }
    
    .request-actions-modal {
        flex-direction: column;
    }
    
    .request-btn {
        width: 100%;
    }
}
</style>

<div class="dashboard-container">
    <!-- Dashboard Sidebar -->
    <aside class="dashboard-sidebar">
        <div class="sidebar-header">
            <div class="profile-image-container" id="profileImageContainer">
                <?php if ( $profile_image_id && is_numeric( $profile_image_id ) && $user_avatar && strpos( $user_avatar, 'gravatar.com' ) === false ) : ?>
                    <img src="<?php echo esc_url( $user_avatar ); ?>" alt="Profile" class="profile-image" id="profileImage">
                <?php else : ?>
                    <div class="profile-initials" id="profileInitials">
                    </div>
                <?php endif; ?>
                <button class="edit-image-btn" id="editImageBtn" title="Edit Profile Image">
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M14.5 2.5L17.5 5.5M16 1L19 4L11 12H8V9L16 1Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                        <path d="M16 6V16C16 17.1046 15.1046 18 14 18H4C2.89543 18 2 17.1046 2 16V6C2 4.89543 2.89543 4 4 4H14C15.1046 4 16 4.89543 16 6Z" stroke="currentColor" stroke-width="2"></path>
                    </svg>
                </button>
                <input type="file" id="profileImageInput" accept="image/*" style="display: none;">
                <div class="image-upload-actions" id="imageUploadActions" style="display: none;">
                    <div class="image-upload-buttons">
                        <button class="btn btn-primary btn-sm" id="saveImageBtn">
                            <svg width="16" height="16" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M16.7071 5.29289C17.0976 5.68342 17.0976 6.31658 16.7071 6.70711L8.70711 14.7071C8.31658 15.0976 7.68342 15.0976 7.29289 14.7071L3.29289 10.7071C2.90237 10.3166 2.90237 9.68342 3.29289 9.29289C3.68342 8.90237 4.31658 8.90237 4.70711 9.29289L8 12.5858L15.2929 5.29289C15.6834 4.90237 16.3166 4.90237 16.7071 5.29289Z" fill="currentColor"></path>
                            </svg>
                            Save
                        </button>
                        <button class="btn btn-outline btn-sm" id="cancelImageBtn">
                            <svg width="16" height="16" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M15 5L5 15M5 5L15 15" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                            </svg>
                            Cancel
                        </button>
                    </div>
                    <div class="image-upload-status" id="imageStatus" style="display: none;"></div>
                </div>
                    </div>
            <h2 class="profile-name" id="profileName" style="display: flex; align-items: center; gap: 0.5rem; flex-wrap: wrap;">
                <span><?php echo esc_html( $business_name ? $business_name : $user_name ); ?></span>
                <?php if ( $is_verified ) : ?>
                    <span class="verified-badge-dashboard" data-tooltip="<?php esc_attr_e('Verified Partner', 'wheelfy'); ?>" style="display: inline-flex; align-items: center; justify-content: center; width: 24px; height: 24px; background: linear-gradient(135deg, #00c853, #00e676); border-radius: 50%; box-shadow: 0 2px 8px rgba(0, 200, 83, 0.4); cursor: help; flex-shrink: 0; position: relative;">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" style="color: white;">
                            <polyline points="20 6 9 17 4 12"></polyline>
                        </svg>
                    </span>
                <?php endif; ?>
            </h2>
            <p class="profile-email"><?php echo esc_html( $user_email ); ?></p>
            <?php if ( $business_name && $business_name !== $user_name ) : ?>
                <p class="profile-business" style="font-size: 0.75rem; color: hsl(var(--muted-foreground)); margin-top: 0.25rem;"><?php echo esc_html( $user_name ); ?></p>
            <?php endif; ?>
            <a href="<?php echo esc_url(home_url('/partner/' . $viewing_user_id . '/')); ?>" class="view-profile-btn" target="_blank" style="display: inline-flex; align-items: center; gap: 0.5rem; margin-top: 1rem; padding: 0.5rem 1rem; background: linear-gradient(135deg, hsl(60 96% 79%), hsl(186 80% 19%)); color: hsl(var(--primary-foreground)); border-radius: 0.5rem; font-size: 0.8125rem; font-weight: 600; text-decoration: none; transition: all 0.2s;">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
                    <polyline points="15 3 21 3 21 9"></polyline>
                    <line x1="10" y1="14" x2="21" y2="3"></line>
                </svg>
                View Public Profile
            </a>
            </div>

        <nav class="dashboard-nav">
            <a href="#dashboard" class="nav-item active" data-section="dashboard">
                <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M3 3H9V9H3V3Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                    <path d="M11 3H17V9H11V3Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                    <path d="M3 11H9V17H3V11Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                    <path d="M11 11H17V17H11V11Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                </svg>
                Dashboard
            </a>
            <a href="#profile" class="nav-item" data-section="profile">
                <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M10 10C12.7614 10 15 7.76142 15 5C15 2.23858 12.7614 0 10 0C7.23858 0 5 2.23858 5 5C5 7.76142 7.23858 10 10 10Z" fill="currentColor"></path>
                    <path d="M10 12C6.68629 12 0 13.7909 0 17V20H20V17C20 13.7909 13.3137 12 10 12Z" fill="currentColor"></path>
                </svg>
                Profile
            </a>
            <?php if (!$is_car_dealership) : ?>
            <a href="#services" class="nav-item" data-section="services">
                <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M3 4H17C17.5523 4 18 4.44772 18 5V15C18 15.5523 17.5523 16 17 16H3C2.44772 16 2 15.5523 2 15V5C2 4.44772 2.44772 4 3 4Z" stroke="currentColor" stroke-width="2"></path>
                    <path d="M6 8H14M6 12H10" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path>
                </svg>
                Services
            </a>
            <?php endif; ?>
            <?php if (!$is_car_dealership) : ?>
            <a href="#subscription-plans" class="nav-item" data-section="subscription-plans">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <rect x="3" y="8" width="18" height="4" rx="1"></rect>
                    <path d="M12 8v13"></path>
                    <path d="M19 12v7a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2v-7"></path>
                    <path d="M7.5 8a2.5 2.5 0 0 1 0-5A4.8 8 0 0 1 12 8a4.8 8 0 0 1 4.5-5 2.5 2.5 0 0 1 0 5"></path>
                </svg>
                Upgrade Plan
            </a>
            <?php endif; ?>
            <a href="#messaging" class="nav-item" data-section="messaging">
                <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M18 2H2C0.895431 2 0 2.89543 0 4V16C0 17.1046 0.895431 18 2 18H18C19.1046 18 20 17.1046 20 16V4C20 2.89543 19.1046 2 18 2Z" stroke="currentColor" stroke-width="2"></path>
                    <path d="M2 6L10 11L18 6" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path>
                </svg>
                Messaging
                <span class="badge" id="messagingBadgeCount" style="display: none;">0</span>
            </a>
            <a href="#requests" class="nav-item" data-section="requests">
                <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M2 4H18V16H2V4Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                    <path d="M6 8H14M6 12H10" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path>
                </svg>
                Requests
                <span class="badge" id="requestsBadgeCount" style="display: none;">0</span>
            </a>
            <a href="#reviews" class="nav-item" data-section="reviews">
                <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="currentColor"></path>
                </svg>
                Reviews
            </a>
            <?php if (!$is_car_dealership) : ?>
            <a href="#analytics" class="nav-item" data-section="analytics">
                <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M3 16L9 10L13 14L17 10" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                    <path d="M17 16H3" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path>
                </svg>
                Analytics
            </a>
            <?php endif; ?>
            <a href="#notifications" class="nav-item" data-section="notifications">
                <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M10 2C8.34315 2 7 3.34315 7 5V8C7 9.10457 6.89543 10 6 10H4C2.89543 10 2 10.8954 2 12V14C2 15.1046 2.89543 16 4 16H16C17.1046 16 18 15.1046 18 14V12C18 10.8954 17.1046 10 16 10H14C13.1046 10 13 9.10457 13 8V5C13 3.34315 11.6569 2 10 2Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                    <path d="M7 16C7 17.1046 7.89543 18 9 18H11C12.1046 18 13 17.1046 13 16" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                </svg>
                Notifications
                <span class="badge" id="notificationsBadgeCount" style="display: none;">0</span>
            </a>
            <a href="#settings" class="nav-item" data-section="settings">
                <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M10 12C11.1046 12 12 11.1046 12 10C12 8.89543 11.1046 8 10 8C8.89543 8 8 8.89543 8 10C8 11.1046 8.89543 12 10 12Z" stroke="currentColor" stroke-width="2"></path>
                    <path d="M17.6569 10C17.6569 10.4142 17.6569 10.8284 17.6569 11.2426C17.6569 11.6569 17.6569 12.0711 17.6569 12.4853C17.6569 12.8995 17.6569 13.3137 17.6569 13.7279C17.6569 14.1421 17.6569 14.5563 17.6569 14.9706C17.6569 15.3848 17.6569 15.799 17.6569 16.2132C17.6569 16.6274 17.6569 17.0416 17.6569 17.4558C17.6569 17.87 17.6569 18.2842 17.6569 18.6984" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path>
                    <path d="M2.34315 10C2.34315 9.58579 2.34315 9.17157 2.34315 8.75736C2.34315 8.34315 2.34315 7.92893 2.34315 7.51472C2.34315 7.1005 2.34315 6.68629 2.34315 6.27208C2.34315 5.85786 2.34315 5.44365 2.34315 5.02943C2.34315 4.61522 2.34315 4.20101 2.34315 3.78679C2.34315 3.37258 2.34315 2.95837 2.34315 2.54415C2.34315 2.12994 2.34315 1.71573 2.34315 1.30151" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path>
                </svg>
                Settings
            </a>
            <a href="<?php echo esc_url( wp_logout_url( home_url( '/' ) ) ); ?>" class="nav-item-logout">
                <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M13 7L17 11M17 11L13 15M17 11H7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                    <path d="M7 3H5C3.89543 3 3 3.89543 3 5V15C3 16.1046 3.89543 17 5 17H7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                </svg>
                <span>Log Out</span>
            </a>
        </nav>
    </aside>

    <!-- Dashboard Content -->
    <div class="dashboard-content">
        <!-- Dashboard Overview Section -->
        <section id="dashboardSection" class="dashboard-section active">
            <div class="section-header">
                <div>
                    <h1>Dashboard</h1>
                    <span class="welcome-text">Welcome back, <?php echo esc_html( $business_name ? $business_name : $user_name ); ?></span>
                    </div>
                    </div>

            <?php if (($current_plan_slug === 'basic' || empty($current_subscription)) && !$is_car_dealership) : ?>
            <!-- Free Plan Reminder Banner -->
            <div class="free-plan-notification-banner" id="freePlanBanner">
                <div class="notification-content">
                    <div class="notification-icon">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M12 2L2 7l10 5 10-5-10-5z"></path>
                            <path d="M2 17l10 5 10-5M2 12l10 5 10-5"></path>
                        </svg>
                    </div>
                    <div class="notification-text">
                        <h3><?php _e('You\'re currently on the Free Plan', 'wheelfy'); ?></h3>
                        <p><?php _e('Upgrade to unlock more features, get priority support, and grow your business faster!', 'wheelfy'); ?></p>
                    </div>
                    <div class="notification-actions">
                        <a href="#subscription-plans" class="btn btn-primary nav-link" data-section="subscription-plans">
                            <?php _e('View Plans', 'wheelfy'); ?>
                        </a>
                        <button class="btn btn-outline dismiss-notification" data-notification="free-plan-banner">
                            <?php _e('Dismiss', 'wheelfy'); ?>
                        </button>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <div class="dashboard-overview">
                <div class="overview-cards">
                    <div class="overview-card">
                        <div class="overview-icon overview-icon-info">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M21 15C21 15.5304 20.7893 16.0391 20.4142 16.4142C20.0391 16.7893 19.5304 17 19 17H7L3 21V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H19C19.5304 3 20.0391 3.21071 20.4142 3.58579C20.7893 3.96086 21 4.46957 21 5V15Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                            </svg>
                    </div>
                        <div class="overview-content">
                            <h3><?php echo esc_html( $active_requests ); ?></h3>
                            <p>Active Requests</p>
                    </div>
                </div>

                    <div class="overview-card">
                        <div class="overview-icon overview-icon-info">
                            <?php if ($is_car_dealership) : ?>
                            <!-- Car icon for Car Dealership -->
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.4 2.9A3.7 3.7 0 0 0 2 12v4c0 .6.4 1 1 1h2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                <circle cx="7" cy="17" r="2" stroke="currentColor" stroke-width="2"/>
                                <path d="M9 17h6" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                                <circle cx="17" cy="17" r="2" stroke="currentColor" stroke-width="2"/>
                            </svg>
                            <?php else : ?>
                            <!-- Checkmark icon for Repair Shop -->
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                            </svg>
                            <?php endif; ?>
                        </div>
                        <div class="overview-content">
                            <h3><?php echo esc_html( $cars_purchased ); ?></h3>
                            <p><?php echo $is_car_dealership ? 'Cars Purchased' : 'Completed Jobs'; ?></p>
                    </div>
                </div>

                    <div class="overview-card">
                        <div class="overview-icon overview-icon-info">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                            </svg>
                            </div>
                        <div class="overview-content">
                            <h3>$<?php echo number_format( $total_revenue, 0 ); ?></h3>
                            <p>Total Revenue</p>
                            </div>
                            </div>
                        </div>

                <div class="recent-activity-summary">
                    <h2>Recent Activity</h2>
                    <div class="activity-summary-list" id="recentActivityList">
                        <?php if (!empty($recent_activities)) : ?>
                            <?php 
                            $activity_index = 0;
                            $activities_per_page = 5;
                            foreach ($recent_activities as $activity) : 
                                $is_hidden = $activity_index >= $activities_per_page;
                            ?>
                                <div class="activity-summary-item<?php echo $is_hidden ? ' activity-hidden' : ''; ?>" data-activity-index="<?php echo $activity_index; ?>">
                                    <div class="activity-summary-icon activity-icon-<?php echo esc_attr($activity['icon']); ?>"></div>
                                    <div class="activity-summary-content">
                                        <p><?php echo esc_html($activity['message']); ?></p>
                                        <span><?php echo esc_html($activity['time']); ?></span>
                                    </div>
                                </div>
                            <?php 
                            $activity_index++;
                            endforeach; 
                            ?>
                        <?php else : ?>
                            <div class="activity-summary-item">
                                <div class="activity-summary-content">
                                    <p><?php _e('No recent activities.', 'wheelfy'); ?></p>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                    <?php if (count($recent_activities) > $activities_per_page) : ?>
                    <button type="button" id="loadMoreActivities" class="load-more-activities-btn" data-total="<?php echo count($recent_activities); ?>" data-per-page="<?php echo $activities_per_page; ?>" data-showing="<?php echo $activities_per_page; ?>">
                        <span style="display: flex; align-items: center; justify-content: center; gap: 0.5rem;">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <polyline points="6 9 12 15 18 9"></polyline>
                            </svg>
                            Load More (<?php echo count($recent_activities) - $activities_per_page; ?> remaining)
                        </span>
                    </button>
                    <?php endif; ?>
                    <a href="#profile" class="view-all-link nav-link" data-section="profile">
                        View full profile →
                    </a>
                </div>
                                    </div>
        </section>

        <!-- Profile Section -->
        <section id="profileSection" class="dashboard-section">
            <div class="section-header">
                <h1>My Profile</h1>
                <button class="edit-btn" id="editProfileBtn">
                    <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M13.5 2.5L15.5 4.5M14 1L17 4L9 12H6V9L14 1Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                        <path d="M14 6V14C14 15.1046 13.1046 16 12 16H4C2.89543 16 2 15.1046 2 14V6C2 4.89543 2.89543 4 4 4H12C13.1046 4 14 4.89543 14 6Z" stroke="currentColor" stroke-width="2"></path>
                    </svg>
                    Edit
                </button>
                                </div>

            <div class="profile-content">
                <!-- Profile Completion Card -->
                <div class="profile-card completion-card">
                    <div class="card-header">
                        <h3>Profile Completion</h3>
                        <span class="completion-badge" id="completionPercentage"><?php echo esc_html( $completion_percentage ); ?>%</span>
                            </div>
                    <div class="card-body">
                        <div class="completion-bar">
                            <div class="completion-fill" id="completionFill" style="width: <?php echo esc_attr( $completion_percentage ); ?>%;"></div>
                                </div>
                        <?php if ( $completion_percentage < 100 ) : 
                            // Build missing fields message
                            $missing_fields = array();
                            if ( empty($user_name) || $user_name === 'Not added' ) $missing_fields[] = 'Name';
                            if ( empty($business_name) || $business_name === 'Not added' ) $missing_fields[] = 'Business Name';
                            if ( empty($user_email) ) $missing_fields[] = 'Email';
                            if ( empty($user_phone) || $user_phone === 'Not added' ) $missing_fields[] = 'Phone';
                            if ( empty($user_location) || $user_location === 'Not added' ) $missing_fields[] = 'Location';
                            if ( empty($user_bio) || $user_bio === 'Not added' ) $missing_fields[] = 'Biography';
                        ?>
                        <p class="completion-text" style="margin-bottom: 0.5rem;">Complete your profile to improve your experience</p>
                        <p class="completion-text" style="font-size: 0.8rem; color: hsl(var(--muted-foreground));">
                            <strong>Missing:</strong> <?php echo esc_html(implode(', ', $missing_fields)); ?>
                        </p>
                        <?php else : ?>
                        <p class="completion-text" style="color: hsl(142 76% 36%);">✓ Your profile is complete!</p>
                        <?php endif; ?>
                        </div>
                    </div>

                <!-- Statistics Cards -->
                <div class="stats-grid">
                    <div class="stat-card stat-card-primary">
                        <div class="stat-icon">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z" fill="currentColor"></path>
                            </svg>
                            </div>
                        <div class="stat-content">
                            <h4 class="stat-value" id="totalReviews"><?php echo esc_html( $total_reviews ); ?></h4>
                            <p class="stat-label">Reviews Received</p>
                                </div>
                                </div>
                    <div class="stat-card stat-card-info">
                        <div class="stat-icon">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                            </svg>
                                </div>
                        <div class="stat-content">
                            <h4 class="stat-value" id="completedJobs"><?php echo esc_html( $cars_purchased ); ?></h4>
                            <p class="stat-label"><?php echo $is_car_dealership ? 'Cars Purchased' : 'Completed Jobs'; ?></p>
                                </div>
                            </div>
                        </div>

                <!-- Bio Section -->
                <div class="profile-card">
                    <div class="card-header">
                        <h3>Biography</h3>
                        <button class="icon-btn edit-bio-btn" id="editBioBtn">
                            <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M13.5 2.5L15.5 4.5M14 1L17 4L9 12H6V9L14 1Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                            </svg>
                        </button>
                            </div>
                    <div class="card-body">
                        <p class="bio-text" id="bioText"><?php echo $user_bio ? esc_html( $user_bio ) : 'You haven\'t added a biography yet. Click edit to add one.'; ?></p>
                        <div class="bio-edit-form" id="bioEditForm" style="display: none;">
                            <textarea id="bioTextarea" rows="5" placeholder="Write your biography here..."><?php echo esc_textarea( $user_bio ); ?></textarea>
                            <div class="form-actions">
                                <button class="btn btn-primary" id="saveBioBtn">Save</button>
                                <button class="btn btn-outline" id="cancelBioBtn">Cancel</button>
                        </div>
                    </div>
                </div>
                </div>
                <!-- Personal Information -->
                <div class="profile-card">
                    <div class="card-header">
                        <h3>Personal Information</h3>
                        <button class="icon-btn edit-info-btn" id="editInfoBtn">
                            <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M13.5 2.5L15.5 4.5M14 1L17 4L9 12H6V9L14 1Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                            </svg>
                        </button>
                            </div>
                    <div class="card-body">
                        <div class="info-grid">
                            <div class="info-item">
                                <label>Name</label>
                                <p class="info-value" id="nameValue"><?php echo $user_name ? esc_html( $user_name ) : 'Not added'; ?></p>
                                <input type="text" class="info-input" id="nameInput" value="<?php echo esc_attr( $user_name ); ?>" placeholder="Your Full Name" style="display: none;">
                            </div>
                            <div class="info-item">
                                <label>Business Name</label>
                                <p class="info-value" id="businessNameValue"><?php echo $business_name ? esc_html( $business_name ) : 'Not added'; ?></p>
                                <input type="text" class="info-input" id="businessNameInput" value="<?php echo esc_attr( $business_name ); ?>" placeholder="Your Business Name" style="display: none;">
                            </div>
                            <div class="info-item">
                                <label>Contact Person</label>
                                <p class="info-value" id="fullNameValue"><?php echo esc_html( $user_name ); ?></p>
                                <input type="text" class="info-input" id="fullNameInput" value="<?php echo esc_attr( $user_name ); ?>" style="display: none;">
                            </div>
                            <div class="info-item">
                                <label>Email</label>
                                <p class="info-value" id="emailValue"><?php echo esc_html( $user_email ); ?></p>
                                <input type="email" class="info-input" id="emailInput" value="<?php echo esc_attr( $user_email ); ?>" style="display: none;">
                            </div>
                            <div class="info-item">
                                <label>Phone</label>
                                <p class="info-value" id="phoneValue"><?php echo $user_phone ? esc_html( $user_phone ) : 'Not added'; ?></p>
                                <input type="tel" class="info-input" id="phoneInput" value="<?php echo esc_attr( $user_phone ); ?>" placeholder="+1 234 567 8900" style="display: none;">
                            </div>
                            <div class="info-item">
                                <label>Location</label>
                                <p class="info-value" id="locationValue"><?php echo $user_location ? esc_html( $user_location ) : 'Not added'; ?></p>
                                <input type="text" class="info-input" id="locationInput" value="<?php echo esc_attr( $user_location ); ?>" placeholder="City, Country" style="display: none;">
                             </div>
                             </div>
                         </div>
                        <div class="form-actions" id="infoFormActions" style="display: none;">
                            <button class="btn btn-primary" id="saveInfoBtn">Save</button>
                            <button class="btn btn-outline" id="cancelInfoBtn">Cancel</button>
                         </div>
                        </div>

                <!-- Professional Information -->
                <?php if (!$is_car_dealership) : ?>
                <div class="profile-card">
                    <div class="card-header">
                        <h3>Professional Information</h3>
                        <button class="icon-btn edit-professional-btn" id="editProfessionalBtn">
                            <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M13.5 2.5L15.5 4.5M14 1L17 4L9 12H6V9L14 1Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                            </svg>
                        </button>
                    </div>
                    <div class="card-body">
                        <div class="info-grid">
                            <div class="info-item">
                                <label>Profession</label>
                                <p class="info-value" id="professionValue"><?php echo $partner_profession ? esc_html( $partner_profession ) : 'Not added'; ?></p>
                                <input type="text" class="info-input" id="professionInput" value="<?php echo esc_attr( $partner_profession ); ?>" placeholder="Enter your profession" style="display: none;">
                            </div>
                            <div class="info-item">
                                <label>Hourly Rate / Starting Price</label>
                                <p class="info-value" id="priceValue">
                                    <?php 
                                    if ($partner_price) {
                                        $currency = get_user_meta($viewing_user_id, 'partner_price_currency', true) ?: get_option('wheelfy_currency', 'USD');
                                        $currency_symbols = array(
                                            'USD' => '$',
                                            'EUR' => '€',
                                            'GBP' => '£',
                                            'HUF' => 'Ft'
                                        );
                                        $symbol = isset($currency_symbols[$currency]) ? $currency_symbols[$currency] : '$';
                                        echo esc_html(number_format(floatval($partner_price), 2) . ' ' . $symbol . ' ' . $currency);
                                    } else {
                                        echo 'Not added';
                                    }
                                    ?>
                                </p>
                                <div id="priceInputWrapper" class="info-price-wrapper" style="display: none;">
                                    <?php
                                    $current_currency = get_user_meta($viewing_user_id, 'partner_price_currency', true) ?: get_option('wheelfy_currency', 'USD');
                                    ?>
                                    <input type="number" class="info-input" id="priceInput" value="<?php echo esc_attr($partner_price); ?>" placeholder="0.00" step="0.01" min="0" style="flex: 1;">
                                    <select class="info-input" id="priceCurrency" style="width: auto; margin-left: 0.5rem;">
                                        <option value="USD" <?php selected($current_currency, 'USD'); ?>>$ USD</option>
                                        <option value="HUF" <?php selected($current_currency, 'HUF'); ?>>Ft HUF</option>
                                    </select>
                                </div>
                            </div>
                            <div class="info-item">
                                <label>Experience</label>
                                <p class="info-value" id="experienceValue"><?php echo $partner_experience ? esc_html( $partner_experience ) : 'Not added'; ?></p>
                                <input type="text" class="info-input" id="experienceInput" value="<?php echo esc_attr( $partner_experience ); ?>" placeholder="Enter experience" style="display: none;">
                            </div>
                        </div>
                    </div>
                    <div class="form-actions" id="professionalFormActions" style="display: none;">
                        <button class="btn btn-primary" id="saveProfessionalBtn">Save</button>
                        <button class="btn btn-outline" id="cancelProfessionalBtn">Cancel</button>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </section>

        <!-- Services Section -->
        <?php if (!$is_car_dealership) : ?>
        <section id="servicesSection" class="dashboard-section">
            <div class="section-header">
                <h1>My Services</h1>
                <button class="edit-btn btn-sm" id="addServiceBtn">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M12 5V19M5 12H19" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path>
                    </svg>
                    Add Service
                </button>
                        </div>
            <div class="profile-content">
                <?php
                // Get real services from user meta
                $partner_services = function_exists('wheelfy_get_partner_services') ? wheelfy_get_partner_services($viewing_user_id, 'all') : array();
                
                // Count requests per service (from transients/user meta)
                foreach ($partner_services as $key => $service) {
                    $service_id = isset($service['id']) ? $service['id'] : '';
                    $request_count = 0;
                    
                    // Count requests for this service
                    if (!empty($service_id)) {
                        global $wpdb;
                        $transient_prefix = '_transient_car_accessories_request_';
                        $transient_keys = $wpdb->get_col($wpdb->prepare(
                            "SELECT option_value FROM {$wpdb->options} 
                            WHERE option_name LIKE %s
                            AND option_name LIKE %s",
                            $wpdb->esc_like($transient_prefix) . '%',
                            '%_partner_' . $viewing_user_id
                        ));
                        
                        foreach ($transient_keys as $transient_value) {
                            $form_data = maybe_unserialize($transient_value);
                            if (is_array($form_data) && isset($form_data['service_id']) && $form_data['service_id'] === $service_id) {
                                $request_count++;
                            }
                        }
                    }
                    
                    $partner_services[$key]['requests'] = $request_count;
                    $partner_services[$key]['rating'] = 0; // Can be calculated from reviews later
                }
                ?>
                
                <?php if (empty($partner_services)) : ?>
                    <div class="empty-state" style="text-align: center; padding: 3rem 2rem;">
                        <div class="empty-state-icon" style="font-size: 3rem; margin-bottom: 1rem;">🔧</div>
                        <h3 class="empty-state-title" style="margin: 0 0 0.5rem; font-size: 1.125rem; font-weight: 600; color: hsl(var(--foreground));">No Services Yet</h3>
                        <p class="empty-state-text" style="margin: 0 0 1.5rem; font-size: 0.9375rem; color: hsl(var(--muted-foreground));">Add your first service to start receiving requests from customers.</p>
                        <button class="btn btn-primary" id="addServiceBtnEmpty">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M12 5V19M5 12H19" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path>
                            </svg>
                            Add Your First Service
                        </button>
                    </div>
                <?php else : ?>
                <div class="services-grid">
                    <?php foreach ($partner_services as $service) : 
                        $service_id = isset($service['id']) ? $service['id'] : '';
                        $service_price = isset($service['price']) ? floatval($service['price']) : 0;
                        $service_currency = isset($service['price_currency']) ? $service['price_currency'] : 'EUR';
                        $currency_symbol = ($service_currency === 'HUF') ? 'HUF' : '€';
                        $price_display = ($service_currency === 'HUF') ? number_format($service_price, 0, ',', ' ') : number_format($service_price, 2);
                    ?>
                        <div class="service-card">
                            <div class="service-header">
                                <div class="service-icon">
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"></path>
                                </svg>
                        </div>
                                <div class="service-status-badge status-active">
                                    <?php echo esc_html(ucfirst($service['status'])); ?>
                    </div>
                    </div>
                            
                            <div class="service-content">
                                <h3 class="service-title"><?php echo esc_html($service['title']); ?></h3>
                                <p class="service-description"><?php echo esc_html($service['description']); ?></p>
                                
                                <div class="service-meta">
                                    <div class="meta-item">
                                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <line x1="12" y1="1" x2="12" y2="23"></line>
                                            <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
                                        </svg>
                                        <span><?php echo esc_html($currency_symbol . $price_display); ?></span>
                                    </div>
                                    <div class="meta-item">
                                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <circle cx="12" cy="12" r="10"></circle>
                                            <polyline points="12 6 12 12 16 14"></polyline>
                                        </svg>
                                        <span><?php echo esc_html($service['duration']); ?></span>
                                    </div>
                                    <?php if (isset($service['rating']) && $service['rating'] > 0) : ?>
                                    <div class="meta-item">
                                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"></path>
                                        </svg>
                                        <span><?php echo number_format($service['rating'], 1); ?></span>
                                    </div>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="service-stats">
                                    <div class="stat-item">
                                        <span class="stat-value"><?php echo isset($service['requests']) ? intval($service['requests']) : 0; ?></span>
                                        <span class="stat-label">Requests</span>
                                    </div>
                                    <div class="stat-item">
                                        <span class="stat-value"><?php echo esc_html(isset($service['category']) ? $service['category'] : 'General'); ?></span>
                                        <span class="stat-label">Category</span>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="service-actions">
                                <button class="btn btn-outline btn-sm edit-service-btn" data-service-id="<?php echo $service['id']; ?>">
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                                        <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                                    </svg>
                                    Edit
                                </button>
                                <button class="btn btn-outline btn-sm delete-service-btn" data-service-id="<?php echo $service['id']; ?>">
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <polyline points="3 6 5 6 21 6"></polyline>
                                        <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                                    </svg>
                                    Delete
                                </button>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>
        </section>
        <?php endif; ?>

        <!-- Service Modal -->
        <div id="serviceModal" class="request-modal-overlay" style="display: none;">
            <div class="request-modal" style="max-width: 600px;">
                <div class="request-modal-header">
                    <h2 class="request-modal-title" id="serviceModalTitle">Add Service</h2>
                    <button class="request-modal-close" id="closeServiceModal">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <line x1="18" y1="6" x2="6" y2="18"></line>
                            <line x1="6" y1="6" x2="18" y2="18"></line>
                        </svg>
                    </button>
                </div>
                <div class="request-modal-body">
                    <form id="serviceForm">
                        <input type="hidden" id="serviceId" name="service_id" value="">
                        
                        <div class="form-group" style="margin-bottom: 1.5rem;">
                            <label class="form-label" for="serviceTitle">Service Title *</label>
                            <input type="text" id="serviceTitle" name="title" class="form-input" required placeholder="e.g., Car Maintenance & Oil Change">
                        </div>
                        
                        <div class="form-group" style="margin-bottom: 1.5rem;">
                            <label class="form-label" for="serviceDescription">Description *</label>
                            <textarea id="serviceDescription" name="description" class="form-input" rows="4" required placeholder="Describe your service in detail..."></textarea>
                        </div>
                        
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-bottom: 1.5rem;">
                            <div class="form-group">
                                <label class="form-label" for="servicePrice">Price *</label>
                                <input type="number" id="servicePrice" name="price" class="form-input" step="0.01" min="0" required placeholder="0.00">
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label" for="serviceCurrency">Currency *</label>
                                <select id="serviceCurrency" name="price_currency" class="form-input" required>
                                    <option value="EUR">EUR (€)</option>
                                    <option value="HUF">HUF</option>
                                    <option value="USD">USD ($)</option>
                                </select>
                            </div>
                        </div>
                        
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-bottom: 1.5rem;">
                            <div class="form-group">
                                <label class="form-label" for="serviceDuration">Duration *</label>
                                <input type="text" id="serviceDuration" name="duration" class="form-input" required placeholder="e.g., 1-2 hours">
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label" for="serviceCategory">Category *</label>
                                <select id="serviceCategory" name="category" class="form-input" required>
                                    <option value="">Select Category</option>
                                    <option value="Maintenance">Maintenance</option>
                                    <option value="Repair">Repair</option>
                                    <option value="Inspection">Inspection</option>
                                    <option value="Diagnostic">Diagnostic</option>
                                    <option value="Tire Service">Tire Service</option>
                                    <option value="Battery Service">Battery Service</option>
                                    <option value="Other">Other</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="form-group" style="margin-bottom: 1.5rem;">
                            <label class="form-label" for="serviceStatus">Status *</label>
                            <select id="serviceStatus" name="status" class="form-input" required>
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                            </select>
                        </div>
                        
                        <div class="request-modal-actions" style="display: flex; gap: 1rem; justify-content: flex-end; margin-top: 2rem;">
                            <button type="button" class="btn btn-outline" id="cancelServiceBtn">Cancel</button>
                            <button type="submit" class="btn btn-primary" id="saveServiceBtn">Save Service</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>


        <!-- Messaging Section -->
        <section id="messagingSection" class="dashboard-section">
            <div class="section-header">
                <h1>Messaging</h1>
            </div>
            <div class="messaging-container">
                <!-- Conversation List (Left Panel) -->
                <div class="conversations-panel">
                    <div class="conversations-header">
                        <h2>Conversations</h2>
                        <input type="text" placeholder="Search conversations..." class="search-input" id="conversationSearch">
                    </div>
                    <div class="conversations-list" id="conversationsList">
                        <div class="conversations-loading" id="conversationsLoading" style="text-align: center; padding: 2rem;">
                            <p>Loading conversations...</p>
                        </div>
                        <div class="empty-state" id="conversationsEmpty" style="display: none;">
                            <div class="empty-state-icon">
                                <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M21 15C21 15.5304 20.7893 16.0391 20.4142 16.4142C20.0391 16.7893 19.5304 17 19 17H7L3 21V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H19C19.5304 3 20.0391 3.21071 20.4142 3.58579C20.7893 3.96086 21 4.46957 21 5V15Z"></path>
                                </svg>
                            </div>
                            <h3 class="empty-state-title">No Conversations</h3>
                            <p class="empty-state-text">Start a conversation with a customer after accepting their request.</p>
                        </div>
                    </div>
                </div>
                
                <!-- Chat Window (Right Panel) -->
                <div class="chat-panel" id="chatPanel" style="display: none;">
                    <div class="chat-header">
                        <div class="chat-partner-info">
                            <div class="chat-partner-avatar" id="chatPartnerAvatar"></div>
                            <div>
                                <h3 class="chat-partner-name" id="chatPartnerName"></h3>
                                <span class="chat-status status-active" id="chatStatus">Online</span>
                            </div>
                        </div>
                    </div>
                    <div class="chat-messages" id="chatMessages" role="log" aria-live="polite" aria-relevant="additions" aria-label="Chat messages" tabindex="-1">
                        <div class="messages-loading" id="messagesLoading" style="text-align: center; padding: 2rem;" role="status" aria-live="polite">
                            <p>Loading messages...</p>
                        </div>
                    </div>
                    <!-- Screen reader status announcements -->
                    <div id="chatStatusAnnouncements" class="sr-only" role="status" aria-live="polite" aria-atomic="true"></div>
                    <!-- Reply Preview Bar -->
                    <div id="replyPreviewBar" class="reply-preview-bar" style="display: none;" role="region" aria-label="Reply preview">
                        <div class="reply-preview-content">
                            <div class="reply-preview-info">
                                <span class="reply-preview-label">Replying to</span>
                                <span class="reply-preview-name" id="replyPreviewName"></span>
                            </div>
                            <div class="reply-preview-text" id="replyPreviewText"></div>
                        </div>
                        <button type="button" id="cancelReplyBtn" class="reply-preview-close" aria-label="Cancel reply" title="Cancel reply">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <line x1="18" y1="6" x2="6" y2="18"></line>
                                <line x1="6" y1="6" x2="18" y2="18"></line>
                            </svg>
                        </button>
                        <input type="hidden" id="replyToMessageId" value="">
                    </div>
                    <div class="chat-composer">
                        <form id="messageForm" aria-label="Send a message">
                            <input type="hidden" id="currentThreadId" value="">
                            <div class="composer-attachments" id="composerAttachments" style="display: none;" role="region" aria-label="Attachments"></div>
                            <div class="composer-input-wrapper">
                                <button type="button" class="btn-icon attachment-btn" id="attachmentBtn" aria-label="Attach file" title="Attach File">
                                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                                        <path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"></path>
                                    </svg>
                                    <span class="sr-only">Attach file</span>
                                </button>
                                <input type="file" id="fileInput" style="display: none;" accept="image/*,.pdf,.doc,.docx,.zip" multiple aria-label="File input">
                                <label for="messageInput" class="sr-only">Type a message</label>
                                <textarea id="messageInput" class="composer-input" placeholder="Type your message..." rows="1" aria-label="Type a message" aria-describedby="messageInputHint"></textarea>
                                <span id="messageInputHint" class="sr-only">Press Enter to send, Shift+Enter for new line</span>
                                <button type="submit" class="btn-icon send-btn" id="sendBtn" aria-label="Send message" title="Send">
                                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                                        <line x1="22" y1="2" x2="11" y2="13"></line>
                                        <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
                                    </svg>
                                    <span class="sr-only">Send message</span>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
                
                <!-- No Chat Selected State -->
                <div class="chat-placeholder" id="chatPlaceholder">
                    <div class="placeholder-content">
                        <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M21 15C21 15.5304 20.7893 16.0391 20.4142 16.4142C20.0391 16.7893 19.5304 17 19 17H7L3 21V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H19C19.5304 3 20.0391 3.21071 20.4142 3.58579C20.7893 3.96086 21 4.46957 21 5V15Z"></path>
                        </svg>
                        <h3>Select a conversation</h3>
                        <p>Choose a conversation from the list to start messaging</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- Requests Section -->
        <section id="requestsSection" class="dashboard-section">
            <div class="section-header">
                <h1>Requests</h1>
                <div class="header-actions">
                    <div class="request-tabs" id="requestTabs">
                        <button class="tab-btn active" data-filter="all">All</button>
                        <button class="tab-btn" data-filter="pending">Pending</button>
                        <button class="tab-btn" data-filter="in_progress">In Progress</button>
                        <button class="tab-btn" data-filter="complete">Complete</button>
                    </div>
                </div>
            </div>
            <div class="profile-content">
                <div id="requestsList" class="requests-list">
                    <div class="requests-loading" id="requestsLoading" style="text-align: center; padding: 2rem;">
                        <p>Loading requests...</p>
                    </div>
                    <div class="empty-state" id="requestsEmpty" style="display: none;">
                        <div class="empty-state-icon">
                            <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M9 12h6m-3-3v6m-9 1V7a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                            </svg>
                        </div>
                        <h3 class="empty-state-title">No Requests Yet</h3>
                        <p class="empty-state-text">When customers submit requests, they will appear here.</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- Request Details Modal -->
        <div id="requestModal" class="request-modal-overlay">
            <div class="request-modal">
                <div class="request-modal-header">
                    <h2 class="request-modal-title">Request Details</h2>
                    <button class="request-modal-close" id="closeRequestModal">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <line x1="18" y1="6" x2="6" y2="18"></line>
                            <line x1="6" y1="6" x2="18" y2="18"></line>
                        </svg>
                    </button>
                </div>
                <div class="request-modal-body" id="requestModalBody">
                    <!-- Content will be populated dynamically -->
                </div>
            </div>
        </div>

        <!-- Reviews Section -->
        <section id="reviewsSection" class="dashboard-section">
            <div class="section-header">
                <h1>Customer Reviews</h1>
                <div class="header-actions">
                    <select class="filter-select" id="filterReviews">
                        <option value="all"><?php _e('All Reviews', 'wheelfy'); ?></option>
                        <option value="5"><?php _e('5 Stars', 'wheelfy'); ?></option>
                        <option value="4"><?php _e('4 Stars', 'wheelfy'); ?></option>
                        <option value="3"><?php _e('3 Stars', 'wheelfy'); ?></option>
                        <option value="2"><?php _e('2 Stars', 'wheelfy'); ?></option>
                        <option value="1"><?php _e('1 Star', 'wheelfy'); ?></option>
                    </select>
                    <input type="search" class="search-input" placeholder="<?php esc_attr_e('Search reviews...', 'wheelfy'); ?>" id="searchReviews">
                </div>
                                        </div>
            <div class="profile-content">
                <?php
                // Get real partner reviews (only approved/published reviews)
                $partner_reviews = wheelfy_get_partner_reviews($viewing_user_id);
                
                // Filter to show only approved/published reviews
                $approved_reviews = array_filter($partner_reviews, function($review) {
                    $status = isset($review['status']) ? $review['status'] : 'pending';
                    return $status === 'published' || $status === 'approved';
                });
                $approved_reviews = array_values($approved_reviews);
                
                // Sort by date (newest first)
                usort($approved_reviews, function($a, $b) {
                    $date_a = isset($a['created_timestamp']) ? $a['created_timestamp'] : (isset($a['created_at']) ? strtotime($a['created_at']) : 0);
                    $date_b = isset($b['created_timestamp']) ? $b['created_timestamp'] : (isset($b['created_at']) ? strtotime($b['created_at']) : 0);
                    return $date_b - $date_a;
                });
                
                // Calculate statistics
                $total_reviews_count = count($approved_reviews);
                $avg_rating = 0;
                $five_star_count = 0;
                if ($total_reviews_count > 0) {
                    $total_rating_sum = array_sum(array_column($approved_reviews, 'rating'));
                    $avg_rating = $total_rating_sum / $total_reviews_count;
                    $five_star_count = count(array_filter($approved_reviews, function($r) { 
                        return isset($r['rating']) && intval($r['rating']) === 5; 
                    }));
                }
                
                // Update partner statistics (for display in sidebar)
                $total_reviews = $total_reviews_count;
                ?>
                
                <!-- Reviews Summary -->
                <div class="reviews-summary">
                    <div class="summary-card">
                        <div class="summary-value"><?php echo number_format($total_reviews_count); ?></div>
                        <div class="summary-label"><?php _e('Total Reviews', 'wheelfy'); ?></div>
                    </div>
                    <div class="summary-card">
                        <div class="summary-value"><?php echo number_format($avg_rating, 1); ?></div>
                        <div class="summary-label"><?php _e('Average Rating', 'wheelfy'); ?></div>
                    </div>
                    <div class="summary-card">
                        <div class="summary-value"><?php echo number_format($five_star_count); ?></div>
                        <div class="summary-label"><?php _e('5 Star Reviews', 'wheelfy'); ?></div>
                    </div>
                </div>

                <!-- Reviews List -->
                <div class="reviews-list" id="partnerReviewsList">
                    <?php if (!empty($approved_reviews)) : ?>
                        <?php foreach ($approved_reviews as $review) : 
                            $customer_name = isset($review['customer_name']) ? $review['customer_name'] : 'Customer';
                            $rating = isset($review['rating']) ? intval($review['rating']) : 0;
                            $review_text = isset($review['review_text']) ? $review['review_text'] : '';
                            $created_at = isset($review['created_at']) ? $review['created_at'] : '';
                            $created_timestamp = isset($review['created_timestamp']) ? $review['created_timestamp'] : strtotime($created_at);
                            
                            // Format date
                            if ($created_timestamp) {
                                $time_diff = current_time('timestamp') - $created_timestamp;
                                if ($time_diff < 3600) {
                                    $date_display = floor($time_diff / 60) . ' minutes ago';
                                } elseif ($time_diff < 86400) {
                                    $date_display = floor($time_diff / 3600) . ' hours ago';
                                } elseif ($time_diff < 604800) {
                                    $date_display = floor($time_diff / 86400) . ' days ago';
                                } elseif ($time_diff < 2592000) {
                                    $date_display = floor($time_diff / 604800) . ' weeks ago';
                                } else {
                                    $date_display = floor($time_diff / 2592000) . ' months ago';
                                }
                            } else {
                                $date_display = 'Recently';
                            }
                            
                            $customer_initial = strtoupper(substr($customer_name, 0, 1));
                        ?>
                            <div class="review-card" data-rating="<?php echo $rating; ?>" data-customer-name="<?php echo esc_attr(strtolower($customer_name)); ?>" data-review-text="<?php echo esc_attr(strtolower($review_text)); ?>" data-review-id="<?php echo isset($review['id']) ? esc_attr($review['id']) : esc_attr(md5($customer_name . $created_timestamp)); ?>">
                                <div class="review-header">
                                    <div class="review-customer">
                                        <div class="customer-avatar">
                                            <?php echo esc_html($customer_initial); ?>
                                        </div>
                                        <div class="customer-info">
                                            <h4 class="customer-name">
                                                <?php echo esc_html($customer_name); ?>
                                            </h4>
                                        </div>
                                    </div>
                                    <div class="review-rating">
                                        <?php
                                        for ($i = 1; $i <= 5; $i++) :
                                            $is_filled = $i <= $rating;
                                        ?>
                                            <svg width="20" height="20" viewBox="0 0 24 24" fill="<?php echo $is_filled ? 'currentColor' : 'none'; ?>" stroke="currentColor" stroke-width="2" class="star <?php echo $is_filled ? 'star-filled' : 'star-empty'; ?>">
                                                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
                                            </svg>
                                        <?php endfor; ?>
                                    </div>
                                </div>
                                <div class="review-content">
                                    <p class="review-text"><?php echo esc_html($review_text); ?></p>
                                    <div class="review-footer">
                                        <span class="review-date"><?php echo esc_html($date_display); ?></span>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else : ?>
                        <div class="empty-state" style="text-align: center; padding: 3rem;">
                            <div class="empty-state-icon" style="margin-bottom: 1rem;">
                                <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"></path>
                                </svg>
                            </div>
                            <h3 class="empty-state-title"><?php _e('No Reviews Yet', 'wheelfy'); ?></h3>
                            <p class="empty-state-text"><?php _e('You haven\'t received any approved reviews yet.', 'wheelfy'); ?></p>
                        </div>
                    <?php endif; ?>
                </div>
        </section>

        <!-- Analytics Section -->
        <?php if (!$is_car_dealership) : ?>
        <section id="analyticsSection" class="dashboard-section">
            <div class="section-header">
                <h1>Analytics & Insights</h1>
                                    </div>
            <div class="profile-content">
                <div class="profile-card">
                    <div class="card-header">
                        <h3>Performance Overview</h3>
                                    </div>
                    <div class="card-body">
                        <div class="stats-grid">
                            <div class="stat-card stat-card-primary">
                                <div class="stat-icon">
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M13 7L18 12L13 17M6 17V7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                                    </svg>
                                    </div>
                                <div class="stat-content">
                                    <h4 class="stat-value"><?php echo esc_html( $response_rate ); ?>%</h4>
                                    <p class="stat-label">Response Rate</p>
                                    </div>
                                    </div>
                            <div class="stat-card stat-card-info">
                                <div class="stat-icon">
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                                    </svg>
                                    </div>
                                <div class="stat-content">
                                    <h4 class="stat-value"><?php echo esc_html( $completed_jobs ); ?></h4>
                                    <p class="stat-label">Completed Jobs</p>
                                </div>
                                </div>
                            <div class="stat-card stat-card-info">
                                <div class="stat-icon">
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z" fill="currentColor"></path>
                                    </svg>
                            </div>
                                <div class="stat-content">
                                    <h4 class="stat-value"><?php echo esc_html( $total_reviews ); ?></h4>
                                    <p class="stat-label">Total Reviews</p>
                        </div>
                            </div>
                            <div class="stat-card stat-card-info">
                                <div class="stat-icon">
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                                    </svg>
                                </div>
                                <div class="stat-content">
                                    <h4 class="stat-value">$<?php echo number_format( $total_revenue, 0 ); ?></h4>
                                    <p class="stat-label">Total Revenue</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <?php endif; ?>

        <!-- Notifications Section -->
        <section id="notificationsSection" class="dashboard-section">
            <div class="section-header">
                <h1>Notifications</h1>
                <button class="edit-btn btn-sm" id="markAllReadBtn" style="display: none;">
                    Mark all as read
                </button>
            </div>
            <div class="profile-content">
                <?php if (($current_plan_slug === 'basic' || empty($current_subscription)) && !$is_car_dealership) : ?>
                <div class="profile-card">
                    <div class="card-body">
                        <div class="activity-item activity-item-upgrade">
                            <div class="activity-icon activity-icon-upgrade">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M12 2L2 7l10 5 10-5-10-5z"></path>
                                    <path d="M2 17l10 5 10-5M2 12l10 5 10-5"></path>
                                </svg>
                            </div>
                            <div class="activity-content">
                                <p class="activity-text"><strong><?php _e('Upgrade Your Plan', 'wheelfy'); ?></strong></p>
                                <p class="activity-description"><?php _e('You\'re on the Free Plan. Upgrade to unlock premium features and grow your business faster!', 'wheelfy'); ?></p>
                                <div class="activity-actions">
                                    <a href="#subscription-plans" class="btn btn-primary btn-sm nav-link" data-section="subscription-plans"><?php _e('View Plans', 'wheelfy'); ?></a>
                                </div>
                                <span class="activity-time"><?php _e('Reminder', 'wheelfy'); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                <div class="profile-card">
                    <div class="card-body">
                        <div class="activity-timeline" id="notificationsList">
                            <div class="empty-state" id="notificationsEmpty" style="display: none;">
                                <div class="empty-state-icon">
                                    <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path>
                                        <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
                                    </svg>
                                </div>
                                <h3 class="empty-state-title">No Notifications</h3>
                                <p class="empty-state-text">You're all caught up! No new notifications.</p>
                            </div>
                            <div class="notifications-loading" id="notificationsLoading" style="text-align: center; padding: 2rem;">
                                <p>Loading notifications...</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Subscription Plans Section -->
        <?php if (!$is_car_dealership) : ?>
        <section id="subscriptionPlansSection" class="dashboard-section">
            <div class="section-header">
                <h1><?php _e('Subscription Plans', 'wheelfy'); ?></h1>
                <p class="section-description"><?php _e('Choose the plan that best fits your business needs', 'wheelfy'); ?></p>
            </div>
            <div class="profile-content">
                <div class="subscription-plans-grid">
                    <?php 
                    // Ensure plans exist (database function returns array of objects)
                    if (empty($subscription_plans)) {
                        echo '<p class="no-plans-message" style="text-align: center; color: hsl(var(--muted-foreground)); padding: 2rem;">' . __('No subscription plans available at the moment. Please check back later.', 'wheelfy') . '</p>';
                    } else {
                    
                    foreach ($subscription_plans as $plan) : 
                        // Database returns objects, not arrays
                        $is_current_plan = ($plan->id == $current_plan_id);
                        $plan_price = floatval($plan->price);
                        $plan_currency = $plan->currency ?: 'HUF';
                        
                        // Get features from features_list (database stores as JSON decoded array)
                        $features_display = array();
                        if (!empty($plan->features_list) && is_array($plan->features_list)) {
                            foreach ($plan->features_list as $feature) {
                                if (is_array($feature) && isset($feature['text'])) {
                                    $features_display[] = $feature;
                                } elseif (is_string($feature) && !empty(trim($feature))) {
                                    $features_display[] = array('text' => trim($feature), 'icon' => 'check');
                                }
                            }
                        }
                        
                        // Fallback features if none provided
                        if (empty($features_display)) {
                            $features_display = array(
                                array('text' => __('Basic features', 'wheelfy'), 'icon' => 'check'),
                                array('text' => __('Standard support', 'wheelfy'), 'icon' => 'check')
                            );
                        }
                        
                        // Get plan details from database object
                        $plan_id = $plan->id;
                        $plan_name_text = $plan->plan_name ?: __('Plan', 'wheelfy');
                        $is_popular = $plan->is_popular;
                        
                        // Format price based on currency
                        $currency_symbol = ($plan_currency === 'HUF') ? 'HUF' : '€';
                        $price_display = ($plan_currency === 'HUF') ? number_format($plan_price, 0, ',', ' ') : number_format($plan_price, 2);
                    ?>
                        <div class="subscription-plan-card <?php echo $is_current_plan ? 'current-plan' : ''; ?> <?php echo $is_popular ? 'popular-plan' : ''; ?>">
                            <?php if ($is_popular) : ?>
                                <div class="plan-badge-popular"><?php _e('MOST POPULAR', 'wheelfy'); ?></div>
                            <?php endif; ?>
                            
                            <div class="plan-header">
                                <h3 class="plan-name"><?php echo esc_html($plan_name_text); ?></h3>
                                <?php if ($is_current_plan) : ?>
                                    <span class="current-plan-badge"><?php _e('Current Plan', 'wheelfy'); ?></span>
                                <?php endif; ?>
                            </div>
                            
                            <div class="plan-price">
                                <?php if ($plan_price == 0) : ?>
                                    <span class="price-amount"><?php _e('Free', 'wheelfy'); ?></span>
                                <?php else : ?>
                                    <span class="price-amount"><?php echo esc_html($price_display); ?></span>
                                    <span class="price-currency"> <?php echo esc_html($currency_symbol); ?></span>
                                    <span class="price-period">/<?php echo esc_html($plan->billing_cycle ?: 'month'); ?></span>
                                <?php endif; ?>
                            </div>
                            
                            <?php if ($plan->commission_rate > 0 || !empty($plan->bidding_restriction_label)) : ?>
                            <div class="plan-meta" style="padding: 0.75rem 0; margin-bottom: 0.75rem; border-bottom: 1px solid hsl(var(--border));">
                                <?php if ($plan->commission_rate > 0) : ?>
                                    <div style="font-size: 0.8125rem; color: hsl(var(--muted-foreground)); margin-bottom: 0.25rem;">
                                        <strong><?php _e('Commission:', 'wheelfy'); ?></strong> <?php echo esc_html($plan->commission_rate); ?>%
                                    </div>
                                <?php elseif (!$plan->has_commission) : ?>
                                    <div style="font-size: 0.8125rem; color: hsl(var(--primary)); margin-bottom: 0.25rem;">
                                        <strong><?php _e('Commission:', 'wheelfy'); ?></strong> <?php _e('Included', 'wheelfy'); ?>
                                    </div>
                                <?php endif; ?>
                                <?php if (!empty($plan->bidding_restriction_label)) : ?>
                                    <div style="font-size: 0.8125rem; color: hsl(var(--muted-foreground));">
                                        <?php echo esc_html($plan->bidding_restriction_label); ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <?php endif; ?>
                            
                            <div class="plan-features">
                                <ul class="features-list">
                                    <?php foreach ($features_display as $feature) : 
                                        $feature_text = is_array($feature) ? ($feature['text'] ?? '') : $feature;
                                        $feature_icon = is_array($feature) ? ($feature['icon'] ?? 'check') : 'check';
                                        if (empty(trim($feature_text))) continue;
                                    ?>
                                        <li class="<?php echo $feature_icon === 'cross' ? 'feature-unavailable' : ''; ?>">
                                            <?php if ($feature_icon === 'cross') : ?>
                                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="hsl(var(--destructive))" stroke-width="2">
                                                    <line x1="18" y1="6" x2="6" y2="18"></line>
                                                    <line x1="6" y1="6" x2="18" y2="18"></line>
                                                </svg>
                                            <?php else : ?>
                                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                                    <polyline points="20 6 9 17 4 12"></polyline>
                                                </svg>
                                            <?php endif; ?>
                                            <?php echo esc_html(trim($feature_text)); ?>
                                        </li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                            
                            <div class="plan-action">
                                <?php if ($is_current_plan) : ?>
                                    <button class="btn btn-outline" disabled>
                                        <?php _e('Current Plan', 'wheelfy'); ?>
                                    </button>
                                <?php else : ?>
                                    <button class="btn btn-primary upgrade-plan-btn" data-plan-id="<?php echo esc_attr($plan_id); ?>" data-plan-price="<?php echo esc_attr($plan_price); ?>" data-plan-name="<?php echo esc_attr($plan_name_text); ?>">
                                        <?php echo $plan_price > 0 ? __('Upgrade Now', 'wheelfy') : __('Select Plan', 'wheelfy'); ?>
                                    </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; 
                    } // end if plans exist ?>
                </div>
            </div>
        </section>
        <?php endif; ?>

        <!-- Settings Section -->
        <section id="settingsSection" class="dashboard-section">
            <div class="section-header">
                <h1>Settings</h1>
                                </div>
            <div class="settings-content">
                <div class="profile-card">
                    <div class="card-header">
                        <h3>Notification Preferences</h3>
                                </div>
                    <div class="card-body">
                        <div class="settings-item">
                            <div class="settings-label">
                                <label>Email Notifications</label>
                                <p class="settings-description">Receive important notifications via email</p>
                            </div>
                            <label class="toggle-switch">
                                <?php 
                                $email_notifications_enabled = get_user_meta($viewing_user_id, 'email_notifications_enabled', true);
                                $email_notifications_checked = ($email_notifications_enabled === '' || $email_notifications_enabled === '1') ? 'checked' : '';
                                ?>
                                <input type="checkbox" id="emailNotificationsToggle" <?php echo $email_notifications_checked; ?>>
                                <span class="toggle-slider"></span>
                            </label>
                        </div>
                        <div class="settings-item">
                            <div class="settings-label">
                                <label>Message Notifications</label>
                                <p class="settings-description">Receive alerts when you receive new messages</p>
                        </div>
                            <label class="toggle-switch">
                                <?php 
                                $message_notifications_enabled = get_user_meta($viewing_user_id, 'message_notifications_enabled', true);
                                $message_notifications_checked = ($message_notifications_enabled === '' || $message_notifications_enabled === '1') ? 'checked' : '';
                                ?>
                                <input type="checkbox" id="messageNotificationsToggle" <?php echo $message_notifications_checked; ?>>
                                <span class="toggle-slider"></span>
                                </label>
                        </div>
                        <div class="settings-item">
                            <div class="settings-label">
                                <label>Review Notifications</label>
                                <p class="settings-description">Receive notifications when you receive new reviews</p>
                            </div>
                            <label class="toggle-switch">
                                <?php 
                                $review_notifications_enabled = get_user_meta($viewing_user_id, 'review_notifications_enabled', true);
                                $review_notifications_checked = ($review_notifications_enabled === '' || $review_notifications_enabled === '1') ? 'checked' : '';
                                ?>
                                <input type="checkbox" id="reviewNotificationsToggle" <?php echo $review_notifications_checked; ?>>
                                <span class="toggle-slider"></span>
                                </label>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        </div>
    </div>

<script>
// ============================================================================
// GLOBAL VARIABLES & CONFIGURATION
// ============================================================================
// Make AJAX variables available
var wheelfy = {
    ajaxUrl: '<?php echo esc_js( admin_url( 'admin-ajax.php' ) ); ?>',
    nonce: '<?php echo esc_js( wp_create_nonce( 'wheelfy_nonce' ) ); ?>',
    userId: '<?php echo esc_js( $viewing_user_id ); ?>'
};

// Global state variables (declared once at top level to prevent redeclaration errors)
var messagePollInterval = null;
var currentThreadId = null;
var attachmentIds = [];
var isPollingActive = false;
var searchTimeout = null;
var lastSearchTerm = '';
var lastSearchTimestamp = 0;
var searchInitialized = false; // Flag to prevent duplicate search listener registration

// ============================================================================
// CHAT SECURITY - Contact Information Blocking
// ============================================================================
<?php echo wheelfy_get_chat_validation_js(); ?>

// ============================================================================
// IMAGE MODAL FUNCTIONS (Global scope so they can be called from renderMessages)
// ============================================================================
function openImageModal(imageUrl, imageName) {
    const modal = document.getElementById('imageModal');
    const modalImg = document.getElementById('imageModalImg');
    const downloadBtn = document.getElementById('imageModalDownload');
    
    if (modal && modalImg) {
        modalImg.src = imageUrl;
        modalImg.alt = imageName || 'Image';
        modal.style.display = 'flex';
        document.body.style.overflow = 'hidden';
        
        // Set download attribute
        if (downloadBtn) {
            downloadBtn.onclick = function() {
                const link = document.createElement('a');
                link.href = imageUrl;
                link.download = imageName || 'image';
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            };
        }
    }
}

function closeImageModal() {
    const modal = document.getElementById('imageModal');
    if (modal) {
        modal.style.display = 'none';
        document.body.style.overflow = '';
    }
}

/**
 * Update Profile Completion Percentage
 * Calculates based on: Name, Business Name, Email, Phone, Location, Biography
 */
function updateProfileCompletion() {
    const totalFields = 6;
    let filledFields = 0;
    
    // Get values from display elements
    const nameValue = document.getElementById('nameValue');
    const businessNameValue = document.getElementById('businessNameValue');
    const emailValue = document.getElementById('emailValue');
    const phoneValue = document.getElementById('phoneValue');
    const locationValue = document.getElementById('locationValue');
    const bioText = document.getElementById('bioText');
    
    // Check each field
    if (nameValue && nameValue.textContent && nameValue.textContent !== 'Not added') filledFields++;
    if (businessNameValue && businessNameValue.textContent && businessNameValue.textContent !== 'Not added') filledFields++;
    if (emailValue && emailValue.textContent && emailValue.textContent !== 'Not added') filledFields++;
    if (phoneValue && phoneValue.textContent && phoneValue.textContent !== 'Not added') filledFields++;
    if (locationValue && locationValue.textContent && locationValue.textContent !== 'Not added') filledFields++;
    if (bioText && bioText.textContent && !bioText.textContent.includes('haven\'t added') && bioText.textContent !== 'Not added') filledFields++;
    
    // Calculate percentage
    const percentage = Math.round((filledFields / totalFields) * 100);
    
    // Update UI elements
    const completionPercentage = document.getElementById('completionPercentage');
    const completionFill = document.getElementById('completionFill');
    const completionCard = document.querySelector('.completion-card .card-body');
    
    if (completionPercentage) {
        completionPercentage.textContent = percentage + '%';
    }
    
    if (completionFill) {
        completionFill.style.width = percentage + '%';
    }
    
    // Update missing fields message
    if (completionCard) {
        const missingFields = [];
        if (!nameValue || !nameValue.textContent || nameValue.textContent === 'Not added') missingFields.push('Name');
        if (!businessNameValue || !businessNameValue.textContent || businessNameValue.textContent === 'Not added') missingFields.push('Business Name');
        if (!emailValue || !emailValue.textContent || emailValue.textContent === 'Not added') missingFields.push('Email');
        if (!phoneValue || !phoneValue.textContent || phoneValue.textContent === 'Not added') missingFields.push('Phone');
        if (!locationValue || !locationValue.textContent || locationValue.textContent === 'Not added') missingFields.push('Location');
        if (!bioText || !bioText.textContent || bioText.textContent.includes('haven\'t added') || bioText.textContent === 'Not added') missingFields.push('Biography');
        
        // Find or create completion text elements
        let completionTexts = completionCard.querySelectorAll('.completion-text');
        
        if (percentage >= 100) {
            // Clear all existing texts and show complete message
            completionTexts.forEach(el => el.remove());
            const completeMsg = document.createElement('p');
            completeMsg.className = 'completion-text';
            completeMsg.style.color = 'hsl(142 76% 36%)';
            completeMsg.textContent = '✓ Your profile is complete!';
            completionCard.querySelector('.completion-bar').after(completeMsg);
        } else {
            // Update or create missing fields message
            if (completionTexts.length >= 2) {
                completionTexts[1].innerHTML = '<strong>Missing:</strong> ' + missingFields.join(', ');
            } else if (completionTexts.length === 1) {
                const missingMsg = document.createElement('p');
                missingMsg.className = 'completion-text';
                missingMsg.style.fontSize = '0.8rem';
                missingMsg.style.color = 'hsl(var(--muted-foreground))';
                missingMsg.innerHTML = '<strong>Missing:</strong> ' + missingFields.join(', ');
                completionTexts[0].after(missingMsg);
            }
        }
    }
}

document.addEventListener('DOMContentLoaded', function() {
    // Recent Activity Load More functionality
    const loadMoreActivitiesBtn = document.getElementById('loadMoreActivities');
    if (loadMoreActivitiesBtn) {
        loadMoreActivitiesBtn.addEventListener('click', function() {
            const total = parseInt(this.getAttribute('data-total'));
            const perPage = parseInt(this.getAttribute('data-per-page'));
            let showing = parseInt(this.getAttribute('data-showing'));
            
            // Show next batch
            const newShowing = Math.min(showing + perPage, total);
            
            // Show hidden items
            const activityList = document.getElementById('recentActivityList');
            if (activityList) {
                const items = activityList.querySelectorAll('.activity-summary-item');
                items.forEach((item, index) => {
                    if (index < newShowing) {
                        item.classList.remove('activity-hidden');
                    }
                });
            }
            
            // Update button
            this.setAttribute('data-showing', newShowing);
            const remaining = total - newShowing;
            
            if (remaining > 0) {
                this.innerHTML = `<span style="display: flex; align-items: center; justify-content: center; gap: 0.5rem;">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <polyline points="6 9 12 15 18 9"></polyline>
                    </svg>
                    Load More (${remaining} remaining)
                </span>`;
            } else {
                this.style.display = 'none';
            }
        });
    }
    
    // Message Notifications Toggle Handler
    const messageNotificationsToggle = document.getElementById('messageNotificationsToggle');
    if (messageNotificationsToggle) {
        messageNotificationsToggle.addEventListener('change', function() {
            const isEnabled = this.checked ? '1' : '0';
            
            // Disable toggle while saving
            this.disabled = true;
            
            const formData = new FormData();
            formData.append('action', 'update_message_notifications');
            formData.append('nonce', wheelfy.nonce);
            formData.append('enabled', isEnabled);
            
            fetch(wheelfy.ajaxUrl, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                this.disabled = false;
                if (data.success) {
                    // Optional: Show success message
                    console.log('Message notifications preference updated');
                } else {
                    // Revert toggle on error
                    this.checked = !this.checked;
                    alert(data.data && data.data.message ? data.data.message : 'Failed to update preference. Please try again.');
                }
            })
            .catch(error => {
                this.disabled = false;
                // Revert toggle on error
                this.checked = !this.checked;
                console.error('Error updating message notifications:', error);
                alert('An error occurred. Please try again.');
            });
        });
    }
    
    // Email Notifications Toggle Handler
    const emailNotificationsToggle = document.getElementById('emailNotificationsToggle');
    if (emailNotificationsToggle) {
        emailNotificationsToggle.addEventListener('change', function() {
            const isEnabled = this.checked ? '1' : '0';
            const originalState = !this.checked;
            
            this.disabled = true;
            
            const formData = new FormData();
            formData.append('action', 'update_email_notifications');
            formData.append('nonce', wheelfy.nonce);
            formData.append('enabled', isEnabled);
            
            fetch(wheelfy.ajaxUrl, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Successfully updated
                } else {
                    alert(data.data.message || 'Failed to update email notification preference.');
                    this.checked = originalState;
                }
            })
            .catch(error => {
                console.error('Error updating email notifications:', error);
                alert('An error occurred. Please try again.');
                this.checked = originalState;
            })
            .finally(() => {
                this.disabled = false;
            });
        });
    }
    
    // Review Notifications Toggle Handler
    const reviewNotificationsToggle = document.getElementById('reviewNotificationsToggle');
    if (reviewNotificationsToggle) {
        reviewNotificationsToggle.addEventListener('change', function() {
            const isEnabled = this.checked ? '1' : '0';
            const originalState = !this.checked; // Store original state for revert
            
            this.disabled = true; // Disable toggle during AJAX call
            
            const formData = new FormData();
            formData.append('action', 'update_review_notifications');
            formData.append('nonce', wheelfy.nonce);
            formData.append('enabled', isEnabled);
            
            fetch(wheelfy.ajaxUrl, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Successfully updated
                } else {
                    alert(data.data.message || 'Failed to update review notification preference.');
                    this.checked = originalState; // Revert on error
                }
            })
            .catch(error => {
                console.error('Error updating review notifications:', error);
                alert('An error occurred. Please try again.');
                this.checked = originalState; // Revert on error
            })
            .finally(() => {
                this.disabled = false; // Re-enable toggle
            });
        });
    }
    
    // ============================================================================
    // SERVICE MANAGEMENT HANDLERS
    // ============================================================================
    
    // Service Modal Elements
    const serviceModal = document.getElementById('serviceModal');
    const serviceModalTitle = document.getElementById('serviceModalTitle');
    const serviceForm = document.getElementById('serviceForm');
    const addServiceBtn = document.getElementById('addServiceBtn');
    const addServiceBtnEmpty = document.getElementById('addServiceBtnEmpty');
    const closeServiceModal = document.getElementById('closeServiceModal');
    const cancelServiceBtn = document.getElementById('cancelServiceBtn');
    
    // Open Service Modal (Add New)
    function openServiceModal(serviceData = null) {
        if (!serviceModal) return;
        
        // Reset form
        if (serviceForm) {
            serviceForm.reset();
            document.getElementById('serviceId').value = '';
        }
        
        if (serviceData) {
            // Edit mode
            if (serviceModalTitle) serviceModalTitle.textContent = 'Edit Service';
            if (document.getElementById('serviceId')) document.getElementById('serviceId').value = serviceData.id || '';
            if (document.getElementById('serviceTitle')) document.getElementById('serviceTitle').value = serviceData.title || '';
            if (document.getElementById('serviceDescription')) document.getElementById('serviceDescription').value = serviceData.description || '';
            if (document.getElementById('servicePrice')) document.getElementById('servicePrice').value = serviceData.price || '';
            if (document.getElementById('serviceCurrency')) document.getElementById('serviceCurrency').value = serviceData.price_currency || 'EUR';
            if (document.getElementById('serviceDuration')) document.getElementById('serviceDuration').value = serviceData.duration || '';
            if (document.getElementById('serviceCategory')) document.getElementById('serviceCategory').value = serviceData.category || '';
            if (document.getElementById('serviceStatus')) document.getElementById('serviceStatus').value = serviceData.status || 'active';
        } else {
            // Add mode
            if (serviceModalTitle) serviceModalTitle.textContent = 'Add Service';
        }
        
        serviceModal.style.display = 'flex';
        document.body.style.overflow = 'hidden';
    }
    
    // Close Service Modal
    function closeServiceModalFunc() {
        if (serviceModal) {
            serviceModal.style.display = 'none';
            document.body.style.overflow = '';
        }
    }
    
    // Event Listeners
    if (addServiceBtn) {
        addServiceBtn.addEventListener('click', () => openServiceModal());
    }
    
    if (addServiceBtnEmpty) {
        addServiceBtnEmpty.addEventListener('click', () => openServiceModal());
    }
    
    if (closeServiceModal) {
        closeServiceModal.addEventListener('click', closeServiceModalFunc);
    }
    
    if (cancelServiceBtn) {
        cancelServiceBtn.addEventListener('click', closeServiceModalFunc);
    }
    
    // Close modal on overlay click
    if (serviceModal) {
        serviceModal.addEventListener('click', function(e) {
            if (e.target === serviceModal) {
                closeServiceModalFunc();
            }
        });
    }
    
    // Edit Service Button Handlers
    document.addEventListener('click', function(e) {
        if (e.target.closest('.edit-service-btn')) {
            const btn = e.target.closest('.edit-service-btn');
            const serviceId = btn.getAttribute('data-service-id');
            
            if (!serviceId) return;
            
            // Fetch service data (we'll need to get it from the services list or make an AJAX call)
            // For now, we'll get it from the DOM
            const serviceCard = btn.closest('.service-card');
            if (serviceCard) {
                const serviceData = {
                    id: serviceId,
                    title: serviceCard.querySelector('.service-title')?.textContent?.trim() || '',
                    description: serviceCard.querySelector('.service-description')?.textContent?.trim() || '',
                    price: parseFloat(serviceCard.querySelector('.meta-item span')?.textContent?.replace(/[^\d.]/g, '') || '0'),
                    price_currency: serviceCard.querySelector('.meta-item span')?.textContent?.includes('HUF') ? 'HUF' : 'EUR',
                    duration: Array.from(serviceCard.querySelectorAll('.meta-item span')).find(el => el.textContent.includes('hour'))?.textContent?.trim() || '',
                    category: serviceCard.querySelector('.stat-value')?.textContent?.trim() || '',
                    status: serviceCard.querySelector('.service-status-badge')?.textContent?.trim().toLowerCase() || 'active'
                };
                
                openServiceModal(serviceData);
            }
        }
    });
    
    // Delete Service Button Handlers
    document.addEventListener('click', function(e) {
        if (e.target.closest('.delete-service-btn')) {
            const btn = e.target.closest('.delete-service-btn');
            const serviceId = btn.getAttribute('data-service-id');
            
            if (!serviceId) return;
            
            if (!confirm('Are you sure you want to delete this service? This action cannot be undone.')) {
                return;
            }
            
            btn.disabled = true;
            btn.textContent = 'Deleting...';
            
            const formData = new FormData();
            formData.append('action', 'delete_partner_service');
            formData.append('nonce', wheelfy.nonce);
            formData.append('service_id', serviceId);
            
            fetch(wheelfy.ajaxUrl, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Remove service card from DOM
                    const serviceCard = btn.closest('.service-card');
                    if (serviceCard) {
                        serviceCard.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
                        serviceCard.style.opacity = '0';
                        serviceCard.style.transform = 'translateX(-20px)';
                        setTimeout(() => {
                            serviceCard.remove();
                            
                            // Check if no services left
                            const servicesGrid = document.querySelector('.services-grid');
                            if (servicesGrid && servicesGrid.children.length === 0) {
                                location.reload(); // Reload to show empty state
                            }
                        }, 300);
                    }
                } else {
                    alert(data.data.message || 'Failed to delete service.');
                    btn.disabled = false;
                    btn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg> Delete';
                }
            })
            .catch(error => {
                console.error('Error deleting service:', error);
                alert('An error occurred. Please try again.');
                btn.disabled = false;
                btn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg> Delete';
            });
        }
    });
    
    // Save Service Form Handler
    if (serviceForm) {
        serviceForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const saveBtn = document.getElementById('saveServiceBtn');
            if (saveBtn) {
                saveBtn.disabled = true;
                saveBtn.textContent = 'Saving...';
            }
            
            const formData = new FormData(serviceForm);
            formData.append('action', 'save_partner_service');
            formData.append('nonce', wheelfy.nonce);
            
            fetch(wheelfy.ajaxUrl, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert(data.data.message || 'Service saved successfully!');
                    closeServiceModalFunc();
                    // Reload page to show updated services
                    location.reload();
                } else {
                    alert(data.data.message || 'Failed to save service.');
                    if (saveBtn) {
                        saveBtn.disabled = false;
                        saveBtn.textContent = 'Save Service';
                    }
                }
            })
            .catch(error => {
                console.error('Error saving service:', error);
                alert('An error occurred. Please try again.');
                if (saveBtn) {
                    saveBtn.disabled = false;
                    saveBtn.textContent = 'Save Service';
                }
            });
        });
    }
    
    const navItems = document.querySelectorAll('.nav-item[data-section]');
    const navLinks = document.querySelectorAll('.nav-link[data-section]');
    const sections = document.querySelectorAll('.dashboard-section');
    
    // Function to switch sections
    function switchSection(sectionName, clickedElement) {
    // Hide all sections
        sections.forEach(section => section.classList.remove('active'));
        
        // Remove active class from all nav items
        navItems.forEach(nav => nav.classList.remove('active'));
        
        // Show selected section
        let section = document.getElementById(sectionName + 'Section');
        // Handle special case for subscription-plans
        if (sectionName === 'subscription-plans') {
            section = document.getElementById('subscriptionPlansSection');
        }
        if (section) {
            section.classList.add('active');
            
            // If clicked element is a nav-item, add active class
            if (clickedElement && clickedElement.classList.contains('nav-item')) {
                clickedElement.classList.add('active');
            } else {
                // Find and activate corresponding nav-item
                const correspondingNavItem = document.querySelector(`.nav-item[data-section="${sectionName}"]`);
                if (correspondingNavItem) {
                    correspondingNavItem.classList.add('active');
                }
            }
            
            // Initialize messaging section when shown
            if (sectionName === 'messaging') {
                // Stop any existing polling
                if (typeof stopMessagePolling === 'function') {
                    stopMessagePolling();
                }
                // Load conversations (respect search state)
                if (typeof loadConversations === 'function') {
                    const searchInput = document.getElementById('conversationSearch');
                    const searchTerm = searchInput && searchInput.value.trim() ? searchInput.value.trim() : '';
                    loadConversations(searchTerm);
                }
                // Start real-time polling
                if (typeof startMessagePolling === 'function') {
                    startMessagePolling();
                }
                
                // Set up conversation search (only once to prevent duplicate listeners)
                if (!searchInitialized) {
                    const searchInput = document.getElementById('conversationSearch');
                    if (searchInput) {
                        // Real-time search with debouncing
                        searchInput.addEventListener('input', handleConversationSearch);
                        
                        // Clear search on Escape key
                        searchInput.addEventListener('keydown', function(e) {
                            if (e.key === 'Escape') {
                                this.value = '';
                                if (typeof loadConversations === 'function') {
                                    loadConversations('');
                                }
                            }
                            // Enter key opens first result (if any)
                            if (e.key === 'Enter') {
                                e.preventDefault();
                                const firstConversation = document.querySelector('.conversation-item');
                                if (firstConversation && typeof selectConversation === 'function') {
                                    const threadId = firstConversation.getAttribute('data-thread-id');
                                    const otherUserId = firstConversation.getAttribute('data-other-user-id');
                                    const otherUserName = firstConversation.querySelector('.conversation-name')?.textContent || '';
                                    const otherUserAvatar = firstConversation.querySelector('.conversation-avatar-image img')?.src || '';
                                    if (threadId) {
                                        selectConversation(threadId, otherUserId, otherUserName, otherUserAvatar);
                                    }
                                }
                            }
                        });
                        
                        // Accessibility: ARIA label
                        searchInput.addEventListener('focus', function() {
                            this.setAttribute('aria-label', 'Search conversations by customer name or email');
                        });
                        
                        searchInitialized = true; // Mark as initialized to prevent duplicate listeners
                    }
                }
            } else {
                // Stop polling when leaving messaging section
                if (typeof stopMessagePolling === 'function') {
                    stopMessagePolling();
                }
            }
            
            // Scroll to top of dashboard content
            const dashboardContent = document.querySelector('.dashboard-content');
            if (dashboardContent) {
                dashboardContent.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        }
    }
    
    // Navigation functionality for nav-items (with error handling)
    if (navItems && navItems.length > 0) {
        navItems.forEach(item => {
            try {
                item.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    const targetSection = this.getAttribute('data-section');
                    if (targetSection && typeof switchSection === 'function') {
                        switchSection(targetSection, this);
                    }
                });
            } catch (error) {
                console.error('Error setting up nav-item listener:', error);
            }
        });
    }
    
    // Navigation functionality for nav-links (like "View full profile →")
    if (navLinks && navLinks.length > 0) {
        navLinks.forEach(link => {
            try {
                link.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    const targetSection = this.getAttribute('data-section');
                    if (targetSection && typeof switchSection === 'function') {
                        switchSection(targetSection, this);
                    }
                });
            } catch (error) {
                console.error('Error setting up nav-link listener:', error);
            }
        });
    }

    // Profile Image Upload
    const editImageBtn = document.getElementById('editImageBtn');
    const profileImageInput = document.getElementById('profileImageInput');
    const imageUploadActions = document.getElementById('imageUploadActions');
    const saveImageBtn = document.getElementById('saveImageBtn');
    const cancelImageBtn = document.getElementById('cancelImageBtn');
    
    let originalImageState = null;
    let selectedFile = null;
    
    if (editImageBtn && profileImageInput) {
        // Store original state
        const profileImage = document.getElementById('profileImage');
        const profileInitials = document.getElementById('profileInitials');
        if (profileImage) {
            originalImageState = { type: 'image', src: profileImage.src };
        } else if (profileInitials) {
            originalImageState = { type: 'initials', text: profileInitials.textContent.trim() };
        }
        
        editImageBtn.addEventListener('click', function() {
            profileImageInput.click();
        });
        
        profileImageInput.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                selectedFile = file;
                // Preview image
                const reader = new FileReader();
                reader.onload = function(e) {
                    const profileImage = document.getElementById('profileImage');
                    const profileInitials = document.getElementById('profileInitials');
                    
                    if (profileImage) {
                        profileImage.src = e.target.result;
                    } else if (profileInitials) {
                        // Create img element if using initials
                        const img = document.createElement('img');
                        img.src = e.target.result;
                        img.alt = 'Profile';
                        img.className = 'profile-image';
                        img.id = 'profileImage';
                        profileInitials.parentNode.replaceChild(img, profileInitials);
                    }
                    
                    // Show save/cancel buttons
                    if (imageUploadActions) {
                        imageUploadActions.style.display = 'block';
                    }
                };
                reader.readAsDataURL(file);
            }
        });
        
        // Save image
        if (saveImageBtn) {
            saveImageBtn.addEventListener('click', function() {
                if (selectedFile) {
                    // Show loading state
                    saveImageBtn.disabled = true;
                    saveImageBtn.innerHTML = '<svg width="16" height="16" viewBox="0 0 20 20" fill="none"><path d="M10 2C5.58172 2 2 5.58172 2 10C2 14.4183 5.58172 18 10 18C14.4183 18 18 14.4183 18 10C18 5.58172 14.4183 2 10 2Z" stroke="currentColor" stroke-width="2"/><path d="M10 2V6C10 7.10457 10.8954 8 12 8H16" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg> Saving...';
                    
                    // Upload to server via AJAX
                    const formData = new FormData();
                    formData.append('action', 'upload_profile_image');
                    formData.append('file', selectedFile);
                    formData.append('nonce', wheelfy.nonce);
                    
                    fetch(wheelfy.ajaxUrl, {
                        method: 'POST',
                        body: formData
                    })
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Network response was not ok');
                        }
                        return response.json();
                    })
                    .then(data => {
                        if (data.success && data.data && data.data.url) {
                            // Update or create profile image element
                            const profileImageContainer = document.getElementById('profileImageContainer');
                            let profileImage = document.getElementById('profileImage');
                            const profileInitials = document.getElementById('profileInitials');
                            
                            // If initials exist, replace with image
                            if (profileInitials && !profileImage) {
                                profileInitials.remove();
                                profileImage = document.createElement('img');
                                profileImage.src = data.data.url;
                                profileImage.alt = 'Profile';
                                profileImage.className = 'profile-image';
                                profileImage.id = 'profileImage';
                                profileImageContainer.insertBefore(profileImage, editImageBtn);
                            } else if (profileImage) {
                                // Update existing image
                                profileImage.src = data.data.url;
                            }
                            
                            // Update original state
                            originalImageState = { type: 'image', src: data.data.url };
                            
                            // Hide buttons
                            if (imageUploadActions) {
                                imageUploadActions.style.display = 'none';
                            }
                            selectedFile = null;
                            profileImageInput.value = '';
                            
                            // Show success message briefly
                            const imageStatus = document.getElementById('imageStatus');
                            if (imageStatus) {
                                imageStatus.textContent = 'Image saved successfully!';
                                imageStatus.style.display = 'block';
                                imageStatus.style.color = '#10b981'; // Green color for success
                                imageStatus.style.backgroundColor = 'rgba(16, 185, 129, 0.1)';
                                setTimeout(() => {
                                    imageStatus.style.display = 'none';
                                }, 3000);
                            }
                        } else {
                            // Show error message
                            const errorMsg = data.data && data.data.message ? data.data.message : 'Failed to upload image. Please try again.';
                            const imageStatus = document.getElementById('imageStatus');
                            if (imageStatus) {
                                imageStatus.textContent = errorMsg;
                                imageStatus.style.display = 'block';
                                imageStatus.style.color = 'hsl(var(--destructive))';
                                imageStatus.style.backgroundColor = 'rgba(239, 68, 68, 0.1)';
                            }
                            
                            // Revert to original state
                            if (originalImageState) {
                                if (originalImageState.type === 'image') {
                                    const profileImage = document.getElementById('profileImage');
                                    if (profileImage) {
                                        profileImage.src = originalImageState.src;
                                    }
                                } else if (originalImageState.type === 'initials') {
                                    const profileImage = document.getElementById('profileImage');
                                    const profileInitials = document.getElementById('profileInitials');
                                    if (profileImage && !profileInitials) {
                                        const initialsDiv = document.createElement('div');
                                        initialsDiv.className = 'profile-initials';
                                        initialsDiv.id = 'profileInitials';
                                        profileImage.parentNode.replaceChild(initialsDiv, profileImage);
                                    }
                                }
                            }
                        }
                        saveImageBtn.disabled = false;
                        saveImageBtn.innerHTML = '<svg width="16" height="16" viewBox="0 0 20 20" fill="none"><path d="M16.7071 5.29289C17.0976 5.68342 17.0976 6.31658 16.7071 6.70711L8.70711 14.7071C8.31658 15.0976 7.68342 15.0976 7.29289 14.7071L3.29289 10.7071C2.90237 10.3166 2.90237 9.68342 3.29289 9.29289C3.68342 8.90237 4.31658 8.90237 4.70711 9.29289L8 12.5858L15.2929 5.29289C15.6834 4.90237 16.3166 4.90237 16.7071 5.29289Z" fill="currentColor"></path></svg> Save';
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        const imageStatus = document.getElementById('imageStatus');
                        if (imageStatus) {
                            imageStatus.textContent = 'Network error. Please check your connection and try again.';
                            imageStatus.style.display = 'block';
                            imageStatus.style.color = 'hsl(var(--destructive))';
                            imageStatus.style.backgroundColor = 'rgba(239, 68, 68, 0.1)';
                        }
                        
                        // Revert to original state
                        if (originalImageState) {
                            if (originalImageState.type === 'image') {
                                const profileImage = document.getElementById('profileImage');
                                if (profileImage) {
                                    profileImage.src = originalImageState.src;
                                }
                            } else if (originalImageState.type === 'initials') {
                                const profileImage = document.getElementById('profileImage');
                                const profileInitials = document.getElementById('profileInitials');
                                if (profileImage && !profileInitials) {
                                    const initialsDiv = document.createElement('div');
                                    initialsDiv.className = 'profile-initials';
                                    initialsDiv.id = 'profileInitials';
                                    profileImage.parentNode.replaceChild(initialsDiv, profileImage);
                                }
                            }
                        }
                        
                        // Hide buttons
                        if (imageUploadActions) {
                            imageUploadActions.style.display = 'none';
                        }
                        selectedFile = null;
                        profileImageInput.value = '';
                        saveImageBtn.disabled = false;
                        saveImageBtn.innerHTML = '<svg width="16" height="16" viewBox="0 0 20 20" fill="none"><path d="M16.7071 5.29289C17.0976 5.68342 17.0976 6.31658 16.7071 6.70711L8.70711 14.7071C8.31658 15.0976 7.68342 15.0976 7.29289 14.7071L3.29289 10.7071C2.90237 10.3166 2.90237 9.68342 3.29289 9.29289C3.68342 8.90237 4.31658 8.90237 4.70711 9.29289L8 12.5858L15.2929 5.29289C15.6834 4.90237 16.3166 4.90237 16.7071 5.29289Z" fill="currentColor"></path></svg> Save';
                    });
                }
            });
        }
        
        // Cancel image upload
        if (cancelImageBtn) {
            cancelImageBtn.addEventListener('click', function() {
                // Revert to original state
                if (originalImageState) {
                    if (originalImageState.type === 'image') {
                        const profileImage = document.getElementById('profileImage');
                        if (profileImage) {
                            profileImage.src = originalImageState.src;
                        }
                    } else if (originalImageState.type === 'initials') {
                        const profileImage = document.getElementById('profileImage');
                        const profileInitials = document.getElementById('profileInitials');
                        if (profileImage && !profileInitials) {
                            const initialsDiv = document.createElement('div');
                            initialsDiv.className = 'profile-initials';
                            initialsDiv.id = 'profileInitials';
                            initialsDiv.textContent = originalImageState.text;
                            profileImage.parentNode.replaceChild(initialsDiv, profileImage);
                        } else if (profileInitials) {
                            profileInitials.textContent = originalImageState.text;
                        }
                    }
                }
                
                // Hide buttons and reset input
                if (imageUploadActions) {
                    imageUploadActions.style.display = 'none';
                }
                selectedFile = null;
                profileImageInput.value = '';
            });
        }
    }

    // Bio Edit Functionality
    const editBioBtn = document.getElementById('editBioBtn');
    const bioText = document.getElementById('bioText');
    const bioEditForm = document.getElementById('bioEditForm');
    const bioTextarea = document.getElementById('bioTextarea');
    const saveBioBtn = document.getElementById('saveBioBtn');
    const cancelBioBtn = document.getElementById('cancelBioBtn');
    
    if (editBioBtn) {
        editBioBtn.addEventListener('click', function() {
            bioText.style.display = 'none';
            bioEditForm.style.display = 'block';
            bioTextarea.value = bioText.textContent.trim();
        });
    }
    
    if (cancelBioBtn) {
        cancelBioBtn.addEventListener('click', function() {
            bioText.style.display = 'block';
            bioEditForm.style.display = 'none';
        });
    }
    
    if (saveBioBtn) {
        saveBioBtn.addEventListener('click', function() {
            if (!bioTextarea) return;
            
            const newBio = bioTextarea.value.trim();
            
            // Disable button during save
            saveBioBtn.disabled = true;
            saveBioBtn.textContent = 'Saving...';
            
            // Prepare data
            const formData = new FormData();
            formData.append('action', 'update_bio');
            formData.append('nonce', wheelfy.nonce);
            formData.append('bio', newBio);
            
            // Send AJAX request
            fetch(wheelfy.ajaxUrl, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    if (bioText) {
                        bioText.textContent = newBio || 'You haven\'t added a biography yet. Click edit to add one.';
                        bioText.style.display = 'block';
                    }
                    bioEditForm.style.display = 'none';
                    
                    // Update profile completion percentage
                    updateProfileCompletion();
                } else {
                    alert(data.data.message || 'Failed to save. Please try again.');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred. Please try again.');
            })
            .finally(() => {
                saveBioBtn.disabled = false;
                saveBioBtn.textContent = 'Save';
            });
        });
    }

    // Personal Information Edit
    const editInfoBtn = document.getElementById('editInfoBtn');
    const infoFormActions = document.getElementById('infoFormActions');
    const saveInfoBtn = document.getElementById('saveInfoBtn');
    const cancelInfoBtn = document.getElementById('cancelInfoBtn');
    
    if (editInfoBtn) {
        editInfoBtn.addEventListener('click', function() {
            // Show inputs, hide values
            document.querySelectorAll('.info-value').forEach(el => el.style.display = 'none');
            document.querySelectorAll('.info-input').forEach(el => el.style.display = 'block');
            infoFormActions.style.display = 'flex';
        });
    }
    
    if (cancelInfoBtn) {
        cancelInfoBtn.addEventListener('click', function() {
            // Reset input values to original
            const nameInput = document.getElementById('nameInput');
            const nameValue = document.getElementById('nameValue');
            if (nameInput && nameValue) {
                nameInput.value = nameValue.textContent;
            }
            
            document.querySelectorAll('.info-value').forEach(el => el.style.display = 'block');
            document.querySelectorAll('.info-input').forEach(el => el.style.display = 'none');
            infoFormActions.style.display = 'none';
        });
    }
    
    if (saveInfoBtn) {
        saveInfoBtn.addEventListener('click', function() {
            const nameInput = document.getElementById('nameInput');
            const businessNameInput = document.getElementById('businessNameInput');
            const fullNameInput = document.getElementById('fullNameInput');
            const emailInput = document.getElementById('emailInput');
            const phoneInput = document.getElementById('phoneInput');
            const locationInput = document.getElementById('locationInput');
            
            // Disable button during save
            saveInfoBtn.disabled = true;
            saveInfoBtn.textContent = 'Saving...';
            
            // Prepare data
            const formData = new FormData();
            formData.append('action', 'update_profile_info');
            formData.append('nonce', wheelfy.nonce);
            formData.append('name', nameInput ? nameInput.value : '');
            formData.append('business_name', businessNameInput ? businessNameInput.value : '');
            formData.append('full_name', fullNameInput ? fullNameInput.value : '');
            formData.append('email', emailInput ? emailInput.value : '');
            formData.append('phone', phoneInput ? phoneInput.value : '');
            formData.append('location', locationInput ? locationInput.value : '');
            
            // Send AJAX request
            fetch(wheelfy.ajaxUrl, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Update display values
                    if (nameInput) document.getElementById('nameValue').textContent = nameInput.value || 'Not added';
                    if (businessNameInput) document.getElementById('businessNameValue').textContent = businessNameInput.value || 'Not added';
                    if (fullNameInput) document.getElementById('fullNameValue').textContent = fullNameInput.value || 'Not added';
                    if (emailInput) document.getElementById('emailValue').textContent = emailInput.value || 'Not added';
                    if (phoneInput) document.getElementById('phoneValue').textContent = phoneInput.value || 'Not added';
                    if (locationInput) document.getElementById('locationValue').textContent = locationInput.value || 'Not added';
                    
                    // Update sidebar name if name changed
                    const profileName = document.getElementById('profileName');
                    if (profileName && nameInput) {
                        profileName.textContent = nameInput.value || profileName.textContent;
                    }
                    
                    // Update profile completion percentage
                    updateProfileCompletion();
                    
                    // Hide inputs, show values
                    document.querySelectorAll('.info-value').forEach(el => el.style.display = 'block');
                    document.querySelectorAll('.info-input').forEach(el => el.style.display = 'none');
                    infoFormActions.style.display = 'none';
                } else {
                    alert(data.data.message || 'Failed to save. Please try again.');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred. Please try again.');
            })
            .finally(() => {
                saveInfoBtn.disabled = false;
                saveInfoBtn.textContent = 'Save';
            });
        });
    }

    // Social Media Links Edit
    const editSocialBtn = document.getElementById('editSocialBtn');
    const socialFormActions = document.getElementById('socialFormActions');
    const saveSocialBtn = document.getElementById('saveSocialBtn');
    const cancelSocialBtn = document.getElementById('cancelSocialBtn');
    
    if (editSocialBtn) {
        editSocialBtn.addEventListener('click', function() {
            document.querySelectorAll('.social-link-value').forEach(el => el.style.display = 'none');
            document.querySelectorAll('.social-link-input').forEach(el => el.style.display = 'block');
            socialFormActions.style.display = 'flex';
        });
    }
    
    if (cancelSocialBtn) {
        cancelSocialBtn.addEventListener('click', function() {
            document.querySelectorAll('.social-link-value').forEach(el => el.style.display = 'block');
            document.querySelectorAll('.social-link-input').forEach(el => el.style.display = 'none');
            socialFormActions.style.display = 'none';
        });
    }
    
    if (saveSocialBtn) {
        saveSocialBtn.addEventListener('click', function() {
            const facebookInput = document.getElementById('facebookInput');
            const twitterInput = document.getElementById('twitterInput');
            const instagramInput = document.getElementById('instagramInput');
            const linkedinInput = document.getElementById('linkedinInput');
            
            // Disable button during save
            saveSocialBtn.disabled = true;
            saveSocialBtn.textContent = 'Saving...';
            
            // Prepare data
            const formData = new FormData();
            formData.append('action', 'update_social_links');
            formData.append('nonce', wheelfy.nonce);
            formData.append('facebook', facebookInput ? facebookInput.value : '');
            formData.append('twitter', twitterInput ? twitterInput.value : '');
            formData.append('instagram', instagramInput ? instagramInput.value : '');
            formData.append('linkedin', linkedinInput ? linkedinInput.value : '');
            
            // Send AJAX request
            fetch(wheelfy.ajaxUrl, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Update display values
                    if (facebookInput) document.getElementById('facebookValue').textContent = facebookInput.value || 'Not added';
                    if (twitterInput) document.getElementById('twitterValue').textContent = twitterInput.value || 'Not added';
                    if (instagramInput) document.getElementById('instagramValue').textContent = instagramInput.value || 'Not added';
                    if (linkedinInput) document.getElementById('linkedinValue').textContent = linkedinInput.value || 'Not added';
                    
                    // Hide inputs, show values
                    document.querySelectorAll('.social-link-value').forEach(el => el.style.display = 'block');
                    document.querySelectorAll('.social-link-input').forEach(el => el.style.display = 'none');
                    socialFormActions.style.display = 'none';
                } else {
                    alert(data.data.message || 'Failed to save. Please try again.');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred. Please try again.');
            })
            .finally(() => {
                saveSocialBtn.disabled = false;
                saveSocialBtn.textContent = 'Save';
            });
        });
    }

    // Professional Information Edit
    const editProfessionalBtn = document.getElementById('editProfessionalBtn');
    const professionalFormActions = document.getElementById('professionalFormActions');
    const saveProfessionalBtn = document.getElementById('saveProfessionalBtn');
    const cancelProfessionalBtn = document.getElementById('cancelProfessionalBtn');
    
    if (editProfessionalBtn) {
        editProfessionalBtn.addEventListener('click', function() {
            // Show inputs, hide values
            const professionValue = document.getElementById('professionValue');
            const professionInput = document.getElementById('professionInput');
            const priceValue = document.getElementById('priceValue');
            const priceInputWrapper = document.getElementById('priceInputWrapper');
            const experienceValue = document.getElementById('experienceValue');
            const experienceInput = document.getElementById('experienceInput');
            
            if (professionValue) professionValue.style.display = 'none';
            if (professionInput) professionInput.style.display = 'block';
            if (priceValue) priceValue.style.display = 'none';
            if (priceInputWrapper) priceInputWrapper.style.display = 'flex';
            if (experienceValue) experienceValue.style.display = 'none';
            if (experienceInput) experienceInput.style.display = 'block';
            if (professionalFormActions) professionalFormActions.style.display = 'flex';
        });
    }
    
    if (cancelProfessionalBtn) {
        cancelProfessionalBtn.addEventListener('click', function() {
            // Hide inputs, show values
            const professionValue = document.getElementById('professionValue');
            const professionInput = document.getElementById('professionInput');
            const priceValue = document.getElementById('priceValue');
            const priceInputWrapper = document.getElementById('priceInputWrapper');
            const experienceValue = document.getElementById('experienceValue');
            const experienceInput = document.getElementById('experienceInput');
            
            if (professionValue) professionValue.style.display = 'block';
            if (professionInput) professionInput.style.display = 'none';
            if (priceValue) priceValue.style.display = 'block';
            if (priceInputWrapper) priceInputWrapper.style.display = 'none';
            if (experienceValue) experienceValue.style.display = 'block';
            if (experienceInput) experienceInput.style.display = 'none';
            if (professionalFormActions) professionalFormActions.style.display = 'none';
        });
    }
    
    if (saveProfessionalBtn) {
        saveProfessionalBtn.addEventListener('click', function() {
            const professionInput = document.getElementById('professionInput');
            const priceInput = document.getElementById('priceInput');
            const priceCurrency = document.getElementById('priceCurrency');
            const experienceInput = document.getElementById('experienceInput');
            
            if (!professionInput || !priceInput || !experienceInput) return;
            
            // Disable button during save
            saveProfessionalBtn.disabled = true;
            saveProfessionalBtn.textContent = 'Saving...';
            
            // Prepare data
            const formData = new FormData();
            formData.append('action', 'update_professional_info');
            formData.append('nonce', wheelfy.nonce);
            formData.append('profession', professionInput.value || '');
            formData.append('price', priceInput.value || '');
            formData.append('currency', priceCurrency ? priceCurrency.value : 'USD');
            formData.append('experience', experienceInput.value || '');
            
            // Send AJAX request
            fetch(wheelfy.ajaxUrl, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Update display values
                    const professionValue = document.getElementById('professionValue');
                    const priceValue = document.getElementById('priceValue');
                    const experienceValue = document.getElementById('experienceValue');
                    const professionText = professionInput.value.trim();
                    const priceText = priceInput.value ? parseFloat(priceInput.value).toFixed(2) + ' ' + (priceCurrency ? priceCurrency.options[priceCurrency.selectedIndex].text : '$') : 'Not added';
                    const experienceText = experienceInput.value.trim();
                    
                    if (professionValue) {
                        professionValue.textContent = professionText ? professionText : 'Not added';
                        professionValue.style.display = 'block';
                    }
                    if (priceValue) {
                        priceValue.textContent = priceText;
                        priceValue.style.display = 'block';
                    }
                    if (experienceValue) {
                        experienceValue.textContent = experienceText ? experienceText : 'Not added';
                        experienceValue.style.display = 'block';
                    }
                    
                    // Hide inputs
                    if (professionInput) professionInput.style.display = 'none';
                    const priceInputWrapper = document.getElementById('priceInputWrapper');
                    if (priceInputWrapper) priceInputWrapper.style.display = 'none';
                    if (experienceInput) experienceInput.style.display = 'none';
                    if (professionalFormActions) professionalFormActions.style.display = 'none';
                } else {
                    alert(data.data.message || 'Failed to save. Please try again.');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred. Please try again.');
            })
            .finally(() => {
                saveProfessionalBtn.disabled = false;
                saveProfessionalBtn.textContent = 'Save';
            });
        });
    }

    // Request Actions - Accept and Delete
    const acceptRequestBtns = document.querySelectorAll('.accept-request-btn');
    const deleteRequestBtns = document.querySelectorAll('.delete-request-btn');
    const requestStatusFilter = document.getElementById('requestStatusFilter');
    
    // Accept Request Handler - NOW REDIRECTS TO MODAL (price is required)
    if (acceptRequestBtns.length > 0) {
        acceptRequestBtns.forEach(btn => {
            btn.addEventListener('click', function(e) {
                e.stopPropagation();
                const requestId = this.getAttribute('data-request-id');
                const requestCard = this.closest('.request-card');
                
                // Find the request and open modal to enter price
                if (typeof allRequests !== 'undefined' && typeof openRequestModal === 'function') {
                    const request = allRequests.find(r => r.id === requestId);
                    if (request) {
                        openRequestModal(request);
                        return;
                    }
                }
                
                // Fallback: click on card to open modal
                if (requestCard) {
                    requestCard.click();
                } else {
                    alert('Please click on the request card to view details and send your offer with price.');
                }
            });
        });
    }
    
    // Delete Request Handler
    if (deleteRequestBtns.length > 0) {
        deleteRequestBtns.forEach(btn => {
            btn.addEventListener('click', function() {
                const requestId = this.getAttribute('data-request-id');
                const requestCard = this.closest('.request-card');
                
                if (!confirm('Are you sure you want to delete this request? This action cannot be undone.')) {
                    return;
                }
                
                this.disabled = true;
                this.textContent = 'Deleting...';
                
                const formData = new FormData();
                formData.append('action', 'update_request_status');
                formData.append('nonce', wheelfy.nonce);
                formData.append('request_id', requestId);
                formData.append('status', 'deleted');
                
                fetch(wheelfy.ajaxUrl, {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        requestCard.style.transition = 'opacity 0.3s, transform 0.3s';
                        requestCard.style.opacity = '0';
                        requestCard.style.transform = 'translateX(-20px)';
                        setTimeout(() => {
                            requestCard.remove();
                            const requestsList = document.getElementById('requestsList');
                            if (requestsList && requestsList.querySelectorAll('.request-card').length === 0) {
                                requestsList.innerHTML = '<div class="empty-state"><div class="empty-state-icon"><svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 12h6m-3-3v6m-9 1V7a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path></svg></div><h3 class="empty-state-title">No Requests</h3><p class="empty-state-text">All requests have been processed.</p></div>';
                            }
                        }, 300);
                        const requestsNav = document.querySelector('.nav-item[data-section="requests"] .badge');
                        if (requestsNav) {
                            const currentCount = parseInt(requestsNav.textContent) || 0;
                            if (currentCount > 0) {
                                requestsNav.textContent = currentCount - 1;
                                if (currentCount - 1 === 0) {
                                    requestsNav.remove();
                                }
                            }
                        }
                    } else {
                        alert(data.data.message || 'Failed to delete request.');
                        this.disabled = false;
                        this.textContent = '✕ Delete';
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('An error occurred. Please try again.');
                    this.disabled = false;
                    this.textContent = '✕ Delete';
                });
            });
        });
    }
    
    // Request Tabs Filter
    const requestTabs = document.getElementById('requestTabs');
    if (requestTabs) {
        requestTabs.addEventListener('click', function(e) {
            if (e.target.classList.contains('tab-btn')) {
                // Update active tab
                requestTabs.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
                e.target.classList.add('active');
                
                // Load requests with filter
                const filter = e.target.getAttribute('data-filter');
                loadPartnerRequests(filter);
            }
        });
    }
    
    // Request Modal - Global variables and functions
    let requestModal, requestModalBody, closeRequestModal;
    
    function initRequestModal() {
        requestModal = document.getElementById('requestModal');
        requestModalBody = document.getElementById('requestModalBody');
        closeRequestModal = document.getElementById('closeRequestModal');
        
        if (closeRequestModal) {
            closeRequestModal.addEventListener('click', closeRequestModalFunc);
        }
        
        if (requestModal) {
            requestModal.addEventListener('click', function(e) {
                if (e.target === requestModal) {
                    closeRequestModalFunc();
                }
            });
            
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape' && requestModal && requestModal.style.display === 'flex') {
                    closeRequestModalFunc();
                }
            });
        }
    }
    
function openRequestModal(requestData) {
    // Ensure modal is initialized
    if (!requestModal || !requestModalBody) {
        initRequestModal();
        if (!requestModal || !requestModalBody) {
            console.error('Request modal elements not found');
            return;
        }
    }
        
        const request = typeof requestData === 'string' ? JSON.parse(requestData) : requestData;
        const status = request.status || 'pending';
        const formData = request.form_data || {};
        
        // Format date properly
        let formattedDate = request.request_date || '';
        if (formattedDate) {
            try {
                const dateObj = new Date(formattedDate);
                if (!isNaN(dateObj.getTime())) {
                    formattedDate = dateObj.toLocaleString('en-US', {
                        month: 'short',
                        day: 'numeric',
                        year: 'numeric',
                        hour: 'numeric',
                        minute: '2-digit',
                        hour12: true
                    });
                }
            } catch(e) {
                formattedDate = request.request_date;
            }
        }
        
        // Extract all data from form_data
        const make = formData.make || '';
        const model = formData.model || '';
        const year = formData.year || '';
        const mileage = formData.mileage || '';
        const services = Array.isArray(formData.services) ? formData.services : [];
        const additionalServices = formData.additional_services || '';
        const customerName = request.customer_name || formData.customer_name || 'Unknown Customer';
        const customerEmail = request.customer_email || formData.customer_email || formData.email || 'No email provided';
        const customerPhone = formData.phone || formData.customer_phone || formData.telephone || 'Not provided';
        const customerLocation = formData.location || formData.customer_location || formData.address || 'Not provided';
        
        // Check if this is a service-based request
        const isServiceRequest = formData.request_type === 'service';
        const serviceTitle = formData.service_title || '';
        const serviceDescription = formData.service_description || '';
        // Get price - ensure we get the actual value
        const servicePriceRaw = formData.service_price !== undefined ? formData.service_price : (formData.price !== undefined ? formData.price : null);
        const servicePrice = (servicePriceRaw !== undefined && servicePriceRaw !== null && servicePriceRaw !== '') ? parseFloat(servicePriceRaw) : 0;
        const servicePriceCurrency = formData.service_price_currency || formData.price_currency || 'EUR';
        const serviceDuration = formData.service_duration || '';
        const serviceCategory = formData.service_category || '';
        
        // Build modal content
        let modalContent = `
            <div class="request-modal-section">
                <h3 class="request-modal-section-title">Customer Information</h3>
                <div class="request-detail-grid">
                    <div class="request-detail-item">
                        <span class="request-detail-label">Customer Name</span>
                        <span class="request-detail-value" style="font-weight: 600; font-size: 1.125rem; color: hsl(var(--primary));">${customerName}</span>
                    </div>
                    <div class="request-detail-item">
                        <span class="request-detail-label">Phone</span>
                        <span class="request-detail-value">
                            <a href="tel:${customerPhone}" style="color: hsl(var(--primary)); text-decoration: none;">${customerPhone}</a>
                        </span>
                    </div>
                    <div class="request-detail-item">
                        <span class="request-detail-label">Location</span>
                        <span class="request-detail-value">${customerLocation}</span>
                    </div>
                </div>
            </div>
            
            <div class="request-modal-section">
                <h3 class="request-modal-section-title">Request Information</h3>
                <div class="request-detail-grid">
                    <div class="request-detail-item">
                        <span class="request-detail-label">Request Type</span>
                        <span class="request-detail-value">
                            <span class="${request.request_type === 'premium' ? 'request-label-premium' : 'request-label-normal'}" style="display: inline-block; margin: 0;">
                                ${request.request_type === 'premium' ? 'Premium Request' : 'Regular Request'}
                            </span>
                        </span>
                    </div>
                    <div class="request-detail-item">
                        <span class="request-detail-label">Status</span>
                        <span class="request-detail-value">
                            <span class="status-badge status-${status}">${status.charAt(0).toUpperCase() + status.slice(1)}</span>
                        </span>
                    </div>
                    <div class="request-detail-item">
                        <span class="request-detail-label">Request Date</span>
                        <span class="request-detail-value">${formattedDate}</span>
                    </div>
                    <div class="request-detail-item">
                        <span class="request-detail-label">Request ID</span>
                        <span class="request-detail-value" style="font-family: monospace; font-size: 0.875rem;">${request.id || request.request_id || 'N/A'}</span>
                    </div>
                </div>
            </div>
            
            ${isServiceRequest ? `
            <div class="request-modal-section" style="background: hsl(var(--secondary) / 0.3); padding: 1.5rem; border-radius: 0.5rem; margin: 1rem 0;">
                <h3 class="request-modal-section-title" style="color: hsl(var(--primary)); margin-bottom: 1rem;">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="display: inline-block; vertical-align: middle; margin-right: 0.5rem;">
                        <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"></path>
                    </svg>
                    Service Information
                </h3>
                <div class="request-detail-grid">
                    <div class="request-detail-item" style="grid-column: 1 / -1;">
                        <span class="request-detail-label">Service Name</span>
                        <span class="request-detail-value" style="font-weight: 600; font-size: 1.125rem; color: hsl(var(--primary));">${serviceTitle}</span>
                    </div>
                    ${serviceDescription ? `
                    <div class="request-detail-item" style="grid-column: 1 / -1;">
                        <span class="request-detail-label">Description</span>
                        <span class="request-detail-value" style="line-height: 1.6;">${serviceDescription}</span>
                    </div>
                    ` : ''}
                    <div class="request-detail-item" style="background: hsl(var(--primary) / 0.1); padding: 1rem; border-radius: 0.5rem; border: 2px solid hsl(var(--primary) / 0.3);">
                        <span class="request-detail-label" style="font-weight: 600; font-size: 0.875rem; text-transform: uppercase; letter-spacing: 0.5px; color: hsl(var(--muted-foreground));">Price</span>
                        <span class="request-detail-value" style="font-weight: 700; font-size: 1.5rem; color: hsl(var(--primary)); display: block; margin-top: 0.5rem;">
                            ${servicePrice > 0 && !isNaN(servicePrice) 
                                ? (servicePriceCurrency === 'HUF' ? 'HUF ' : '€') + (servicePriceCurrency === 'HUF' ? servicePrice.toLocaleString('hu-HU', {minimumFractionDigits: 0, maximumFractionDigits: 0}) : servicePrice.toFixed(2))
                                : '<span style="color: hsl(var(--muted-foreground)); font-size: 1rem;">Not set</span>'}
                        </span>
                    </div>
                    ${serviceDuration ? `
                    <div class="request-detail-item">
                        <span class="request-detail-label">Duration</span>
                        <span class="request-detail-value">${serviceDuration}</span>
                    </div>
                    ` : ''}
                    ${serviceCategory ? `
                    <div class="request-detail-item">
                        <span class="request-detail-label">Category</span>
                        <span class="request-detail-value">${serviceCategory}</span>
                    </div>
                    ` : ''}
                </div>
            </div>
            ` : ''}
            
            ${(year || make || model || mileage) ? `
            <div class="request-modal-section">
                <h3 class="request-modal-section-title">Vehicle Information</h3>
                <div class="request-detail-grid">
                    ${year ? `
                    <div class="request-detail-item">
                        <span class="request-detail-label">Year</span>
                        <span class="request-detail-value">${year}</span>
                    </div>
                    ` : ''}
                    ${make ? `
                    <div class="request-detail-item">
                        <span class="request-detail-label">Make</span>
                        <span class="request-detail-value">${make}</span>
                    </div>
                    ` : ''}
                    ${model ? `
                    <div class="request-detail-item">
                        <span class="request-detail-label">Model</span>
                        <span class="request-detail-value">${model}</span>
                    </div>
                    ` : ''}
                    ${mileage ? `
                    <div class="request-detail-item">
                        <span class="request-detail-label">Mileage</span>
                        <span class="request-detail-value">${mileage}</span>
                    </div>
                    ` : ''}
                </div>
            </div>
            ` : ''}
            
            ${services.length > 0 ? `
            <div class="request-modal-section">
                <h3 class="request-modal-section-title">Services Requested</h3>
                <div class="request-detail-item" style="grid-column: 1 / -1;">
                    <div style="display: flex; flex-wrap: wrap; gap: 0.5rem;">
                        ${services.map(service => `<span class="service-badge" style="padding: 0.5rem 1rem; background: hsl(var(--primary) / 0.1); color: hsl(var(--primary)); border-radius: 0.5rem; font-weight: 600;">${service}</span>`).join('')}
                    </div>
                </div>
            </div>
            ` : ''}
            
            <div class="request-modal-section">
                <h3 class="request-modal-section-title">Request Details</h3>
                <div class="request-detail-item" style="grid-column: 1 / -1; padding: 1rem; background: hsl(var(--secondary)); border-radius: 0.5rem; border: 1px solid hsl(var(--border));">
                    <span class="request-detail-value" style="line-height: 1.6; white-space: pre-wrap;">
                        ${isServiceRequest && serviceTitle ? serviceTitle + ' - Service Request' : (request.request_details || 'No additional details provided')}
                    </span>
                </div>
                ${additionalServices ? `
                <div class="request-detail-item" style="grid-column: 1 / -1; margin-top: 1rem; padding: 1rem; background: hsl(var(--muted) / 0.3); border-radius: 0.5rem;">
                    <span class="request-detail-label" style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Additional Services:</span>
                    <span class="request-detail-value" style="line-height: 1.6;">${additionalServices}</span>
                </div>
                ` : ''}
            </div>
        `;
        
        // Add action buttons if pending - WITH PRICE FORM (new workflow)
        if (status === 'pending') {
            modalContent += `
                <div class="modal-actions-wrapper" style="margin-top: 2rem; padding-top: 2rem; border-top: 1px solid hsl(var(--border));">
                    <!-- NEW WORKFLOW: Offer Form -->
                    <div class="offer-form-section" style="margin-bottom: 1.5rem; padding: 1.25rem; background: hsl(var(--muted) / 0.3); border-radius: 0.75rem; border: 1px solid hsl(var(--border));">
                        <h4 style="margin: 0 0 1rem 0; font-size: 1rem; font-weight: 600; color: hsl(var(--foreground)); display: flex; align-items: center; gap: 0.5rem;">
                            💰 Your Offer
                        </h4>
                        <div class="offer-form-fields" style="display: flex; flex-direction: column; gap: 1rem;">
                            <div class="form-group">
                                <label for="legacyOfferPrice" style="display: block; margin-bottom: 0.5rem; font-size: 0.875rem; font-weight: 500; color: hsl(var(--foreground));">
                                    Service Price (€) <span style="color: hsl(var(--destructive));">*</span>
                                </label>
                                <input type="number" id="legacyOfferPrice" name="offer_price" min="0" step="0.01" required
                                       placeholder="Enter your price"
                                       style="width: 100%; padding: 0.75rem 1rem; border: 1px solid hsl(var(--border)); border-radius: 0.5rem; font-size: 1rem; background: hsl(var(--background)); color: hsl(var(--foreground));">
                            </div>
                            <div class="form-group">
                                <label for="legacyOfferNote" style="display: block; margin-bottom: 0.5rem; font-size: 0.875rem; font-weight: 500; color: hsl(var(--foreground));">
                                    Additional Note (Optional)
                                </label>
                                <textarea id="legacyOfferNote" name="offer_note" rows="3"
                                          placeholder="Add any details about your service..."
                                          style="width: 100%; padding: 0.75rem 1rem; border: 1px solid hsl(var(--border)); border-radius: 0.5rem; font-size: 0.875rem; background: hsl(var(--background)); color: hsl(var(--foreground)); resize: vertical;"></textarea>
                            </div>
                            <p style="margin: 0; font-size: 0.75rem; color: hsl(var(--muted-foreground)); line-height: 1.5;">
                                ℹ️ The customer will need to approve your offer before you can start working.
                            </p>
                        </div>
                    </div>
                    
                    <div class="request-actions-modal" style="display: flex; gap: 1rem;">
                        <button class="btn btn-primary legacy-send-offer-btn" data-request-id="${request.id}" style="flex: 1;">
                            ✓ Send Offer
                        </button>
                        <button class="btn btn-outline delete-request-btn" data-request-id="${request.id}" style="flex: 1; color: hsl(var(--destructive)); border-color: hsl(var(--destructive));">
                            ✕ Delete Request
                        </button>
                    </div>
                </div>
            `;
        }
        
        requestModalBody.innerHTML = modalContent;
        requestModal.style.display = 'flex';
        requestModal.classList.add('active');
        document.body.style.overflow = 'hidden';
        
        // Re-attach event listeners for buttons in modal
        const sendOfferBtn = requestModalBody.querySelector('.legacy-send-offer-btn');
        const deleteBtn = requestModalBody.querySelector('.delete-request-btn');
        
        if (sendOfferBtn) {
            sendOfferBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                const requestId = this.getAttribute('data-request-id');
                
                // Get price and note
                const offerPriceInput = document.getElementById('legacyOfferPrice');
                const offerNoteInput = document.getElementById('legacyOfferNote');
                const offerPrice = offerPriceInput ? parseFloat(offerPriceInput.value) : 0;
                const offerNote = offerNoteInput ? offerNoteInput.value.trim() : '';
                
                // Validate price
                if (!offerPrice || offerPrice <= 0) {
                    alert('Please enter a valid service price.');
                    if (offerPriceInput) {
                        offerPriceInput.focus();
                        offerPriceInput.style.borderColor = 'hsl(var(--destructive))';
                    }
                    return;
                }
                
                if (!confirm('Are you sure you want to send this offer? The customer will need to approve it before you can start working.')) return;
                
                this.disabled = true;
                this.textContent = 'Sending Offer...';
                
                const formData = new FormData();
                formData.append('action', 'update_request_status');
                formData.append('nonce', wheelfy.nonce);
                formData.append('request_id', requestId);
                formData.append('status', 'accepted');
                formData.append('offer_price', offerPrice);
                formData.append('offer_note', offerNote);
                
                fetch(wheelfy.ajaxUrl, { method: 'POST', body: formData })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('Offer sent successfully! The customer will be notified.');
                        closeRequestModalFunc();
                        loadPartnerRequests(currentRequestFilter);
                    } else {
                        alert(data.data.message || 'Failed to send offer.');
                        this.disabled = false;
                        this.textContent = '✓ Send Offer';
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('An error occurred. Please try again.');
                    this.disabled = false;
                    this.textContent = '✓ Send Offer';
                });
            });
        }
        
        if (deleteBtn) {
            deleteBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                const requestId = this.getAttribute('data-request-id');
                if (!confirm('Are you sure you want to delete this request? This action is final and irreversible.')) return;
                this.disabled = true;
                this.textContent = 'Deleting...';
                const formData = new FormData();
                formData.append('action', 'update_request_status');
                formData.append('nonce', wheelfy.nonce);
                formData.append('request_id', requestId);
                formData.append('status', 'rejected');
                fetch(wheelfy.ajaxUrl, { method: 'POST', body: formData })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        closeRequestModalFunc();
                        loadPartnerRequests(currentRequestFilter);
                    } else {
                        alert(data.data.message || 'Failed to delete request.');
                        this.disabled = false;
                        this.textContent = '✕ Delete Request';
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('An error occurred. Please try again.');
                    this.disabled = false;
                    this.textContent = '✕ Delete Request';
                });
            });
        }
    }
    
    // Helper functions for accept/delete from modal
    // DEPRECATED: This function is no longer used for direct accept
    // All accepts now require price input through the modal form
    function handleAcceptRequest(btn) {
        const requestId = btn.getAttribute('data-request-id');
        
        // Find request and redirect to modal with price form
        if (typeof allRequests !== 'undefined' && typeof openRequestModal === 'function') {
            const request = allRequests.find(r => r.id === requestId);
            if (request) {
                openRequestModal(request);
                return;
            }
        }
        
        alert('Please use the modal to enter your offer price before accepting.');
    }
    
    function handleDeleteRequest(btn) {
        const requestId = btn.getAttribute('data-request-id');
        const requestCard = document.querySelector(`[data-request-id="${requestId}"]`);
        
        if (!confirm('Are you sure you want to delete this request? This action cannot be undone.')) {
            return;
        }
        
        btn.disabled = true;
        btn.textContent = 'Deleting...';
        
        const formData = new FormData();
        formData.append('action', 'update_request_status');
        formData.append('nonce', wheelfy.nonce);
        formData.append('request_id', requestId);
        formData.append('status', 'deleted');
        
        fetch(wheelfy.ajaxUrl, {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                closeRequestModalFunc();
                if (requestCard) {
                    requestCard.style.transition = 'opacity 0.3s, transform 0.3s';
                    requestCard.style.opacity = '0';
                    requestCard.style.transform = 'translateX(-20px)';
                    setTimeout(() => {
                        requestCard.remove();
                        const requestsList = document.getElementById('requestsList');
                        if (requestsList && requestsList.querySelectorAll('.request-card').length === 0) {
                            requestsList.innerHTML = '<div class="empty-state"><div class="empty-state-icon"><svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 12h6m-3-3v6m-9 1V7a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path></svg></div><h3 class="empty-state-title">No Requests</h3><p class="empty-state-text">All requests have been processed.</p></div>';
                        }
                    }, 300);
                }
                const requestsNav = document.querySelector('.nav-item[data-section="requests"] .badge');
                if (requestsNav) {
                    const currentCount = parseInt(requestsNav.textContent) || 0;
                    if (currentCount > 0) {
                        requestsNav.textContent = currentCount - 1;
                        if (currentCount - 1 === 0) {
                            requestsNav.remove();
                        }
                    }
                }
            } else {
                alert(data.data.message || 'Failed to delete request.');
                btn.disabled = false;
                btn.textContent = '✕ Delete Request';
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred. Please try again.');
            btn.disabled = false;
            btn.textContent = '✕ Delete Request';
        });
    }

    // Dismiss Notification Handler
    const dismissButtons = document.querySelectorAll('.dismiss-notification');
    dismissButtons.forEach(button => {
        button.addEventListener('click', function() {
            const banner = document.getElementById('freePlanBanner');
            
            if (banner) {
                // Simply hide the banner (will show again on reload)
                banner.style.display = 'none';
            }
        });
    });

    // Upgrade Plan Button Handler - Redirect to Checkout Page
    const upgradePlanButtons = document.querySelectorAll('.upgrade-plan-btn');
    upgradePlanButtons.forEach(button => {
        button.addEventListener('click', function() {
            const planId = this.getAttribute('data-plan-id');
            const planPrice = parseFloat(this.getAttribute('data-plan-price') || 0);
            const planName = this.getAttribute('data-plan-name') || 'Plan';
            
            if (!planId) return;
            
            // For free plans, process directly via AJAX
            if (planPrice <= 0) {
                if (!confirm('<?php echo esc_js(__('Switch to', 'wheelfy')); ?> ' + planName + '?')) return;
                
                this.disabled = true;
                const originalText = this.textContent;
                this.textContent = '<?php echo esc_js(__('Processing...', 'wheelfy')); ?>';
                
                const formData = new FormData();
                formData.append('action', 'wheelfy_process_checkout');
                formData.append('nonce', '<?php echo wp_create_nonce('wheelfy_checkout_nonce'); ?>');
                formData.append('plan_id', planId);
                formData.append('gateway', 'free');
                
                fetch(wheelfy.ajaxUrl, {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert(data.data.message || '<?php echo esc_js(__('Plan updated successfully!', 'wheelfy')); ?>');
                        window.location.reload();
                    } else {
                        alert(data.data?.message || '<?php echo esc_js(__('Failed to update plan.', 'wheelfy')); ?>');
                        this.disabled = false;
                        this.textContent = originalText;
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('<?php echo esc_js(__('An error occurred. Please try again.', 'wheelfy')); ?>');
                    this.disabled = false;
                    this.textContent = originalText;
                });
            } else {
                // For paid plans, redirect to checkout page
                window.location.href = '<?php echo esc_url(home_url('/subscription-checkout/')); ?>?plan=' + planId;
            }
        });
    });
});

// ============================================================================
// REAL-TIME NOTIFICATION SYSTEM
// ============================================================================

let notificationPollInterval = null;
let lastNotificationCheck = 0;

/**
 * Get notification icon based on type
 */
function getNotificationIcon(type) {
    const icons = {
        'message': '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15C21 15.5304 20.7893 16.0391 20.4142 16.4142C20.0391 16.7893 19.5304 17 19 17H7L3 21V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H19C19.5304 3 20.0391 3.21071 20.4142 3.58579C20.7893 3.96086 21 4.46957 21 5V15Z"></path></svg>',
        'review': '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"></path></svg>',
        'request_accepted': '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>',
        'request_rejected': '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>',
        'request_deleted': '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>',
        'new_request': '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path><path d="M13.73 21a2 2 0 0 1-3.46 0"></path></svg>',
        'system': '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>'
    };
    return icons[type] || icons['system'];
}

/**
 * Get notification icon class based on type
 */
function getNotificationIconClass(type) {
    const classes = {
        'message': 'activity-icon-info',
        'review': 'activity-icon-warning',
        'request_accepted': 'activity-icon-success',
        'request_rejected': 'activity-icon-error',
        'request_deleted': 'activity-icon-error',
        'new_request': 'activity-icon-info',
        'system': 'activity-icon-info'
    };
    return classes[type] || 'activity-icon-info';
}

/**
 * Format time ago
 */
function formatTimeAgo(timestamp) {
    const now = Math.floor(Date.now() / 1000);
    const diff = now - timestamp;
    
    if (diff < 60) return 'Just now';
    if (diff < 3600) return Math.floor(diff / 60) + ' minutes ago';
    if (diff < 86400) return Math.floor(diff / 3600) + ' hours ago';
    if (diff < 604800) return Math.floor(diff / 86400) + ' days ago';
    return Math.floor(diff / 604800) + ' weeks ago';
}

/**
 * Notification pagination settings
 */
let allNotifications = [];
let displayedNotificationsCount = 0;
const NOTIFICATIONS_PER_PAGE = 5;

/**
 * Render notifications
 */
function renderNotifications(notifications) {
    const container = document.getElementById('notificationsList');
    const emptyState = document.getElementById('notificationsEmpty');
    const loading = document.getElementById('notificationsLoading');
    
    if (!container) return;
    
    // Hide loading
    if (loading) loading.style.display = 'none';
    
    if (!notifications || notifications.length === 0) {
        if (emptyState) emptyState.style.display = 'block';
        container.innerHTML = '';
        container.appendChild(emptyState);
        // Remove load more button if exists
        const existingLoadMore = document.getElementById('loadMoreNotifications');
        if (existingLoadMore) existingLoadMore.remove();
        return;
    }
    
    if (emptyState) emptyState.style.display = 'none';
    
    // SORT: Priority (VIP/Fast Track) notifications first, then by timestamp
    notifications.sort((a, b) => {
        const aPriority = (a.meta && (a.meta.is_priority === true || a.meta.is_priority === 'true' || a.meta.is_priority == 1)) ? 1 : 0;
        const bPriority = (b.meta && (b.meta.is_priority === true || b.meta.is_priority === 'true' || b.meta.is_priority == 1)) ? 1 : 0;
        
        // Priority first (descending)
        if (bPriority !== aPriority) {
            return bPriority - aPriority;
        }
        
        // Then by timestamp (newest first)
        return (b.timestamp || 0) - (a.timestamp || 0);
    });
    
    // Store all notifications and reset counter
    allNotifications = notifications;
    displayedNotificationsCount = 0;
    container.innerHTML = '';
    
    // Show first batch
    showMoreNotifications();
}

/**
 * Show more notifications (pagination)
 */
function showMoreNotifications() {
    const container = document.getElementById('notificationsList');
    if (!container) return;
    
    const startIndex = displayedNotificationsCount;
    const endIndex = Math.min(startIndex + NOTIFICATIONS_PER_PAGE, allNotifications.length);
    
    for (let i = startIndex; i < endIndex; i++) {
        const notif = allNotifications[i];
        renderSingleNotification(notif, container);
    }
    
    displayedNotificationsCount = endIndex;
    
    // Update or create load more button
    updateLoadMoreButton();
    
    // Reattach event handlers for new items
    attachNotificationEventHandlers();
}

/**
 * Update load more button visibility
 */
function updateLoadMoreButton() {
    const container = document.getElementById('notificationsList');
    if (!container) return;
    
    let loadMoreBtn = document.getElementById('loadMoreNotifications');
    
    if (displayedNotificationsCount < allNotifications.length) {
        const remaining = allNotifications.length - displayedNotificationsCount;
        
        if (!loadMoreBtn) {
            loadMoreBtn = document.createElement('button');
            loadMoreBtn.id = 'loadMoreNotifications';
            loadMoreBtn.className = 'load-more-btn';
            loadMoreBtn.style.cssText = 'display: block; width: 100%; padding: 1rem; margin-top: 1rem; background: hsl(var(--secondary)); border: 1px solid hsl(var(--border)); border-radius: 0.5rem; color: hsl(var(--foreground)); cursor: pointer; font-size: 0.9rem; transition: all 0.2s; text-align: center;';
            loadMoreBtn.addEventListener('click', showMoreNotifications);
            loadMoreBtn.addEventListener('mouseenter', function() {
                this.style.background = 'hsl(var(--primary) / 0.1)';
                this.style.borderColor = 'hsl(var(--primary) / 0.5)';
            });
            loadMoreBtn.addEventListener('mouseleave', function() {
                this.style.background = 'hsl(var(--secondary))';
                this.style.borderColor = 'hsl(var(--border))';
            });
            container.parentNode.appendChild(loadMoreBtn);
        }
        
        loadMoreBtn.innerHTML = `<span style="display: flex; align-items: center; justify-content: center; gap: 0.5rem;">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <polyline points="6 9 12 15 18 9"></polyline>
            </svg>
            Load More (${remaining} remaining)
        </span>`;
        loadMoreBtn.style.display = 'block';
    } else {
        if (loadMoreBtn) {
            loadMoreBtn.style.display = 'none';
        }
    }
}

/**
 * Render a single notification item
 */
function renderSingleNotification(notif, container) {
        const item = document.createElement('div');
        // Add priority class for VIP/Fast Track notifications
        const isPriority = notif.meta && (notif.meta.is_priority === true || notif.meta.is_priority === 'true' || notif.meta.is_priority == 1);
        item.className = 'activity-item' + (notif.read ? '' : ' notification-unread') + (isPriority ? ' notification-priority' : '');
        item.setAttribute('data-notification-id', notif.id);
        if (isPriority) {
            item.setAttribute('data-priority', 'true');
        }
        
        const iconClass = getNotificationIconClass(notif.type);
        const icon = getNotificationIcon(notif.type);
        
        // For message notifications, use a data attribute to store thread info
        const isMessageNotification = notif.type === 'message';
        const threadId = (notif.meta && notif.meta.related_id) ? notif.meta.related_id : '';
        
        // For review notifications, use a data attribute to store review info
        const isReviewNotification = notif.type === 'review';
        const reviewId = (notif.meta && notif.meta.related_id) ? notif.meta.related_id : '';
        // Get customer name from meta, or extract from notification message
        let reviewCustomerName = '';
        if (isReviewNotification) {
            if (notif.meta && notif.meta.customer_name) {
                reviewCustomerName = notif.meta.customer_name;
            } else if (notif.message) {
                // Extract customer name from notification message (format: "You received a new review from {customer_name}.")
                const match = notif.message.match(/from\s+([^.]+)\./i);
                if (match && match[1]) {
                    reviewCustomerName = match[1].trim();
                }
            }
        }
        
        // For new request notifications, use a data attribute to store request info
        const isNewRequestNotification = notif.type === 'new_request';
        let requestId = (notif.meta && notif.meta.request_id) ? notif.meta.request_id : '';
        let customerId = (notif.meta && notif.meta.customer_id) ? notif.meta.customer_id : '';
        let customerName = (notif.meta && notif.meta.customer_name) ? notif.meta.customer_name : '';
        
        // Check if this is a priority (VIP/Fast Track) notification
        const isPriorityNotification = notif.meta && (notif.meta.is_priority === true || notif.meta.is_priority === 'true' || notif.meta.is_priority == 1);
        
        // For cancelled/deleted request notifications, also use a data attribute to store request info
        const isRequestCancelledNotification = notif.type === 'request_cancelled' || notif.type === 'request_deleted';
        if (isRequestCancelledNotification) {
            // Try to extract request_id from meta or from notification message
            if (notif.meta && notif.meta.request_id) {
                requestId = notif.meta.request_id;
            } else if (notif.meta && notif.meta.related_id) {
                requestId = notif.meta.related_id;
            }
            if (notif.meta && notif.meta.customer_id) {
                customerId = notif.meta.customer_id;
            }
            if (notif.meta && notif.meta.customer_name) {
                customerName = notif.meta.customer_name;
            } else if (notif.message) {
                // Try to extract customer name from notification message (format: "Service request from {customer_name} has been cancelled.")
                const match = notif.message.match(/from\s+([^.]+)\s+has/i);
                if (match && match[1]) {
                    customerName = match[1].trim();
                }
            }
        }
        
        const linkClass = isMessageNotification ? 'notification-link message-notification-link' : 
                         (isReviewNotification ? 'notification-link review-notification-link' : 
                         (isNewRequestNotification || isRequestCancelledNotification ? 'notification-link request-notification-link' : 'notification-link'));
        const linkHref = (isMessageNotification || isReviewNotification || isNewRequestNotification || isRequestCancelledNotification) ? '#' : (notif.meta && notif.meta.link ? notif.meta.link : '#');
        let linkDataAttributes = '';
        if (isMessageNotification && threadId) {
            linkDataAttributes = `data-thread-id="${threadId}" data-notification-id="${notif.id}"`;
        } else if (isReviewNotification) {
            linkDataAttributes = `data-review-id="${reviewId}" data-customer-name="${reviewCustomerName}" data-notification-id="${notif.id}"`;
        } else if ((isNewRequestNotification || isRequestCancelledNotification) && requestId) {
            linkDataAttributes = `data-request-id="${requestId}" data-customer-id="${customerId}" data-customer-name="${customerName}" data-notification-id="${notif.id}"`;
        }
        
        // VIP/Fast Track badge HTML
        const priorityBadge = isPriorityNotification ? `<span class="vip-badge" style="display: inline-flex; align-items: center; gap: 0.25rem; padding: 0.2rem 0.6rem; background: linear-gradient(135deg, #ffd700, #ff8c00); color: #1a1a1a; font-size: 0.65rem; font-weight: 700; border-radius: 9999px; text-transform: uppercase; letter-spacing: 0.05em; margin-left: 0.5rem; box-shadow: 0 2px 8px rgba(255, 215, 0, 0.4);"><svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg> VIP</span>` : '';
        
        item.innerHTML = `
            <div class="activity-icon ${iconClass}${isPriorityNotification ? ' priority-icon' : ''}">
                ${icon}
            </div>
            <div class="activity-content">
                <p class="activity-text"><strong>${notif.title}</strong>${priorityBadge}</p>
                <p class="activity-description">${notif.message}</p>
                ${notif.meta && (notif.meta.link || isMessageNotification || isReviewNotification || isNewRequestNotification || isRequestCancelledNotification) ? `<a href="${linkHref}" class="${linkClass}" ${linkDataAttributes} style="color: hsl(var(--primary)); text-decoration: none; font-size: 0.875rem; margin-top: 0.5rem; display: inline-block; cursor: pointer;">${notif.meta.action_text || (isMessageNotification ? 'View Message' : (isReviewNotification ? 'View Review' : ((isNewRequestNotification || isRequestCancelledNotification) ? (isRequestCancelledNotification ? 'View Requests' : 'View') : 'View')))}</a>` : ''}
                <span class="activity-time">${formatTimeAgo(notif.timestamp)}</span>
            </div>
            ${!notif.read ? '<button class="notification-mark-read" data-notification-id="' + notif.id + '" title="Mark as read" style="background: none; border: none; color: hsl(var(--muted-foreground)); cursor: pointer; padding: 0.5rem; opacity: 0.6; transition: opacity 0.2s;"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"></polyline></svg></button>' : ''}
        `;
        
        container.appendChild(item);
}

/**
 * Attach event handlers for notification items (legacy wrapper for backwards compatibility)
 */
function attachNotificationEventHandlers() {
    const container = document.getElementById('notificationsList');
    if (!container) return;
    
    // Add click handlers for mark as read (only for items without handlers)
    container.querySelectorAll('.notification-mark-read:not([data-handler-attached])').forEach(btn => {
        btn.setAttribute('data-handler-attached', 'true');
        btn.addEventListener('click', function(e) {
            e.stopPropagation();
            const notifId = this.getAttribute('data-notification-id');
            markNotificationRead(notifId);
        });
    });
    
    // Add click handlers for message notification links
    container.querySelectorAll('.message-notification-link:not([data-handler-attached])').forEach(link => {
        link.setAttribute('data-handler-attached', 'true');
        link.addEventListener('click', handleMessageNotificationClick);
    });
    
    // Add click handlers for review notification links
    container.querySelectorAll('.review-notification-link:not([data-handler-attached])').forEach(link => {
        link.setAttribute('data-handler-attached', 'true');
        link.addEventListener('click', handleReviewNotificationClick);
    });
    
    // Add click handlers for request notification links
    container.querySelectorAll('.request-notification-link:not([data-handler-attached])').forEach(link => {
        link.setAttribute('data-handler-attached', 'true');
        link.addEventListener('click', handleRequestNotificationClick);
    });
}

// Handler functions for notification clicks (extracted from original inline handlers)
function handleMessageNotificationClick(e) {
    e.preventDefault();
    const threadId = this.getAttribute('data-thread-id');
    const notificationId = this.getAttribute('data-notification-id');
    
    if (!threadId) {
        console.error('Thread ID not found in notification');
        return;
    }
    
    // Mark notification as read
    if (notificationId) {
        markNotificationRead(notificationId);
    }
    
    // Switch to messages section (partner dashboard uses "messaging" instead of "messages")
    const messagesNav = document.querySelector('[data-section="messaging"]');
    if (messagesNav) {
        messagesNav.click();
        
        // After switching, open the conversation
        setTimeout(function() {
            // Get thread data to find other user info
            if (typeof loadConversations === 'function') {
                loadConversations();
            }
            
            // Wait a bit for conversations to load, then select the thread
            setTimeout(function() {
                // Try to select the conversation using selectConversation function
                if (typeof selectConversation === 'function') {
                    // First try to find the conversation item in the list
                    const conversationItem = document.querySelector(`.conversation-item[data-thread-id="${threadId}"]`);
                    if (conversationItem) {
                        conversationItem.click();
                    } else {
                        // If conversation item not found, try to load thread and get user info
                        const formData = new FormData();
                        formData.append('action', 'get_thread_messages');
                        formData.append('nonce', wheelfy.nonce);
                        formData.append('thread_id', threadId);
                        
                        fetch(wheelfy.ajaxUrl, {
                            method: 'POST',
                            body: formData
                        })
                        .then(response => response.json())
                        .then(data => {
                            if (data.success && data.data && data.data.thread) {
                                const thread = data.data.thread;
                                const otherUserId = thread.other_user_id || (thread.customer_id == wheelfy.userId ? thread.partner_id : thread.customer_id);
                                const otherUserName = thread.other_user_name || 'Partner';
                                const otherUserAvatar = thread.other_user_avatar || '';
                                selectConversation(threadId, otherUserId, otherUserName, otherUserAvatar);
                            }
                        })
                        .catch(error => {
                            console.error('Error loading thread:', error);
                        });
                    }
                }
            }, 800);
        }, 500);
    }
}

function handleReviewNotificationClick(e) {
    e.preventDefault();
    const reviewId = this.getAttribute('data-review-id');
    const customerName = this.getAttribute('data-customer-name');
    const notificationId = this.getAttribute('data-notification-id');
    
    // Mark notification as read
    if (notificationId) {
        markNotificationRead(notificationId);
    }
    
    // Switch to reviews section
    const reviewsNav = document.querySelector('[data-section="reviews"]');
    if (reviewsNav) {
        reviewsNav.click();
    }
}

function handleRequestNotificationClick(e) {
    e.preventDefault();
    const requestId = this.getAttribute('data-request-id');
    const notificationId = this.getAttribute('data-notification-id');
    
    // Mark notification as read
    if (notificationId) {
        markNotificationRead(notificationId);
    }
    
    // Switch to requests section
    const requestsNav = document.querySelector('[data-section="requests"]');
    if (requestsNav) {
        requestsNav.click();
    }
}

/**
 * Fetch notifications from server
 */
function fetchNotifications() {
    const formData = new FormData();
    formData.append('action', 'get_notifications');
    formData.append('nonce', wheelfy.nonce);
    formData.append('limit', '50');
    
    fetch(wheelfy.ajaxUrl, {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            renderNotifications(data.data.notifications);
            updateNotificationBadge(data.data.unread_count);
            lastNotificationCheck = Date.now();
        } else {
            console.error('Failed to fetch notifications:', data.data);
        }
    })
    .catch(error => {
        console.error('Error fetching notifications:', error);
    });
}

/**
 * Mark notification as read
 */
function markNotificationRead(notificationId) {
    const formData = new FormData();
    formData.append('action', 'mark_notification_read');
    formData.append('nonce', wheelfy.nonce);
    formData.append('notification_id', notificationId);
    
    fetch(wheelfy.ajaxUrl, {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Update badge
            if (data.data.unread_count !== undefined) {
                updateNotificationBadge(data.data.unread_count);
            }
            // Remove unread class
            const item = document.querySelector(`[data-notification-id="${notificationId}"]`);
            if (item) {
                item.classList.remove('notification-unread');
                const markReadBtn = item.querySelector('.notification-mark-read');
                if (markReadBtn) markReadBtn.remove();
            }
        }
    })
    .catch(error => {
        console.error('Error marking notification as read:', error);
    });
}

/**
 * Mark all notifications as read
 */
function markAllNotificationsRead() {
    const formData = new FormData();
    formData.append('action', 'mark_all_notifications_read');
    formData.append('nonce', wheelfy.nonce);
    
    fetch(wheelfy.ajaxUrl, {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            updateNotificationBadge(0);
            // Reload notifications
            fetchNotifications();
        }
    })
    .catch(error => {
        console.error('Error marking all notifications as read:', error);
    });
}

/**
 * Update notification badge count
 */
function updateNotificationBadge(count) {
    const badge = document.getElementById('notificationsBadgeCount');
    if (badge) {
        if (count > 0) {
            badge.textContent = count;
            badge.style.display = 'inline-flex';
        } else {
            badge.style.display = 'none';
        }
    }
    
    // Show/hide mark all as read button
    const markAllBtn = document.getElementById('markAllReadBtn');
    if (markAllBtn) {
        markAllBtn.style.display = count > 0 ? 'inline-flex' : 'none';
    }
}

/**
 * Start real-time notification polling
 */
function startNotificationPolling() {
    // Initial fetch
    fetchNotifications();
    
    // Poll every 30 seconds
    notificationPollInterval = setInterval(() => {
        fetchNotifications();
    }, 30000);
}

/**
 * Stop notification polling
 */
function stopNotificationPolling() {
    if (notificationPollInterval) {
        clearInterval(notificationPollInterval);
        notificationPollInterval = null;
    }
}

// Initialize notification system when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    // Start polling
    startNotificationPolling();
    
    // Mark all as read button
    const markAllBtn = document.getElementById('markAllReadBtn');
    if (markAllBtn) {
        markAllBtn.addEventListener('click', function() {
            markAllNotificationsRead();
        });
    }
    
    // Stop polling when page is hidden (browser optimization)
    document.addEventListener('visibilitychange', function() {
        if (document.hidden) {
            stopNotificationPolling();
        } else {
            startNotificationPolling();
        }
    });
});

// ============================================================================
// MESSAGING SYSTEM (Partner Dashboard)
// ============================================================================
// Note: Global variables (messagePollInterval, currentThreadId, attachmentIds, isPollingActive)
// are declared at the top of the script to prevent redeclaration errors

function formatMessageTime(timestamp) {
    if (!timestamp) return 'Just now';
    const now = Math.floor(Date.now() / 1000);
    const diff = now - timestamp;
    if (diff < 60) return 'Just now';
    if (diff < 3600) return Math.floor(diff / 60) + 'm ago';
    if (diff < 86400) return Math.floor(diff / 3600) + 'h ago';
    if (diff < 604800) return Math.floor(diff / 86400) + 'd ago';
    return new Date(timestamp * 1000).toLocaleDateString();
}

function renderConversations(conversations, searchTerm = '') {
    const container = document.getElementById('conversationsList');
    const loading = document.getElementById('conversationsLoading');
    const empty = document.getElementById('conversationsEmpty');
    if (!container) return;
    if (loading) loading.style.display = 'none';
    if (!conversations || conversations.length === 0) {
        // Determine the message based on search
        let title, description;
        if (searchTerm && searchTerm.trim() !== '') {
            title = 'No User Found';
            description = `No customers found matching "${searchTerm}". Try a different search term.`;
        } else {
            title = 'No Conversations';
            description = 'Start a conversation with a customer after accepting their request.';
        }
        
        // Create empty state HTML dynamically
        container.innerHTML = `
            <div class="empty-state" id="conversationsEmpty" style="display: block;">
                <div class="empty-state-icon">
                    <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M21 15C21 15.5304 20.7893 16.0391 20.4142 16.4142C20.0391 16.7893 19.5304 17 19 17H7L3 21V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H19C19.5304 3 20.0391 3.21071 20.4142 3.58579C20.7893 3.96086 21 4.46957 21 5V15Z"></path>
                    </svg>
                </div>
                <h3 class="empty-state-title">${title}</h3>
                <p class="empty-state-text">${description}</p>
            </div>
        `;
        return;
    }
    if (empty) empty.style.display = 'none';
    
    // REAL-TIME DELETE SYNC: Check for deleted conversations in current DOM
    // Get all currently rendered conversation IDs
    const renderedConversationElements = container.querySelectorAll('.conversation-item[data-thread-id]');
    const renderedConversationIds = new Set();
    renderedConversationElements.forEach(el => {
        const threadId = el.getAttribute('data-thread-id');
        if (threadId) renderedConversationIds.add(threadId);
    });
    
    // Get conversation IDs from server data
    const serverConversationIds = new Set();
    conversations.forEach(conv => {
        if (conv.thread_id) serverConversationIds.add(conv.thread_id);
    });
    
    // Find conversations that are in DOM but not in server data (deleted)
    const deletedConversationIds = new Set();
    renderedConversationIds.forEach(threadId => {
        if (!serverConversationIds.has(threadId)) {
            deletedConversationIds.add(threadId);
        }
    });
    
    // Remove deleted conversations from DOM instantly (real-time sync)
    if (deletedConversationIds.size > 0) {
        console.log('Real-time conversation delete sync: Detected', deletedConversationIds.size, 'deleted conversation(s)');
        deletedConversationIds.forEach(threadId => {
            const conversationElement = container.querySelector(`.conversation-item[data-thread-id="${threadId}"]`);
            if (conversationElement) {
                console.log('Real-time conversation delete sync: Removing conversation from DOM - Thread ID:', threadId);
                
                // Check if this conversation is currently open
                const isCurrentlyOpen = currentThreadId === threadId;
                
                // Add fade-out animation
                conversationElement.style.transition = 'opacity 0.3s ease, transform 0.3s ease, height 0.3s ease, margin 0.3s ease';
                conversationElement.style.opacity = '0';
                conversationElement.style.transform = 'translateX(-20px)';
                conversationElement.style.overflow = 'hidden';
                
                // Remove from DOM after animation
                setTimeout(() => {
                    conversationElement.remove();
                    console.log('Real-time conversation delete sync: Conversation removed - Thread ID:', threadId);
                    
                    // If this conversation was open, close the chat panel
                    if (isCurrentlyOpen) {
                        document.getElementById('chatPanel').style.display = 'none';
                        document.getElementById('chatPlaceholder').style.display = 'flex';
                        currentThreadId = null;
                        
                        // Clear messages
                        const messageContainer = document.getElementById('chatMessages');
                        if (messageContainer) {
                            messageContainer.innerHTML = '<div class="empty-state" style="text-align: center; padding: 3rem 2rem; color: hsl(var(--muted-foreground));"><div style="font-size: 3rem; margin-bottom: 1rem;">💬</div><h3 style="margin: 0 0 0.5rem; font-size: 1.125rem; font-weight: 600; color: hsl(var(--foreground));">Conversation deleted</h3><p style="margin: 0; font-size: 0.9375rem;">This conversation has been deleted.</p></div>';
                        }
                    }
                    
                    // Check if conversations list is now empty
                    const remainingConversations = container.querySelectorAll('.conversation-item');
                    if (remainingConversations.length === 0) {
                        if (empty && empty instanceof Node) {
                            try {
                                empty.style.display = 'block';
                                // Only append if not already a child
                                if (!container.contains(empty)) {
                                    container.appendChild(empty);
                                }
                            } catch (e) {
                                console.error('Error appending empty state after deletion:', e);
                            }
                        }
                    }
                }, 300);
            }
        });
    }
    
    container.innerHTML = '';
    conversations.forEach(conv => {
        const item = document.createElement('div');
        item.className = 'conversation-item';
        item.setAttribute('data-thread-id', conv.thread_id);
        item.setAttribute('data-other-user-id', conv.other_user_id || '');
        if (conv.thread_id === currentThreadId) item.classList.add('active');
        const avatarInitial = conv.other_user_name ? conv.other_user_name.charAt(0).toUpperCase() : '?';
        const lastMessageText = conv.last_message ? conv.last_message.text : 'No messages yet';
        const lastMessageTime = conv.last_message ? formatMessageTime(conv.last_message.timestamp) : '';
        const isFromMe = conv.last_message && conv.last_message.sender_id === parseInt(wheelfy.userId || '0');
        
        // Create avatar HTML - use image if available, otherwise use initial
        let avatarHtml = '';
        if (conv.other_user_avatar) {
            avatarHtml = `<div class="conversation-avatar conversation-avatar-image"><img src="${conv.other_user_avatar}" alt="${conv.other_user_name || 'User'}" onerror="this.parentElement.innerHTML='${avatarInitial}'; this.parentElement.classList.remove('conversation-avatar-image');"></div>`;
        } else {
            avatarHtml = `<div class="conversation-avatar">${avatarInitial}</div>`;
        }
        
        // Create conversation delete button
        const deleteBtn = document.createElement('button');
        deleteBtn.className = 'conversation-delete-btn';
        deleteBtn.type = 'button';
        deleteBtn.setAttribute('aria-label', `Delete conversation with ${conv.other_user_name || 'Unknown'}`);
        deleteBtn.setAttribute('title', 'Delete conversation');
        deleteBtn.innerHTML = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>`;
        deleteBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            handleDeleteConversation(conv.thread_id);
        });
        deleteBtn.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                e.stopPropagation();
                handleDeleteConversation(conv.thread_id);
            }
        });
        
        item.innerHTML = `${avatarHtml}<div class="conversation-info"><div class="conversation-name">${conv.other_user_name || 'Unknown'}</div><div class="conversation-preview">${isFromMe ? 'You: ' : ''}${lastMessageText}</div></div><div class="conversation-meta"><div class="conversation-time">${lastMessageTime}</div>${conv.unread_count > 0 ? `<div class="conversation-unread" aria-label="${conv.unread_count} unread messages">${conv.unread_count}</div>` : ''}</div>`;
        item.appendChild(deleteBtn);
        
        // Make conversation item keyboard accessible
        item.setAttribute('role', 'button');
        item.setAttribute('tabindex', '0');
        item.setAttribute('aria-label', `Conversation with ${conv.other_user_name || 'Unknown'}. ${isFromMe ? 'You' : conv.other_user_name || 'They'}: ${lastMessageText}. ${lastMessageTime}. ${conv.unread_count > 0 ? conv.unread_count + ' unread messages' : 'No unread messages'}`);
        
        // Click handler
        const handleSelect = () => selectConversation(conv.thread_id, conv.other_user_id, conv.other_user_name, conv.other_user_avatar);
        item.addEventListener('click', handleSelect);
        
        // Keyboard handler (Enter or Space)
        item.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                handleSelect();
            }
        });
        
        container.appendChild(item);
    });
}

// Store last rendered message IDs to prevent unnecessary re-renders
let lastRenderedMessageIds = new Set();
let isScrolledToBottom = true;

// Helper function to escape HTML and preserve newlines
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Reply functionality
let replyingToMessageId = null;
let replyingToMessageData = null;

function handleReplyToMessage(msg, senderName) {
    // Use actual sender name from message data, not the passed parameter
    const actualSenderName = msg.sender_name || senderName || 'Unknown User';
    
    replyingToMessageId = msg.id;
    replyingToMessageData = {
        id: msg.id,
        sender_name: actualSenderName,
        message_text: msg.message_text || ''
    };
    
    const replyPreviewBar = document.getElementById('replyPreviewBar');
    const replyPreviewName = document.getElementById('replyPreviewName');
    const replyPreviewText = document.getElementById('replyPreviewText');
    const replyToMessageId = document.getElementById('replyToMessageId');
    
    if (replyPreviewBar && replyPreviewName && replyPreviewText && replyToMessageId) {
        replyPreviewName.textContent = actualSenderName;
        const previewText = (msg.message_text || '').length > 60 
            ? (msg.message_text || '').substring(0, 60) + '...' 
            : (msg.message_text || '');
        replyPreviewText.textContent = previewText || '(No text)';
        replyToMessageId.value = msg.id;
        replyPreviewBar.style.display = 'flex';
        
        const messageInput = document.getElementById('messageInput');
        if (messageInput) {
            messageInput.focus();
        }
        
        const statusAnnouncements = document.getElementById('chatStatusAnnouncements');
        if (statusAnnouncements) {
            statusAnnouncements.textContent = `Replying to message from ${actualSenderName}`;
        }
    }
}

function cancelReply() {
    replyingToMessageId = null;
    replyingToMessageData = null;
    
    const replyPreviewBar = document.getElementById('replyPreviewBar');
    const replyToMessageId = document.getElementById('replyToMessageId');
    
    if (replyPreviewBar) {
        replyPreviewBar.style.display = 'none';
    }
    if (replyToMessageId) {
        replyToMessageId.value = '';
    }
    
    const statusAnnouncements = document.getElementById('chatStatusAnnouncements');
    if (statusAnnouncements) {
        statusAnnouncements.textContent = 'Reply cancelled';
    }
}

function scrollToMessage(messageId) {
    const container = document.getElementById('chatMessages');
    if (!container) return;
    
    const targetMessage = container.querySelector(`[data-message-id="${messageId}"]`);
    if (targetMessage) {
        targetMessage.scrollIntoView({ behavior: 'smooth', block: 'center' });
        targetMessage.classList.add('highlight-message');
        
        setTimeout(() => {
            targetMessage.classList.remove('highlight-message');
        }, 2000);
        
        targetMessage.setAttribute('tabindex', '-1');
        targetMessage.focus();
    }
}

window.scrollToMessage = scrollToMessage;

// ============================================
// MESSAGE CONTEXT MENU (Right-click menu)
// ============================================
let activeContextMenu = null;
let contextMenuMessageData = null;

// Create and show context menu on right-click
function showMessageContextMenu(event, messageElement, messageData) {
    event.preventDefault();
    event.stopPropagation();
    
    // Remove any existing context menu
    hideMessageContextMenu();
    
    const isDeleted = messageElement.classList.contains('message-deleted');
    if (isDeleted) return; // Don't show menu for deleted messages
    
    const currentUserId = parseInt(wheelfy.userId || '0');
    const isOwnMessage = parseInt(messageData.sender_id || '0') === currentUserId;
    
    // Store message data for actions
    contextMenuMessageData = messageData;
    
    // Create context menu
    const menu = document.createElement('div');
    menu.className = 'message-context-menu';
    menu.setAttribute('role', 'menu');
    menu.setAttribute('aria-label', 'Message options');
    
    // Reply option (always available for non-deleted messages)
    const replyItem = document.createElement('button');
    replyItem.className = 'message-context-menu-item reply-item';
    replyItem.setAttribute('role', 'menuitem');
    replyItem.innerHTML = `
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="9 10 4 15 9 20"></polyline>
            <path d="M20 4v7a4 4 0 0 1-4 4H4"></path>
        </svg>
        <span>Reply</span>
    `;
    replyItem.addEventListener('click', () => {
        handleReplyToMessage(contextMenuMessageData, contextMenuMessageData.sender_name);
        hideMessageContextMenu();
    });
    menu.appendChild(replyItem);
    
    // Delete option (only for own messages)
    if (isOwnMessage) {
        const deleteItem = document.createElement('button');
        deleteItem.className = 'message-context-menu-item delete-item';
        deleteItem.setAttribute('role', 'menuitem');
        deleteItem.innerHTML = `
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <polyline points="3 6 5 6 21 6"></polyline>
                <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
            </svg>
            <span>Delete</span>
        `;
        deleteItem.addEventListener('click', () => {
            const threadId = contextMenuMessageData.thread_id || currentThreadId;
            handleDeleteMessage(contextMenuMessageData.id, threadId);
            hideMessageContextMenu();
        });
        menu.appendChild(deleteItem);
    }
    
    // Position the menu at cursor position
    document.body.appendChild(menu);
    
    // Get menu dimensions
    const menuRect = menu.getBoundingClientRect();
    const viewportWidth = window.innerWidth;
    const viewportHeight = window.innerHeight;
    
    // Calculate position (ensure menu stays within viewport)
    let left = event.clientX;
    let top = event.clientY;
    
    if (left + menuRect.width > viewportWidth) {
        left = viewportWidth - menuRect.width - 10;
    }
    if (top + menuRect.height > viewportHeight) {
        top = viewportHeight - menuRect.height - 10;
    }
    
    menu.style.left = left + 'px';
    menu.style.top = top + 'px';
    
    activeContextMenu = menu;
    
    // Focus first item for accessibility
    const firstItem = menu.querySelector('.message-context-menu-item');
    if (firstItem) {
        firstItem.focus();
    }
}

// Hide context menu
function hideMessageContextMenu() {
    if (activeContextMenu) {
        activeContextMenu.remove();
        activeContextMenu = null;
        contextMenuMessageData = null;
    }
}

// Close context menu on click outside or Escape key
document.addEventListener('click', (e) => {
    if (activeContextMenu && !activeContextMenu.contains(e.target)) {
        hideMessageContextMenu();
    }
});

document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && activeContextMenu) {
        hideMessageContextMenu();
    }
});

// Close context menu on scroll
document.addEventListener('scroll', hideMessageContextMenu, true);

// Delete message handler
function handleDeleteMessage(messageId, threadId) {
    console.log('handleDeleteMessage called - Message ID:', messageId, 'Thread ID:', threadId);
    
    if (!messageId || !threadId) {
        console.error('Delete message: Missing messageId or threadId');
        alert('Error: Missing message or conversation information.');
        return;
    }
    
    if (!confirm('Are you sure you want to delete this message? This action cannot be undone.')) {
        return;
    }
    
    // Find the message element in DOM
    const messageContainer = document.getElementById('chatMessages');
    if (!messageContainer) {
        console.error('Delete message: Message container not found');
        return;
    }
    
    const messageElement = messageContainer.querySelector(`[data-message-id="${messageId}"]`);
    if (!messageElement) {
        console.error('Delete message: Message element not found in DOM');
        // Fallback to reload if element not found
        if (typeof loadThreadMessages === 'function') {
            loadThreadMessages(threadId);
        }
        return;
    }
    
    // Disable delete button to prevent double clicks
    const deleteBtn = messageElement.querySelector('.message-delete-btn');
    if (deleteBtn) {
        deleteBtn.disabled = true;
        deleteBtn.style.opacity = '0.5';
        deleteBtn.style.cursor = 'not-allowed';
    }
    
    console.log('Delete message: Sending AJAX request');
    
    const formData = new FormData();
    formData.append('action', 'delete_message');
    formData.append('nonce', wheelfy.nonce);
    formData.append('message_id', messageId);
    formData.append('thread_id', threadId);
    
    fetch(wheelfy.ajaxUrl, { 
        method: 'POST', 
        body: formData 
    })
    .then(response => {
        console.log('Delete message: Response received', response);
        return response.json();
    })
    .then(data => {
        console.log('Delete message: Response data', data);
        if (data.success) {
            console.log('Delete message: Success - Removing message from DOM');
            
            // Get message text for conversation preview update
            const messageTextElement = messageElement.querySelector('p');
            const messageText = messageTextElement ? messageTextElement.textContent.trim() : '';
            
            // Check if this is the last message by checking all message bubbles
            const allMessageBubbles = messageContainer.querySelectorAll('.message-bubble');
            const isLastMessage = allMessageBubbles.length === 1 || 
                                 messageElement === allMessageBubbles[allMessageBubbles.length - 1];
            
            // Add fade-out animation
            messageElement.style.transition = 'opacity 0.3s ease, transform 0.3s ease, height 0.3s ease, margin 0.3s ease';
            messageElement.style.opacity = '0';
            messageElement.style.transform = 'translateX(-20px)';
            messageElement.style.overflow = 'hidden';
            
            // Remove from DOM after animation
            setTimeout(() => {
                messageElement.remove();
                console.log('Delete message: Message removed from DOM - Message ID:', messageId);
                
                // Check if messages container is now empty
                const remainingMessages = messageContainer.querySelectorAll('.message-bubble');
                if (remainingMessages.length === 0) {
                    messageContainer.innerHTML = '<div class="empty-state" style="text-align: center; padding: 3rem 2rem; color: hsl(var(--muted-foreground));"><div style="font-size: 3rem; margin-bottom: 1rem;">💬</div><h3 style="margin: 0 0 0.5rem; font-size: 1.125rem; font-weight: 600; color: hsl(var(--foreground));">No messages yet</h3><p style="margin: 0; font-size: 0.9375rem;">Start the conversation!</p></div>';
                }
                
                // Update conversation list preview if this was the last message
                if (isLastMessage && messageText) {
                    updateConversationPreview(threadId, messageText);
                }
            }, 300);
            
            // Announce to screen readers
            const statusAnnouncements = document.getElementById('chatStatusAnnouncements');
            if (statusAnnouncements) {
                statusAnnouncements.textContent = 'Message deleted successfully';
            }
        } else {
            // Re-enable delete button on error
            if (deleteBtn) {
                deleteBtn.disabled = false;
                deleteBtn.style.opacity = '';
                deleteBtn.style.cursor = '';
            }
            
            const errorMsg = data.data && data.data.message ? data.data.message : 'Failed to delete message';
            console.error('Delete message: Error response', errorMsg);
            alert(errorMsg);
        }
    })
    .catch(error => {
        // Re-enable delete button on error
        if (deleteBtn) {
            deleteBtn.disabled = false;
            deleteBtn.style.opacity = '';
            deleteBtn.style.cursor = '';
        }
        
        console.error('Delete message: Fetch error', error);
        alert('An error occurred while deleting the message. Please check the console for details.');
    });
}

// Helper function to update conversation preview in conversation list
function updateConversationPreview(threadId, deletedMessageText) {
    const conversationItem = document.querySelector(`.conversation-item[data-thread-id="${threadId}"]`);
    if (!conversationItem) {
        console.log('Delete message: Conversation item not found for preview update');
        return;
    }
    
    const previewElement = conversationItem.querySelector('.conversation-preview');
    if (!previewElement) {
        console.log('Delete message: Preview element not found');
        return;
    }
    
    // Get all remaining messages to find the new last message
    const messageContainer = document.getElementById('chatMessages');
    if (!messageContainer) return;
    
    const allMessages = messageContainer.querySelectorAll('.message-bubble');
    if (allMessages.length === 0) {
        // No messages left
        previewElement.textContent = 'No messages yet';
        return;
    }
    
    // Get the last remaining message
    const lastMessage = allMessages[allMessages.length - 1];
    const lastMessageTextElement = lastMessage.querySelector('p');
    const lastMessageTimeElement = lastMessage.querySelector('.message-time');
    
    if (lastMessageTextElement) {
        const lastMessageText = lastMessageTextElement.textContent.trim();
        const isFromMe = lastMessage.classList.contains('own-message');
        const previewText = lastMessageText.length > 50 ? lastMessageText.substring(0, 50) + '...' : lastMessageText;
        previewElement.textContent = isFromMe ? `You: ${previewText}` : previewText;
    }
    
    // Update timestamp if available
    if (lastMessageTimeElement) {
        const timeElement = conversationItem.querySelector('.conversation-time');
        if (timeElement) {
            const timeText = lastMessageTimeElement.textContent.trim().split(' ')[0]; // Get just the time part
            timeElement.textContent = timeText;
        }
    }
    
    console.log('Delete message: Conversation preview updated');
}

// Delete conversation handler
function handleDeleteConversation(threadId) {
    console.log('handleDeleteConversation called - Thread ID:', threadId);
    
    if (!threadId) {
        console.error('Delete conversation: Missing threadId');
        alert('Error: Missing conversation information.');
        return;
    }
    
    if (!confirm('Are you sure you want to delete this conversation? It will be removed from your conversation list.')) {
        return;
    }
    
    // Find the conversation item in DOM
    const conversationItem = document.querySelector(`.conversation-item[data-thread-id="${threadId}"]`);
    if (!conversationItem) {
        console.error('Delete conversation: Conversation item not found in DOM');
        return;
    }
    
    // Disable delete button to prevent double clicks
    const deleteBtn = conversationItem.querySelector('.conversation-delete-btn');
    if (deleteBtn) {
        deleteBtn.disabled = true;
        deleteBtn.style.opacity = '0.5';
        deleteBtn.style.cursor = 'not-allowed';
    }
    
    console.log('Delete conversation: Sending AJAX request');
    
    const formData = new FormData();
    formData.append('action', 'delete_conversation');
    formData.append('nonce', wheelfy.nonce);
    formData.append('thread_id', threadId);
    
    fetch(wheelfy.ajaxUrl, { 
        method: 'POST', 
        body: formData 
    })
    .then(response => {
        console.log('Delete conversation: Response received', response);
        return response.json();
    })
    .then(data => {
        console.log('Delete conversation: Response data', data);
        if (data.success) {
            console.log('Delete conversation: Success - Removing conversation from DOM');
            
            // Check if this conversation is currently open
            const isCurrentlyOpen = currentThreadId === threadId;
            
            // Add fade-out animation
            conversationItem.style.transition = 'opacity 0.3s ease, transform 0.3s ease, height 0.3s ease, margin 0.3s ease';
            conversationItem.style.opacity = '0';
            conversationItem.style.transform = 'translateX(-20px)';
            conversationItem.style.overflow = 'hidden';
            
            // Remove from DOM after animation
            setTimeout(() => {
                conversationItem.remove();
                console.log('Delete conversation: Conversation removed from DOM - Thread ID:', threadId);
                
                // If this conversation was open, close the chat panel
                if (isCurrentlyOpen) {
                    document.getElementById('chatPanel').style.display = 'none';
                    document.getElementById('chatPlaceholder').style.display = 'flex';
                    currentThreadId = null;
                    
                    // Clear messages
                    const messageContainer = document.getElementById('chatMessages');
                    if (messageContainer) {
                        messageContainer.innerHTML = '<div class="empty-state" style="text-align: center; padding: 3rem 2rem; color: hsl(var(--muted-foreground));"><div style="font-size: 3rem; margin-bottom: 1rem;">💬</div><h3 style="margin: 0 0 0.5rem; font-size: 1.125rem; font-weight: 600; color: hsl(var(--foreground));">Conversation deleted</h3><p style="margin: 0; font-size: 0.9375rem;">This conversation has been deleted.</p></div>';
                    }
                }
                
                // Check if conversations list is now empty
                const conversationsList = document.getElementById('conversationsList');
                if (conversationsList) {
                    const remainingConversations = conversationsList.querySelectorAll('.conversation-item');
                    if (remainingConversations.length === 0) {
                        const empty = document.getElementById('conversationsEmpty');
                        if (empty) {
                            empty.style.display = 'block';
                            conversationsList.appendChild(empty);
                        }
                    }
                }
            }, 300);
            
            // Announce to screen readers
            const statusAnnouncements = document.getElementById('chatStatusAnnouncements');
            if (statusAnnouncements) {
                statusAnnouncements.textContent = 'Conversation deleted successfully';
            }
        } else {
            // Re-enable delete button on error
            if (deleteBtn) {
                deleteBtn.disabled = false;
                deleteBtn.style.opacity = '';
                deleteBtn.style.cursor = '';
            }
            
            const errorMsg = data.data && data.data.message ? data.data.message : 'Failed to delete conversation';
            console.error('Delete conversation: Error response', errorMsg);
            alert(errorMsg);
        }
    })
    .catch(error => {
        // Re-enable delete button on error
        if (deleteBtn) {
            deleteBtn.disabled = false;
            deleteBtn.style.opacity = '';
            deleteBtn.style.cursor = '';
        }
        
        console.error('Delete conversation: Fetch error', error);
        alert('An error occurred while deleting the conversation. Please check the console for details.');
    });
}

function renderMessages(messages, thread) {
    const container = document.getElementById('chatMessages');
    const loading = document.getElementById('messagesLoading');
    if (!container) return;
    if (loading) loading.style.display = 'none';
    
    // Get current thread ID
    const threadId = document.getElementById('currentThreadId') ? document.getElementById('currentThreadId').value : '';
    
    // Check if we're scrolled to bottom before updating
    const wasScrolledToBottom = container.scrollHeight - container.scrollTop <= container.clientHeight + 50;
    
    if (!messages || messages.length === 0) {
        container.innerHTML = '<div class="empty-state" style="text-align: center; padding: 3rem 2rem; color: hsl(var(--muted-foreground));"><div style="font-size: 3rem; margin-bottom: 1rem;">💬</div><h3 style="margin: 0 0 0.5rem; font-size: 1.125rem; font-weight: 600; color: hsl(var(--foreground));">No messages yet</h3><p style="margin: 0; font-size: 0.9375rem;">Start the conversation!</p></div>';
        lastRenderedMessageIds.clear();
        return;
    }
    
    // REAL-TIME DELETE SYNC: Check for deleted messages in current DOM
    // Get all currently rendered message IDs
    const renderedMessageElements = container.querySelectorAll('.message-bubble[data-message-id]');
    const renderedMessageIds = new Set();
    renderedMessageElements.forEach(el => {
        const msgId = el.getAttribute('data-message-id');
        if (msgId) renderedMessageIds.add(msgId);
    });
    
    // Check which messages are now deleted (were in DOM but now marked as deleted in data)
    const deletedMessageIds = new Set();
    messages.forEach(msg => {
        const msgId = msg.id || `${msg.sender_id}_${msg.created_timestamp}`;
        if (renderedMessageIds.has(msgId) && msg.is_deleted === true) {
            deletedMessageIds.add(msgId);
        }
    });
    
    // REAL-TIME DELETE SYNC: Remove deleted messages from DOM instantly
    if (deletedMessageIds.size > 0) {
        console.log('Real-time delete sync: Detected', deletedMessageIds.size, 'deleted message(s)');
        deletedMessageIds.forEach(msgId => {
            const messageElement = container.querySelector(`[data-message-id="${msgId}"]`);
            if (messageElement && !messageElement.classList.contains('message-deleted')) {
                console.log('Real-time delete sync: Removing message from DOM - Message ID:', msgId);
                
                // Update any reply containers that reference this deleted message
                const replyContainers = container.querySelectorAll(`[data-parent-message-id="${msgId}"]`);
                replyContainers.forEach(replyContainer => {
                    const unavailableDiv = replyContainer.querySelector('.message-reply-unavailable');
                    if (!unavailableDiv) {
                        replyContainer.innerHTML = '<div class="message-reply-unavailable">Message deleted</div>';
                        console.log('Real-time delete sync: Updated reply container for deleted parent message');
                    }
                });
                
                // Add fade-out animation
                messageElement.style.transition = 'opacity 0.3s ease, transform 0.3s ease, height 0.3s ease, margin 0.3s ease';
                messageElement.style.opacity = '0';
                messageElement.style.transform = 'translateX(-20px)';
                messageElement.style.overflow = 'hidden';
                
                // Remove from DOM after animation
                setTimeout(() => {
                    messageElement.remove();
                    console.log('Real-time delete sync: Message removed - Message ID:', msgId);
                    
                    // Check if messages container is now empty
                    const remainingMessages = container.querySelectorAll('.message-bubble');
                    if (remainingMessages.length === 0) {
                        container.innerHTML = '<div class="empty-state" style="text-align: center; padding: 3rem 2rem; color: hsl(var(--muted-foreground));"><div style="font-size: 3rem; margin-bottom: 1rem;">💬</div><h3 style="margin: 0 0 0.5rem; font-size: 1.125rem; font-weight: 600; color: hsl(var(--foreground));">No messages yet</h3><p style="margin: 0; font-size: 0.9375rem;">Start the conversation!</p></div>';
                    }
                    
                    // Update conversation preview if this was the last message
                    updateConversationPreview(threadId, '');
                }, 300);
            }
        });
    }
    
    // Create a set of current message IDs
    const currentMessageIds = new Set();
    messages.forEach(msg => {
        if (msg.id) currentMessageIds.add(msg.id);
        else if (msg.created_timestamp && msg.sender_id) {
            currentMessageIds.add(`${msg.sender_id}_${msg.created_timestamp}`);
        }
    });
    
    // Check if messages have actually changed
    const messagesChanged = currentMessageIds.size !== lastRenderedMessageIds.size ||
        ![...currentMessageIds].every(id => lastRenderedMessageIds.has(id));
    
    if (!messagesChanged && container.children.length > 0 && deletedMessageIds.size === 0) {
        // Only update read status and timestamps without full re-render
        // But if there are deleted messages, we need to re-render to show deleted state
        return;
    }
    
    // Use DocumentFragment for better performance
    const fragment = document.createDocumentFragment();
    const currentUserId = parseInt(wheelfy.userId || '0');
    
    messages.forEach((msg, index) => {
        const msgId = msg.id || `${msg.sender_id}_${msg.created_timestamp}`;
        const isNewMessage = !lastRenderedMessageIds.has(msgId);
        
        const bubble = document.createElement('div');
        const msgSenderId = parseInt(msg.sender_id || '0');
        
        // Logged-in user's messages = RIGHT side, Other user's messages = LEFT side
        const isOwnMessage = msgSenderId === currentUserId;
        
        // Set bubble class based on sender perspective
        bubble.className = `message-bubble ${isOwnMessage ? 'own-message' : 'other-message'}`;
        
        // Only animate new messages
        if (!isNewMessage) {
            bubble.style.animation = 'none';
        }
        
        // Add data attribute for tracking
        bubble.setAttribute('data-message-id', msgId);
        
        // Add ARIA attributes for screen readers
        // Get actual sender name from message data
        const actualSenderName = msg.sender_name || (isOwnMessage ? 'You' : (thread && thread.other_user_name ? thread.other_user_name : 'Other user'));
        const senderName = isOwnMessage ? 'You' : actualSenderName;
        const timeText = formatMessageTime(msg.created_timestamp);
        const readStatus = msg.read ? 'read' : 'sent';
        bubble.setAttribute('role', 'article');
        bubble.setAttribute('aria-label', `Message from ${senderName}, ${timeText}, ${readStatus}`);
        
        // Add right-click context menu handler
        const messageDataForContext = {
            id: msg.id,
            sender_id: msg.sender_id,
            sender_name: actualSenderName,
            message_text: msg.message_text || '',
            thread_id: threadId
        };
        bubble.addEventListener('contextmenu', (e) => {
            showMessageContextMenu(e, bubble, messageDataForContext);
        });
        
        let attachmentsHtml = '';
        if (msg.attachment_urls && msg.attachment_urls.length > 0) {
            attachmentsHtml = '<div class="message-attachments" style="margin-top: 0.5rem;" role="group" aria-label="Message attachments">';
            msg.attachment_urls.forEach((att, attIndex) => {
                if (att.type && att.type.startsWith('image/')) {
                    attachmentsHtml += `<img src="${att.url}" alt="${att.name || 'Image attachment'}" class="message-image-clickable" data-image-url="${att.url}" data-image-name="${att.name || 'image'}" style="max-width: 200px; border-radius: 0.5rem; display: block; cursor: pointer; transition: opacity 0.2s;" loading="lazy" tabindex="0" role="button" aria-label="View image: ${att.name || 'image'}" onmouseover="this.style.opacity='0.8'" onmouseout="this.style.opacity='1'">`;
                } else {
                    attachmentsHtml += `<div style="padding: 0.5rem; background: hsl(var(--muted) / 0.3); border-radius: 0.5rem; margin-top: 0.25rem;"><a href="${att.url}" target="_blank" style="color: hsl(var(--primary)); text-decoration: none; display: flex; align-items: center; gap: 0.5rem;" aria-label="Download attachment: ${att.name}">📎 <span>${att.name}</span></a></div>`;
                }
            });
            attachmentsHtml += '</div>';
        }
        
        // Add reply button
        const replyBtn = document.createElement('button');
        replyBtn.className = 'message-reply-btn';
        replyBtn.type = 'button';
        replyBtn.setAttribute('aria-label', `Reply to message from ${senderName}`);
        replyBtn.setAttribute('title', 'Reply');
        replyBtn.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 10 4 15 9 20"></polyline><path d="M20 4v7a4 4 0 0 1-4 4H4"></path></svg>`;
        replyBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            handleReplyToMessage(msg, senderName);
        });
        replyBtn.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                e.stopPropagation();
                handleReplyToMessage(msg, senderName);
            }
        });
        
        // Add reply container if this message is a reply
        let replyContainer = null;
        if (msg.parent_message_id) {
            if (msg.parent_message && !msg.parent_message.deleted) {
                // Parent message exists and is not deleted
                const parentSenderName = msg.parent_message.sender_name || 'Unknown User';
                const parentText = msg.parent_message.message_text || '';
                const escapedParentText = escapeHtml(parentText);
                const truncatedText = parentText.length > 100 ? parentText.substring(0, 100) + '...' : parentText;
                const escapedTruncatedText = escapeHtml(truncatedText);
                replyContainer = document.createElement('div');
                replyContainer.className = 'message-reply-container';
                replyContainer.setAttribute('role', 'button');
                replyContainer.setAttribute('tabindex', '0');
                replyContainer.setAttribute('data-parent-message-id', msg.parent_message_id);
                replyContainer.setAttribute('aria-label', `Reply to message from ${parentSenderName}: ${escapedParentText}`);
                replyContainer.innerHTML = `<div class="message-reply-sender">${escapeHtml(parentSenderName)}</div><div class="message-reply-text">${escapedTruncatedText}</div>`;
                replyContainer.addEventListener('click', () => scrollToMessage(msg.parent_message_id));
                replyContainer.addEventListener('keydown', (e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        scrollToMessage(msg.parent_message_id);
                    }
                });
            } else {
                // Parent message deleted or not found
                replyContainer = document.createElement('div');
                replyContainer.className = 'message-reply-container';
                replyContainer.innerHTML = '<div class="message-reply-unavailable">Message deleted</div>';
            }
        }
        
        // Check if message is deleted
        const isDeleted = msg.is_deleted === true;
        
        // Add delete button (only for own messages that are not deleted)
        let deleteBtn = null;
        if (isOwnMessage && !isDeleted) {
            deleteBtn = document.createElement('button');
            deleteBtn.className = 'message-delete-btn';
            deleteBtn.type = 'button';
            deleteBtn.setAttribute('aria-label', 'Delete this message');
            deleteBtn.setAttribute('title', 'Delete message');
            deleteBtn.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>`;
            deleteBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                handleDeleteMessage(msg.id, threadId);
            });
            deleteBtn.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    e.stopPropagation();
                    handleDeleteMessage(msg.id, threadId);
                }
            });
        }
        
        // Add screen reader text for message content
        const messageText = isDeleted ? '' : (msg.message_text || '');
        const escapedMessageText = escapeHtml(messageText);
        const srText = document.createElement('span');
        srText.className = 'sr-only';
        if (isDeleted) {
            srText.textContent = `Message from ${senderName} was deleted. ${timeText}.`;
        } else {
            srText.textContent = `${senderName} said: ${messageText}. ${timeText}. ${readStatus}.`;
        }
        
        const messageParagraph = document.createElement('p');
        messageParagraph.style.cssText = 'margin: 0; line-height: 1.5; word-wrap: break-word; white-space: pre-wrap;';
        if (isDeleted) {
            messageParagraph.className = 'message-deleted-text';
            messageParagraph.textContent = 'This message was deleted';
        } else {
            messageParagraph.textContent = messageText;
        }
        
        // Add deleted class to bubble
        if (isDeleted) {
            bubble.classList.add('message-deleted');
        }
        
        const timeDiv = document.createElement('div');
        timeDiv.className = 'message-time';
        timeDiv.style.cssText = 'font-size: 0.75rem; opacity: 0.7; margin-top: 0.375rem; display: flex; align-items: center; gap: 0.25rem;';
        timeDiv.setAttribute('aria-hidden', 'true');
        timeDiv.innerHTML = `${timeText} <span style="font-size: 0.875rem;" aria-label="${readStatus}">${msg.read ? '✓✓' : '✓'}</span>`;
        
        // Build bubble content
        bubble.appendChild(srText);
        if (replyContainer) {
            bubble.appendChild(replyContainer);
        }
        bubble.appendChild(messageParagraph);
        if (attachmentsHtml) {
            const tempDiv = document.createElement('div');
            tempDiv.innerHTML = attachmentsHtml;
            while (tempDiv.firstChild) {
                bubble.appendChild(tempDiv.firstChild);
            }
        }
        bubble.appendChild(timeDiv);
        if (deleteBtn) {
            bubble.appendChild(deleteBtn);
        }
        if (!isDeleted) {
            bubble.appendChild(replyBtn);
        }
        fragment.appendChild(bubble);
    });
    
    // Clear and append fragment in one operation
    container.innerHTML = '';
    container.appendChild(fragment);
    
    // Add click and keyboard handlers for images
    container.querySelectorAll('.message-image-clickable').forEach(img => {
        const handleImageClick = function() {
            openImageModal(this.getAttribute('data-image-url'), this.getAttribute('data-image-name'));
        };
        img.addEventListener('click', handleImageClick);
        img.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                handleImageClick.call(this);
            }
        });
    });
    
    // Store new message IDs before updating lastRenderedMessageIds
    const previousRenderedIds = new Set(lastRenderedMessageIds);
    
    // Update last rendered IDs
    lastRenderedMessageIds = currentMessageIds;
    
    // Smooth scroll to bottom only if user was already at bottom
    requestAnimationFrame(() => {
        if (wasScrolledToBottom || container.scrollHeight - container.scrollTop <= container.clientHeight + 100) {
            container.scrollTo({
                top: container.scrollHeight,
                behavior: 'smooth'
            });
        }
    });
    
    // Announce new messages to screen readers (only for new messages, and only if user is not actively typing)
    const newMessages = messages.filter(msg => {
        const msgId = msg.id || `${msg.sender_id}_${msg.created_timestamp}`;
        return !previousRenderedIds.has(msgId);
    });
    
    if (newMessages.length > 0) {
        const statusAnnouncements = document.getElementById('chatStatusAnnouncements');
        const messageInput = document.getElementById('messageInput');
        const isUserTyping = messageInput && document.activeElement === messageInput;
        
        // Only announce if user is not actively typing (to avoid interrupting)
        if (statusAnnouncements && !isUserTyping) {
            const currentUserId = parseInt(wheelfy.userId || '0');
            // Announce the most recent new message
            const latestNewMessage = newMessages[newMessages.length - 1];
            const isOwn = parseInt(latestNewMessage.sender_id || '0') === currentUserId;
            const senderName = isOwn ? 'You' : (thread && thread.other_user_name ? thread.other_user_name : 'Other user');
            const messagePreview = (latestNewMessage.message_text || '').substring(0, 50);
            if (messagePreview) {
                statusAnnouncements.textContent = `${senderName}: ${messagePreview}`;
            }
        }
    }
}

// Track the last search term to prevent race conditions
function loadConversations(searchTerm = '', retryCount = 0) {
    // If no search term provided, check the input field
    if (!searchTerm || searchTerm.trim() === '') {
        const searchInput = document.getElementById('conversationSearch');
        if (searchInput && searchInput.value.trim().length > 0) {
            searchTerm = searchInput.value.trim();
        }
    }
    
    const formData = new FormData();
    const isSearchingNow = searchTerm && searchTerm.trim() !== '';
    const currentTimestamp = Date.now();
    
    if (isSearchingNow) {
        formData.append('action', 'search_partner_conversations');
        formData.append('search_term', searchTerm.trim());
        lastSearchTerm = searchTerm.trim();
        lastSearchTimestamp = currentTimestamp;
    } else {
        formData.append('action', 'get_conversations');
        lastSearchTerm = '';
    }
    
    formData.append('nonce', wheelfy.nonce);
    
    fetch(wheelfy.ajaxUrl, { method: 'POST', body: formData })
    .then(response => response.json())
    .then(data => {
        // CRITICAL: Prevent race conditions - only render if this is the latest request
        // Check if search state has changed since this request was made
        const searchInput = document.getElementById('conversationSearch');
        const currentSearchValue = searchInput ? searchInput.value.trim() : '';
        
        // If we were searching but now the input is empty, ignore this response
        if (isSearchingNow && currentSearchValue === '') {
            console.log('Search was cleared, ignoring stale search response');
            return;
        }
        
        // If we weren't searching but now there's a search term, ignore this response
        if (!isSearchingNow && currentSearchValue.length > 0) {
            console.log('Search started, ignoring stale default conversation response');
            return;
        }
        
        // If searching, ensure the search term matches
        if (isSearchingNow && currentSearchValue !== searchTerm.trim()) {
            console.log('Search term changed, ignoring stale response');
            return;
        }
        
        if (data.success) {
            renderConversations(data.data.conversations, isSearchingNow ? searchTerm : '');
            updateMessageBadge(data.data.unread_count);
        } else {
            const errorMessage = data.data && data.data.message ? data.data.message : '';
            
            // Handle security check failure - refresh nonce and retry
            if (errorMessage.includes('Security check failed') && retryCount < 1) {
                console.log('Security check failed for conversations, refreshing nonce...');
                refreshNonce().then(success => {
                    if (success) {
                        setTimeout(() => {
                            loadConversations(searchTerm, retryCount + 1);
                        }, 500);
                    }
                });
                return;
            }
            
            console.error('Failed to load conversations:', data.data);
            // Only render empty if we're not in a search state
            if (!isSearchingNow) {
                renderConversations([]);
            }
        }
    })
    .catch(error => {
        console.error('Error loading conversations:', error);
        // Only render empty if we're not in a search state
        if (!isSearchingNow) {
            renderConversations([]);
        }
    });
}

// Search state management
function isSearching() {
    const searchInput = document.getElementById('conversationSearch');
    if (!searchInput) return false;
    return searchInput.value.trim().length > 0;
}

function getCurrentSearchTerm() {
    const searchInput = document.getElementById('conversationSearch');
    if (!searchInput) return '';
    return searchInput.value.trim();
}

// Debounced search function
function handleConversationSearch() {
    const searchInput = document.getElementById('conversationSearch');
    if (!searchInput) return;
    
    // Clear existing timeout
    if (searchTimeout) {
        clearTimeout(searchTimeout);
    }
    
    // Get search term
    const searchTerm = searchInput.value.trim();
    
    // Show loading state if searching (not if clearing)
    const loading = document.getElementById('conversationsLoading');
    if (searchTerm && loading) {
        loading.style.display = 'block';
    }
    
    // If search is cleared, immediately load all conversations
    if (searchTerm === '') {
        console.log('Search cleared, loading all conversations');
        loadConversations('');
        return;
    }
    
    // Debounce: wait 400ms after user stops typing
    searchTimeout = setTimeout(() => {
        console.log('Search conversations:', searchTerm);
        loadConversations(searchTerm);
    }, 400);
}

function selectConversation(threadId, otherUserId, otherUserName, otherUserAvatar) {
    currentThreadId = threadId;
    document.querySelectorAll('.conversation-item').forEach(item => {
        item.classList.remove('active');
        item.setAttribute('aria-selected', 'false');
        if (item.getAttribute('data-thread-id') === threadId) {
            item.classList.add('active');
            item.setAttribute('aria-selected', 'true');
        }
    });
    document.getElementById('chatPanel').style.display = 'flex';
    document.getElementById('chatPlaceholder').style.display = 'none';
    document.getElementById('currentThreadId').value = threadId;
    document.getElementById('chatPartnerName').textContent = otherUserName || 'Customer';
    const avatar = document.getElementById('chatPartnerAvatar');
    const avatarInitial = otherUserName ? otherUserName.charAt(0).toUpperCase() : '?';
    
    // Update chat header avatar with image if available
    if (otherUserAvatar) {
        avatar.innerHTML = `<img src="${otherUserAvatar}" alt="${otherUserName || 'User'}" onerror="this.parentElement.textContent='${avatarInitial}'; this.parentElement.classList.remove('chat-partner-avatar-image');">`;
        avatar.classList.add('chat-partner-avatar-image');
    } else {
        avatar.textContent = avatarInitial;
        avatar.classList.remove('chat-partner-avatar-image');
    }
    
    // Announce conversation selection to screen readers
    const statusAnnouncements = document.getElementById('chatStatusAnnouncements');
    if (statusAnnouncements) {
        statusAnnouncements.textContent = `Opened conversation with ${otherUserName || 'Customer'}`;
    }
    
    loadThreadMessages(threadId);
    
    // Focus management: Move focus to message input after a short delay
    setTimeout(() => {
        const messageInput = document.getElementById('messageInput');
        if (messageInput) {
            messageInput.focus();
        }
    }, 100);
}

// Function to refresh nonce
function refreshNonce() {
    return fetch(wheelfy.ajaxUrl + '?action=wheelfy_refresh_nonce&_=' + Date.now(), {
        method: 'GET',
        credentials: 'same-origin'
    }).then(response => response.json()).then(data => {
        if (data.success && data.data && data.data.nonce) {
            wheelfy.nonce = data.data.nonce;
            console.log('Nonce refreshed successfully');
            return true;
        }
        return false;
    }).catch(() => {
        // Fallback: reload page to get fresh nonce
        console.warn('Could not refresh nonce, page will reload');
        window.location.reload();
        return false;
    });
}

function startMessagePolling() {
    // Stop any existing polling first
    stopMessagePolling();
    
    if (isPollingActive) return;
    isPollingActive = true;
    
    // Start polling every 5 seconds for real-time updates
    messagePollInterval = setInterval(() => {
        if (!isPollingActive) return;
        
        // Use requestAnimationFrame for smoother updates
        requestAnimationFrame(() => {
            // CRITICAL: Check if user is searching before reloading conversations
            // If searching, use the current search term; otherwise load all conversations
            if (typeof loadConversations === 'function') {
                const currentSearchTerm = getCurrentSearchTerm();
                loadConversations(currentSearchTerm);
            }
            if (currentThreadId && typeof loadThreadMessages === 'function') {
                loadThreadMessages(currentThreadId);
            }
        });
    }, 5000);
}

function stopMessagePolling() {
    isPollingActive = false;
    if (messagePollInterval) {
        clearInterval(messagePollInterval);
        messagePollInterval = null;
    }
}

function loadThreadMessages(threadId, retryCount = 0, refreshNonceOnError = false) {
    const container = document.getElementById('chatMessages');
    const loading = document.getElementById('messagesLoading');
    if (loading) loading.style.display = 'block';
    
    // Validate threadId
    if (!threadId || threadId.trim() === '') {
        if (loading) loading.style.display = 'none';
        container.innerHTML = '<div class="empty-state" style="text-align: center; padding: 3rem 2rem; color: hsl(var(--muted-foreground));"><div style="font-size: 3rem; margin-bottom: 1rem;">⚠️</div><h3 style="margin: 0 0 0.5rem; font-size: 1.125rem; font-weight: 600; color: hsl(var(--foreground));">Invalid conversation</h3><p style="margin: 0; font-size: 0.9375rem;">Please select a valid conversation.</p></div>';
        return;
    }
    
    const formData = new FormData();
    formData.append('action', 'get_thread_messages');
    formData.append('nonce', wheelfy.nonce);
    formData.append('thread_id', threadId.trim());
    
    fetch(wheelfy.ajaxUrl, { 
        method: 'POST', 
        body: formData,
        credentials: 'same-origin'
    })
    .then(response => {
        // Check if response is ok
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        // Check if response is JSON
        const contentType = response.headers.get('content-type');
        if (!contentType || !contentType.includes('application/json')) {
            throw new Error('Invalid response format');
        }
        return response.json();
    })
    .then(data => {
        if (loading) loading.style.display = 'none';
        
        if (data.success) {
            renderMessages(data.data.messages, data.data.thread);
            // Update chat header avatar if thread data includes it
            if (data.data.thread && data.data.thread.other_user_avatar) {
                const avatar = document.getElementById('chatPartnerAvatar');
                const otherUserName = document.getElementById('chatPartnerName').textContent;
                const avatarInitial = otherUserName ? otherUserName.charAt(0).toUpperCase() : '?';
                avatar.innerHTML = `<img src="${data.data.thread.other_user_avatar}" alt="${otherUserName || 'User'}" onerror="this.parentElement.textContent='${avatarInitial}'; this.parentElement.classList.remove('chat-partner-avatar-image');">`;
                avatar.classList.add('chat-partner-avatar-image');
            }
        } else {
            console.error('Failed to load messages:', data.data);
            const errorMessage = data.data && data.data.message ? data.data.message : 'Failed to load messages.';
            
            // Handle security check failure - refresh nonce and retry
            if (errorMessage.includes('Security check failed') && !refreshNonceOnError && retryCount < 2) {
                console.log('Security check failed, refreshing nonce...');
                refreshNonce().then(success => {
                    if (success) {
                        setTimeout(() => {
                            loadThreadMessages(threadId, retryCount + 1, true);
                        }, 500);
                    }
                });
                return;
            }
            
            // Retry logic for certain errors
            if (retryCount < 2 && (errorMessage.includes('Thread not found') || errorMessage.includes('Connection'))) {
                console.log(`Retrying message load (attempt ${retryCount + 1})...`);
                setTimeout(() => {
                    loadThreadMessages(threadId, retryCount + 1, refreshNonceOnError);
                }, 1000);
                return;
            }
            
            // Show error message matching the image design
            const isSecurityError = errorMessage.includes('Security check failed');
            container.innerHTML = `<div class="empty-state" style="text-align: center; padding: 3rem 2rem; color: hsl(var(--muted-foreground));">
                <div style="font-size: 3rem; margin-bottom: 1rem; color: #fbbf24;">⚠️</div>
                <h3 style="margin: 0 0 0.5rem; font-size: 1.125rem; font-weight: 600; color: hsl(var(--foreground));">${isSecurityError ? 'Connection Error' : 'Failed to load messages'}</h3>
                <p style="margin: 0; font-size: 0.9375rem; margin-bottom: 1.5rem;">${isSecurityError ? 'Unable to load messages. Please check your connection and try again.' : errorMessage}</p>
                <button onclick="loadThreadMessages('${threadId}', 0, false)" style="margin-top: 1rem; padding: 0.75rem 1.5rem; background: #fbbf24; color: #000; border: none; border-radius: 0.5rem; cursor: pointer; font-size: 0.875rem; font-weight: 600; transition: opacity 0.2s;" onmouseover="this.style.opacity='0.9'" onmouseout="this.style.opacity='1'">Retry</button>
            </div>`;
        }
    })
    .catch(error => {
        if (loading) loading.style.display = 'none';
        console.error('Error loading messages:', error);
        
        // Retry logic for network errors
        if (retryCount < 2) {
            console.log(`Retrying message load due to network error (attempt ${retryCount + 1})...`);
            setTimeout(() => {
                loadThreadMessages(threadId, retryCount + 1, refreshNonceOnError);
            }, 1000);
            return;
        }
        
        // Show connection error matching the image design
        container.innerHTML = `<div class="empty-state" style="text-align: center; padding: 3rem 2rem; color: hsl(var(--muted-foreground));">
            <div style="font-size: 3rem; margin-bottom: 1rem; color: #fbbf24;">⚠️</div>
            <h3 style="margin: 0 0 0.5rem; font-size: 1.125rem; font-weight: 600; color: hsl(var(--foreground));">Connection Error</h3>
            <p style="margin: 0; font-size: 0.9375rem; margin-bottom: 1.5rem;">Unable to load messages. Please check your connection and try again.</p>
            <button onclick="loadThreadMessages('${threadId}', 0, false)" style="margin-top: 1rem; padding: 0.75rem 1.5rem; background: #fbbf24; color: #000; border: none; border-radius: 0.5rem; cursor: pointer; font-size: 0.875rem; font-weight: 600; transition: opacity 0.2s;" onmouseover="this.style.opacity='0.9'" onmouseout="this.style.opacity='1'">Retry</button>
        </div>`;
    });
}

function sendMessage(e) {
    e.preventDefault();
    const threadId = document.getElementById('currentThreadId').value;
    const messageInput = document.getElementById('messageInput');
    const messageText = messageInput.value.trim();
    const statusAnnouncements = document.getElementById('chatStatusAnnouncements');
    
    if (!threadId) {
        const errorMsg = 'Please select a conversation first.';
        if (statusAnnouncements) {
            statusAnnouncements.textContent = errorMsg;
        }
        alert(errorMsg);
        return;
    }
    if (!messageText && attachmentIds.length === 0) return;
    
    // Frontend validation: Check for contact information
    if (messageText && typeof WheelfyChatSecurity !== 'undefined') {
        const validation = WheelfyChatSecurity.containsContactInfo(messageText);
        if (validation.hasContact) {
            const errorMsg = validation.message || '<?php echo esc_js(__('Sharing contact information is not allowed.', 'wheelfy')); ?>';
            if (statusAnnouncements) {
                statusAnnouncements.textContent = errorMsg;
            }
            alert(errorMsg);
            return;
        }
    }
    
    const sendBtn = document.getElementById('sendBtn');
    sendBtn.disabled = true;
    sendBtn.setAttribute('aria-busy', 'true');
    
    const formData = new FormData();
    formData.append('action', 'send_message');
    formData.append('nonce', wheelfy.nonce);
    formData.append('thread_id', threadId);
    formData.append('message_text', messageText);
    if (replyingToMessageId) {
        formData.append('parent_message_id', replyingToMessageId);
    }
    if (attachmentIds.length > 0) {
        attachmentIds.forEach(id => formData.append('attachment_ids[]', id));
    }
    
    fetch(wheelfy.ajaxUrl, { method: 'POST', body: formData })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            messageInput.value = '';
            messageInput.style.height = 'auto';
            attachmentIds = [];
            document.getElementById('composerAttachments').style.display = 'none';
            document.getElementById('composerAttachments').innerHTML = '';
            
            // Clear reply preview
            cancelReply();
            
            // Announce success to screen readers
            if (statusAnnouncements) {
                statusAnnouncements.textContent = 'Message sent successfully.';
            }
            
            // Keep focus on input after sending
            messageInput.focus();
            
            loadThreadMessages(threadId);
            loadConversations();
        } else {
            const errorMsg = data.data.message || 'Failed to send message.';
            if (statusAnnouncements) {
                statusAnnouncements.textContent = 'Error: ' + errorMsg;
            }
            alert(errorMsg);
        }
        sendBtn.disabled = false;
        sendBtn.removeAttribute('aria-busy');
    })
    .catch(error => {
        console.error('Error sending message:', error);
        const errorMsg = 'An error occurred. Please try again.';
        if (statusAnnouncements) {
            statusAnnouncements.textContent = 'Error: ' + errorMsg;
        }
        alert(errorMsg);
        sendBtn.disabled = false;
        sendBtn.removeAttribute('aria-busy');
    });
}

function uploadAttachment(file) {
    const formData = new FormData();
    formData.append('action', 'upload_attachment');
    formData.append('nonce', wheelfy.nonce);
    formData.append('attachment', file);
    return fetch(wheelfy.ajaxUrl, { method: 'POST', body: formData })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            attachmentIds.push(data.data.attachment_id);
            displayAttachmentPreview(data.data);
            return data.data;
        } else {
            throw new Error(data.data.message || 'Upload failed');
        }
    });
}

function displayAttachmentPreview(attachment) {
    const container = document.getElementById('composerAttachments');
    container.style.display = 'flex';
    const preview = document.createElement('div');
    preview.className = 'attachment-preview';
    if (attachment.attachment_url && attachment.attachment_url.match(/\.(jpg|jpeg|png|webp)$/i)) {
        preview.innerHTML = `<img src="${attachment.attachment_url}" alt="${attachment.attachment_name}" style="width: 48px; height: 48px; object-fit: cover; border-radius: 0.25rem;"><span>${attachment.attachment_name}</span><button type="button" class="remove-attachment" data-attachment-id="${attachment.attachment_id}">×</button>`;
    } else {
        preview.innerHTML = `<span>📎 ${attachment.attachment_name}</span><button type="button" class="remove-attachment" data-attachment-id="${attachment.attachment_id}">×</button>`;
    }
    container.appendChild(preview);
    preview.querySelector('.remove-attachment').addEventListener('click', function() {
        const attId = parseInt(this.getAttribute('data-attachment-id'));
        attachmentIds = attachmentIds.filter(id => id !== attId);
        preview.remove();
        if (attachmentIds.length === 0) container.style.display = 'none';
    });
}

function updateMessageBadge(count) {
    const badge = document.getElementById('messagingBadgeCount');
    if (badge) {
        if (count > 0) {
            badge.textContent = count;
            badge.style.display = 'inline-flex';
            badge.classList.add('badge-new');
        } else {
            badge.style.display = 'none';
            badge.classList.remove('badge-new');
        }
    }
}

// Global badge polling - runs regardless of which section is active
var badgePollInterval = null;

function fetchUnreadMessageCount() {
    var formData = new FormData();
    formData.append('action', 'get_conversations');
    formData.append('nonce', wheelfy.nonce);
    
    fetch(wheelfy.ajaxUrl, { method: 'POST', body: formData })
    .then(function(response) { return response.json(); })
    .then(function(data) {
        if (data.success && typeof data.data.unread_count !== 'undefined') {
            updateMessageBadge(data.data.unread_count);
        }
    })
    .catch(function(error) {
        console.error('Error fetching unread count:', error);
    });
}

function startGlobalBadgePolling() {
    // Fetch immediately on start
    fetchUnreadMessageCount();
    
    // Then poll every 15 seconds for badge updates (lightweight check)
    if (badgePollInterval) {
        clearInterval(badgePollInterval);
    }
    badgePollInterval = setInterval(function() {
        // Only poll for badge if NOT in messaging section (messaging section has its own polling)
        var messagingSection = document.getElementById('messagingSection');
        if (!messagingSection || !messagingSection.classList.contains('active')) {
            fetchUnreadMessageCount();
        }
    }, 15000); // Every 15 seconds
}

// Start global badge polling on page load
document.addEventListener('DOMContentLoaded', function() {
    // Small delay to ensure page is ready
    setTimeout(startGlobalBadgePolling, 1000);
});

// Initialize messaging functionality
function initMessaging() {
    // Load conversations if messaging section is active
    const messagesSection = document.getElementById('messagingSection');
    if (messagesSection && messagesSection.classList.contains('active')) {
        if (typeof loadConversations === 'function') {
            loadConversations();
        }
        if (typeof startMessagePolling === 'function') {
            startMessagePolling();
        }
    }
    
    // Set up message form
    const messageForm = document.getElementById('messageForm');
    if (messageForm && typeof sendMessage === 'function') {
        messageForm.addEventListener('submit', sendMessage);
        
        // Keyboard accessibility: ENTER to send, SHIFT+ENTER for newline
        const messageInput = document.getElementById('messageInput');
        if (messageInput) {
            messageInput.addEventListener('keydown', function(e) {
                // ENTER without SHIFT = send message
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    sendMessage(e);
                }
                // ESC = cancel reply
                if (e.key === 'Escape' && replyingToMessageId) {
                    cancelReply();
                }
                // SHIFT+ENTER = new line (default behavior, allow it)
            });
            
            // Auto-resize textarea
            messageInput.addEventListener('input', function() {
                this.style.height = 'auto';
                this.style.height = Math.min(this.scrollHeight, 120) + 'px';
            });
        }
    }
    
    // Set up cancel reply button
    const cancelReplyBtn = document.getElementById('cancelReplyBtn');
    if (cancelReplyBtn && typeof cancelReply === 'function') {
        cancelReplyBtn.addEventListener('click', cancelReply);
        cancelReplyBtn.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                cancelReply();
            }
        });
    }
    
    // Set up attachment button
    const attachmentBtn = document.getElementById('attachmentBtn');
    const fileInput = document.getElementById('fileInput');
    if (attachmentBtn && fileInput && typeof uploadAttachment === 'function') {
        attachmentBtn.addEventListener('click', () => fileInput.click());
        fileInput.addEventListener('change', function() {
            Array.from(this.files).forEach(file => {
                uploadAttachment(file).catch(error => alert('Failed to upload file: ' + error.message));
            });
            this.value = '';
        });
    }
    
    // Set up message input auto-resize and real-time validation
    const messageInput = document.getElementById('messageInput');
    if (messageInput) {
        // Create error message container for chat
        let chatErrorContainer = document.getElementById('chatSecurityError');
        if (!chatErrorContainer) {
            chatErrorContainer = document.createElement('div');
            chatErrorContainer.id = 'chatSecurityError';
            chatErrorContainer.style.cssText = 'display:none;color:#ef4444;background:rgba(239,68,68,0.1);padding:0.5rem 1rem;border-radius:0.5rem;font-size:0.875rem;margin-bottom:0.5rem;';
            const chatInputContainer = document.querySelector('.chat-input-container, .chat-composer');
            if (chatInputContainer) {
                chatInputContainer.insertBefore(chatErrorContainer, chatInputContainer.firstChild);
            }
        }
        
        messageInput.addEventListener('input', function() {
            this.style.height = 'auto';
            this.style.height = Math.min(this.scrollHeight, 120) + 'px';
            const sendBtn = document.getElementById('sendBtn');
            
            // Real-time contact info validation
            if (typeof WheelfyChatSecurity !== 'undefined' && this.value.trim()) {
                const validation = WheelfyChatSecurity.containsContactInfo(this.value.trim());
                if (validation.hasContact) {
                    chatErrorContainer.textContent = validation.message;
                    chatErrorContainer.style.display = 'block';
                    if (sendBtn) {
                        sendBtn.disabled = true;
                        sendBtn.classList.add('chat-blocked');
                    }
                    return;
                } else {
                    chatErrorContainer.style.display = 'none';
                    if (sendBtn) sendBtn.classList.remove('chat-blocked');
                }
            } else {
                chatErrorContainer.style.display = 'none';
            }
            
            if (sendBtn) sendBtn.disabled = !this.value.trim() && attachmentIds.length === 0;
        });
    }
    
    // Handle page visibility changes
    document.addEventListener('visibilitychange', function() {
        const messagesSection = document.getElementById('messagingSection');
        if (messagesSection && messagesSection.classList.contains('active')) {
            if (document.hidden) {
                if (typeof stopMessagePolling === 'function') {
                    stopMessagePolling();
                }
            } else {
                if (typeof startMessagePolling === 'function') {
                    startMessagePolling();
                }
            }
        }
    });
}

document.addEventListener('DOMContentLoaded', function() {
    // Initialize messaging (will only start if section is active)
    initMessaging();
});

// ============================================================================
// PARTNER REQUESTS SYSTEM (Real-Time)
// ============================================================================

let requestPollInterval = null;
let currentRequestFilter = 'all';

// Request Modal - Global variables and functions
let requestModal, requestModalBody, closeRequestModal;

function initRequestModal() {
    requestModal = document.getElementById('requestModal');
    requestModalBody = document.getElementById('requestModalBody');
    closeRequestModal = document.getElementById('closeRequestModal');
    
    if (closeRequestModal) {
        closeRequestModal.addEventListener('click', closeRequestModalFunc);
    }
    
    if (requestModal) {
        requestModal.addEventListener('click', function(e) {
            if (e.target === requestModal) {
                closeRequestModalFunc();
            }
        });
        
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && requestModal && requestModal.style.display === 'flex') {
                closeRequestModalFunc();
            }
        });
    }
}

function closeRequestModalFunc() {
    if (requestModal) {
        requestModal.style.display = 'none';
        requestModal.classList.remove('active');
        document.body.style.overflow = '';
    }
}

// Open request details modal with full service information and chat option
function openRequestModal(request) {
    if (!requestModal || !requestModalBody) {
        initRequestModal();
    }
    
    const formData = request.form_data || {};
    const status = request.status || 'pending';
    
    // Check request type
    const requestType = formData.request_type || '';
    const isServiceRequest = requestType === 'service';
    const isSellCarRequest = requestType === 'sell_car';
    
    const serviceTitle = formData.service_title || '';
    const serviceDescription = formData.service_description || '';
        const servicePrice = formData.service_price !== undefined && formData.service_price !== null ? parseFloat(formData.service_price) : 0;
        const servicePriceCurrency = formData.service_price_currency || 'EUR';
    const serviceDuration = formData.service_duration || '';
    const serviceCategory = formData.service_category || '';
    
    // Format status for display
    let statusLabel = status.charAt(0).toUpperCase() + status.slice(1).replace('_', ' ');
    let statusClass = 'status-' + status;
    if (status === 'complete' || status === 'completed') {
        statusLabel = 'Completed';
        statusClass = 'status-complete';
    } else if (status === 'in_progress') {
        statusLabel = 'In Progress';
        statusClass = 'status-in-progress';
    } else if (status === 'pending_completion') {
        statusLabel = 'Awaiting Customer Confirmation';
        statusClass = 'status-pending-completion';
    } else if (status === 'waiting_customer_approval') {
        statusLabel = 'Offer Sent - Awaiting Approval';
        statusClass = 'status-waiting-approval';
    }
    
    // Build service info (for service-based requests)
    let serviceInfo = '';
    if (isServiceRequest) {
        // Get price - ensure we get the actual value
        const servicePriceRaw = formData.service_price !== undefined ? formData.service_price : (formData.price !== undefined ? formData.price : null);
        const priceValue = (servicePriceRaw !== undefined && servicePriceRaw !== null && servicePriceRaw !== '') ? parseFloat(servicePriceRaw) : 0;
        const currency = formData.service_price_currency || formData.price_currency || 'EUR';
        
        let priceDisplayText = 'Not set';
        if (priceValue > 0 && !isNaN(priceValue)) {
            const currencySymbol = currency === 'HUF' ? 'HUF ' : '€';
            const formattedPrice = currency === 'HUF' 
                ? priceValue.toLocaleString('hu-HU', {minimumFractionDigits: 0, maximumFractionDigits: 0})
                : priceValue.toFixed(2);
            priceDisplayText = currencySymbol + formattedPrice;
        }
        
        serviceInfo = `
            <div class="request-modal-section">
                <h4 class="section-title">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"></path>
                    </svg>
                    Service Information
                </h4>
                <div class="info-grid">
                    <div class="info-item" style="grid-column: 1 / -1;">
                        <span class="info-label">Service Name</span>
                        <span class="info-value" style="font-weight: 600; font-size: 1.125rem; color: hsl(var(--primary));">${serviceTitle}</span>
                    </div>
                    ${serviceDescription ? `
                    <div class="info-item" style="grid-column: 1 / -1;">
                        <span class="info-label">Description</span>
                        <span class="info-value" style="line-height: 1.6;">${serviceDescription}</span>
                    </div>
                    ` : ''}
                    <div class="info-item">
                        <span class="info-label">Price</span>
                        <span class="info-value" style="font-weight: 600; color: hsl(var(--primary));">${priceDisplayText}</span>
                    </div>
                    ${serviceDuration ? `
                    <div class="info-item">
                        <span class="info-label">Duration</span>
                        <span class="info-value">${serviceDuration}</span>
                    </div>
                    ` : ''}
                    ${serviceCategory ? `
                    <div class="info-item">
                        <span class="info-label">Category</span>
                        <span class="info-value">${serviceCategory}</span>
                    </div>
                    ` : ''}
                </div>
            </div>
        `;
    }
    
    // Build car images (for sell_car requests)
    let carImagesInfo = '';
    if (isSellCarRequest) {
        // Check for car_photos_urls (from backend) or car_photos (attachment IDs)
        let carImages = [];
        if (formData.car_photos_urls && Array.isArray(formData.car_photos_urls) && formData.car_photos_urls.length > 0) {
            // Use URLs from backend
            carImages = formData.car_photos_urls;
        } else if (formData.car_photos && Array.isArray(formData.car_photos) && formData.car_photos.length > 0) {
            // Convert attachment IDs to URLs (fallback - will need AJAX call)
            carImages = formData.car_photos.filter(photoId => {
                return typeof photoId === 'number' || (typeof photoId === 'string' && /^\d+$/.test(photoId));
            }).map(photoId => ({
                id: photoId,
                url: '',
                full_url: ''
            }));
        }
        
        if (carImages.length > 0) {
            const imagesHtml = carImages.map((img, index) => {
                const imageUrl = img.url || img.full_url || '';
                if (imageUrl) {
                    // Has URL from backend
                    return `<div style="position: relative;"><img src="${imageUrl}" alt="Car Photo ${index + 1}" style="width: 100%; max-width: 300px; height: auto; border-radius: 0.5rem; margin-bottom: 0.5rem; cursor: pointer; object-fit: cover;" onclick="window.open('${img.full_url || imageUrl}', '_blank')" onerror="this.style.display='none'"></div>`;
                } else if (img.id) {
                    // Need to fetch URL - will be handled after modal is rendered
                    return `<div style="position: relative;" data-attachment-id="${img.id}"><div style="width: 100%; max-width: 300px; height: 200px; border-radius: 0.5rem; background: hsl(var(--secondary)); display: flex; align-items: center; justify-content: center; color: hsl(var(--muted-foreground));">Loading image...</div></div>`;
                }
                return '';
            }).filter(html => html).join('');
            
            carImagesInfo = `
                <div class="request-modal-section">
                    <h4 class="section-title">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                            <circle cx="8.5" cy="8.5" r="1.5"></circle>
                            <polyline points="21 15 16 10 5 21"></polyline>
                        </svg>
                        Car Images
                    </h4>
                    <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 1rem;">
                        ${imagesHtml}
                    </div>
                </div>
            `;
        }
    }
    
    // Build vehicle info
    let vehicleInfo = '';
    if (formData.year || formData.make || formData.model) {
        vehicleInfo = `
            <div class="request-modal-section">
                <h4 class="section-title">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M5 17a2 2 0 1 0 4 0 2 2 0 0 0-4 0m10 0a2 2 0 1 0 4 0 2 2 0 0 0-4 0"></path>
                        <path d="M3 17h-2v-4l2-4h12l2 4v4h-2"></path>
                        <path d="M9 17h6"></path>
                        <path d="M6 13V9h12v4"></path>
                    </svg>
                    Vehicle Information
                </h4>
                <div class="info-grid">
                    ${formData.year ? `<div class="info-item"><span class="info-label">Year</span><span class="info-value">${formData.year}</span></div>` : ''}
                    ${formData.make ? `<div class="info-item"><span class="info-label">Make</span><span class="info-value">${formData.make}</span></div>` : ''}
                    ${formData.model ? `<div class="info-item"><span class="info-label">Model</span><span class="info-value">${formData.model}</span></div>` : ''}
                    ${formData.mileage ? `<div class="info-item"><span class="info-label">Mileage</span><span class="info-value">${formData.mileage}${formData.mileage.toString().includes('km') ? '' : ' km'}</span></div>` : ''}
                    ${formData.color ? `<div class="info-item"><span class="info-label">Color</span><span class="info-value">${formData.color}</span></div>` : ''}
                    ${formData.fuel_type ? `<div class="info-item"><span class="info-label">Fuel Type</span><span class="info-value">${formData.fuel_type}</span></div>` : ''}
                    ${formData.price ? `<div class="info-item"><span class="info-label">Expected Price</span><span class="info-value">${formData.price}</span></div>` : ''}
                    ${formData.vin ? `<div class="info-item"><span class="info-label">VIN</span><span class="info-value">${formData.vin}</span></div>` : ''}
                    ${formData.license_plate ? `<div class="info-item"><span class="info-label">License Plate</span><span class="info-value">${formData.license_plate}</span></div>` : ''}
                    ${formData.service_book ? `<div class="info-item"><span class="info-label">Service Book</span><span class="info-value">${formData.service_book}</span></div>` : ''}
                    ${formData.last_service_date ? `<div class="info-item"><span class="info-label">Last Service Date</span><span class="info-value">${formData.last_service_date}</span></div>` : ''}
                    ${formData.last_service_mileage ? `<div class="info-item"><span class="info-label">Last Service Mileage</span><span class="info-value">${formData.last_service_mileage}${formData.last_service_mileage.toString().includes('km') ? '' : ' km'}</span></div>` : ''}
                </div>
            </div>
        `;
    }
    
    // Build services list
    let servicesInfo = '';
    const services = formData.services || formData.selected_services || formData.accessories || [];
    if (Array.isArray(services) && services.length > 0) {
        const servicesList = services.map(s => `<li>${s}</li>`).join('');
        servicesInfo = `
            <div class="request-modal-section">
                <h4 class="section-title">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"></path>
                    </svg>
                    Requested Services
                </h4>
                <ul class="services-list">${servicesList}</ul>
            </div>
        `;
    }
    
    // Build additional details
    let additionalInfo = '';
    const description = formData.description || formData.message || formData.notes || formData.additional_info || formData.service_description || formData.additional_notes;
    if (description) {
        additionalInfo = `
            <div class="request-modal-section">
                <h4 class="section-title">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                        <polyline points="14 2 14 8 20 8"></polyline>
                        <line x1="16" y1="13" x2="8" y2="13"></line>
                        <line x1="16" y1="17" x2="8" y2="17"></line>
                        <polyline points="10 9 9 9 8 9"></polyline>
                    </svg>
                    Additional Details
                </h4>
                <p class="description-text">${description}</p>
            </div>
        `;
    }
    
    // Build contact info (hide for sell_car requests)
    let contactInfo = '';
    if (!isSellCarRequest && (formData.phone || formData.email || formData.preferred_date || formData.preferred_time)) {
        contactInfo = `
            <div class="request-modal-section">
                <h4 class="section-title">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
                    </svg>
                    Contact & Scheduling
                </h4>
                <div class="info-grid">
                    ${formData.phone ? `<div class="info-item"><span class="info-label">Phone</span><span class="info-value">${formData.phone}</span></div>` : ''}
                    ${formData.email ? `<div class="info-item"><span class="info-label">Email</span><span class="info-value">${formData.email}</span></div>` : ''}
                    ${formData.preferred_date ? `<div class="info-item"><span class="info-label">Preferred Date</span><span class="info-value">${formData.preferred_date}</span></div>` : ''}
                    ${formData.preferred_time ? `<div class="info-item"><span class="info-label">Preferred Time</span><span class="info-value">${formData.preferred_time}</span></div>` : ''}
                </div>
            </div>
        `;
    }
    
    // Build location info
    let locationInfo = '';
    if (formData.address || formData.city || formData.location) {
        locationInfo = `
            <div class="request-modal-section">
                <h4 class="section-title">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                        <circle cx="12" cy="10" r="3"></circle>
                    </svg>
                    Location
                </h4>
                <p class="location-text">${formData.address || ''} ${formData.city || ''} ${formData.location || ''}</p>
            </div>
        `;
    }
    
    // Time ago display
    const timeAgo = request.time_ago || formatRequestTime(request.request_date);
    
    // Request type badge
    const requestTypeBadge = request.request_type === 'premium' 
        ? '<span class="request-type-badge premium">Premium Request</span>' 
        : '<span class="request-type-badge normal">Regular Request</span>';
    
    // Check if this is a Sell Car request (no price form needed)
    const isSellCar = request.request_type === 'sell_car';
    
    // Action buttons based on status
    let actionButtons = '';
    if (status === 'pending') {
        if (isSellCar) {
            // Sell Car: Direct accept without price form
            actionButtons = `
                <div class="modal-actions-wrapper">
                    <div class="sell-car-notice" style="margin-bottom: 1.5rem; padding: 1.25rem; background: hsl(var(--muted) / 0.3); border-radius: 0.75rem; border: 1px solid hsl(var(--border));">
                        <p style="margin: 0; font-size: 0.875rem; color: hsl(var(--foreground)); line-height: 1.5; display: flex; align-items: flex-start; gap: 0.5rem;">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="hsl(var(--primary))" stroke-width="2" style="flex-shrink: 0; margin-top: 2px;">
                                <circle cx="12" cy="12" r="10"></circle>
                                <line x1="12" y1="16" x2="12" y2="12"></line>
                                <line x1="12" y1="8" x2="12.01" y2="8"></line>
                            </svg>
                            <span>This is a <strong>Sell Car</strong> request. The customer is selling their car at the listed price. Click Accept to start communicating with the customer.</span>
                        </p>
                    </div>
                    
                    <div class="modal-actions">
                        <button class="btn btn-primary modal-accept-btn" data-request-id="${request.id}" data-is-sell-car="true">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <polyline points="20 6 9 17 4 12"></polyline>
                            </svg>
                            Accept Request
                        </button>
                        <button class="btn btn-outline modal-delete-btn" data-request-id="${request.id}">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <polyline points="3 6 5 6 21 6"></polyline>
                                <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                            </svg>
                            Delete
                        </button>
                    </div>
                </div>
            `;
        } else {
            // Other requests: Show offer form with price
            actionButtons = `
                <div class="modal-actions-wrapper">
                    <!-- NEW WORKFLOW: Offer Form -->
                    <div class="offer-form-section" id="offerFormSection" style="margin-bottom: 1.5rem; padding: 1.25rem; background: hsl(var(--muted) / 0.3); border-radius: 0.75rem; border: 1px solid hsl(var(--border));">
                        <h4 style="margin: 0 0 1rem 0; font-size: 1rem; font-weight: 600; color: hsl(var(--foreground)); display: flex; align-items: center; gap: 0.5rem;">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <line x1="12" y1="1" x2="12" y2="23"></line>
                                <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
                            </svg>
                            Your Offer
                        </h4>
                        <div class="offer-form-fields" style="display: flex; flex-direction: column; gap: 1rem;">
                            <div class="form-group">
                                <label for="offerPrice" style="display: block; margin-bottom: 0.5rem; font-size: 0.875rem; font-weight: 500; color: hsl(var(--foreground));">
                                    Service Price (€) <span style="color: hsl(var(--destructive));">*</span>
                                </label>
                                <input type="number" id="offerPrice" name="offer_price" min="0" step="0.01" required
                                       placeholder="Enter your price"
                                       style="width: 100%; padding: 0.75rem 1rem; border: 1px solid hsl(var(--border)); border-radius: 0.5rem; font-size: 1rem; background: hsl(var(--background)); color: hsl(var(--foreground)); transition: border-color 0.2s, box-shadow 0.2s;"
                                       onfocus="this.style.borderColor='hsl(var(--primary))'; this.style.boxShadow='0 0 0 3px hsl(var(--primary) / 0.1)';"
                                       onblur="this.style.borderColor='hsl(var(--border))'; this.style.boxShadow='none';">
                            </div>
                            <div class="form-group">
                                <label for="offerNote" style="display: block; margin-bottom: 0.5rem; font-size: 0.875rem; font-weight: 500; color: hsl(var(--foreground));">
                                    Additional Note (Optional)
                                </label>
                                <textarea id="offerNote" name="offer_note" rows="3"
                                          placeholder="Add any details about your service, timeline, or special conditions..."
                                          style="width: 100%; padding: 0.75rem 1rem; border: 1px solid hsl(var(--border)); border-radius: 0.5rem; font-size: 0.875rem; background: hsl(var(--background)); color: hsl(var(--foreground)); resize: vertical; min-height: 80px; transition: border-color 0.2s, box-shadow 0.2s;"
                                          onfocus="this.style.borderColor='hsl(var(--primary))'; this.style.boxShadow='0 0 0 3px hsl(var(--primary) / 0.1)';"
                                          onblur="this.style.borderColor='hsl(var(--border))'; this.style.boxShadow='none';"></textarea>
                            </div>
                            <p style="margin: 0; font-size: 0.75rem; color: hsl(var(--muted-foreground)); line-height: 1.5;">
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="display: inline-block; vertical-align: middle; margin-right: 0.25rem;">
                                    <circle cx="12" cy="12" r="10"></circle>
                                    <line x1="12" y1="16" x2="12" y2="12"></line>
                                    <line x1="12" y1="8" x2="12.01" y2="8"></line>
                                </svg>
                                The customer will need to approve your offer before you can start working. Chat will be enabled after approval.
                            </p>
                        </div>
                    </div>
                    
                    <div class="modal-actions">
                        <button class="btn btn-primary modal-accept-btn" data-request-id="${request.id}">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <polyline points="20 6 9 17 4 12"></polyline>
                            </svg>
                            Send Offer
                        </button>
                        <button class="btn btn-outline modal-delete-btn" data-request-id="${request.id}">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <polyline points="3 6 5 6 21 6"></polyline>
                                <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                            </svg>
                            Delete
                        </button>
                    </div>
                </div>
            `;
        }
    } else {
        // For accepted, in_progress, completed statuses - show chat button
        // For Sell Car: Only show chat (no Start Work / Mark Complete - customer confirms directly)
        actionButtons = `
            <div class="modal-actions">
                <button class="btn btn-primary modal-chat-btn" data-customer-id="${request.customer_id}" data-customer-name="${request.customer_name}">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
                    </svg>
                    Start Chat
                </button>
                ${status === 'accepted' && !isSellCar ? `
                    <button class="btn btn-outline modal-start-work-btn" data-request-id="${request.id}">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <polygon points="5 3 19 12 5 21 5 3"></polygon>
                        </svg>
                        Start Work
                    </button>
                ` : ''}
                ${status === 'accepted' && isSellCar ? `
                    <span class="sell-car-notice" style="display: inline-flex; align-items: center; gap: 0.5rem; padding: 0.5rem 1rem; background: hsl(var(--muted) / 0.5); border-radius: 0.5rem; font-size: 0.875rem; color: hsl(var(--muted-foreground));">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="12" cy="12" r="10"></circle>
                            <line x1="12" y1="16" x2="12" y2="12"></line>
                            <line x1="12" y1="8" x2="12.01" y2="8"></line>
                        </svg>
                        Waiting for customer to confirm sale
                    </span>
                ` : ''}
                ${status === 'in_progress' && !isSellCar ? `
                    <button class="btn btn-outline modal-complete-btn" data-request-id="${request.id}">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                            <polyline points="22 4 12 14.01 9 11.01"></polyline>
                        </svg>
                        Mark Complete
                    </button>
                ` : ''}
            </div>
        `;
    }
    
    // Build modal content
    const modalContent = `
        <div class="request-modal-customer-header">
            <div class="customer-avatar">
                ${request.customer_name ? request.customer_name.charAt(0).toUpperCase() : 'C'}
            </div>
            <div class="customer-details">
                <h3 class="customer-name">${request.customer_name || 'Unknown Customer'}</h3>
                <div class="request-meta">
                    <span class="request-time">📅 ${timeAgo}</span>
                    ${requestTypeBadge}
                    <span class="status-badge ${statusClass}">${statusLabel}</span>
                </div>
            </div>
        </div>
        
        <div class="request-modal-content-wrapper">
            ${serviceInfo}
            ${carImagesInfo}
            ${vehicleInfo}
            ${servicesInfo}
            ${additionalInfo}
            ${contactInfo}
            ${locationInfo}
            
            ${(!vehicleInfo && !servicesInfo && !additionalInfo && !contactInfo && !locationInfo) ? `
                <div class="request-modal-section">
                    <h4 class="section-title">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <circle cx="12" cy="12" r="10"></circle>
                            <line x1="12" y1="16" x2="12" y2="12"></line>
                            <line x1="12" y1="8" x2="12.01" y2="8"></line>
                        </svg>
                        Request Details
                    </h4>
                    <p class="description-text">${isServiceRequest && serviceTitle ? serviceTitle + ' - Service Request' : (request.request_details || 'Service Request')}</p>
                </div>
            ` : ''}
        </div>
        
        ${actionButtons}
    `;
    
    requestModalBody.innerHTML = modalContent;
    requestModal.style.display = 'flex';
    requestModal.classList.add('active');
    document.body.style.overflow = 'hidden';
    
    // Fetch car image URLs if needed (for sell_car requests with attachment IDs)
    if (isSellCarRequest && formData.car_photos && Array.isArray(formData.car_photos) && formData.car_photos.length > 0) {
        formData.car_photos.forEach((photoId, index) => {
            if ((typeof photoId === 'number' || (typeof photoId === 'string' && /^\d+$/.test(photoId))) && 
                (!formData.car_photos_urls || !formData.car_photos_urls[index] || !formData.car_photos_urls[index].url)) {
                const imgContainer = requestModalBody.querySelector(`[data-attachment-id="${photoId}"]`);
                if (imgContainer) {
                    // Fetch attachment URL via AJAX
                    fetch(wheelfy.ajaxUrl, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                        body: new URLSearchParams({
                            action: 'wheelfy_get_attachment_url',
                            attachment_id: photoId,
                            nonce: wheelfy.nonce
                        })
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success && data.data && data.data.url) {
                            imgContainer.innerHTML = `<img src="${data.data.url}" alt="Car Photo ${index + 1}" style="width: 100%; max-width: 300px; height: auto; border-radius: 0.5rem; margin-bottom: 0.5rem; cursor: pointer; object-fit: cover;" onclick="window.open('${data.data.url}', '_blank')" onerror="this.style.display='none'">`;
                        } else {
                            imgContainer.style.display = 'none';
                        }
                    })
                    .catch(error => {
                        console.error('Error fetching image URL:', error);
                        imgContainer.style.display = 'none';
                    });
                }
            }
        });
    }
    
    // Attach modal button handlers
    attachModalButtonHandlers(request);
}

// Attach event handlers for modal buttons
function attachModalButtonHandlers(request) {
    // Accept button (NEW WORKFLOW: with price/note, except for sell_car)
    const acceptBtn = requestModalBody.querySelector('.modal-accept-btn');
    if (acceptBtn) {
        acceptBtn.addEventListener('click', function() {
            const requestId = this.getAttribute('data-request-id');
            const isSellCar = this.getAttribute('data-is-sell-car') === 'true';
            
            // Get offer price and note from form (only for non-sell_car requests)
            const offerPriceInput = document.getElementById('offerPrice');
            const offerNoteInput = document.getElementById('offerNote');
            
            let offerPrice = 0;
            let offerNote = '';
            
            if (!isSellCar) {
                // Validate price only for non-sell_car requests
                offerPrice = offerPriceInput ? parseFloat(offerPriceInput.value) : 0;
                offerNote = offerNoteInput ? offerNoteInput.value.trim() : '';
                
                if (!offerPrice || offerPrice <= 0) {
                    alert('Please enter a valid service price.');
                    if (offerPriceInput) {
                        offerPriceInput.focus();
                        offerPriceInput.style.borderColor = 'hsl(var(--destructive))';
                    }
                    return;
                }
                
                if (!confirm('Are you sure you want to send this offer? The customer will need to approve it before you can start working.')) return;
            } else {
                // Sell Car - direct acceptance
                if (!confirm('Are you sure you want to accept this sell car request? You will be able to chat with the customer.')) return;
            }
            
            this.disabled = true;
            this.innerHTML = isSellCar ? '<span class="spinner"></span> Accepting...' : '<span class="spinner"></span> Sending Offer...';
            
            const formData = new FormData();
            formData.append('action', 'update_request_status');
            formData.append('nonce', wheelfy.nonce);
            formData.append('request_id', requestId);
            formData.append('status', 'accepted');
            
            // Only send price/note for non-sell_car requests
            if (!isSellCar) {
                formData.append('offer_price', offerPrice);
                formData.append('offer_note', offerNote);
            }
            
            fetch(wheelfy.ajaxUrl, { method: 'POST', body: formData })
            .then(response => response.text())
            .then(text => {
                // Try to parse JSON, handling potential PHP warnings before the JSON
                let data;
                try {
                    // Try to find JSON in response (might have PHP warnings before it)
                    const jsonStart = text.indexOf('{');
                    if (jsonStart > 0) {
                        console.warn('PHP output before JSON:', text.substring(0, jsonStart));
                        text = text.substring(jsonStart);
                    }
                    data = JSON.parse(text);
                } catch (e) {
                    console.error('Failed to parse response:', text);
                    throw new Error('Invalid server response');
                }
                
                if (data.success) {
                    if (isSellCar) {
                        // Sell Car: Direct acceptance
                        alert('Request accepted! A chat thread has been created. You can now message the customer.');
                    } else if (data.data && data.data.status === 'waiting_customer_approval') {
                        // New workflow: waiting for customer approval
                        alert('Offer sent successfully! The customer will be notified. Once they approve, you can start working and chat will be enabled.');
                    } else {
                        // Legacy workflow
                        alert('Request accepted! A chat thread has been created. You can now message the customer.');
                    }
                    closeRequestModalFunc();
                    loadPartnerRequests(currentRequestFilter);
                    if (typeof loadConversations === 'function') loadConversations();
                } else {
                    alert((data.data && data.data.message) || 'Failed to send offer.');
                    this.disabled = false;
                    this.innerHTML = isSellCar 
                        ? '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"></polyline></svg> Accept Request'
                        : '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"></polyline></svg> Send Offer';
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('A system error occurred. Please try again.');
                this.disabled = false;
                this.innerHTML = isSellCar 
                    ? '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"></polyline></svg> Accept Request'
                    : '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"></polyline></svg> Send Offer';
            });
        });
    }
    
    // Delete button
    const deleteBtn = requestModalBody.querySelector('.modal-delete-btn');
    if (deleteBtn) {
        deleteBtn.addEventListener('click', function() {
            const requestId = this.getAttribute('data-request-id');
            if (!confirm('Are you sure you want to delete this request? This action is final and irreversible.')) return;
            this.disabled = true;
            this.innerHTML = '<span class="spinner"></span> Deleting...';
            const formData = new FormData();
            formData.append('action', 'update_request_status');
            formData.append('nonce', wheelfy.nonce);
            formData.append('request_id', requestId);
            formData.append('status', 'rejected');
            fetch(wheelfy.ajaxUrl, { method: 'POST', body: formData })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    closeRequestModalFunc();
                    loadPartnerRequests(currentRequestFilter);
                } else {
                    alert(data.data.message || 'Failed to delete request.');
                    this.disabled = false;
                    this.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg> Delete';
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred. Please try again.');
                this.disabled = false;
                this.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg> Delete';
            });
        });
    }
    
    // Chat button - open messaging with customer
    const chatBtn = requestModalBody.querySelector('.modal-chat-btn');
    if (chatBtn) {
        chatBtn.addEventListener('click', function() {
            const customerId = this.getAttribute('data-customer-id');
            const customerName = this.getAttribute('data-customer-name');
            
            // Close modal first
            closeRequestModalFunc();
            
            // Hide all sections
            document.querySelectorAll('.dashboard-section').forEach(section => {
                section.classList.remove('active');
            });
            
            // Show messaging section
            const messagingSection = document.getElementById('messagingSection');
            if (messagingSection) {
                messagingSection.classList.add('active');
            }
            
            // Update nav active state
            document.querySelectorAll('.nav-item').forEach(nav => nav.classList.remove('active'));
            const messagingNav = document.querySelector('.nav-item[data-section="messaging"]');
            if (messagingNav) {
                messagingNav.classList.add('active');
            }
            
            // Function to find and select conversation
            function findAndSelectConversation(retryCount) {
                retryCount = retryCount || 0;
                const conversationItems = document.querySelectorAll('.conversation-item');
                let foundConversation = null;
                
                console.log('Looking for customer ID:', customerId, 'Found conversations:', conversationItems.length);
                
                conversationItems.forEach(function(item) {
                    const otherUserId = item.getAttribute('data-other-user-id');
                    console.log('Checking conversation with user ID:', otherUserId);
                    // Compare as strings to handle both string and number IDs
                    if (otherUserId && String(otherUserId) === String(customerId)) {
                        foundConversation = item;
                    }
                });
                
                if (foundConversation) {
                    console.log('Found conversation, clicking...');
                    // Click to open the conversation
                    foundConversation.click();
                } else if (retryCount < 8) {
                    console.log('Conversation not found, retrying...', retryCount);
                    // Retry after a delay
                    setTimeout(function() {
                        findAndSelectConversation(retryCount + 1);
                    }, 500);
                } else {
                    console.log('Conversation not found after retries for customer:', customerId);
                }
            }
            
            // Load conversations and then find the customer's conversation
            setTimeout(function() {
                if (typeof loadConversations === 'function') {
                    loadConversations();
                }
                // Wait for conversations to load, then find and select
                setTimeout(function() {
                    findAndSelectConversation(0);
                }, 1000);
            }, 500);
        });
    }
    
    // Start Work button
    const startWorkBtn = requestModalBody.querySelector('.modal-start-work-btn');
    if (startWorkBtn) {
        startWorkBtn.addEventListener('click', function() {
            const requestId = this.getAttribute('data-request-id');
            if (!confirm('Are you sure you want to mark this request as "In Progress"? The customer will be notified.')) return;
            this.disabled = true;
            this.innerHTML = '<span class="spinner"></span> Processing...';
            const formData = new FormData();
            formData.append('action', 'wheelfy_mark_in_progress');
            formData.append('nonce', wheelfy.nonce);
            formData.append('request_id', requestId);
            fetch(wheelfy.ajaxUrl, { method: 'POST', body: formData })
            .then(response => response.text())
            .then(text => {
                let data;
                try {
                    const jsonStart = text.indexOf('{');
                    if (jsonStart > 0) text = text.substring(jsonStart);
                    data = JSON.parse(text);
                } catch (e) {
                    console.error('Failed to parse response:', text);
                    throw new Error('Invalid response');
                }
                if (data.success) {
                    alert('Request marked as "In Progress"! The customer has been notified.');
                    closeRequestModalFunc();
                    loadPartnerRequests(currentRequestFilter);
                } else {
                    alert((data.data && data.data.message) || 'Failed to mark request as in progress.');
                    this.disabled = false;
                    this.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg> Start Work';
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('A system error occurred. Please try again.');
                this.disabled = false;
                this.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg> Start Work';
            });
        });
    }
    
    // Mark Complete button
    const completeBtn = requestModalBody.querySelector('.modal-complete-btn');
    if (completeBtn) {
        completeBtn.addEventListener('click', function() {
            const requestId = this.getAttribute('data-request-id');
            if (!confirm('Are you sure you want to mark this request as complete? The customer will be notified to confirm completion.')) return;
            this.disabled = true;
            this.innerHTML = '<span class="spinner"></span> Processing...';
            const formData = new FormData();
            formData.append('action', 'wheelfy_complete_request');
            formData.append('nonce', wheelfy.nonce);
            formData.append('request_id', requestId);
            fetch(wheelfy.ajaxUrl, { method: 'POST', body: formData })
            .then(response => response.text())
            .then(text => {
                let data;
                try {
                    const jsonStart = text.indexOf('{');
                    if (jsonStart > 0) text = text.substring(jsonStart);
                    data = JSON.parse(text);
                } catch (e) {
                    console.error('Failed to parse response:', text);
                    throw new Error('Invalid response');
                }
                if (data.success) {
                    // Show appropriate message based on response
                    const msg = (data.data && data.data.message) || 'Request marked as complete! Waiting for customer confirmation.';
                    alert(msg);
                    closeRequestModalFunc();
                    loadPartnerRequests(currentRequestFilter);
                } else {
                    alert((data.data && data.data.message) || 'Failed to mark request as complete.');
                    this.disabled = false;
                    this.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg> Mark Complete';
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('A system error occurred. Please try again.');
                this.disabled = false;
                this.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg> Mark Complete';
            });
        });
    }
}

function formatRequestTime(dateString) {
    if (!dateString) return 'Unknown';
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);
    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return diffMins + 'm ago';
    if (diffHours < 24) return diffHours + 'h ago';
    if (diffDays < 7) return diffDays + 'd ago';
    return date.toLocaleDateString();
}

function renderPartnerRequests(requests) {
    const container = document.getElementById('requestsList');
    const loading = document.getElementById('requestsLoading');
    const empty = document.getElementById('requestsEmpty');
    if (!container) return;
    if (loading) loading.style.display = 'none';
    if (!requests || requests.length === 0) {
        if (empty) empty.style.display = 'block';
        container.innerHTML = '';
        container.appendChild(empty);
        return;
    }
    if (empty) empty.style.display = 'none';
    container.innerHTML = '';
    
    // SORT: Priority (VIP/Fast Track) requests first, then by date
    requests.sort((a, b) => {
        const aPriority = (a.form_data && (a.form_data.is_priority === true || a.form_data.is_priority === 'true' || a.form_data.is_priority == 1)) ? 1 : 0;
        const bPriority = (b.form_data && (b.form_data.is_priority === true || b.form_data.is_priority === 'true' || b.form_data.is_priority == 1)) ? 1 : 0;
        
        // Priority first (descending)
        if (bPriority !== aPriority) {
            return bPriority - aPriority;
        }
        
        // Then by date (newest first)
        return new Date(b.request_date || 0) - new Date(a.request_date || 0);
    });
    
    requests.forEach(request => {
        // Check if this is a priority (VIP/Fast Track) request
        // Handle both boolean true and string "true" / "1"
        const isPriorityRequest = request.form_data && 
            (request.form_data.is_priority === true || 
             request.form_data.is_priority === 'true' || 
             request.form_data.is_priority === '1' ||
             request.form_data.is_priority == 1);
        
        const card = document.createElement('div');
        card.className = `request-card request-card-compact ${request.request_type === 'premium' ? 'premium' : 'normal'}${isPriorityRequest ? ' request-priority' : ''}`;
        card.setAttribute('data-request-id', request.id);
        card.setAttribute('data-status', request.status);
        if (isPriorityRequest) {
            card.setAttribute('data-priority', 'true');
        }
        
        // Priority label takes precedence over request_type
        let labelClass, labelText;
        if (isPriorityRequest) {
            labelClass = 'request-label-vip';
            labelText = '⭐ VIP - Customer Chose You';
        } else if (request.request_type === 'premium') {
            labelClass = 'request-label-premium';
            labelText = 'Premium Request';
        } else {
            labelClass = 'request-label-normal';
            labelText = 'Regular Request';
        }
        // Use time_ago if available (from server), otherwise calculate from request_date
        const formattedDate = request.time_ago || formatRequestTime(request.request_date);
        // Check if this is a Sell Car request
        const isSellCarRequest = request.request_type === 'sell_car' || 
                                 (request.request_details && request.request_details.toLowerCase().includes('sell car'));
        
        let actionsHtml = '';
        if (request.status === 'pending') {
            // Don't show Accept button in list - must open modal to enter price (or accept for sell_car)
            actionsHtml = `<div class="request-actions"><button class="btn btn-primary btn-sm view-request-btn" data-request-id="${request.id}" title="Click to view details and send offer">📋 View & Send Offer</button><button class="btn btn-outline btn-sm delete-request-btn" data-request-id="${request.id}" style="color: hsl(var(--destructive)); border-color: hsl(var(--destructive));">✕ Delete</button></div>`;
        } else if (request.status === 'waiting_customer_approval') {
            const offerPrice = request.form_data && request.form_data.offer_price ? request.form_data.offer_price : '';
            actionsHtml = `<div class="request-actions"><span class="status-badge status-waiting-approval">Offer Sent${offerPrice ? ' - €' + offerPrice : ''}</span></div>`;
        } else if (request.status === 'accepted') {
            if (isSellCarRequest) {
                // Sell Car: No Start Work button - just show status (waiting for customer to confirm sale)
                actionsHtml = `<div class="request-actions"><span class="status-badge status-accepted">Accepted</span><span style="margin-left: 8px; font-size: 0.75rem; color: hsl(var(--muted-foreground));">⏳ Awaiting Customer</span></div>`;
            } else {
                // Other services: Show Start Work button
                actionsHtml = `<div class="request-actions"><span class="status-badge status-accepted">Accepted</span><button class="btn btn-primary btn-sm in-progress-btn" data-request-id="${request.id}" style="margin-left: 8px;">▶ Start Work</button></div>`;
            }
        } else if (request.status === 'in_progress') {
            // Sell Car requests should never reach in_progress, but handle just in case
            if (isSellCarRequest) {
                actionsHtml = `<div class="request-actions"><span class="status-badge status-in-progress">In Progress</span></div>`;
            } else {
                actionsHtml = `<div class="request-actions"><span class="status-badge status-in-progress">In Progress</span><button class="btn btn-primary btn-sm complete-request-btn" data-request-id="${request.id}" style="margin-left: 8px;">✓ Mark as Complete</button></div>`;
            }
        } else if (request.status === 'pending_completion') {
            actionsHtml = `<div class="request-actions"><span class="status-badge status-pending-completion">Awaiting Customer Confirmation</span></div>`;
        } else if (request.status === 'complete' || request.status === 'completed') {
            actionsHtml = `<div class="request-actions"><span class="status-badge status-complete">Completed</span></div>`;
        }
        let statusBadge = '';
        if (request.status === 'waiting_customer_approval') {
            statusBadge = '<span class="status-badge status-waiting-approval">Offer Sent</span>';
        } else if (request.status === 'accepted') {
            statusBadge = '<span class="status-badge status-accepted">Accepted</span>';
        } else if (request.status === 'in_progress') {
            statusBadge = '<span class="status-badge status-in-progress">In Progress</span>';
        } else if (request.status === 'pending_completion') {
            statusBadge = '<span class="status-badge status-pending-completion">Awaiting Confirmation</span>';
        } else if (request.status === 'complete' || request.status === 'completed') {
            statusBadge = '<span class="status-badge status-complete">Completed</span>';
        } else if (request.status !== 'pending') {
            statusBadge = `<span class="status-badge status-${request.status}">${request.status.charAt(0).toUpperCase() + request.status.slice(1).replace('_', ' ')}</span>`;
        }
        card.innerHTML = `<div class="request-header"><div style="width: 100%;"><span class="${labelClass}">${labelText}</span><h3 class="request-title">${request.customer_name || 'Unknown Customer'}</h3><div class="request-meta"><span>📅 ${formattedDate}</span>${statusBadge ? `<span>•</span>${statusBadge}` : ''}</div><div class="request-details" style="margin-top: 0.75rem; color: hsl(var(--muted-foreground)); font-size: 0.875rem;">${request.request_details || 'Service Request'}</div></div></div>${actionsHtml}`;
        card.style.cursor = 'pointer';
        card.addEventListener('click', function(e) {
            // Don't open modal if clicking on buttons
            if (e.target.closest('.accept-request-btn') || e.target.closest('.delete-request-btn') || e.target.closest('.complete-request-btn') || e.target.closest('.view-request-btn') || e.target.closest('.in-progress-btn')) {
                return;
            }
            // Ensure modal is initialized before opening
            if (!requestModal || !requestModalBody) {
                initRequestModal();
            }
            if (typeof openRequestModal === 'function') {
                openRequestModal(request);
            } else {
                console.error('openRequestModal function not found');
            }
        });
        container.appendChild(card);
    });
    attachRequestHandlers();
}

// Global variable to store all requests for modal access
let allRequests = [];

function loadPartnerRequests(statusFilter = 'all') {
    currentRequestFilter = statusFilter;
    const container = document.getElementById('requestsList');
    const loading = document.getElementById('requestsLoading');
    if (loading) loading.style.display = 'block';
    const formData = new FormData();
    formData.append('action', 'get_partner_requests');
    formData.append('nonce', wheelfy.nonce);
    formData.append('status_filter', statusFilter);
    fetch(wheelfy.ajaxUrl, { method: 'POST', body: formData })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Store requests globally for modal access
            allRequests = data.data.requests || [];
            renderPartnerRequests(data.data.requests);
            updateRequestBadge(data.data.pending_count);
        } else {
            console.error('Failed to load requests:', data.data);
            allRequests = [];
            renderPartnerRequests([]);
        }
    })
    .catch(error => {
        console.error('Error loading requests:', error);
        renderPartnerRequests([]);
    });
}

function updateRequestBadge(count) {
    const badge = document.getElementById('requestsBadgeCount');
    if (badge) {
        if (count > 0) {
            badge.textContent = count;
            badge.style.display = 'inline-flex';
        } else {
            badge.style.display = 'none';
        }
    }
}

function attachRequestHandlers() {
    // View & Send Offer button - opens modal with price form
    document.querySelectorAll('.view-request-btn').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.stopPropagation();
            const requestId = this.getAttribute('data-request-id');
            // Find the request data from allRequests
            const request = allRequests.find(r => r.id === requestId);
            if (request && typeof openRequestModal === 'function') {
                openRequestModal(request);
            } else {
                // Fallback: click on the card to open modal
                const card = this.closest('.request-card');
                if (card) {
                    card.click();
                }
            }
        });
    });
    
    // Legacy accept-request-btn handler (if any still exist) - redirect to modal
    document.querySelectorAll('.accept-request-btn').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.stopPropagation();
            const requestId = this.getAttribute('data-request-id');
            // Find the request data and open modal instead of direct accept
            const request = allRequests.find(r => r.id === requestId);
            if (request && typeof openRequestModal === 'function') {
                openRequestModal(request);
            } else {
                alert('Please click on the request card to view details and send your offer with price.');
            }
        });
    });
    document.querySelectorAll('.delete-request-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const requestId = this.getAttribute('data-request-id');
            if (!confirm('Are you sure you want to delete this request? This action is final and irreversible.')) return;
            this.disabled = true;
            this.textContent = 'Deleting...';
            const formData = new FormData();
            formData.append('action', 'update_request_status');
            formData.append('nonce', wheelfy.nonce);
            formData.append('request_id', requestId);
            formData.append('status', 'rejected');
            fetch(wheelfy.ajaxUrl, { method: 'POST', body: formData })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const requestCard = this.closest('.request-card');
                    if (requestCard) {
                        requestCard.style.transition = 'opacity 0.3s, transform 0.3s';
                        requestCard.style.opacity = '0';
                        requestCard.style.transform = 'translateX(-20px)';
                        setTimeout(() => {
                            requestCard.remove();
                            loadPartnerRequests(currentRequestFilter);
                        }, 300);
                    }
                } else {
                    alert(data.data.message || 'Failed to delete request.');
                    this.disabled = false;
                    this.textContent = '✕ Delete';
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred. Please try again.');
                this.disabled = false;
                this.textContent = '✕ Delete';
            });
        });
    });
    document.querySelectorAll('.in-progress-btn').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.stopPropagation();
            const requestId = this.getAttribute('data-request-id');
            if (!confirm('Are you sure you want to mark this request as "In Progress"? The customer will be notified.')) return;
            this.disabled = true;
            this.textContent = 'Processing...';
            const formData = new FormData();
            formData.append('action', 'wheelfy_mark_in_progress');
            formData.append('nonce', wheelfy.nonce);
            formData.append('request_id', requestId);
            fetch(wheelfy.ajaxUrl, { method: 'POST', body: formData })
            .then(response => response.text())
            .then(text => {
                let data;
                try {
                    const jsonStart = text.indexOf('{');
                    if (jsonStart > 0) text = text.substring(jsonStart);
                    data = JSON.parse(text);
                } catch (e) {
                    console.error('Failed to parse response:', text);
                    throw new Error('Invalid response');
                }
                if (data.success) {
                    alert('Request marked as "In Progress"! The customer has been notified.');
                    loadPartnerRequests(currentRequestFilter);
                } else {
                    alert((data.data && data.data.message) || 'Failed to mark request as in progress.');
                    this.disabled = false;
                    this.textContent = '▶ Start Work';
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('A system error occurred. Please try again.');
                this.disabled = false;
                this.textContent = '▶ Start Work';
            });
        });
    });
    document.querySelectorAll('.complete-request-btn').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.stopPropagation();
            const requestId = this.getAttribute('data-request-id');
            if (!confirm('Are you sure you want to mark this request as complete? The customer will be notified to confirm completion.')) return;
            this.disabled = true;
            this.textContent = 'Processing...';
            const formData = new FormData();
            formData.append('action', 'wheelfy_complete_request');
            formData.append('nonce', wheelfy.nonce);
            formData.append('request_id', requestId);
            fetch(wheelfy.ajaxUrl, { method: 'POST', body: formData })
            .then(response => response.text())
            .then(text => {
                let data;
                try {
                    const jsonStart = text.indexOf('{');
                    if (jsonStart > 0) text = text.substring(jsonStart);
                    data = JSON.parse(text);
                } catch (e) {
                    console.error('Failed to parse response:', text);
                    throw new Error('Invalid response');
                }
                if (data.success) {
                    const msg = (data.data && data.data.message) || 'Request marked as complete! Waiting for customer confirmation.';
                    alert(msg);
                    loadPartnerRequests(currentRequestFilter);
                } else {
                    alert((data.data && data.data.message) || 'Failed to mark request as complete.');
                    this.disabled = false;
                    this.textContent = '✓ Mark as Complete';
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('A system error occurred. Please try again.');
                this.disabled = false;
                this.textContent = '✓ Mark as Complete';
            });
        });
    });
}

function startRequestPolling() {
    requestPollInterval = setInterval(() => {
        loadPartnerRequests(currentRequestFilter);
    }, 15000);
}

function stopRequestPolling() {
    if (requestPollInterval) {
        clearInterval(requestPollInterval);
        requestPollInterval = null;
    }
}

document.addEventListener('DOMContentLoaded', function() {
    // Initialize modal first
    initRequestModal();
    
    loadPartnerRequests('all');
    const requestTabs = document.getElementById('requestTabs');
    if (requestTabs) {
        requestTabs.addEventListener('click', function(e) {
            if (e.target.classList.contains('tab-btn')) {
                requestTabs.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
                e.target.classList.add('active');
                const filter = e.target.getAttribute('data-filter');
                loadPartnerRequests(filter);
            }
        });
    }
    startRequestPolling();
    document.addEventListener('visibilitychange', function() {
        if (document.hidden) {
            stopRequestPolling();
        } else {
            startRequestPolling();
            loadPartnerRequests(currentRequestFilter);
        }
    });
});
</script>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Store all reviews for filtering/searching
    let allPartnerReviews = [];
    
    // Initialize - store all reviews
    function initializePartnerReviews() {
        allPartnerReviews = [];
        const reviewsList = document.getElementById('partnerReviewsList');
        if (!reviewsList) {
            console.log('Reviews list not found');
            return false;
        }
        
        const reviewCards = reviewsList.querySelectorAll('.review-card');
        reviewCards.forEach(function(card) {
            const rating = parseInt(card.getAttribute('data-rating')) || 0;
            const customerName = (card.getAttribute('data-customer-name') || '').toLowerCase();
            const reviewText = (card.getAttribute('data-review-text') || '').toLowerCase();
            
            allPartnerReviews.push({
                element: card,
                rating: rating,
                customerName: customerName,
                reviewText: reviewText
            });
        });
     
        return allPartnerReviews.length > 0;
    }
    
    // Filter and search reviews
    function filterAndSearchPartnerReviews() {
        if (allPartnerReviews.length === 0) {
            return;
        }
        
        const filterSelect = document.getElementById('filterReviews');
        const searchInput = document.getElementById('searchReviews');
        if (!filterSelect || !searchInput) return;
        
        const filterValue = filterSelect.value || 'all';
        const searchValue = (searchInput.value || '').toLowerCase().trim();
        
        console.log('Filtering - Rating:', filterValue, 'Search:', searchValue);
        
        let visibleCount = 0;
        
        allPartnerReviews.forEach(function(review) {
            let show = true;
            
            // Filter by rating
            if (filterValue !== 'all') {
                const selectedRating = parseInt(filterValue);
                if (review.rating !== selectedRating) {
                    show = false;
                }
            }
            
            // Search in customer name and review text
            if (show && searchValue) {
                const customerMatch = review.customerName && review.customerName.indexOf(searchValue) !== -1;
                const textMatch = review.reviewText && review.reviewText.indexOf(searchValue) !== -1;
                if (!customerMatch && !textMatch) {
                    show = false;
                }
            }
            
            // Show or hide review card
            review.element.style.display = show ? '' : 'none';
            if (show) visibleCount++;
        });
        
        console.log('Visible reviews:', visibleCount);
        
        // Show/hide empty state
        const reviewsList = document.getElementById('partnerReviewsList');
        if (!reviewsList) return;
        
        const existingEmptyState = reviewsList.nextElementSibling;
        const isFilteredEmptyState = existingEmptyState && existingEmptyState.classList.contains('empty-state-filtered');
        
        if (visibleCount === 0 && allPartnerReviews.length > 0) {
            if (isFilteredEmptyState) {
                existingEmptyState.style.display = 'block';
            } else {
                const emptyStateDiv = document.createElement('div');
                emptyStateDiv.className = 'empty-state-filtered empty-state';
                emptyStateDiv.style.cssText = 'text-align: center; padding: 3rem; display: block;';
                emptyStateDiv.innerHTML = '<div class="empty-state-icon" style="margin: 0 auto 1rem auto; display: flex; justify-content: center; align-items: center;"><svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"></path></svg></div><h3 class="empty-state-title">No reviews match your filters</h3><p class="empty-state-text">Try adjusting your search or filter criteria.</p>';
                reviewsList.parentNode.insertBefore(emptyStateDiv, reviewsList.nextSibling);
            }
        } else {
            if (isFilteredEmptyState) {
                existingEmptyState.style.display = 'none';
            }
        }
    }
    
    // Initialize when reviews section is visible
    function initReviewsFilter() {
        const reviewsList = document.getElementById('partnerReviewsList');
        const filterSelect = document.getElementById('filterReviews');
        const searchInput = document.getElementById('searchReviews');
        
        if (!reviewsList || !filterSelect || !searchInput) {
            return;
        }
        
        const reviewCards = reviewsList.querySelectorAll('.review-card');
        if (reviewCards.length === 0) {
            return;
        }
        
        // Initialize reviews
        if (initializePartnerReviews()) {
            // Remove existing listeners by cloning
            const newFilter = filterSelect.cloneNode(true);
            filterSelect.parentNode.replaceChild(newFilter, filterSelect);
            const newSearch = searchInput.cloneNode(true);
            searchInput.parentNode.replaceChild(newSearch, searchInput);
            
            // Filter dropdown change event
            document.getElementById('filterReviews').addEventListener('change', filterAndSearchPartnerReviews);
            
            // Search input event with debounce
            let searchTimeout;
            document.getElementById('searchReviews').addEventListener('input', function() {
                clearTimeout(searchTimeout);
                searchTimeout = setTimeout(filterAndSearchPartnerReviews, 300);
            });
            
        }
    }
    
    // Initialize on page load
    setTimeout(initReviewsFilter, 100);
    
    // Re-initialize when section becomes visible (for tab navigation)
    document.addEventListener('click', function(e) {
        const navItem = e.target.closest('.nav-item[data-section="reviews"]');
        if (navItem) {
            setTimeout(initReviewsFilter, 200);
        }
    });
    
    // Also check when reviews section is shown
    const reviewsSection = document.getElementById('reviewsSection');
    if (reviewsSection && reviewsSection.classList.contains('active')) {
        setTimeout(initReviewsFilter, 200);
    }
    
    // Image Modal Event Listeners
    const imageModal = document.getElementById('imageModal');
    const imageModalClose = document.querySelector('.image-modal-close');
    
    if (imageModalClose) {
        imageModalClose.addEventListener('click', closeImageModal);
    }
    
    if (imageModal) {
        imageModal.addEventListener('click', function(e) {
            if (e.target === imageModal) {
                closeImageModal();
            }
        });
    }
    
    // Close image modal on Escape key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            closeImageModal();
        }
    });
});
</script>

    <!-- Image Modal -->
    <div id="imageModal" class="image-modal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.9); z-index: 10000; align-items: center; justify-content: center;">
        <div class="image-modal-content" style="position: relative; max-width: 90%; max-height: 90%; display: flex; flex-direction: column; align-items: center;">
            <button class="image-modal-close" style="position: absolute; top: -40px; right: 0; background: rgba(255, 255, 255, 0.2); border: none; color: white; width: 40px; height: 40px; border-radius: 50%; cursor: pointer; font-size: 24px; display: flex; align-items: center; justify-content: center; transition: background 0.2s;" onmouseover="this.style.background='rgba(255, 255, 255, 0.3)'" onmouseout="this.style.background='rgba(255, 255, 255, 0.2)'">×</button>
            <img id="imageModalImg" src="" alt="" style="max-width: 100%; max-height: 80vh; border-radius: 8px; box-shadow: 0 4px 20px rgba(0, 0, 0, 0.5);">
            <div class="image-modal-actions" style="margin-top: 20px; display: flex; gap: 10px;">
                <button id="imageModalDownload" class="image-modal-download" style="padding: 10px 20px; background: hsl(var(--primary)); color: white; border: none; border-radius: 6px; cursor: pointer; font-size: 14px; font-weight: 600; transition: opacity 0.2s;" onmouseover="this.style.opacity='0.9'" onmouseout="this.style.opacity='1'">Download</button>
            </div>
        </div>
    </div>

<?php
get_footer();

