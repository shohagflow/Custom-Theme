<?php
/**
 * Template Name: Partner Profile
 * 
 * Public Partner Profile Page
 * Shows partner details and allows customers with completed services to leave reviews
 */

// Get partner ID from URL
$partner_id = get_query_var('partner_id');
if (empty($partner_id)) {
    $partner_id = isset($_GET['partner_id']) ? intval($_GET['partner_id']) : 0;
}

// Check if partner exists and is a valid partner
$partner = get_userdata($partner_id);
if (!$partner) {
    wp_redirect(home_url('/'));
    exit;
}

// Check if user is a partner
$user_type = get_user_meta($partner_id, 'user_type', true);
$user_roles = $partner->roles;
$is_partner = ($user_type === 'partner' || in_array('partner', $user_roles));

if (!$is_partner) {
    wp_redirect(home_url('/'));
    exit;
}

// Get current logged-in user
$current_user_id = get_current_user_id();
$is_logged_in = is_user_logged_in();

// Get partner data
$partner_name = $partner->display_name ?: $partner->user_login;
$business_name = get_user_meta($partner_id, 'business_name', true);
$display_name = !empty($business_name) ? $business_name : $partner_name;
$user_email = $partner->user_email;
$user_bio = get_user_meta($partner_id, 'user_bio', true);
$user_phone = get_user_meta($partner_id, 'phone_number', true);
$user_location = get_user_meta($partner_id, 'user_location', true);
$partner_profession = get_user_meta($partner_id, 'partner_profession', true);
$partner_experience = get_user_meta($partner_id, 'partner_experience', true);
$partner_tier = get_user_meta($partner_id, 'partner_tier', true) ?: 'standard';
$partner_type = get_user_meta($partner_id, 'partner_type', true);
$is_car_dealership = ($partner_type === 'car_dealership');
$user_registered = $partner->user_registered;

// Get verification status
$is_verified = get_user_meta($partner_id, 'partner_verified', true);

// Social links
$user_facebook = get_user_meta($partner_id, 'user_facebook', true);
$user_twitter = get_user_meta($partner_id, 'user_twitter', true);
$user_instagram = get_user_meta($partner_id, 'user_instagram', true);
$user_linkedin = get_user_meta($partner_id, 'user_linkedin', true);

// Get profile image
$profile_image_id = get_user_meta($partner_id, 'profile_image_id', true);
if ($profile_image_id && is_numeric($profile_image_id)) {
    $user_avatar = wp_get_attachment_image_url($profile_image_id, 'full');
} else {
    $user_avatar = get_avatar_url($partner_id, array('size' => 200));
}
$user_initials = strtoupper(substr($display_name, 0, 1));

// Get partner statistics
// For car dealerships, use cars purchased count; for repair shops, use completed jobs count
if ($is_car_dealership) {
    $completed_jobs = function_exists('wheelfy_get_partner_cars_purchased_count') ? wheelfy_get_partner_cars_purchased_count($partner_id) : 0;
    $jobs_label = 'Cars Purchased';
} else {
    $completed_jobs = function_exists('wheelfy_get_partner_completed_jobs_count') ? wheelfy_get_partner_completed_jobs_count($partner_id) : 0;
    $jobs_label = 'Jobs Completed';
}
$total_reviews = function_exists('wheelfy_get_partner_reviews_count') ? wheelfy_get_partner_reviews_count($partner_id) : 0;
$response_rate = function_exists('wheelfy_get_partner_response_rate') ? wheelfy_get_partner_response_rate($partner_id) : 95;

// Calculate average rating from reviews
$partner_reviews = get_user_meta($partner_id, 'wheelfy_reviews_received', true);
if (!is_array($partner_reviews)) {
    $partner_reviews = array();
}

// Filter reviews that should be displayed publicly
// IMPORTANT: Only show approved/published reviews. Pending reviews need admin approval first.
// Show: approved, published, OR reviews without status (backward compatibility for old reviews)
// Hide: pending, cancelled, rejected
$approved_reviews = array_filter($partner_reviews, function($review) {
    // If no status, treat as approved (backward compatibility for old reviews created before status system)
    if (!isset($review['status'])) {
        return true;
    }
    // Only show approved or published reviews - pending reviews are hidden until admin approves
    $allowed_statuses = array('approved', 'published');
    return in_array($review['status'], $allowed_statuses);
});

$avg_rating = 0;
if (!empty($approved_reviews)) {
    $total_rating = array_sum(array_column($approved_reviews, 'rating'));
    $avg_rating = round($total_rating / count($approved_reviews), 1);
}

// Check if current user can leave a review
// IMPORTANT: Customer can only review if they have completed requests with this partner
$can_review = false;
$eligible_requests = array();
if ($is_logged_in && $current_user_id != $partner_id) {
    // Check if customer has any completed requests with this partner
    // IMPORTANT: Only customers who have completed requests with this partner can review
    // Query posts where customer is author, status is 'complete', and partner_id matches
    $args = array(
        'post_type' => 'post', // Requests are stored as 'post' type
        'post_status' => 'publish',
        'posts_per_page' => -1,
        'author' => $current_user_id, // Customer created the request
        'meta_query' => array(
            'relation' => 'AND',
            array(
                'key' => '_proposal_status',
                'value' => 'complete',
                'compare' => '='
            ),
            array(
                'key' => 'partner_id',
                'value' => $partner_id,
                'compare' => '='
            )
        )
    );
    
    $completed_requests = get_posts($args);
    
    // Also check for requests where _proposal_accepted_by matches (alternative format)
    if (empty($completed_requests)) {
        $args2 = array(
            'post_type' => 'post',
            'post_status' => 'publish',
            'posts_per_page' => -1,
            'author' => $current_user_id,
            'meta_query' => array(
                'relation' => 'AND',
                array(
                    'key' => '_proposal_status',
                    'value' => 'complete',
                    'compare' => '='
                ),
                array(
                    'key' => '_proposal_accepted_by',
                    'value' => $partner_id,
                    'compare' => '='
                )
            )
        );
        $completed_requests_alt = get_posts($args2);
        if (!empty($completed_requests_alt)) {
            $completed_requests = $completed_requests_alt;
        }
    }
    
    // Query 2: Also check transient/request data for non-logged-in user requests that were later linked
    // This handles cases where customer submitted request before login but later logged in
    $customer_email = '';
    if ($is_logged_in) {
        $customer_user = get_userdata($current_user_id);
        $customer_email = $customer_user ? $customer_user->user_email : '';
    }
    
    // If we found completed requests, check which ones haven't been reviewed
    if (!empty($completed_requests)) {
        // Get customer's existing reviews for this partner
        $customer_reviews = get_user_meta($current_user_id, 'wheelfy_reviews_given', true);
        if (!is_array($customer_reviews)) {
            $customer_reviews = array();
        }
        
        $reviewed_request_ids = array();
        foreach ($customer_reviews as $review) {
            // Check both request_id formats (post_ID and request_id string)
            if (isset($review['request_id']) && isset($review['partner_id']) && $review['partner_id'] == $partner_id) {
                $reviewed_request_ids[] = $review['request_id'];
                // Also check post_ID format
                if (isset($review['post_ID'])) {
                    $reviewed_request_ids[] = $review['post_ID'];
                }
            }
        }
        
        // Find requests not yet reviewed - only allow 1 review per completed request
        foreach ($completed_requests as $request) {
            $request_id = $request->ID;
            $post_id_str = 'post_' . $request_id;
            
            // Check if this request has already been reviewed
            $already_reviewed = in_array($request_id, $reviewed_request_ids) || 
                               in_array($post_id_str, $reviewed_request_ids);
            
            if (!$already_reviewed) {
                // Get request details
                $request_type = get_post_meta($request_id, '_proposal_request_type', true);
                $car_brand = get_post_meta($request_id, '_proposal_car_brand', true);
                $car_model = get_post_meta($request_id, '_proposal_car_model', true);
                $car_year = get_post_meta($request_id, '_proposal_car_year', true);
                
                $request_title = 'Service Request';
                if ($car_brand && $car_model) {
                    $request_title = ($car_year ? $car_year . ' ' : '') . $car_brand . ' ' . $car_model;
                    if ($request_type) {
                        $request_title .= ' - ' . ucfirst($request_type);
                    }
                } elseif ($request_type) {
                    $request_title = ucfirst($request_type) . ' Request';
                }
                
                $eligible_requests[] = array(
                    'id' => $request_id,
                    'post_id' => $request_id,
                    'title' => $request_title,
                    'completed_date' => get_post_meta($request_id, '_proposal_completed_date', true) ?: get_post_meta($request_id, '_proposal_completion_requested_date', true)
                );
            }
        }
        
        // Customer can review only if they have at least one eligible (completed but not reviewed) request
        $can_review = !empty($eligible_requests);
    }
}

// Member since
$member_since = date('F Y', strtotime($user_registered));

get_header();
?>

<style>
/* ============================================
   PARTNER PROFILE PAGE STYLES
   ============================================ */
   
:root {
    --profile-gradient: linear-gradient(135deg, hsl(60 96% 79%), hsl(186 80% 19%));
    --profile-accent: hsl(186 80% 35%);
    --profile-accent-light: hsl(186 80% 45%);
}

.partner-profile-page {
    min-height: 100vh;
    background: hsl(var(--background));
    padding-bottom: 4rem;
}

/* Hero Section */
.profile-hero {
    background: var(--profile-gradient);
    padding: 3rem 0;
    position: relative;
    overflow: hidden;
}

.profile-hero::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.08'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
    opacity: 0.5;
}

.profile-hero-content {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 1.5rem;
    display: flex;
    align-items: center;
    gap: 2.5rem;
    position: relative;
    z-index: 1;
}

.profile-avatar-wrapper {
    flex-shrink: 0;
}

.profile-avatar {
    width: 160px;
    height: 160px;
    border-radius: 50%;
    border: 5px solid white;
    box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
    object-fit: cover;
    background: hsl(var(--card));
}

.profile-avatar-initials {
    width: 160px;
    height: 160px;
    border-radius: 50%;
    border: 5px solid white;
    background: hsl(var(--card));
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 4rem;
    font-weight: 800;
    color: var(--profile-accent);
    box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
}

.profile-hero-info {
    flex: 1;
    color: hsl(var(--primary-foreground));
}

.profile-tier-badge {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    padding: 0.375rem 1rem;
    background: rgba(255, 255, 255, 0.25);
    backdrop-filter: blur(10px);
    border-radius: 2rem;
    font-size: 0.8125rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    margin-bottom: 0.75rem;
}

.profile-tier-badge.premium {
    background: linear-gradient(135deg, #ffd700, #ffb347);
    color: #1a1a2e;
}

.profile-tier-badge.standard {
    background: rgba(255, 255, 255, 0.25);
}

.profile-hero-name {
    font-size: 2.5rem;
    font-weight: 800;
    margin: 0 0 0.5rem;
    display: flex;
    align-items: center;
    gap: 0.75rem;
    flex-wrap: wrap;
}

/* Verified Badge */
.verified-badge {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 32px;
    height: 32px;
    background: linear-gradient(135deg, #00c853, #00e676);
    border-radius: 50%;
    box-shadow: 0 4px 12px rgba(0, 200, 83, 0.4);
    flex-shrink: 0;
    cursor: help;
    position: relative;
    animation: verifiedPulse 2s ease-in-out infinite;
}

.verified-badge svg {
    width: 18px;
    height: 18px;
    color: white;
    stroke-width: 3;
}

.verified-badge::after {
    content: attr(data-tooltip);
    position: absolute;
    bottom: calc(100% + 8px);
    left: 50%;
    transform: translateX(-50%);
    padding: 0.5rem 0.75rem;
    background: rgba(0, 0, 0, 0.85);
    color: white;
    font-size: 0.75rem;
    font-weight: 600;
    white-space: nowrap;
    border-radius: 0.5rem;
    opacity: 0;
    visibility: hidden;
    transition: all 0.2s ease;
    pointer-events: none;
    z-index: 10;
}

.verified-badge::before {
    content: '';
    position: absolute;
    bottom: calc(100% + 2px);
    left: 50%;
    transform: translateX(-50%);
    border: 6px solid transparent;
    border-top-color: rgba(0, 0, 0, 0.85);
    opacity: 0;
    visibility: hidden;
    transition: all 0.2s ease;
}

.verified-badge:hover::after,
.verified-badge:hover::before {
    opacity: 1;
    visibility: visible;
}

@keyframes verifiedPulse {
    0%, 100% {
        box-shadow: 0 4px 12px rgba(0, 200, 83, 0.4);
    }
    50% {
        box-shadow: 0 4px 20px rgba(0, 200, 83, 0.6);
    }
}

.profile-hero-profession {
    font-size: 1.125rem;
    opacity: 0.95;
    margin-bottom: 1rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.profile-hero-stats {
    display: flex;
    gap: 2rem;
    flex-wrap: wrap;
}

.hero-stat {
    text-align: left;
}

.hero-stat-value {
    font-size: 1.75rem;
    font-weight: 800;
}

.hero-stat-label {
    font-size: 0.875rem;
    opacity: 0.9;
}

/* Rating Stars */
.rating-stars {
    display: flex;
    align-items: center;
    gap: 0.25rem;
}

.rating-stars svg {
    width: 20px;
    height: 20px;
}

.rating-stars .star-filled {
    color: #ffd700;
    fill: #ffd700;
}

.rating-stars .star-empty {
    color: rgba(255, 255, 255, 0.4);
    fill: none;
}

/* Main Content */
.profile-main {
    max-width: 1200px;
    margin: -2rem auto 0;
    padding: 0 1.5rem;
    position: relative;
    z-index: 2;
}

.profile-grid {
    display: grid;
    grid-template-columns: 1fr 380px;
    gap: 2rem;
}

/* Cards */
.profile-card {
    background: hsl(var(--card));
    border-radius: 1.25rem;
    border: 1px solid hsl(var(--border));
    overflow: hidden;
    box-shadow: 0 4px 20px hsl(var(--foreground) / 0.05);
}

.profile-card-header {
    padding: 1.25rem 1.5rem;
    border-bottom: 1px solid hsl(var(--border));
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.profile-card-title {
    font-size: 1.125rem;
    font-weight: 700;
    color: hsl(var(--foreground));
    margin: 0;
    display: flex;
    align-items: center;
    gap: 0.75rem;
}

.profile-card-title svg {
    width: 22px;
    height: 22px;
    color: var(--profile-accent);
}

.profile-card-body {
    padding: 1.5rem;
}

/* About Section */
.about-content {
    font-size: 1rem;
    line-height: 1.8;
    color: hsl(var(--foreground));
}

.about-content.no-bio {
    color: hsl(var(--muted-foreground));
    font-style: italic;
}

/* Info Grid */
.info-grid {
    display: grid;
    gap: 1.25rem;
}

.info-item {
    display: flex;
    align-items: flex-start;
    gap: 1rem;
}

.info-icon {
    width: 44px;
    height: 44px;
    border-radius: 0.75rem;
    background: linear-gradient(135deg, hsl(60 96% 79% / 0.15), hsl(186 80% 19% / 0.15));
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.info-icon svg {
    width: 20px;
    height: 20px;
    color: var(--profile-accent);
}

.info-content {
    flex: 1;
    min-width: 0;
}

.info-label {
    font-size: 0.8125rem;
    color: hsl(var(--muted-foreground));
    margin-bottom: 0.25rem;
}

.info-value {
    font-size: 0.9375rem;
    font-weight: 600;
    color: hsl(var(--foreground));
    word-break: break-word;
}

/* Social Links */
.social-links {
    display: flex;
    gap: 0.75rem;
    flex-wrap: wrap;
}

.social-link {
    width: 44px;
    height: 44px;
    border-radius: 0.75rem;
    background: hsl(var(--muted));
    display: flex;
    align-items: center;
    justify-content: center;
    color: hsl(var(--foreground));
    transition: all 0.3s ease;
    text-decoration: none;
}

.social-link:hover {
    background: var(--profile-gradient);
    color: hsl(var(--primary-foreground));
    transform: translateY(-2px);
}

.social-link svg {
    width: 20px;
    height: 20px;
}

/* Stats Cards */
.stats-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 1rem;
}

.stat-card {
    background: linear-gradient(135deg, hsl(60 96% 79% / 0.08), hsl(186 80% 19% / 0.08));
    border-radius: 1rem;
    padding: 1.25rem;
    text-align: center;
    border: 1px solid hsl(var(--border) / 0.5);
}

.stat-card-value {
    font-size: 2rem;
    font-weight: 800;
    background: var(--profile-gradient);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.stat-card-label {
    font-size: 0.8125rem;
    color: hsl(var(--muted-foreground));
    margin-top: 0.25rem;
}

/* Reviews Section */
.reviews-list {
    display: flex;
    flex-direction: column;
    gap: 1.25rem;
}

.review-item {
    padding: 1.25rem;
    background: hsl(var(--muted) / 0.3);
    border-radius: 1rem;
    border: 1px solid hsl(var(--border) / 0.5);
}

.review-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 0.75rem;
}

.review-author {
    display: flex;
    align-items: center;
    gap: 0.75rem;
}

.review-author-avatar {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: var(--profile-gradient);
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 700;
    color: hsl(var(--primary-foreground));
    font-size: 1rem;
}

.review-author-name {
    font-weight: 600;
    color: hsl(var(--foreground));
}

.review-date {
    font-size: 0.8125rem;
    color: hsl(var(--muted-foreground));
}

.review-rating {
    display: flex;
    gap: 0.125rem;
}

.review-rating svg {
    width: 16px;
    height: 16px;
    color: #ffd700;
    fill: #ffd700;
}

.review-text {
    font-size: 0.9375rem;
    line-height: 1.7;
    color: hsl(var(--foreground));
}

.no-reviews {
    text-align: center;
    padding: 2rem;
    color: hsl(var(--muted-foreground));
}

.no-reviews svg {
    width: 48px;
    height: 48px;
    margin-bottom: 1rem;
    opacity: 0.5;
}

/* Write Review Section */
.write-review-card {
    background: linear-gradient(135deg, hsl(60 96% 79% / 0.1), hsl(186 80% 19% / 0.1));
    border: 2px dashed hsl(var(--border));
}

.write-review-prompt {
    text-align: center;
    padding: 1.5rem 1rem;
}

.write-review-prompt svg {
    width: 40px;
    height: 40px;
    color: var(--profile-accent);
    margin-bottom: 0.75rem;
    opacity: 0.8;
}

.write-review-prompt h3 {
    font-size: 1rem;
    font-weight: 700;
    color: hsl(var(--foreground));
    margin-bottom: 0.5rem;
}

.write-review-prompt p {
    font-size: 0.8125rem;
    color: hsl(var(--muted-foreground));
    margin-bottom: 1rem;
    line-height: 1.5;
}

.btn-write-review {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
    padding: 0.625rem 1.25rem;
    background: linear-gradient(135deg, hsl(186 80% 35%), hsl(186 80% 25%));
    color: hsl(var(--primary-foreground));
    border: none;
    border-radius: 0.5rem;
    font-size: 0.875rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.2s ease;
    box-shadow: 0 2px 8px hsl(186 80% 19% / 0.2);
    position: relative;
    overflow: hidden;
}

.btn-write-review::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
    transition: left 0.5s ease;
}

.btn-write-review:hover {
    transform: translateY(-1px);
    box-shadow: 0 4px 12px hsl(186 80% 19% / 0.35);
    background: linear-gradient(135deg, hsl(186 80% 40%), hsl(186 80% 30%));
}

.btn-write-review:hover::before {
    left: 100%;
}

.btn-write-review:active {
    transform: translateY(0);
    box-shadow: 0 2px 6px hsl(186 80% 19% / 0.25);
}

.btn-write-review svg {
    width: 14px;
    height: 14px;
    flex-shrink: 0;
}

/* Review Form Modal */
.review-modal-overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.6);
    backdrop-filter: blur(4px);
    z-index: 9999;
    display: none;
    align-items: center;
    justify-content: center;
    padding: 1rem;
}

.review-modal-overlay.active {
    display: flex;
}

.review-modal {
    background: hsl(var(--card));
    border-radius: 1.25rem;
    max-width: 500px;
    width: 100%;
    max-height: 90vh;
    overflow-y: auto;
    box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
}

.review-modal-header {
    padding: 1.5rem;
    border-bottom: 1px solid hsl(var(--border));
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.review-modal-header h3 {
    font-size: 1.25rem;
    font-weight: 700;
    color: hsl(var(--foreground));
    margin: 0;
}

.review-modal-close {
    width: 36px;
    height: 36px;
    border-radius: 50%;
    background: hsl(var(--muted));
    border: none;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    color: hsl(var(--foreground));
    transition: all 0.2s;
}

.review-modal-close:hover {
    background: hsl(var(--destructive));
    color: white;
}

.review-modal-body {
    padding: 1.5rem;
}

.form-group {
    margin-bottom: 1.5rem;
}

.form-label {
    display: block;
    font-size: 0.875rem;
    font-weight: 600;
    color: hsl(var(--foreground));
    margin-bottom: 0.5rem;
}

.rating-input {
    display: flex;
    gap: 0.5rem;
}

.rating-star {
    width: 40px;
    height: 40px;
    background: hsl(var(--muted));
    border: none;
    border-radius: 0.5rem;
    cursor: pointer;
    transition: all 0.2s;
    display: flex;
    align-items: center;
    justify-content: center;
}

.rating-star:hover,
.rating-star.active {
    background: #ffd700;
    color: #1a1a2e;
}

.rating-star svg {
    width: 24px;
    height: 24px;
}

.form-select,
.form-textarea {
    width: 100%;
    padding: 0.875rem 1rem;
    background: hsl(var(--background));
    border: 1px solid hsl(var(--border));
    border-radius: 0.75rem;
    font-size: 0.9375rem;
    color: hsl(var(--foreground));
    transition: border-color 0.2s;
}

.form-select:focus,
.form-textarea:focus {
    outline: none;
    border-color: var(--profile-accent);
}

.form-textarea {
    min-height: 120px;
    resize: vertical;
}

.btn-submit-review {
    width: 100%;
    padding: 1rem;
    background: var(--profile-gradient);
    color: hsl(var(--primary-foreground));
    border: none;
    border-radius: 0.75rem;
    font-size: 1rem;
    font-weight: 700;
    cursor: pointer;
    transition: all 0.3s;
}

.btn-submit-review:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 20px hsl(186 80% 19% / 0.3);
}

.btn-submit-review:disabled {
    opacity: 0.6;
    cursor: not-allowed;
    transform: none;
}

/* Login Prompt */
.login-prompt {
    text-align: center;
    padding: 2rem;
    background: hsl(var(--muted) / 0.3);
    border-radius: 1rem;
}

.login-prompt p {
    color: hsl(var(--muted-foreground));
    margin-bottom: 1rem;
}

.btn-login {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    padding: 0.75rem 1.5rem;
    background: hsl(var(--foreground));
    color: hsl(var(--background));
    border: none;
    border-radius: 0.75rem;
    font-size: 0.9375rem;
    font-weight: 600;
    text-decoration: none;
    transition: all 0.3s;
}

.btn-login:hover {
    transform: translateY(-2px);
    opacity: 0.9;
}

/* Back Button */
.back-nav {
    max-width: 1200px;
    margin: 0 auto;
    padding: 1rem 1.5rem;
}

.btn-back {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    padding: 0.5rem 1rem;
    background: hsl(var(--card));
    border: 1px solid hsl(var(--border));
    border-radius: 0.5rem;
    color: hsl(var(--foreground));
    text-decoration: none;
    font-size: 0.875rem;
    font-weight: 500;
    transition: all 0.2s;
}

.btn-back:hover {
    background: hsl(var(--muted));
}

/* Responsive */
@media (max-width: 1024px) {
    .profile-grid {
        grid-template-columns: 1fr;
    }
}

@media (max-width: 768px) {
    .profile-hero-content {
        flex-direction: column;
        text-align: center;
    }
    
    .profile-hero-name {
        font-size: 1.75rem;
    }
    
    .profile-hero-stats {
        justify-content: center;
    }
    
    .hero-stat {
        text-align: center;
    }
    
    .profile-avatar,
    .profile-avatar-initials {
        width: 120px;
        height: 120px;
    }
    
    .profile-avatar-initials {
        font-size: 3rem;
    }
    
    .stats-grid {
        grid-template-columns: 1fr;
    }
}
</style>

<div class="partner-profile-page">
    <!-- Back Navigation -->
    <div class="back-nav">
        <a href="javascript:history.back()" class="btn-back">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M19 12H5"></path>
                <path d="M12 19l-7-7 7-7"></path>
            </svg>
            Back
        </a>
    </div>

    <!-- Hero Section -->
    <section class="profile-hero">
        <div class="profile-hero-content">
            <div class="profile-avatar-wrapper">
                <?php if (!empty($user_avatar)) : ?>
                    <img src="<?php echo esc_url($user_avatar); ?>" alt="<?php echo esc_attr($display_name); ?>" class="profile-avatar">
                <?php else : ?>
                    <div class="profile-avatar-initials"><?php echo esc_html($user_initials); ?></div>
                <?php endif; ?>
            </div>
            
            <div class="profile-hero-info">
                <span class="profile-tier-badge <?php echo esc_attr($partner_tier); ?>">
                    <?php if ($partner_tier === 'premium') : ?>
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                        </svg>
                    <?php endif; ?>
                    <?php echo esc_html(ucfirst($partner_tier)); ?> Partner
                </span>
                
                <h1 class="profile-hero-name">
                    <?php echo esc_html($display_name); ?>
                    <?php if ($is_verified) : ?>
                        <span class="verified-badge" data-tooltip="<?php esc_attr_e('Verified Partner', 'wheelfy'); ?>">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
                                <polyline points="20 6 9 17 4 12"></polyline>
                            </svg>
                        </span>
                    <?php endif; ?>
                </h1>
                
                <?php if (!empty($partner_profession) && !$is_car_dealership) : ?>
                    <p class="profile-hero-profession">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M20 7h-9m9 10H4M4 7l3-3 3 3M4 17l3 3 3-3"/>
                        </svg>
                        <?php echo esc_html($partner_profession); ?>
                    </p>
                <?php endif; ?>
                
                <div class="profile-hero-stats">
                    <div class="hero-stat">
                        <div class="hero-stat-value">
                            <div class="rating-stars">
                                <?php 
                                $full_stars = floor($avg_rating);
                                $half_star = ($avg_rating - $full_stars) >= 0.5;
                                for ($i = 1; $i <= 5; $i++) {
                                    if ($i <= $full_stars) {
                                        echo '<svg class="star-filled" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>';
                                    } else {
                                        echo '<svg class="star-empty" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>';
                                    }
                                }
                                ?>
                                <span style="margin-left: 0.5rem; font-size: 1.25rem;"><?php echo number_format($avg_rating, 1); ?></span>
                            </div>
                        </div>
                        <div class="hero-stat-label"><?php echo count($approved_reviews); ?> Reviews</div>
                    </div>
                    
                    <div class="hero-stat">
                        <div class="hero-stat-value"><?php echo esc_html($completed_jobs); ?></div>
                        <div class="hero-stat-label"><?php echo esc_html($jobs_label); ?></div>
                    </div>
                    
                    <div class="hero-stat">
                        <div class="hero-stat-value"><?php echo esc_html($response_rate); ?>%</div>
                        <div class="hero-stat-label">Response Rate</div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Main Content -->
    <div class="profile-main">
        <div class="profile-grid">
            <!-- Left Column -->
            <div class="profile-left">
                <!-- About Card -->
                <div class="profile-card" style="margin-bottom: 2rem;">
                    <div class="profile-card-header">
                        <h2 class="profile-card-title">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                                <circle cx="12" cy="7" r="4"></circle>
                            </svg>
                            About
                        </h2>
                    </div>
                    <div class="profile-card-body">
                        <?php if (!empty($user_bio)) : ?>
                            <p class="about-content"><?php echo nl2br(esc_html($user_bio)); ?></p>
                        <?php else : ?>
                            <p class="about-content no-bio">No bio available yet.</p>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Services Card (Only for Repair Shop partners) -->
                <?php if (!$is_car_dealership) : 
                    $partner_services = function_exists('wheelfy_get_partner_services') ? wheelfy_get_partner_services($partner_id, 'active') : array();
                ?>
                <div class="profile-card" style="margin-bottom: 2rem;">
                    <div class="profile-card-header">
                        <h2 class="profile-card-title">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"></path>
                            </svg>
                            Services
                        </h2>
                        <span style="font-size: 0.875rem; color: hsl(var(--muted-foreground));"><?php echo count($partner_services); ?> services</span>
                    </div>
                    <div class="profile-card-body">
                        <?php if (!empty($partner_services)) : ?>
                            <div class="services-list" style="display: grid; gap: 1rem;">
                                <?php foreach ($partner_services as $service) : 
                                    $service_id = isset($service['id']) ? $service['id'] : '';
                                    $service_price = isset($service['price']) ? floatval($service['price']) : 0;
                                    $service_currency = isset($service['price_currency']) ? $service['price_currency'] : 'EUR';
                                    $currency_symbol = ($service_currency === 'HUF') ? 'HUF' : '€';
                                    $price_display = ($service_currency === 'HUF') ? number_format($service_price, 0, ',', ' ') : number_format($service_price, 2);
                                ?>
                                    <div class="service-item" style="padding: 1.25rem; background: hsl(var(--card)); border: 1px solid hsl(var(--border)); border-radius: 0.75rem; transition: all 0.2s;">
                                        <div style="display: flex; justify-content: space-between; align-items: start; gap: 1rem; margin-bottom: 0.75rem;">
                                            <div style="flex: 1;">
                                                <h3 style="margin: 0 0 0.5rem; font-size: 1.125rem; font-weight: 600; color: hsl(var(--foreground));">
                                                    <?php echo esc_html($service['title']); ?>
                                                </h3>
                                                <p style="margin: 0; font-size: 0.9375rem; color: hsl(var(--muted-foreground)); line-height: 1.6;">
                                                    <?php echo esc_html($service['description']); ?>
                                                </p>
                                            </div>
                                        </div>
                                        
                                        <div style="display: flex; align-items: center; gap: 1.5rem; margin-top: 1rem; padding-top: 1rem; border-top: 1px solid hsl(var(--border));">
                                            <div style="display: flex; align-items: center; gap: 0.5rem; font-size: 0.9375rem; font-weight: 600; color: hsl(var(--primary));">
                                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                                    <line x1="12" y1="1" x2="12" y2="23"></line>
                                                    <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
                                                </svg>
                                                <span><?php echo esc_html($currency_symbol . $price_display); ?></span>
                                            </div>
                                            
                                            <div style="display: flex; align-items: center; gap: 0.5rem; font-size: 0.875rem; color: hsl(var(--muted-foreground));">
                                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                                    <circle cx="12" cy="12" r="10"></circle>
                                                    <polyline points="12 6 12 12 16 14"></polyline>
                                                </svg>
                                                <span>
                                                    <?php 
                                                    $duration = isset($service['duration']) ? trim($service['duration']) : '';
                                                    // Check if duration already contains "hour" or "hours" or other time units
                                                    if (!empty($duration)) {
                                                        $duration_lower = strtolower($duration);
                                                        // If it's just a number or doesn't contain time units, add "hours"
                                                        if (is_numeric($duration) || (!preg_match('/\b(hour|hours|hr|hrs|minute|minutes|min|mins|day|days)\b/i', $duration_lower))) {
                                                            echo esc_html($duration . ' hours');
                                                        } else {
                                                            echo esc_html($duration);
                                                        }
                                                    } else {
                                                        echo 'Not specified';
                                                    }
                                                    ?>
                                                </span>
                                            </div>
                                            
                                            <?php if (!empty($service['category'])) : ?>
                                            <div style="display: flex; align-items: center; gap: 0.5rem; font-size: 0.875rem; color: hsl(var(--muted-foreground));">
                                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                                    <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                                                    <line x1="3" y1="9" x2="21" y2="9"></line>
                                                    <line x1="9" y1="21" x2="9" y2="9"></line>
                                                </svg>
                                                <span><?php echo esc_html($service['category']); ?></span>
                                            </div>
                                            <?php endif; ?>
                                        </div>
                                        
                                        <?php if ($is_logged_in && $current_user_id != $partner_id) : ?>
                                        <div style="margin-top: 1rem;">
                                            <form method="post" action="<?php echo esc_url(home_url('/request-service')); ?>" style="margin: 0;">
                                                <?php wp_nonce_field('request_service', 'request_service_nonce'); ?>
                                                <input type="hidden" name="service_id" value="<?php echo esc_attr($service_id); ?>">
                                                <input type="hidden" name="partner_id" value="<?php echo esc_attr($partner_id); ?>">
                                                <button type="submit" class="btn-request-service" style="width: 100%; padding: 0.75rem 1.5rem; background: linear-gradient(135deg, hsl(60 96% 79%), hsl(186 80% 19%)); color: hsl(var(--primary-foreground)); border: none; border-radius: 0.5rem; font-weight: 600; font-size: 0.9375rem; cursor: pointer; transition: all 0.2s;">
                                                    Request This Service
                                                </button>
                                            </form>
                                        </div>
                                        <?php elseif (!$is_logged_in) : ?>
                                        <div style="margin-top: 1rem;">
                                            <a href="<?php echo esc_url(wp_login_url(get_permalink())); ?>" class="btn-request-service" style="display: block; width: 100%; padding: 0.75rem 1.5rem; background: linear-gradient(135deg, hsl(60 96% 79%), hsl(186 80% 19%)); color: hsl(var(--primary-foreground)); border: none; border-radius: 0.5rem; font-weight: 600; font-size: 0.9375rem; text-align: center; text-decoration: none; transition: all 0.2s;">
                                                Login to Request Service
                                            </a>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php else : ?>
                            <div style="text-align: center; padding: 2rem; color: hsl(var(--muted-foreground));">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width: 48px; height: 48px; margin: 0 auto 1rem; opacity: 0.5;">
                                    <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"></path>
                                </svg>
                                <p style="margin: 0;">No services available yet.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Reviews Card -->
                <div class="profile-card">
                    <div class="profile-card-header">
                        <h2 class="profile-card-title">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                            </svg>
                            Customer Reviews
                        </h2>
                        <span style="font-size: 0.875rem; color: hsl(var(--muted-foreground));"><?php echo count($approved_reviews); ?> reviews</span>
                    </div>
                    <div class="profile-card-body">
                        <?php if (!empty($approved_reviews)) : ?>
                            <div class="reviews-list">
                                <?php 
                                // Sort by newest first (check multiple date field formats for backward compatibility)
                                usort($approved_reviews, function($a, $b) {
                                    $date_a = 0;
                                    $date_b = 0;
                                    
                                    // Try multiple date field formats
                                    if (isset($a['date'])) {
                                        $date_a = strtotime($a['date']);
                                    } elseif (isset($a['created_at'])) {
                                        $date_a = strtotime($a['created_at']);
                                    } elseif (isset($a['created_timestamp'])) {
                                        $date_a = intval($a['created_timestamp']);
                                    }
                                    
                                    if (isset($b['date'])) {
                                        $date_b = strtotime($b['date']);
                                    } elseif (isset($b['created_at'])) {
                                        $date_b = strtotime($b['created_at']);
                                    } elseif (isset($b['created_timestamp'])) {
                                        $date_b = intval($b['created_timestamp']);
                                    }
                                    
                                    return $date_b - $date_a;
                                });
                                
                                // Show only last 5 reviews
                                $display_reviews = array_slice($approved_reviews, 0, 5);
                                
                                foreach ($display_reviews as $review) : 
                                    $reviewer_name = isset($review['customer_name']) ? $review['customer_name'] : 'Customer';
                                    $reviewer_initial = strtoupper(substr($reviewer_name, 0, 1));
                                    
                                    // Get review date (check multiple field formats for backward compatibility)
                                    $review_date = 'Unknown';
                                    if (isset($review['date'])) {
                                        $review_date = date('M d, Y', strtotime($review['date']));
                                    } elseif (isset($review['created_at'])) {
                                        $review_date = date('M d, Y', strtotime($review['created_at']));
                                    }
                                    
                                    $review_rating = isset($review['rating']) ? intval($review['rating']) : 5;
                                ?>
                                    <div class="review-item">
                                        <div class="review-header">
                                            <div class="review-author">
                                                <div class="review-author-avatar"><?php echo esc_html($reviewer_initial); ?></div>
                                                <div>
                                                    <div class="review-author-name"><?php echo esc_html($reviewer_name); ?></div>
                                                    <div class="review-date"><?php echo esc_html($review_date); ?></div>
                                                </div>
                                            </div>
                                            <div class="review-rating">
                                                <?php for ($i = 1; $i <= 5; $i++) : ?>
                                                    <?php if ($i <= $review_rating) : ?>
                                                        <svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
                                                    <?php else : ?>
                                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="color: hsl(var(--border));"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
                                                    <?php endif; ?>
                                                <?php endfor; ?>
                                            </div>
                                        </div>
                                        <?php if (!empty($review['review_text'])) : ?>
                                            <p class="review-text"><?php echo esc_html($review['review_text']); ?></p>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php else : ?>
                            <div class="no-reviews">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                                </svg>
                                <p>No reviews yet. Be the first to leave a review!</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Right Column -->
            <div class="profile-right">
                <!-- Contact & Info Card -->
                <div class="profile-card" style="margin-bottom: 2rem;">
                    <div class="profile-card-header">
                        <h2 class="profile-card-title">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                                <circle cx="12" cy="10" r="3"></circle>
                            </svg>
                            Contact Info
                        </h2>
                    </div>
                    <div class="profile-card-body">
                        <div class="info-grid">
                            <?php if (!empty($user_location)) : ?>
                                <div class="info-item">
                                    <div class="info-icon">
                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                                            <circle cx="12" cy="10" r="3"></circle>
                                        </svg>
                                    </div>
                                    <div class="info-content">
                                        <div class="info-label">Location</div>
                                        <div class="info-value"><?php echo esc_html($user_location); ?></div>
                                    </div>
                                </div>
                            <?php endif; ?>
                            
                            <?php if (!empty($partner_experience) && !$is_car_dealership) : ?>
                                <div class="info-item">
                                    <div class="info-icon">
                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <rect x="2" y="7" width="20" height="14" rx="2" ry="2"></rect>
                                            <path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"></path>
                                        </svg>
                                    </div>
                                    <div class="info-content">
                                        <div class="info-label">Experience</div>
                                        <div class="info-value"><?php echo esc_html($partner_experience); ?> years</div>
                                    </div>
                                </div>
                            <?php endif; ?>
                            
                            <div class="info-item">
                                <div class="info-icon">
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                                        <line x1="16" y1="2" x2="16" y2="6"></line>
                                        <line x1="8" y1="2" x2="8" y2="6"></line>
                                        <line x1="3" y1="10" x2="21" y2="10"></line>
                                    </svg>
                                </div>
                                <div class="info-content">
                                    <div class="info-label">Member Since</div>
                                    <div class="info-value"><?php echo esc_html($member_since); ?></div>
                                </div>
                            </div>
                        </div>
                        
                        <?php if (!empty($user_facebook) || !empty($user_twitter) || !empty($user_instagram) || !empty($user_linkedin)) : ?>
                            <div style="margin-top: 1.5rem; padding-top: 1.5rem; border-top: 1px solid hsl(var(--border));">
                                <div class="info-label" style="margin-bottom: 0.75rem;">Social Links</div>
                                <div class="social-links">
                                    <?php if (!empty($user_facebook)) : ?>
                                        <a href="<?php echo esc_url($user_facebook); ?>" target="_blank" class="social-link" title="Facebook">
                                            <svg viewBox="0 0 24 24" fill="currentColor"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg>
                                        </a>
                                    <?php endif; ?>
                                    <?php if (!empty($user_twitter)) : ?>
                                        <a href="<?php echo esc_url($user_twitter); ?>" target="_blank" class="social-link" title="Twitter">
                                            <svg viewBox="0 0 24 24" fill="currentColor"><path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z"/></svg>
                                        </a>
                                    <?php endif; ?>
                                    <?php if (!empty($user_instagram)) : ?>
                                        <a href="<?php echo esc_url($user_instagram); ?>" target="_blank" class="social-link" title="Instagram">
                                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line></svg>
                                        </a>
                                    <?php endif; ?>
                                    <?php if (!empty($user_linkedin)) : ?>
                                        <a href="<?php echo esc_url($user_linkedin); ?>" target="_blank" class="social-link" title="LinkedIn">
                                            <svg viewBox="0 0 24 24" fill="currentColor"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/><rect x="2" y="9" width="4" height="12"/><circle cx="4" cy="4" r="2"/></svg>
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Stats Card -->
                <div class="profile-card" style="margin-bottom: 2rem;">
                    <div class="profile-card-header">
                        <h2 class="profile-card-title">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <line x1="18" y1="20" x2="18" y2="10"></line>
                                <line x1="12" y1="20" x2="12" y2="4"></line>
                                <line x1="6" y1="20" x2="6" y2="14"></line>
                            </svg>
                            Statistics
                        </h2>
                    </div>
                    <div class="profile-card-body">
                        <div class="stats-grid">
                            <div class="stat-card">
                                <div class="stat-card-value"><?php echo esc_html($completed_jobs); ?></div>
                                <div class="stat-card-label"><?php echo esc_html($is_car_dealership ? 'Cars Purchased' : 'Jobs Done'); ?></div>
                            </div>
                            <div class="stat-card">
                                <div class="stat-card-value"><?php echo count($approved_reviews); ?></div>
                                <div class="stat-card-label">Reviews</div>
                            </div>
                            <div class="stat-card">
                                <div class="stat-card-value"><?php echo number_format($avg_rating, 1); ?></div>
                                <div class="stat-card-label">Avg Rating</div>
                            </div>
                            <div class="stat-card">
                                <div class="stat-card-value"><?php echo esc_html($response_rate); ?>%</div>
                                <div class="stat-card-label">Response</div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Write Review Card -->
                <?php if ($can_review) : ?>
                    <div class="profile-card write-review-card">
                        <div class="profile-card-body">
                            <div class="write-review-prompt">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                                    <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                                </svg>
                                <h3>Share Your Experience</h3>
                                <p>You've completed a service with this partner. Leave a review to help others!</p>
                                <button type="button" class="btn-write-review" onclick="openReviewModal()">
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                                    </svg>
                                    Write a Review
                                </button>
                            </div>
                        </div>
                    </div>
                <?php elseif (!$is_logged_in) : ?>
                    <div class="profile-card">
                        <div class="profile-card-body">
                            <div class="login-prompt">
                                <p>Login to leave a review for this partner</p>
                                <a href="<?php echo esc_url(wp_login_url(get_permalink())); ?>" class="btn-login">
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"></path>
                                        <polyline points="10 17 15 12 10 7"></polyline>
                                        <line x1="15" y1="12" x2="3" y2="12"></line>
                                    </svg>
                                    Login
                                </a>
                            </div>
                        </div>
                    </div>
                <?php else : ?>
                    <!-- Logged in but no completed requests -->
                    <div class="profile-card">
                        <div class="profile-card-body">
                            <div class="login-prompt" style="text-align: center; padding: 2rem;">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width: 48px; height: 48px; margin: 0 auto 1rem; opacity: 0.5;">
                                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                                </svg>
                                <p style="color: hsl(var(--muted-foreground)); margin: 0;">You can only review partners after completing a service with them.</p>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php if ($can_review) : ?>
<!-- Review Modal -->
<div class="review-modal-overlay" id="reviewModalOverlay">
    <div class="review-modal">
        <div class="review-modal-header">
            <h3>Write a Review</h3>
            <button type="button" class="review-modal-close" onclick="closeReviewModal()">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <line x1="18" y1="6" x2="6" y2="18"></line>
                    <line x1="6" y1="6" x2="18" y2="18"></line>
                </svg>
            </button>
        </div>
        <div class="review-modal-body">
            <form id="reviewForm">
                <input type="hidden" name="partner_id" value="<?php echo esc_attr($partner_id); ?>">
                <input type="hidden" name="nonce" value="<?php echo wp_create_nonce('wheelfy_submit_review'); ?>">
                
                <div class="form-group">
                    <label class="form-label">Select Service</label>
                    <select name="request_id" class="form-select" required>
                        <option value="">Choose a completed service...</option>
                        <?php foreach ($eligible_requests as $request) : ?>
                            <option value="<?php echo esc_attr($request['id']); ?>">
                                <?php echo esc_html(ucfirst($request['title'])); ?> 
                                <?php if (!empty($request['completed_date'])) : ?>
                                    (<?php echo esc_html(date('M d, Y', strtotime($request['completed_date']))); ?>)
                                <?php endif; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Your Rating</label>
                    <div class="rating-input" id="ratingInput">
                        <?php for ($i = 1; $i <= 5; $i++) : ?>
                            <button type="button" class="rating-star" data-rating="<?php echo $i; ?>">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                                </svg>
                            </button>
                        <?php endfor; ?>
                    </div>
                    <input type="hidden" name="rating" id="ratingValue" value="0" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Your Review</label>
                    <textarea name="review_text" class="form-textarea" placeholder="Share your experience with this partner..." required></textarea>
                </div>
                
                <button type="submit" class="btn-submit-review" id="submitReviewBtn">
                    Submit Review
                </button>
            </form>
        </div>
    </div>
</div>

<script>
// Review Modal Functions
function openReviewModal() {
    document.getElementById('reviewModalOverlay').classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closeReviewModal() {
    document.getElementById('reviewModalOverlay').classList.remove('active');
    document.body.style.overflow = '';
}

// Close modal on overlay click
document.getElementById('reviewModalOverlay').addEventListener('click', function(e) {
    if (e.target === this) {
        closeReviewModal();
    }
});

// Close modal on Escape key
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closeReviewModal();
    }
});

// Rating stars interaction
document.querySelectorAll('.rating-star').forEach(star => {
    star.addEventListener('click', function() {
        const rating = parseInt(this.getAttribute('data-rating'));
        document.getElementById('ratingValue').value = rating;
        
        // Update visual state
        document.querySelectorAll('.rating-star').forEach((s, index) => {
            if (index < rating) {
                s.classList.add('active');
                s.querySelector('svg').setAttribute('fill', 'currentColor');
            } else {
                s.classList.remove('active');
                s.querySelector('svg').setAttribute('fill', 'none');
            }
        });
    });
    
    // Hover effect
    star.addEventListener('mouseenter', function() {
        const rating = parseInt(this.getAttribute('data-rating'));
        document.querySelectorAll('.rating-star').forEach((s, index) => {
            if (index < rating) {
                s.style.background = '#ffd700';
                s.style.color = '#1a1a2e';
            }
        });
    });
    
    star.addEventListener('mouseleave', function() {
        const currentRating = parseInt(document.getElementById('ratingValue').value);
        document.querySelectorAll('.rating-star').forEach((s, index) => {
            if (index >= currentRating) {
                s.style.background = '';
                s.style.color = '';
            }
        });
    });
});

// Form submission
document.getElementById('reviewForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const submitBtn = document.getElementById('submitReviewBtn');
    const rating = document.getElementById('ratingValue').value;
    
    if (rating === '0') {
        alert('Please select a rating');
        return;
    }
    
    submitBtn.disabled = true;
    submitBtn.textContent = 'Submitting...';
    
    const formData = new FormData(this);
    formData.append('action', 'wheelfy_submit_review');
    
    fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Review submitted successfully! It will appear after admin approval.');
            closeReviewModal();
            location.reload();
        } else {
            alert(data.data && data.data.message ? data.data.message : 'Failed to submit review. Please try again.');
            submitBtn.disabled = false;
            submitBtn.textContent = 'Submit Review';
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred. Please try again.');
        submitBtn.disabled = false;
        submitBtn.textContent = 'Submit Review';
    });
});
</script>
<?php endif; ?>

<?php get_footer(); ?>
