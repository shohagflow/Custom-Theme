<?php
/**
 * Template Name: Car Accessories Form
 * 
 * Page template for the car accessories form
 * Includes the form from form/car-accessories-form.php
 *
 * @package Wheelfy
 */

get_header();

// Include the form file properly
$form_file = get_template_directory() . '/form/car-accessories-form.php';
if (file_exists($form_file)) {
    // Set a flag so the form knows headers/footers are already called
    $wheelfy_headers_already_loaded = true;
    
    // Include the form file - it will execute PHP properly
    // The form file will skip get_header() and get_footer() because of the flag
    include $form_file;
} else {
    // Fallback: Show error message
    ?>
    <section class="py-20">
        <div class="container max-w-4xl">
            <div class="text-center mb-12">
                <h1 class="text-3xl sm:text-4xl font-bold text-foreground mb-4">Car Accessories Form</h1>
                <p class="text-muted-foreground text-lg max-w-2xl mx-auto">Select the accessories and features your car has.</p>
            </div>
            <div class="card text-center">
                <p class="text-red-400">Form file not found. Please contact the administrator.</p>
            </div>
        </div>
    </section>
    <?php
}

get_footer();
?>

