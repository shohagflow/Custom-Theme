<?php
/**
 * Template Name: All Services Form
 * 
 * Page template for car maintenance service requests
 */
// Only call get_header() if not already loaded by page template
if (!isset($wheelfy_headers_already_loaded) || !$wheelfy_headers_already_loaded) {
    get_header();
}
?>

<style>
/* CSS Variables - Match Website Branding Colors */
:root {
    --background: 220 20% 10%;
    --foreground: 210 40% 98%;
    --card: 220 18% 13%;
    --primary: 60 96% 79%;
    --primary-foreground: 220 20% 10%;
    --border: 220 15% 22%;
    --muted-foreground: 215 20% 65%;
    --secondary: 220 15% 18%;
    --brand-yellow: 60 96% 79%;
    --brand-green: 186 80% 19%;
}

/* Tailwind Utilities & Custom Styles */
.container { width: 100%; max-width: 1280px; margin: 0 auto; padding: 0 2rem; }
.max-w-4xl { max-width: 56rem; }
.py-20 { padding-top: 5rem; padding-bottom: 5rem; }
.text-center { text-align: center; }
.mb-12 { margin-bottom: 3rem; }
.mb-6 { margin-bottom: 1.5rem; }
.mb-4 { margin-bottom: 1rem; }
.mt-1 { margin-top: 0.25rem; }
.inline-flex { display: inline-flex; }
.items-center { align-items: center; }
.items-start { align-items: flex-start; }
.gap-2 { gap: 0.5rem; }
.gap-3 { gap: 0.75rem; }
.gap-4 { gap: 1rem; }
.px-4 { padding-left: 1rem; padding-right: 1rem; }
.py-2 { padding-top: 0.5rem; padding-bottom: 0.5rem; }
.rounded-full { border-radius: 9999px; }
.text-sm { font-size: 0.875rem; }
.font-medium { font-weight: 500; }
.text-3xl { font-size: 1.875rem; }
.sm\:text-4xl { font-size: 2.25rem; }
.font-bold { font-weight: 700; }
.text-lg { font-size: 1.125rem; }
.max-w-2xl { max-width: 42rem; }
.mx-auto { margin-left: auto; margin-right: auto; }
.space-y-8 > * + * { margin-top: 2rem; }
.space-y-6 > * + * { margin-top: 1.5rem; }
.space-y-2 > * + * { margin-top: 0.5rem; }
.grid { display: grid; }
.sm\:grid-cols-2 { grid-template-columns: repeat(2, minmax(0, 1fr)); }
.flex { display: flex; }
.flex-1 { flex: 1 1 0%; }
.p-4 { padding: 1rem; }
.rounded-xl { border-radius: 0.75rem; }
.cursor-pointer { cursor: pointer; }
.transition-all { transition: all 0.2s; }
.w-full { width: 100%; }
.mt-4 { margin-top: 1rem; }
.h-4 { height: 1rem; }
.h-5 { height: 1.25rem; }
.rounded-lg { border-radius: 0.5rem; }

/* Card Styles - Match Website Branding */
.card { 
    background: hsl(var(--card)); 
    border: 1px solid hsl(var(--border)); 
    border-radius: 0.75rem; 
    padding: 1.5rem; 
    box-shadow: 0 2px 8px hsl(220 40% 4% / 0.3);
}
.card-header { margin-bottom: 1rem; }
.card-title { 
    font-size: 1.25rem; 
    font-weight: 600; 
    margin-bottom: 0.25rem; 
    color: hsl(var(--foreground)); 
    display: flex; 
    align-items: center; 
    gap: 0.5rem; 
}
.card-description { 
    font-size: 0.875rem; 
    color: hsl(var(--muted-foreground)); 
}

/* Form Styles - Match Website Branding */
input[type="text"], input[type="number"], input[type="date"], select, textarea {
    width: 100%; 
    padding: 0.625rem 0.875rem; 
    background: hsl(var(--background)); 
    border: 1px solid hsl(var(--border));
    border-radius: 0.5rem; 
    color: hsl(var(--foreground)); 
    font-size: 0.875rem;
    transition: all 0.2s ease;
}

/* Date Input Calendar Icon Styling */
input[type="date"] {
    position: relative;
    padding-right: 2.5rem;
    cursor: pointer;
}

input[type="date"]::-webkit-calendar-picker-indicator {
    position: absolute;
    right: 0.75rem;
    top: 50%;
    transform: translateY(-50%);
    width: 1.25rem;
    height: 1.25rem;
    cursor: pointer;
    opacity: 0.7;
    filter: invert(1) brightness(0.8);
    transition: opacity 0.2s ease;
}

input[type="date"]:hover::-webkit-calendar-picker-indicator {
    opacity: 1;
}

input[type="date"]:focus::-webkit-calendar-picker-indicator {
    opacity: 1;
    filter: invert(1) brightness(1);
}

/* Firefox date input styling */
input[type="date"]::-moz-calendar-picker-indicator {
    width: 1.25rem;
    height: 1.25rem;
    cursor: pointer;
    opacity: 0.7;
    filter: invert(1) brightness(0.8);
    transition: opacity 0.2s ease;
}

input[type="date"]:hover::-moz-calendar-picker-indicator,
input[type="date"]:focus::-moz-calendar-picker-indicator {
    opacity: 1;
    filter: invert(1) brightness(1);
}

input:focus, select:focus, textarea:focus {
    outline: none; 
    border-color: hsl(var(--primary)); 
    box-shadow: 0 0 0 3px hsl(var(--primary) / 0.2);
}
textarea { resize: vertical; }
label { display: block; font-size: 0.875rem; font-weight: 500; margin-bottom: 0.5rem; color: hsl(var(--foreground)); }

/* Button Styles - Match Website Branding with Gradient */
.btn { 
    display: inline-flex; 
    align-items: center; 
    justify-content: center; 
    gap: 0.5rem;
    padding: 0.75rem 2rem; 
    font-size: 1rem; 
    font-weight: 600; 
    border-radius: 0.5rem;
    transition: all 0.2s; 
    cursor: pointer; 
    border: none;
    box-shadow: 0 4px 12px hsl(220 40% 4% / 0.4);
}
.btn-hero { 
    background: linear-gradient(135deg, hsl(var(--brand-yellow)), hsl(var(--brand-green))); 
    color: hsl(var(--primary-foreground)); 
}
.btn-hero:hover { 
    background: linear-gradient(135deg, hsl(60 96% 82%), hsl(186 80% 22%)); 
    transform: translateY(-2px); 
    box-shadow: 0 6px 16px hsl(220 40% 4% / 0.5);
}

/* Color Utilities */
.text-primary { color: hsl(var(--primary)); }
.bg-primary\/10 { background-color: hsl(var(--primary) / 0.1); }
.bg-primary\/5 { background-color: hsl(var(--primary) / 0.05); }
.border-primary\/20 { border-color: hsl(var(--primary) / 0.2); }
.border-primary\/50 { border-color: hsl(var(--primary) / 0.5); }
.border-primary { border-color: hsl(var(--primary)); }
.text-foreground { color: hsl(var(--foreground)); }
.text-muted-foreground { color: hsl(var(--muted-foreground)); }
.border-border { border-color: hsl(var(--border)); }
.hover\:border-primary\/50:hover { border-color: hsl(var(--primary) / 0.5); }

/* Checkbox Styles - Match Website Branding Colors */
.service-checkbox { 
    appearance: none;
    -webkit-appearance: none;
    -moz-appearance: none;
    width: 1.25rem; 
    height: 1.25rem; 
    border: 2px solid hsl(var(--primary));
    border-radius: 0.25rem;
    background: transparent;
    cursor: pointer; 
    position: relative;
    flex-shrink: 0;
    margin-top: 0.125rem;
    transition: all 0.2s ease;
}

.service-checkbox:checked {
    background: hsl(var(--primary));
    border-color: hsl(var(--primary));
    box-shadow: 0 0 0 2px hsl(var(--primary) / 0.2);
}

.service-checkbox:checked::after {
    content: '✓';
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    color: hsl(var(--primary-foreground));
    font-size: 0.875rem;
    font-weight: bold;
    line-height: 1;
}

.service-checkbox:hover {
    border-color: hsl(var(--primary) / 0.8);
    box-shadow: 0 0 0 2px hsl(var(--primary) / 0.1);
}

.service-label {
    border: 1px solid hsl(var(--border));
    transition: all 0.2s ease;
    background: hsl(var(--card));
}

.service-label:hover {
    border-color: hsl(var(--primary) / 0.5);
    background: hsl(var(--card));
}

.service-label:has(.service-checkbox:checked) {
    border-color: hsl(var(--primary));
    background: hsl(var(--primary) / 0.1);
    box-shadow: 0 0 0 1px hsl(var(--primary) / 0.2);
}

/* Select All Label Special Styling */
.select-all-label {
    position: relative;
}

.select-all-label:hover {
    border-color: hsl(var(--primary) / 0.7) !important;
    background: linear-gradient(135deg, hsl(var(--primary) / 0.2), hsl(186 80% 19% / 0.2)) !important;
}

.select-all-label:has(.service-checkbox:checked) {
    border-color: hsl(var(--primary)) !important;
    background: linear-gradient(135deg, hsl(var(--primary) / 0.25), hsl(186 80% 19% / 0.25)) !important;
    box-shadow: 0 0 0 2px hsl(var(--primary) / 0.3);
}

/* Indeterminate state for Select All checkbox */
.service-checkbox:indeterminate {
    background: hsl(var(--primary) / 0.5);
    border-color: hsl(var(--primary));
}

.service-checkbox:indeterminate::after {
    content: '−';
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    color: hsl(var(--primary-foreground));
    font-size: 1rem;
    font-weight: bold;
    line-height: 1;
}


/* Group Hover */
.group:hover .group-hover\:translate-x-1 { transform: translateX(0.25rem); }

/* Responsive */
@media (max-width: 640px) {
    .sm\:grid-cols-2 { grid-template-columns: 1fr; }
    .container { padding: 0 1rem; }
}
</style>

<?php
// Get service parameter from URL (check query var first, then GET parameter)
$service_slug = get_query_var('service');
if (empty($service_slug) && isset($_GET['service'])) {
    $service_slug = sanitize_text_field($_GET['service']);
}
$service_slug = !empty($service_slug) ? $service_slug : '';
$services = array(
    'regular-maintenance' => array('label' => 'Regular maintenance', 'icon' => 'wrench', 'description' => 'Regular scheduled maintenance service'),
    'technical-fault' => array('label' => 'Technical fault', 'icon' => 'alert-triangle', 'description' => 'Technical issue or malfunction'),
    'fault-diagnosis' => array('label' => 'Fault diagnosis', 'icon' => 'search', 'description' => 'Diagnose and identify vehicle problems'),
    'oil-change' => array('label' => 'Oil change', 'icon' => 'droplet', 'description' => 'Engine oil and filter replacement'),
    'ac-maintenance' => array('label' => 'Air conditioning maintenance', 'icon' => 'wind', 'description' => 'AC system service and repair'),
    'brake-maintenance' => array('label' => 'Brake or brake pad maintenance', 'icon' => 'circle-stop', 'description' => 'Brake pads, rotors, and brake system service'),
    'tire-replacement' => array('label' => 'Tire replacement', 'icon' => 'circle', 'description' => 'Tire replacement and balancing'),
    'inspection' => array('label' => 'Inspection', 'icon' => 'clipboard-check', 'description' => 'Vehicle inspection and safety check'),
    'other' => array('label' => 'Other', 'icon' => 'more-horizontal', 'description' => 'Custom service request'),
);

$current_service = isset($services[$service_slug]) ? $services[$service_slug] : null;
$service_icon = $current_service ? $current_service['icon'] : 'wrench';
$service_label = $current_service ? $current_service['label'] : 'All Services';
?>

<section class="py-20">
    <div class="container max-w-4xl">
        <div class="text-center mb-12">
            <div class="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-6">
                <i data-lucide="<?php echo esc_attr($service_icon); ?>" class="h-4 w-4 text-primary"></i>
                <span class="text-sm font-medium text-primary">
                    <?php echo esc_html($service_label); ?>
                </span>
            </div>
            <h1 class="text-3xl sm:text-4xl font-bold text-foreground mb-4">
                <?php
                if ($current_service) {
                    echo 'Request ' . esc_html($current_service['label']);
                } else {
                    echo 'All Services - Browse all maintenance services';
                }
                ?>
            </h1>
            <p class="text-muted-foreground text-lg max-w-2xl mx-auto">
                <?php
                if ($current_service) {
                    echo 'Fill out the form below to get quotes for ' . esc_html(strtolower($current_service['label'])) . ' from qualified mechanics.';
                } else {
                    echo "Select the services you need and we'll connect you with qualified mechanics who will compete for your business.";
                }
                ?>
            </p>
        </div>

        <form class="car-maintenance-form space-y-8" method="post">
            <?php wp_nonce_field('all_services_form', 'all_services_form_nonce'); ?>
            <!-- Service Selection -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Select Services</h3>
                    <p class="card-description">Choose one or more maintenance services</p>
                </div>
                <div class="grid sm:grid-cols-2 gap-4">
                    <?php foreach ($services as $service_id => $service) : ?>
                    <label class="service-label flex items-start gap-3 p-4 rounded-xl cursor-pointer">
                        <input
                            type="checkbox"
                            name="services[]"
                            value="<?php echo esc_attr($service_id); ?>"
                            class="service-checkbox individual-service"
                            <?php checked($service_slug === $service_id); ?>
                        />
                        <div class="flex-1">
                            <div class="flex items-center gap-2">
                                <i data-lucide="<?php echo esc_attr($service['icon']); ?>" class="h-4 w-4 text-primary"></i>
                                <span class="font-medium text-foreground"><?php echo esc_html($service['label']); ?></span>
                            </div>
                            <p class="text-sm text-muted-foreground mt-1"><?php echo esc_html($service['description']); ?></p>
                        </div>
                    </label>
                    <?php endforeach; ?>
                    
                    <!-- Select All Option - At the end -->
                    <label class="service-label flex items-start gap-3 p-4 rounded-xl cursor-pointer select-all-label" style="background: linear-gradient(135deg, hsl(var(--primary) / 0.15), hsl(186 80% 19% / 0.15)); border: 2px solid hsl(var(--primary) / 0.4);">
                        <input
                            type="checkbox"
                            id="select-all-services"
                            class="service-checkbox"
                        />
                        <div class="flex-1">
                            <div class="flex items-center gap-2">
                                <i data-lucide="check-check" class="h-4 w-4 text-primary"></i>
                                <span class="font-medium text-foreground" style="color: hsl(var(--primary));">All of them</span>
                            </div>
                            <p class="text-sm text-muted-foreground mt-1">Select all maintenance services at once</p>
                        </div>
                    </label>
                </div>
            </div>

            <!-- Car Information -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Car Information</h3>
                    <p class="card-description">Tell us about your vehicle</p>
                </div>
                <div class="grid sm:grid-cols-2 gap-4">
                    <div class="space-y-2">
                        <label for="make">Make</label>
                        <input type="text" id="make" name="make" placeholder="e.g., Toyota" required />
                    </div>
                    <div class="space-y-2">
                        <label for="model">Model</label>
                        <input type="text" id="model" name="model" placeholder="e.g., Camry" required />
                    </div>
                    <div class="space-y-2">
                        <label for="year">Year</label>
                        <input type="text" id="year" name="year" placeholder="e.g., 2020" required />
                    </div>
                    <div class="space-y-2">
                        <label for="mileage">Mileage (km)</label>
                        <input type="number" id="mileage" name="mileage" placeholder="e.g., 50000" />
                    </div>
                </div>
                <div class="mt-4 space-y-2">
                    <label for="notes">Additional Notes</label>
                    <textarea id="notes" name="additional_notes" rows="3" placeholder="Any additional details about the service needed..."></textarea>
                </div>
            </div>

            <button type="submit" class="btn btn-hero w-full group">
                Submit Request
                <i data-lucide="chevron-right" class="h-5 w-5 group-hover:translate-x-1 transition-transform"></i>
            </button>
        </form>
    </div>
</section>

<script src="https://unpkg.com/lucide@latest"></script>
<script>
    // Initialize Lucide icons after DOM is ready
    document.addEventListener('DOMContentLoaded', function() {
        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }
        
        // Select All Services functionality
        const selectAllCheckbox = document.getElementById('select-all-services');
        const individualCheckboxes = document.querySelectorAll('.individual-service');
        
        if (selectAllCheckbox) {
            // When "All of them" is clicked, select/deselect all services
            selectAllCheckbox.addEventListener('change', function() {
                const isChecked = this.checked;
                individualCheckboxes.forEach(checkbox => {
                    checkbox.checked = isChecked;
                    // Trigger change event to update visual state
                    checkbox.dispatchEvent(new Event('change', { bubbles: true }));
                });
            });
            
            // When any individual checkbox changes, update "All of them" state
            individualCheckboxes.forEach(checkbox => {
                checkbox.addEventListener('change', function() {
                    // Check if all individual checkboxes are checked
                    const allChecked = Array.from(individualCheckboxes).every(cb => cb.checked);
                    const someChecked = Array.from(individualCheckboxes).some(cb => cb.checked);
                    
                    selectAllCheckbox.checked = allChecked;
                    selectAllCheckbox.indeterminate = someChecked && !allChecked;
                });
            });
            
            // Check initial state (if some are pre-selected)
            const allChecked = Array.from(individualCheckboxes).every(cb => cb.checked);
            const someChecked = Array.from(individualCheckboxes).some(cb => cb.checked);
            selectAllCheckbox.checked = allChecked;
            selectAllCheckbox.indeterminate = someChecked && !allChecked;
        }
    });
</script>

<?php
// Only call get_footer() if not already loaded by page template
if (!isset($wheelfy_headers_already_loaded) || !$wheelfy_headers_already_loaded) {
    get_footer();
}
?>

