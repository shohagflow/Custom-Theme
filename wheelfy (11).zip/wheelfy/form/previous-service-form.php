<?php
/**
 * Template Name: Previous Service Form
 * 
 * Page template for previous service section
 */
// Only call get_header() if not already loaded by page template
if (!isset($wheelfy_headers_already_loaded) || !$wheelfy_headers_already_loaded) {
get_header();
}
?>

<style>
/* CSS Variables - Match Website Branding Colors */
:root {
    --background: 220 20% 10%;
    --foreground: 210 40% 98%;
    --card: 220 18% 13%;
    --primary: 60 96% 79%;
    --primary-foreground: 220 20% 10%;
    --border: 220 15% 22%;
    --muted-foreground: 215 20% 65%;
    --secondary: 220 15% 18%;
    --brand-yellow: 60 96% 79%;
    --brand-green: 186 80% 19%;
}

/* Tailwind Utilities & Custom Styles */
.container { width: 100%; max-width: 1280px; margin: 0 auto; padding: 0 2rem; }
.max-w-4xl { max-width: 56rem; }
.py-20 { padding-top: 5rem; padding-bottom: 5rem; }
.text-center { text-align: center; }
.mb-12 { margin-bottom: 3rem; }
.mb-6 { margin-bottom: 1.5rem; }
.mb-4 { margin-bottom: 1rem; }
.inline-flex { display: inline-flex; }
.items-center { align-items: center; }
.gap-2 { gap: 0.5rem; }
.px-4 { padding-left: 1rem; padding-right: 1rem; }
.py-2 { padding-top: 0.5rem; padding-bottom: 0.5rem; }
.rounded-full { border-radius: 9999px; }
.text-sm { font-size: 0.875rem; }
.font-medium { font-weight: 500; }
.text-3xl { font-size: 1.875rem; }
.sm\:text-4xl { font-size: 2.25rem; }
.font-bold { font-weight: 700; }
.text-lg { font-size: 1.125rem; }
.max-w-2xl { max-width: 42rem; }
.mx-auto { margin-left: auto; margin-right: auto; }
.space-y-8 > * + * { margin-top: 2rem; }
.grid { display: grid; }
.sm\:grid-cols-2 { grid-template-columns: repeat(2, minmax(0, 1fr)); }
.gap-4 { gap: 1rem; }
.space-y-6 > * + * { margin-top: 1.5rem; }
.space-y-2 > * + * { margin-top: 0.5rem; }
.w-full { width: 100%; }
.mt-4 { margin-top: 1rem; }
.h-4 { height: 1rem; }
.h-5 { height: 1.25rem; }
.rounded-lg { border-radius: 0.5rem; }

/* Card Styles - Match Website Branding */
.card { 
    background: hsl(var(--card)); 
    border: 1px solid hsl(var(--border)); 
    border-radius: 0.75rem; 
    padding: 1.5rem; 
    box-shadow: 0 2px 8px hsl(220 40% 4% / 0.3);
}
.card-header { margin-bottom: 1rem; }
.card-title { 
    font-size: 1.25rem; 
    font-weight: 600; 
    margin-bottom: 0.25rem; 
    color: hsl(var(--foreground)); 
    display: flex; 
    align-items: center; 
    gap: 0.5rem; 
}
.card-description { 
    font-size: 0.875rem; 
    color: hsl(var(--muted-foreground)); 
}

/* Form Styles - Match Website Branding */
input[type="text"], input[type="date"], input[type="number"], select, textarea {
    width: 100%; 
    padding: 0.625rem 0.875rem; 
    background: hsl(var(--background)); 
    border: 1px solid hsl(var(--border));
    border-radius: 0.5rem; 
    color: hsl(var(--foreground)); 
    font-size: 0.875rem;
    transition: all 0.2s ease;
}

/* Date Input Calendar Icon Styling */
input[type="date"] {
    position: relative;
    padding-right: 2.5rem;
    cursor: pointer;
}

input[type="date"]::-webkit-calendar-picker-indicator {
    position: absolute;
    right: 0.75rem;
    top: 50%;
    transform: translateY(-50%);
    width: 1.25rem;
    height: 1.25rem;
    cursor: pointer;
    opacity: 0.7;
    filter: invert(1) brightness(0.8);
    transition: opacity 0.2s ease;
}

input[type="date"]:hover::-webkit-calendar-picker-indicator {
    opacity: 1;
}

input[type="date"]:focus::-webkit-calendar-picker-indicator {
    opacity: 1;
    filter: invert(1) brightness(1);
}

/* Firefox date input styling */
input[type="date"]::-moz-calendar-picker-indicator {
    width: 1.25rem;
    height: 1.25rem;
    cursor: pointer;
    opacity: 0.7;
    filter: invert(1) brightness(0.8);
    transition: opacity 0.2s ease;
}

input[type="date"]:hover::-moz-calendar-picker-indicator,
input[type="date"]:focus::-moz-calendar-picker-indicator {
    opacity: 1;
    filter: invert(1) brightness(1);
}

input:focus, select:focus, textarea:focus {
    outline: none; 
    border-color: hsl(var(--primary)); 
    box-shadow: 0 0 0 3px hsl(var(--primary) / 0.2);
}

.text-primary { color: hsl(var(--primary)); }
.bg-primary\/10 { background-color: hsl(var(--primary) / 0.1); }
.border-primary\/20 { border-color: hsl(var(--primary) / 0.2); }
.text-foreground { color: hsl(var(--foreground)); }
.text-muted-foreground { color: hsl(var(--muted-foreground)); }
.border-border { border-color: hsl(var(--border)); }
textarea { resize: vertical; }
label { display: block; font-size: 0.875rem; font-weight: 500; margin-bottom: 0.5rem; color: hsl(var(--foreground)); }

/* Button Styles - Match Website Branding with Gradient */
.btn { 
    display: inline-flex; 
    align-items: center; 
    justify-content: center; 
    gap: 0.5rem;
    padding: 0.75rem 2rem; 
    font-size: 1rem; 
    font-weight: 600; 
    border-radius: 0.5rem;
    transition: all 0.2s; 
    cursor: pointer; 
    border: none;
    box-shadow: 0 4px 12px hsl(220 40% 4% / 0.4);
}
.btn-hero { 
    background: linear-gradient(135deg, hsl(var(--brand-yellow)), hsl(var(--brand-green))); 
    color: hsl(var(--primary-foreground)); 
}
.btn-hero:hover { 
    background: linear-gradient(135deg, hsl(60 96% 82%), hsl(186 80% 22%)); 
    transform: translateY(-2px); 
    box-shadow: 0 6px 16px hsl(220 40% 4% / 0.5);
}

@media (max-width: 640px) {
    .sm\:grid-cols-2 { grid-template-columns: 1fr; }
    .container { padding: 0 1rem; }
}
</style>

<section class="py-20">
    <div class="container max-w-4xl">
        <div class="text-center mb-12">
            <div class="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-6">
                <i data-lucide="calendar" class="h-4 w-4 text-primary"></i>
                <span class="text-sm font-medium text-primary">Previous Service</span>
            </div>
            <h1 class="text-3xl sm:text-4xl font-bold text-foreground mb-4">
                Previous Service
            </h1>
            <p class="text-muted-foreground text-lg max-w-2xl mx-auto">
                When was the last service performed on your car
            </p>
        </div>

        <form class="car-sales-form space-y-8" method="post" action="<?php echo esc_url(home_url('/previous-service-form')); ?>">
            <?php wp_nonce_field('previous_service_form', 'previous_service_form_nonce'); ?>
            <!-- Car Information -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Car Information</h3>
                    <p class="card-description">Basic details about your vehicle</p>
                </div>
                <div class="grid sm:grid-cols-2 gap-4">
                    <div class="space-y-2">
                        <label for="make">Make</label>
                        <input type="text" id="make" name="make" placeholder="e.g., BMW" required />
                    </div>
                    <div class="space-y-2">
                        <label for="model">Model</label>
                        <input type="text" id="model" name="model" placeholder="e.g., 3 Series" required />
                    </div>
                    <div class="space-y-2">
                        <label for="year">Year</label>
                        <input type="text" id="year" name="year" placeholder="e.g., 2021" required />
                    </div>
                    <div class="space-y-2">
                        <label for="mileage">Mileage (km)</label>
                        <input type="number" id="mileage" name="mileage" placeholder="e.g., 35000" required />
                    </div>
                </div>
            </div>

            <!-- Previous Service Section -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title flex items-center gap-2">
                        <i data-lucide="calendar" class="h-5 w-5 text-primary"></i>
                        Previous Service Details
                    </h3>
                    <p class="card-description">Information about the last service performed</p>
                </div>
                <div class="space-y-6">
                    <div class="grid sm:grid-cols-2 gap-4">
                        <div class="space-y-2">
                            <label for="lastService">Last Service Date</label>
                            <input type="date" id="lastService" name="last_service_date" required />
                        </div>
                        <div class="space-y-2">
                            <label for="lastServiceMileage">Mileage at Last Service</label>
                            <input type="number" id="lastServiceMileage" name="last_service_mileage" placeholder="e.g., 30000" required />
                        </div>
                    </div>
                    <div class="space-y-2">
                        <label for="serviceType">Type of Service Performed</label>
                        <select id="serviceType" name="service_type" class="w-full">
                            <option value="">Select service type</option>
                            <option value="full">Full Service</option>
                            <option value="interim">Interim Service</option>
                            <option value="major">Major Service</option>
                            <option value="oil-change">Oil Change Only</option>
                            <option value="other">Other</option>
                        </select>
                    </div>
                    <div class="space-y-2">
                        <label for="serviceDetails">Service Details</label>
                        <textarea id="serviceDetails" name="additional_notes" rows="4" placeholder="What was done during the service..."></textarea>
                    </div>
                </div>
            </div>

            <button type="submit" class="btn btn-hero w-full group">
                Submit Request
                <i data-lucide="chevron-right" class="h-5 w-5 group-hover:translate-x-1 transition-transform"></i>
            </button>
        </form>
    </div>
</section>

<script src="https://unpkg.com/lucide@latest"></script>
<script>
    // Initialize Lucide icons after DOM is ready
    document.addEventListener('DOMContentLoaded', function() {
        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }
    });
</script>

<?php
// Only call get_footer() if not already loaded by page template
if (!isset($wheelfy_headers_already_loaded) || !$wheelfy_headers_already_loaded) {
get_footer();
}
?>

