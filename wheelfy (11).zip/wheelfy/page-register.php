<?php
/**
 * Template Name: Register
 * 
 * @package Wheelfy
 */

$user_type = isset($_GET['type']) && $_GET['type'] === 'partner' ? 'partner' : 'customer';
$error = isset($_GET['error']) ? $_GET['error'] : '';
$redirect_to = isset($_GET['redirect_to']) ? esc_url(urldecode($_GET['redirect_to'])) : '';

get_header();
?>

<div class="container mx-auto px-4 lg:px-8 py-24">
    <div class="max-w-md mx-auto">
        <div class="bg-card rounded-3xl p-8 border border-border">
            <div class="text-center mb-8">
                <h1 class="text-3xl font-bold text-foreground mb-2" style="font-size: 45px !important;">
                    Create Account
                </h1>
                <p class="text-muted-foreground">
                    Join thousands of car owners saving money
                </p>
            </div>

            <?php if ($redirect_to) : ?>
                <div class="mb-6 p-4 bg-primary/10 border border-primary/20 rounded-lg">
                    <p class="text-primary text-sm flex items-center gap-2">
                        <svg class="w-5 h-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        <span>Please create an account or login to continue with the form.</span>
                    </p>
                </div>
            <?php endif; ?>

            <?php if ($error) : ?>
                <div class="mb-6 p-4 bg-destructive/10 border border-destructive/20 rounded-lg">
                    <p class="text-destructive text-sm">
                        <?php
                        switch ($error) {
                            case 'password_mismatch':
                                echo 'Passwords do not match. Please try again.';
                                break;
                            case 'weak_password':
                                echo 'Password must be at least 6 characters long.';
                                break;
                            case 'username_exists':
                            case 'existing_user_login':
                                echo 'This username is already registered.';
                                break;
                            case 'email_exists':
                            case 'existing_user_email':
                                echo 'This email address is already registered.';
                                break;
                            case 'empty_fields':
                                echo 'Please fill in all required fields.';
                                break;
                            case 'invalid_email':
                                echo 'Please enter a valid email address.';
                                break;
                            case 'business_required':
                                echo 'Please enter your business name.';
                                break;
                            case 'phone_required':
                                echo 'Please enter your phone number.';
                                break;
                            case 'partner_type_required':
                                echo 'Please select your partner type (Repair Shop or Car Dealership).';
                                break;
                            case 'terms_required':
                                echo 'Please agree to the Terms of Service and Privacy Policy.';
                                break;
                            default:
                                echo 'Registration failed. Please try again.';
                        }
                        ?>
                    </p>
                </div>
            <?php endif; ?>

            <form method="post" action="<?php echo esc_url( home_url( '/register' ) ); ?>" style="display: flex; flex-direction: column; gap: 2rem;">
                <?php wp_nonce_field('wheelfy_register', 'wheelfy_register_nonce'); ?>
                <?php if ($redirect_to) : ?>
                    <input type="hidden" name="redirect_to" value="<?php echo esc_url($redirect_to); ?>">
                <?php endif; ?>
                
                <div>
                    <label for="user_email" class="block text-sm font-medium text-foreground mb-2">
                        Email Address
                    </label>
                    <input 
                        type="email" 
                        id="user_email" 
                        name="user_email" 
                        required 
                        class="w-full px-4 py-3 rounded-lg bg-secondary border border-border text-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                        placeholder="Enter your email"
                    >
                </div>

                <div>
                    <label for="user_login" class="block text-sm font-medium text-foreground mb-2">
                        Username
                    </label>
                    <input 
                        type="text" 
                        id="user_login" 
                        name="user_login" 
                        required 
                        class="w-full px-4 py-3 rounded-lg bg-secondary border border-border text-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                        placeholder="Choose a username"
                    >
                </div>

                <div>
                    <span class="block text-sm font-medium text-foreground mb-2">
                        Account Type
                    </span>
                    <div class="flex flex-col gap-2">
                        <label class="flex items-center gap-2 text-sm text-foreground">
                            <input
                                type="radio"
                                name="user_type"
                                value="customer"
                                class="w-4 h-4 rounded border-border bg-secondary text-primary focus:ring-primary flex-shrink-0"
                                <?php checked( $user_type, 'customer' ); ?>
                            >
                            <span>I am a customer</span>
                        </label>
                        <label class="flex items-center gap-2 text-sm text-foreground">
                            <input
                                type="radio"
                                name="user_type"
                                value="partner"
                                class="w-4 h-4 rounded border-border bg-secondary text-primary focus:ring-primary flex-shrink-0"
                                <?php checked( $user_type, 'partner' ); ?>
                            >
                            <span>I am a partner (garage, workshop, dealer)</span>
                        </label>
                    </div>
                    <p class="mt-2 text-xs text-muted-foreground">
                        Customers compare prices and book services. Partners list their services and receive leads.
                    </p>
                </div>

                <div>
                    <label for="user_pass" class="block text-sm font-medium text-foreground mb-2">
                        Password
                    </label>
                    <input 
                        type="password" 
                        id="user_pass" 
                        name="user_pass" 
                        required 
                        class="w-full px-4 py-3 rounded-lg bg-secondary border border-border text-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                        placeholder="Create a password"
                    >
                </div>

                <div>
                    <label for="confirm_pass" class="block text-sm font-medium text-foreground mb-2">
                        Confirm Password
                    </label>
                    <input 
                        type="password" 
                        id="confirm_pass" 
                        name="confirm_pass" 
                        required 
                        class="w-full px-4 py-3 rounded-lg bg-secondary border border-border text-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                        placeholder="Confirm your password"
                    >
                </div>

                <div id="partner-fields" class="<?php echo $user_type === 'partner' ? '' : 'hidden'; ?>">
                    <div class="mt-2">
                        <label class="block text-sm font-medium text-foreground mb-2">
                            Partner Type <span class="text-destructive">*</span>
                        </label>
                        <div class="grid grid-cols-2 gap-3">
                            <label class="flex items-center gap-3 p-4 rounded-lg bg-secondary border border-border cursor-pointer transition-all hover:border-primary/50 hover:bg-secondary/80">
                                <input 
                                    type="radio" 
                                    name="partner_type" 
                                    value="repair_shop" 
                                    class="w-4 h-4 text-primary focus:ring-primary border-border bg-secondary"
                                    required
                                >
                                <span class="text-sm font-medium text-foreground">Repair Shop</span>
                            </label>
                            <label class="flex items-center gap-3 p-4 rounded-lg bg-secondary border border-border cursor-pointer transition-all hover:border-primary/50 hover:bg-secondary/80">
                                <input 
                                    type="radio" 
                                    name="partner_type" 
                                    value="car_dealership" 
                                    class="w-4 h-4 text-primary focus:ring-primary border-border bg-secondary"
                                    required
                                >
                                <span class="text-sm font-medium text-foreground">Car Dealership</span>
                            </label>
                        </div>
                    </div>

                    <div class="mt-2">
                        <label for="business_name" class="block text-sm font-medium text-foreground mb-2">
                            Business Name
                        </label>
                        <input 
                            type="text" 
                            id="business_name" 
                            name="business_name" 
                            class="w-full px-4 py-3 rounded-lg bg-secondary border border-border text-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                            placeholder="Enter your business name"
                        >
                    </div>

                    <div class="mt-4">
                        <label for="phone_number" class="block text-sm font-medium text-foreground mb-2">
                            Phone Number
                        </label>
                        <input 
                            type="tel" 
                            id="phone_number" 
                            name="phone_number" 
                            class="w-full px-4 py-3 rounded-lg bg-secondary border border-border text-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                            placeholder="Enter your phone number"
                        >
                    </div>
                </div>

                <div class="pt-2">
                    <label class="flex items-start gap-3">
                        <input type="checkbox" name="terms_agree" value="1" required class="w-4 h-4 rounded border-border bg-secondary text-primary focus:ring-primary mt-1 flex-shrink-0">
                        <span class="text-sm text-muted-foreground">
                            I agree to the <a href="#" class="text-primary hover:underline">Terms of Service</a> and <a href="#" class="text-primary hover:underline">Privacy Policy</a>
                        </span>
                    </label>
                </div>

                <button type="submit" class="button button-hero w-full" id="register-submit-btn">
                    <span class="btn-text">Create Account</span>
                    <span class="btn-loading hidden">Creating Account...</span>
                </button>
            </form>

            <script>
            document.addEventListener('DOMContentLoaded', function() {
                console.log('Registration form script loaded');
                const form = document.querySelector('form[method="post"]');
                const submitBtn = document.getElementById('register-submit-btn');
                
                console.log('Form element:', form);
                console.log('Submit button:', submitBtn);
                const userTypeRadios = document.querySelectorAll('input[name="user_type"]');
                const partnerFields = document.getElementById('partner-fields');

                function getSelectedUserType() {
                    const selected = Array.from(userTypeRadios).find(radio => radio.checked);
                    return selected ? selected.value : 'customer';
                }

                function updateUserTypeUI() {
                    const isPartner = getSelectedUserType() === 'partner';
                    if (partnerFields) {
                        if (isPartner) {
                            partnerFields.classList.remove('hidden');
                            // Make partner fields required when visible
                            const businessInput = document.getElementById('business_name');
                            const phoneInput = document.getElementById('phone_number');
                            if (businessInput) businessInput.required = true;
                            if (phoneInput) phoneInput.required = true;
                        } else {
                            partnerFields.classList.add('hidden');
                            // Remove required when hidden
                            const businessInput = document.getElementById('business_name');
                            const phoneInput = document.getElementById('phone_number');
                            if (businessInput) businessInput.required = false;
                            if (phoneInput) phoneInput.required = false;
                        }
                    }
                }

                // Initialize UI based on default selection
                if (userTypeRadios.length) {
                    userTypeRadios.forEach(radio => {
                        radio.addEventListener('change', updateUserTypeUI);
                    });
                    updateUserTypeUI();
                }
                
                if (form && submitBtn) {
                    const btnText = submitBtn.querySelector('.btn-text');
                    const btnLoading = submitBtn.querySelector('.btn-loading');
                    let isSubmitting = false;
                    
                    // Handle button click - do validation and submit manually
                    submitBtn.addEventListener('click', function(e) {
                        e.preventDefault(); // Always prevent default, we'll submit manually
                        console.log('Button clicked!');
                        
                        // Prevent double submission
                        if (isSubmitting) {
                            console.log('Already submitting, preventing duplicate submission');
                            return false;
                        }
                        
                        const email = document.getElementById('user_email').value.trim();
                        const username = document.getElementById('user_login').value.trim();
                        const password = document.getElementById('user_pass').value;
                        const confirmPass = document.getElementById('confirm_pass').value;
                        const terms = document.querySelector('input[name="terms_agree"]')?.checked;
                        const userType = getSelectedUserType();
                        const isPartner = userType === 'partner';
                        
                        console.log('Form data:', { email, username, userType, hasPassword: !!password, hasConfirmPass: !!confirmPass, terms });
                        
                        // Client-side validation
                        let hasError = false;
                        let errorMessage = '';
                        
                        if (!email || !username || !password || !confirmPass) {
                            hasError = true;
                            errorMessage = 'Please fill in all required fields.';
                            console.log('Validation error: Empty fields');
                        } else if (password !== confirmPass) {
                            hasError = true;
                            errorMessage = 'Passwords do not match.';
                            console.log('Validation error: Passwords do not match');
                        } else if (password.length < 6) {
                            hasError = true;
                            errorMessage = 'Password must be at least 6 characters long.';
                            console.log('Validation error: Password too short');
                        } else if (!terms) {
                            hasError = true;
                            errorMessage = 'Please agree to the Terms of Service and Privacy Policy.';
                            console.log('Validation error: Terms not agreed');
                        } else if (isPartner) {
                            const businessInput = document.getElementById('business_name');
                            const phoneInput = document.getElementById('phone_number');
                            const business = businessInput ? businessInput.value.trim() : '';
                            const phone = phoneInput ? phoneInput.value.trim() : '';
                            if (!business || !phone) {
                                hasError = true;
                                errorMessage = 'Please enter your business name and phone number.';
                                console.log('Validation error: Partner fields missing');
                            }
                        }
                        
                        if (hasError) {
                            console.log('Validation failed:', errorMessage);
                            alert(errorMessage);
                            return false;
                        }
                        
                        console.log('Validation passed! Submitting form...');
                        
                        // Mark as submitting to prevent double submission
                        isSubmitting = true;
                        
                        // Update button to show loading state
                        if (btnText && btnLoading) {
                            btnText.classList.add('hidden');
                            btnLoading.classList.remove('hidden');
                            submitBtn.style.opacity = '0.7';
                            submitBtn.style.cursor = 'not-allowed';
                        }
                        
                        console.log('Form is submitting to:', form.action);
                        console.log('Form method:', form.method);
                        
                        // Manually submit the form
                        form.submit();
                    });
                    
                    // Also handle form submit event (in case form is submitted another way)
                    form.addEventListener('submit', function(e) {
                        console.log('=== FORM SUBMIT EVENT TRIGGERED ===');
                        // Allow form to submit - validation already done in button click
                    });
                    
                    // Make sure form can submit - check if there are any issues
                    console.log('Form submit listener attached successfully');
                } else {
                    console.error('Form or submit button not found!', { form, submitBtn });
                }
            });
            </script>

            <div class="mt-6 pt-6 border-t border-border text-center">
                <p class="text-sm text-muted-foreground">
                    Already have an account? 
                    <a href="<?php echo esc_url($redirect_to ? add_query_arg('redirect_to', urlencode($redirect_to), home_url('/login')) : home_url('/login')); ?>" class="text-primary hover:underline font-medium">
                        Sign in here
                    </a>
                </p>
            </div>
        </div>
    </div>
</div>

<?php
get_footer();

