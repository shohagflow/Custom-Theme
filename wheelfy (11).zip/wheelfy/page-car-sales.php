<?php
/**
 * Template Name: Car Sales
 * 
 * @package Wheelfy
 */

get_header();

// Get page ID
$page_id = get_the_ID();

// Get hero meta fields
$hero_badge = get_post_meta($page_id, 'sales_hero_badge', true);
if (empty($hero_badge)) {
    $hero_badge = 'Car Sales';
}

$hero_title = get_post_meta($page_id, 'sales_hero_title_text', true);
if (empty($hero_title)) {
    $hero_title = 'Sell your car easily and at the';
}

$hero_subtitle = get_post_meta($page_id, 'sales_hero_subtitle', true);
if (empty($hero_subtitle)) {
    $hero_subtitle = 'best price';
}

$hero_description = get_post_meta($page_id, 'sales_hero_description', true);
if (empty($hero_description)) {
    $hero_description = 'Compete with car dealers and sell your car to the highest bidder. For free.';
}

$hero_button_text = get_post_meta($page_id, 'sales_hero_button_text', true);
if (empty($hero_button_text)) {
    $hero_button_text = 'Start Here';
}

$hero_button_link = get_post_meta($page_id, 'sales_hero_button_link', true);
if (empty($hero_button_link)) {
    $hero_button_link = home_url('/request-proposal?type=sales');
} else {
    // Handle relative URLs
    if (strpos($hero_button_link, 'http') !== 0) {
        $hero_button_link = home_url($hero_button_link);
    }
}
?>

<!-- Hero Section -->
<section class="relative min-h-[50vh] md:min-h-[80vh] flex items-center overflow-hidden">
    <div class="absolute inset-0">
        <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/hero-sales.jpg'); ?>" alt="Car sales showroom" class="w-full h-full object-cover">
        <div class="absolute inset-0 hero-gradient"></div>
        <div class="absolute inset-0 bg-gradient-to-r from-background via-background/90 to-transparent"></div>
    </div>

    <div class="container mx-auto px-4 lg:px-8 relative z-10" style="margin-top: 6rem;">
        <div class="max-w-2xl">
            <?php if (!empty($hero_badge)) : ?>
            <span class="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-6">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
                <?php echo esc_html($hero_badge); ?>
            </span>
            <?php endif; ?>

            <h1 class="text-foreground mb-6 hero-title">
                <?php echo esc_html($hero_title); ?>
                <?php if (!empty($hero_subtitle)) : ?>
                <span class="gradient-text block"><?php echo esc_html($hero_subtitle); ?></span>
                <?php endif; ?>
            </h1>

            <?php if (!empty($hero_description)) : ?>
            <p class="text-lg md:text-xl text-muted-foreground mb-10">
                <?php echo esc_html($hero_description); ?>
            </p>
            <?php endif; ?>

            <?php if (!empty($hero_button_text)) : ?>
            <a href="<?php echo esc_url($hero_button_link); ?>" class="button button-hero button-xl group inline-flex items-center gap-2">
                <?php echo esc_html($hero_button_text); ?>
                <svg class="w-5 h-5 transition-transform group-hover:translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
                </svg>
            </a>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- How It Works -->
<section class="py-24 bg-background">
    <div class="container mx-auto px-4 lg:px-8">
        <?php get_template_part('template-parts/services/sales-steps'); ?>
    </div>
</section>

<!-- Recent Sales -->
<section class="py-24 section-gradient">
    <div class="container mx-auto px-4 lg:px-8">
        <?php get_template_part('template-parts/services/recent-sales'); ?>
    </div>
</section>

<!-- Benefits -->
<section class="py-24 bg-background">
    <div class="container mx-auto px-4 lg:px-8">
        <?php get_template_part('template-parts/services/sales-benefits'); ?>
    </div>
</section>

<?php
get_footer();

