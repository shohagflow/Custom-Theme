<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @package Wheelfy
 */

get_header();
?>

<div class="container mx-auto px-4 lg:px-8 py-24">
    <div class="max-w-2xl mx-auto text-center">
        <div class="mb-8">
            <h1 class="text-8xl font-bold text-primary mb-4">404</h1>
            <h2 class="text-3xl md:text-4xl font-bold text-foreground mb-4">
                Page Not Found
            </h2>
            <p class="text-lg text-muted-foreground mb-8">
                Sorry, we couldn't find the page you're looking for.
            </p>
        </div>

        <div class="flex flex-col sm:flex-row gap-4 justify-center">
            <a href="<?php echo esc_url(home_url('/')); ?>" class="button button-hero button-lg">
                Go Home
            </a>
            <a href="<?php echo esc_url(home_url('/car-maintenance')); ?>" class="button button-hero-outline button-lg">
                Browse Services
            </a>
        </div>
    </div>
</div>

<?php
get_footer();


