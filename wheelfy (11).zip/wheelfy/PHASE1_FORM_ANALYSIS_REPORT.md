# PHASE 1: FULL THEME ANALYSIS REPORT
## Form System Comparison & Gap Analysis

---

## EXECUTIVE SUMMARY

**Reference Form (WORKING):** Car Accessories Form  
**Forms to Fix:** Sell Your Car Form, Service Book Form, Previous Service Form

**Key Finding:** All 3 forms have handlers that save to transients and redirect to `/select-partner`, BUT they are using different submission mechanisms than Car Accessories Form. The partner selection handler (`wheelfy_handle_partner_selection`) expects data in a specific format and transient key pattern that Car Accessories Form uses correctly.

---

## 1. HOW CAR ACCESSORIES FORM WORKS (STEP-BY-STEP)

### 1.1 Form Submission Flow

**File:** `form/car-accessories-form.php` (line 226)
- **Form Action:** `home_url('/car-accessories-form')` (POST to same page)
- **Nonce:** `car_accessories_nonce` / `car_accessories_form`
- **Method:** POST
- **Fields:** make, model, year, mileage, services[], additional_services

### 1.2 Handler Function

**File:** `functions.php` (line 2678)  
**Function:** `wheelfy_handle_car_accessories_form()`  
**Hook:** `add_action('init', 'wheelfy_handle_car_accessories_form', 0);` (line 2744)

**Process:**
1. Verifies nonce: `car_accessories_nonce` / `car_accessories_form`
2. Clears output buffers
3. Validates required fields (make, model, year, mileage)
4. Creates `$request_id = uniqid('req_', true);`
5. Builds `$form_data` array with:
   - make, model, year, mileage
   - services[], additional_services
   - timestamp
   - customer_id (if logged in)
   - customer_email (if logged in)
6. **Saves to transient:** `set_transient('car_accessories_request_' . $request_id, $form_data, HOUR_IN_SECONDS);`
7. **Redirects to:** `home_url('/select-partner?request_id=' . $request_id)`

### 1.3 Partner Selection Flow

**File:** `functions.php` (line 3056)  
**Function:** `wheelfy_handle_partner_selection()`  
**Hook:** `add_action('init', 'wheelfy_handle_partner_selection', 0);` (line 3274)

**Process:**
1. Verifies nonce: `select_partner_nonce` / `select_partner`
2. Gets `$request_id` from POST
3. **Retrieves form data:** `$form_data = get_transient('car_accessories_request_' . $request_id);` (line 3089)
4. If transient not found, redirects to `/car-accessories-form` (line 3091)
5. For each selected partner:
   - Updates transient: `set_transient('car_accessories_request_' . $request_id . '_partner_' . $partner_id, $form_data, 30 * DAY_IN_SECONDS);`
   - Saves to user meta: `customer_service_requests` (if logged in)
   - Creates notification: `wheelfy_create_notification()` (line 3146)
   - Sends email: `wheelfy_send_new_request_email_to_partner()` (line 3160)
6. Redirects to: `/partner-quotation?request_id={$request_id}&partner_id={$first_partner_id}`

### 1.4 Partner Dashboard Display

**File:** `functions.php` (line 3443)  
**Function:** `wheelfy_get_partner_requests_data($partner_id, $status_filter)`

**Process:**
1. Queries transients: `_transient_car_accessories_request_%_partner_{$partner_id}` (line 3448-3456)
2. Extracts `$request_id` from transient key
3. Gets transient: `get_transient('car_accessories_request_' . $request_id . '_partner_' . $partner_id);` (line 3467)
4. Builds request array with status, customer info, request details
5. Also queries posts (proposals) with `partner_id` meta
6. Returns combined array sorted by date

### 1.5 Partner Accept/Reject Flow

**File:** `functions.php` (line 3279)  
**Function:** `wheelfy_update_request_status()`  
**Hook:** `add_action('wp_ajax_update_request_status', 'wheelfy_update_request_status');` (line 3406)

**Process:**
1. Verifies nonce and partner role
2. Parses `request_id` (format: `req_xxx_partner_y` or `req_xxx`)
3. Gets transient: `get_transient('car_accessories_request_' . $request_id . '_partner_' . $partner_id);` (line 3324)
4. Updates status in transient and user meta
5. If accepted:
   - Creates chat thread: `wheelfy_get_or_create_thread()`
   - Creates notification for customer
   - Sends email to customer
6. Returns JSON success

### 1.6 Customer Dashboard Display

**File:** `functions.php` (line 3955)  
**Function:** `wheelfy_ajax_get_customer_requests()`  
**Hook:** `add_action('wp_ajax_get_customer_requests', 'wheelfy_ajax_get_customer_requests');` (line 4362)

**Process:**
1. Queries 3 sources:
   - **Query 1:** Posts (proposals) created by customer
   - **Query 2:** User meta `customer_service_requests`
   - **Query 3:** Transients `car_accessories_request_*` (checks customer_id or customer_email)
2. Combines and returns all requests with partner info

---

## 2. FILE-BY-FILE COMPARISON

### 2.1 Sell Your Car Form

**Template File:** `page-sell-car-form.php` (line 100)
- **Form Action:** `admin_url('admin-post.php')` ❌ DIFFERENT
- **Hidden Action:** `action=submit_proposal` ❌ DIFFERENT
- **Nonce:** `proposal_nonce` / `submit_proposal_nonce` ❌ DIFFERENT
- **Handler Used:** `wheelfy_handle_proposal_submission()` (line 8499) ❌ DIFFERENT HANDLER
- **Handler Available:** `wheelfy_handle_sell_car_form()` (line 2749) ✅ EXISTS BUT NOT USED

**Handler Analysis (`wheelfy_handle_proposal_submission`):**
- ✅ Saves to transient: `car_accessories_request_{$request_id}` (line 8568)
- ✅ Sets `request_type => 'sell_car'` (line 8559)
- ✅ Redirects to `/select-partner?request_id={$request_id}` (line 8569)
- ✅ Includes customer_id and customer_email
- ✅ Uses same transient key pattern as Car Accessories Form

**Handler Analysis (`wheelfy_handle_sell_car_form`):**
- ✅ Verifies nonce: `sell_car_form_nonce` / `sell_car_form`
- ✅ Saves to transient: `car_accessories_request_{$request_id}` (line 2817)
- ✅ Sets `request_type => 'sell_car'` (line 2805)
- ✅ Redirects to `/select-partner?request_id={$request_id}` (line 2820)
- ✅ Hook: `add_action('init', 'wheelfy_handle_sell_car_form', 0);` (line 2824)
- ❌ **NOT BEING USED** - Form submits to `admin-post.php` instead

**Gap:** Form uses wrong handler. Should use `wheelfy_handle_sell_car_form()` via `init` hook, not `wheelfy_handle_proposal_submission()` via `admin-post.php`.

---

### 2.2 Service Book Form

**Template File:** `form/service-book-form.php` (line 131)
- **Form Action:** Empty string `action=""` ✅ CORRECT (POST to same page)
- **Nonce:** `service_book_form_nonce` / `service_book_form` ✅ CORRECT
- **Handler:** `wheelfy_handle_service_book_form()` (line 2829) ✅ EXISTS

**Handler Analysis (`wheelfy_handle_service_book_form`):**
- ✅ Verifies nonce: `service_book_form_nonce` / `service_book_form` (line 2831)
- ✅ Saves to transient: `car_accessories_request_{$request_id}` (line 2889)
- ✅ Sets `request_type => 'service_book'` (line 2877)
- ✅ Redirects to `/select-partner?request_id={$request_id}` (line 2892)
- ✅ Hook: `add_action('init', 'wheelfy_handle_service_book_form', 0);` (line 2896)
- ✅ Includes customer_id and customer_email

**Gap:** Handler exists and looks correct. Need to verify form is actually calling it (form action is empty, should POST to same page).

---

### 2.3 Previous Service Form

**Template File:** `form/previous-service-form.php` (line 200)
- **Form Action:** Empty string `action=""` ✅ CORRECT (POST to same page)
- **Nonce:** `previous_service_form_nonce` / `previous_service_form` ✅ CORRECT
- **Handler:** `wheelfy_handle_previous_service_form()` (line 2901) ✅ EXISTS

**Handler Analysis (`wheelfy_handle_previous_service_form`):**
- ✅ Verifies nonce: `previous_service_form_nonce` / `previous_service_form` (line 2903)
- ✅ Saves to transient: `car_accessories_request_{$request_id}` (line 2969)
- ✅ Sets `request_type => 'previous_service'` (line 2953)
- ✅ Redirects to `/select-partner?request_id={$request_id}` (line 2972)
- ✅ Hook: `add_action('init', 'wheelfy_handle_previous_service_form', 0);` (line 2972)
- ✅ Includes customer_id and customer_email

**Gap:** Handler exists and looks correct. Need to verify form is actually calling it (form action is empty, should POST to same page).

---

## 3. MISSING OR BROKEN CONNECTIONS

### 3.1 Sell Your Car Form

**Problem:** Form uses `admin-post.php` with `action=submit_proposal`, which routes to `wheelfy_handle_proposal_submission()` instead of `wheelfy_handle_sell_car_form()`.

**Impact:**
- Handler `wheelfy_handle_sell_car_form()` exists but is never called
- `wheelfy_handle_proposal_submission()` DOES work for sell requests (line 8545-8570), but it's a different code path
- Both handlers save to same transient pattern, so partner selection SHOULD work
- However, using different handlers creates inconsistency and potential bugs

**Fix Required:**
- Change form action from `admin_url('admin-post.php')` to `home_url('/sell-your-car-form')` or empty string
- Change hidden input from `action=submit_proposal` to remove it (let `init` hook catch it)
- Ensure nonce matches: `sell_car_form_nonce` / `sell_car_form`

---

### 3.2 Service Book Form

**Status:** Handler exists and looks correct. Form action is empty (correct for POST to same page).

**Potential Issues:**
- Need to verify form fields match handler expectations
- Need to verify nonce field name matches handler check
- Handler expects: `service_book_form_nonce` / `service_book_form`
- Form provides: `service_book_form_nonce` / `service_book_form` ✅ MATCHES

**Fix Required:**
- Verify handler is being called (check if redirect happens)
- If not working, may need to ensure form action is explicitly set to same page URL

---

### 3.3 Previous Service Form

**Status:** Handler exists and looks correct. Form action is empty (correct for POST to same page).

**Potential Issues:**
- Need to verify form fields match handler expectations
- Handler expects: `previous_service_form_nonce` / `previous_service_form`
- Form provides: `previous_service_form_nonce` / `previous_service_form` ✅ MATCHES

**Fix Required:**
- Verify handler is being called (check if redirect happens)
- If not working, may need to ensure form action is explicitly set to same page URL

---

## 4. EXACT FUNCTIONS THAT MUST BE REUSED

### 4.1 Form Submission Handlers (Already Exist)

1. **`wheelfy_handle_sell_car_form()`** (line 2749)
   - Hook: `init` (priority 0)
   - Nonce: `sell_car_form_nonce` / `sell_car_form`
   - Transient: `car_accessories_request_{$request_id}`
   - Redirect: `/select-partner?request_id={$request_id}`

2. **`wheelfy_handle_service_book_form()`** (line 2829)
   - Hook: `init` (priority 0)
   - Nonce: `service_book_form_nonce` / `service_book_form`
   - Transient: `car_accessories_request_{$request_id}`
   - Redirect: `/select-partner?request_id={$request_id}`

3. **`wheelfy_handle_previous_service_form()`** (line 2901)
   - Hook: `init` (priority 0)
   - Nonce: `previous_service_form_nonce` / `previous_service_form`
   - Transient: `car_accessories_request_{$request_id}`
   - Redirect: `/select-partner?request_id={$request_id}`

### 4.2 Partner Selection Handler (Shared)

**`wheelfy_handle_partner_selection()`** (line 3056)
- Used by ALL forms
- Expects transient: `car_accessories_request_{$request_id}`
- Creates partner-specific transients: `car_accessories_request_{$request_id}_partner_{$partner_id}`
- Saves to user meta: `customer_service_requests`
- Creates notifications and sends emails

### 4.3 Dashboard Display Functions (Shared)

1. **`wheelfy_get_partner_requests_data($partner_id, $status_filter)`** (line 3443)
   - Queries transients: `car_accessories_request_*_partner_{$partner_id}`
   - Used by partner dashboard

2. **`wheelfy_ajax_get_customer_requests()`** (line 3955)
   - Queries posts, user meta, and transients
   - Used by customer dashboard

3. **`wheelfy_update_request_status()`** (line 3279)
   - Updates request status via AJAX
   - Used by partner dashboard to accept/reject requests

### 4.4 Notification Functions (Shared)

1. **`wheelfy_create_notification($user_id, $type, $title, $message, $meta)`** (line 8993)
2. **`wheelfy_send_new_request_email_to_partner()`** (called in partner selection handler)
3. **`wheelfy_send_request_accepted_email_to_customer()`** (called in status update handler)

---

## 5. SAFE EXTENSION POINTS

### 5.1 Form-Specific Fields

Each form can have unique fields:
- **Sell Your Car:** color, price, service_book, last_service_date, last_service_mileage, car_photos
- **Service Book:** service_book, additional_notes
- **Previous Service:** last_service_date, last_service_mileage, service_type, additional_notes

These fields are already being saved in `$form_data` array and will be available in:
- Partner selection handler
- Partner dashboard display
- Customer dashboard display
- Notifications

### 5.2 Request Type Identification

All handlers set `request_type` in form_data:
- Car Accessories: No `request_type` (defaults to empty or 'normal')
- Sell Your Car: `request_type => 'sell_car'`
- Service Book: `request_type => 'service_book'`
- Previous Service: `request_type => 'previous_service'`

This allows conditional logic in:
- Partner selection (filtering by partner_type)
- Dashboard display (showing different labels)
- Notifications (custom messages)

### 5.3 Transient Key Pattern

**Pattern:** `car_accessories_request_{$request_id}` (base)  
**Pattern:** `car_accessories_request_{$request_id}_partner_{$partner_id}` (partner-specific)

**Note:** Despite the name "car_accessories_request", this transient key pattern is used by ALL forms. This is intentional and allows the shared partner selection handler to work with all forms.

---

## 6. CRITICAL FINDINGS

### 6.1 Sell Your Car Form - WRONG HANDLER

**Current:** Form submits to `admin-post.php?action=submit_proposal`  
**Should:** Form submits to same page (POST), caught by `init` hook → `wheelfy_handle_sell_car_form()`

**Why:** 
- `wheelfy_handle_proposal_submission()` works but is a different code path
- `wheelfy_handle_sell_car_form()` exists specifically for this form
- Consistency with other forms requires using `init` hook pattern

### 6.2 Service Book & Previous Service Forms - VERIFICATION NEEDED

**Status:** Handlers exist and look correct, but need verification:
- Are forms actually calling handlers?
- Are redirects happening?
- Are requests appearing in dashboards?

**Potential Issue:** Form action is empty string. WordPress should handle this, but explicit URL may be safer.

### 6.3 Partner Selection Handler - EXPECTS SPECIFIC FORMAT

**Critical:** `wheelfy_handle_partner_selection()` (line 3089) retrieves transient:
```php
$form_data = get_transient('car_accessories_request_' . $request_id);
```

**If transient not found:** Redirects to `/car-accessories-form` (line 3091) - hardcoded fallback!

**Impact:** If any form's handler doesn't save transient correctly, partner selection will fail and redirect to wrong page.

**Fix Needed:** Make fallback dynamic or remove hardcoded redirect.

---

## 7. DATABASE/TABLE STRUCTURE

### 7.1 Transients (Temporary Storage)

**Pattern:** `car_accessories_request_{$request_id}` (1 hour)  
**Pattern:** `car_accessories_request_{$request_id}_partner_{$partner_id}` (30 days)

**Storage:** WordPress `wp_options` table  
**Keys:** `_transient_car_accessories_request_*` and `_transient_timeout_car_accessories_request_*`

### 7.2 User Meta (Permanent Storage)

**Key:** `customer_service_requests`  
**Format:** Array of request entries:
```php
array(
    'request_id' => 'req_xxx',
    'partner_id' => 123,
    'status' => 'pending',
    'created_at' => '2024-01-01 12:00:00',
    'form_data' => array(...)
)
```

### 7.3 Posts (Proposals)

**Post Type:** `post`  
**Meta Keys:**
- `_proposal_status` (pending/accepted/rejected/completed)
- `partner_id`
- `_proposal_request_type`
- `_proposal_car_brand`, `_proposal_car_model`, etc.

### 7.4 Notifications

**Key:** `wheelfy_notifications` (user meta)  
**Format:** Array of notification objects

---

## 8. HOOKS AND ACTIONS USED

### 8.1 Form Submission Hooks

1. `init` (priority 0) - Catches POST requests before headers sent
   - `wheelfy_handle_car_accessories_form()` (line 2744)
   - `wheelfy_handle_sell_car_form()` (line 2824)
   - `wheelfy_handle_service_book_form()` (line 2896)
   - `wheelfy_handle_previous_service_form()` (line 2972)
   - `wheelfy_handle_partner_selection()` (line 3274)

2. `admin_post_submit_proposal` - Used by Sell Your Car Form (WRONG)
   - `wheelfy_handle_proposal_submission()` (line 8717)

### 8.2 AJAX Hooks

1. `wp_ajax_update_request_status` - Partner accept/reject
2. `wp_ajax_get_partner_requests` - Partner dashboard requests
3. `wp_ajax_get_customer_requests` - Customer dashboard requests
4. `wp_ajax_wheelfy_get_partner_rating` - Dynamic rating fetch

---

## 9. SUMMARY OF GAPS

### 9.1 Sell Your Car Form

❌ **Form uses wrong submission handler**  
❌ **Form action points to `admin-post.php` instead of same page**  
❌ **Nonce may not match handler expectation**  
✅ Handler exists and is correct  
✅ Partner selection should work IF transient is saved correctly

### 9.2 Service Book Form

✅ Handler exists and looks correct  
✅ Form action is correct (empty = POST to same page)  
✅ Nonce matches handler  
⚠️ **NEEDS VERIFICATION** - Is handler actually being called?

### 9.3 Previous Service Form

✅ Handler exists and looks correct  
✅ Form action is correct (empty = POST to same page)  
✅ Nonce matches handler  
⚠️ **NEEDS VERIFICATION** - Is handler actually being called?

### 9.4 Partner Selection Handler

⚠️ **Hardcoded fallback redirect** to `/car-accessories-form` (line 3091)  
⚠️ Should be dynamic or removed

---

## 10. RECOMMENDED FIXES (PHASE 2)

### Priority 1: Sell Your Car Form
1. Change form action from `admin_url('admin-post.php')` to `home_url('/sell-your-car-form')` or empty string
2. Remove hidden `action=submit_proposal` input
3. Ensure nonce matches: `sell_car_form_nonce` / `sell_car_form`
4. Verify handler `wheelfy_handle_sell_car_form()` is called

### Priority 2: Service Book & Previous Service Forms
1. Verify handlers are being called (add logging or test)
2. If not working, explicitly set form action to page URL
3. Ensure all form fields match handler expectations

### Priority 3: Partner Selection Handler
1. Make fallback redirect dynamic (use `wp_get_referer()` or form-specific redirect)
2. Or remove hardcoded redirect and show error message

### Priority 4: Testing
1. Test each form submission → partner selection → partner accept → dashboard display
2. Verify notifications are created
3. Verify emails are sent
4. Verify requests appear in both customer and partner dashboards

---

## END OF PHASE 1 REPORT

**Status:** Analysis complete. Ready for Phase 2 implementation after approval.

**Next Step:** Wait for explicit approval: "Proceed with implementation"
