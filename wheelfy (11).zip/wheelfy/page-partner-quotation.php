<?php
/**
 * Template Name: Partner Quotation
 * 
 * Partner profile and quotation view with locked/unlocked states
 */
get_header();

// Get request ID and partner ID from URL
$request_id = isset($_GET['request_id']) ? sanitize_text_field($_GET['request_id']) : '';
$partner_id = isset($_GET['partner_id']) ? intval($_GET['partner_id']) : 0;
$quote_accepted = isset($_GET['accepted']) && $_GET['accepted'] === '1';

// Get form data
$form_data = $request_id ? get_transient('car_accessories_request_' . $request_id) : null;

// Get partner data
$partner = $partner_id ? get_userdata($partner_id) : null;
if (!$partner || !in_array('partner', $partner->roles)) {
    wp_redirect(home_url('/select-partner'));
    exit;
}

$business_name = get_user_meta($partner_id, 'business_name', true) ?: $partner->display_name;
$partner_tier = get_user_meta($partner_id, 'partner_tier', true) ?: 'premium';
$rating = get_user_meta($partner_id, 'partner_rating', true) ?: 4.5;
$review_count = get_user_meta($partner_id, 'partner_review_count', true) ?: 150;
$phone = get_user_meta($partner_id, 'phone_number', true) ?: '';
$full_address = get_user_meta($partner_id, 'user_location', true) ?: '';
$city = explode(',', $full_address)[0];
$logo_id = get_user_meta($partner_id, 'partner_logo_id', true);
$logo_url = $logo_id ? wp_get_attachment_image_url($logo_id, 'full') : get_avatar_url($partner_id, array('size' => 150));
?>

<style>
/* CSS Variables - Match Website Branding Colors */
:root {
    --background: 220 20% 10%;
    --foreground: 210 40% 98%;
    --card: 220 18% 13%;
    --primary: 60 96% 79%;
    --primary-foreground: 220 20% 10%;
    --border: 220 15% 22%;
    --muted-foreground: 215 20% 65%;
    --secondary: 220 15% 18%;
    --brand-yellow: 60 96% 79%;
    --brand-green: 186 80% 19%;
    --premium-gold: 45 96% 55%;
    --exclusive-diamond: 210 100% 90%;
}

.container { width: 100%; max-width: 1280px; margin: 0 auto; padding: 0 2rem; }
.max-w-4xl { max-width: 56rem; }
.py-20 { padding-top: 5rem; padding-bottom: 5rem; }
.text-center { text-align: center; }
.mb-12 { margin-bottom: 3rem; }
.mb-6 { margin-bottom: 1.5rem; }
.mb-4 { margin-bottom: 1rem; }
.grid { display: grid; }
.gap-6 { gap: 1.5rem; }
.flex { display: flex; }
.items-center { align-items: center; }
.justify-between { justify-content: space-between; }
.space-y-6 > * + * { margin-top: 1.5rem; }
.w-full { width: 100%; }
.rounded-xl { border-radius: 0.75rem; }
.p-6 { padding: 1.5rem; }
.border { border: 1px solid hsl(var(--border)); }
.bg-card { background: hsl(var(--card)); }
.text-foreground { color: hsl(var(--foreground)); }
.text-muted-foreground { color: hsl(var(--muted-foreground)); }
.font-bold { font-weight: 700; }
.font-semibold { font-weight: 600; }
.font-medium { font-weight: 500; }
.text-3xl { font-size: 1.875rem; }
.text-xl { font-size: 1.25rem; }
.text-lg { font-size: 1.125rem; }
.text-sm { font-size: 0.875rem; }

/* Partner Header */
.partner-header {
    background: hsl(var(--card));
    border: 1px solid hsl(var(--border));
    border-radius: 0.75rem;
    padding: 2rem;
    display: flex;
    align-items: center;
    gap: 2rem;
    margin-bottom: 1.5rem;
}

.partner-logo-large {
    width: 120px;
    height: 120px;
    border-radius: 0.75rem;
    background: hsl(var(--secondary));
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    border: 2px solid hsl(var(--border));
    overflow: hidden;
}

.partner-logo-large img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.partner-info-header {
    flex: 1;
}

.partner-name-wrapper {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    margin-bottom: 0.5rem;
    flex-wrap: wrap;
}

.partner-name-large {
    font-size: 2rem;
    font-weight: 700;
    color: hsl(var(--foreground));
}

.badge {
    display: inline-flex;
    align-items: center;
    gap: 0.25rem;
    padding: 0.375rem 0.875rem;
    border-radius: 9999px;
    font-size: 0.75rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.05em;
}

.badge-premium {
    background: linear-gradient(135deg, hsl(var(--premium-gold)), hsl(45 96% 45%));
    color: hsl(var(--primary-foreground));
    box-shadow: 0 2px 8px hsl(var(--premium-gold) / 0.3);
}

.badge-exclusive {
    background: linear-gradient(135deg, hsl(var(--exclusive-diamond)), hsl(210 100% 70%));
    color: hsl(var(--primary-foreground));
    box-shadow: 0 2px 8px hsl(var(--exclusive-diamond) / 0.3);
}

.reviews-section {
    display: flex;
    align-items: center;
    gap: 1rem;
    margin-top: 0.5rem;
}

.rating-large {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    color: hsl(var(--primary));
    font-size: 1.125rem;
    font-weight: 600;
}

/* Contact Section - Locked/Unlocked States */
.contact-section {
    background: hsl(var(--card));
    border: 1px solid hsl(var(--border));
    border-radius: 0.75rem;
    padding: 1.5rem;
    margin-bottom: 1.5rem;
}

.contact-item {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    padding: 1rem;
    border-bottom: 1px solid hsl(var(--border));
}

.contact-item:last-child {
    border-bottom: none;
}

.contact-label {
    font-weight: 600;
    color: hsl(var(--muted-foreground));
    min-width: 80px;
}

.contact-value {
    flex: 1;
    color: hsl(var(--foreground));
}

/* Locked State */
.contact-value.locked {
    filter: blur(4px);
    position: relative;
    user-select: none;
}

.contact-value.locked::after {
    content: '🔒';
    position: absolute;
    right: 0;
    top: 50%;
    transform: translateY(-50%);
    filter: none;
    font-size: 1.25rem;
}

.phone-blurred {
    letter-spacing: 0.1em;
}

/* Info Notice */
.info-notice {
    background: hsl(var(--primary) / 0.1);
    border: 1px solid hsl(var(--primary) / 0.3);
    border-radius: 0.5rem;
    padding: 1rem;
    margin-bottom: 1.5rem;
    display: flex;
    align-items: center;
    gap: 0.75rem;
    color: hsl(var(--foreground));
}

.info-notice.unlocked {
    background: hsl(var(--brand-green) / 0.1);
    border-color: hsl(var(--brand-green) / 0.3);
}

/* Button Styles */
.btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
    padding: 1rem 2rem;
    font-size: 1rem;
    font-weight: 600;
    border-radius: 0.5rem;
    transition: all 0.2s;
    cursor: pointer;
    border: none;
    text-decoration: none;
}

.btn-primary {
    background: linear-gradient(135deg, hsl(var(--brand-yellow)), hsl(var(--brand-green)));
    color: hsl(var(--primary-foreground));
    box-shadow: 0 4px 12px hsl(220 40% 4% / 0.4);
}

.btn-primary:hover {
    background: linear-gradient(135deg, hsl(60 96% 82%), hsl(186 80% 22%));
    transform: translateY(-2px);
    box-shadow: 0 6px 16px hsl(220 40% 4% / 0.5);
}

.btn-secondary {
    background: hsl(var(--secondary));
    color: hsl(var(--foreground));
    border: 1px solid hsl(var(--border));
}

.btn-secondary:hover {
    background: hsl(var(--secondary) / 0.8);
    border-color: hsl(var(--primary) / 0.5);
}

.btn-large {
    padding: 1.25rem 2.5rem;
    font-size: 1.125rem;
}

.action-buttons {
    display: flex;
    gap: 1rem;
    flex-wrap: wrap;
}

.quote-section {
    background: hsl(var(--card));
    border: 1px solid hsl(var(--border));
    border-radius: 0.75rem;
    padding: 1.5rem;
}

.quote-amount {
    font-size: 2.5rem;
    font-weight: 700;
    color: hsl(var(--primary));
    margin: 1rem 0;
}

@media (max-width: 768px) {
    .partner-header {
        flex-direction: column;
        text-align: center;
    }
    
    .action-buttons {
        flex-direction: column;
    }
    
    .btn {
        width: 100%;
    }
}
</style>

<section class="py-20">
    <div class="container max-w-4xl">
        <!-- Partner Header -->
        <div class="partner-header">
            <div class="partner-logo-large">
                <img src="<?php echo esc_url($logo_url); ?>" alt="<?php echo esc_attr($business_name); ?>">
            </div>
            <div class="partner-info-header">
                <div class="partner-name-wrapper">
                    <h1 class="partner-name-large"><?php echo esc_html($business_name); ?></h1>
                    <?php if ($partner_tier === 'premium') : ?>
                        <span class="badge badge-premium">⭐ Premium</span>
                    <?php elseif ($partner_tier === 'exclusive') : ?>
                        <span class="badge badge-exclusive">💎 Exclusive</span>
                    <?php endif; ?>
                </div>
                <div class="reviews-section">
                    <div class="rating-large">
                        <span>⭐</span>
                        <span><?php echo number_format($rating, 1); ?></span>
                    </div>
                    <span class="text-muted-foreground">(<?php echo number_format($review_count); ?> reviews)</span>
                </div>
            </div>
        </div>

        <?php if (!$quote_accepted) : ?>
            <!-- Info Notice (Locked State) -->
            <div class="info-notice">
                <span>ℹ️</span>
                <span>Accept the quote to unlock full contact details.</span>
            </div>
        <?php else : ?>
            <!-- Info Notice (Unlocked State) -->
            <div class="info-notice unlocked">
                <span>✓</span>
                <span>Contact details unlocked. You can now contact the partner directly.</span>
            </div>
        <?php endif; ?>

        <!-- Quote Section -->
        <div class="quote-section mb-6">
            <h2 class="text-xl font-semibold text-foreground mb-4">Quotation</h2>
            <?php if ($form_data) : ?>
                <div class="space-y-6">
                    <div>
                        <p class="text-muted-foreground mb-2">Vehicle Details</p>
                        <p class="text-foreground font-medium">
                            <?php echo esc_html($form_data['year'] . ' ' . $form_data['make'] . ' ' . $form_data['model']); ?>
                            (<?php echo esc_html(number_format($form_data['mileage'])); ?> km)
                        </p>
                    </div>
                    <?php if (!empty($form_data['accessories'])) : ?>
                        <div>
                            <p class="text-muted-foreground mb-2">Selected Accessories</p>
                            <p class="text-foreground">
                                <?php echo esc_html(implode(', ', $form_data['accessories'])); ?>
                            </p>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="mt-6 pt-6 border-t border-border">
                    <p class="text-muted-foreground mb-2">Estimated Price</p>
                    <p class="quote-amount">$<?php echo number_format(rand(500, 2000), 0); ?></p>
                </div>
            <?php endif; ?>
        </div>

        <!-- Contact Section -->
        <div class="contact-section">
            <h2 class="text-xl font-semibold text-foreground mb-4">Contact Information</h2>
            
            <div class="contact-item">
                <div class="contact-label">Phone:</div>
                <div class="contact-value <?php echo $quote_accepted ? '' : 'locked'; ?>">
                    <?php if ($quote_accepted && $phone) : ?>
                        <a href="tel:<?php echo esc_attr($phone); ?>" class="text-primary hover:underline">
                            <?php echo esc_html($phone); ?>
                        </a>
                    <?php else : ?>
                        <span class="phone-blurred">
                            <?php echo $phone ? substr($phone, 0, 6) . 'XX-XXXXXX' : '+880 17XX-XXXXXX'; ?>
                        </span>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="contact-item">
                <div class="contact-label">Address:</div>
                <div class="contact-value <?php echo $quote_accepted ? '' : 'locked'; ?>">
                    <?php if ($quote_accepted) : ?>
                        <div>
                            <p><?php echo esc_html($full_address); ?></p>
                            <?php if ($full_address) : ?>
                                <a href="https://maps.google.com/?q=<?php echo urlencode($full_address); ?>" target="_blank" class="text-primary hover:underline text-sm mt-1">
                                    View on Google Maps →
                                </a>
                            <?php endif; ?>
                        </div>
                    <?php else : ?>
                        <span><?php echo esc_html($city); ?></span>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Action Buttons -->
        <div class="action-buttons">
            <?php if (!$quote_accepted) : ?>
                <a href="<?php echo esc_url(home_url('/partner-quotation?request_id=' . $request_id . '&partner_id=' . $partner_id . '&accepted=1')); ?>" class="btn btn-primary btn-large">
                    Accept Quote
                </a>
                <button class="btn btn-secondary">
                    Chat with Partner
                </button>
            <?php else : ?>
                <a href="tel:<?php echo esc_attr($phone); ?>" class="btn btn-primary btn-large">
                    Call Now
                </a>
                <button class="btn btn-secondary">
                    Chat with Partner
                </button>
            <?php endif; ?>
        </div>
    </div>
</section>

<?php
get_footer();
?>

