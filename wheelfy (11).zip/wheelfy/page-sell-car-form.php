<?php
/**
 * Template Name: Sell Your Car Form
 * 
 * Page template for the sell your car form
 * Multi-step form for selling a car
 *
 * @package Wheelfy
 */

get_header();

// Set request type for selling car
$request_type = 'sell';
?>

<section class="py-16 md:py-24 min-h-[calc(100vh-80px)]">
    <div class="container mx-auto px-4 lg:px-8">
        <div class="max-w-2xl mx-auto">
            <!-- Header -->
            <div class="text-center mb-8">
                <h1 class="text-3xl md:text-4xl font-bold text-foreground mb-2">Sell Your Car</h1>
                <p class="text-muted-foreground">Get the best price for your vehicle</p>
            </div>

            <!-- Success/Error Messages (hidden inline messages for fallback) -->
            <?php if (isset($_GET['error'])) : ?>
                <div class="mb-6 p-4 rounded-lg bg-red-500/20 border border-red-500/50 text-red-400">
                    <p class="text-sm font-medium">
                        <?php
                        $error = sanitize_text_field($_GET['error']);
                        if ($error === 'missing_fields') {
                            echo 'Please fill in all required fields.';
                        } elseif ($error === 'submission_failed') {
                            echo 'There was an error submitting your listing. Please try again.';
} else {
                            echo 'An error occurred. Please try again.';
                        }
                        ?>
                    </p>
                </div>
            <?php endif; ?>

            <!-- Success Popup Modal -->
            <div id="success-popup" class="success-popup-overlay" style="display: none;">
                <div class="success-popup-content">
                    <button class="success-popup-close" id="close-success-popup" aria-label="Close">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                        </svg>
                    </button>
                    <div class="success-popup-icon">
                        <svg class="w-16 h-16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                    </div>
                    <h2 class="success-popup-title gradient-text">Successfully Submitted Your Request!</h2>
                    <p class="success-popup-message">Your car listing has been submitted successfully. We'll contact you soon.</p>
                    <button class="button button-hero success-popup-button" id="success-popup-ok-btn">OK</button>
                </div>
            </div>

            <!-- Step Navigation Tabs -->
            <div class="flex items-center justify-center gap-4 mb-12">
                <!-- Step 1: Car Details -->
                <div class="flex items-center">
                    <div id="step-1-tab" class="step-tab active flex items-center gap-2 px-4 py-2 rounded-full transition-all bg-primary text-primary-foreground cursor-pointer">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.4 2.9A3.7 3.7 0 0 0 2 12v4c0 .6.4 1 1 1h2"/><circle cx="7" cy="17" r="2"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 17h6"/><circle cx="17" cy="17" r="2"/>
                        </svg>
                        <span class="text-sm font-medium">Car Details</span>
                    </div>
                    <div class="w-8 h-0.5 mx-2 bg-border"></div>
                </div>

                <!-- Step 2: Car Info -->
                <div class="flex items-center">
                    <div id="step-2-tab" class="step-tab flex items-center gap-2 px-4 py-2 rounded-full transition-all bg-card text-muted-foreground border border-border cursor-pointer">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z" />
                        </svg>
                        <span class="text-sm font-medium">Car Info</span>
                    </div>
                    <div class="w-8 h-0.5 mx-2 bg-border"></div>
                </div>

                <!-- Step 3: Contact -->
                <div class="flex items-center">
                    <div id="step-3-tab" class="step-tab flex items-center gap-2 px-4 py-2 rounded-full transition-all bg-card text-muted-foreground border border-border cursor-pointer">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0" />
                            <circle cx="12" cy="10" r="3" />
                        </svg>
                        <span class="text-sm font-medium">Contact</span>
                    </div>
                </div>
            </div>

            <!-- Form -->
            <form id="proposal-form" class="bg-card rounded-2xl p-8 border border-border" method="POST" action="<?php echo esc_url(home_url('/sell-your-car-form')); ?>" enctype="multipart/form-data" novalidate>
                <input type="hidden" name="request_type" value="<?php echo esc_attr($request_type); ?>">
                <?php wp_nonce_field('sell_car_form', 'sell_car_form_nonce'); ?>

                <!-- Step 1: Car Details -->
                <div id="step-1-content" class="step-content active">
                    <h2 class="text-xl font-semibold text-foreground mb-6">Car Details</h2>
                    
                    <div class="form-fields-container">
                        <div class="form-row">
                            <!-- Brand -->
                            <div class="form-field">
                                <label for="car_brand" class="form-label">Brand</label>
                                <div class="relative">
                                    <select id="car_brand" name="car_brand" class="form-input w-full" required>
                                        <option value="">Select brand</option>
                                        <option value="Audi">Audi</option>
                                        <option value="BMW">BMW</option>
                                        <option value="Ford">Ford</option>
                                        <option value="Honda">Honda</option>
                                        <option value="Hyundai">Hyundai</option>
                                        <option value="Mercedes">Mercedes</option>
                                        <option value="Opel">Opel</option>
                                        <option value="Peugeot">Peugeot</option>
                                        <option value="Renault">Renault</option>
                                        <option value="Skoda">Skoda</option>
                                        <option value="Tesla">Tesla</option>
                                        <option value="Toyota">Toyota</option>
                                        <option value="Volkswagen">Volkswagen</option>
                                        <option value="Volvo">Volvo</option>
                                        <option value="Other">Other</option>
                                    </select>
                                    <svg class="dropdown-arrow-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m6 9 6 6 6-6" />
                                    </svg>
                                </div>
                            </div>

                            <!-- Model -->
                            <div class="form-field">
                                <label for="car_model" class="form-label">Model</label>
                                <div class="relative">
                                    <input type="text" id="car_model" name="car_model" class="form-input w-full" placeholder="e.g., Golf, 3 Series" required>
                                </div>
                            </div>
                        </div>

                        <div class="form-row">
                            <!-- Year -->
                            <div class="form-field">
                                <label for="car_year" class="form-label">Year</label>
                                <div class="relative">
                                    <input type="number" id="car_year" name="car_year" class="form-input w-full" placeholder="e.g., 2020" min="1900" max="<?php echo date('Y') + 1; ?>" required>
                                </div>
                            </div>

                            <!-- Fuel Type -->
                            <div class="form-field">
                                <label for="fuel_type" class="form-label">Fuel Type</label>
                                <div class="relative">
                                    <select id="fuel_type" name="fuel_type" class="form-input w-full" required>
                                        <option value="">Select fuel</option>
                                        <option value="Petrol">Petrol</option>
                                        <option value="Diesel">Diesel</option>
                                        <option value="Electric">Electric</option>
                                        <option value="Hybrid">Hybrid</option>
                                        <option value="LPG">LPG</option>
                                    </select>
                                    <svg class="dropdown-arrow-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m6 9 6 6 6-6" />
                                    </svg>
                                </div>
                            </div>
                        </div>

                        <div class="form-row">
                            <!-- Mileage -->
                            <div class="form-field">
                                <label for="mileage" class="form-label">Mileage (km)</label>
                                <div class="relative">
                                    <input type="number" id="mileage" name="mileage" class="form-input w-full" placeholder="e.g., 85000" min="0" required>
                                </div>
                            </div>

                            <!-- License Plate -->
                            <div class="form-field">
                                <label for="license_plate" class="form-label">License Plate</label>
                                <div class="relative">
                                    <input type="text" id="license_plate" name="license_plate" class="form-input w-full" placeholder="e.g., ABC-123">
                                </div>
                            </div>
                        </div>

                        <div class="form-row">
                            <!-- Color -->
                            <div class="form-field">
                                <label for="color" class="form-label">Color</label>
                                <div class="relative">
                                    <input type="text" id="color" name="color" class="form-input w-full" placeholder="e.g., Midnight Blue">
                                </div>
                            </div>

                            <!-- Price -->
                            <div class="form-field">
                                <label for="price" class="form-label">Expected Price (€)</label>
                                <div class="relative">
                                    <input type="number" id="price" name="price" class="form-input w-full" placeholder="e.g., 25000" min="0" step="0.01">
                                </div>
                            </div>
                        </div>

                        <!-- Upload Photos -->
                        <div class="form-field">
                            <label class="form-label">Upload Photos</label>
                            <div class="relative">
                                <div id="photo-upload-area" class="photo-upload-area">
                                    <input type="file" id="car_photos" name="car_photos[]" multiple accept=".png,.jpg,.jpeg,.webp,.svg,image/png,image/jpeg,image/webp,image/svg+xml" class="hidden" />
                                    <label for="car_photos" class="photo-upload-label">
                                        <svg class="w-8 h-8 mb-3 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                                        </svg>
                                        <span class="text-muted-foreground">Drag & drop or click to upload photos</span>
                                        <span class="text-xs text-muted-foreground mt-2">PNG, JPG, WEBP, SVG (Max 8 MB)</span>
                                    </label>
                                    <div id="photo-error" class="photo-error hidden"></div>
                                    <div id="photo-preview" class="photo-preview hidden"></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="flex items-center justify-between mt-8 pt-6 border-t border-border">
                        <div></div>
                        <button type="button" id="next-step-1" class="button button-hero group inline-flex items-center gap-2 form-continue-button">
                            Continue
                            <svg class="w-4 h-4 transition-transform group-hover:translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
                            </svg>
                        </button>
                    </div>
                </div>

                <!-- Step 2: Car Info -->
                <div id="step-2-content" class="step-content hidden">
                    <h2 class="text-xl font-semibold text-foreground mb-6">Additional Details</h2>
                    
                    <div class="form-fields-container">
                        <!-- Description -->
                        <div class="form-field">
                            <label for="service_description" class="form-label">Description</label>
                            <div class="relative">
                                <textarea id="service_description" name="service_description" rows="4" class="form-input w-full" placeholder="Describe your car, any features, condition, or additional information..."></textarea>
                            </div>
                        </div>

                        <!-- Location -->
                        <div class="form-field">
                            <label for="location" class="form-label">Location</label>
                            <div class="relative">
                                <svg class="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground pointer-events-none" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                                </svg>
                                <input type="text" id="location" name="location" class="form-input w-full pl-10" placeholder="City or postal code">
                            </div>
                        </div>
                    </div>

                    <div class="flex items-center justify-between mt-8 pt-6 border-t border-border">
                        <button type="button" id="prev-step-2" class="button button-ghost group inline-flex items-center gap-2 form-back-button">
                            <svg class="w-4 h-4 transition-transform group-hover:-translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" />
                            </svg>
                            Back
                        </button>
                        <button type="button" id="next-step-2" class="button button-hero group inline-flex items-center gap-2 form-continue-button">
                            Continue
                            <svg class="w-4 h-4 transition-transform group-hover:translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
                            </svg>
                        </button>
                    </div>
                </div>

                <!-- Step 3: Contact -->
                <div id="step-3-content" class="step-content hidden">
                    <h2 class="text-xl font-semibold text-foreground mb-6">Contact Information</h2>
                    
                    <div class="form-fields-container">
                        <!-- Full Name -->
                        <div class="form-field">
                            <label for="full_name" class="form-label">Full Name</label>
                            <div class="relative">
                                <input type="text" id="full_name" name="full_name" class="form-input w-full" placeholder="Enter your name" required>
                            </div>
                        </div>

                        <!-- Email -->
                        <div class="form-field">
                            <label for="email" class="form-label">Email</label>
                            <div class="relative">
                                <input type="email" id="email" name="email" class="form-input w-full" placeholder="Enter your email" required>
                            </div>
                        </div>

                        <!-- Phone Number -->
                        <div class="form-field">
                            <label for="phone" class="form-label">Phone Number</label>
                            <div class="relative">
                                <input type="tel" id="phone" name="phone" class="form-input w-full" placeholder="Enter your phone number">
                            </div>
                        </div>

                        <!-- Terms Checkbox -->
                        <div class="form-field checkbox-field">
                            <div class="flex items-start gap-3">
                                <input type="checkbox" id="terms_agree" name="terms_agree" class="mt-1 w-4 h-4 rounded border-border text-primary focus:ring-primary focus:ring-2" required>
                                <label for="terms_agree" class="text-sm text-foreground cursor-pointer leading-relaxed">
                                    I agree to receive offers from partners and accept the terms of service
                                </label>
                            </div>
                        </div>
                    </div>

                    <div class="flex items-center justify-between mt-8 pt-6 border-t border-border">
                        <button type="button" id="prev-step-3" class="button button-ghost group inline-flex items-center gap-2 form-back-button">
                            <svg class="w-4 h-4 transition-transform group-hover:-translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" />
                            </svg>
                            Back
                        </button>
                        <button type="submit" id="submit-request-btn" class="button button-hero group inline-flex items-center gap-2 form-continue-button">
                            Submit Request
                            <svg class="w-4 h-4 transition-transform group-hover:translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
                            </svg>
                        </button>
                    </div>
            </div>
            </form>
            </div>
        </div>
    </section>

<script>
document.addEventListener('DOMContentLoaded', function() {
    'use strict';
    
    let currentStep = 1;
    const totalSteps = 3;

    // Step tabs
    const stepTabs = {
        1: document.getElementById('step-1-tab'),
        2: document.getElementById('step-2-tab'),
        3: document.getElementById('step-3-tab')
    };

    // Step contents
    const stepContents = {
        1: document.getElementById('step-1-content'),
        2: document.getElementById('step-2-content'),
        3: document.getElementById('step-3-content')
    };

    // Navigation buttons
    const nextStep1 = document.getElementById('next-step-1');
    const nextStep2 = document.getElementById('next-step-2');
    const prevStep2 = document.getElementById('prev-step-2');
    const prevStep3 = document.getElementById('prev-step-3');
    const submitButton = document.getElementById('submit-request-btn');

    function updateStepTabs(activeStep) {
        Object.keys(stepTabs).forEach(step => {
            const tab = stepTabs[step];
            if (parseInt(step) === activeStep) {
                tab.classList.add('active');
                tab.classList.remove('bg-card', 'text-muted-foreground', 'border', 'border-border');
            } else {
                tab.classList.remove('active', 'bg-primary', 'text-primary-foreground');
                tab.classList.add('bg-card', 'text-muted-foreground', 'border', 'border-border');
            }
        });
    }

    function showStep(step) {
        Object.keys(stepContents).forEach(s => {
            const content = stepContents[s];
            if (parseInt(s) === step) {
                content.classList.remove('hidden');
                content.classList.add('active');
            } else {
                content.classList.add('hidden');
                content.classList.remove('active');
            }
        });
        updateStepTabs(step);
        currentStep = step;
    }

    function validateStep(step) {
        const content = stepContents[step];
        if (!content) return false;
        
        const requiredFields = content.querySelectorAll('[required]');
        let isValid = true;

        requiredFields.forEach(field => {
            // Handle checkboxes separately
            if (field.type === 'checkbox') {
                if (!field.checked) {
                    field.classList.add('border-red-500');
                    isValid = false;
                } else {
                    field.classList.remove('border-red-500');
                }
            } else {
                let value = field.value;
                // For select elements, check if value is empty
                if (field.tagName === 'SELECT') {
                    if (!value || value === '') {
                        field.classList.add('border-red-500');
                        isValid = false;
                    } else {
                        field.classList.remove('border-red-500');
                    }
                } else {
                    // For input/textarea elements, trim the value
                    if (!value || !value.trim()) {
                        field.classList.add('border-red-500');
                        isValid = false;
                    } else {
                        field.classList.remove('border-red-500');
                    }
                }
            }
        });

        return isValid;
    }

    // Next button handlers
    if (nextStep1) {
        nextStep1.addEventListener('click', function(e) {
            e.preventDefault();
            if (validateStep(1)) {
                showStep(2);
                window.scrollTo({ top: 0, behavior: 'smooth' });
            }
        });
    }

    if (nextStep2) {
        nextStep2.addEventListener('click', function(e) {
            e.preventDefault();
            if (validateStep(2)) {
                showStep(3);
                window.scrollTo({ top: 0, behavior: 'smooth' });
            }
        });
    }

    // Previous button handlers
    if (prevStep2) {
        prevStep2.addEventListener('click', function(e) {
            e.preventDefault();
            showStep(1);
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    if (prevStep3) {
        prevStep3.addEventListener('click', function(e) {
            e.preventDefault();
            showStep(2);
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    // Tab click handlers
    Object.keys(stepTabs).forEach(step => {
        stepTabs[step].addEventListener('click', function() {
            if (parseInt(step) <= currentStep || parseInt(step) === 1) {
                showStep(parseInt(step));
                window.scrollTo({ top: 0, behavior: 'smooth' });
            }
        });
    });

    // Submit button click handler
    if (submitButton) {
        submitButton.addEventListener('click', function(e) {
            // Ensure we're on step 3
            if (currentStep !== 3) {
                e.preventDefault();
                showStep(3);
                window.scrollTo({ top: 0, behavior: 'smooth' });
                return false;
            }
            
            // Validate step 3 (Contact Information) before submitting
            const isStep3Valid = validateStep(3);
            if (!isStep3Valid) {
                e.preventDefault();
                window.scrollTo({ top: 0, behavior: 'smooth' });
                return false;
            }
            
            // If validation passes, allow form to submit normally
            // Don't preventDefault() - let the button submit the form
        });
    }
    
    // Form submit handler - validate step 3 before submitting (backup)
    const proposalForm = document.getElementById('proposal-form');
    if (proposalForm) {
        proposalForm.addEventListener('submit', function(e) {
            // Show step 3 if not already visible
            if (currentStep !== 3) {
                e.preventDefault();
                showStep(3);
                window.scrollTo({ top: 0, behavior: 'smooth' });
                return false;
            }
            
            // Validate step 3 (Contact Information) before submitting
            const isStep3Valid = validateStep(3);
            if (!isStep3Valid) {
                e.preventDefault();
                window.scrollTo({ top: 0, behavior: 'smooth' });
                return false;
            }
            
            // If validation passes, allow form to submit normally
            // Form will POST to same page and be caught by init hook handler
        });
    }

    // Success popup handling
    const successPopup = document.getElementById('success-popup');
    const closeSuccessPopup = document.getElementById('close-success-popup');
    const successPopupOkBtn = document.getElementById('success-popup-ok-btn');
    const urlParams = new URLSearchParams(window.location.search);
    
    // Show success popup if success parameter is in URL
    if (urlParams.get('success') === '1' && successPopup) {
        successPopup.style.display = 'flex';
        document.body.style.overflow = 'hidden';
        
        // Remove success parameter from URL without reloading
        const newUrl = window.location.pathname + (urlParams.get('error') ? '?error=' + urlParams.get('error') : '');
        window.history.replaceState({}, '', newUrl);
    }
    
    // Close popup handlers
    function closeSuccessModal() {
        if (successPopup) {
            successPopup.style.display = 'none';
            document.body.style.overflow = '';
        }
    }
    
    if (closeSuccessPopup) {
        closeSuccessPopup.addEventListener('click', closeSuccessModal);
    }
    
    if (successPopupOkBtn) {
        successPopupOkBtn.addEventListener('click', closeSuccessModal);
    }
    
    // Close popup when clicking overlay
    if (successPopup) {
        successPopup.addEventListener('click', function(e) {
            if (e.target === successPopup) {
                closeSuccessModal();
            }
        });
    }
    
    // Close popup with ESC key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && successPopup && successPopup.style.display === 'flex') {
            closeSuccessModal();
        }
    });

    // Remove red border on input
    document.querySelectorAll('input, select, textarea').forEach(field => {
        field.addEventListener('input', function() {
            this.classList.remove('border-red-500');
        });
        // Also handle change for select elements
        if (field.tagName === 'SELECT') {
            field.addEventListener('change', function() {
                this.classList.remove('border-red-500');
            });
        }
    });

    // Photo Upload Functionality
    const photoUploadArea = document.getElementById('photo-upload-area');
    const photoInput = document.getElementById('car_photos');
    const photoPreview = document.getElementById('photo-preview');
    const photoUploadLabel = document.querySelector('.photo-upload-label');
    const photoError = document.getElementById('photo-error');

    // Allowed file types and max size
    const allowedTypes = ['image/png', 'image/jpeg', 'image/jpg', 'image/webp', 'image/svg+xml'];
    const allowedExtensions = ['.png', '.jpg', '.jpeg', '.webp', '.svg'];
    const maxFileSize = 8 * 1024 * 1024; // 8 MB in bytes

    function showError(message) {
        if (photoError) {
            photoError.textContent = message;
            photoError.classList.remove('hidden');
            setTimeout(() => {
                photoError.classList.add('hidden');
            }, 5000);
        }
    }

    function isValidFileType(file) {
        const fileName = file.name.toLowerCase();
        const fileType = file.type.toLowerCase();
        
        // Check MIME type
        if (allowedTypes.includes(fileType)) {
            return true;
        }
        
        // Check file extension as fallback
        return allowedExtensions.some(ext => fileName.endsWith(ext));
    }

    function isValidFileSize(file) {
        return file.size <= maxFileSize;
    }

    if (photoUploadArea && photoInput && photoPreview) {
        // Handle file input change
        photoInput.addEventListener('change', function(e) {
            handleFiles(e.target.files);
        });

        // Drag and drop functionality
        photoUploadArea.addEventListener('dragover', function(e) {
            e.preventDefault();
            e.stopPropagation();
            photoUploadArea.classList.add('drag-over');
        });

        photoUploadArea.addEventListener('dragleave', function(e) {
            e.preventDefault();
            e.stopPropagation();
            photoUploadArea.classList.remove('drag-over');
        });

        photoUploadArea.addEventListener('drop', function(e) {
            e.preventDefault();
            e.stopPropagation();
            photoUploadArea.classList.remove('drag-over');
            
            const files = e.dataTransfer.files;
            if (files.length > 0) {
                // Create a new FileList-like object for the input
                const dt = new DataTransfer();
                Array.from(files).forEach(file => {
                    if (isValidFileType(file) && isValidFileSize(file)) {
                        dt.items.add(file);
                    }
                });
                photoInput.files = dt.files;
                handleFiles(photoInput.files);
            }
        });

        function handleFiles(files) {
            if (files.length === 0) return;

            const validFiles = [];
            const errors = [];

            // Validate all files first
            Array.from(files).forEach((file, index) => {
                if (!isValidFileType(file)) {
                    errors.push(`"${file.name}" - Invalid file type. Allowed: PNG, JPG, WEBP, SVG`);
                } else if (!isValidFileSize(file)) {
                    const fileSizeMB = (file.size / (1024 * 1024)).toFixed(2);
                    errors.push(`"${file.name}" - File size (${fileSizeMB} MB) exceeds 8 MB limit`);
                } else {
                    validFiles.push(file);
                }
            });

            // Show errors if any
            if (errors.length > 0) {
                showError(errors.join('<br>'));
            } else {
                photoError.classList.add('hidden');
            }

            // Only process valid files
            if (validFiles.length === 0) {
                return;
            }

            photoPreview.innerHTML = '';
            photoPreview.classList.remove('hidden');
            photoUploadLabel.classList.add('hidden');

            validFiles.forEach((file, index) => {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const previewItem = document.createElement('div');
                    previewItem.className = 'photo-preview-item';
                    previewItem.innerHTML = `
                        <img src="${e.target.result}" alt="Preview ${index + 1}" />
                        <button type="button" class="photo-remove-btn" data-index="${index}">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                            </svg>
                        </button>
                    `;
                    photoPreview.appendChild(previewItem);

                    // Add remove functionality
                    const removeBtn = previewItem.querySelector('.photo-remove-btn');
                    removeBtn.addEventListener('click', function() {
                        previewItem.remove();
                        if (photoPreview.children.length === 0) {
                            photoPreview.classList.add('hidden');
                            photoUploadLabel.classList.remove('hidden');
                            photoInput.value = '';
                        }
                    });
                };
                reader.readAsDataURL(file);
            });
        }
    }
});
</script>

<style>
/* Professional Form Layout */
.form-fields-container {
    display: flex;
    flex-direction: column;
    gap: 1.5rem;
}

.form-row {
    display: grid;
    grid-template-columns: 1fr;
    gap: 1.5rem;
}

@media (min-width: 768px) {
    .form-row {
        grid-template-columns: repeat(2, 1fr);
    }
}

.form-field {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
}

.form-label {
    display: block;
    font-size: 0.875rem;
    font-weight: 500;
    color: hsl(var(--foreground));
    margin-bottom: 0.25rem;
}

.checkbox-field {
    margin-top: 0.5rem;
}

/* Form Input Styles - All fields same design */
.form-input {
    display: block;
    width: 100%;
    height: 2.5rem;
    border-radius: 0.5rem;
    border: 1px solid hsl(var(--border));
    background-color: hsl(var(--background));
    padding: 0 0.75rem;
    font-size: 0.875rem;
    line-height: 1.5;
    color: hsl(var(--foreground));
    transition: all 0.2s ease;
    outline: none;
    box-sizing: border-box;
}

.form-input::placeholder {
    color: hsl(var(--muted-foreground));
    opacity: 0.7;
}

.form-input:hover {
    border-color: hsl(var(--border) / 0.8);
}

.form-input:focus {
    border-color: hsl(var(--primary));
    box-shadow: 0 0 0 3px hsl(var(--primary) / 0.1);
}

/* All inputs same styling */
input.form-input,
select.form-input {
    height: 2.5rem;
    padding: 0 0.75rem;
    line-height: 1.5;
    vertical-align: middle;
}

textarea.form-input {
    min-height: 6rem;
    padding: 0.625rem 0.75rem;
    resize: vertical;
    line-height: 1.5;
}

/* Select dropdown specific */
select.form-input {
    appearance: none;
    -webkit-appearance: none;
    -moz-appearance: none;
    background-image: none;
    padding-right: 2.5rem;
    cursor: pointer;
}

select.form-input:focus {
    padding-right: 2.5rem;
}

select.form-input option {
    padding: 0.5rem 0.75rem;
    line-height: 1.5;
    background-color: hsl(var(--card));
    color: hsl(var(--foreground));
    height: auto;
    min-height: 2rem;
}

/* Ensure dropdown arrows only show on select elements with relative wrapper */
.form-field > .relative {
    position: relative;
}

.form-field .relative svg,
.dropdown-arrow-icon {
    position: absolute !important;
    right: 0.75rem !important;
    top: 50% !important;
    transform: translateY(-50%) !important;
    width: 1rem !important;
    height: 1rem !important;
    pointer-events: none !important;
    z-index: 10 !important;
    opacity: 0.5 !important;
    color: hsl(var(--muted-foreground)) !important;
    display: block !important;
    visibility: visible !important;
}

.form-field .relative:hover svg,
.form-field .relative:hover .dropdown-arrow-icon {
    opacity: 0.7 !important;
}

.form-field .relative:focus-within svg,
.form-field .relative:focus-within .dropdown-arrow-icon,
.form-field select:focus + svg {
    opacity: 1 !important;
    color: hsl(var(--primary)) !important;
}

/* Ensure text inputs don't have dropdown arrows */
.form-field input[type="text"],
.form-field input[type="number"],
.form-field input[type="tel"],
.form-field input[type="email"],
.form-field textarea {
    padding-right: 0.75rem !important;
}

/* Remove any default arrows from number inputs */
input[type="number"]::-webkit-inner-spin-button,
input[type="number"]::-webkit-outer-spin-button {
    -webkit-appearance: none;
    margin: 0;
}

input[type="number"] {
    -moz-appearance: textfield;
}

/* Back button with arrow */
.button-ghost {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    padding: 0.625rem 1.25rem;
    border-radius: 0.5rem;
    background-color: transparent;
    color: hsl(var(--foreground));
    border: none;
    cursor: pointer;
    transition: all 0.2s;
    font-size: 0.875rem;
    font-weight: 500;
}

.button-ghost:hover {
    background-color: hsl(var(--secondary));
}

select.form-input option {
    background-color: hsl(var(--card));
    color: hsl(var(--foreground));
}

/* Form button styling - reduced padding */
.form-continue-button {
    padding: 0.5rem 0.875rem !important;
    height: 2.125rem !important;
    font-size: 0.875rem !important;
}

.form-back-button {
    padding: 0.5rem 0.875rem !important;
    height: 2.125rem !important;
    font-size: 0.875rem !important;
}

.flex.items-center.justify-between.mt-8.pt-6.border-t.border-border {
    margin-top: 1.5rem;
}

/* Step tab branding colors - use brand gradient for active tabs */
.step-tab.active {
    background: linear-gradient(135deg, hsl(60 96% 79%), hsl(186 80% 19%)) !important;
    color: hsl(220 20% 10%) !important;
    border: none !important;
}

.step-tab.active svg {
    color: hsl(220 20% 10%) !important;
}

.step-tab.active .text-sm {
    color: hsl(220 20% 10%) !important;
}

/* Mobile Responsive Styles */
/* Success Popup Modal Styles */
.success-popup-overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: rgba(0, 0, 0, 0.6);
    backdrop-filter: blur(4px);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 9999;
    animation: fadeIn 0.3s ease-out;
}

.success-popup-content {
    background: hsl(var(--card));
    border-radius: 1rem;
    padding: 2.5rem;
    max-width: 500px;
    width: 90%;
    position: relative;
    box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
    border: 1px solid hsl(var(--border));
    animation: slideUp 0.3s ease-out;
    text-align: center;
}

.success-popup-close {
    position: absolute;
    top: 1rem;
    right: 1rem;
    background: transparent;
    border: none;
    color: hsl(var(--muted-foreground));
    cursor: pointer;
    padding: 0.5rem;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 0.5rem;
    transition: all 0.2s ease;
}

.success-popup-close:hover {
    background: hsl(var(--muted) / 0.2);
    color: hsl(var(--foreground));
}

.success-popup-icon {
    margin: 0 auto 1.5rem;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 5rem;
    height: 5rem;
    border-radius: 50%;
    background: linear-gradient(135deg, hsl(60 96% 79%), hsl(186 80% 19%));
    animation: scaleIn 0.4s ease-out 0.1s both;
    box-shadow: 0 0 30px hsl(60 96% 79% / 0.4), 0 0 30px hsl(186 80% 19% / 0.3);
}

.success-popup-icon svg {
    color: hsl(220 20% 10%);
}

.success-popup-title {
    font-size: 1.5rem;
    font-weight: 700;
    margin-bottom: 0.75rem;
}

.success-popup-message {
    font-size: 1rem;
    color: hsl(var(--muted-foreground));
    margin-bottom: 2rem;
    line-height: 1.6;
}

.success-popup-button {
    padding: 0.75rem 2rem;
    font-size: 1rem;
    min-width: 120px;
}

@keyframes fadeIn {
    from {
        opacity: 0;
    }
    to {
        opacity: 1;
    }
}

@keyframes slideUp {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@keyframes scaleIn {
    from {
        opacity: 0;
        transform: scale(0.8);
    }
    to {
        opacity: 1;
        transform: scale(1);
    }
}

@media (max-width: 640px) {
    .success-popup-content {
        padding: 2rem 1.5rem;
        width: 95%;
    }
    
    .success-popup-title {
        font-size: 1.25rem;
    }
    
    .success-popup-icon {
        width: 4rem;
        height: 4rem;
    }
    
    .success-popup-icon svg {
        width: 3rem;
        height: 3rem;
    }
    
    /* Reduce form container padding on mobile */
    #proposal-form {
        padding: 1.5rem !important;
    }
    
    /* Step navigation - reduce gaps and padding */
    .flex.items-center.justify-center.gap-4.mb-12 {
        gap: 0.5rem !important;
        margin-bottom: 1.5rem !important;
        flex-wrap: wrap;
    }
    
    /* Step tabs - smaller padding and hide text on very small screens */
    .step-tab {
        padding: 0.5rem 0.75rem !important;
        font-size: 0.75rem !important;
    }
    
    .step-tab .text-sm {
        font-size: 0.75rem !important;
    }
    
    .step-tab svg {
        width: 1rem !important;
        height: 1rem !important;
    }
    
    /* Reduce connector lines on mobile */
    .flex.items-center .w-8 {
        width: 0.5rem !important;
        margin-left: 0.25rem !important;
        margin-right: 0.25rem !important;
    }
    
    /* Button container adjustments */
    .flex.items-center.justify-between.mt-8.pt-6 {
        margin-top: 1rem !important;
        padding-top: 1rem !important;
        flex-direction: column;
        gap: 1rem;
    }
    
    .flex.items-center.justify-between.mt-8.pt-6 > div:first-child {
        display: none;
    }
    
    .flex.items-center.justify-between.mt-8.pt-6 button {
        width: 100%;
        justify-content: center;
    }
    
    /* Form field spacing adjustments */
    .form-fields-container {
        gap: 1rem !important;
    }
    
    .form-row {
        gap: 1rem !important;
    }
    
    /* Reduce heading margins */
    h2.text-xl {
        margin-bottom: 1.5rem !important;
        font-size: 1.125rem !important;
    }
}

@media (max-width: 480px) {
    /* Hide step tab text on very small screens, show only icons */
    .step-tab .text-sm {
        display: none;
    }
    
    .step-tab {
        padding: 0.5rem !important;
        min-width: 2.5rem;
        justify-content: center;
    }
    
    /* Further reduce form padding */
    #proposal-form {
        padding: 1rem !important;
    }
}

/* Photo Upload Area Styles */
.photo-upload-area {
    border: 2px dashed hsl(var(--border));
    border-radius: 0.5rem;
    padding: 2.5rem 1.5rem;
    background-color: hsl(var(--background));
    transition: all 0.2s ease;
    cursor: pointer;
    position: relative;
}

.photo-upload-area:hover {
    border-color: hsl(var(--primary));
    background-color: hsl(var(--secondary) / 0.3);
}

.photo-upload-area.drag-over {
    border-color: hsl(var(--primary));
    background-color: hsl(var(--primary) / 0.1);
}

.photo-upload-label {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    text-align: center;
    color: hsl(var(--muted-foreground));
    font-size: 0.875rem;
}

.photo-upload-label svg {
    color: hsl(var(--muted-foreground));
}

.photo-error {
    margin-top: 0.75rem;
    padding: 0.75rem;
    background-color: hsl(var(--destructive) / 0.1);
    border: 1px solid hsl(var(--destructive) / 0.3);
    border-radius: 0.5rem;
    color: hsl(var(--destructive));
    font-size: 0.875rem;
    line-height: 1.5;
}

.photo-preview {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(100px, 1fr));
    gap: 1rem;
    margin-top: 1rem;
}

.photo-preview-item {
    position: relative;
    aspect-ratio: 1;
    border-radius: 0.5rem;
    overflow: hidden;
    border: 1px solid hsl(var(--border));
}

.photo-preview-item img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.photo-remove-btn {
    position: absolute;
    top: 0.25rem;
    right: 0.25rem;
    background-color: rgba(0, 0, 0, 0.7);
    color: white;
    border: none;
    border-radius: 50%;
    width: 1.75rem;
    height: 1.75rem;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: background-color 0.2s;
}

.photo-remove-btn:hover {
    background-color: rgba(239, 68, 68, 0.9);
}

@media (max-width: 640px) {
    .photo-upload-area {
        padding: 1.5rem 1rem;
    }
    
    .photo-preview {
        grid-template-columns: repeat(auto-fill, minmax(80px, 1fr));
        gap: 0.75rem;
    }
}

</style>

<?php
get_footer();
?>
