<?php
/**
 * Template Name: Subscription Checkout
 * 
 * WooCommerce-style checkout page for subscription purchases
 * 
 * @package Wheelfy
 */

// Redirect if not logged in
if (!is_user_logged_in()) {
    wp_redirect(wp_login_url(get_permalink()));
    exit;
}

// Check user role
$current_user = wp_get_current_user();
if (!in_array('partner', $current_user->roles)) {
    wp_redirect(home_url());
    exit;
}

get_header();

$plan_id = isset($_GET['plan']) ? intval($_GET['plan']) : 0;
$plan = $plan_id ? wheelfy_get_subscription_plan_by_id($plan_id) : null;

// Get enabled payment gateways
$payment_gateway = Wheelfy_Payment_Gateway::get_instance();
$enabled_gateways = $payment_gateway->get_enabled_gateways();

// Get all active plans if no specific plan selected
$all_plans = wheelfy_get_subscription_plans_db(true);

// Currency settings
$currency = 'HUF';
$currency_symbol = 'HUF';

// Handle payment return messages
$payment_status = isset($_GET['payment']) ? sanitize_text_field($_GET['payment']) : '';
$payment_gateway_return = isset($_GET['gateway']) ? sanitize_text_field($_GET['gateway']) : '';
$transaction_id = isset($_GET['transaction_id']) ? sanitize_text_field($_GET['transaction_id']) : '';

// Get user billing info
$user_id = get_current_user_id();
$billing_first_name = get_user_meta($user_id, 'billing_first_name', true) ?: $current_user->first_name;
$billing_last_name = get_user_meta($user_id, 'billing_last_name', true) ?: $current_user->last_name;
$billing_company = get_user_meta($user_id, 'billing_company', true);
$billing_country = get_user_meta($user_id, 'billing_country', true) ?: 'Hungary';
$billing_address = get_user_meta($user_id, 'billing_address', true);
$billing_city = get_user_meta($user_id, 'billing_city', true);
$billing_state = get_user_meta($user_id, 'billing_state', true);
$billing_postcode = get_user_meta($user_id, 'billing_postcode', true);
$billing_phone = get_user_meta($user_id, 'billing_phone', true) ?: get_user_meta($user_id, 'phone', true);
$billing_email = $current_user->user_email;
?>

<style>
/* Checkout Page - WooCommerce Style with Wheelfy Branding */
.wc-checkout-page {
    min-height: 100vh;
    background: hsl(var(--background));
    padding: 2rem 1rem 4rem;
}

.wc-checkout-container {
    max-width: 1200px;
    margin: 0 auto;
}

.wc-checkout-header {
    margin-bottom: 2rem;
}

.wc-back-link {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    color: hsl(var(--primary));
    text-decoration: none;
    font-size: 0.9375rem;
    font-weight: 500;
    transition: all 0.2s;
    margin-bottom: 1.5rem;
}

.wc-back-link:hover {
    opacity: 0.8;
}

.wc-back-link svg {
    width: 18px;
    height: 18px;
}

.wc-checkout-title {
    font-size: 2rem;
    font-weight: 700;
    color: hsl(var(--foreground));
    margin: 0;
}

/* Alert Messages */
.wc-alert {
    padding: 1rem 1.25rem;
    border-radius: 0.5rem;
    margin-bottom: 1.5rem;
    display: flex;
    align-items: center;
    gap: 0.75rem;
    font-size: 0.9375rem;
}

.wc-alert.success {
    background: hsl(142 76% 36% / 0.15);
    border-left: 4px solid hsl(142 76% 36%);
    color: hsl(142 76% 36%);
}

.wc-alert.warning {
    background: hsl(45 93% 47% / 0.15);
    border-left: 4px solid hsl(45 93% 47%);
    color: hsl(45 93% 47%);
}

.wc-alert.error {
    background: hsl(0 84% 60% / 0.15);
    border-left: 4px solid hsl(0 84% 60%);
    color: hsl(0 84% 60%);
}

/* Checkout Grid Layout */
.wc-checkout-grid {
    display: grid;
    grid-template-columns: 1fr 400px;
    grid-template-rows: auto auto;
    gap: 1.5rem 2rem;
    align-items: start;
}

/* Order summary at top right, spans to align with plan/payment */
.wc-order-sidebar {
    grid-column: 2;
    grid-row: 1 / 3;
}

/* Billing details full width at top left */
.wc-checkout-forms .wc-checkout-section:first-child {
    grid-column: 1;
}

@media (max-width: 1024px) {
    .wc-checkout-grid {
        grid-template-columns: 1fr;
    }
    
    .wc-order-sidebar {
        grid-column: 1;
        grid-row: auto;
        order: -1;
    }
}

/* Form Sections */
.wc-checkout-section {
    background: hsl(var(--card));
    border: 1px solid hsl(var(--border));
    border-radius: 0.75rem;
    margin-bottom: 1.5rem;
}

.wc-section-header {
    padding: 1.25rem 1.5rem;
    border-bottom: 1px solid hsl(var(--border));
}

.wc-section-title {
    font-size: 1.25rem;
    font-weight: 700;
    color: hsl(var(--foreground));
    margin: 0;
    display: flex;
    align-items: center;
    gap: 0.75rem;
}

.wc-section-title svg {
    width: 22px;
    height: 22px;
    color: hsl(var(--primary));
}

.wc-section-body {
    padding: 1.5rem;
}

/* Form Fields */
.wc-form-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 1rem;
    margin-bottom: 1rem;
}

.wc-form-row.full {
    grid-template-columns: 1fr;
}

@media (max-width: 600px) {
    .wc-form-row {
        grid-template-columns: 1fr;
    }
}

.wc-form-group {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
}

.wc-form-group label {
    font-size: 0.875rem;
    font-weight: 600;
    color: hsl(var(--foreground));
}

.wc-form-group label .required {
    color: hsl(0 84% 60%);
}

.wc-form-group input,
.wc-form-group select {
    padding: 0.75rem 1rem;
    border: 1px solid hsl(var(--border));
    border-radius: 0.5rem;
    font-size: 0.9375rem;
    color: hsl(var(--foreground));
    background: hsl(var(--background));
    transition: all 0.2s;
}

.wc-form-group input:focus,
.wc-form-group select:focus {
    outline: none;
    border-color: hsl(var(--primary));
    box-shadow: 0 0 0 3px hsl(var(--primary) / 0.15);
}

.wc-form-group input::placeholder {
    color: hsl(var(--muted-foreground));
}

/* Plan Selection */
.wc-plan-options {
    display: flex;
    flex-direction: column;
    gap: 0.75rem;
}

.wc-plan-option {
    border: 2px solid hsl(var(--border));
    border-radius: 0.75rem;
    padding: 1.25rem;
    cursor: pointer;
    transition: all 0.2s;
    position: relative;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 1rem;
}

.wc-plan-option:hover {
    border-color: hsl(var(--primary) / 0.5);
}

.wc-plan-option.selected {
    border-color: hsl(var(--primary));
    background: hsl(var(--primary) / 0.05);
}

.wc-plan-option.popular {
    border-color: hsl(60 96% 79%);
}

.wc-plan-badge {
    position: absolute;
    top: -10px;
    left: 1rem;
    background: linear-gradient(135deg, hsl(60 96% 79%), hsl(186 80% 19%));
    color: hsl(var(--primary-foreground));
    padding: 0.25rem 0.75rem;
    border-radius: 1rem;
    font-size: 0.7rem;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.05em;
}

.wc-plan-option input[type="radio"] {
    display: none;
}

.wc-plan-info {
    flex: 1;
}

.wc-plan-name {
    font-size: 1.0625rem;
    font-weight: 600;
    color: hsl(var(--foreground));
    margin: 0 0 0.25rem;
}

.wc-plan-features {
    display: flex;
    flex-wrap: wrap;
    gap: 0.5rem;
    margin-top: 0.5rem;
}

.wc-plan-feature {
    display: inline-flex;
    align-items: center;
    gap: 0.25rem;
    font-size: 0.8125rem;
    color: hsl(var(--muted-foreground));
    background: hsl(var(--secondary));
    padding: 0.25rem 0.6rem;
    border-radius: 0.375rem;
}

.wc-plan-feature svg {
    width: 12px;
    height: 12px;
    color: hsl(var(--primary));
}

.wc-plan-price {
    text-align: right;
    flex-shrink: 0;
}

.wc-plan-price .amount {
    font-size: 1.5rem;
    font-weight: 700;
    color: hsl(var(--primary));
    display: block;
}

.wc-plan-price .period {
    font-size: 0.8125rem;
    color: hsl(var(--muted-foreground));
}

/* Radio Check Indicator */
.wc-radio-check {
    width: 22px;
    height: 22px;
    border: 2px solid hsl(var(--border));
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    transition: all 0.2s;
}

.wc-plan-option.selected .wc-radio-check {
    border-color: hsl(var(--primary));
    background: hsl(var(--primary));
}

.wc-radio-check svg {
    width: 12px;
    height: 12px;
    color: white;
    opacity: 0;
    transition: all 0.2s;
}

.wc-plan-option.selected .wc-radio-check svg {
    opacity: 1;
}

/* Payment Methods */
.wc-payment-methods {
    display: flex;
    flex-direction: column;
    gap: 0.75rem;
}

.wc-payment-method {
    border: 2px solid hsl(var(--border));
    border-radius: 0.75rem;
    padding: 1rem 1.25rem;
    cursor: pointer;
    transition: all 0.2s;
    display: flex;
    align-items: center;
    gap: 1rem;
}

.wc-payment-method:hover {
    border-color: hsl(var(--primary) / 0.5);
}

.wc-payment-method.selected {
    border-color: hsl(var(--primary));
    background: hsl(var(--primary) / 0.05);
}

.wc-payment-method input[type="radio"] {
    display: none;
}

.wc-payment-icon {
    width: 44px;
    height: 44px;
    border-radius: 0.5rem;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.wc-payment-icon.stripe {
    background: #635bff;
}

.wc-payment-icon.paypal {
    background: #003087;
}

.wc-payment-icon.bank_transfer {
    background: hsl(var(--primary) / 0.15);
}

.wc-payment-icon svg {
    width: 24px;
    height: 24px;
    color: white;
}

.wc-payment-icon.bank_transfer svg {
    color: hsl(var(--primary));
}

.wc-payment-info {
    flex: 1;
}

.wc-payment-name {
    font-size: 0.9375rem;
    font-weight: 600;
    color: hsl(var(--foreground));
    margin: 0 0 0.125rem;
}

.wc-payment-desc {
    font-size: 0.8125rem;
    color: hsl(var(--muted-foreground));
    margin: 0;
}

/* Order Summary Sidebar */
.wc-order-summary {
    background: hsl(var(--card));
    border: 1px solid hsl(var(--border));
    border-radius: 0.75rem;
    position: sticky;
    top: 2rem;
}

.wc-order-header {
    padding: 1.25rem 1.5rem;
    border-bottom: 1px solid hsl(var(--border));
}

.wc-order-title {
    font-size: 1.25rem;
    font-weight: 700;
    color: hsl(var(--foreground));
    margin: 0;
}

.wc-order-body {
    padding: 1.5rem;
}

.wc-order-item {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    padding: 0.875rem 0;
    border-bottom: 1px solid hsl(var(--border));
}

.wc-order-item:first-child {
    padding-top: 0;
}

.wc-order-item-name {
    font-size: 0.9375rem;
    color: hsl(var(--foreground));
    font-weight: 500;
}

.wc-order-item-details {
    font-size: 0.8125rem;
    color: hsl(var(--muted-foreground));
    margin-top: 0.25rem;
}

.wc-order-item-price {
    font-size: 0.9375rem;
    font-weight: 600;
    color: hsl(var(--foreground));
    text-align: right;
}

.wc-order-subtotal,
.wc-order-total {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0.875rem 0;
}

.wc-order-subtotal {
    border-bottom: 1px solid hsl(var(--border));
}

.wc-order-subtotal span {
    font-size: 0.9375rem;
    color: hsl(var(--muted-foreground));
}

.wc-order-total {
    padding-top: 1rem;
}

.wc-order-total span:first-child {
    font-size: 1rem;
    font-weight: 700;
    color: hsl(var(--foreground));
}

.wc-order-total span:last-child {
    font-size: 1.5rem;
    font-weight: 700;
    color: hsl(var(--primary));
}

/* Payment Methods inside Your Order */
.wc-order-payment-section {
    margin-top: 1.25rem;
    padding-top: 1.25rem;
    border-top: 1px solid hsl(var(--border));
}

.wc-order-payment-title {
    font-size: 0.9375rem;
    font-weight: 600;
    color: hsl(var(--foreground));
    margin: 0 0 0.75rem;
}

.wc-payment-methods-compact {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
}

.wc-payment-method-compact {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    padding: 0.75rem;
    border: 2px solid hsl(var(--border));
    border-radius: 0.5rem;
    cursor: pointer;
    transition: all 0.2s;
}

.wc-payment-method-compact:hover {
    border-color: hsl(var(--primary) / 0.5);
}

.wc-payment-method-compact.selected {
    border-color: hsl(var(--primary));
    background: hsl(var(--primary) / 0.05);
}

.wc-payment-method-compact input[type="radio"] {
    display: none;
}

.wc-payment-icon-sm {
    width: 36px;
    height: 36px;
    border-radius: 0.375rem;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.wc-payment-icon-sm.stripe {
    background: #635bff;
}

.wc-payment-icon-sm.paypal {
    background: #003087;
}

.wc-payment-icon-sm.bank_transfer {
    background: hsl(var(--primary) / 0.15);
}

.wc-payment-icon-sm svg {
    width: 18px;
    height: 18px;
    color: white;
}

.wc-payment-icon-sm.bank_transfer svg {
    color: hsl(var(--primary));
}

.wc-payment-label {
    flex: 1;
    font-size: 0.875rem;
    font-weight: 500;
    color: hsl(var(--foreground));
}

.wc-radio-check-sm {
    width: 18px;
    height: 18px;
    border: 2px solid hsl(var(--border));
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    transition: all 0.2s;
}

.wc-payment-method-compact.selected .wc-radio-check-sm {
    border-color: hsl(var(--primary));
    background: hsl(var(--primary));
}

.wc-radio-check-sm svg {
    width: 10px;
    height: 10px;
    color: white;
    opacity: 0;
    transition: all 0.2s;
}

.wc-payment-method-compact.selected .wc-radio-check-sm svg {
    opacity: 1;
}

.wc-no-gateways-sm {
    padding: 1rem;
    background: hsl(45 93% 47% / 0.1);
    border-radius: 0.5rem;
    margin-top: 1rem;
}

.wc-no-gateways-sm p {
    margin: 0;
    font-size: 0.8125rem;
    color: hsl(45 93% 47%);
    text-align: center;
}

/* Place Order Button */
.wc-place-order-btn {
    width: 100%;
    padding: 1rem 1.5rem;
    background: linear-gradient(135deg, hsl(60 96% 79%), hsl(186 80% 19%));
    color: hsl(var(--primary-foreground));
    border: none;
    border-radius: 0.75rem;
    font-size: 1.0625rem;
    font-weight: 700;
    cursor: pointer;
    transition: all 0.3s ease;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
    margin-top: 1.5rem;
    box-shadow: 0 10px 15px -3px hsl(60 96% 79% / 0.3), 0 4px 6px -4px hsl(186 80% 19% / 0.2);
}

.wc-place-order-btn:hover:not(:disabled) {
    transform: translateY(-2px);
    box-shadow: 0 15px 25px -5px hsl(60 96% 79% / 0.4), 0 10px 10px -5px hsl(186 80% 19% / 0.3);
}

.wc-place-order-btn:disabled {
    opacity: 0.6;
    cursor: not-allowed;
    transform: none;
}

.wc-place-order-btn .spinner {
    width: 20px;
    height: 20px;
    border: 2px solid rgba(0, 0, 0, 0.2);
    border-top-color: hsl(var(--primary-foreground));
    border-radius: 50%;
    animation: spin 0.8s linear infinite;
    display: none;
}

@keyframes spin {
    to { transform: rotate(360deg); }
}

/* Privacy Notice */
.wc-privacy-notice {
    font-size: 0.8125rem;
    color: hsl(var(--muted-foreground));
    line-height: 1.5;
    margin-top: 1rem;
    text-align: center;
}

.wc-privacy-notice a {
    color: hsl(var(--primary));
    text-decoration: underline;
}

/* Secure Badge */
.wc-secure-badge {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
    padding: 1rem;
    background: hsl(var(--primary) / 0.1);
    border-radius: 0.5rem;
    margin-top: 1rem;
    font-size: 0.8125rem;
    color: hsl(var(--primary));
    font-weight: 500;
}

.wc-secure-badge svg {
    width: 16px;
    height: 16px;
}

/* No Gateways Message */
.wc-no-gateways {
    text-align: center;
    padding: 2rem;
    background: hsl(45 93% 47% / 0.1);
    border: 1px solid hsl(45 93% 47% / 0.3);
    border-radius: 0.75rem;
}

.wc-no-gateways svg {
    width: 48px;
    height: 48px;
    color: hsl(45 93% 47%);
    margin-bottom: 1rem;
}

.wc-no-gateways h3 {
    font-size: 1.125rem;
    font-weight: 600;
    color: hsl(var(--foreground));
    margin: 0 0 0.5rem;
}

.wc-no-gateways p {
    font-size: 0.875rem;
    color: hsl(var(--muted-foreground));
    margin: 0;
}

/* Bank Transfer Modal */
.wc-bank-modal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.7);
    backdrop-filter: blur(4px);
    z-index: 9999;
    align-items: center;
    justify-content: center;
    padding: 1rem;
}

.wc-bank-modal.active {
    display: flex;
}

.wc-bank-modal-content {
    background: hsl(var(--card));
    border-radius: 1rem;
    padding: 2rem;
    max-width: 480px;
    width: 100%;
    max-height: 90vh;
    overflow-y: auto;
}

.wc-bank-modal-content h3 {
    font-size: 1.5rem;
    font-weight: 700;
    color: hsl(var(--foreground));
    margin: 0 0 0.5rem;
}

.wc-bank-modal-content > p {
    color: hsl(var(--muted-foreground));
    margin: 0 0 1.5rem;
    font-size: 0.9375rem;
}

.wc-bank-detail-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0.875rem 0;
    border-bottom: 1px solid hsl(var(--border));
}

.wc-bank-detail-row:last-of-type {
    border-bottom: none;
}

.wc-bank-detail-row label {
    font-size: 0.875rem;
    color: hsl(var(--muted-foreground));
    font-weight: 500;
}

.wc-bank-detail-row .value {
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.wc-bank-detail-row span {
    font-size: 0.9375rem;
    color: hsl(var(--foreground));
    font-weight: 600;
    font-family: monospace;
}

.wc-bank-copy-btn {
    background: hsl(var(--primary));
    color: hsl(var(--primary-foreground));
    border: none;
    padding: 0.25rem 0.5rem;
    border-radius: 0.25rem;
    font-size: 0.75rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.2s;
}

.wc-bank-copy-btn:hover {
    opacity: 0.9;
}

.wc-bank-warning {
    background: hsl(45 93% 47% / 0.15);
    border: 1px solid hsl(45 93% 47% / 0.3);
    border-radius: 0.5rem;
    padding: 1rem;
    margin-top: 1.5rem;
}

.wc-bank-warning p {
    margin: 0;
    font-size: 0.875rem;
    color: hsl(45 93% 47%);
    line-height: 1.5;
}

.wc-bank-close-btn {
    width: 100%;
    padding: 0.875rem 1.5rem;
    background: hsl(var(--secondary));
    color: hsl(var(--foreground));
    border: none;
    border-radius: 0.5rem;
    font-size: 0.9375rem;
    font-weight: 600;
    cursor: pointer;
    margin-top: 1.5rem;
    transition: all 0.2s;
}

.wc-bank-close-btn:hover {
    background: hsl(var(--secondary) / 0.8);
}
</style>

<div class="wc-checkout-page">
    <div class="wc-checkout-container">
        
        <!-- Page Title -->
        <div class="wc-checkout-header">
            <h1 class="wc-checkout-title"><?php _e('Checkout', 'wheelfy'); ?></h1>
        </div>
        
        <!-- Alert Messages -->
        <?php if ($payment_status === 'cancelled') : ?>
            <div class="wc-alert warning">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="12" cy="12" r="10"/>
                    <line x1="12" y1="8" x2="12" y2="12"/>
                    <line x1="12" y1="16" x2="12.01" y2="16"/>
                </svg>
                <?php _e('Payment was cancelled. Please try again.', 'wheelfy'); ?>
            </div>
        <?php endif; ?>
        
        <?php if ($payment_status === 'success') : ?>
            <div class="wc-alert success">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
                    <polyline points="22 4 12 14.01 9 11.01"/>
                </svg>
                <?php _e('Payment successful! Your subscription has been activated.', 'wheelfy'); ?>
            </div>
        <?php endif; ?>
        
        <div class="wc-checkout-grid">
            <!-- Left Column - Forms -->
            <div class="wc-checkout-forms">
                
                <!-- Billing Details Section -->
                <div class="wc-checkout-section">
                    <div class="wc-section-header">
                        <h2 class="wc-section-title">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                                <circle cx="12" cy="7" r="4"/>
                            </svg>
                            <?php _e('Billing Details', 'wheelfy'); ?>
                        </h2>
                    </div>
                    <div class="wc-section-body">
                        <div class="wc-form-row">
                            <div class="wc-form-group">
                                <label for="billing_first_name"><?php _e('First Name', 'wheelfy'); ?> <span class="required">*</span></label>
                                <input type="text" id="billing_first_name" name="billing_first_name" value="<?php echo esc_attr($billing_first_name); ?>" required>
                            </div>
                            <div class="wc-form-group">
                                <label for="billing_last_name"><?php _e('Last Name', 'wheelfy'); ?> <span class="required">*</span></label>
                                <input type="text" id="billing_last_name" name="billing_last_name" value="<?php echo esc_attr($billing_last_name); ?>" required>
                            </div>
                        </div>
                        
                        <div class="wc-form-row full">
                            <div class="wc-form-group">
                                <label for="billing_company"><?php _e('Company Name (optional)', 'wheelfy'); ?></label>
                                <input type="text" id="billing_company" name="billing_company" value="<?php echo esc_attr($billing_company); ?>">
                            </div>
                        </div>
                        
                        <div class="wc-form-row full">
                            <div class="wc-form-group">
                                <label for="billing_country"><?php _e('Country / Region', 'wheelfy'); ?> <span class="required">*</span></label>
                                <select id="billing_country" name="billing_country" required>
                                    <option value="Hungary" selected>Hungary</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="wc-form-row full">
                            <div class="wc-form-group">
                                <label for="billing_address"><?php _e('Street Address', 'wheelfy'); ?> <span class="required">*</span></label>
                                <input type="text" id="billing_address" name="billing_address" value="<?php echo esc_attr($billing_address); ?>" placeholder="<?php _e('House number and street name', 'wheelfy'); ?>" required>
                            </div>
                        </div>
                        
                        <div class="wc-form-row">
                            <div class="wc-form-group">
                                <label for="billing_city"><?php _e('Town / City', 'wheelfy'); ?> <span class="required">*</span></label>
                                <input type="text" id="billing_city" name="billing_city" value="<?php echo esc_attr($billing_city); ?>" required>
                            </div>
                            <div class="wc-form-group">
                                <label for="billing_postcode"><?php _e('Postcode / ZIP', 'wheelfy'); ?> <span class="required">*</span></label>
                                <input type="text" id="billing_postcode" name="billing_postcode" value="<?php echo esc_attr($billing_postcode); ?>" required>
                            </div>
                        </div>
                        
                        <div class="wc-form-row">
                            <div class="wc-form-group">
                                <label for="billing_phone"><?php _e('Phone', 'wheelfy'); ?> <span class="required">*</span></label>
                                <input type="tel" id="billing_phone" name="billing_phone" value="<?php echo esc_attr($billing_phone); ?>" required>
                            </div>
                            <div class="wc-form-group">
                                <label for="billing_email"><?php _e('Email Address', 'wheelfy'); ?> <span class="required">*</span></label>
                                <input type="email" id="billing_email" name="billing_email" value="<?php echo esc_attr($billing_email); ?>" required readonly>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Selected Plan Section -->
                <div class="wc-checkout-section">
                    <div class="wc-section-header">
                        <h2 class="wc-section-title">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M12 2L2 7l10 5 10-5-10-5z"/>
                                <path d="M2 17l10 5 10-5"/>
                                <path d="M2 12l10 5 10-5"/>
                            </svg>
                            <?php _e('Selected Plan', 'wheelfy'); ?>
                        </h2>
                    </div>
                    <div class="wc-section-body">
                        <div class="wc-plan-options" id="plansList">
                            <?php if ($plan) : ?>
                                <!-- Show only the pre-selected plan -->
                                <div class="wc-plan-option selected <?php echo $plan->is_popular ? 'popular' : ''; ?>" data-plan-id="<?php echo esc_attr($plan->id); ?>">
                                    <?php if ($plan->is_popular) : ?>
                                        <span class="wc-plan-badge"><?php _e('Popular', 'wheelfy'); ?></span>
                                    <?php endif; ?>
                                    <input type="hidden" name="plan_id" value="<?php echo esc_attr($plan->id); ?>">
                                    <div class="wc-radio-check" style="border-color: hsl(var(--primary)); background: hsl(var(--primary));">
                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" style="opacity: 1;">
                                            <polyline points="20 6 9 17 4 12"/>
                                        </svg>
                                    </div>
                                    <div class="wc-plan-info">
                                        <h4 class="wc-plan-name"><?php echo esc_html($plan->plan_name); ?></h4>
                                        <div class="wc-plan-features">
                                            <?php 
                                            $features = is_array($plan->features) ? $plan->features : json_decode($plan->features, true);
                                            if (!empty($features)) :
                                                foreach ($features as $feature) : 
                                            ?>
                                                <span class="wc-plan-feature">
                                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                                        <polyline points="20 6 9 17 4 12"/>
                                                    </svg>
                                                    <?php echo esc_html(is_array($feature) ? ($feature['text'] ?? '') : $feature); ?>
                                                </span>
                                            <?php 
                                                endforeach;
                                            endif; 
                                            ?>
                                        </div>
                                    </div>
                                    <div class="wc-plan-price">
                                        <?php if ($plan->price > 0) : ?>
                                            <span class="amount"><?php echo number_format($plan->price, 0, ',', ' '); ?> <?php echo esc_html($currency_symbol); ?></span>
                                            <span class="period">/<?php echo esc_html($plan->billing_cycle ?? 'month'); ?></span>
                                        <?php else : ?>
                                            <span class="amount"><?php _e('Free', 'wheelfy'); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <!-- Change Plan Link -->
                                <div style="text-align: center; margin-top: 1rem;">
                                    <a href="<?php echo esc_url(home_url('/pricing')); ?>" style="color: hsl(var(--primary)); font-size: 0.875rem; text-decoration: underline;">
                                        <?php _e('Change Plan', 'wheelfy'); ?>
                                    </a>
                                </div>
                            <?php else : ?>
                                <!-- No plan selected - redirect to pricing page -->
                                <div class="wc-no-gateways">
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <circle cx="12" cy="12" r="10"/>
                                        <line x1="12" y1="8" x2="12" y2="12"/>
                                        <line x1="12" y1="16" x2="12.01" y2="16"/>
                                    </svg>
                                    <h3><?php _e('No Plan Selected', 'wheelfy'); ?></h3>
                                    <p><?php _e('Please select a plan from the pricing page first.', 'wheelfy'); ?></p>
                                    <a href="<?php echo esc_url(home_url('/pricing')); ?>" class="wc-place-order-btn" style="margin-top: 1rem; display: inline-flex;">
                                        <?php _e('View Pricing Plans', 'wheelfy'); ?>
                                    </a>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
            </div>
            
            <!-- Right Column - Order Summary -->
            <div class="wc-order-sidebar">
                <div class="wc-order-summary">
                    <div class="wc-order-header">
                        <h2 class="wc-order-title"><?php _e('Your Order', 'wheelfy'); ?></h2>
                    </div>
                    <div class="wc-order-body">
                        <!-- Order Item -->
                        <div class="wc-order-item">
                            <div>
                                <div class="wc-order-item-name" id="orderPlanName">-</div>
                                <div class="wc-order-item-details" id="orderPlanCycle">-</div>
                            </div>
                            <div class="wc-order-item-price" id="orderPlanPrice">0 <?php echo esc_html($currency_symbol); ?></div>
                        </div>
                        
                        <!-- Subtotal -->
                        <div class="wc-order-subtotal">
                            <span><?php _e('Subtotal', 'wheelfy'); ?></span>
                            <span id="orderSubtotal">0 <?php echo esc_html($currency_symbol); ?></span>
                        </div>
                        
                        <!-- Total -->
                        <div class="wc-order-total">
                            <span><?php _e('Total', 'wheelfy'); ?></span>
                            <span id="orderTotal">0 <?php echo esc_html($currency_symbol); ?></span>
                        </div>
                        
                        <!-- Payment Methods (inside Your Order) -->
                        <?php if (!empty($enabled_gateways)) : ?>
                            <div class="wc-order-payment-section">
                                <h4 class="wc-order-payment-title"><?php _e('Payment Method', 'wheelfy'); ?></h4>
                                <div class="wc-payment-methods-compact" id="paymentMethods">
                                    <?php foreach ($enabled_gateways as $gateway) : ?>
                                        <label class="wc-payment-method-compact" data-gateway="<?php echo esc_attr($gateway['id']); ?>">
                                            <input type="radio" name="gateway" value="<?php echo esc_attr($gateway['id']); ?>">
                                            <div class="wc-payment-icon-sm <?php echo esc_attr($gateway['id']); ?>">
                                                <?php if ($gateway['id'] === 'stripe') : ?>
                                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                                        <rect x="1" y="4" width="22" height="16" rx="2" ry="2"/>
                                                        <line x1="1" y1="10" x2="23" y2="10"/>
                                                    </svg>
                                                <?php elseif ($gateway['id'] === 'paypal') : ?>
                                                    <svg viewBox="0 0 24 24" fill="currentColor">
                                                        <path d="M7.076 21.337H2.47a.641.641 0 0 1-.633-.74L4.944.901C5.026.382 5.474 0 5.998 0h7.46c2.57 0 4.578.543 5.69 1.81 1.01 1.15 1.304 2.42 1.012 4.287-.023.143-.047.288-.077.437-.983 5.05-4.349 6.797-8.647 6.797h-2.19c-.524 0-.968.382-1.05.9l-1.12 7.106z"/>
                                                    </svg>
                                                <?php elseif ($gateway['id'] === 'bank_transfer') : ?>
                                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                                        <path d="M3 21h18M3 10h18M5 6l7-3 7 3M4 10v11M20 10v11M8 14v3M12 14v3M16 14v3"/>
                                                    </svg>
                                                <?php else : ?>
                                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                                        <rect x="2" y="6" width="20" height="12" rx="2"/>
                                                        <circle cx="12" cy="12" r="3"/>
                                                    </svg>
                                                <?php endif; ?>
                                            </div>
                                            <span class="wc-payment-label"><?php echo esc_html($gateway['title']); ?></span>
                                            <div class="wc-radio-check-sm">
                                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3">
                                                    <polyline points="20 6 9 17 4 12"/>
                                                </svg>
                                            </div>
                                        </label>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                            
                            <!-- Place Order Button -->
                            <button type="button" class="wc-place-order-btn" id="placeOrderBtn" disabled>
                                <span class="btn-text"><?php _e('Place Order', 'wheelfy'); ?></span>
                                <span class="spinner"></span>
                            </button>
                        <?php else : ?>
                            <div class="wc-no-gateways-sm">
                                <p><?php _e('No payment methods available. Please contact support.', 'wheelfy'); ?></p>
                            </div>
                        <?php endif; ?>
                        
                        <!-- Privacy Notice -->
                        <p class="wc-privacy-notice">
                            <?php _e('Your personal data will be used to process your order, support your experience throughout this website, and for other purposes described in our', 'wheelfy'); ?> 
                            <a href="<?php echo esc_url(get_privacy_policy_url()); ?>"><?php _e('privacy policy', 'wheelfy'); ?></a>.
                        </p>
                        
                        <!-- Secure Badge -->
                        <div class="wc-secure-badge">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                                <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
                            </svg>
                            <?php _e('Secure SSL Encrypted Payment', 'wheelfy'); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bank Transfer Details Modal -->
<div class="wc-bank-modal" id="bankDetailsModal">
    <div class="wc-bank-modal-content">
        <h3><?php _e('Bank Transfer Details', 'wheelfy'); ?></h3>
        <p><?php _e('Please transfer the amount to the following bank account:', 'wheelfy'); ?></p>
        
        <div class="wc-bank-detail-row">
            <label><?php _e('Account Name', 'wheelfy'); ?></label>
            <div class="value">
                <span id="bankAccountName">-</span>
            </div>
        </div>
        <div class="wc-bank-detail-row">
            <label><?php _e('Account Number', 'wheelfy'); ?></label>
            <div class="value">
                <span id="bankAccountNumber">-</span>
                <button class="wc-bank-copy-btn" data-copy="bankAccountNumber"><?php _e('Copy', 'wheelfy'); ?></button>
            </div>
        </div>
        <div class="wc-bank-detail-row">
            <label><?php _e('Bank Name', 'wheelfy'); ?></label>
            <div class="value">
                <span id="bankName">-</span>
            </div>
        </div>
        <div class="wc-bank-detail-row">
            <label><?php _e('IBAN / SWIFT', 'wheelfy'); ?></label>
            <div class="value">
                <span id="bankIban">-</span>
                <button class="wc-bank-copy-btn" data-copy="bankIban"><?php _e('Copy', 'wheelfy'); ?></button>
            </div>
        </div>
        <div class="wc-bank-detail-row">
            <label><?php _e('Reference', 'wheelfy'); ?></label>
            <div class="value">
                <span id="bankReference">-</span>
                <button class="wc-bank-copy-btn" data-copy="bankReference"><?php _e('Copy', 'wheelfy'); ?></button>
            </div>
        </div>
        <div class="wc-bank-detail-row">
            <label><?php _e('Amount', 'wheelfy'); ?></label>
            <div class="value">
                <span id="bankAmount" style="color: hsl(var(--primary)); font-weight: 700;">-</span>
            </div>
        </div>
        
        <div class="wc-bank-warning">
            <p><strong><?php _e('Important:', 'wheelfy'); ?></strong> <?php _e('Please use the Reference number as your payment reference. Your subscription will be activated once we confirm your payment (usually within 1-2 business days).', 'wheelfy'); ?></p>
        </div>
        
        <button type="button" class="wc-bank-close-btn" onclick="closeBankModal()">
            <?php _e('I understand, close', 'wheelfy'); ?>
        </button>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const paymentMethods = document.querySelectorAll('.wc-payment-method-compact');
    const placeOrderBtn = document.getElementById('placeOrderBtn');
    const orderPlanName = document.getElementById('orderPlanName');
    const orderPlanCycle = document.getElementById('orderPlanCycle');
    const orderPlanPrice = document.getElementById('orderPlanPrice');
    const orderSubtotal = document.getElementById('orderSubtotal');
    const orderTotal = document.getElementById('orderTotal');
    
    let selectedGateway = null;
    
    const currencySymbol = '<?php echo esc_js($currency_symbol); ?>';
    
    // Pre-selected plan from URL parameter
    <?php if ($plan) : ?>
    const selectedPlan = {
        id: <?php echo intval($plan->id); ?>,
        name: '<?php echo esc_js($plan->plan_name); ?>',
        price: <?php echo floatval($plan->price); ?>,
        price_formatted: '<?php echo number_format($plan->price, 0, ',', ' ') . ' ' . esc_js($currency_symbol); ?>',
        billing_cycle: '<?php echo esc_js($plan->billing_cycle ?? 'monthly'); ?>'
    };
    <?php else : ?>
    const selectedPlan = null;
    <?php endif; ?>
    
    // Payment method selection
    paymentMethods.forEach(method => {
        method.addEventListener('click', function() {
            paymentMethods.forEach(m => m.classList.remove('selected'));
            this.classList.add('selected');
            this.querySelector('input[type="radio"]').checked = true;
            
            selectedGateway = this.dataset.gateway;
            updatePlaceOrderButton();
        });
    });
    
    function updateOrderSummary() {
        if (selectedPlan) {
            orderPlanName.textContent = selectedPlan.name;
            
            let cycleText = '';
            if (selectedPlan.billing_cycle === 'monthly') {
                cycleText = '<?php echo esc_js(__('Monthly subscription', 'wheelfy')); ?>';
            } else if (selectedPlan.billing_cycle === 'yearly') {
                cycleText = '<?php echo esc_js(__('Yearly subscription', 'wheelfy')); ?>';
            } else {
                cycleText = selectedPlan.billing_cycle;
            }
            orderPlanCycle.textContent = cycleText;
            
            const priceText = selectedPlan.price > 0 ? selectedPlan.price_formatted : '<?php echo esc_js(__('Free', 'wheelfy')); ?>';
            orderPlanPrice.textContent = priceText;
            orderSubtotal.textContent = priceText;
            orderTotal.textContent = priceText;
        }
    }
    
    function updatePlaceOrderButton() {
        if (!placeOrderBtn) return;
        
        const enabled = selectedPlan && (selectedPlan.price <= 0 || selectedGateway);
        placeOrderBtn.disabled = !enabled;
        
        if (selectedPlan && selectedPlan.price <= 0) {
            placeOrderBtn.querySelector('.btn-text').textContent = '<?php echo esc_js(__('Activate Free Plan', 'wheelfy')); ?>';
        } else {
            placeOrderBtn.querySelector('.btn-text').textContent = '<?php echo esc_js(__('Place Order', 'wheelfy')); ?>';
        }
    }
    
    // Initialize order summary with pre-selected plan
    if (selectedPlan) {
        updateOrderSummary();
        updatePlaceOrderButton();
    }
    
    // Place order button click
    if (placeOrderBtn) {
        placeOrderBtn.addEventListener('click', function() {
            if (!selectedPlan) {
                alert('<?php echo esc_js(__('Please select a plan.', 'wheelfy')); ?>');
                return;
            }
            
            if (selectedPlan.price > 0 && !selectedGateway) {
                alert('<?php echo esc_js(__('Please select a payment method.', 'wheelfy')); ?>');
                return;
            }
            
            // Validate billing fields
            const requiredFields = ['billing_first_name', 'billing_last_name', 'billing_country', 'billing_address', 'billing_city', 'billing_postcode', 'billing_phone'];
            let isValid = true;
            
            requiredFields.forEach(fieldId => {
                const field = document.getElementById(fieldId);
                if (field && !field.value.trim()) {
                    field.style.borderColor = 'hsl(0 84% 60%)';
                    isValid = false;
                } else if (field) {
                    field.style.borderColor = '';
                }
            });
            
            if (!isValid) {
                alert('<?php echo esc_js(__('Please fill in all required billing fields.', 'wheelfy')); ?>');
                return;
            }
            
            // Show loading
            placeOrderBtn.disabled = true;
            placeOrderBtn.querySelector('.btn-text').style.display = 'none';
            placeOrderBtn.querySelector('.spinner').style.display = 'block';
            
            // Collect billing data
            const billingData = {
                first_name: document.getElementById('billing_first_name').value,
                last_name: document.getElementById('billing_last_name').value,
                company: document.getElementById('billing_company').value,
                country: document.getElementById('billing_country').value,
                address: document.getElementById('billing_address').value,
                city: document.getElementById('billing_city').value,
                postcode: document.getElementById('billing_postcode').value,
                phone: document.getElementById('billing_phone').value,
                email: document.getElementById('billing_email').value
            };
            
            // Process checkout
            const formData = new FormData();
            formData.append('action', 'wheelfy_process_checkout');
            formData.append('nonce', '<?php echo wp_create_nonce('wheelfy_checkout_nonce'); ?>');
            formData.append('plan_id', selectedPlan.id);
            formData.append('gateway', selectedPlan.price <= 0 ? 'free' : selectedGateway);
            formData.append('billing_data', JSON.stringify(billingData));
            
            fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    if (data.data.redirect) {
                        window.location.href = data.data.redirect;
                    } else if (data.data.checkout_url) {
                        window.location.href = data.data.checkout_url;
                    } else if (data.data.gateway === 'bank_transfer') {
                        showBankDetails(data.data.bank_details);
                    } else {
                        alert(data.data.message || '<?php echo esc_js(__('Success!', 'wheelfy')); ?>');
                    }
                } else {
                    alert(data.data.message || '<?php echo esc_js(__('An error occurred. Please try again.', 'wheelfy')); ?>');
                    resetPlaceOrderButton();
                }
            })
            .catch(error => {
                console.error('Checkout error:', error);
                alert('<?php echo esc_js(__('An error occurred. Please try again.', 'wheelfy')); ?>');
                resetPlaceOrderButton();
            });
        });
    }
    
    function resetPlaceOrderButton() {
        if (!placeOrderBtn) return;
        placeOrderBtn.disabled = false;
        placeOrderBtn.querySelector('.btn-text').style.display = 'inline';
        placeOrderBtn.querySelector('.spinner').style.display = 'none';
    }
    
    function showBankDetails(details) {
        document.getElementById('bankAccountName').textContent = details.account_name || '-';
        document.getElementById('bankAccountNumber').textContent = details.account_number || '-';
        document.getElementById('bankName').textContent = details.bank_name || '-';
        document.getElementById('bankIban').textContent = details.iban || '-';
        document.getElementById('bankReference').textContent = details.reference || '-';
        document.getElementById('bankAmount').textContent = details.amount || '-';
        
        document.getElementById('bankDetailsModal').classList.add('active');
        resetPlaceOrderButton();
    }
    
    // Copy functionality
    document.querySelectorAll('.wc-bank-copy-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const targetId = this.dataset.copy;
            const text = document.getElementById(targetId).textContent;
            navigator.clipboard.writeText(text).then(() => {
                this.textContent = '<?php echo esc_js(__('Copied!', 'wheelfy')); ?>';
                setTimeout(() => {
                    this.textContent = '<?php echo esc_js(__('Copy', 'wheelfy')); ?>';
                }, 2000);
            });
        });
    });
    
    // Handle PayPal return
    <?php if ($payment_gateway_return === 'paypal' && $payment_status === 'success') : ?>
    (function() {
        const urlParams = new URLSearchParams(window.location.search);
        const token = urlParams.get('token');
        const transactionId = urlParams.get('transaction_id');
        
        if (token && transactionId) {
            const formData = new FormData();
            formData.append('action', 'wheelfy_verify_paypal_payment');
            formData.append('nonce', '<?php echo wp_create_nonce('wheelfy_checkout_nonce'); ?>');
            formData.append('order_id', token);
            formData.append('transaction_id', transactionId);
            
            fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success && data.data.redirect) {
                    window.location.href = data.data.redirect;
                } else {
                    alert(data.data.message || 'Payment verification failed.');
                }
            });
        }
    })();
    <?php endif; ?>
});

function closeBankModal() {
    document.getElementById('bankDetailsModal').classList.remove('active');
}

// Close modal on outside click
document.getElementById('bankDetailsModal').addEventListener('click', function(e) {
    if (e.target === this) {
        closeBankModal();
    }
});
</script>

<?php get_footer(); ?>
