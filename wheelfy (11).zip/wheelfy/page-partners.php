<?php
/**
 * Template Name: Partners
 * 
 * @package Wheelfy
 */

get_header();
?>

<!-- Hero Section -->
<section class="relative min-h-[80vh] flex items-center overflow-hidden">
    <!-- Background Image -->
    <div class="absolute inset-0">
        <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/hero-maintenance.jpg'); ?>" alt="Partner network" class="w-full h-full object-cover">
        <div class="absolute inset-0 hero-gradient"></div>
        <div class="absolute inset-0 bg-gradient-to-r from-background via-background/90 to-transparent"></div>
    </div>
    
    <!-- Modern Background Effects -->
    <div class="absolute inset-0 overflow-hidden">
        <div class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-gradient-to-r from-primary/10 via-primary/5 to-transparent rounded-full blur-3xl animate-pulse opacity-50"></div>
    </div>
    
    <div class="container mx-auto px-4 lg:px-8 relative z-10">
        <div class="max-w-3xl mx-auto text-center">
            <!-- Badge -->
            <div class="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 text-primary text-sm font-medium mb-6 animate-fade-in-up" data-animate>
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                </svg>
                <span>Partner Program</span>
            </div>
            
            <h1 class="text-foreground mb-6 hero-title animate-fade-in-up" style="animation-delay: 0.2s; opacity: 0;" data-animate>
                Join Our
                <span class="gradient-text block mt-2">Partner Network</span>
            </h1>
            
            <p class="text-lg md:text-xl text-muted-foreground mb-10 max-w-2xl mx-auto leading-relaxed animate-fade-in-up" style="animation-delay: 0.4s; opacity: 0;" data-animate>
                Connect with thousands of car owners. Grow your business with our trusted platform. Get qualified leads and expand your reach.
            </p>
            
            <div class="flex flex-col sm:flex-row gap-4 justify-center animate-fade-in-up" style="animation-delay: 0.6s; opacity: 0;" data-animate>
                <a href="<?php echo esc_url(home_url('/become-partner')); ?>" class="button button-hero button-xl group inline-flex items-center gap-2 px-8 py-4 rounded-xl font-semibold shadow-2xl shadow-primary/30 hover:shadow-primary/40 hover:scale-105 transition-all">
                Become a Partner
                <svg class="w-5 h-5 transition-transform group-hover:translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
                </svg>
            </a>
                <a href="<?php echo esc_url(home_url('/pricing')); ?>" class="button button-hero-outline button-xl px-8 py-4 rounded-xl font-semibold border-2 hover:bg-primary/10 hover:border-primary/50 transition-all">
                    View Pricing
                </a>
            </div>
        </div>
    </div>
    
    <!-- Decorative Elements -->
    <div class="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-background to-transparent"></div>
</section>

<!-- Partners Grid -->
<section class="py-24 bg-background">
    <div class="container mx-auto px-4 lg:px-8">
        <div class="text-center mb-16">
            <h2 class="text-foreground mb-4 section-title">
                Our Trusted Partners
            </h2>
            <p class="text-lg text-muted-foreground max-w-2xl mx-auto">
                We work with verified service providers and dealerships across the country.
            </p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <!-- Partner Card 1 -->
            <div class="bg-card rounded-2xl p-6 border border-border card-hover-smooth">
                <div class="w-16 h-16 rounded-xl bg-primary/10 flex items-center justify-center mb-4">
                    <svg class="w-8 h-8 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                    </svg>
                </div>
                <h3 class="text-xl font-semibold text-foreground mb-2">Premium Auto Service</h3>
                <p class="text-muted-foreground mb-4">Expert car maintenance and repair services with 15+ years of experience.</p>
                <div class="flex items-center gap-2 text-sm text-muted-foreground">
                    <svg class="w-4 h-4 text-primary" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                    </svg>
                    <span>4.8 Rating</span>
                    <span class="mx-2">•</span>
                    <span>500+ Reviews</span>
                </div>
            </div>

            <!-- Partner Card 2 -->
            <div class="bg-card rounded-2xl p-6 border border-border card-hover-smooth">
                <div class="w-16 h-16 rounded-xl bg-primary/10 flex items-center justify-center mb-4">
                    <svg class="w-8 h-8 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                </div>
                <h3 class="text-xl font-semibold text-foreground mb-2">City Car Dealership</h3>
                <p class="text-muted-foreground mb-4">Leading car sales and trade-in services with competitive pricing.</p>
                <div class="flex items-center gap-2 text-sm text-muted-foreground">
                    <svg class="w-4 h-4 text-primary" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                    </svg>
                    <span>4.9 Rating</span>
                    <span class="mx-2">•</span>
                    <span>1200+ Reviews</span>
                </div>
            </div>

            <!-- Partner Card 3 -->
            <div class="bg-card rounded-2xl p-6 border border-border card-hover-smooth">
                <div class="w-16 h-16 rounded-xl bg-primary/10 flex items-center justify-center mb-4">
                    <svg class="w-8 h-8 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                    </svg>
                </div>
                <h3 class="text-xl font-semibold text-foreground mb-2">Quick Fix Garage</h3>
                <p class="text-muted-foreground mb-4">Fast and reliable maintenance services with same-day appointments available.</p>
                <div class="flex items-center gap-2 text-sm text-muted-foreground">
                    <svg class="w-4 h-4 text-primary" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                    </svg>
                    <span>4.7 Rating</span>
                    <span class="mx-2">•</span>
                    <span>800+ Reviews</span>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- CTA Section -->
<section class="py-24 section-gradient">
    <div class="container mx-auto px-4 lg:px-8">
        <div class="max-w-3xl mx-auto text-center">
            <h2 class="text-foreground mb-6 section-title">
                Ready to Join Us?
            </h2>
            <p class="text-lg text-muted-foreground mb-10">
                Become a partner and start receiving qualified leads today.
            </p>
            <a href="<?php echo esc_url(home_url('/become-partner')); ?>" class="button button-hero button-xl group inline-flex items-center gap-2">
                Apply Now
                <svg class="w-5 h-5 transition-transform group-hover:translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
                </svg>
            </a>
        </div>
    </div>
</section>

<?php
get_footer();


