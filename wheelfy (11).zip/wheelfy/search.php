<?php
/**
 * The template for displaying search results
 *
 * @package Wheelfy
 */

get_header();
?>

<div class="container mx-auto px-4 lg:px-8 py-16">
    <header class="mb-12">
        <h1 class="text-4xl md:text-5xl font-bold text-foreground mb-4">
            <?php
            printf(
                esc_html__('Search Results for: %s', 'wheelfy'),
                '<span class="text-primary">' . get_search_query() . '</span>'
            );
            ?>
        </h1>
    </header>

    <?php
    if (have_posts()) {
        ?>
        <div class="space-y-8">
            <?php
            while (have_posts()) {
                the_post();
                get_template_part('template-parts/content', 'search');
            }
            ?>
        </div>

        <div class="mt-12">
            <?php
            the_posts_pagination(array(
                'mid_size' => 2,
                'prev_text' => __('Previous', 'wheelfy'),
                'next_text' => __('Next', 'wheelfy'),
            ));
            ?>
        </div>
        <?php
    } else {
        get_template_part('template-parts/content', 'none');
    }
    ?>
</div>

<?php
get_footer();


