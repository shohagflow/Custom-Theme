<?php
/**
 * Template Name: Select Partner
 * 
 * Page template for selecting Premium/Exclusive partners after form submission
 */
get_header();
?>

<style>
/* CSS Variables - Match Website Branding Colors */
:root {
    --background: 220 20% 10%;
    --foreground: 210 40% 98%;
    --card: 220 18% 13%;
    --primary: 60 96% 79%;
    --primary-foreground: 220 20% 10%;
    --border: 220 15% 22%;
    --muted-foreground: 215 20% 65%;
    --secondary: 220 15% 18%;
    --brand-yellow: 60 96% 79%;
    --brand-green: 186 80% 19%;
    --premium-gold: 45 96% 55%;
    --exclusive-diamond: 210 100% 90%;
}

/* Tailwind Utilities & Custom Styles */
.container { width: 100%; max-width: 1280px; margin: 0 auto; padding: 0 2rem; }
.mx-auto { margin-left: auto; margin-right: auto; }
.px-4 { padding-left: 1rem; padding-right: 1rem; }
@media (min-width: 1024px) {
    .lg\:px-8 { padding-left: 2rem; padding-right: 2rem; }
}
.max-w-6xl { max-width: 72rem; }
.py-20 { padding-top: 5rem; padding-bottom: 5rem; }
.text-center { text-align: center; }
.mb-12 { margin-bottom: 3rem; }
.mb-6 { margin-bottom: 1.5rem; }
.mb-4 { margin-bottom: 1rem; }
.mt-12 { margin-top: 3rem; }
.mt-8 { margin-top: 2rem; }
.pt-6 { padding-top: 1.5rem; }
.pb-0 { padding-bottom: 0; }
.grid { display: grid; }
.grid-cols-1 { grid-template-columns: repeat(1, minmax(0, 1fr)); }
@media (min-width: 768px) {
    .md\:grid-cols-2 { grid-template-columns: repeat(2, minmax(0, 1fr)); }
}
@media (min-width: 1024px) {
    .lg\:grid-cols-4 { grid-template-columns: repeat(4, minmax(0, 1fr)); }
}
.gap-12 { gap: 3rem; }
.gap-6 { gap: 1.5rem; }
.flex { display: flex; }
.flex-1 { flex: 1 1 0%; }
.items-center { align-items: center; }
.justify-between { justify-content: space-between; }
.space-y-4 > * + * { margin-top: 1rem; }
.w-full { width: 100%; }
.rounded-xl { border-radius: 0.75rem; }
.p-6 { padding: 1.5rem; }
.border { border: 1px solid hsl(var(--border)); }
.border-t { border-top: 1px solid hsl(var(--border)); }
.bg-card { background: hsl(var(--card)); }
.text-foreground { color: hsl(var(--foreground)); }
.text-muted-foreground { color: hsl(var(--muted-foreground)); }
.font-bold { font-weight: 700; }
.font-semibold { font-weight: 600; }
.font-medium { font-weight: 500; }
.text-3xl { font-size: 1.875rem; }
.text-xl { font-size: 1.25rem; }
.text-lg { font-size: 1.125rem; }
.text-sm { font-size: 0.875rem; }
.h-16 { height: 4rem; }
.w-16 { width: 4rem; }
.rounded-lg { border-radius: 0.5rem; }
.gap-3 { gap: 0.75rem; }
.gap-4 { gap: 1rem; }
.mb-2 { margin-bottom: 0.5rem; }
.mb-3 { margin-bottom: 0.75rem; }
.p-4 { padding: 1rem; }
.cursor-pointer { cursor: pointer; }
.transition-all { transition: all 0.2s; }

/* Partner Card Styles */
.partner-card {
    background: hsl(var(--card));
    border: 1px solid hsl(var(--border));
    border-radius: 0.75rem;
    padding: 1.5rem;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 1.5rem;
    transition: all 0.3s ease;
}

.partner-card:hover {
    border-color: hsl(var(--primary) / 0.5);
    box-shadow: 0 4px 12px hsl(var(--primary) / 0.1);
}

.partner-card.selected {
    border-color: hsl(var(--primary));
    background: hsl(var(--primary) / 0.05);
    box-shadow: 0 4px 16px hsl(var(--primary) / 0.2);
}

.partner-info {
    display: flex;
    align-items: center;
    gap: 1.5rem;
    flex: 1;
}

.partner-logo {
    width: 64px;
    height: 64px;
    border-radius: 50%;
    background: hsl(var(--secondary));
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    border: 1px solid hsl(var(--border));
    overflow: hidden;
}

.partner-logo img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    border-radius: 50%;
}

.partner-details {
    flex: 1;
}

.partner-name-wrapper {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    margin-bottom: 0.5rem;
}

.partner-name {
    font-size: 1.25rem;
    font-weight: 600;
    color: hsl(var(--foreground));
}

/* Premium/Exclusive Badges */
.badge {
    display: inline-flex;
    align-items: center;
    gap: 0.25rem;
    padding: 0.25rem 0.75rem;
    border-radius: 9999px;
    font-size: 0.75rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.05em;
}

.badge-premium {
    background: linear-gradient(135deg, hsl(var(--premium-gold)), hsl(45 96% 45%));
    color: hsl(var(--primary-foreground));
    box-shadow: 0 2px 8px hsl(var(--premium-gold) / 0.3);
}

.badge-exclusive {
    background: linear-gradient(135deg, hsl(var(--exclusive-diamond)), hsl(210 100% 70%));
    color: hsl(var(--primary-foreground));
    box-shadow: 0 2px 8px hsl(var(--exclusive-diamond) / 0.3);
}

.partner-meta {
    display: flex;
    align-items: center;
    gap: 1rem;
    flex-wrap: wrap;
    color: hsl(var(--muted-foreground));
    font-size: 0.875rem;
}

.rating {
    display: flex;
    align-items: center;
    gap: 0.25rem;
    color: hsl(var(--primary));
}

.location {
    display: flex;
    align-items: center;
    gap: 0.25rem;
}

/* Select Checkbox */
.select-checkbox {
    width: 1.5rem;
    height: 1.5rem;
    border: 2px solid hsl(var(--border));
    border-radius: 0.25rem;
    background: transparent;
    cursor: pointer;
    position: relative;
    flex-shrink: 0;
    transition: all 0.2s ease;
    appearance: none;
    -webkit-appearance: none;
    -moz-appearance: none;
}

.select-checkbox:checked {
    background: hsl(var(--primary));
    border-color: hsl(var(--primary));
}

.select-checkbox:checked::after {
    content: '✓';
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    color: hsl(var(--primary-foreground));
    font-size: 1rem;
    font-weight: bold;
}

/* Footer Actions */
.footer-actions {
    margin-top: 3rem;
    padding-top: 2rem;
    border-top: 1px solid hsl(var(--border));
    display: flex;
    gap: 1rem;
    justify-content: center;
}

/* Button Styles */
.btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
    padding: 0.75rem 2rem;
    font-size: 1rem;
    font-weight: 600;
    border-radius: 0.5rem;
    transition: all 0.2s;
    cursor: pointer;
    border: none;
}

.btn-primary {
    background: linear-gradient(135deg, hsl(var(--brand-yellow)), hsl(var(--brand-green)));
    color: hsl(var(--primary-foreground));
    box-shadow: 0 4px 12px hsl(220 40% 4% / 0.4);
}

.btn-primary:hover {
    background: linear-gradient(135deg, hsl(60 96% 82%), hsl(186 80% 22%));
    transform: translateY(-2px);
    box-shadow: 0 6px 16px hsl(220 40% 4% / 0.5);
}

.btn-secondary {
    background: hsl(var(--secondary));
    color: hsl(var(--foreground));
    border: 1px solid hsl(var(--border));
}

.btn-secondary:hover {
    background: hsl(var(--secondary) / 0.8);
    border-color: hsl(var(--primary) / 0.5);
}

/* VIP Button Style - when dealers are selected */
.btn-vip {
    background: linear-gradient(135deg, #ffd700, #ff8c00) !important;
    color: #1a1a1a !important;
    box-shadow: 0 4px 15px rgba(255, 215, 0, 0.4) !important;
    animation: vipBtnPulse 2s ease-in-out infinite;
}

.btn-vip:hover {
    background: linear-gradient(135deg, #ffdf00, #ff9500) !important;
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(255, 215, 0, 0.5) !important;
}

@keyframes vipBtnPulse {
    0%, 100% { box-shadow: 0 4px 15px rgba(255, 215, 0, 0.4); }
    50% { box-shadow: 0 4px 25px rgba(255, 215, 0, 0.6); }
}

.sr-only {
    position: absolute;
    width: 1px;
    height: 1px;
    padding: 0;
    margin: -1px;
    overflow: hidden;
    clip: rect(0, 0, 0, 0);
    white-space: nowrap;
    border-width: 0;
}

/* Success Modal/Popup */
.success-modal-overlay {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.8);
    backdrop-filter: blur(4px);
    z-index: 10000;
    align-items: center;
    justify-content: center;
    padding: 1rem;
    overflow-y: auto;
}

.success-modal-overlay.active {
    display: flex;
}

.success-modal {
    background: hsl(var(--card));
    border: 1px solid hsl(var(--border));
    border-radius: 1rem;
    max-width: 500px;
    width: 100%;
    position: relative;
    box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
    animation: modalFadeIn 0.3s ease;
    padding: 2rem;
}

@keyframes modalFadeIn {
    from {
        opacity: 0;
        transform: scale(0.95) translateY(-20px);
    }
    to {
        opacity: 1;
        transform: scale(1) translateY(0);
    }
}

.success-icon {
    width: 64px;
    height: 64px;
    border-radius: 50%;
    background: linear-gradient(135deg, hsl(var(--brand-green)), hsl(186 80% 25%));
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 1.5rem;
    font-size: 2rem;
}

.success-title {
    font-size: 1.5rem;
    font-weight: 700;
    color: hsl(var(--foreground));
    text-align: center;
    margin-bottom: 1rem;
}

.success-message {
    color: hsl(var(--muted-foreground));
    text-align: center;
    line-height: 1.6;
    margin-bottom: 1.5rem;
}

.success-info {
    background: hsl(var(--secondary));
    border: 1px solid hsl(var(--border));
    border-radius: 0.75rem;
    padding: 1.5rem;
    margin-bottom: 1.5rem;
}

.success-info p {
    margin: 0.75rem 0;
    color: hsl(var(--foreground));
    font-size: 0.9375rem;
    line-height: 1.6;
}

.success-info p:first-child {
    margin-top: 0;
}

.success-info p:last-child {
    margin-bottom: 0;
}

.success-actions {
    display: flex;
    gap: 1rem;
    flex-direction: column;
}

.success-actions .btn {
    width: 100%;
    justify-content: center;
}

/* Partner Details Modal */
.partner-details-modal {
    background: hsl(var(--card));
    border: 1px solid hsl(var(--border));
    border-radius: 1rem;
    max-width: 700px;
    width: 100%;
    position: relative;
    box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
    animation: modalFadeIn 0.3s ease;
    padding: 2rem;
    max-height: 90vh;
    overflow-y: auto;
}

.modal-close-btn {
    position: absolute;
    top: 1rem;
    right: 1rem;
    width: 2.5rem;
    height: 2.5rem;
    border-radius: 50%;
    background: hsl(var(--secondary));
    border: 1px solid hsl(var(--border));
    color: hsl(var(--foreground));
    font-size: 1.5rem;
    line-height: 1;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.2s;
    z-index: 10;
}

.modal-close-btn:hover {
    background: hsl(var(--secondary) / 0.8);
    border-color: hsl(var(--primary) / 0.5);
    transform: scale(1.1);
}

.partner-details-content {
    display: flex;
    flex-direction: column;
    gap: 1.5rem;
}

.partner-details-header {
    display: flex;
    align-items: center;
    gap: 1.5rem;
    padding-bottom: 1.5rem;
    border-bottom: 1px solid hsl(var(--border));
}

.partner-details-logo {
    flex-shrink: 0;
}

.partner-details-logo img {
    width: 120px;
    height: 120px;
    border-radius: 50%;
    object-fit: cover;
    border: 2px solid hsl(var(--border));
}

.partner-details-title {
    flex: 1;
}

.partner-details-name {
    font-size: 1.75rem;
    font-weight: 700;
    color: hsl(var(--foreground));
    margin: 0 0 0.75rem 0;
}

.partner-name-link {
    color: inherit;
    text-decoration: none;
    cursor: pointer;
    transition: all 0.2s ease;
    display: inline-block;
}

.partner-name-link:hover {
    color: hsl(var(--primary)) !important;
    text-decoration: underline;
}

.partner-details-body {
    padding: 1rem 0;
}

.partner-details-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 1.5rem;
}

.detail-item {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
}

.detail-item label {
    font-size: 0.75rem;
    font-weight: 600;
    color: hsl(var(--muted-foreground));
    text-transform: uppercase;
    letter-spacing: 0.05em;
}

.detail-item p {
    font-size: 0.9375rem;
    color: hsl(var(--foreground));
    margin: 0;
    padding: 0.5rem 0;
}

.chat-locked {
    color: hsl(var(--muted-foreground)) !important;
    font-style: italic;
}

/* Search & Filter Section */
.search-filter-section {
    background: hsl(var(--card));
    border: 1px solid hsl(var(--border));
    border-radius: 0.75rem;
    padding: 1.5rem;
}

.search-filter-container {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}

.search-filter-form {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}

.filter-input-group {
    display: flex;
    gap: 0.75rem;
    flex: 1;
}

.filter-input {
    flex: 1;
    padding: 0.875rem 1rem;
    background: hsl(var(--secondary));
    border: 1px solid hsl(var(--border));
    border-radius: 0.5rem;
    color: hsl(var(--foreground));
    font-size: 0.9375rem;
    transition: all 0.2s;
}

.filter-input:focus {
    outline: none;
    border-color: hsl(var(--primary));
    box-shadow: 0 0 0 3px hsl(var(--primary) / 0.1);
}

.filter-actions {
    display: flex;
    gap: 0.75rem;
    flex-wrap: wrap;
}

.btn-search {
    padding: 0.875rem 1.5rem;
    white-space: nowrap;
}

.btn-near-me {
    padding: 0.875rem 1.5rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
    white-space: nowrap;
}

.btn-clear {
    padding: 0.875rem 1.5rem;
    white-space: nowrap;
}

.filter-status {
    padding: 0.75rem 1rem;
    background: hsl(var(--primary) / 0.1);
    border: 1px solid hsl(var(--primary) / 0.3);
    border-radius: 0.5rem;
    color: hsl(var(--foreground));
    font-size: 0.875rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.filter-status::before {
    content: '';
    display: inline-block;
    width: 16px;
    height: 16px;
    margin-right: 0.5rem;
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Ccircle cx='11' cy='11' r='8'%3E%3C/circle%3E%3Cpath d='m21 21-4.35-4.35'%3E%3C/path%3E%3C/svg%3E");
    background-repeat: no-repeat;
    background-position: center;
    background-size: contain;
    vertical-align: middle;
}

.partner-card.hidden {
    display: none;
}

@media (min-width: 768px) {
    .search-filter-form {
        flex-direction: row;
        align-items: center;
    }
    
    .filter-input-group {
        flex: 1;
    }
    
    .filter-actions {
        flex: 0 0 auto;
    }
}

.partner-details-footer {
    padding-top: 1.5rem;
    border-top: 1px solid hsl(var(--border));
    display: flex;
    justify-content: flex-end;
}

@media (max-width: 768px) {
    .partner-card {
        flex-direction: column;
        align-items: flex-start;
    }
    
    .partner-info {
        width: 100%;
    }
    
    .footer-actions {
        flex-direction: column;
    }
    
    .btn {
        width: 100%;
    }
    
    .success-modal {
        padding: 1.5rem;
        margin: 1rem;
    }
    
    .partner-details-modal {
        padding: 1.5rem;
        margin: 1rem;
        max-width: calc(100% - 2rem);
    }
    
    .partner-details-header {
        flex-direction: column;
        text-align: center;
    }
    
    .partner-details-grid {
        grid-template-columns: 1fr;
        gap: 1.25rem;
    }
    
    .partner-details-logo img {
        width: 100px;
        height: 100px;
    }
}
</style>

<section class="py-20">
    <div class="container max-w-6xl">
        <?php
        // Get request type early for page header
        $header_request_id = isset($_GET['request_id']) ? sanitize_text_field($_GET['request_id']) : '';
        $header_form_data = !empty($header_request_id) ? get_transient('car_accessories_request_' . $header_request_id) : null;
        $header_request_type = isset($header_form_data['request_type']) ? $header_form_data['request_type'] : '';
        $header_is_sell_car = ($header_request_type === 'sell_car');
        ?>
        <div class="text-center mb-12">
            <h1 class="text-3xl font-bold text-foreground mb-4">
                <?php echo $header_is_sell_car ? 'Select Dealerships' : 'Select Premium Partners'; ?>
            </h1>
            <?php if ($header_is_sell_car) : ?>
            <p class="text-muted-foreground text-lg mb-4">
                Your car listing will be sent to all dealerships. Select specific dealers for VIP priority (optional).
            </p>
            <div style="max-width: 600px; margin: 0 auto; background: hsl(var(--primary) / 0.1); border: 1px solid hsl(var(--primary) / 0.3); border-radius: 0.75rem; padding: 1rem; text-align: left;">
                <p style="color: hsl(var(--foreground)); font-size: 0.9rem; margin: 0; line-height: 1.6;">
                    <strong>💡 How it works:</strong><br>
                    ✅ Click "Send to All Dealers" - your car goes to everyone<br>
                    ⭐ Select dealers with checkbox - they get VIP priority and see your request first
                </p>
            </div>
            <?php else : ?>
            <p class="text-muted-foreground text-lg">
                Choose your preferred partners or send the request to all eligible partners
            </p>
            <?php endif; ?>
        </div>

        <!-- Search & Filter Section -->
        <div class="search-filter-section mb-8">
            <div class="search-filter-container">
                <div class="search-filter-form">
                    <div class="filter-input-group">
                        <input 
                            type="text" 
                            id="locationSearch" 
                            class="filter-input" 
                            placeholder="<?php echo $header_is_sell_car ? 'Search dealers by name or location...' : 'Search by name, location, or email...'; ?>"
                            autocomplete="off"
                        >
                        <button type="button" id="searchLocationBtn" class="btn btn-primary btn-search">
                            Search
                        </button>
                    </div>
                    <div class="filter-actions">
                        <button type="button" id="nearMeBtn" class="btn btn-secondary btn-near-me">
                            <span><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg></span> Near Me
                        </button>
                        <button type="button" id="clearFilterBtn" class="btn btn-secondary btn-clear" style="display: none;">
                            Clear Filter
                        </button>
                    </div>
                </div>
                <div id="filterStatus" class="filter-status" style="display: none;">
                    <span id="filterStatusText"></span>
                </div>
            </div>
        </div>

        <?php
        // Get request ID from URL
        $request_id = isset($_GET['request_id']) ? sanitize_text_field($_GET['request_id']) : '';
        if (empty($request_id)) {
            echo '<div class="text-center"><p class="text-muted-foreground">Invalid request. Please submit the form again.</p></div>';
            get_footer();
            exit;
        }

        // Get form data from transient
        $form_data = get_transient('car_accessories_request_' . $request_id);
        if (!$form_data) {
            echo '<div class="text-center"><p class="text-muted-foreground">Request expired. Please submit the form again.</p></div>';
            get_footer();
            exit;
        }

        // Check request type - if sell_car, only show Car Dealership partners
        $request_type = isset($form_data['request_type']) ? $form_data['request_type'] : '';
        $is_sell_car_request = ($request_type === 'sell_car');

        // For Sell Car requests - Show ALL Car Dealership partners (not just premium/exclusive)
        if ($is_sell_car_request) {
            $args = array(
                'role' => 'partner',
                'number' => -1, // Get all partners
                'orderby' => 'display_name',
                'order' => 'ASC',
                'meta_query' => array(
                    array(
                        'key' => 'partner_type',
                        'value' => 'car_dealership',
                        'compare' => '='
                    )
                )
            );
            $partners = get_users($args);
            
            // If no car dealership partners found, get ALL partners as fallback
            if (empty($partners)) {
                $partners = get_users(array(
                    'role' => 'partner',
                    'number' => -1,
                    'orderby' => 'display_name',
                    'order' => 'ASC'
                ));
            }
        } else {
            // For other service requests - Get Premium/Exclusive partners first
            $args = array(
                'role' => 'partner',
                'number' => -1, // Get all partners
                'meta_query' => array(
                    'relation' => 'AND',
                    array(
                        'relation' => 'OR',
                        array(
                            'key' => 'partner_tier',
                            'value' => 'premium',
                            'compare' => '='
                        ),
                        array(
                            'key' => 'partner_tier',
                            'value' => 'exclusive',
                            'compare' => '='
                        )
                    )
                ),
                'orderby' => 'meta_value',
                'meta_key' => 'partner_tier',
                'order' => 'DESC' // Exclusive first, then premium
            );
            
            $partners = get_users($args);
            
            // If no premium/exclusive partners found, get all partners as fallback
            if (empty($partners)) {
                $partners = get_users(array(
                    'role' => 'partner',
                    'number' => -1,
                    'orderby' => 'display_name',
                    'order' => 'ASC'
                ));
            }
        }
        ?>

        <form id="select-partner-form" method="post" action="<?php echo esc_url(home_url('/partner-quotation')); ?>" onsubmit="return handleFormSubmit(event);">
            <?php wp_nonce_field('select_partner', 'select_partner_nonce'); ?>
            <input type="hidden" name="request_id" value="<?php echo esc_attr($request_id); ?>">
            
            <div class="space-y-4" id="partnersContainer">
                <?php if (empty($partners)) : ?>
                    <div class="partner-card">
                        <p class="text-muted-foreground">
                            <?php echo $is_sell_car_request 
                                ? 'No car dealerships available at the moment. Please try again later.' 
                                : 'No partners available at the moment. Please try again later.'; ?>
                        </p>
                    </div>
                <?php else : ?>
                    <?php foreach ($partners as $partner) : 
                        $partner_id = $partner->ID;
                        
                        // Get business name or fallback to display name
                        $business_name = get_user_meta($partner_id, 'business_name', true);
                        if (empty($business_name)) {
                            $business_name = $partner->display_name ?: $partner->user_login;
                        }
                        
                        // Get partner tier (premium/exclusive/normal)
                        $partner_tier = get_user_meta($partner_id, 'partner_tier', true);
                        if (empty($partner_tier)) {
                            // Default to premium if not set
                            $partner_tier = 'premium';
                        }
                        
                        // Get rating - calculate from reviews dynamically
                        if (function_exists('wheelfy_get_partner_dynamic_rating')) {
                            $rating = wheelfy_get_partner_dynamic_rating($partner_id);
                            // If no reviews, fallback to stored rating or 0.0
                            if ($rating == 0.0) {
                                $rating = get_user_meta($partner_id, 'partner_rating', true);
                                if (empty($rating) || $rating === '0') {
                                    $rating = 0.0; // Show 0.0 if no reviews instead of fake 4.5
                                } else {
                                    $rating = floatval($rating);
                                }
                            }
                        } else {
                            // Fallback if function doesn't exist
                            $rating = get_user_meta($partner_id, 'partner_rating', true);
                            if (empty($rating) || $rating === '0') {
                                $rating = 0.0;
                            } else {
                                $rating = floatval($rating);
                            }
                        }
                        
                        // Get location
                        $location = get_user_meta($partner_id, 'user_location', true);
                        if (empty($location)) {
                            $location = 'Location not set';
                        }
                        
                        // Extract city from location (if full address like "City, Country")
                        $city = $location;
                        if (strpos($location, ',') !== false) {
                            $parts = explode(',', $location);
                            $city = trim($parts[0]);
                        }
                        
                        // Get partner logo - check multiple meta keys for compatibility
                        $logo_url = '';
                        
                        // First, try partner_logo_id (most specific)
                        $logo_id = get_user_meta($partner_id, 'partner_logo_id', true);
                        
                        // If not found, try profile_image_id (alternative key)
                        if (empty($logo_id) || !is_numeric($logo_id)) {
                            $logo_id = get_user_meta($partner_id, 'profile_image_id', true);
                        }
                        
                        // If we have a valid attachment ID, get the image URL
                        if ($logo_id && is_numeric($logo_id)) {
                            $logo_url = wp_get_attachment_image_url($logo_id, 'thumbnail');
                            // If thumbnail size doesn't exist, try medium or full
                            if (!$logo_url) {
                                $logo_url = wp_get_attachment_image_url($logo_id, 'medium');
                            }
                            if (!$logo_url) {
                                $logo_url = wp_get_attachment_image_url($logo_id, 'full');
                            }
                        }
                        
                        // Fallback to Gravatar/WordPress avatar if no custom logo
                        if (empty($logo_url)) {
                            $logo_url = get_avatar_url($partner_id, array(
                                'size' => 64,
                                'default' => 'mm',
                                'rating' => 'g'
                            ));
                        }
                    ?>
                    <div class="partner-card" data-partner-id="<?php echo esc_attr($partner_id); ?>" data-partner-location="<?php echo esc_attr(strtolower($full_location)); ?>" data-partner-data='<?php 
                        // Get all partner data for the modal
                        $partner_profession = get_user_meta($partner_id, 'partner_profession', true);
                        $partner_experience = get_user_meta($partner_id, 'partner_experience', true);
                        $partner_price = get_user_meta($partner_id, 'partner_price', true);
                        $partner_price_currency = get_user_meta($partner_id, 'partner_price_currency', true) ?: 'USD';
                        $partner_email = $partner->user_email;
                        $partner_phone = get_user_meta($partner_id, 'phone_number', true);
                        $full_location = get_user_meta($partner_id, 'user_location', true);
                        
                        // Format price
                        $price_display = 'Not set';
                        if ($partner_price) {
                            $currency_symbols = array('USD' => '$', 'HUF' => 'Ft');
                            $symbol = isset($currency_symbols[$partner_price_currency]) ? $currency_symbols[$partner_price_currency] : '$';
                            $price_display = number_format(floatval($partner_price), 2) . ' ' . $symbol . ' ' . $partner_price_currency;
                        }
                        
                        $partner_data = array(
                            'id' => $partner_id,
                            'name' => $business_name,
                            'logo' => $logo_url,
                            'profession' => $partner_profession ?: 'Not set',
                            'experience' => $partner_experience ?: 'Not set',
                            'rating' => number_format($rating, 1),
                            'price' => $price_display,
                            'location' => $full_location ?: 'Location not set',
                            'email' => $partner_email,
                            'phone' => $partner_phone ?: 'Not set',
                            'tier' => $partner_tier
                        );
                        echo esc_attr(json_encode($partner_data));
                    ?>'>
                        <div class="partner-info">
                            <div class="partner-logo">
                                <img 
                                    src="<?php echo esc_url($logo_url); ?>" 
                                    alt="<?php echo esc_attr($business_name); ?>"
                                    loading="lazy"
                                    width="64"
                                    height="64"
                                    onerror="this.onerror=null; this.src='<?php echo esc_url(get_avatar_url($partner_id, array('size' => 64, 'default' => 'mm'))); ?>';"
                                >
                            </div>
                            <div class="partner-details">
                                <div class="partner-name-wrapper">
                                    <h3 class="partner-name"><?php echo esc_html($business_name); ?></h3>
                                    <?php if ($partner_tier === 'premium') : ?>
                                        <span class="badge badge-premium">
                                            ⭐ Premium
                                        </span>
                                    <?php elseif ($partner_tier === 'exclusive') : ?>
                                        <span class="badge badge-exclusive">
                                            💎 Exclusive
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="partner-meta">
                                    <div class="rating">
                                        <span>⭐</span>
                                        <span><?php echo number_format($rating, 1); ?></span>
                                    </div>
                                    <span>•</span>
                                    <div class="location">
                                        <span><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg></span>
                                        <span><?php echo esc_html($city); ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div>
                            <input 
                                type="checkbox" 
                                name="selected_partners[]" 
                                value="<?php echo esc_attr($partner_id); ?>" 
                                class="select-checkbox partner-checkbox"
                                id="partner-<?php echo esc_attr($partner_id); ?>"
                            >
                            <label for="partner-<?php echo esc_attr($partner_id); ?>" class="sr-only">Select <?php echo esc_html($business_name); ?></label>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <div class="footer-actions">
                <?php if ($is_sell_car_request) : ?>
                <!-- Sell Your Car - Single smart button with VIP functionality -->
                <button type="submit" name="action" value="smart" class="btn btn-primary" id="smartSendBtn" data-original-text="Send to All Dealers">
                    Send to All Dealers
                </button>
                <?php else : ?>
                <!-- Other forms - Original two button layout -->
                <button type="submit" name="action" value="selected" class="btn btn-primary" id="sendSelectedBtn">
                    Send Request
                </button>
                <button type="submit" name="action" value="all" class="btn btn-secondary" id="sendAllBtn">
                    Skip &amp; Send to All
                </button>
                <?php endif; ?>
            </div>
        </form>
    </div>
</section>

<!-- Success Modal -->
<div id="successModal" class="success-modal-overlay">
    <div class="success-modal">
        <div class="success-icon" id="successIcon">
            ✅
        </div>
        <h2 class="success-title" id="successTitle">Request Sent Successfully!</h2>
        <div class="success-message" id="successMessage">
            Your service request has been sent to the selected partner.
        </div>
        <div class="success-info" id="successInfo">
            <p><strong>To track your request, receive responses, and continue the conversation:</strong></p>
            <p><strong>If you already have an account:</strong><br>
            👉 Go to your Dashboard to view updates and messages.</p>
            <p><strong>If you don't have an account yet:</strong><br>
            👉 Create a free account or log in to manage your request and communicate with the partner.</p>
        </div>
        <div class="success-actions">
            <?php if (is_user_logged_in()) : ?>
                <a href="<?php echo esc_url(home_url('/customer-dashboard')); ?>" class="btn btn-primary">
                    Go to Dashboard
                </a>
            <?php else : ?>
                <a href="<?php echo esc_url(home_url('/login')); ?>" class="btn btn-primary">
                    Go to Dashboard or Login
                </a>
                <a href="<?php echo esc_url(home_url('/register')); ?>" class="btn btn-secondary">
                    Register Account
                </a>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Info Modal - Not needed anymore since smart button handles both cases -->
<div id="validationModal" class="success-modal-overlay" style="display: none;">
    <!-- Kept for backwards compatibility but not used -->
</div>

<!-- Partner Details Modal -->
<div id="partnerDetailsModal" class="success-modal-overlay">
    <div class="partner-details-modal">
        <button class="modal-close-btn" onclick="closePartnerModal()" aria-label="Close">×</button>
        <div class="partner-details-content">
            <div class="partner-details-header">
                <div class="partner-details-logo">
                    <img id="modalPartnerLogo" src="" alt="" width="120" height="120">
                </div>
                <div class="partner-details-title">
                    <h2 class="partner-details-name">
                        <a id="modalPartnerName" href="#" class="partner-name-link" style="color: inherit; text-decoration: none; cursor: pointer; transition: color 0.2s;" onmouseover="this.style.color='hsl(var(--primary))'" onmouseout="this.style.color='inherit'"></a>
                    </h2>
                    <span id="modalPartnerBadge" class="badge"></span>
                </div>
            </div>
            <div class="partner-details-body">
                <div class="partner-details-grid">
                    <div class="detail-item">
                        <label>Profession</label>
                        <p id="modalPartnerProfession">-</p>
                    </div>
                    <div class="detail-item">
                        <label>Experience</label>
                        <p id="modalPartnerExperience">-</p>
                    </div>
                    <div class="detail-item">
                        <label>Rating</label>
                        <p id="modalPartnerRating">-</p>
                    </div>
                    <div class="detail-item">
                        <label>Price</label>
                        <p id="modalPartnerPrice">-</p>
                    </div>
                    <div class="detail-item">
                        <label>Location</label>
                        <p id="modalPartnerLocation">-</p>
                    </div>
                    <div class="detail-item">
                        <label>Email</label>
                        <p class="chat-locked">🔒 Locked - Available after selection</p>
                    </div>
                    <div class="detail-item">
                        <label>Phone</label>
                        <p class="chat-locked">🔒 Locked - Available after selection</p>
                    </div>
                    <div class="detail-item">
                        <label>Chat</label>
                        <p class="chat-locked">🔒 Locked - Available after selection</p>
                    </div>
                </div>
            </div>
            <div class="partner-details-footer">
                <button type="button" class="btn btn-secondary" onclick="closePartnerModal()">Close</button>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const partnerCards = document.querySelectorAll('.partner-card');
    const checkboxes = document.querySelectorAll('.partner-checkbox');
    const locationSearch = document.getElementById('locationSearch');
    const searchLocationBtn = document.getElementById('searchLocationBtn');
    const nearMeBtn = document.getElementById('nearMeBtn');
    const clearFilterBtn = document.getElementById('clearFilterBtn');
    const filterStatus = document.getElementById('filterStatus');
    const filterStatusText = document.getElementById('filterStatusText');
    const partnersContainer = document.getElementById('partnersContainer');
    
    let currentFilter = null;
    
    // Open partner details modal on card click (but not checkbox)
    partnerCards.forEach(card => {
        card.addEventListener('click', function(e) {
            // Don't open modal if clicking the checkbox or label directly
            if (e.target.type === 'checkbox' || e.target.tagName === 'LABEL' || e.target.closest('label')) {
                return;
            }
            
            // Get partner data from data attribute
            const partnerDataStr = card.getAttribute('data-partner-data');
            if (partnerDataStr) {
                try {
                    const partnerData = JSON.parse(partnerDataStr);
                    openPartnerModal(partnerData);
                } catch (error) {
                    console.error('Error parsing partner data:', error);
                }
            }
        });
    });
    
    // Toggle checkbox when checkbox is clicked directly
    checkboxes.forEach(checkbox => {
        checkbox.addEventListener('click', function(e) {
            e.stopPropagation(); // Prevent card click event
        });
        
        checkbox.addEventListener('change', function() {
            const card = this.closest('.partner-card');
            updateCardState(card, this.checked);
            updateSmartButtonText(); // Update button text based on selection
        });
    });
    
    // Smart Button Text Update based on selection (only for Sell Car)
    function updateSmartButtonText() {
        const isSellCar = <?php echo json_encode($header_is_sell_car); ?>;
        
        if (isSellCar) {
            // Sell Car - VIP selection functionality
            const smartBtn = document.getElementById('smartSendBtn');
            if (!smartBtn) return;
            
            const selectedCount = document.querySelectorAll('.partner-checkbox:checked').length;
            
            if (selectedCount > 0) {
                // Some dealers selected - they will get VIP, others normal
                smartBtn.innerHTML = `Send to All Dealers (${selectedCount} VIP)`;
                smartBtn.classList.add('btn-vip');
            } else {
                // No selection - will send to all as normal
                smartBtn.innerHTML = 'Send to All Dealers';
                smartBtn.classList.remove('btn-vip');
            }
        }
        // For other forms - no dynamic button update needed (original two-button behavior)
    }
    
    // Initialize button text on page load
    updateSmartButtonText();
    
    function updateCardState(card, isSelected) {
        if (isSelected) {
            card.classList.add('selected');
        } else {
            card.classList.remove('selected');
        }
    }
    
    // Filter partners by search term (name, location, etc.)
    function filterPartnersByLocation(searchTerm) {
        if (!searchTerm || searchTerm.trim() === '') {
            showAllPartners();
            return;
        }
        
        const searchLower = searchTerm.toLowerCase().trim();
        let visibleCount = 0;
        let totalCount = partnerCards.length;
        
        partnerCards.forEach(card => {
            let matches = false;
            
            // Search in location
            const partnerLocation = card.getAttribute('data-partner-location') || '';
            if (partnerLocation.includes(searchLower)) {
                matches = true;
            }
            
            // Search in partner data (name, email, etc.)
            const partnerDataStr = card.getAttribute('data-partner-data');
            if (partnerDataStr && !matches) {
                try {
                    const partnerData = JSON.parse(partnerDataStr);
                    const partnerName = (partnerData.name || '').toLowerCase();
                    const partnerEmail = (partnerData.email || '').toLowerCase();
                    const partnerLocationFull = (partnerData.location || '').toLowerCase();
                    
                    if (partnerName.includes(searchLower) || 
                        partnerEmail.includes(searchLower) || 
                        partnerLocationFull.includes(searchLower)) {
                        matches = true;
                    }
                } catch (e) {
                    // If JSON parsing fails, continue with location search only
                }
            }
            
            // Search in visible text (partner name in the card)
            if (!matches) {
                const partnerNameElement = card.querySelector('.partner-name');
                if (partnerNameElement) {
                    const nameText = partnerNameElement.textContent.toLowerCase();
                    if (nameText.includes(searchLower)) {
                        matches = true;
                    }
                }
            }
            
            if (matches) {
                card.classList.remove('hidden');
                visibleCount++;
            } else {
                card.classList.add('hidden');
            }
        });
        
        if (visibleCount === 0) {
            showNoResults();
        } else {
            showFilterStatus(visibleCount, totalCount, searchTerm);
        }
        
        currentFilter = searchTerm;
        clearFilterBtn.style.display = 'block';
    }
    
    // Show all partners
    function showAllPartners() {
        partnerCards.forEach(card => {
            card.classList.remove('hidden');
        });
        filterStatus.style.display = 'none';
        clearFilterBtn.style.display = 'none';
        currentFilter = null;
    }
    
    // Show no results message
    function showNoResults() {
        filterStatusText.textContent = 'No partners found matching your search.';
        filterStatus.style.display = 'block';
        filterStatus.style.background = 'hsl(var(--secondary))';
        filterStatus.style.borderColor = 'hsl(var(--border))';
    }
    
    // Show filter status
    function showFilterStatus(visible, total, searchTerm) {
        filterStatusText.textContent = `Showing ${visible} of ${total} partners matching "${searchTerm}"`;
        filterStatus.style.display = 'block';
        filterStatus.style.background = 'hsl(var(--primary) / 0.1)';
        filterStatus.style.borderColor = 'hsl(var(--primary) / 0.3)';
    }
    
    // Search by name, location, or email input
    if (searchLocationBtn && locationSearch) {
        let searchTimeout;
        
        // Real-time search as user types (with debounce)
        locationSearch.addEventListener('input', function() {
            clearTimeout(searchTimeout);
            const searchTerm = this.value.trim();
            
            searchTimeout = setTimeout(function() {
                if (searchTerm) {
                    filterPartnersByLocation(searchTerm);
                } else {
                    showAllPartners();
                }
            }, 300); // Wait 300ms after user stops typing
        });
        
        // Search button click
        searchLocationBtn.addEventListener('click', function() {
            const searchTerm = locationSearch.value.trim();
            if (searchTerm) {
                filterPartnersByLocation(searchTerm);
            } else {
                showAllPartners();
            }
        });
        
        // Allow Enter key to trigger search
        locationSearch.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                clearTimeout(searchTimeout);
                const searchTerm = this.value.trim();
                if (searchTerm) {
                    filterPartnersByLocation(searchTerm);
                } else {
                    showAllPartners();
                }
            }
        });
    }
    
    // Near Me button - Get user location
    if (nearMeBtn) {
        nearMeBtn.addEventListener('click', function() {
            if (!navigator.geolocation) {
                alert('Geolocation is not supported by your browser.');
                return;
            }
            
            nearMeBtn.disabled = true;
            nearMeBtn.innerHTML = '<span><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg></span> Getting location...';
            
            navigator.geolocation.getCurrentPosition(
                function(position) {
                    const lat = position.coords.latitude;
                    const lon = position.coords.longitude;
                    
                    // Use reverse geocoding to get location name
                    // For now, we'll use a simple approach - you can integrate with Google Maps Geocoding API
                    // For this example, we'll search by coordinates or use a geocoding service
                    
                    // Simple approach: Use coordinates to search (you might want to use a geocoding API)
                    fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lon}`)
                        .then(response => response.json())
                        .then(data => {
                            const city = data.address?.city || data.address?.town || data.address?.village || data.address?.county || '';
                            const country = data.address?.country || '';
                            const locationName = city ? (country ? `${city}, ${country}` : city) : 'Your Location';
                            
                            locationSearch.value = locationName;
                            filterPartnersByLocation(locationName);
                            nearMeBtn.disabled = false;
                            nearMeBtn.innerHTML = '<span><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg></span> Near Me';
                        })
                        .catch(error => {
                            console.error('Geocoding error:', error);
                            alert('Could not determine your location. Please enter it manually.');
                            nearMeBtn.disabled = false;
                            nearMeBtn.innerHTML = '<span><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg></span> Near Me';
                        });
                },
                function(error) {
                    alert('Could not get your location. Please allow location access or enter it manually.');
                    nearMeBtn.disabled = false;
                    nearMeBtn.innerHTML = '<span><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg></span> Near Me';
                }
            );
        });
    }
    
    // Clear filter button
    if (clearFilterBtn) {
        clearFilterBtn.addEventListener('click', function() {
            locationSearch.value = '';
            showAllPartners();
        });
    }
});

// Open partner details modal
function openPartnerModal(partnerData) {
    const modal = document.getElementById('partnerDetailsModal');
    if (!modal) return;
    
    // Populate modal with partner data
    document.getElementById('modalPartnerLogo').src = partnerData.logo || '';
    document.getElementById('modalPartnerLogo').alt = partnerData.name || '';
    
    // Set partner name as clickable link
    const partnerNameLink = document.getElementById('modalPartnerName');
    if (partnerNameLink && partnerData.id) {
        partnerNameLink.textContent = partnerData.name || 'Unknown';
        partnerNameLink.href = '<?php echo esc_js(home_url('/partner/')); ?>' + partnerData.id + '/';
        partnerNameLink.title = 'View ' + (partnerData.name || 'Partner') + '\'s Profile';
    }
    
    // Set badge
    const badgeEl = document.getElementById('modalPartnerBadge');
    badgeEl.className = 'badge';
    badgeEl.textContent = '';
    if (partnerData.tier === 'premium') {
        badgeEl.classList.add('badge-premium');
        badgeEl.textContent = '⭐ Premium';
    } else if (partnerData.tier === 'exclusive') {
        badgeEl.classList.add('badge-exclusive');
        badgeEl.textContent = '💎 Exclusive';
    }
    
    // Set details
    document.getElementById('modalPartnerProfession').textContent = partnerData.profession || 'Not set';
    document.getElementById('modalPartnerExperience').textContent = partnerData.experience || 'Not set';
    document.getElementById('modalPartnerRating').textContent = '⭐ ' + (partnerData.rating || '0.0');
    document.getElementById('modalPartnerPrice').textContent = partnerData.price || 'Not set';
    document.getElementById('modalPartnerLocation').textContent = partnerData.location || 'Not set';
    // Email and Phone are locked, no need to set them
    
    // Show modal
    modal.classList.add('active');
}

// Close partner details modal
function closePartnerModal() {
    const modal = document.getElementById('partnerDetailsModal');
    if (modal) {
        modal.classList.remove('active');
    }
}

// Handle form submission and show appropriate modal
function handleFormSubmit(event) {
    event.preventDefault();
    
    const form = event.target;
    const formData = new FormData(form);
    const isSellCarRequest = <?php echo json_encode($header_is_sell_car); ?>;
    
    // Get the clicked button's action value
    const clickedButton = event.submitter;
    const action = clickedButton ? clickedButton.value : 'all';
    
    let selectedIds = [];
    
    if (isSellCarRequest) {
        // For Sell Car: Send to ALL dealers with VIP/Priority for selected ones
        formData.set('action', 'all_with_priority');
        
        // Get selected partner IDs for VIP marking
        const selectedPartners = form.querySelectorAll('input[name="selected_partners[]"]:checked');
        selectedIds = Array.from(selectedPartners).map(cb => cb.value);
        
        // Add selected IDs as priority partners
        formData.set('priority_partner_ids', JSON.stringify(selectedIds));
    } else {
        // For other forms: Original two-button behavior
        if (action === 'selected') {
            // Send to selected partners only
            const selectedPartners = form.querySelectorAll('input[name="selected_partners[]"]:checked');
            if (selectedPartners.length === 0) {
                alert('Please select at least one partner or click "Skip & Send to All"');
                return false;
            }
            formData.set('action', 'selected');
        } else {
            // Send to all partners
            formData.set('action', 'all');
        }
        formData.set('priority_partner_ids', JSON.stringify([]));
    }
    
    // Disable submit buttons to prevent double submission
    const submitButtons = form.querySelectorAll('button[type="submit"]');
    submitButtons.forEach(btn => {
        btn.disabled = true;
        const originalText = btn.getAttribute('data-original-text') || btn.textContent;
        btn.setAttribute('data-original-text', originalText);
        btn.textContent = 'Sending...';
    });
    
    // Submit form via AJAX
    fetch(form.action, {
        method: 'POST',
        body: formData
    })
    .then(response => {
        // Update success modal based on action
        const successModal = document.getElementById('successModal');
        const successIcon = document.getElementById('successIcon');
        const successTitle = document.getElementById('successTitle');
        const successMessage = document.getElementById('successMessage');
        const successInfo = document.getElementById('successInfo');
        
        const vipCount = selectedIds.length;
        
        if (successModal) {
            if (successIcon) successIcon.textContent = '🚀';
            
            if (isSellCarRequest) {
                // Sell Car specific messages
                if (successTitle) successTitle.textContent = 'Car Listing Sent to All Dealers!';
                if (vipCount > 0) {
                    if (successMessage) {
                        successMessage.textContent = `Your car listing has been sent to all dealers. ${vipCount} dealer(s) marked as VIP will see your request first!`;
                    }
                    if (successInfo) {
                        successInfo.innerHTML = '<p><strong>What happens next?</strong></p><p>⭐ VIP dealers you selected will see your request with priority.</p><p>👉 All dealers will review your car and may contact you.</p><p>👉 Track responses from your Dashboard.</p>';
                    }
                } else {
                    if (successMessage) {
                        successMessage.textContent = 'Your car listing has been sent to all available dealerships.';
                    }
                    if (successInfo) {
                        successInfo.innerHTML = '<p><strong>What happens next?</strong></p><p>👉 All dealers will see your car listing and may contact you with offers.</p><p>👉 Track responses and confirm sales from your Dashboard.</p>';
                    }
                }
            } else {
                // Other service forms - original behavior
                if (action === 'selected') {
                    const selectedCount = form.querySelectorAll('input[name="selected_partners[]"]:checked').length;
                    if (successTitle) successTitle.textContent = 'Request Sent Successfully!';
                    if (successMessage) {
                        successMessage.textContent = `Your service request has been sent to ${selectedCount} selected partner(s).`;
                    }
                } else {
                    if (successTitle) successTitle.textContent = 'Request Sent to All Partners!';
                    if (successMessage) {
                        successMessage.textContent = 'Your service request has been sent to all available partners.';
                    }
                }
                if (successInfo) {
                    successInfo.innerHTML = '<p><strong>To track your request, receive responses, and continue the conversation:</strong></p><p><strong>If you already have an account:</strong><br>👉 Go to your Dashboard to view updates and messages.</p><p><strong>If you don\'t have an account yet:</strong><br>👉 Create a free account or log in to manage your request and communicate with the partner.</p>';
                }
            }
            
            // Show success modal
            successModal.classList.add('active');
        }
        
        // Re-enable buttons
        submitButtons.forEach(btn => {
            btn.disabled = false;
            const originalText = btn.getAttribute('data-original-text') || btn.textContent;
            btn.textContent = originalText;
        });
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred. Please try again.');
        submitButtons.forEach(btn => {
            btn.disabled = false;
            const originalText = btn.getAttribute('data-original-text') || btn.textContent;
            btn.textContent = originalText;
        });
    });
    
    return false;
}

// Close modals when clicking outside or pressing Escape
document.addEventListener('DOMContentLoaded', function() {
    const successModal = document.getElementById('successModal');
    const validationModal = document.getElementById('validationModal');
    
    function setupModalCloseHandlers(modal) {
        if (!modal) return;
        
        modal.addEventListener('click', function(e) {
            if (e.target === modal) {
                modal.classList.remove('active');
            }
        });
    }
    
    setupModalCloseHandlers(successModal);
    setupModalCloseHandlers(validationModal);
    
    const partnerDetailsModal = document.getElementById('partnerDetailsModal');
    setupModalCloseHandlers(partnerDetailsModal);
    
    // Close on Escape key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            if (successModal && successModal.classList.contains('active')) {
                successModal.classList.remove('active');
            }
            if (validationModal && validationModal.classList.contains('active')) {
                validationModal.classList.remove('active');
            }
            if (partnerDetailsModal && partnerDetailsModal.classList.contains('active')) {
                partnerDetailsModal.classList.remove('active');
            }
        }
    });
});
</script>

<?php
get_footer();
?>

