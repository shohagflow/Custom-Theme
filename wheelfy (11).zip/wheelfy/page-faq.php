<?php
/**
 * Template Name: FAQ
 * 
 * Frequently Asked Questions page with accordion functionality
 *
 * @package Wheelfy
 */

get_header();

// Get page ID
$page_id = get_the_ID();

// Get FAQ meta fields
$faq_title = get_post_meta($page_id, 'faq_title', true);
if (empty($faq_title)) {
    $faq_title = 'Frequently Asked Questions';
}

$faq_description = get_post_meta($page_id, 'faq_description', true);
if (empty($faq_description)) {
    $faq_description = 'Find answers to common questions about our platform.';
}

// Get FAQ items (repeatable group)
$faq_items = get_post_meta($page_id, 'faq_items', true);
if (empty($faq_items) || !is_array($faq_items)) {
    // Default FAQ items
    $faq_items = array(
        array(
            'question' => 'What is AutoHub?',
            'answer' => 'AutoHub is a platform that connects customers with verified service providers for car maintenance and car sales services.'
        ),
        array(
            'question' => 'Is AutoHub free to use?',
            'answer' => 'Yes, AutoHub is completely free for customers. You can compare prices and request proposals without any fees.'
        ),
        array(
            'question' => 'How do I get started?',
            'answer' => 'Simply request a proposal by filling out our form with your car details and service needs. We\'ll connect you with verified service providers who will send you competitive offers.'
        ),
        array(
            'question' => 'What areas do you cover?',
            'answer' => 'We currently serve multiple regions. Check your location during the proposal request process to see if we cover your area.'
        ),
    );
}
?>

<section class="py-16 md:py-24 min-h-[calc(100vh-80px)] bg-background">
    <div class="container mx-auto px-4 lg:px-8">
        <div class="max-w-4xl mx-auto">
            <!-- Header -->
            <div class="text-center mb-12">
                <h1 class="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-4">
                    <?php echo esc_html($faq_title); ?>
                </h1>
                <?php if (!empty($faq_description)) : ?>
                <p class="text-lg md:text-xl text-muted-foreground">
                    <?php echo esc_html($faq_description); ?>
                </p>
                <?php endif; ?>
            </div>

            <!-- FAQ Accordion -->
            <div class="space-y-4" id="faq-accordion">
                <?php foreach ($faq_items as $index => $item) : 
                    $question = isset($item['question']) ? $item['question'] : '';
                    $answer = isset($item['answer']) ? $item['answer'] : '';
                    if (empty($question)) continue;
                ?>
                <div class="faq-item bg-card border border-border rounded-lg overflow-hidden transition-all duration-300 hover:border-primary/50">
                    <button 
                        class="faq-question w-full flex items-center justify-between p-6 text-left focus:outline-none focus:ring-2 focus:ring-primary focus:ring-inset"
                        aria-expanded="false"
                        data-faq-index="<?php echo esc_attr($index); ?>"
                    >
                        <span class="text-lg font-medium text-foreground pr-4">
                            <?php echo esc_html($question); ?>
                        </span>
                        <svg 
                            class="faq-chevron w-5 h-5 text-muted-foreground flex-shrink-0 transition-transform duration-300" 
                            fill="none" 
                            stroke="currentColor" 
                            viewBox="0 0 24 24"
                        >
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                        </svg>
                    </button>
                    <div class="faq-answer hidden overflow-hidden">
                        <div class="px-6 pb-6 text-muted-foreground leading-relaxed">
                            <?php echo wp_kses_post(nl2br($answer)); ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <?php if (empty($faq_items)) : ?>
            <div class="text-center py-12">
                <p class="text-muted-foreground">No FAQ items have been added yet.</p>
            </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<style>
/* FAQ Accordion Styles */
.faq-item {
    transition: all 0.3s ease;
}

.faq-item.active {
    border-color: hsl(var(--primary) / 0.5);
}

.faq-question {
    transition: background-color 0.2s ease;
}

.faq-question:hover {
    background-color: hsl(var(--foreground) / 0.02);
}

.faq-item.active .faq-question {
    background-color: hsl(var(--foreground) / 0.03);
}

.faq-item.active .faq-chevron {
    transform: rotate(180deg);
    color: hsl(var(--primary));
}

.faq-answer {
    max-height: 0;
    transition: max-height 0.3s ease-out, padding 0.3s ease-out;
}

.faq-item.active .faq-answer {
    max-height: 1000px;
    display: block;
}

.faq-item.active .faq-answer > div {
    animation: fadeIn 0.3s ease-in;
}

@keyframes fadeIn {
    from {
        opacity: 0;
        transform: translateY(-10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}
</style>

<?php
get_footer();
?>

