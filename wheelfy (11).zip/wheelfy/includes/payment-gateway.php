<?php
/**
 * Payment Gateway System
 * 
 * Complete payment gateway integration for subscription management
 * Supports: Stripe, PayPal, Bank Transfer, Cash on Delivery
 * 
 * @package Wheelfy
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Create payment transactions table
 */
function wheelfy_create_payment_tables() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    
    // Payment Transactions Table
    $table_transactions = $wpdb->prefix . 'wheelfy_payment_transactions';
    
    $sql_transactions = "CREATE TABLE IF NOT EXISTS $table_transactions (
        id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        transaction_id varchar(100) NOT NULL,
        user_id bigint(20) UNSIGNED NOT NULL,
        plan_id bigint(20) UNSIGNED NOT NULL,
        gateway varchar(50) NOT NULL,
        amount decimal(10,2) NOT NULL,
        currency varchar(10) NOT NULL DEFAULT 'HUF',
        status varchar(30) NOT NULL DEFAULT 'pending',
        gateway_transaction_id varchar(255) DEFAULT NULL,
        gateway_response longtext DEFAULT NULL,
        subscription_id bigint(20) UNSIGNED DEFAULT NULL,
        billing_period_start datetime DEFAULT NULL,
        billing_period_end datetime DEFAULT NULL,
        metadata longtext DEFAULT NULL,
        ip_address varchar(45) DEFAULT NULL,
        user_agent text DEFAULT NULL,
        created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
        completed_at datetime DEFAULT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY transaction_id (transaction_id),
        KEY user_id (user_id),
        KEY plan_id (plan_id),
        KEY status (status),
        KEY gateway (gateway),
        KEY created_at (created_at)
    ) $charset_collate;";
    
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql_transactions);
    
    // Partner Subscriptions Table (if not exists from subscription-management.php)
    $table_subscriptions = $wpdb->prefix . 'wheelfy_partner_subscriptions';
    
    $sql_subscriptions = "CREATE TABLE IF NOT EXISTS $table_subscriptions (
        id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id bigint(20) UNSIGNED NOT NULL,
        plan_id bigint(20) UNSIGNED NOT NULL,
        status varchar(30) NOT NULL DEFAULT 'pending',
        start_date datetime DEFAULT NULL,
        end_date datetime DEFAULT NULL,
        next_billing_date datetime DEFAULT NULL,
        auto_renew tinyint(1) NOT NULL DEFAULT 1,
        payment_method varchar(50) DEFAULT NULL,
        last_payment_id bigint(20) UNSIGNED DEFAULT NULL,
        trial_ends_at datetime DEFAULT NULL,
        cancelled_at datetime DEFAULT NULL,
        cancellation_reason text DEFAULT NULL,
        metadata longtext DEFAULT NULL,
        created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY user_id (user_id),
        KEY plan_id (plan_id),
        KEY status (status),
        KEY end_date (end_date)
    ) $charset_collate;";
    
    dbDelta($sql_subscriptions);
}

// Create tables on theme activation
add_action('after_switch_theme', 'wheelfy_create_payment_tables');

// Ensure tables exist on admin init
add_action('admin_init', function() {
    if (get_option('wheelfy_payment_tables_version', '') !== '1.1') {
        wheelfy_create_payment_tables();
        update_option('wheelfy_payment_tables_version', '1.1');
    }
});

/**
 * Encryption helper for storing sensitive API keys
 */
class Wheelfy_Encryption {
    
    private static $method = 'AES-256-CBC';
    
    /**
     * Get encryption key (generates one if not exists)
     */
    private static function get_key() {
        $key = get_option('wheelfy_encryption_key');
        if (!$key) {
            $key = wp_generate_password(32, true, true);
            update_option('wheelfy_encryption_key', $key);
        }
        return hash('sha256', $key . AUTH_KEY);
    }
    
    /**
     * Encrypt a value
     */
    public static function encrypt($value) {
        if (empty($value)) {
            return '';
        }
        
        $key = self::get_key();
        $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length(self::$method));
        $encrypted = openssl_encrypt($value, self::$method, $key, 0, $iv);
        
        return base64_encode($iv . '::' . $encrypted);
    }
    
    /**
     * Decrypt a value
     */
    public static function decrypt($value) {
        if (empty($value)) {
            return '';
        }
        
        $key = self::get_key();
        $parts = explode('::', base64_decode($value), 2);
        
        if (count($parts) !== 2) {
            return $value; // Return as-is if not encrypted
        }
        
        list($iv, $encrypted) = $parts;
        return openssl_decrypt($encrypted, self::$method, $key, 0, $iv);
    }
}

/**
 * Main Payment Gateway Class
 */
class Wheelfy_Payment_Gateway {
    
    private static $instance = null;
    
    /**
     * Get singleton instance
     */
    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        add_action('init', array($this, 'register_endpoints'));
        add_action('template_redirect', array($this, 'handle_webhooks'));
    }
    
    /**
     * Register custom endpoints
     */
    public function register_endpoints() {
        add_rewrite_rule('^wheelfy-payment/webhook/([^/]+)/?', 'index.php?wheelfy_webhook=$matches[1]', 'top');
        add_rewrite_tag('%wheelfy_webhook%', '([^&]+)');
    }
    
    /**
     * Handle incoming webhooks
     */
    public function handle_webhooks() {
        $webhook = get_query_var('wheelfy_webhook');
        
        if ($webhook === 'stripe') {
            $this->handle_stripe_webhook();
            exit;
        } elseif ($webhook === 'paypal') {
            $this->handle_paypal_webhook();
            exit;
        }
    }
    
    /**
     * Get enabled payment gateways
     */
    public function get_enabled_gateways() {
        $gateways = array();
        
        $available_gateways = array(
            'stripe' => array(
                'id' => 'stripe',
                'title' => get_option('wheelfy_stripe_title', 'Credit Card (Stripe)'),
                'description' => get_option('wheelfy_stripe_description', 'Pay securely using your credit card.'),
                'icon' => 'credit-card',
                'supports_recurring' => true
            ),
            'paypal' => array(
                'id' => 'paypal',
                'title' => get_option('wheelfy_paypal_title', 'PayPal'),
                'description' => get_option('wheelfy_paypal_description', 'Pay via PayPal; you can pay with your credit card if you don\'t have a PayPal account.'),
                'icon' => 'paypal',
                'supports_recurring' => true
            ),
            'bank_transfer' => array(
                'id' => 'bank_transfer',
                'title' => get_option('wheelfy_bank_transfer_title', 'Direct Bank Transfer'),
                'description' => get_option('wheelfy_bank_transfer_description', 'Make your payment directly into our bank account.'),
                'icon' => 'building',
                'supports_recurring' => false
            ),
            'cash_on_delivery' => array(
                'id' => 'cash_on_delivery',
                'title' => get_option('wheelfy_cash_on_delivery_title', 'Pay Later'),
                'description' => get_option('wheelfy_cash_on_delivery_description', 'Pay when you use the service.'),
                'icon' => 'cash',
                'supports_recurring' => false
            )
        );
        
        foreach ($available_gateways as $id => $gateway) {
            if (get_option('wheelfy_' . $id . '_enabled') === 'yes') {
                $gateways[$id] = $gateway;
            }
        }
        
        return $gateways;
    }
    
    /**
     * Generate unique transaction ID
     */
    public function generate_transaction_id() {
        return 'TXN_' . strtoupper(wp_generate_password(8, false)) . '_' . time();
    }
    
    /**
     * Create a pending transaction
     */
    public function create_transaction($user_id, $plan_id, $gateway, $amount, $currency = 'HUF') {
        global $wpdb;
        $table = $wpdb->prefix . 'wheelfy_payment_transactions';
        
        $transaction_id = $this->generate_transaction_id();
        
        $data = array(
            'transaction_id' => $transaction_id,
            'user_id' => $user_id,
            'plan_id' => $plan_id,
            'gateway' => $gateway,
            'amount' => $amount,
            'currency' => $currency,
            'status' => 'pending',
            'ip_address' => $this->get_client_ip(),
            'user_agent' => isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field($_SERVER['HTTP_USER_AGENT']) : '',
            'created_at' => current_time('mysql')
        );
        
        $result = $wpdb->insert($table, $data, array('%s', '%d', '%d', '%s', '%f', '%s', '%s', '%s', '%s', '%s'));
        
        if ($result) {
            return array(
                'id' => $wpdb->insert_id,
                'transaction_id' => $transaction_id
            );
        }
        
        return false;
    }
    
    /**
     * Update transaction status
     */
    public function update_transaction($transaction_id, $data) {
        global $wpdb;
        $table = $wpdb->prefix . 'wheelfy_payment_transactions';
        
        return $wpdb->update(
            $table,
            $data,
            array('transaction_id' => $transaction_id),
            null,
            array('%s')
        );
    }
    
    /**
     * Get transaction by ID
     */
    public function get_transaction($transaction_id) {
        global $wpdb;
        $table = $wpdb->prefix . 'wheelfy_payment_transactions';
        
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table WHERE transaction_id = %s",
            $transaction_id
        ));
    }
    
    /**
     * Complete a transaction and activate subscription
     */
    public function complete_transaction($transaction_id, $gateway_transaction_id = null, $gateway_response = null) {
        global $wpdb;
        
        $transaction = $this->get_transaction($transaction_id);
        if (!$transaction || $transaction->status === 'completed') {
            return false;
        }
        
        // Update transaction
        $this->update_transaction($transaction_id, array(
            'status' => 'completed',
            'gateway_transaction_id' => $gateway_transaction_id,
            'gateway_response' => is_array($gateway_response) ? json_encode($gateway_response) : $gateway_response,
            'completed_at' => current_time('mysql')
        ));
        
        // Activate subscription
        $subscription_id = $this->activate_subscription(
            $transaction->user_id,
            $transaction->plan_id,
            $transaction->gateway
        );
        
        // Update transaction with subscription ID
        if ($subscription_id) {
            $this->update_transaction($transaction_id, array(
                'subscription_id' => $subscription_id
            ));
        }
        
        // Send confirmation email
        $this->send_payment_confirmation_email($transaction);
        
        // Trigger action for other integrations
        do_action('wheelfy_payment_completed', $transaction_id, $transaction);
        
        return true;
    }
    
    /**
     * Activate subscription for a user
     */
    public function activate_subscription($user_id, $plan_id, $payment_method) {
        global $wpdb;
        $table = $wpdb->prefix . 'wheelfy_partner_subscriptions';
        
        // Get plan details
        $plan = wheelfy_get_subscription_plan_by_id($plan_id);
        if (!$plan) {
            return false;
        }
        
        // Calculate dates
        $start_date = current_time('mysql');
        $billing_cycle = $plan->billing_cycle ?? 'monthly';
        
        if ($billing_cycle === 'monthly') {
            $end_date = date('Y-m-d H:i:s', strtotime('+1 month'));
        } elseif ($billing_cycle === 'yearly') {
            $end_date = date('Y-m-d H:i:s', strtotime('+1 year'));
        } else {
            $end_date = date('Y-m-d H:i:s', strtotime('+1 month'));
        }
        
        // Check for existing subscription
        $existing = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table WHERE user_id = %d AND status IN ('active', 'pending')",
            $user_id
        ));
        
        if ($existing) {
            // Upgrade existing subscription
            $wpdb->update(
                $table,
                array(
                    'plan_id' => $plan_id,
                    'status' => 'active',
                    'start_date' => $start_date,
                    'end_date' => $end_date,
                    'next_billing_date' => $end_date,
                    'payment_method' => $payment_method,
                    'updated_at' => current_time('mysql')
                ),
                array('id' => $existing->id),
                array('%d', '%s', '%s', '%s', '%s', '%s', '%s'),
                array('%d')
            );
            
            $subscription_id = $existing->id;
        } else {
            // Create new subscription
            $wpdb->insert(
                $table,
                array(
                    'user_id' => $user_id,
                    'plan_id' => $plan_id,
                    'status' => 'active',
                    'start_date' => $start_date,
                    'end_date' => $end_date,
                    'next_billing_date' => $end_date,
                    'payment_method' => $payment_method,
                    'created_at' => current_time('mysql')
                ),
                array('%d', '%d', '%s', '%s', '%s', '%s', '%s', '%s')
            );
            
            $subscription_id = $wpdb->insert_id;
        }
        
        // Update user meta
        update_user_meta($user_id, 'wheelfy_subscription_plan_id', $plan_id);
        update_user_meta($user_id, 'wheelfy_subscription_status', 'active');
        update_user_meta($user_id, 'wheelfy_subscription_end_date', $end_date);
        
        // Trigger action
        do_action('wheelfy_subscription_activated', $user_id, $plan_id, $subscription_id);
        
        return $subscription_id;
    }
    
    /**
     * Get user's active subscription
     */
    public function get_user_subscription($user_id) {
        global $wpdb;
        $table = $wpdb->prefix . 'wheelfy_partner_subscriptions';
        
        return $wpdb->get_row($wpdb->prepare(
            "SELECT s.*, p.plan_name, p.plan_slug, p.price, p.currency, p.billing_cycle 
             FROM $table s 
             LEFT JOIN {$wpdb->prefix}wheelfy_subscription_plans p ON s.plan_id = p.id
             WHERE s.user_id = %d AND s.status = 'active' 
             ORDER BY s.created_at DESC LIMIT 1",
            $user_id
        ));
    }
    
    /**
     * Send payment confirmation email
     */
    public function send_payment_confirmation_email($transaction) {
        $user = get_user_by('ID', $transaction->user_id);
        if (!$user) {
            return false;
        }
        
        $plan = wheelfy_get_subscription_plan_by_id($transaction->plan_id);
        $plan_name = $plan ? $plan->plan_name : 'Subscription';
        
        $currency_symbol = get_option('wheelfy_currency_symbol', 'Ft');
        
        $to = $user->user_email;
        $subject = sprintf(__('[%s] Payment Confirmation - %s', 'wheelfy'), get_bloginfo('name'), $plan_name);
        
        $message = sprintf(
            __("Dear %s,\n\nThank you for your payment! Your subscription has been activated.\n\n" .
               "Transaction Details:\n" .
               "- Transaction ID: %s\n" .
               "- Plan: %s\n" .
               "- Amount: %s %s\n" .
               "- Payment Method: %s\n" .
               "- Date: %s\n\n" .
               "Your subscription is now active and you can start using all the features.\n\n" .
               "If you have any questions, please contact our support team.\n\n" .
               "Best regards,\n%s Team", 'wheelfy'),
            $user->display_name,
            $transaction->transaction_id,
            $plan_name,
            number_format($transaction->amount, 0, ',', ' '),
            $currency_symbol,
            ucfirst(str_replace('_', ' ', $transaction->gateway)),
            date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($transaction->created_at)),
            get_bloginfo('name')
        );
        
        $headers = array('Content-Type: text/plain; charset=UTF-8');
        
        return wp_mail($to, $subject, $message, $headers);
    }
    
    /**
     * Get client IP address
     */
    private function get_client_ip() {
        $ip = '';
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = sanitize_text_field($_SERVER['HTTP_CLIENT_IP']);
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip = sanitize_text_field($_SERVER['HTTP_X_FORWARDED_FOR']);
        } elseif (!empty($_SERVER['REMOTE_ADDR'])) {
            $ip = sanitize_text_field($_SERVER['REMOTE_ADDR']);
        }
        return $ip;
    }
    
    /**
     * Handle Stripe webhook
     */
    public function handle_stripe_webhook() {
        $payload = file_get_contents('php://input');
        $sig_header = isset($_SERVER['HTTP_STRIPE_SIGNATURE']) ? $_SERVER['HTTP_STRIPE_SIGNATURE'] : '';
        
        // Log webhook for debugging
        error_log('Stripe webhook received');
        
        $data = json_decode($payload, true);
        
        if (!$data || !isset($data['type'])) {
            http_response_code(400);
            echo json_encode(array('error' => 'Invalid payload'));
            return;
        }
        
        switch ($data['type']) {
            case 'checkout.session.completed':
                $session = $data['data']['object'];
                $transaction_id = $session['metadata']['transaction_id'] ?? null;
                
                if ($transaction_id) {
                    $this->complete_transaction(
                        $transaction_id,
                        $session['payment_intent'] ?? $session['id'],
                        $session
                    );
                }
                break;
                
            case 'payment_intent.succeeded':
                $intent = $data['data']['object'];
                $transaction_id = $intent['metadata']['transaction_id'] ?? null;
                
                if ($transaction_id) {
                    $this->complete_transaction(
                        $transaction_id,
                        $intent['id'],
                        $intent
                    );
                }
                break;
                
            case 'payment_intent.payment_failed':
                $intent = $data['data']['object'];
                $transaction_id = $intent['metadata']['transaction_id'] ?? null;
                
                if ($transaction_id) {
                    $this->update_transaction($transaction_id, array(
                        'status' => 'failed',
                        'gateway_response' => json_encode($intent)
                    ));
                }
                break;
        }
        
        http_response_code(200);
        echo json_encode(array('received' => true));
    }
    
    /**
     * Handle PayPal webhook
     */
    public function handle_paypal_webhook() {
        $payload = file_get_contents('php://input');
        
        error_log('PayPal webhook received');
        
        $data = json_decode($payload, true);
        
        if (!$data || !isset($data['event_type'])) {
            http_response_code(400);
            echo json_encode(array('error' => 'Invalid payload'));
            return;
        }
        
        switch ($data['event_type']) {
            case 'CHECKOUT.ORDER.APPROVED':
            case 'PAYMENT.CAPTURE.COMPLETED':
                $resource = $data['resource'];
                $transaction_id = $resource['custom_id'] ?? ($resource['purchase_units'][0]['custom_id'] ?? null);
                
                if ($transaction_id) {
                    $this->complete_transaction(
                        $transaction_id,
                        $resource['id'],
                        $resource
                    );
                }
                break;
                
            case 'PAYMENT.CAPTURE.DENIED':
            case 'PAYMENT.CAPTURE.REFUNDED':
                $resource = $data['resource'];
                $transaction_id = $resource['custom_id'] ?? null;
                
                if ($transaction_id) {
                    $this->update_transaction($transaction_id, array(
                        'status' => 'failed',
                        'gateway_response' => json_encode($resource)
                    ));
                }
                break;
        }
        
        http_response_code(200);
        echo json_encode(array('received' => true));
    }
}

// Initialize payment gateway
Wheelfy_Payment_Gateway::get_instance();

/**
 * Stripe Payment Processor
 */
class Wheelfy_Stripe_Processor {
    
    /**
     * Get Stripe settings
     */
    public static function get_settings() {
        $test_mode = get_option('wheelfy_stripe_test_mode') === 'yes';
        
        return array(
            'enabled' => get_option('wheelfy_stripe_enabled') === 'yes',
            'test_mode' => $test_mode,
            'publishable_key' => get_option('wheelfy_stripe_publishable_key', ''),
            'secret_key' => get_option('wheelfy_stripe_secret_key', '')
        );
    }
    
    /**
     * Create Stripe Checkout Session
     */
    public static function create_checkout_session($transaction_id, $user_id, $plan, $return_url, $cancel_url) {
        $settings = self::get_settings();
        
        if (empty($settings['secret_key'])) {
            return new WP_Error('stripe_error', __('Stripe is not configured properly.', 'wheelfy'));
        }
        
        $amount = intval($plan->price * 100); // Convert to smallest currency unit
        $currency = strtolower($plan->currency ?? 'huf');
        
        $user = get_user_by('ID', $user_id);
        $customer_email = $user ? $user->user_email : '';
        
        $data = array(
            'payment_method_types' => array('card'),
            'mode' => 'payment',
            'success_url' => add_query_arg(array(
                'wheelfy_payment' => 'success',
                'transaction_id' => $transaction_id,
                'gateway' => 'stripe'
            ), $return_url),
            'cancel_url' => add_query_arg(array(
                'wheelfy_payment' => 'cancelled',
                'transaction_id' => $transaction_id
            ), $cancel_url),
            'customer_email' => $customer_email,
            'metadata' => array(
                'transaction_id' => $transaction_id,
                'user_id' => $user_id,
                'plan_id' => $plan->id
            ),
            'line_items' => array(
                array(
                    'price_data' => array(
                        'currency' => $currency,
                        'unit_amount' => $amount,
                        'product_data' => array(
                            'name' => $plan->plan_name,
                            'description' => sprintf(__('%s Subscription', 'wheelfy'), $plan->plan_name)
                        )
                    ),
                    'quantity' => 1
                )
            )
        );
        
        $response = wp_remote_post('https://api.stripe.com/v1/checkout/sessions', array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $settings['secret_key'],
                'Content-Type' => 'application/x-www-form-urlencoded'
            ),
            'body' => http_build_query(self::flatten_array($data)),
            'timeout' => 30
        ));
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (isset($body['error'])) {
            return new WP_Error('stripe_error', $body['error']['message'] ?? __('Stripe error occurred.', 'wheelfy'));
        }
        
        return $body;
    }
    
    /**
     * Flatten nested array for Stripe API
     */
    private static function flatten_array($array, $prefix = '') {
        $result = array();
        foreach ($array as $key => $value) {
            $new_key = $prefix ? "{$prefix}[{$key}]" : $key;
            if (is_array($value)) {
                $result = array_merge($result, self::flatten_array($value, $new_key));
            } else {
                $result[$new_key] = $value;
            }
        }
        return $result;
    }
    
    /**
     * Verify Stripe webhook signature
     */
    public static function verify_webhook_signature($payload, $sig_header, $endpoint_secret) {
        if (empty($endpoint_secret)) {
            return true; // Skip verification if no secret configured
        }
        
        $timestamp = null;
        $signature = null;
        
        $items = explode(',', $sig_header);
        foreach ($items as $item) {
            $parts = explode('=', trim($item), 2);
            if (count($parts) === 2) {
                if ($parts[0] === 't') {
                    $timestamp = $parts[1];
                } elseif ($parts[0] === 'v1') {
                    $signature = $parts[1];
                }
            }
        }
        
        if (!$timestamp || !$signature) {
            return false;
        }
        
        $signed_payload = $timestamp . '.' . $payload;
        $expected_signature = hash_hmac('sha256', $signed_payload, $endpoint_secret);
        
        return hash_equals($expected_signature, $signature);
    }
}

/**
 * PayPal Payment Processor
 */
class Wheelfy_PayPal_Processor {
    
    /**
     * Get PayPal settings
     */
    public static function get_settings() {
        $sandbox = get_option('wheelfy_paypal_sandbox') === 'yes';
        
        return array(
            'enabled' => get_option('wheelfy_paypal_enabled') === 'yes',
            'sandbox' => $sandbox,
            'client_id' => get_option('wheelfy_paypal_client_id', ''),
            'secret' => get_option('wheelfy_paypal_secret', ''),
            'api_url' => $sandbox ? 'https://api-m.sandbox.paypal.com' : 'https://api-m.paypal.com'
        );
    }
    
    /**
     * Get PayPal access token
     */
    public static function get_access_token() {
        $settings = self::get_settings();
        
        if (empty($settings['client_id']) || empty($settings['secret'])) {
            return new WP_Error('paypal_error', __('PayPal is not configured properly.', 'wheelfy'));
        }
        
        $response = wp_remote_post($settings['api_url'] . '/v1/oauth2/token', array(
            'headers' => array(
                'Authorization' => 'Basic ' . base64_encode($settings['client_id'] . ':' . $settings['secret']),
                'Content-Type' => 'application/x-www-form-urlencoded'
            ),
            'body' => 'grant_type=client_credentials',
            'timeout' => 30
        ));
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (isset($body['error'])) {
            return new WP_Error('paypal_error', $body['error_description'] ?? __('PayPal authentication failed.', 'wheelfy'));
        }
        
        return $body['access_token'] ?? null;
    }
    
    /**
     * Create PayPal order
     */
    public static function create_order($transaction_id, $user_id, $plan, $return_url, $cancel_url) {
        $settings = self::get_settings();
        $access_token = self::get_access_token();
        
        if (is_wp_error($access_token)) {
            return $access_token;
        }
        
        $currency = strtoupper($plan->currency ?? 'HUF');
        $amount = number_format($plan->price, 2, '.', '');
        
        $data = array(
            'intent' => 'CAPTURE',
            'purchase_units' => array(
                array(
                    'reference_id' => $transaction_id,
                    'custom_id' => $transaction_id,
                    'description' => sprintf(__('%s Subscription', 'wheelfy'), $plan->plan_name),
                    'amount' => array(
                        'currency_code' => $currency,
                        'value' => $amount
                    )
                )
            ),
            'application_context' => array(
                'brand_name' => get_bloginfo('name'),
                'return_url' => add_query_arg(array(
                    'wheelfy_payment' => 'success',
                    'transaction_id' => $transaction_id,
                    'gateway' => 'paypal'
                ), $return_url),
                'cancel_url' => add_query_arg(array(
                    'wheelfy_payment' => 'cancelled',
                    'transaction_id' => $transaction_id
                ), $cancel_url),
                'user_action' => 'PAY_NOW'
            )
        );
        
        $response = wp_remote_post($settings['api_url'] . '/v2/checkout/orders', array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $access_token,
                'Content-Type' => 'application/json'
            ),
            'body' => json_encode($data),
            'timeout' => 30
        ));
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (isset($body['error'])) {
            return new WP_Error('paypal_error', $body['message'] ?? __('PayPal error occurred.', 'wheelfy'));
        }
        
        return $body;
    }
    
    /**
     * Capture PayPal order
     */
    public static function capture_order($order_id) {
        $settings = self::get_settings();
        $access_token = self::get_access_token();
        
        if (is_wp_error($access_token)) {
            return $access_token;
        }
        
        $response = wp_remote_post($settings['api_url'] . '/v2/checkout/orders/' . $order_id . '/capture', array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $access_token,
                'Content-Type' => 'application/json'
            ),
            'body' => '{}',
            'timeout' => 30
        ));
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        return json_decode(wp_remote_retrieve_body($response), true);
    }
}

/**
 * AJAX: Process checkout
 */
function wheelfy_ajax_process_checkout() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_checkout_nonce')) {
        wp_send_json_error(array('message' => __('Security check failed.', 'wheelfy')));
    }
    
    // Check if user is logged in
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => __('You must be logged in.', 'wheelfy')));
    }
    
    $user_id = get_current_user_id();
    $plan_id = isset($_POST['plan_id']) ? intval($_POST['plan_id']) : 0;
    $gateway = isset($_POST['gateway']) ? sanitize_text_field($_POST['gateway']) : '';
    
    // Validate inputs
    if (!$plan_id || !$gateway) {
        wp_send_json_error(array('message' => __('Please select a plan and payment method.', 'wheelfy')));
    }
    
    // Get plan
    $plan = wheelfy_get_subscription_plan_by_id($plan_id);
    if (!$plan) {
        wp_send_json_error(array('message' => __('Invalid subscription plan.', 'wheelfy')));
    }
    
    // Check if gateway is enabled
    $payment_gateway = Wheelfy_Payment_Gateway::get_instance();
    $enabled_gateways = $payment_gateway->get_enabled_gateways();
    
    if (!isset($enabled_gateways[$gateway])) {
        wp_send_json_error(array('message' => __('Selected payment method is not available.', 'wheelfy')));
    }
    
    // Handle free plans
    if ($plan->price <= 0) {
        // Directly activate subscription for free plans
        $subscription_id = $payment_gateway->activate_subscription($user_id, $plan_id, 'free');
        
        if ($subscription_id) {
            wp_send_json_success(array(
                'message' => __('Your subscription has been activated!', 'wheelfy'),
                'redirect' => add_query_arg('subscription', 'activated', get_permalink(get_page_by_path('dashboard-partner')))
            ));
        } else {
            wp_send_json_error(array('message' => __('Failed to activate subscription.', 'wheelfy')));
        }
    }
    
    // Create transaction
    $transaction = $payment_gateway->create_transaction(
        $user_id,
        $plan_id,
        $gateway,
        $plan->price,
        $plan->currency ?? 'HUF'
    );
    
    if (!$transaction) {
        wp_send_json_error(array('message' => __('Failed to create transaction.', 'wheelfy')));
    }
    
    $return_url = home_url('/subscription-checkout/');
    $cancel_url = home_url('/subscription-checkout/');
    
    // Process based on gateway
    switch ($gateway) {
        case 'stripe':
            $session = Wheelfy_Stripe_Processor::create_checkout_session(
                $transaction['transaction_id'],
                $user_id,
                $plan,
                $return_url,
                $cancel_url
            );
            
            if (is_wp_error($session)) {
                wp_send_json_error(array('message' => $session->get_error_message()));
            }
            
            wp_send_json_success(array(
                'gateway' => 'stripe',
                'checkout_url' => $session['url'],
                'session_id' => $session['id']
            ));
            break;
            
        case 'paypal':
            $order = Wheelfy_PayPal_Processor::create_order(
                $transaction['transaction_id'],
                $user_id,
                $plan,
                $return_url,
                $cancel_url
            );
            
            if (is_wp_error($order)) {
                wp_send_json_error(array('message' => $order->get_error_message()));
            }
            
            // Find approval URL
            $approval_url = null;
            if (isset($order['links'])) {
                foreach ($order['links'] as $link) {
                    if ($link['rel'] === 'approve') {
                        $approval_url = $link['href'];
                        break;
                    }
                }
            }
            
            if (!$approval_url) {
                wp_send_json_error(array('message' => __('Failed to get PayPal checkout URL.', 'wheelfy')));
            }
            
            wp_send_json_success(array(
                'gateway' => 'paypal',
                'checkout_url' => $approval_url,
                'order_id' => $order['id']
            ));
            break;
            
        case 'bank_transfer':
            // Mark as pending and show bank details
            $payment_gateway->update_transaction($transaction['transaction_id'], array(
                'status' => 'awaiting_payment'
            ));
            
            wp_send_json_success(array(
                'gateway' => 'bank_transfer',
                'transaction_id' => $transaction['transaction_id'],
                'bank_details' => array(
                    'account_name' => get_option('wheelfy_bank_account_name', ''),
                    'account_number' => get_option('wheelfy_bank_account_number', ''),
                    'bank_name' => get_option('wheelfy_bank_name', ''),
                    'iban' => get_option('wheelfy_bank_iban', ''),
                    'reference' => $transaction['transaction_id'],
                    'amount' => number_format($plan->price, 0, ',', ' ') . ' ' . ($plan->currency ?? 'HUF')
                ),
                'message' => __('Please complete your bank transfer using the details below.', 'wheelfy')
            ));
            break;
            
        case 'cash_on_delivery':
            // Mark as pending
            $payment_gateway->update_transaction($transaction['transaction_id'], array(
                'status' => 'pending_payment'
            ));
            
            // For now, activate subscription with pending status
            $subscription_id = $payment_gateway->activate_subscription($user_id, $plan_id, 'cash_on_delivery');
            
            wp_send_json_success(array(
                'gateway' => 'cash_on_delivery',
                'transaction_id' => $transaction['transaction_id'],
                'message' => __('Your subscription request has been submitted. You can pay later when using the service.', 'wheelfy'),
                'redirect' => add_query_arg('subscription', 'pending', get_permalink(get_page_by_path('dashboard-partner')))
            ));
            break;
            
        default:
            wp_send_json_error(array('message' => __('Invalid payment gateway.', 'wheelfy')));
    }
}
add_action('wp_ajax_wheelfy_process_checkout', 'wheelfy_ajax_process_checkout');

/**
 * AJAX: Verify PayPal payment
 */
function wheelfy_ajax_verify_paypal_payment() {
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_checkout_nonce')) {
        wp_send_json_error(array('message' => __('Security check failed.', 'wheelfy')));
    }
    
    $order_id = isset($_POST['order_id']) ? sanitize_text_field($_POST['order_id']) : '';
    $transaction_id = isset($_POST['transaction_id']) ? sanitize_text_field($_POST['transaction_id']) : '';
    
    if (!$order_id) {
        wp_send_json_error(array('message' => __('Invalid PayPal order.', 'wheelfy')));
    }
    
    // Capture the order
    $capture = Wheelfy_PayPal_Processor::capture_order($order_id);
    
    if (is_wp_error($capture)) {
        wp_send_json_error(array('message' => $capture->get_error_message()));
    }
    
    if (isset($capture['status']) && $capture['status'] === 'COMPLETED') {
        // Complete the transaction
        $payment_gateway = Wheelfy_Payment_Gateway::get_instance();
        $payment_gateway->complete_transaction($transaction_id, $order_id, $capture);
        
        wp_send_json_success(array(
            'message' => __('Payment successful! Your subscription has been activated.', 'wheelfy'),
            'redirect' => add_query_arg('subscription', 'activated', get_permalink(get_page_by_path('dashboard-partner')))
        ));
    } else {
        wp_send_json_error(array('message' => __('Payment was not completed.', 'wheelfy')));
    }
}
add_action('wp_ajax_wheelfy_verify_paypal_payment', 'wheelfy_ajax_verify_paypal_payment');

/**
 * AJAX: Get checkout data
 */
function wheelfy_ajax_get_checkout_data() {
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_nonce')) {
        wp_send_json_error(array('message' => __('Security check failed.', 'wheelfy')));
    }
    
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => __('You must be logged in.', 'wheelfy')));
    }
    
    $plan_id = isset($_POST['plan_id']) ? intval($_POST['plan_id']) : 0;
    
    $plan = wheelfy_get_subscription_plan_by_id($plan_id);
    if (!$plan) {
        wp_send_json_error(array('message' => __('Invalid plan.', 'wheelfy')));
    }
    
    $payment_gateway = Wheelfy_Payment_Gateway::get_instance();
    $gateways = $payment_gateway->get_enabled_gateways();
    
    $currency_symbol = get_option('wheelfy_currency_symbol', 'Ft');
    
    wp_send_json_success(array(
        'plan' => array(
            'id' => $plan->id,
            'name' => $plan->plan_name,
            'price' => $plan->price,
            'price_formatted' => number_format($plan->price, 0, ',', ' ') . ' ' . $currency_symbol,
            'currency' => $plan->currency ?? 'HUF',
            'billing_cycle' => $plan->billing_cycle ?? 'monthly',
            'features' => $plan->features ?? array()
        ),
        'gateways' => array_values($gateways),
        'nonce' => wp_create_nonce('wheelfy_checkout_nonce')
    ));
}
add_action('wp_ajax_wheelfy_get_checkout_data', 'wheelfy_ajax_get_checkout_data');

/**
 * Handle payment return callbacks
 */
function wheelfy_handle_payment_return() {
    if (!isset($_GET['wheelfy_payment'])) {
        return;
    }
    
    $status = sanitize_text_field($_GET['wheelfy_payment']);
    $transaction_id = isset($_GET['transaction_id']) ? sanitize_text_field($_GET['transaction_id']) : '';
    $gateway = isset($_GET['gateway']) ? sanitize_text_field($_GET['gateway']) : '';
    
    if ($status === 'success' && $gateway === 'stripe') {
        // Stripe payment returns - complete transaction
        $payment_gateway = Wheelfy_Payment_Gateway::get_instance();
        $transaction = $payment_gateway->get_transaction($transaction_id);
        
        if ($transaction && $transaction->status === 'pending') {
            // The webhook should have already completed this, but let's check
            // In production, you'd verify with Stripe API
            $payment_gateway->complete_transaction($transaction_id, null, array('source' => 'return_callback'));
        }
        
        // Redirect to dashboard with success message
        wp_redirect(add_query_arg('subscription', 'activated', get_permalink(get_page_by_path('dashboard-partner'))));
        exit;
    }
    
    if ($status === 'success' && $gateway === 'paypal') {
        // PayPal returns with token, capture in JS
        return; // Let the page handle this
    }
    
    if ($status === 'cancelled') {
        // Update transaction as cancelled
        $payment_gateway = Wheelfy_Payment_Gateway::get_instance();
        $payment_gateway->update_transaction($transaction_id, array('status' => 'cancelled'));
        
        // Redirect back to checkout with message
        wp_redirect(add_query_arg('payment', 'cancelled', home_url('/subscription-checkout/')));
        exit;
    }
}
add_action('template_redirect', 'wheelfy_handle_payment_return', 5);

/**
 * Get user's payment history
 */
function wheelfy_get_user_payment_history($user_id, $limit = 10) {
    global $wpdb;
    $table = $wpdb->prefix . 'wheelfy_payment_transactions';
    
    return $wpdb->get_results($wpdb->prepare(
        "SELECT t.*, p.plan_name 
         FROM $table t 
         LEFT JOIN {$wpdb->prefix}wheelfy_subscription_plans p ON t.plan_id = p.id
         WHERE t.user_id = %d 
         ORDER BY t.created_at DESC 
         LIMIT %d",
        $user_id,
        $limit
    ));
}

/**
 * Admin: Get all payment transactions
 */
function wheelfy_get_all_transactions($args = array()) {
    global $wpdb;
    $table = $wpdb->prefix . 'wheelfy_payment_transactions';
    
    $defaults = array(
        'status' => null,
        'gateway' => null,
        'limit' => 50,
        'offset' => 0,
        'orderby' => 'created_at',
        'order' => 'DESC'
    );
    
    $args = wp_parse_args($args, $defaults);
    
    $where = array('1=1');
    $values = array();
    
    if ($args['status']) {
        $where[] = 't.status = %s';
        $values[] = $args['status'];
    }
    
    if ($args['gateway']) {
        $where[] = 't.gateway = %s';
        $values[] = $args['gateway'];
    }
    
    $where_clause = implode(' AND ', $where);
    $order = in_array(strtoupper($args['order']), array('ASC', 'DESC')) ? strtoupper($args['order']) : 'DESC';
    $orderby = in_array($args['orderby'], array('created_at', 'amount', 'status')) ? $args['orderby'] : 'created_at';
    
    $sql = "SELECT t.*, p.plan_name, u.display_name as user_name, u.user_email 
            FROM $table t 
            LEFT JOIN {$wpdb->prefix}wheelfy_subscription_plans p ON t.plan_id = p.id
            LEFT JOIN {$wpdb->users} u ON t.user_id = u.ID
            WHERE {$where_clause} 
            ORDER BY t.{$orderby} {$order} 
            LIMIT %d OFFSET %d";
    
    $values[] = $args['limit'];
    $values[] = $args['offset'];
    
    if (count($values) > 2) {
        return $wpdb->get_results($wpdb->prepare($sql, $values));
    } else {
        return $wpdb->get_results($wpdb->prepare($sql, $args['limit'], $args['offset']));
    }
}

/**
 * Get payment statistics
 */
function wheelfy_get_payment_statistics() {
    global $wpdb;
    $table = $wpdb->prefix . 'wheelfy_payment_transactions';
    
    $stats = array(
        'total_transactions' => 0,
        'total_revenue' => 0,
        'monthly_revenue' => 0,
        'pending_payments' => 0,
        'by_gateway' => array(),
        'by_status' => array()
    );
    
    // Check if table exists
    $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table'") === $table;
    if (!$table_exists) {
        return $stats;
    }
    
    // Total transactions
    $stats['total_transactions'] = (int) $wpdb->get_var("SELECT COUNT(*) FROM $table");
    
    // Total revenue (completed only)
    $stats['total_revenue'] = (float) $wpdb->get_var(
        "SELECT COALESCE(SUM(amount), 0) FROM $table WHERE status = 'completed'"
    );
    
    // Monthly revenue
    $stats['monthly_revenue'] = (float) $wpdb->get_var($wpdb->prepare(
        "SELECT COALESCE(SUM(amount), 0) FROM $table WHERE status = 'completed' AND created_at >= %s",
        date('Y-m-01')
    ));
    
    // Pending payments
    $stats['pending_payments'] = (int) $wpdb->get_var(
        "SELECT COUNT(*) FROM $table WHERE status IN ('pending', 'awaiting_payment', 'pending_payment')"
    );
    
    // By gateway
    $by_gateway = $wpdb->get_results(
        "SELECT gateway, COUNT(*) as count, COALESCE(SUM(CASE WHEN status = 'completed' THEN amount ELSE 0 END), 0) as revenue 
         FROM $table GROUP BY gateway"
    );
    foreach ($by_gateway as $g) {
        $stats['by_gateway'][$g->gateway] = array(
            'count' => (int) $g->count,
            'revenue' => (float) $g->revenue
        );
    }
    
    // By status
    $by_status = $wpdb->get_results("SELECT status, COUNT(*) as count FROM $table GROUP BY status");
    foreach ($by_status as $s) {
        $stats['by_status'][$s->status] = (int) $s->count;
    }
    
    return $stats;
}

/**
 * Manually complete a bank transfer payment (admin function)
 */
function wheelfy_admin_complete_bank_transfer($transaction_id) {
    if (!current_user_can('manage_options')) {
        return new WP_Error('permission_denied', __('Permission denied.', 'wheelfy'));
    }
    
    $payment_gateway = Wheelfy_Payment_Gateway::get_instance();
    $transaction = $payment_gateway->get_transaction($transaction_id);
    
    if (!$transaction) {
        return new WP_Error('not_found', __('Transaction not found.', 'wheelfy'));
    }
    
    if ($transaction->status === 'completed') {
        return new WP_Error('already_completed', __('Transaction already completed.', 'wheelfy'));
    }
    
    return $payment_gateway->complete_transaction($transaction_id, 'manual_verification', array(
        'verified_by' => get_current_user_id(),
        'verified_at' => current_time('mysql')
    ));
}

/**
 * AJAX: Admin complete bank transfer
 */
function wheelfy_ajax_admin_complete_bank_transfer() {
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_admin_nonce')) {
        wp_send_json_error(array('message' => __('Security check failed.', 'wheelfy')));
    }
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => __('Permission denied.', 'wheelfy')));
    }
    
    $transaction_id = isset($_POST['transaction_id']) ? sanitize_text_field($_POST['transaction_id']) : '';
    
    $result = wheelfy_admin_complete_bank_transfer($transaction_id);
    
    if (is_wp_error($result)) {
        wp_send_json_error(array('message' => $result->get_error_message()));
    }
    
    wp_send_json_success(array('message' => __('Payment verified and subscription activated.', 'wheelfy')));
}
add_action('wp_ajax_wheelfy_admin_complete_bank_transfer', 'wheelfy_ajax_admin_complete_bank_transfer');

// Note: wheelfy_check_expired_subscriptions() is defined in subscription-management.php
// Cron scheduling is also handled there via wheelfy_daily_subscription_check action
