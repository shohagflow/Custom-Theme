<?php
/**
 * Chat Security - Contact Information Blocking System
 * 
 * Prevents users from sharing email addresses, phone numbers, WhatsApp numbers,
 * and other contact information through the chat system.
 * 
 * @package Wheelfy
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Regex Patterns for Contact Information Detection
 * 
 * These patterns detect various formats of contact information including
 * obfuscated versions that users might try to bypass filters.
 */
class Wheelfy_Contact_Patterns {
    
    /**
     * Email detection patterns
     * Detects: test@gmail.com, test [at] gmail [dot] com, test(at)gmail(dot)com, etc.
     */
    public static function get_email_patterns() {
        return array(
            // Standard email format
            '/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/i',
            
            // Obfuscated email with [at], (at), {at}, <at>, -at-, _at_
            '/[a-zA-Z0-9._%+-]+\s*[\[\(\{<\-_]?\s*at\s*[\]\)\}>_\-]?\s*[a-zA-Z0-9.-]+\s*[\[\(\{<\-_]?\s*dot\s*[\]\)\}>_\-]?\s*[a-zA-Z]{2,}/i',
            
            // Email with spaces around @
            '/[a-zA-Z0-9._%+-]+\s+@\s+[a-zA-Z0-9.-]+\s*\.\s*[a-zA-Z]{2,}/i',
            
            // Email with spelled out "at" and "dot"
            '/[a-zA-Z0-9._%+-]+\s+at\s+[a-zA-Z0-9.-]+\s+dot\s+[a-zA-Z]{2,}/i',
            
            // Unicode @ symbol variations
            '/[a-zA-Z0-9._%+-]+[\x{FF20}\x{FE6B}][a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/iu',
            
            // Email with asterisks or dashes replacing characters
            '/[a-zA-Z0-9._%+*-]+[\*]+[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/i',
        );
    }
    
    /**
     * Phone number detection patterns
     * Detects various international and local formats including obfuscated versions
     */
    public static function get_phone_patterns() {
        return array(
            // International format with + (e.g., +880 1700 000000, +1-234-567-8900)
            '/\+\d{1,4}[\s\-\.]*\d{2,4}[\s\-\.]*\d{2,4}[\s\-\.]*\d{2,6}/i',
            
            // International format without + (e.g., 00880 1700 000000)
            '/00\d{1,4}[\s\-\.]*\d{2,4}[\s\-\.]*\d{2,4}[\s\-\.]*\d{2,6}/i',
            
            // Bangladesh phone numbers (01XXXXXXXXX format)
            '/\b0?1[3-9]\d{8,9}\b/',
            
            // US/Canada format (XXX) XXX-XXXX or XXX-XXX-XXXX
            '/\(?\d{3}\)?[\s\-\.]*\d{3}[\s\-\.]*\d{4}/',
            
            // General 10+ digit number with separators
            '/\b\d{3,4}[\s\-\.]+\d{3,4}[\s\-\.]+\d{3,5}\b/',
            
            // Consecutive digits (8 or more digits with optional separators)
            '/\b[\d][\d\s\-\.]{7,15}[\d]\b/',
            
            // Numbers with letters spelling separators (e.g., 0 1 7 one two three)
            '/\b\d[\d\s]*(?:zero|one|two|three|four|five|six|seven|eight|nine|oh|o)[\d\s\w]*\d\b/i',
            
            // WhatsApp specific patterns
            '/whatsapp[\s\:\-]*[\+]?\d[\d\s\-\.]{7,15}/i',
            '/wa[\s\:\-\.]*[\+]?\d[\d\s\-\.]{7,15}/i',
            '/w\/a[\s\:\-\.]*[\+]?\d[\d\s\-\.]{7,15}/i',
            
            // Call/Text me patterns followed by numbers
            '/(?:call|text|msg|message|contact|reach)[\s\:\-]*(?:me)?[\s\:\-]*(?:at|on)?[\s\:\-]*[\+]?\d[\d\s\-\.]{7,15}/i',
            
            // Numbers with spelled out digits
            '/\b(?:zero|one|two|three|four|five|six|seven|eight|nine|oh|o)[\s\-]*(?:zero|one|two|three|four|five|six|seven|eight|nine|oh|o)[\s\-]*(?:zero|one|two|three|four|five|six|seven|eight|nine|oh|o)[\s\-]*(?:zero|one|two|three|four|five|six|seven|eight|nine|oh|o)[\s\-]*(?:zero|one|two|three|four|five|six|seven|eight|nine|oh|o)/i',
        );
    }
    
    /**
     * Social media and messaging app patterns
     */
    public static function get_social_patterns() {
        return array(
            // Facebook
            '/(?:facebook|fb)[\s\:\-\.\/]*(?:com\/|me\/)?[a-zA-Z0-9._]+/i',
            '/fb[\s\:\-\.]+(?:me|id|profile)[\s\:\-\.]+[a-zA-Z0-9._]+/i',
            
            // Instagram
            '/(?:instagram|insta|ig)[\s\:\-\.\/]*(?:com\/)?@?[a-zA-Z0-9._]+/i',
            
            // Telegram
            '/(?:telegram|tg)[\s\:\-\.\/]*(?:me\/)?@?[a-zA-Z0-9._]+/i',
            '/t\.me\/[a-zA-Z0-9._]+/i',
            
            // WhatsApp (link format)
            '/wa\.me\/[\d]+/i',
            '/api\.whatsapp\.com\/send[\?\&]phone=[\d]+/i',
            
            // Viber
            '/viber[\s\:\-\.\/]*[\+]?\d[\d\s\-\.]{7,15}/i',
            
            // IMO
            '/imo[\s\:\-\.\/]*[\+]?\d[\d\s\-\.]{7,15}/i',
            
            // Skype
            '/skype[\s\:\-\.\/]*[a-zA-Z0-9._:-]+/i',
            
            // WeChat
            '/wechat[\s\:\-\.\/]*[a-zA-Z0-9._]+/i',
            '/weixin[\s\:\-\.\/]*[a-zA-Z0-9._]+/i',
        );
    }
    
    /**
     * URL patterns (to catch website sharing)
     */
    public static function get_url_patterns() {
        return array(
            // Standard URLs
            '/https?:\/\/[^\s<>"{}|\\^`\[\]]+/i',
            
            // URLs without protocol
            '/www\.[a-zA-Z0-9][a-zA-Z0-9\-]*[a-zA-Z0-9]\.[a-zA-Z]{2,}[^\s]*/i',
            
            // Common domain extensions without www
            '/[a-zA-Z0-9][a-zA-Z0-9\-]*[a-zA-Z0-9]\.(?:com|net|org|io|co|info|biz|me|us|uk|bd|in)[\/\?\#]?[^\s]*/i',
        );
    }
}

/**
 * Main Contact Information Validator Class
 */
class Wheelfy_Chat_Security {
    
    /**
     * Singleton instance
     */
    private static $instance = null;
    
    /**
     * Blocked patterns log table name
     */
    private $log_table;
    
    /**
     * Constructor
     */
    private function __construct() {
        global $wpdb;
        $this->log_table = $wpdb->prefix . 'wheelfy_blocked_messages';
    }
    
    /**
     * Get singleton instance
     */
    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Create log table on activation
     */
    public static function create_log_table() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'wheelfy_blocked_messages';
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE IF NOT EXISTS $table_name (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint(20) unsigned NOT NULL,
            thread_id varchar(100) NOT NULL,
            message_text text NOT NULL,
            detected_pattern varchar(50) NOT NULL,
            detected_content text NOT NULL,
            blocked_at datetime DEFAULT CURRENT_TIMESTAMP,
            ip_address varchar(45) DEFAULT NULL,
            user_agent text DEFAULT NULL,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY blocked_at (blocked_at),
            KEY detected_pattern (detected_pattern)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
    
    /**
     * Check if message contains contact information
     * 
     * @param string $message The message to check
     * @return array Array with 'has_contact' boolean and 'detected' array of found patterns
     */
    public function contains_contact_info($message) {
        $result = array(
            'has_contact' => false,
            'detected' => array(),
            'pattern_type' => null
        );
        
        // Normalize the message for better detection
        $normalized_message = $this->normalize_message($message);
        
        // Check email patterns
        foreach (Wheelfy_Contact_Patterns::get_email_patterns() as $pattern) {
            if (preg_match($pattern, $normalized_message, $matches)) {
                $result['has_contact'] = true;
                $result['detected'][] = $matches[0];
                $result['pattern_type'] = 'email';
                break; // Found one, no need to continue
            }
        }
        
        // Check phone patterns if no email found
        if (!$result['has_contact']) {
            foreach (Wheelfy_Contact_Patterns::get_phone_patterns() as $pattern) {
                if (preg_match($pattern, $normalized_message, $matches)) {
                    // Additional validation: must contain enough digits
                    $digits_only = preg_replace('/[^0-9]/', '', $matches[0]);
                    if (strlen($digits_only) >= 7) {
                        $result['has_contact'] = true;
                        $result['detected'][] = $matches[0];
                        $result['pattern_type'] = 'phone';
                        break;
                    }
                }
            }
        }
        
        // Check social media patterns
        if (!$result['has_contact']) {
            foreach (Wheelfy_Contact_Patterns::get_social_patterns() as $pattern) {
                if (preg_match($pattern, $normalized_message, $matches)) {
                    $result['has_contact'] = true;
                    $result['detected'][] = $matches[0];
                    $result['pattern_type'] = 'social';
                    break;
                }
            }
        }
        
        return $result;
    }
    
    /**
     * Normalize message for better pattern detection
     * 
     * @param string $message The message to normalize
     * @return string Normalized message
     */
    private function normalize_message($message) {
        // Convert to lowercase for consistent matching
        $normalized = strtolower($message);
        
        // Replace common letter substitutions
        $replacements = array(
            // Number to letter
            '0' => 'o',
            '1' => 'l',
            '3' => 'e',
            '4' => 'a',
            '5' => 's',
            '7' => 't',
            '@' => 'at',
            
            // Unicode variations of @
            '＠' => '@',
            '﹫' => '@',
            
            // Common obfuscations
            '[dot]' => '.',
            '(dot)' => '.',
            '{dot}' => '.',
            '-dot-' => '.',
            '_dot_' => '.',
            ' dot ' => '.',
            '[at]' => '@',
            '(at)' => '@',
            '{at}' => '@',
            '-at-' => '@',
            '_at_' => '@',
            ' at ' => '@',
        );
        
        // Keep original for some checks
        $original = $message;
        
        return $message; // Return original, normalization happens in patterns
    }
    
    /**
     * Mask contact information in a message (alternative to blocking)
     * 
     * @param string $message The message to mask
     * @return string Message with contact info masked
     */
    public function mask_contact_info($message) {
        $masked = $message;
        
        // Mask emails
        foreach (Wheelfy_Contact_Patterns::get_email_patterns() as $pattern) {
            $masked = preg_replace($pattern, '***[email hidden]***', $masked);
        }
        
        // Mask phone numbers
        foreach (Wheelfy_Contact_Patterns::get_phone_patterns() as $pattern) {
            $masked = preg_replace_callback($pattern, function($matches) {
                $digits_only = preg_replace('/[^0-9]/', '', $matches[0]);
                if (strlen($digits_only) >= 7) {
                    return '***[phone hidden]***';
                }
                return $matches[0];
            }, $masked);
        }
        
        // Mask social media handles
        foreach (Wheelfy_Contact_Patterns::get_social_patterns() as $pattern) {
            $masked = preg_replace($pattern, '***[contact hidden]***', $masked);
        }
        
        return $masked;
    }
    
    /**
     * Log a blocked message attempt
     * 
     * @param int $user_id User ID
     * @param string $thread_id Thread ID
     * @param string $message Message content
     * @param string $pattern_type Type of pattern detected
     * @param string $detected_content What was detected
     */
    public function log_blocked_attempt($user_id, $thread_id, $message, $pattern_type, $detected_content) {
        global $wpdb;
        
        // Get user IP
        $ip_address = '';
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip_address = sanitize_text_field($_SERVER['HTTP_CLIENT_IP']);
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip_address = sanitize_text_field($_SERVER['HTTP_X_FORWARDED_FOR']);
        } elseif (!empty($_SERVER['REMOTE_ADDR'])) {
            $ip_address = sanitize_text_field($_SERVER['REMOTE_ADDR']);
        }
        
        // Get user agent
        $user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field($_SERVER['HTTP_USER_AGENT']) : '';
        
        // Ensure table exists
        self::create_log_table();
        
        $wpdb->insert(
            $this->log_table,
            array(
                'user_id' => $user_id,
                'thread_id' => $thread_id,
                'message_text' => $message,
                'detected_pattern' => $pattern_type,
                'detected_content' => is_array($detected_content) ? implode(', ', $detected_content) : $detected_content,
                'blocked_at' => current_time('mysql'),
                'ip_address' => $ip_address,
                'user_agent' => $user_agent,
            ),
            array('%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s')
        );
        
        // Optionally trigger action for notifications
        do_action('wheelfy_message_blocked', $user_id, $thread_id, $pattern_type, $detected_content);
    }
    
    /**
     * Get blocked attempts for admin review
     * 
     * @param array $args Query arguments
     * @return array Array of blocked attempts
     */
    public function get_blocked_attempts($args = array()) {
        global $wpdb;
        
        $defaults = array(
            'user_id' => null,
            'pattern_type' => null,
            'limit' => 50,
            'offset' => 0,
            'orderby' => 'blocked_at',
            'order' => 'DESC',
        );
        
        $args = wp_parse_args($args, $defaults);
        
        $where = array('1=1');
        $values = array();
        
        if ($args['user_id']) {
            $where[] = 'user_id = %d';
            $values[] = $args['user_id'];
        }
        
        if ($args['pattern_type']) {
            $where[] = 'detected_pattern = %s';
            $values[] = $args['pattern_type'];
        }
        
        $where_clause = implode(' AND ', $where);
        $order = in_array(strtoupper($args['order']), array('ASC', 'DESC')) ? strtoupper($args['order']) : 'DESC';
        $orderby = in_array($args['orderby'], array('blocked_at', 'user_id', 'detected_pattern')) ? $args['orderby'] : 'blocked_at';
        
        $sql = "SELECT * FROM {$this->log_table} WHERE {$where_clause} ORDER BY {$orderby} {$order} LIMIT %d OFFSET %d";
        $values[] = $args['limit'];
        $values[] = $args['offset'];
        
        if (count($values) > 2) {
            $results = $wpdb->get_results($wpdb->prepare($sql, $values));
        } else {
            $results = $wpdb->get_results($wpdb->prepare($sql, $args['limit'], $args['offset']));
        }
        
        return $results ? $results : array();
    }
    
    /**
     * Get statistics of blocked attempts
     * 
     * @return array Statistics
     */
    public function get_blocked_statistics() {
        global $wpdb;
        
        $stats = array(
            'total' => 0,
            'today' => 0,
            'this_week' => 0,
            'this_month' => 0,
            'by_type' => array(),
            'top_offenders' => array(),
        );
        
        // Check if table exists
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$this->log_table}'") === $this->log_table;
        if (!$table_exists) {
            return $stats;
        }
        
        // Total blocked
        $stats['total'] = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$this->log_table}");
        
        // Today
        $stats['today'] = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$this->log_table} WHERE DATE(blocked_at) = %s",
            current_time('Y-m-d')
        ));
        
        // This week
        $stats['this_week'] = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$this->log_table} WHERE blocked_at >= %s",
            date('Y-m-d', strtotime('-7 days'))
        ));
        
        // This month
        $stats['this_month'] = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$this->log_table} WHERE blocked_at >= %s",
            date('Y-m-01')
        ));
        
        // By type
        $by_type = $wpdb->get_results(
            "SELECT detected_pattern, COUNT(*) as count FROM {$this->log_table} GROUP BY detected_pattern"
        );
        foreach ($by_type as $type) {
            $stats['by_type'][$type->detected_pattern] = (int) $type->count;
        }
        
        // Top offenders
        $stats['top_offenders'] = $wpdb->get_results(
            "SELECT user_id, COUNT(*) as attempts FROM {$this->log_table} 
             GROUP BY user_id ORDER BY attempts DESC LIMIT 10"
        );
        
        return $stats;
    }
}

/**
 * Validate message content before sending
 * This is the main function to call for validation
 * 
 * @param string $message The message to validate
 * @param int $user_id The user ID sending the message
 * @param string $thread_id The thread ID
 * @param bool $log_attempt Whether to log blocked attempts
 * @return array Result array with 'valid' boolean and 'message' string
 */
function wheelfy_validate_chat_message($message, $user_id = 0, $thread_id = '', $log_attempt = true) {
    $security = Wheelfy_Chat_Security::get_instance();
    $check = $security->contains_contact_info($message);
    
    if ($check['has_contact']) {
        // Log the blocked attempt
        if ($log_attempt && $user_id > 0) {
            $security->log_blocked_attempt(
                $user_id,
                $thread_id,
                $message,
                $check['pattern_type'],
                $check['detected']
            );
        }
        
        return array(
            'valid' => false,
            'message' => __('Sharing contact information (email, phone, WhatsApp, social media) is not allowed in chat messages.', 'wheelfy'),
            'pattern_type' => $check['pattern_type'],
            'detected' => $check['detected'],
        );
    }
    
    return array(
        'valid' => true,
        'message' => '',
        'pattern_type' => null,
        'detected' => array(),
    );
}

/**
 * Get JavaScript validation code for frontend
 * This generates the regex patterns for client-side validation
 * 
 * @return string JavaScript code
 */
function wheelfy_get_chat_validation_js() {
    ob_start();
    ?>
    // Wheelfy Chat Security - Frontend Validation
    const WheelfyChatSecurity = {
        // Email patterns
        emailPatterns: [
            /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/i,
            /[a-zA-Z0-9._%+-]+\s*[\[\(\{<\-_]?\s*at\s*[\]\)\}>_\-]?\s*[a-zA-Z0-9.-]+\s*[\[\(\{<\-_]?\s*dot\s*[\]\)\}>_\-]?\s*[a-zA-Z]{2,}/i,
            /[a-zA-Z0-9._%+-]+\s+@\s+[a-zA-Z0-9.-]+\s*\.\s*[a-zA-Z]{2,}/i,
            /[a-zA-Z0-9._%+-]+\s+at\s+[a-zA-Z0-9.-]+\s+dot\s+[a-zA-Z]{2,}/i,
        ],
        
        // Phone patterns
        phonePatterns: [
            /\+\d{1,4}[\s\-\.]*\d{2,4}[\s\-\.]*\d{2,4}[\s\-\.]*\d{2,6}/i,
            /00\d{1,4}[\s\-\.]*\d{2,4}[\s\-\.]*\d{2,4}[\s\-\.]*\d{2,6}/i,
            /\b0?1[3-9]\d{8,9}\b/,
            /\(?\d{3}\)?[\s\-\.]*\d{3}[\s\-\.]*\d{4}/,
            /\b\d{3,4}[\s\-\.]+\d{3,4}[\s\-\.]+\d{3,5}\b/,
            /whatsapp[\s\:\-]*[\+]?\d[\d\s\-\.]{7,15}/i,
            /wa[\s\:\-\.]*[\+]?\d[\d\s\-\.]{7,15}/i,
            /w\/a[\s\:\-\.]*[\+]?\d[\d\s\-\.]{7,15}/i,
            /(?:call|text|msg|message|contact|reach)[\s\:\-]*(?:me)?[\s\:\-]*(?:at|on)?[\s\:\-]*[\+]?\d[\d\s\-\.]{7,15}/i,
        ],
        
        // Social media patterns
        socialPatterns: [
            /(?:facebook|fb)[\s\:\-\.\/]*(?:com\/|me\/)?[a-zA-Z0-9._]+/i,
            /(?:instagram|insta|ig)[\s\:\-\.\/]*(?:com\/)?@?[a-zA-Z0-9._]+/i,
            /(?:telegram|tg)[\s\:\-\.\/]*(?:me\/)?@?[a-zA-Z0-9._]+/i,
            /t\.me\/[a-zA-Z0-9._]+/i,
            /wa\.me\/[\d]+/i,
            /viber[\s\:\-\.\/]*[\+]?\d[\d\s\-\.]{7,15}/i,
            /imo[\s\:\-\.\/]*[\+]?\d[\d\s\-\.]{7,15}/i,
            /skype[\s\:\-\.\/]*[a-zA-Z0-9._:-]+/i,
        ],
        
        // Error messages
        errorMessages: {
            email: '<?php echo esc_js(__('Email addresses are not allowed in messages.', 'wheelfy')); ?>',
            phone: '<?php echo esc_js(__('Phone numbers are not allowed in messages.', 'wheelfy')); ?>',
            social: '<?php echo esc_js(__('Social media links/handles are not allowed in messages.', 'wheelfy')); ?>',
            generic: '<?php echo esc_js(__('Sharing contact information is not allowed.', 'wheelfy')); ?>'
        },
        
        /**
         * Check if message contains contact information
         * @param {string} message - The message to check
         * @returns {object} - { hasContact: boolean, type: string|null, message: string }
         */
        containsContactInfo: function(message) {
            // Check emails
            for (let pattern of this.emailPatterns) {
                if (pattern.test(message)) {
                    return { hasContact: true, type: 'email', message: this.errorMessages.email };
                }
            }
            
            // Check phone numbers
            for (let pattern of this.phonePatterns) {
                let match = message.match(pattern);
                if (match) {
                    // Additional validation: must contain at least 7 digits
                    let digitsOnly = match[0].replace(/\D/g, '');
                    if (digitsOnly.length >= 7) {
                        return { hasContact: true, type: 'phone', message: this.errorMessages.phone };
                    }
                }
            }
            
            // Check social media
            for (let pattern of this.socialPatterns) {
                if (pattern.test(message)) {
                    return { hasContact: true, type: 'social', message: this.errorMessages.social };
                }
            }
            
            return { hasContact: false, type: null, message: '' };
        },
        
        /**
         * Validate message and show error if invalid
         * @param {string} message - The message to validate
         * @param {HTMLElement} errorContainer - Optional element to show error in
         * @returns {boolean} - True if valid, false if contains contact info
         */
        validateMessage: function(message, errorContainer = null) {
            const result = this.containsContactInfo(message);
            
            if (result.hasContact) {
                if (errorContainer) {
                    errorContainer.textContent = result.message;
                    errorContainer.style.display = 'block';
                }
                return false;
            }
            
            if (errorContainer) {
                errorContainer.style.display = 'none';
            }
            return true;
        },
        
        /**
         * Initialize real-time validation on an input element
         * @param {HTMLElement} inputElement - The textarea/input to monitor
         * @param {HTMLElement} errorContainer - Element to show errors
         * @param {HTMLElement} submitButton - Optional submit button to disable
         */
        initRealTimeValidation: function(inputElement, errorContainer, submitButton = null) {
            if (!inputElement) return;
            
            const self = this;
            let debounceTimer;
            
            inputElement.addEventListener('input', function() {
                clearTimeout(debounceTimer);
                debounceTimer = setTimeout(function() {
                    const isValid = self.validateMessage(inputElement.value, errorContainer);
                    
                    if (submitButton) {
                        // Only disable if contains contact info (not for empty messages)
                        if (!isValid && inputElement.value.trim()) {
                            submitButton.disabled = true;
                            submitButton.classList.add('chat-blocked');
                        } else if (!inputElement.value.trim()) {
                            submitButton.disabled = true;
                        } else {
                            submitButton.disabled = false;
                            submitButton.classList.remove('chat-blocked');
                        }
                    }
                }, 300); // Debounce 300ms
            });
        }
    };
    <?php
    return ob_get_clean();
}

/**
 * AJAX endpoint for validating messages (for double-checking from frontend)
 */
function wheelfy_ajax_validate_message() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_nonce')) {
        wp_send_json_error(array('message' => __('Security check failed.', 'wheelfy')));
    }
    
    // Check if user is logged in
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => __('You must be logged in.', 'wheelfy')));
    }
    
    $message = isset($_POST['message']) ? sanitize_textarea_field($_POST['message']) : '';
    
    if (empty($message)) {
        wp_send_json_success(array('valid' => true));
    }
    
    $validation = wheelfy_validate_chat_message($message, get_current_user_id(), '', false);
    
    if ($validation['valid']) {
        wp_send_json_success(array('valid' => true));
    } else {
        wp_send_json_error(array(
            'valid' => false,
            'message' => $validation['message'],
            'pattern_type' => $validation['pattern_type']
        ));
    }
}
add_action('wp_ajax_wheelfy_validate_message', 'wheelfy_ajax_validate_message');

/**
 * Initialize chat security on theme activation
 */
function wheelfy_init_chat_security() {
    Wheelfy_Chat_Security::create_log_table();
}
add_action('after_switch_theme', 'wheelfy_init_chat_security');

// Also ensure table exists on admin_init (for updates)
add_action('admin_init', function() {
    if (get_option('wheelfy_chat_security_db_version', '') !== '1.0') {
        Wheelfy_Chat_Security::create_log_table();
        update_option('wheelfy_chat_security_db_version', '1.0');
    }
});
