<?php
/**
 * CMB2 Field Definitions for Wheelfy Theme
 * 
 * This file contains all CMB2 meta box and field definitions
 * for dynamic content management.
 * 
 * @package Wheelfy
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Prevent CMB2 from creating its own menu for header settings
 * We handle menu creation manually
 */
add_filter('cmb2_options_page_menu_title', 'wheelfy_prevent_cmb2_header_footer_menu', 10, 2);
function wheelfy_prevent_cmb2_header_footer_menu($title, $cmb_id) {
    if ($cmb_id === 'wheelfy_header_settings_metabox' || 
        $cmb_id === 'wheelfy_footer_settings_metabox' || 
        $cmb_id === 'wheelfy_contact_social_settings_metabox') {
        return false; // Prevent menu creation
    }
    return $title;
}

/**
 * Remove CMB2's auto-created menu for header settings
 */
add_action('admin_menu', 'wheelfy_remove_cmb2_header_footer_menu', 999);
function wheelfy_remove_cmb2_header_footer_menu() {
    global $submenu, $menu;
    
    // Remove from Settings menu if CMB2 added it there
    if (isset($submenu['options-general.php'])) {
        foreach ($submenu['options-general.php'] as $key => $item) {
            if (isset($item[2]) && ($item[2] === 'wheelfy-header-options' || 
                $item[2] === 'wheelfy-footer-options' || 
                $item[2] === 'wheelfy-contact-options' ||
                strpos($item[2], 'wheelfy-header') !== false || 
                strpos($item[2], 'wheelfy-footer') !== false ||
                strpos($item[2], 'wheelfy-contact') !== false)) {
                unset($submenu['options-general.php'][$key]);
            }
        }
    }
    
    // Also check for any top-level menu CMB2 might have created
    if (isset($menu)) {
        foreach ($menu as $key => $item) {
            if (isset($item[2]) && ($item[2] === 'wheelfy-header-options' || 
                $item[2] === 'wheelfy-footer-options' || 
                $item[2] === 'wheelfy-contact-options')) {
                unset($menu[$key]);
            }
        }
    }
    
    // Remove from any other parent menus
    if (isset($submenu)) {
        foreach ($submenu as $parent => $items) {
            if ($parent !== 'wheelfy-theme-options' && $parent !== 'options-general.php') {
                foreach ($items as $key => $item) {
                    if (isset($item[2]) && ($item[2] === 'wheelfy-header-options' || 
                        $item[2] === 'wheelfy-footer-options' || 
                        $item[2] === 'wheelfy-contact-options')) {
                        unset($submenu[$parent][$key]);
                    }
                }
            }
        }
    }
    
    // Remove from any other parent menus
    if (isset($submenu)) {
        foreach ($submenu as $parent => $items) {
            if ($parent !== 'wheelfy-theme-options' && $parent !== 'options-general.php') {
                foreach ($items as $key => $item) {
                    if (isset($item[2]) && ($item[2] === 'wheelfy-header-options' || $item[2] === 'wheelfy-footer-options')) {
                        unset($submenu[$parent][$key]);
                    }
                }
            }
        }
    }
}

/**
 * Register CMB2 Meta Boxes
 * This function registers all CMB2 metaboxes for the theme
 * You can add new metaboxes here or create them anywhere in the theme
 */
add_action('cmb2_admin_init', 'wheelfy_register_cmb2_metaboxes');

function wheelfy_register_cmb2_metaboxes() {
    // Ensure CMB2 is available
    if (!function_exists('new_cmb2_box')) {
        return; // CMB2 not available, skip registration
    }
    
    // ============================================
    // HOME PAGE META BOXES
    // ============================================
    
    /**
     * Hero Section Meta Box
     */
    $hero_cmb = new_cmb2_box(array(
        'id'            => 'wheelfy_hero_metabox',
        'title'         => __('Hero Section', 'wheelfy'),
        'object_types'  => array('page'),
        'show_on'       => array('key' => 'page-template', 'value' => 'page-home.php'),
        'context'       => 'normal',
        'priority'      => 'high',
        'show_names'    => true,
    ));
    
    // Hero Badge
    $hero_cmb->add_field(array(
        'name'       => __('Badge Text', 'wheelfy'),
        'desc'       => __('Text displayed in the badge above the title (e.g., "Car Maintenance")', 'wheelfy'),
        'id'         => 'hero_badge_text',
        'type'       => 'text',
        'default'    => 'Car Maintenance',
    ));
    
    // Hero Title
    $hero_cmb->add_field(array(
        'name'       => __('Hero Title', 'wheelfy'),
        'desc'       => __('Main heading text', 'wheelfy'),
        'id'         => 'hero_title',
        'type'       => 'text',
        'default'    => 'When your car needs care, we help you',
    ));
    
    // Hero Title Highlight
    $hero_cmb->add_field(array(
        'name'       => __('Hero Title Highlight', 'wheelfy'),
        'desc'       => __('Highlighted part of the title (displayed with gradient)', 'wheelfy'),
        'id'         => 'hero_title_highlight',
        'type'       => 'text',
        'default'    => 'save money',
    ));
    
    // Hero Description
    $hero_cmb->add_field(array(
        'name'       => __('Hero Description', 'wheelfy'),
        'desc'       => __('Subtitle/description text below the title', 'wheelfy'),
        'id'         => 'hero_description',
        'type'       => 'textarea_small',
        'default'    => 'Save time and money by comparing maintenance prices. Our service is completely free to use.',
    ));
    
    // Hero Background Image
    $hero_cmb->add_field(array(
        'name'       => __('Hero Background Image', 'wheelfy'),
        'desc'       => __('Upload or select the hero section background image', 'wheelfy'),
        'id'         => 'hero_background_image',
        'type'       => 'file',
        'options'    => array(
            'url' => false,
        ),
        'text'       => array(
            'add_upload_file_text' => __('Add Image', 'wheelfy'),
        ),
        'query_args' => array(
            'type' => array('image/gif', 'image/jpeg', 'image/png', 'image/webp'),
        ),
        'preview_size' => 'medium',
    ));
    
    // Hero CTA Button
    $hero_cmb->add_field(array(
        'name'       => __('CTA Button Text', 'wheelfy'),
        'desc'       => __('Call-to-action button text', 'wheelfy'),
        'id'         => 'hero_cta_text',
        'type'       => 'text',
        'default'    => 'Compare Prices',
    ));
    
    // Hero CTA Link
    $hero_cmb->add_field(array(
        'name'       => __('CTA Button Link', 'wheelfy'),
        'desc'       => __('URL for the CTA button', 'wheelfy'),
        'id'         => 'hero_cta_link',
        'type'       => 'text_url',
        'attributes' => array(
            'placeholder' => 'https://example.com',
        ),
    ));
    
    // Filter to clear old default value from hero_cta_link field when displaying
    add_filter('cmb2_get_field_value', 'wheelfy_clear_hero_cta_link_default', 10, 4);
    function wheelfy_clear_hero_cta_link_default($value, $object_id, $args, $field) {
        // Only process hero_cta_link field
        if ($field && $field->id() === 'hero_cta_link') {
            // Check if value is the old default
            $old_default = '/request-proposal?type=maintenance';
            
            // Handle array format (CMB2 text_url can store as array)
            if (is_array($value)) {
                if (isset($value['url']) && $value['url'] === $old_default) {
                    // Clear from database
                    delete_post_meta($object_id, 'hero_cta_link');
                    return ''; // Return empty for display
                } elseif (isset($value[0]) && $value[0] === $old_default) {
                    // Clear from database
                    delete_post_meta($object_id, 'hero_cta_link');
                    return ''; // Return empty for display
                }
            } elseif (is_string($value) && $value === $old_default) {
                // Clear from database
                delete_post_meta($object_id, 'hero_cta_link');
                return ''; // Return empty for display
            }
        }
        return $value;
    }
    
    // Also clear old default when saving
    add_action('cmb2_save_field_hero_cta_link', 'wheelfy_clear_hero_cta_link_on_save', 10, 3);
    function wheelfy_clear_hero_cta_link_on_save($updated, $action, $field) {
        if ($action === 'updated') {
            $value = $field->value;
            $old_default = '/request-proposal?type=maintenance';
            
            // Check if the saved value is the old default
            if (is_array($value)) {
                if ((isset($value['url']) && $value['url'] === $old_default) || 
                    (isset($value[0]) && $value[0] === $old_default)) {
                    // Clear it
                    delete_post_meta($field->object_id, 'hero_cta_link');
                }
            } elseif (is_string($value) && $value === $old_default) {
                // Clear it
                delete_post_meta($field->object_id, 'hero_cta_link');
            }
        }
    }
    
    // One-time cleanup: Clear old default value from all pages on admin load
    add_action('admin_init', 'wheelfy_cleanup_hero_cta_link_default', 1);
    function wheelfy_cleanup_hero_cta_link_default() {
        // Only run once
        if (get_option('wheelfy_hero_cta_link_cleaned') === 'yes') {
            return;
        }
        
        $old_default = '/request-proposal?type=maintenance';
        
        // Get all pages with hero_cta_link meta
        $pages = get_posts(array(
            'post_type' => 'page',
            'posts_per_page' => -1,
            'meta_key' => 'hero_cta_link',
        ));
        
        foreach ($pages as $page) {
            $value = get_post_meta($page->ID, 'hero_cta_link', true);
            
            // Check if value is the old default
            if (is_array($value)) {
                if ((isset($value['url']) && $value['url'] === $old_default) || 
                    (isset($value[0]) && $value[0] === $old_default)) {
                    delete_post_meta($page->ID, 'hero_cta_link');
                }
            } elseif (is_string($value) && $value === $old_default) {
                delete_post_meta($page->ID, 'hero_cta_link');
            }
        }
        
        // Mark as cleaned
        update_option('wheelfy_hero_cta_link_cleaned', 'yes');
    }
    
    /**
     * Services Section Meta Box
     */
    $services_cmb = new_cmb2_box(array(
        'id'            => 'wheelfy_services_metabox',
        'title'         => __('Services Section', 'wheelfy'),
        'object_types'  => array('page'),
        'show_on'       => array('key' => 'page-template', 'value' => 'page-home.php'),
        'context'       => 'normal',
        'priority'      => 'high',
        'show_names'    => true,
    ));
    
    // Section Title
    $services_cmb->add_field(array(
        'name'       => __('Section Title', 'wheelfy'),
        'desc'       => __('Main title for the services section', 'wheelfy'),
        'id'         => 'services_section_title',
        'type'       => 'text',
        'default'    => 'Maintenance Services',
    ));
    
    // Section Description
    $services_cmb->add_field(array(
        'name'       => __('Section Description', 'wheelfy'),
        'desc'       => __('Description text below the title', 'wheelfy'),
        'id'         => 'services_section_description',
        'type'       => 'textarea_small',
        'default'    => 'Browse our wide range of car maintenance services and get quotes from trusted professionals.',
    ));
    
    // Services Notice - Services will come from Service Post Type
    $services_cmb->add_field(array(
        'name'       => '',
        'desc'       => '<div style="background: linear-gradient(135deg, #D9E38D 0%, #c4d070 100%); color: #1f2937; padding: 20px 25px; border-left: 5px solid #1f2937; border-radius: 6px; font-weight: 700; font-size: 15px; margin: 15px 0; box-shadow: 0 2px 8px rgba(0,0,0,0.1); line-height: 1.6;"><span style="font-size: 20px; margin-right: 8px;">ℹ️</span><strong style="text-transform: uppercase; letter-spacing: 0.5px;">Services Information:</strong><br><br>Services will be automatically displayed from the <strong style="background: rgba(31, 41, 55, 0.1); padding: 2px 8px; border-radius: 3px;">Service Post Type</strong>. Create and manage services from the <strong>Services</strong> menu in the WordPress admin sidebar.</div>',
        'id'         => 'services_notice',
        'type'       => 'title',
    ));
    
    /**
     * Benefits Section Meta Box
     */
    $benefits_cmb = new_cmb2_box(array(
        'id'            => 'wheelfy_benefits_metabox',
        'title'         => __('Benefits Section', 'wheelfy'),
        'object_types'  => array('page'),
        'show_on'       => array('key' => 'page-template', 'value' => 'page-home.php'),
        'context'       => 'normal',
        'priority'      => 'high',
        'show_names'    => true,
    ));
    
    // Benefits Section Title
    $benefits_cmb->add_field(array(
        'name'       => __('Section Title', 'wheelfy'),
        'desc'       => __('Main title for the benefits section', 'wheelfy'),
        'id'         => 'benefits_section_title',
        'type'       => 'text',
        'default'    => 'Why choose our',
    ));
    
    // Benefits Section Title Highlight
    $benefits_cmb->add_field(array(
        'name'       => __('Section Title Highlight', 'wheelfy'),
        'desc'       => __('Highlighted part of the title', 'wheelfy'),
        'id'         => 'benefits_section_title_highlight',
        'type'       => 'text',
        'default'    => 'maintenance platform?',
    ));
    
    // Benefits Description
    $benefits_cmb->add_field(array(
        'name'       => __('Section Description', 'wheelfy'),
        'desc'       => __('Description text for the benefits section', 'wheelfy'),
        'id'         => 'benefits_section_description',
        'type'       => 'textarea_small',
        'default'    => 'We\'ve partnered with hundreds of verified garages and workshops to bring you the best prices and service quality.',
    ));
    
    // Benefits Repeater Group
    $benefits_group = $benefits_cmb->add_field(array(
        'id'          => 'benefits_repeater',
        'type'        => 'group',
        'description' => __('Add benefit items. Click "Add Benefit" to add more.', 'wheelfy'),
        'options'     => array(
            'group_title'   => __('Benefit {#}', 'wheelfy'),
            'add_button'    => __('Add Benefit', 'wheelfy'),
            'remove_button' => __('Remove Benefit', 'wheelfy'),
            'sortable'      => true,
            'closed'        => false,
        ),
    ));
    
    // Benefit Text
    $benefits_cmb->add_group_field($benefits_group, array(
        'name'       => __('Benefit Text', 'wheelfy'),
        'desc'       => __('Text for this benefit item', 'wheelfy'),
        'id'         => 'benefit_text',
        'type'       => 'text',
    ));
    
    // CTA Card Section
    $benefits_cmb->add_field(array(
        'name'       => __('CTA Card Title', 'wheelfy'),
        'desc'       => __('Title for the CTA card on the right side', 'wheelfy'),
        'id'         => 'benefits_cta_title',
        'type'       => 'text',
        'default'    => 'Get a Free Quote',
    ));
    
    $benefits_cmb->add_field(array(
        'name'       => __('CTA Card Description', 'wheelfy'),
        'desc'       => __('Description text for the CTA card', 'wheelfy'),
        'id'         => 'benefits_cta_description',
        'type'       => 'textarea_small',
        'default'    => 'Tell us about your car and the service you need. We\'ll connect you with the best providers.',
    ));
    
    $benefits_cmb->add_field(array(
        'name'       => __('CTA Button Text', 'wheelfy'),
        'desc'       => __('Button text for the CTA card', 'wheelfy'),
        'id'         => 'benefits_cta_button_text',
        'type'       => 'text',
        'default'    => 'Start Your Request',
    ));
    
    $benefits_cmb->add_field(array(
        'name'       => __('CTA Button Link', 'wheelfy'),
        'desc'       => __('URL for the CTA button', 'wheelfy'),
        'id'         => 'benefits_cta_button_link',
        'type'       => 'text_url',
        'attributes' => array(
            'placeholder' => 'https://example.com',
        ),
    ));
    
    // Filter to clear old default value from benefits_cta_button_link field
    add_filter('cmb2_get_field_value', 'wheelfy_clear_benefits_cta_link_default', 10, 4);
    function wheelfy_clear_benefits_cta_link_default($value, $object_id, $args, $field) {
        // Only process benefits_cta_button_link field
        if ($field && $field->id() === 'benefits_cta_button_link') {
            // Check if value is the old default
            $old_default = '/request-proposal?type=maintenance';
            
            // Handle array format (CMB2 text_url can store as array)
            if (is_array($value)) {
                if (isset($value['url']) && $value['url'] === $old_default) {
                    // Clear from database
                    delete_post_meta($object_id, 'benefits_cta_button_link');
                    return ''; // Return empty for display
                } elseif (isset($value[0]) && $value[0] === $old_default) {
                    // Clear from database
                    delete_post_meta($object_id, 'benefits_cta_button_link');
                    return ''; // Return empty for display
                }
            } elseif (is_string($value) && $value === $old_default) {
                // Clear from database
                delete_post_meta($object_id, 'benefits_cta_button_link');
                return ''; // Return empty for display
            }
        }
        return $value;
    }
    
    // Also clear old default when saving
    add_action('cmb2_save_field_benefits_cta_button_link', 'wheelfy_clear_benefits_cta_link_on_save', 10, 3);
    function wheelfy_clear_benefits_cta_link_on_save($updated, $action, $field) {
        if ($action === 'updated') {
            $value = $field->value;
            $old_default = '/request-proposal?type=maintenance';
            
            // Check if the saved value is the old default
            if (is_array($value)) {
                if ((isset($value['url']) && $value['url'] === $old_default) || 
                    (isset($value[0]) && $value[0] === $old_default)) {
                    // Clear it
                    delete_post_meta($field->object_id, 'benefits_cta_button_link');
                }
            } elseif (is_string($value) && $value === $old_default) {
                // Clear it
                delete_post_meta($field->object_id, 'benefits_cta_button_link');
            }
        }
    }
    
    // One-time cleanup: Clear old default value from all pages on admin load
    add_action('admin_init', 'wheelfy_cleanup_benefits_cta_link_default', 1);
    function wheelfy_cleanup_benefits_cta_link_default() {
        // Only run once
        if (get_option('wheelfy_benefits_cta_link_cleaned') === 'yes') {
            return;
        }
        
        $old_default = '/request-proposal?type=maintenance';
        
        // Get all pages with benefits_cta_button_link meta
        $pages = get_posts(array(
            'post_type' => 'page',
            'posts_per_page' => -1,
            'meta_key' => 'benefits_cta_button_link',
        ));
        
        foreach ($pages as $page) {
            $value = get_post_meta($page->ID, 'benefits_cta_button_link', true);
            
            // Check if value is the old default
            if (is_array($value)) {
                if ((isset($value['url']) && $value['url'] === $old_default) || 
                    (isset($value[0]) && $value[0] === $old_default)) {
                    delete_post_meta($page->ID, 'benefits_cta_button_link');
                }
            } elseif (is_string($value) && $value === $old_default) {
                delete_post_meta($page->ID, 'benefits_cta_button_link');
            }
        }
        
        // Mark as cleaned
        update_option('wheelfy_benefits_cta_link_cleaned', 'yes');
    }
    
    /**
     * Features Section Meta Box
     */
    $features_cmb = new_cmb2_box(array(
        'id'            => 'wheelfy_features_metabox',
        'title'         => __('Features Section', 'wheelfy'),
        'object_types'  => array('page'),
        'show_on'       => array('key' => 'page-template', 'value' => 'page-home.php'),
        'context'       => 'normal',
        'priority'      => 'high',
        'show_names'    => true,
    ));
    
    // Features Repeater Group
    $features_group = $features_cmb->add_field(array(
        'id'          => 'features_repeater',
        'type'        => 'group',
        'description' => __('Add feature cards. Click "Add Feature" to add more.', 'wheelfy'),
        'options'     => array(
            'group_title'   => __('Feature {#}', 'wheelfy'),
            'add_button'    => __('Add Feature', 'wheelfy'),
            'remove_button' => __('Remove Feature', 'wheelfy'),
            'sortable'      => true,
            'closed'        => false,
        ),
    ));
    
    // Feature Icon (select from common icons)
    $features_cmb->add_group_field($features_group, array(
        'name'       => __('Icon', 'wheelfy'),
        'desc'       => __('Select an icon for this feature', 'wheelfy'),
        'id'         => 'feature_icon',
        'type'       => 'select',
        'options'    => array(
            'dollar-sign' => 'Dollar Sign (Save Money)',
            'clock' => 'Clock (Save Time)',
            'shield' => 'Shield (Free to Use)',
            'star' => 'Star (Verified Partners)',
            'check-circle' => 'Check Circle',
            'user' => 'User',
            'car' => 'Car',
            'wrench' => 'Wrench',
        ),
        'default'    => 'dollar-sign',
    ));
    
    // Feature Title
    $features_cmb->add_group_field($features_group, array(
        'name'       => __('Title', 'wheelfy'),
        'desc'       => __('Feature title', 'wheelfy'),
        'id'         => 'feature_title',
        'type'       => 'text',
    ));
    
    // Feature Description
    $features_cmb->add_group_field($features_group, array(
        'name'       => __('Description', 'wheelfy'),
        'desc'       => __('Feature description', 'wheelfy'),
        'id'         => 'feature_description',
        'type'       => 'textarea_small',
    ));
    
    // Set default features when page is first created or when field is empty
    add_action('save_post', 'wheelfy_set_default_features', 10, 2);
    function wheelfy_set_default_features($post_id, $post) {
        // Only for pages with Home template
        if ($post->post_type !== 'page') {
            return;
        }
        
        $template = get_post_meta($post_id, '_wp_page_template', true);
        if ($template !== 'page-home.php') {
            return;
        }
        
        // Check if features already exist
        $existing_features = get_post_meta($post_id, 'features_repeater', true);
        if (!empty($existing_features) && is_array($existing_features) && count($existing_features) > 0) {
            return; // Don't override if features already exist
        }
        
        // Set default features
        $default_features = array(
            array(
                'feature_icon' => 'dollar-sign',
                'feature_title' => 'Save Money',
                'feature_description' => 'Compare prices from multiple providers and get the best deal',
            ),
            array(
                'feature_icon' => 'clock',
                'feature_title' => 'Save Time',
                'feature_description' => 'Get multiple offers in one place without visiting each shop',
            ),
            array(
                'feature_icon' => 'shield',
                'feature_title' => 'Free to Use',
                'feature_description' => 'Our comparison service is completely free for customers',
            ),
            array(
                'feature_icon' => 'star',
                'feature_title' => 'Verified Partners',
                'feature_description' => 'Work only with trusted and reviewed service providers',
            ),
        );
        
        update_post_meta($post_id, 'features_repeater', $default_features);
    }
    
    // Filter to show default features when field is empty
    add_filter('cmb2_get_field_value', 'wheelfy_get_default_features', 10, 4);
    function wheelfy_get_default_features($value, $object_id, $args, $field) {
        // Only for features_repeater field
        if ($field->id() !== 'features_repeater') {
            return $value;
        }
        
        // Check if we're on a page with Home template
        $template = get_post_meta($object_id, '_wp_page_template', true);
        if ($template !== 'page-home.php') {
            return $value;
        }
        
        // If value is empty, return defaults
        if (empty($value) || !is_array($value) || count($value) === 0) {
            return array(
                array(
                    'feature_icon' => 'dollar-sign',
                    'feature_title' => 'Save Money',
                    'feature_description' => 'Compare prices from multiple providers and get the best deal',
                ),
                array(
                    'feature_icon' => 'clock',
                    'feature_title' => 'Save Time',
                    'feature_description' => 'Get multiple offers in one place without visiting each shop',
                ),
                array(
                    'feature_icon' => 'shield',
                    'feature_title' => 'Free to Use',
                    'feature_description' => 'Our comparison service is completely free for customers',
                ),
                array(
                    'feature_icon' => 'star',
                    'feature_title' => 'Verified Partners',
                    'feature_description' => 'Work only with trusted and reviewed service providers',
                ),
            );
        }
        
        return $value;
    }
    
    /**
     * How It Works Section Meta Box
     */
    $how_it_works_cmb = new_cmb2_box(array(
        'id'            => 'wheelfy_how_it_works_metabox',
        'title'         => __('How It Works Section', 'wheelfy'),
        'object_types'  => array('page'),
        'show_on'       => array('key' => 'page-template', 'value' => 'page-home.php'),
        'context'       => 'normal',
        'priority'      => 'high',
        'show_names'    => true,
    ));
    
    // Section Title
    $how_it_works_cmb->add_field(array(
        'name'       => __('Section Title', 'wheelfy'),
        'desc'       => __('Main title for the How It Works section', 'wheelfy'),
        'id'         => 'how_it_works_title',
        'type'       => 'text',
        'default'    => 'How It Works',
    ));
    
    // Section Description
    $how_it_works_cmb->add_field(array(
        'name'       => __('Section Description', 'wheelfy'),
        'desc'       => __('Description text below the title', 'wheelfy'),
        'id'         => 'how_it_works_description',
        'type'       => 'textarea_small',
        'default'    => 'Compare prices easily and totally free. We\'ve made the process simple so you can focus on what matters.',
    ));
    
    // Steps Repeater Group
    $steps_group = $how_it_works_cmb->add_field(array(
        'id'          => 'how_it_works_steps',
        'type'        => 'group',
        'description' => __('Add steps. Click "Add Step" to add more.', 'wheelfy'),
        'options'     => array(
            'group_title'   => __('Step {#}', 'wheelfy'),
            'add_button'    => __('Add Step', 'wheelfy'),
            'remove_button' => __('Remove Step', 'wheelfy'),
            'sortable'      => true,
            'closed'        => false,
        ),
    ));
    
    // Step Number
    $how_it_works_cmb->add_group_field($steps_group, array(
        'name'       => __('Step Number', 'wheelfy'),
        'desc'       => __('Step number (e.g., 01, 02, 03, 04)', 'wheelfy'),
        'id'         => 'step_number',
        'type'       => 'text_small',
    ));
    
    // Step Icon
    $how_it_works_cmb->add_group_field($steps_group, array(
        'name'       => __('Icon', 'wheelfy'),
        'desc'       => __('Select an icon for this step', 'wheelfy'),
        'id'         => 'step_icon',
        'type'       => 'select',
        'options'    => array(
            'user-plus' => 'User Plus (Register)',
            'car' => 'Car (Car Details)',
            'calendar' => 'Calendar (Schedule)',
            'send' => 'Send (Receive Offers)',
            'bell' => 'Bell (Notifications)',
            'check-circle' => 'Check Circle (Choose & Save)',
            'file-text' => 'File Text',
            'message-square' => 'Message Square',
            'credit-card' => 'Credit Card',
            'shield' => 'Shield (Security)',
            'star' => 'Star (Rating)',
            'clock' => 'Clock (Time)',
            'dollar-sign' => 'Dollar Sign (Money)',
            'wrench' => 'Wrench (Service)',
            'search' => 'Search',
            'heart' => 'Heart',
        ),
    ));
    
    // Step Title
    $how_it_works_cmb->add_group_field($steps_group, array(
        'name'       => __('Title', 'wheelfy'),
        'desc'       => __('Step title', 'wheelfy'),
        'id'         => 'step_title',
        'type'       => 'text',
    ));
    
    // Step Description
    $how_it_works_cmb->add_group_field($steps_group, array(
        'name'       => __('Description', 'wheelfy'),
        'desc'       => __('Step description', 'wheelfy'),
        'id'         => 'step_description',
        'type'       => 'textarea_small',
    ));
    
    // CTA Button Text
    $how_it_works_cmb->add_field(array(
        'name'       => __('CTA Button Text', 'wheelfy'),
        'desc'       => __('Button text below the steps', 'wheelfy'),
        'id'         => 'how_it_works_cta_text',
        'type'       => 'text',
        'default'    => 'Start Comparing Prices',
    ));
    
    // CTA Button Link
    $how_it_works_cmb->add_field(array(
        'name'       => __('CTA Button Link', 'wheelfy'),
        'desc'       => __('URL for the CTA button', 'wheelfy'),
        'id'         => 'how_it_works_cta_link',
        'type'       => 'text_url',
        'attributes' => array(
            'placeholder' => 'https://example.com',
        ),
    ));
    
    // Set default steps when page is first created or when field is empty
    add_filter('cmb2_get_field_value', 'wheelfy_set_default_how_it_works_steps', 10, 3);
    function wheelfy_set_default_how_it_works_steps($value, $object_id, $args) {
        // Only for how_it_works_steps field
        if ($args['field_id'] !== 'how_it_works_steps') {
            return $value;
        }
        
        // Only for pages with Home template
        $template = get_post_meta($object_id, '_wp_page_template', true);
        if ($template !== 'page-home.php') {
            return $value;
        }
        
        // If value is empty or not an array, set defaults
        if (empty($value) || !is_array($value)) {
            return array(
                array(
                    'step_number' => '01',
                    'step_icon' => 'user-plus',
                    'step_title' => 'Register for Free',
                    'step_description' => 'Create your account in seconds. It\'s completely free and takes less than a minute.',
                ),
                array(
                    'step_number' => '02',
                    'step_icon' => 'car',
                    'step_title' => 'Enter Car Details',
                    'step_description' => 'Provide information about your vehicle and the service you need.',
                ),
                array(
                    'step_number' => '03',
                    'step_icon' => 'send',
                    'step_title' => 'Receive Offers',
                    'step_description' => 'Get competitive offers from verified service providers and dealerships.',
                ),
                array(
                    'step_number' => '04',
                    'step_icon' => 'check-circle',
                    'step_title' => 'Choose & Save',
                    'step_description' => 'Compare offers, choose the best one, and save money on your service.',
                ),
            );
        }
        
        return $value;
    }
    
    /**
     * Testimonials Section Meta Box
     */
    $testimonials_cmb = new_cmb2_box(array(
        'id'            => 'wheelfy_testimonials_metabox',
        'title'         => __('Testimonials Section', 'wheelfy'),
        'object_types'  => array('page'),
        'show_on'       => array('key' => 'page-template', 'value' => 'page-home.php'),
        'context'       => 'normal',
        'priority'      => 'high',
        'show_names'    => true,
    ));
    
    // Section Title
    $testimonials_cmb->add_field(array(
        'name'       => __('Section Title', 'wheelfy'),
        'desc'       => __('Main title for the testimonials section', 'wheelfy'),
        'id'         => 'testimonials_title',
        'type'       => 'text',
        'default'    => 'What Our Customers Say',
    ));
    
    // Section Description
    $testimonials_cmb->add_field(array(
        'name'       => __('Section Description', 'wheelfy'),
        'desc'       => __('Description text below the title', 'wheelfy'),
        'id'         => 'testimonials_description',
        'type'       => 'textarea_small',
        'default'    => 'Join thousands of satisfied car owners who have saved time and money.',
    ));
    
    // Testimonials Repeater Group
    $testimonials_group = $testimonials_cmb->add_field(array(
        'id'          => 'testimonials_repeater',
        'type'        => 'group',
        'description' => __('Add customer testimonials. Click "Add Testimonial" to add more.', 'wheelfy'),
        'options'     => array(
            'group_title'   => __('Testimonial {#}', 'wheelfy'),
            'add_button'    => __('Add Testimonial', 'wheelfy'),
            'remove_button' => __('Remove Testimonial', 'wheelfy'),
            'sortable'      => true,
            'closed'        => false,
        ),
    ));
    
    // Customer Name
    $testimonials_cmb->add_group_field($testimonials_group, array(
        'name'       => __('Customer Name', 'wheelfy'),
        'desc'       => __('Name of the customer', 'wheelfy'),
        'id'         => 'testimonial_name',
        'type'       => 'text',
    ));
    
    // Car Model
    $testimonials_cmb->add_group_field($testimonials_group, array(
        'name'       => __('Car Model', 'wheelfy'),
        'desc'       => __('Customer\'s car model', 'wheelfy'),
        'id'         => 'testimonial_car',
        'type'       => 'text',
    ));
    
    // Savings Amount
    $testimonials_cmb->add_group_field($testimonials_group, array(
        'name'       => __('Savings Amount', 'wheelfy'),
        'desc'       => __('Amount saved (e.g., €340, €2,500)', 'wheelfy'),
        'id'         => 'testimonial_savings',
        'type'       => 'text',
    ));
    
    // Quote/Testimonial Text
    $testimonials_cmb->add_group_field($testimonials_group, array(
        'name'       => __('Quote', 'wheelfy'),
        'desc'       => __('Customer testimonial quote', 'wheelfy'),
        'id'         => 'testimonial_quote',
        'type'       => 'textarea',
    ));
    
    // Rating
    $testimonials_cmb->add_group_field($testimonials_group, array(
        'name'       => __('Rating', 'wheelfy'),
        'desc'       => __('Star rating (1-5)', 'wheelfy'),
        'id'         => 'testimonial_rating',
        'type'       => 'select',
        'options'    => array(
            '1' => '1 Star',
            '2' => '2 Stars',
            '3' => '3 Stars',
            '4' => '4 Stars',
            '5' => '5 Stars',
        ),
        'default'    => '5',
    ));
    
    // Set default testimonials when page is first created or when field is empty
    add_filter('cmb2_get_field_value', 'wheelfy_set_default_testimonials_repeater', 10, 3);
    function wheelfy_set_default_testimonials_repeater($value, $object_id, $args) {
        // Only for testimonials_repeater field
        if ($args['field_id'] !== 'testimonials_repeater') {
            return $value;
        }
        
        // Only for pages with Home template
        $template = get_post_meta($object_id, '_wp_page_template', true);
        if ($template !== 'page-home.php') {
            return $value;
        }
        
        // If value is empty or not an array, set defaults
        if (empty($value) || !is_array($value)) {
            return array(
                array(
                    'testimonial_name' => 'Michael Schmidt',
                    'testimonial_car' => 'BMW 320d',
                    'testimonial_savings' => '€340',
                    'testimonial_quote' => 'I saved over €340 on my brake service. The process was incredibly simple and I received 5 offers within 24 hours.',
                    'testimonial_rating' => '5',
                ),
                array(
                    'testimonial_name' => 'Anna Kovács',
                    'testimonial_car' => 'Tesla Model 3',
                    'testimonial_savings' => '€2,500',
                    'testimonial_quote' => 'Sold my Tesla in just 3 days. Got 15 offers from dealerships and chose the highest bidder. Highly recommended!',
                    'testimonial_rating' => '5',
                ),
                array(
                    'testimonial_name' => 'Peter Nagy',
                    'testimonial_car' => 'VW Golf',
                    'testimonial_savings' => '€180',
                    'testimonial_quote' => 'Great service for comparing tire prices. Found a trusted shop near me with excellent reviews.',
                    'testimonial_rating' => '5',
                ),
            );
        }
        
        return $value;
    }
    
    /**
     * How It Works Page - Hero Section Meta Box
     */
    $hiw_hero_cmb = new_cmb2_box(array(
        'id'            => 'wheelfy_hiw_hero_metabox',
        'title'         => __('Hero Section', 'wheelfy'),
        'object_types'  => array('page'),
        'show_on'       => array('key' => 'page-template', 'value' => 'page-how-it-works.php'),
        'context'       => 'normal',
        'priority'      => 'high',
        'show_names'    => true,
    ));
    
    $hiw_hero_cmb->add_field(array(
        'name'       => __('Hero Background Image', 'wheelfy'),
        'desc'       => __('Background image for the hero section', 'wheelfy'),
        'id'         => 'hiw_hero_background_image',
        'type'       => 'file',
        'options'    => array(
            'url' => false,
        ),
        'text'       => array(
            'add_upload_file_text' => __('Add Background Image', 'wheelfy'),
        ),
        'query_args' => array(
            'type' => array('image/gif', 'image/jpeg', 'image/png', 'image/webp'),
        ),
        'preview_size' => 'medium',
    ));
    
    $hiw_hero_cmb->add_field(array(
        'name'       => __('Badge Text', 'wheelfy'),
        'desc'       => __('Text for the badge above the title', 'wheelfy'),
        'id'         => 'hiw_hero_badge',
        'type'       => 'text',
        'default'    => 'Simple Process',
    ));
    
    $hiw_hero_cmb->add_field(array(
        'name'       => __('Hero Title', 'wheelfy'),
        'desc'       => __('Main title for the hero section', 'wheelfy'),
        'id'         => 'hiw_hero_title_text',
        'type'       => 'text',
        'default'    => 'How It Works',
    ));
    
    $hiw_hero_cmb->add_field(array(
        'name'       => __('Hero Subtitle', 'wheelfy'),
        'desc'       => __('Subtitle/Highlight text below main title', 'wheelfy'),
        'id'         => 'hiw_hero_subtitle',
        'type'       => 'text',
        'default'    => 'Save Time & Money',
    ));
    
    $hiw_hero_cmb->add_field(array(
        'name'       => __('Hero Description', 'wheelfy'),
        'desc'       => __('Description text below the title', 'wheelfy'),
        'id'         => 'hiw_hero_description',
        'type'       => 'textarea_small',
        'default'    => 'Getting started is easy. Follow these simple steps to compare prices and save money on your car services.',
    ));
    
    $hiw_hero_cmb->add_field(array(
        'name'       => __('Hero Button Text', 'wheelfy'),
        'desc'       => __('Text for the hero button', 'wheelfy'),
        'id'         => 'hiw_hero_button_text',
        'type'       => 'text',
        'default'    => 'Get Started',
    ));
    
    $hiw_hero_cmb->add_field(array(
        'name'       => __('Hero Button Link', 'wheelfy'),
        'desc'       => __('URL for the hero button', 'wheelfy'),
        'id'         => 'hiw_hero_button_link',
        'type'       => 'text_url',
        'attributes' => array(
            'placeholder' => '/request-proposal',
        ),
    ));
    
    /**
     * How It Works Page - Main Steps Section Meta Box
     */
    $hiw_steps_cmb = new_cmb2_box(array(
        'id'            => 'wheelfy_hiw_steps_metabox',
        'title'         => __('Main Steps Section', 'wheelfy'),
        'object_types'  => array('page'),
        'show_on'       => array('key' => 'page-template', 'value' => 'page-how-it-works.php'),
        'context'       => 'normal',
        'priority'      => 'high',
        'show_names'    => true,
    ));
    
    $hiw_steps_group = $hiw_steps_cmb->add_field(array(
        'id'          => 'hiw_main_steps',
        'type'        => 'group',
        'description' => __('Add main steps. Click "Add Step" to add more.', 'wheelfy'),
        'options'     => array(
            'group_title'   => __('Step {#}', 'wheelfy'),
            'add_button'    => __('Add Step', 'wheelfy'),
            'remove_button' => __('Remove Step', 'wheelfy'),
            'sortable'      => true,
            'closed'        => false,
        ),
    ));
    
    $hiw_steps_cmb->add_group_field($hiw_steps_group, array(
        'name'       => __('Step Number', 'wheelfy'),
        'desc'       => __('Step number (e.g., 01, 02, 03, 04)', 'wheelfy'),
        'id'         => 'number',
        'type'       => 'text_small',
    ));
    
    $hiw_steps_cmb->add_group_field($hiw_steps_group, array(
        'name'       => __('Icon', 'wheelfy'),
        'desc'       => __('Select an icon for this step', 'wheelfy'),
        'id'         => 'icon',
        'type'       => 'select',
        'options'    => array(
            'user-plus' => 'User Plus (Register)',
            'car' => 'Car (Car Details)',
            'calendar' => 'Calendar (Schedule)',
            'send' => 'Send (Receive Offers)',
            'bell' => 'Bell (Notifications)',
            'check-circle' => 'Check Circle (Choose & Save)',
            'file-text' => 'File Text',
            'message-square' => 'Message Square',
            'credit-card' => 'Credit Card',
            'shield' => 'Shield (Security)',
            'star' => 'Star (Rating)',
            'clock' => 'Clock (Time)',
            'dollar-sign' => 'Dollar Sign (Money)',
            'wrench' => 'Wrench (Service)',
            'search' => 'Search',
            'heart' => 'Heart',
        ),
    ));
    
    $hiw_steps_cmb->add_group_field($hiw_steps_group, array(
        'name'       => __('Title', 'wheelfy'),
        'desc'       => __('Step title', 'wheelfy'),
        'id'         => 'title',
        'type'       => 'text',
    ));
    
    $hiw_steps_cmb->add_group_field($hiw_steps_group, array(
        'name'       => __('Description', 'wheelfy'),
        'desc'       => __('Step description', 'wheelfy'),
        'id'         => 'description',
        'type'       => 'textarea_small',
    ));
    
    /**
     * How It Works Page - Additional Features Section Meta Box
     */
    $hiw_features_cmb = new_cmb2_box(array(
        'id'            => 'wheelfy_hiw_features_metabox',
        'title'         => __('Additional Features Section', 'wheelfy'),
        'object_types'  => array('page'),
        'show_on'       => array('key' => 'page-template', 'value' => 'page-how-it-works.php'),
        'context'       => 'normal',
        'priority'      => 'high',
        'show_names'    => true,
    ));
    
    $hiw_features_cmb->add_field(array(
        'name'       => __('Section Title', 'wheelfy'),
        'desc'       => __('Title for the additional features section', 'wheelfy'),
        'id'         => 'hiw_features_section_title',
        'type'       => 'text',
        'default'    => 'Additional Features',
    ));
    
    $hiw_features_cmb->add_field(array(
        'name'       => __('Section Description', 'wheelfy'),
        'desc'       => __('Description text below the section title', 'wheelfy'),
        'id'         => 'hiw_features_section_description',
        'type'       => 'textarea_small',
        'default'    => 'Our platform offers more than just price comparison.',
    ));
    
    $hiw_features_group = $hiw_features_cmb->add_field(array(
        'id'          => 'hiw_additional_features',
        'type'        => 'group',
        'description' => __('Add additional features. Click "Add Feature" to add more.', 'wheelfy'),
        'options'     => array(
            'group_title'   => __('Feature {#}', 'wheelfy'),
            'add_button'    => __('Add Feature', 'wheelfy'),
            'remove_button' => __('Remove Feature', 'wheelfy'),
            'sortable'      => true,
            'closed'        => false,
        ),
    ));
    
    $hiw_features_cmb->add_group_field($hiw_features_group, array(
        'name'       => __('Icon', 'wheelfy'),
        'desc'       => __('Select an icon for this feature', 'wheelfy'),
        'id'         => 'icon',
        'type'       => 'select',
        'options'    => array(
            'message-square' => 'Message Square',
            'credit-card' => 'Credit Card',
            'star' => 'Star (Rating)',
            'shield' => 'Shield (Security)',
            'clock' => 'Clock (Time)',
            'dollar-sign' => 'Dollar Sign (Money)',
            'wrench' => 'Wrench (Service)',
            'search' => 'Search',
            'heart' => 'Heart',
            'user-plus' => 'User Plus',
            'car' => 'Car',
        ),
    ));
    
    $hiw_features_cmb->add_group_field($hiw_features_group, array(
        'name'       => __('Title', 'wheelfy'),
        'desc'       => __('Feature title', 'wheelfy'),
        'id'         => 'title',
        'type'       => 'text',
    ));
    
    $hiw_features_cmb->add_group_field($hiw_features_group, array(
        'name'       => __('Description', 'wheelfy'),
        'desc'       => __('Feature description', 'wheelfy'),
        'id'         => 'description',
        'type'       => 'textarea_small',
    ));
    
    /**
     * How It Works Page - CTA Section Meta Box
     */
    $hiw_cta_cmb = new_cmb2_box(array(
        'id'            => 'wheelfy_hiw_cta_metabox',
        'title'         => __('CTA Section', 'wheelfy'),
        'object_types'  => array('page'),
        'show_on'       => array('key' => 'page-template', 'value' => 'page-how-it-works.php'),
        'context'       => 'normal',
        'priority'      => 'high',
        'show_names'    => true,
    ));
    
    $hiw_cta_cmb->add_field(array(
        'name'       => __('CTA Title', 'wheelfy'),
        'desc'       => __('Title for the CTA section', 'wheelfy'),
        'id'         => 'hiw_cta_title_text',
        'type'       => 'text',
        'default'    => 'Ready to get started?',
    ));
    
    $hiw_cta_cmb->add_field(array(
        'name'       => __('CTA Description', 'wheelfy'),
        'desc'       => __('Description text below the CTA title', 'wheelfy'),
        'id'         => 'hiw_cta_description',
        'type'       => 'textarea_small',
        'default'    => 'Join thousands of car owners who are already saving time and money.',
    ));
    
    $hiw_cta_cmb->add_field(array(
        'name'       => __('CTA Button Text', 'wheelfy'),
        'desc'       => __('Text for the CTA button', 'wheelfy'),
        'id'         => 'hiw_cta_button_text',
        'type'       => 'text',
        'default'    => 'Submit a Request',
    ));
    
    $hiw_cta_cmb->add_field(array(
        'name'       => __('CTA Button Link', 'wheelfy'),
        'desc'       => __('URL for the CTA button', 'wheelfy'),
        'id'         => 'hiw_cta_button_link',
        'type'       => 'text_url',
        'attributes' => array(
            'placeholder' => '/request-proposal',
        ),
    ));
    
    /**
     * Car Sales Page - Hero Section Meta Box
     */
    $sales_hero_cmb = new_cmb2_box(array(
        'id'            => 'wheelfy_sales_hero_metabox',
        'title'         => __('Hero Section', 'wheelfy'),
        'object_types'  => array('page'),
        'show_on'       => array('key' => 'page-template', 'value' => 'page-car-sales.php'),
        'context'       => 'normal',
        'priority'      => 'high',
        'show_names'    => true,
    ));
    
    $sales_hero_cmb->add_field(array(
        'name'       => __('Badge Text', 'wheelfy'),
        'desc'       => __('Text for the badge above the title', 'wheelfy'),
        'id'         => 'sales_hero_badge',
        'type'       => 'text',
        'default'    => 'Car Sales',
    ));
    
    $sales_hero_cmb->add_field(array(
        'name'       => __('Hero Title', 'wheelfy'),
        'desc'       => __('Main title for the hero section', 'wheelfy'),
        'id'         => 'sales_hero_title_text',
        'type'       => 'text',
        'default'    => 'Sell your car easily and at the',
    ));
    
    $sales_hero_cmb->add_field(array(
        'name'       => __('Hero Subtitle', 'wheelfy'),
        'desc'       => __('Subtitle/Highlight text below main title', 'wheelfy'),
        'id'         => 'sales_hero_subtitle',
        'type'       => 'text',
        'default'    => 'best price',
    ));
    
    $sales_hero_cmb->add_field(array(
        'name'       => __('Hero Description', 'wheelfy'),
        'desc'       => __('Description text below the title', 'wheelfy'),
        'id'         => 'sales_hero_description',
        'type'       => 'textarea_small',
        'default'    => 'Compete with car dealers and sell your car to the highest bidder. For free.',
    ));
    
    $sales_hero_cmb->add_field(array(
        'name'       => __('Hero Button Text', 'wheelfy'),
        'desc'       => __('Text for the hero button', 'wheelfy'),
        'id'         => 'sales_hero_button_text',
        'type'       => 'text',
        'default'    => 'Start Here',
    ));
    
    $sales_hero_cmb->add_field(array(
        'name'       => __('Hero Button Link', 'wheelfy'),
        'desc'       => __('URL for the hero button', 'wheelfy'),
        'id'         => 'sales_hero_button_link',
        'type'       => 'text_url',
        'default'    => '/request-proposal?type=sales',
        'attributes' => array(
            'placeholder' => '/request-proposal?type=sales',
        ),
    ));
    
    /**
     * Car Sales Page - Steps Section Meta Box
     */
    $sales_steps_cmb = new_cmb2_box(array(
        'id'            => 'wheelfy_sales_steps_metabox',
        'title'         => __('Steps Section', 'wheelfy'),
        'object_types'  => array('page'),
        'show_on'       => array('key' => 'page-template', 'value' => 'page-car-sales.php'),
        'context'       => 'normal',
        'priority'      => 'high',
        'show_names'    => true,
    ));
    
    $sales_steps_cmb->add_field(array(
        'name'       => __('Section Title', 'wheelfy'),
        'desc'       => __('Title for the steps section', 'wheelfy'),
        'id'         => 'sales_steps_section_title',
        'type'       => 'text',
        'default'    => 'How to sell your car',
    ));
    
    $sales_steps_cmb->add_field(array(
        'name'       => __('Section Description', 'wheelfy'),
        'desc'       => __('Description text below the section title', 'wheelfy'),
        'id'         => 'sales_steps_section_description',
        'type'       => 'textarea_small',
        'default'    => 'Three simple steps to sell your car at the best price.',
    ));
    
    $sales_steps_group = $sales_steps_cmb->add_field(array(
        'id'          => 'sales_steps',
        'type'        => 'group',
        'description' => __('Add steps. Click "Add Step" to add more.', 'wheelfy'),
        'options'     => array(
            'group_title'   => __('Step {#}', 'wheelfy'),
            'add_button'    => __('Add Step', 'wheelfy'),
            'remove_button' => __('Remove Step', 'wheelfy'),
            'sortable'      => true,
            'closed'        => false,
        ),
    ));
    
    $sales_steps_cmb->add_group_field($sales_steps_group, array(
        'name'       => __('Step Number', 'wheelfy'),
        'desc'       => __('Step number (e.g., 01, 02, 03)', 'wheelfy'),
        'id'         => 'number',
        'type'       => 'text_small',
    ));
    
    $sales_steps_cmb->add_group_field($sales_steps_group, array(
        'name'       => __('Title', 'wheelfy'),
        'desc'       => __('Step title', 'wheelfy'),
        'id'         => 'title',
        'type'       => 'text',
    ));
    
    $sales_steps_cmb->add_group_field($sales_steps_group, array(
        'name'       => __('Description', 'wheelfy'),
        'desc'       => __('Step description', 'wheelfy'),
        'id'         => 'description',
        'type'       => 'textarea_small',
    ));
    
    $sales_steps_cmb->add_field(array(
        'name'       => __('Button Text', 'wheelfy'),
        'desc'       => __('Text for the button below steps', 'wheelfy'),
        'id'         => 'sales_steps_button_text',
        'type'       => 'text',
        'default'    => 'Get the Best Offers',
    ));
    
    $sales_steps_cmb->add_field(array(
        'name'       => __('Button Link', 'wheelfy'),
        'desc'       => __('URL for the button', 'wheelfy'),
        'id'         => 'sales_steps_button_link',
        'type'       => 'text_url',
        'default'    => '/request-proposal?type=sales',
        'attributes' => array(
            'placeholder' => '/request-proposal?type=sales',
        ),
    ));
    
    /**
     * Car Sales Page - Recent Sales Section Meta Box
     */
    $sales_recent_cmb = new_cmb2_box(array(
        'id'            => 'wheelfy_sales_recent_metabox',
        'title'         => __('Recent Sales Section', 'wheelfy'),
        'object_types'  => array('page'),
        'show_on'       => array('key' => 'page-template', 'value' => 'page-car-sales.php'),
        'context'       => 'normal',
        'priority'      => 'high',
        'show_names'    => true,
    ));
    
    $sales_recent_cmb->add_field(array(
        'name'       => __('Section Title', 'wheelfy'),
        'desc'       => __('Title for the recent sales section', 'wheelfy'),
        'id'         => 'sales_recent_section_title',
        'type'       => 'text',
        'default'    => 'Customer Experiences',
    ));
    
    $sales_recent_cmb->add_field(array(
        'name'       => __('Section Description', 'wheelfy'),
        'desc'       => __('Description text below the section title', 'wheelfy'),
        'id'         => 'sales_recent_section_description',
        'type'       => 'textarea_small',
        'default'    => 'Take a look at our customers\' completed deals.',
    ));
    
    $sales_recent_group = $sales_recent_cmb->add_field(array(
        'id'          => 'sales_recent_sales',
        'type'        => 'group',
        'description' => __('Add recent sales. Click "Add Sale" to add more.', 'wheelfy'),
        'options'     => array(
            'group_title'   => __('Sale {#}', 'wheelfy'),
            'add_button'    => __('Add Sale', 'wheelfy'),
            'remove_button' => __('Remove Sale', 'wheelfy'),
            'sortable'      => true,
            'closed'        => false,
        ),
    ));
    
    $sales_recent_cmb->add_group_field($sales_recent_group, array(
        'name'       => __('Date', 'wheelfy'),
        'desc'       => __('Sale date (e.g., 2025. January 20)', 'wheelfy'),
        'id'         => 'date',
        'type'       => 'text',
    ));
    
    $sales_recent_cmb->add_group_field($sales_recent_group, array(
        'name'       => __('Car Name', 'wheelfy'),
        'desc'       => __('Car name (e.g., Mike\'s Ford Sierra)', 'wheelfy'),
        'id'         => 'car',
        'type'       => 'text',
    ));
    
    $sales_recent_cmb->add_group_field($sales_recent_group, array(
        'name'       => __('Price', 'wheelfy'),
        'desc'       => __('Sale price (e.g., €12,405)', 'wheelfy'),
        'id'         => 'price',
        'type'       => 'text',
    ));
    
    $sales_recent_cmb->add_group_field($sales_recent_group, array(
        'name'       => __('Days to Sell', 'wheelfy'),
        'desc'       => __('Number of days it took to sell (leave empty if using offers)', 'wheelfy'),
        'id'         => 'days',
        'type'       => 'text_small',
    ));
    
    $sales_recent_cmb->add_group_field($sales_recent_group, array(
        'name'       => __('Number of Offers', 'wheelfy'),
        'desc'       => __('Number of offers received (leave empty if using days)', 'wheelfy'),
        'id'         => 'offers',
        'type'       => 'text_small',
    ));
    
    /**
     * Car Sales Page - Benefits Section Meta Box
     */
    $sales_benefits_cmb = new_cmb2_box(array(
        'id'            => 'wheelfy_sales_benefits_metabox',
        'title'         => __('Benefits Section', 'wheelfy'),
        'object_types'  => array('page'),
        'show_on'       => array('key' => 'page-template', 'value' => 'page-car-sales.php'),
        'context'       => 'normal',
        'priority'      => 'high',
        'show_names'    => true,
    ));
    
    $sales_benefits_group = $sales_benefits_cmb->add_field(array(
        'id'          => 'sales_benefits',
        'type'        => 'group',
        'description' => __('Add benefits. Click "Add Benefit" to add more.', 'wheelfy'),
        'options'     => array(
            'group_title'   => __('Benefit {#}', 'wheelfy'),
            'add_button'    => __('Add Benefit', 'wheelfy'),
            'remove_button' => __('Remove Benefit', 'wheelfy'),
            'sortable'      => true,
            'closed'        => false,
        ),
    ));
    
    $sales_benefits_cmb->add_group_field($sales_benefits_group, array(
        'name'       => __('Icon', 'wheelfy'),
        'desc'       => __('Select an icon for this benefit', 'wheelfy'),
        'id'         => 'icon',
        'type'       => 'select',
        'options'    => array(
            'dollar-sign' => 'Dollar Sign (Best Price)',
            'clock' => 'Clock (Fast Process)',
            'shield' => 'Shield (Safe & Secure)',
            'users' => 'Users (Dealers Network)',
            'star' => 'Star (Rating)',
            'message-square' => 'Message Square',
            'credit-card' => 'Credit Card',
            'wrench' => 'Wrench (Service)',
            'search' => 'Search',
            'heart' => 'Heart',
            'car' => 'Car',
        ),
    ));
    
    $sales_benefits_cmb->add_group_field($sales_benefits_group, array(
        'name'       => __('Title', 'wheelfy'),
        'desc'       => __('Benefit title', 'wheelfy'),
        'id'         => 'title',
        'type'       => 'text',
    ));
    
    $sales_benefits_cmb->add_group_field($sales_benefits_group, array(
        'name'       => __('Description', 'wheelfy'),
        'desc'       => __('Benefit description', 'wheelfy'),
        'id'         => 'description',
        'type'       => 'textarea_small',
    ));
    
    /**
     * Car Maintenance Page - Hero Section Meta Box
     */
    $maintenance_hero_cmb = new_cmb2_box(array(
        'id'            => 'wheelfy_maintenance_hero_metabox',
        'title'         => __('Hero Section', 'wheelfy'),
        'object_types'  => array('page'),
        'show_on'       => array('key' => 'page-template', 'value' => 'page-car-maintenance.php'),
        'context'       => 'normal',
        'priority'      => 'high',
        'show_names'    => true,
    ));
    
    $maintenance_hero_cmb->add_field(array(
        'name'       => __('Hero Background Image', 'wheelfy'),
        'desc'       => __('Background image for the hero section', 'wheelfy'),
        'id'         => 'maintenance_hero_background_image',
        'type'       => 'file',
        'options'    => array(
            'url' => false,
        ),
        'text'       => array(
            'add_upload_file_text' => __('Add Background Image', 'wheelfy'),
        ),
        'query_args' => array(
            'type' => array('image/gif', 'image/jpeg', 'image/png', 'image/webp'),
        ),
        'preview_size' => 'medium',
    ));
    
    $maintenance_hero_cmb->add_field(array(
        'name'       => __('Badge Text', 'wheelfy'),
        'desc'       => __('Text for the badge above the title', 'wheelfy'),
        'id'         => 'maintenance_hero_badge',
        'type'       => 'text',
        'default'    => 'Car Maintenance',
    ));
    
    $maintenance_hero_cmb->add_field(array(
        'name'       => __('Hero Title', 'wheelfy'),
        'desc'       => __('Main title for the hero section', 'wheelfy'),
        'id'         => 'maintenance_hero_title_text',
        'type'       => 'text',
        'default'    => 'When your car needs care, we help you',
    ));
    
    $maintenance_hero_cmb->add_field(array(
        'name'       => __('Hero Subtitle', 'wheelfy'),
        'desc'       => __('Subtitle/Highlight text below main title', 'wheelfy'),
        'id'         => 'maintenance_hero_subtitle',
        'type'       => 'text',
        'default'    => 'save money',
    ));
    
    $maintenance_hero_cmb->add_field(array(
        'name'       => __('Hero Description', 'wheelfy'),
        'desc'       => __('Description text below the title', 'wheelfy'),
        'id'         => 'maintenance_hero_description',
        'type'       => 'textarea_small',
        'default'    => 'Save time and money by comparing maintenance prices. Our service is completely free to use.',
    ));
    
    $maintenance_hero_cmb->add_field(array(
        'name'       => __('Hero Button Text', 'wheelfy'),
        'desc'       => __('Text for the hero button', 'wheelfy'),
        'id'         => 'maintenance_hero_button_text',
        'type'       => 'text',
        'default'    => 'Compare Prices',
    ));
    
    $maintenance_hero_cmb->add_field(array(
        'name'       => __('Hero Button Link', 'wheelfy'),
        'desc'       => __('URL for the hero button', 'wheelfy'),
        'id'         => 'maintenance_hero_button_link',
        'type'       => 'text_url',
        'default'    => '/request-proposal?type=maintenance',
        'attributes' => array(
            'placeholder' => '/request-proposal?type=maintenance',
        ),
    ));
    
    /**
     * Car Maintenance Page - Services Grid Section Meta Box
     */
    $maintenance_services_cmb = new_cmb2_box(array(
        'id'            => 'wheelfy_maintenance_services_metabox',
        'title'         => __('Services Grid Section', 'wheelfy'),
        'object_types'  => array('page'),
        'show_on'       => array('key' => 'page-template', 'value' => 'page-car-maintenance.php'),
        'context'       => 'normal',
        'priority'      => 'high',
        'show_names'    => true,
    ));
    
    $maintenance_services_cmb->add_field(array(
        'name'       => __('Section Title', 'wheelfy'),
        'desc'       => __('Title for the services section', 'wheelfy'),
        'id'         => 'maintenance_services_section_title',
        'type'       => 'text',
        'default'    => 'Maintenance Services',
    ));
    
    $maintenance_services_cmb->add_field(array(
        'name'       => __('Section Description', 'wheelfy'),
        'desc'       => __('Description text for the services section', 'wheelfy'),
        'id'         => 'maintenance_services_section_description',
        'type'       => 'textarea_small',
        'default'    => 'Browse our wide range of car maintenance services and get quotes from trusted professionals.',
    ));
    
    $maintenance_services_group = $maintenance_services_cmb->add_field(array(
        'id'          => 'maintenance_services',
        'type'        => 'group',
        'description' => __('Add maintenance services. Click "Add Service" to add more.', 'wheelfy'),
        'options'     => array(
            'group_title'   => __('Service {#}', 'wheelfy'),
            'add_button'    => __('Add Service', 'wheelfy'),
            'remove_button' => __('Remove Service', 'wheelfy'),
            'sortable'      => true,
            'closed'        => false,
        ),
    ));
    
    $maintenance_services_cmb->add_group_field($maintenance_services_group, array(
        'name'       => __('Icon', 'wheelfy'),
        'desc'       => __('Select an icon for this service', 'wheelfy'),
        'id'         => 'icon',
        'type'       => 'select',
        'options'    => array(
            'disc' => 'Disc (Brake Service)',
            'circle-dot' => 'Circle Dot (Tire Service)',
            'droplets' => 'Droplets (Oil Change)',
            'cog' => 'Cog (Transmission)',
            'zap' => 'Zap (Electrical)',
            'wind' => 'Wind (AC Service)',
            'gauge' => 'Gauge (Engine Diagnostics)',
            'shield' => 'Shield (Inspection)',
            'wrench' => 'Wrench',
            'car' => 'Car',
        ),
    ));
    
    $maintenance_services_cmb->add_group_field($maintenance_services_group, array(
        'name'       => __('Service Name', 'wheelfy'),
        'desc'       => __('Name of the service', 'wheelfy'),
        'id'         => 'name',
        'type'       => 'text',
    ));
    
    $maintenance_services_cmb->add_group_field($maintenance_services_group, array(
        'name'       => __('Service Description', 'wheelfy'),
        'desc'       => __('Description of the service', 'wheelfy'),
        'id'         => 'description',
        'type'       => 'text',
    ));
    
    /**
     * Car Maintenance Page - Benefits Section Meta Box
     */
    $maintenance_benefits_cmb = new_cmb2_box(array(
        'id'            => 'wheelfy_maintenance_benefits_metabox',
        'title'         => __('Benefits Section', 'wheelfy'),
        'object_types'  => array('page'),
        'show_on'       => array('key' => 'page-template', 'value' => 'page-car-maintenance.php'),
        'context'       => 'normal',
        'priority'      => 'high',
        'show_names'    => true,
    ));
    
    $maintenance_benefits_cmb->add_field(array(
        'name'       => __('Section Title', 'wheelfy'),
        'desc'       => __('Main title for the benefits section', 'wheelfy'),
        'id'         => 'maintenance_benefits_section_title',
        'type'       => 'text',
        'default'    => 'Why choose our',
    ));
    
    $maintenance_benefits_cmb->add_field(array(
        'name'       => __('Section Title Highlight', 'wheelfy'),
        'desc'       => __('Highlighted part of the title (gradient text)', 'wheelfy'),
        'id'         => 'maintenance_benefits_section_title_highlight',
        'type'       => 'text',
        'default'    => 'maintenance platform?',
    ));
    
    $maintenance_benefits_cmb->add_field(array(
        'name'       => __('Section Description', 'wheelfy'),
        'desc'       => __('Description text for the benefits section', 'wheelfy'),
        'id'         => 'maintenance_benefits_section_description',
        'type'       => 'textarea_small',
        'default'    => 'We\'ve partnered with hundreds of verified garages and workshops to bring you the best prices and service quality.',
    ));
    
    $maintenance_benefits_list_group = $maintenance_benefits_cmb->add_field(array(
        'id'          => 'maintenance_benefits_list',
        'type'        => 'group',
        'description' => __('Add benefit list items. Click "Add Benefit" to add more.', 'wheelfy'),
        'options'     => array(
            'group_title'   => __('Benefit {#}', 'wheelfy'),
            'add_button'    => __('Add Benefit', 'wheelfy'),
            'remove_button' => __('Remove Benefit', 'wheelfy'),
            'sortable'      => true,
            'closed'        => false,
        ),
    ));
    
    $maintenance_benefits_cmb->add_group_field($maintenance_benefits_list_group, array(
        'name'       => __('Benefit Text', 'wheelfy'),
        'desc'       => __('Text for this benefit item', 'wheelfy'),
        'id'         => 'text',
        'type'       => 'text',
    ));
    
    $maintenance_benefits_cmb->add_field(array(
        'name'       => __('CTA Card Title', 'wheelfy'),
        'desc'       => __('Title for the CTA card on the right', 'wheelfy'),
        'id'         => 'maintenance_benefits_cta_title',
        'type'       => 'text',
        'default'    => 'Get a Free Quote',
    ));
    
    $maintenance_benefits_cmb->add_field(array(
        'name'       => __('CTA Card Description', 'wheelfy'),
        'desc'       => __('Description text for the CTA card', 'wheelfy'),
        'id'         => 'maintenance_benefits_cta_description',
        'type'       => 'textarea_small',
        'default'    => 'Tell us about your car and the service you need. We\'ll connect you with the best providers.',
    ));
    
    $maintenance_benefits_cmb->add_field(array(
        'name'       => __('CTA Button Text', 'wheelfy'),
        'desc'       => __('Text for the CTA button', 'wheelfy'),
        'id'         => 'maintenance_benefits_cta_button_text',
        'type'       => 'text',
        'default'    => 'Start Your Request',
    ));
    
    $maintenance_benefits_cmb->add_field(array(
        'name'       => __('CTA Button Link', 'wheelfy'),
        'desc'       => __('URL for the CTA button', 'wheelfy'),
        'id'         => 'maintenance_benefits_cta_button_link',
        'type'       => 'text_url',
        'default'    => '/request-proposal?type=maintenance',
        'attributes' => array(
            'placeholder' => '/request-proposal?type=maintenance',
        ),
    ));
    
    /**
     * Pricing Page - Hero Section Meta Box
     */
    $pricing_hero_cmb = new_cmb2_box(array(
        'id'            => 'wheelfy_pricing_hero_metabox',
        'title'         => __('Hero Section', 'wheelfy'),
        'object_types'  => array('page'),
        'show_on'       => array('key' => 'page-template', 'value' => 'page-pricing.php'),
        'context'       => 'normal',
        'priority'      => 'high',
        'show_names'    => true,
    ));
    
    $pricing_hero_cmb->add_field(array(
        'name'       => __('Hero Background Image', 'wheelfy'),
        'desc'       => __('Background image for the hero section', 'wheelfy'),
        'id'         => 'pricing_hero_background_image',
        'type'       => 'file',
        'options'    => array(
            'url' => false,
        ),
        'text'       => array(
            'add_upload_file_text' => __('Add Background Image', 'wheelfy'),
        ),
        'query_args' => array(
            'type' => array('image/gif', 'image/jpeg', 'image/png', 'image/webp'),
        ),
        'preview_size' => 'medium',
    ));
    
    $pricing_hero_cmb->add_field(array(
        'name'       => __('Badge Text', 'wheelfy'),
        'desc'       => __('Text for the badge above the title', 'wheelfy'),
        'id'         => 'pricing_hero_badge',
        'type'       => 'text',
        'default'    => 'Transparent Pricing',
    ));
    
    $pricing_hero_cmb->add_field(array(
        'name'       => __('Hero Title', 'wheelfy'),
        'desc'       => __('Main title for the hero section', 'wheelfy'),
        'id'         => 'pricing_hero_title_text',
        'type'       => 'text',
        'default'    => 'Simple, Transparent',
    ));
    
    $pricing_hero_cmb->add_field(array(
        'name'       => __('Hero Subtitle', 'wheelfy'),
        'desc'       => __('Subtitle/Highlight text below main title (gradient text)', 'wheelfy'),
        'id'         => 'pricing_hero_subtitle',
        'type'       => 'text',
        'default'    => 'Pricing',
    ));
    
    $pricing_hero_cmb->add_field(array(
        'name'       => __('Hero Description', 'wheelfy'),
        'desc'       => __('Description text below the title', 'wheelfy'),
        'id'         => 'pricing_hero_description',
        'type'       => 'textarea_small',
        'default'    => 'Free for customers. Fair pricing for partners. No hidden fees. Choose the plan that works best for you.',
    ));
    
    $pricing_hero_cmb->add_field(array(
        'name'       => __('Primary Button Text', 'wheelfy'),
        'desc'       => __('Text for the primary hero button', 'wheelfy'),
        'id'         => 'pricing_hero_primary_button_text',
        'type'       => 'text',
        'default'    => 'Get Started Free',
    ));
    
    $pricing_hero_cmb->add_field(array(
        'name'       => __('Primary Button Link', 'wheelfy'),
        'desc'       => __('URL for the primary button', 'wheelfy'),
        'id'         => 'pricing_hero_primary_button_link',
        'type'       => 'text_url',
        'default'    => '/request-proposal',
        'attributes' => array(
            'placeholder' => '/request-proposal',
        ),
    ));
    
    $pricing_hero_cmb->add_field(array(
        'name'       => __('Secondary Button Text', 'wheelfy'),
        'desc'       => __('Text for the secondary hero button', 'wheelfy'),
        'id'         => 'pricing_hero_secondary_button_text',
        'type'       => 'text',
        'default'    => 'Become a Partner',
    ));
    
    $pricing_hero_cmb->add_field(array(
        'name'       => __('Secondary Button Link', 'wheelfy'),
        'desc'       => __('URL for the secondary button', 'wheelfy'),
        'id'         => 'pricing_hero_secondary_button_link',
        'type'       => 'text_url',
        'default'    => '/become-partner',
        'attributes' => array(
            'placeholder' => '/become-partner',
        ),
    ));
    
    /**
     * Pricing Page - Pricing Cards Section Info Box
     * Shows notification that plans are managed from Subscriptions admin page
     */
    $pricing_cards_cmb = new_cmb2_box(array(
        'id'            => 'wheelfy_pricing_cards_metabox',
        'title'         => __('Pricing Cards Section', 'wheelfy'),
        'object_types'  => array('page'),
        'show_on'       => array('key' => 'page-template', 'value' => 'page-pricing.php'),
        'context'       => 'normal',
        'priority'      => 'high',
        'show_names'    => false,
    ));
    
    $pricing_cards_cmb->add_field(array(
        'id'         => 'pricing_cards_info',
        'type'       => 'title',
        'desc'       => sprintf(
            '<div style="background: linear-gradient(135deg, #667eea 0%%, #764ba2 100%%); color: #fff; padding: 20px; border-radius: 8px; margin: -10px 0;">
                <div style="display: flex; align-items: center; gap: 15px;">
                    <div style="background: rgba(255,255,255,0.2); border-radius: 50%%; padding: 12px;">
                        <span class="dashicons dashicons-money-alt" style="font-size: 24px; width: 24px; height: 24px;"></span>
                    </div>
                    <div>
                        <h3 style="margin: 0 0 5px 0; font-size: 16px; font-weight: 600;">%s</h3>
                        <p style="margin: 0; opacity: 0.9; font-size: 13px;">%s</p>
                    </div>
                </div>
                <div style="margin-top: 15px;">
                    <a href="%s" class="button" style="background: #fff; color: #667eea; border: none; font-weight: 500; padding: 8px 20px;">
                        <span class="dashicons dashicons-admin-settings" style="vertical-align: middle; margin-right: 5px;"></span>
                        %s
                    </a>
                </div>
            </div>',
            __('Subscription Plans', 'wheelfy'),
            __('Pricing cards are loaded dynamically from the Subscriptions admin page. Add, edit, or remove plans from there.', 'wheelfy'),
            admin_url('admin.php?page=wheelfy-subscriptions'),
            __('Manage Subscription Plans', 'wheelfy')
        ),
    ));
    
    /**
     * Pricing Page - FAQ Section Meta Box
     */
    $pricing_faq_cmb = new_cmb2_box(array(
        'id'            => 'wheelfy_pricing_faq_metabox',
        'title'         => __('FAQ Section', 'wheelfy'),
        'object_types'  => array('page'),
        'show_on'       => array('key' => 'page-template', 'value' => 'page-pricing.php'),
        'context'       => 'normal',
        'priority'      => 'high',
        'show_names'    => true,
    ));
    
    $pricing_faq_cmb->add_field(array(
        'name'       => __('FAQ Badge Text', 'wheelfy'),
        'desc'       => __('Text for the badge above the FAQ title', 'wheelfy'),
        'id'         => 'pricing_faq_badge',
        'type'       => 'text',
        'default'    => 'Got Questions?',
    ));
    
    $pricing_faq_cmb->add_field(array(
        'name'       => __('FAQ Section Title', 'wheelfy'),
        'desc'       => __('Main title for the FAQ section', 'wheelfy'),
        'id'         => 'pricing_faq_section_title',
        'type'       => 'text',
        'default'    => 'Frequently Asked Questions',
    ));
    
    $pricing_faq_cmb->add_field(array(
        'name'       => __('FAQ Section Description', 'wheelfy'),
        'desc'       => __('Description text for the FAQ section', 'wheelfy'),
        'id'         => 'pricing_faq_section_description',
        'type'       => 'textarea_small',
        'default'    => 'Find answers to common questions about our pricing and services.',
    ));
    
    $faq_items_group = $pricing_faq_cmb->add_field(array(
        'id'          => 'pricing_faq_items',
        'type'        => 'group',
        'description' => __('Add FAQ items. Click "Add FAQ Item" to add more.', 'wheelfy'),
        'options'     => array(
            'group_title'   => __('FAQ Item {#}', 'wheelfy'),
            'add_button'    => __('Add FAQ Item', 'wheelfy'),
            'remove_button' => __('Remove FAQ Item', 'wheelfy'),
            'sortable'      => true,
            'closed'        => false,
        ),
    ));
    
    $pricing_faq_cmb->add_group_field($faq_items_group, array(
        'name'       => __('Question', 'wheelfy'),
        'desc'       => __('FAQ question text', 'wheelfy'),
        'id'         => 'question',
        'type'       => 'text',
    ));
    
    $pricing_faq_cmb->add_group_field($faq_items_group, array(
        'name'       => __('Answer', 'wheelfy'),
        'desc'       => __('FAQ answer text', 'wheelfy'),
        'id'         => 'answer',
        'type'       => 'textarea',
    ));
    
    /**
     * CTA Section Meta Box (Ready to Save Section)
     */
    $cta_section_cmb = new_cmb2_box(array(
        'id'            => 'wheelfy_cta_section_metabox',
        'title'         => __('CTA Section (Ready to Save)', 'wheelfy'),
        'object_types'  => array('page'),
        'show_on'       => array('key' => 'page-template', 'value' => 'page-home.php'),
        'context'       => 'normal',
        'priority'      => 'high',
        'show_names'    => true,
    ));
    
    // Badge Text
    $cta_section_cmb->add_field(array(
        'name'       => __('Badge Text', 'wheelfy'),
        'desc'       => __('Small badge text above the title', 'wheelfy'),
        'id'         => 'cta_section_badge',
        'type'       => 'text',
        'default'    => 'Start saving today',
    ));
    
    // Section Title
    $cta_section_cmb->add_field(array(
        'name'       => __('Title', 'wheelfy'),
        'desc'       => __('Main title for the CTA section', 'wheelfy'),
        'id'         => 'cta_section_title',
        'type'       => 'text',
        'default'    => 'Ready to save on your',
    ));
    
    // Title Highlight
    $cta_section_cmb->add_field(array(
        'name'       => __('Title Highlight', 'wheelfy'),
        'desc'       => __('Highlighted part of the title', 'wheelfy'),
        'id'         => 'cta_section_title_highlight',
        'type'       => 'text',
        'default'    => 'next car service?',
    ));
    
    // Description
    $cta_section_cmb->add_field(array(
        'name'       => __('Description', 'wheelfy'),
        'desc'       => __('Description text', 'wheelfy'),
        'id'         => 'cta_section_description',
        'type'       => 'textarea',
        'default'    => 'Join thousands of car owners who trust us to find the best deals. It\'s free, fast, and simple.',
    ));
    
    // Primary Button Text
    $cta_section_cmb->add_field(array(
        'name'       => __('Primary Button Text', 'wheelfy'),
        'desc'       => __('Text for the main CTA button', 'wheelfy'),
        'id'         => 'cta_section_primary_button_text',
        'type'       => 'text',
        'default'    => 'Get Started Now',
    ));
    
    // Primary Button Link
    $cta_section_cmb->add_field(array(
        'name'       => __('Primary Button Link', 'wheelfy'),
        'desc'       => __('URL for the primary button', 'wheelfy'),
        'id'         => 'cta_section_primary_button_link',
        'type'       => 'text_url',
        'attributes' => array(
            'placeholder' => 'https://example.com',
        ),
    ));
    
    // Secondary Button Text
    $cta_section_cmb->add_field(array(
        'name'       => __('Secondary Button Text', 'wheelfy'),
        'desc'       => __('Text for the secondary button', 'wheelfy'),
        'id'         => 'cta_section_secondary_button_text',
        'type'       => 'text',
        'default'    => 'Learn More',
    ));
    
    // Secondary Button Link
    $cta_section_cmb->add_field(array(
        'name'       => __('Secondary Button Link', 'wheelfy'),
        'desc'       => __('URL for the secondary button', 'wheelfy'),
        'id'         => 'cta_section_secondary_button_link',
        'type'       => 'text_url',
        'attributes' => array(
            'placeholder' => 'https://example.com',
        ),
    ));
    
    // ============================================
    // UNIVERSAL PAGE META BOXES
    // ============================================
    
    /**
     * Page Settings Meta Box (for all pages)
     */
    $page_settings_cmb = new_cmb2_box(array(
        'id'            => 'wheelfy_page_settings_metabox',
        'title'         => __('Page Settings', 'wheelfy'),
        'object_types'  => array('page'),
        'context'       => 'side',
        'priority'      => 'default',
        'show_names'    => true,
    ));
    
    // Hide Header
    $page_settings_cmb->add_field(array(
        'name'       => __('Hide Header', 'wheelfy'),
        'desc'       => __('Check to hide the header on this page', 'wheelfy'),
        'id'         => 'hide_header',
        'type'       => 'checkbox',
    ));
    
    // Hide Footer
    $page_settings_cmb->add_field(array(
        'name'       => __('Hide Footer', 'wheelfy'),
        'desc'       => __('Check to hide the footer on this page', 'wheelfy'),
        'id'         => 'hide_footer',
        'type'       => 'checkbox',
    ));
    
    // Custom Page Title
    $page_settings_cmb->add_field(array(
        'name'       => __('Custom Page Title', 'wheelfy'),
        'desc'       => __('Override the default page title (leave empty to use page title)', 'wheelfy'),
        'id'         => 'custom_page_title',
        'type'       => 'text',
    ));
    
    // Page Subtitle
    $page_settings_cmb->add_field(array(
        'name'       => __('Page Subtitle', 'wheelfy'),
        'desc'       => __('Optional subtitle displayed below the page title', 'wheelfy'),
        'id'         => 'page_subtitle',
        'type'       => 'text',
    ));
    
    // Featured Image Override
    $page_settings_cmb->add_field(array(
        'name'       => __('Featured Image Override', 'wheelfy'),
        'desc'       => __('Override the featured image for this page', 'wheelfy'),
        'id'         => 'page_featured_image',
        'type'       => 'file',
        'options'    => array(
            'url' => false,
        ),
        'query_args' => array(
            'type' => array('image/gif', 'image/jpeg', 'image/png', 'image/webp'),
        ),
        'preview_size' => 'medium',
    ));
    
    // ============================================
    // HEADER SETTINGS (Theme Options)
    // ============================================
    
    /**
     * Header Settings Meta Box (Theme Options)
     * Note: We use 'options-page' but prevent CMB2 from creating its own menu
     * by not setting parent_slug, menu_title, etc. We handle menu creation manually.
     */
    $header_settings_cmb = new_cmb2_box(array(
        'id'            => 'wheelfy_header_settings_metabox',
        'title'         => __('Header Settings', 'wheelfy'),
        'object_types'  => array('options-page'),
        'option_key'    => 'wheelfy-header-options',
        'capability'    => 'manage_options',
        'save_button'   => __('Save Settings', 'wheelfy'),
        'menu_title'    => false, // Don't create menu - we handle it manually
        'parent_slug'   => '', // Empty to prevent CMB2 from creating menu
    ));
    
    // Logo Section
    $header_settings_cmb->add_field(array(
        'name' => __('Logo Settings', 'wheelfy'),
        'desc' => __('Configure your site logo', 'wheelfy'),
        'type' => 'title',
        'id'   => 'header_logo_title',
    ));
    
    // Custom Logo Upload
    $header_settings_cmb->add_field(array(
        'name'       => __('Header Logo', 'wheelfy'),
        'desc'       => __('Upload your logo image. Recommended size: 200x60px. If empty, uses default logo or site name.', 'wheelfy'),
        'id'         => 'header_logo',
        'type'       => 'file',
        'options'    => array(
            'url' => false,
        ),
        'query_args' => array(
            'type' => array('image/gif', 'image/jpeg', 'image/png', 'image/svg+xml', 'image/webp'),
        ),
        'preview_size' => 'medium',
    ));
    
    // Logo Height
    $header_settings_cmb->add_field(array(
        'name'       => __('Logo Height (Desktop)', 'wheelfy'),
        'desc'       => __('Logo height in pixels for desktop (e.g., 40)', 'wheelfy'),
        'id'         => 'header_logo_height_desktop',
        'type'       => 'text_small',
        'default'    => '40',
        'attributes' => array(
            'type' => 'number',
            'min'  => '20',
            'max'  => '100',
        ),
    ));
    
    // Logo Height Mobile
    $header_settings_cmb->add_field(array(
        'name'       => __('Logo Height (Mobile)', 'wheelfy'),
        'desc'       => __('Logo height in pixels for mobile (e.g., 32)', 'wheelfy'),
        'id'         => 'header_logo_height_mobile',
        'type'       => 'text_small',
        'default'    => '32',
        'attributes' => array(
            'type' => 'number',
            'min'  => '20',
            'max'  => '80',
        ),
    ));
    
    // Header Layout Section
    $header_settings_cmb->add_field(array(
        'name' => __('Header Layout', 'wheelfy'),
        'desc' => __('Configure header appearance and behavior', 'wheelfy'),
        'type' => 'title',
        'id'   => 'header_layout_title',
    ));
    
    // Header Height Desktop
    $header_settings_cmb->add_field(array(
        'name'       => __('Header Height (Desktop)', 'wheelfy'),
        'desc'       => __('Header height in pixels for desktop (e.g., 80)', 'wheelfy'),
        'id'         => 'header_height_desktop',
        'type'       => 'text_small',
        'default'    => '80',
        'attributes' => array(
            'type' => 'number',
            'min'  => '50',
            'max'  => '150',
        ),
    ));
    
    // Header Height Mobile
    $header_settings_cmb->add_field(array(
        'name'       => __('Header Height (Mobile)', 'wheelfy'),
        'desc'       => __('Header height in pixels for mobile (e.g., 60)', 'wheelfy'),
        'id'         => 'header_height_mobile',
        'type'       => 'text_small',
        'default'    => '60',
        'attributes' => array(
            'type' => 'number',
            'min'  => '40',
            'max'  => '120',
        ),
    ));
    
    // Sticky Header
    $header_settings_cmb->add_field(array(
        'name'    => __('Sticky Header', 'wheelfy'),
        'desc'    => __('Enable sticky header that stays at top when scrolling', 'wheelfy'),
        'id'      => 'header_sticky',
        'type'    => 'checkbox',
        'default' => 'on',
    ));
    
    // Header Background Color
    $header_settings_cmb->add_field(array(
        'name'    => __('Header Background Color', 'wheelfy'),
        'desc'    => __('Background color for the header', 'wheelfy'),
        'id'      => 'header_bg_color',
        'type'    => 'colorpicker',
        'default' => '#1a1d2e',
    ));
    
    // Header Background Transparency
    $header_settings_cmb->add_field(array(
        'name'       => __('Header Background Opacity', 'wheelfy'),
        'desc'       => __('Header background opacity (0-100). Lower values = more transparent.', 'wheelfy'),
        'id'         => 'header_bg_opacity',
        'type'       => 'text_small',
        'default'    => '100',
        'attributes' => array(
            'type' => 'number',
            'min'  => '0',
            'max'  => '100',
        ),
    ));
    
    // Navigation Section
    $header_settings_cmb->add_field(array(
        'name' => __('Navigation Menu', 'wheelfy'),
        'desc' => __('Configure navigation menu settings', 'wheelfy'),
        'type' => 'title',
        'id'   => 'header_nav_title',
    ));
    
    // Menu Font Size
    $header_settings_cmb->add_field(array(
        'name'       => __('Menu Font Size', 'wheelfy'),
        'desc'       => __('Font size for menu items in pixels (e.g., 15)', 'wheelfy'),
        'id'         => 'header_menu_font_size',
        'type'       => 'text_small',
        'default'    => '15',
        'attributes' => array(
            'type' => 'number',
            'min'  => '10',
            'max'  => '20',
        ),
    ));
    
    // Menu Item Spacing
    $header_settings_cmb->add_field(array(
        'name'       => __('Menu Item Spacing', 'wheelfy'),
        'desc'       => __('Spacing between menu items in pixels (e.g., 4)', 'wheelfy'),
        'id'         => 'header_menu_spacing',
        'type'       => 'text_small',
        'default'    => '4',
        'attributes' => array(
            'type' => 'number',
            'min'  => '0',
            'max'  => '20',
        ),
    ));
    
    // CTA Button Section
    $header_settings_cmb->add_field(array(
        'name' => __('CTA Button Settings', 'wheelfy'),
        'desc' => __('Configure the call-to-action button in header', 'wheelfy'),
        'type' => 'title',
        'id'   => 'header_cta_title',
    ));
    
    // Show CTA Button
    $header_settings_cmb->add_field(array(
        'name'    => __('Show Register Button', 'wheelfy'),
        'desc'    => __('Display the Register/CTA button in header', 'wheelfy'),
        'id'      => 'header_show_cta',
        'type'    => 'checkbox',
        'default' => 'on',
    ));
    
    // CTA Button Text
    $header_settings_cmb->add_field(array(
        'name'    => __('CTA Button Text', 'wheelfy'),
        'desc'    => __('Text for the CTA button (e.g., "Register", "Get Started")', 'wheelfy'),
        'id'      => 'header_cta_text',
        'type'    => 'text',
        'default' => 'Register',
    ));
    
    // CTA Button Link
    $header_settings_cmb->add_field(array(
        'name'    => __('CTA Button Link', 'wheelfy'),
        'desc'    => __('URL for the CTA button', 'wheelfy'),
        'id'      => 'header_cta_link',
        'type'    => 'text_url',
        'default' => '/register',
    ));
    
    // Login Link Section
    $header_settings_cmb->add_field(array(
        'name' => __('Login Link', 'wheelfy'),
        'desc' => __('Configure the login link in header', 'wheelfy'),
        'type' => 'title',
        'id'   => 'header_login_title',
    ));
    
    // Show Login Link
    $header_settings_cmb->add_field(array(
        'name'    => __('Show Login Link', 'wheelfy'),
        'desc'    => __('Display the Login link in header', 'wheelfy'),
        'id'      => 'header_show_login',
        'type'    => 'checkbox',
        'default' => 'on',
    ));
    
    // Login Link Text
    $header_settings_cmb->add_field(array(
        'name'    => __('Login Link Text', 'wheelfy'),
        'desc'    => __('Text for the login link', 'wheelfy'),
        'id'      => 'header_login_text',
        'type'    => 'text',
        'default' => 'Login',
    ));
    
    // Login Link URL
    $header_settings_cmb->add_field(array(
        'name'    => __('Login Link URL', 'wheelfy'),
        'desc'    => __('URL for the login link', 'wheelfy'),
        'id'      => 'header_login_link',
        'type'    => 'text_url',
        'default' => '/login',
    ));
    
    // Language Switcher Section
    $header_settings_cmb->add_field(array(
        'name' => __('Language Switcher', 'wheelfy'),
        'desc' => __('Configure language switcher in header', 'wheelfy'),
        'type' => 'title',
        'id'   => 'header_language_title',
    ));
    
    // Show Language Switcher
    $header_settings_cmb->add_field(array(
        'name'    => __('Show Language Switcher', 'wheelfy'),
        'desc'    => __('Display language switcher dropdown in header', 'wheelfy'),
        'id'      => 'header_show_language',
        'type'    => 'checkbox',
        'default' => 'on',
    ));
    
    // Available Languages (shortcode field)
    $header_settings_cmb->add_field(array(
        'name'    => __('Available Languages', 'wheelfy'),
        'desc'    => __('Enter a shortcode for the language switcher. Example: [your-shortcode]', 'wheelfy'),
        'id'      => 'header_languages',
        'type'    => 'text',
        'default' => '',
        'attributes' => array(
            'placeholder' => '[your-shortcode]',
            'class' => 'regular-text',
        ),
        'sanitization_cb' => 'wheelfy_sanitize_header_languages',
        'escape_cb' => false, // Allow shortcodes to be stored as-is
    ));
    
    // Mobile Menu Section
    $header_settings_cmb->add_field(array(
        'name' => __('Mobile Menu Settings', 'wheelfy'),
        'desc' => __('Configure mobile menu appearance', 'wheelfy'),
        'type' => 'title',
        'id'   => 'header_mobile_title',
    ));
    
    // Mobile Menu Background Color
    $header_settings_cmb->add_field(array(
        'name'    => __('Mobile Menu Background Color', 'wheelfy'),
        'desc'    => __('Background color for mobile menu overlay', 'wheelfy'),
        'id'      => 'header_mobile_bg_color',
        'type'    => 'colorpicker',
        'default' => '#000000',
    ));
    
    // Mobile Menu Animation Speed
    $header_settings_cmb->add_field(array(
        'name'       => __('Mobile Menu Animation Speed', 'wheelfy'),
        'desc'       => __('Animation duration in milliseconds (e.g., 300)', 'wheelfy'),
        'id'         => 'header_mobile_animation_speed',
        'type'       => 'text_small',
        'default'    => '300',
        'attributes' => array(
            'type' => 'number',
            'min'  => '100',
            'max'  => '1000',
        ),
    ));
    
    // Additional Header Text
    $header_settings_cmb->add_field(array(
        'name' => __('Additional Settings', 'wheelfy'),
        'desc' => __('Extra header customization options', 'wheelfy'),
        'type' => 'title',
        'id'   => 'header_additional_title',
    ));
    
    // Header Additional Text
    $header_settings_cmb->add_field(array(
        'name'       => __('Header Additional Text', 'wheelfy'),
        'desc'       => __('Optional text to display in header (e.g., phone number, promo text)', 'wheelfy'),
        'id'         => 'header_additional_text',
        'type'       => 'text',
    ));
    
    // Show Header Widget Area
    $header_settings_cmb->add_field(array(
        'name'    => __('Show Header Widget Area', 'wheelfy'),
        'desc'    => __('Display widget area in header (if widgets are added)', 'wheelfy'),
        'id'      => 'header_show_widgets',
        'type'    => 'checkbox',
        'default' => 'on',
    ));
    
    // Header Border
    $header_settings_cmb->add_field(array(
        'name'    => __('Show Header Border', 'wheelfy'),
        'desc'    => __('Display bottom border on header', 'wheelfy'),
        'id'      => 'header_show_border',
        'type'    => 'checkbox',
        'default' => 'on',
    ));
    
    // Header Border Color
    $header_settings_cmb->add_field(array(
        'name'    => __('Header Border Color', 'wheelfy'),
        'desc'    => __('Color for the header bottom border', 'wheelfy'),
        'id'      => 'header_border_color',
        'type'    => 'colorpicker',
        'default' => 'rgba(255, 255, 255, 0.05)',
    ));
    
    // ============================================
    // FOOTER SETTINGS (Theme Options)
    // ============================================
    
    /**
     * Footer Settings Meta Box (Theme Options)
     */
    $footer_settings_cmb = new_cmb2_box(array(
        'id'            => 'wheelfy_footer_settings_metabox',
        'title'         => __('Footer Settings', 'wheelfy'),
        'object_types'  => array('options-page'),
        'option_key'    => 'wheelfy-footer-options',
        'capability'    => 'manage_options',
        'save_button'   => __('Save Settings', 'wheelfy'),
        'menu_title'    => false, // Don't create menu - we handle it manually
        'parent_slug'   => '', // Empty to prevent CMB2 from creating menu
    ));
    
    // Footer Logo Section
    $footer_settings_cmb->add_field(array(
        'name' => __('Footer Logo', 'wheelfy'),
        'desc' => __('Configure footer logo settings', 'wheelfy'),
        'type' => 'title',
        'id'   => 'footer_logo_title',
    ));
    
    // Footer Logo Upload
    $footer_settings_cmb->add_field(array(
        'name'       => __('Footer Logo', 'wheelfy'),
        'desc'       => __('Upload footer logo. If empty, uses header logo or site name.', 'wheelfy'),
        'id'         => 'footer_logo',
        'type'       => 'file',
        'options'    => array(
            'url' => false,
        ),
        'query_args' => array(
            'type' => array('image/gif', 'image/jpeg', 'image/png', 'image/svg+xml', 'image/webp'),
        ),
        'preview_size' => 'medium',
    ));
    
    // Footer Logo Height
    $footer_settings_cmb->add_field(array(
        'name'       => __('Logo Height', 'wheelfy'),
        'desc'       => __('Logo height in pixels for footer (e.g., 40)', 'wheelfy'),
        'id'         => 'footer_logo_height',
        'type'       => 'text_small',
        'default'    => '40',
        'attributes' => array(
            'type' => 'number',
            'min'  => '20',
            'max'  => '100',
        ),
    ));
    
    // Footer Logo Description
    $footer_settings_cmb->add_field(array(
        'name'       => __('Logo Short Description', 'wheelfy'),
        'desc'       => __('Short description text displayed below the logo in footer', 'wheelfy'),
        'id'         => 'footer_logo_description',
        'type'       => 'textarea',
        'default'    => '',
        'attributes' => array(
            'rows' => 3,
            'placeholder' => __('Enter a short description about your company or brand...', 'wheelfy'),
        ),
    ));
    
    // Footer Layout Section
    $footer_settings_cmb->add_field(array(
        'name' => __('Footer Layout', 'wheelfy'),
        'desc' => __('Configure footer appearance', 'wheelfy'),
        'type' => 'title',
        'id'   => 'footer_layout_title',
    ));
    
    // Footer Background Color
    $footer_settings_cmb->add_field(array(
        'name'    => __('Background Color', 'wheelfy'),
        'desc'    => __('Background color for the footer', 'wheelfy'),
        'id'      => 'footer_bg_color',
        'type'    => 'colorpicker',
        'default' => '#1a1d2e',
    ));
    
    // Footer Text Color
    $footer_settings_cmb->add_field(array(
        'name'    => __('Text Color', 'wheelfy'),
        'desc'    => __('Default text color for the footer', 'wheelfy'),
        'id'      => 'footer_text_color',
        'type'    => 'colorpicker',
        'default' => '#ffffff',
    ));
    
    // Footer Padding Top
    $footer_settings_cmb->add_field(array(
        'name'       => __('Padding Top (px)', 'wheelfy'),
        'desc'       => __('Top padding for the footer section in pixels (e.g., 64)', 'wheelfy'),
        'id'         => 'footer_padding_top',
        'type'       => 'text_small',
        'default'    => '64',
        'attributes' => array(
            'type' => 'number',
            'min'  => '0',
            'max'  => '200',
        ),
    ));
    
    // Footer Padding Bottom
    $footer_settings_cmb->add_field(array(
        'name'       => __('Padding Bottom (px)', 'wheelfy'),
        'desc'       => __('Bottom padding for the footer section in pixels (e.g., 64)', 'wheelfy'),
        'id'         => 'footer_padding_bottom',
        'type'       => 'text_small',
        'default'    => '64',
        'attributes' => array(
            'type' => 'number',
            'min'  => '0',
            'max'  => '200',
        ),
    ));
    
    // Show Footer Border
    $footer_settings_cmb->add_field(array(
        'name'    => __('Show Footer Border', 'wheelfy'),
        'desc'    => __('Display a top border on the footer', 'wheelfy'),
        'id'      => 'footer_show_border',
        'type'    => 'checkbox',
        'default' => 'on',
    ));
    
    // Footer Border Color
    $footer_settings_cmb->add_field(array(
        'name'    => __('Footer Border Color', 'wheelfy'),
        'desc'    => __('Color for the footer top border', 'wheelfy'),
        'id'      => 'footer_border_color',
        'type'    => 'colorpicker',
        'default' => 'rgba(255, 255, 255, 0.05)',
    ));
    
    // Footer Content Section
    $footer_settings_cmb->add_field(array(
        'name' => __('Footer Content', 'wheelfy'),
        'desc' => __('Configure content displayed in the footer', 'wheelfy'),
        'type' => 'title',
        'id'   => 'footer_content_title',
    ));
    
    // Footer Copyright Text
    $footer_settings_cmb->add_field(array(
        'name'    => __('Copyright Text', 'wheelfy'),
        'desc'    => __('Text for the copyright section. Use {year} for current year. HTML allowed.', 'wheelfy'),
        'id'      => 'footer_copyright_text',
        'type'    => 'textarea_code',
        'default' => '&copy; {year} wheelfy &mdash; All rights reserved',
        'options' => array(
            'disable_codemirror' => true,
        ),
    ));
    
    // Show Footer Menu
    $footer_settings_cmb->add_field(array(
        'name'    => __('Show Footer Menu', 'wheelfy'),
        'desc'    => __('Display the footer navigation menu (if assigned)', 'wheelfy'),
        'id'      => 'footer_show_menu',
        'type'    => 'checkbox',
        'default' => 'on',
    ));
    
    // Show Social Links
    $footer_settings_cmb->add_field(array(
        'name'    => __('Show Social Links', 'wheelfy'),
        'desc'    => __('Display social media icons in the footer', 'wheelfy'),
        'id'      => 'footer_show_social',
        'type'    => 'checkbox',
        'default' => 'on',
    ));
    
    // Quick Links Section
    $footer_settings_cmb->add_field(array(
        'name' => __('Quick Links', 'wheelfy'),
        'desc' => __('Configure quick links displayed in the footer', 'wheelfy'),
        'type' => 'title',
        'id'   => 'footer_quick_links_title',
    ));
    
    // Show Quick Links Section
    $footer_settings_cmb->add_field(array(
        'name'    => __('Show Quick Links Section', 'wheelfy'),
        'desc'    => __('Display the Quick Links column in the footer', 'wheelfy'),
        'id'      => 'footer_show_quick_links',
        'type'    => 'checkbox',
        'default' => 'on',
    ));
    
    // Quick Links Heading
    $footer_settings_cmb->add_field(array(
        'name'    => __('Quick Links Heading', 'wheelfy'),
        'desc'    => __('Heading text for the Quick Links section', 'wheelfy'),
        'id'      => 'footer_quick_links_heading',
        'type'    => 'text',
        'default' => 'Quick Links',
    ));
    
    // Quick Links Repeater Group
    $quick_links_group = $footer_settings_cmb->add_field(array(
        'id'          => 'footer_quick_links',
        'type'        => 'group',
        'description' => __('Add quick links. Click "Add Link" to add more.', 'wheelfy'),
        'options'     => array(
            'group_title'   => __('Link {#}', 'wheelfy'),
            'add_button'    => __('Add Link', 'wheelfy'),
            'remove_button' => __('Remove Link', 'wheelfy'),
            'sortable'      => true,
            'closed'        => false,
        ),
    ));
    
    // Link Text
    $footer_settings_cmb->add_group_field($quick_links_group, array(
        'name'       => __('Link Text', 'wheelfy'),
        'desc'       => __('Text displayed for the link', 'wheelfy'),
        'id'         => 'link_text',
        'type'       => 'text',
        'attributes' => array(
            'required' => 'required',
        ),
    ));
    
    // Link URL
    $footer_settings_cmb->add_group_field($quick_links_group, array(
        'name'       => __('Link URL', 'wheelfy'),
        'desc'       => __('URL for the link (can be relative or absolute)', 'wheelfy'),
        'id'         => 'link_url',
        'type'       => 'text_url',
        'attributes' => array(
            'required' => 'required',
        ),
    ));
    
    // Footer Widgets Section
    $footer_settings_cmb->add_field(array(
        'name' => __('Footer Widgets', 'wheelfy'),
        'desc' => __('Configure footer widget areas', 'wheelfy'),
        'type' => 'title',
        'id'   => 'footer_widgets_title',
    ));
    
    // Show Footer Widget Area
    $footer_settings_cmb->add_field(array(
        'name'    => __('Show Footer Widget Area', 'wheelfy'),
        'desc'    => __('Display the footer widget area (if widgets are added)', 'wheelfy'),
        'id'      => 'footer_show_widgets',
        'type'    => 'checkbox',
        'default' => 'on',
    ));
    
    // Footer Widget Columns
    $footer_settings_cmb->add_field(array(
        'name'    => __('Widget Columns', 'wheelfy'),
        'desc'    => __('Number of columns for footer widgets (1-4)', 'wheelfy'),
        'id'      => 'footer_widget_columns',
        'type'    => 'select',
        'options' => array(
            '1' => '1 Column',
            '2' => '2 Columns',
            '3' => '3 Columns',
            '4' => '4 Columns',
        ),
        'default' => '4',
    ));
    
    // Footer Menu Two Section
    $footer_settings_cmb->add_field(array(
        'name' => __('Footer Menu Two', 'wheelfy'),
        'desc' => __('Configure Footer Menu Two widget area', 'wheelfy'),
        'type' => 'title',
        'id'   => 'footer_menu_two_title',
    ));
    
    // Show Footer Menu Two
    $footer_settings_cmb->add_field(array(
        'name'    => __('Show Footer Menu Two', 'wheelfy'),
        'desc'    => __('Display the Footer Menu Two widget area (if widgets are added)', 'wheelfy'),
        'id'      => 'footer_show_menu_two',
        'type'    => 'checkbox',
        'default' => 'on',
    ));
    
    // Filter to prevent CMB2 from creating its own menu page for manually registered options pages
    add_filter('cmb2_options-page_filter_object_args', 'wheelfy_prevent_cmb2_footer_menu_page_creation', 10, 3);
    function wheelfy_prevent_cmb2_footer_menu_page_creation($object_args, $cmb_id, $cmb) {
        if ('wheelfy_footer_settings_metabox' === $cmb_id) {
            $object_args['menu_title'] = ''; // Prevent CMB2 from adding a menu item
            $object_args['parent_slug'] = ''; // Prevent CMB2 from adding a submenu item
        }
        return $object_args;
    }
}

/**
 * Contact & Social Settings CMB2 Metabox
 */
add_action('cmb2_admin_init', 'wheelfy_register_contact_social_settings_metabox');
function wheelfy_register_contact_social_settings_metabox() {
    $contact_social_cmb = new_cmb2_box(array(
        'id'           => 'wheelfy_contact_social_settings_metabox',
        'title'        => '', // Title removed - using page title instead
        'object_types' => array('options-page'),
        'option_key'   => 'wheelfy-contact-options',
        // Don't set parent_slug - we handle menu creation manually to prevent duplicate forms
        'menu_title'   => '', // We handle menu creation manually
    ));
    
    // Contact & Social Text Field
    $contact_social_cmb->add_field(array(
        'name'    => __('Contact & Social', 'wheelfy'),
        'desc'    => __('Enter a description or subtitle for the Contact & Social section', 'wheelfy'),
        'id'      => 'contact_social_text',
        'type'    => 'text',
        'default' => '',
    ));
    
    // Contact Information Section
    $contact_social_cmb->add_field(array(
        'name' => __('Contact Information', 'wheelfy'),
        'desc' => __('Enter your business contact details', 'wheelfy'),
        'id'   => 'contact_info_title',
        'type' => 'title',
    ));
    
    // Contact Email
    $contact_social_cmb->add_field(array(
        'name'    => __('Contact Email', 'wheelfy'),
        'desc'    => __('Primary contact email address', 'wheelfy'),
        'id'      => 'contact_email',
        'type'    => 'text_email',
        'default' => 'info@wheelfy.com',
    ));
    
    // Contact Phone
    $contact_social_cmb->add_field(array(
        'name'    => __('Contact Phone', 'wheelfy'),
        'desc'    => __('Primary contact phone number', 'wheelfy'),
        'id'      => 'contact_phone',
        'type'    => 'text',
        'default' => '+36 30 123 4567',
    ));
    
    // Contact City
    $contact_social_cmb->add_field(array(
        'name'    => __('City', 'wheelfy'),
        'desc'    => __('Business city location', 'wheelfy'),
        'id'      => 'contact_city',
        'type'    => 'text',
        'default' => 'Budapest',
    ));
    
    // Contact Country
    $contact_social_cmb->add_field(array(
        'name'    => __('Country', 'wheelfy'),
        'desc'    => __('Business country location', 'wheelfy'),
        'id'      => 'contact_country',
        'type'    => 'text',
        'default' => 'Hungary',
    ));
    
    // Social Media Section
    $contact_social_cmb->add_field(array(
        'name' => __('Social Media Links', 'wheelfy'),
        'desc' => __('Enter your social media profile URLs', 'wheelfy'),
        'id'   => 'social_media_title',
        'type' => 'title',
    ));
    
    // Facebook
    $contact_social_cmb->add_field(array(
        'name'    => __('Facebook URL', 'wheelfy'),
        'desc'    => __('Your Facebook page/profile URL', 'wheelfy'),
        'id'      => 'social_facebook',
        'type'    => 'text_url',
    ));
    
    // Instagram
    $contact_social_cmb->add_field(array(
        'name'    => __('Instagram URL', 'wheelfy'),
        'desc'    => __('Your Instagram profile URL', 'wheelfy'),
        'id'      => 'social_instagram',
        'type'    => 'text_url',
    ));
    
    // LinkedIn
    $contact_social_cmb->add_field(array(
        'name'    => __('LinkedIn URL', 'wheelfy'),
        'desc'    => __('Your LinkedIn company/profile URL', 'wheelfy'),
        'id'      => 'social_linkedin',
        'type'    => 'text_url',
    ));
    
    // Twitter/X
    $contact_social_cmb->add_field(array(
        'name'    => __('Twitter/X URL', 'wheelfy'),
        'desc'    => __('Your Twitter/X profile URL', 'wheelfy'),
        'id'      => 'social_twitter',
        'type'    => 'text_url',
    ));
    
    // YouTube
    $contact_social_cmb->add_field(array(
        'name'    => __('YouTube URL', 'wheelfy'),
        'desc'    => __('Your YouTube channel URL', 'wheelfy'),
        'id'      => 'social_youtube',
        'type'    => 'text_url',
    ));
    
    // Filter to prevent CMB2 from creating its own menu page for contact & social
    add_filter('cmb2_options-page_filter_object_args', 'wheelfy_prevent_cmb2_contact_social_menu_page_creation', 10, 3);
    function wheelfy_prevent_cmb2_contact_social_menu_page_creation($object_args, $cmb_id, $cmb) {
        if ('wheelfy_contact_social_settings_metabox' === $cmb_id) {
            $object_args['menu_title'] = ''; // Prevent CMB2 from adding a menu item
            $object_args['parent_slug'] = ''; // Prevent CMB2 from adding a submenu item
            $object_args['capability'] = 'do_not_register'; // Prevent registration
        }
        return $object_args;
    }
    
    // Also prevent CMB2 from hooking up the options page automatically
    add_action('admin_menu', 'wheelfy_remove_cmb2_contact_social_menu', 998);
    function wheelfy_remove_cmb2_contact_social_menu() {
        global $submenu;
        
        // Remove from Settings menu
        if (isset($submenu['options-general.php'])) {
            foreach ($submenu['options-general.php'] as $key => $item) {
                if (isset($item[2]) && $item[2] === 'wheelfy-contact-options') {
                    unset($submenu['options-general.php'][$key]);
                }
            }
        }
        
        // Remove from any other parent menus
        foreach ($submenu as $parent => $items) {
            if ($parent !== 'wheelfy-theme-options') {
                foreach ($items as $key => $item) {
                    if (isset($item[2]) && $item[2] === 'wheelfy-contact-options') {
                        unset($submenu[$parent][$key]);
                    }
                }
            }
        }
    }
    
    // Hide the metabox title for Contact & Social page
    add_filter('cmb2_get_metabox', 'wheelfy_hide_contact_social_metabox_title', 10, 2);
    function wheelfy_hide_contact_social_metabox_title($cmb, $cmb_id) {
        if ('wheelfy_contact_social_settings_metabox' === $cmb_id) {
            add_action('admin_head', function() {
                echo '<style>
                    .option-wheelfy-contact-options .cmb2-metabox-title,
                    .option-wheelfy-contact-options .cmb2-wrap > h2.cmb2-metabox-title {
                        display: none !important;
                    }
                </style>';
            });
        }
        return $cmb;
    }
    
}

/**
 * Sanitize header_languages field
 * Converts old array values (from multicheck) to empty string for shortcode field
 * 
 * @param mixed $value The value to sanitize
 * @param array $field_args Field arguments
 * @param object $field CMB2 field object
 * @return string Sanitized value
 */
function wheelfy_sanitize_header_languages($value, $field_args, $field) {
    // If it's an array (old multicheck format), convert to empty string
    if (is_array($value)) {
        return '';
    }
    
    // If it's a string that looks like old array values (comma-separated like "en,hu,de"), return empty string
    if (is_string($value) && preg_match('/^(en|hu|de)(,|\s)*(en|hu|de)(,|\s)*(en|hu|de)?$/i', trim($value))) {
        return '';
    }
    
    // If it's already a string, sanitize it but preserve shortcode brackets
    if (is_string($value)) {
        // Allow shortcodes and basic HTML, but sanitize
        return wp_kses_post($value);
    }
    
    // For any other type, return empty string
    return '';
}

/**
 * Filter to handle old array values when displaying header_languages field
 * This prevents "Array to string conversion" warnings and clears old values
 */
add_filter('cmb2_get_field_value', 'wheelfy_filter_header_languages_display', 10, 4);
function wheelfy_filter_header_languages_display($value, $object_id, $args, $field) {
    // Only apply to header_languages field in options page
    if ($field && $field->id() === 'header_languages' && $field->object_type === 'options-page') {
        // If value is an array (old multicheck format), convert to empty string
        if (is_array($value)) {
            // Clear the old value from database
            wheelfy_clear_old_header_languages();
            return '';
        }
        // If it's a string that looks like old array values (comma-separated like "en,hu,de"), return empty string
        if (is_string($value)) {
            $trimmed = trim($value);
            // Check for patterns like "en,hu,de", "en, hu, de", or any combination of en/hu/de with commas
            // This matches: "en,hu,de", "en,hu", "hu,de", "en", etc.
            if (preg_match('/^(en|hu|de)(\s*,\s*(en|hu|de))*$/i', $trimmed) && !preg_match('/\[.*\]/', $trimmed)) {
                // Clear the old value from database
                wheelfy_clear_old_header_languages();
                return '';
            }
        }
    }
    
    return $value;
}

/**
 * Clear old header_languages value from database
 * This removes the old multicheck array or comma-separated string value
 */
function wheelfy_clear_old_header_languages() {
    $options = get_option('wheelfy-header-options', array());
    
    if (isset($options['header_languages'])) {
        $old_value = $options['header_languages'];
        
        // Check if it's an old value that needs clearing
        $should_clear = false;
        
        if (is_array($old_value)) {
            $should_clear = true;
        } elseif (is_string($old_value)) {
            $trimmed = trim($old_value);
            // Match old language codes but not shortcodes (which contain brackets)
            if (preg_match('/^(en|hu|de)(\s*,\s*(en|hu|de))*$/i', $trimmed) && !preg_match('/\[.*\]/', $trimmed)) {
                $should_clear = true;
            }
        }
        
        // Clear the old value
        if ($should_clear) {
            $options['header_languages'] = '';
            update_option('wheelfy-header-options', $options);
        }
    }
}

/**
 * Update timestamp when header options are saved (for cache busting logo)
 */
add_action('cmb2_save_options-page_fields', 'wheelfy_update_header_options_timestamp', 10, 4);
function wheelfy_update_header_options_timestamp($cmb_id, $object_id, $updated, $cmb) {
    if ('wheelfy_header_settings_metabox' === $cmb_id) {
        // Update timestamp when header options are saved
        update_option('wheelfy-header-options-updated', time());
    }
}

// Update timestamp when footer options are saved for cache busting
add_action('cmb2_save_options-page_fields_wheelfy_footer_settings_metabox', 'wheelfy_update_footer_options_timestamp', 10, 2);
function wheelfy_update_footer_options_timestamp($object_id, $cmb_args) {
    update_option('wheelfy-footer-options-updated', time());
}

/**
 * Auto-clear old header_languages value on admin page load
 * This ensures the old value is cleared when the Header Settings page is accessed
 */
add_action('admin_init', 'wheelfy_auto_clear_old_header_languages');
function wheelfy_auto_clear_old_header_languages() {
    // Only run on the Header Settings page
    if (isset($_GET['page']) && $_GET['page'] === 'wheelfy-header-options') {
        $options = get_option('wheelfy-header-options', array());
        
        if (isset($options['header_languages'])) {
            $value = $options['header_languages'];
            $should_clear = false;
            
            // Check if it's an old value
            if (is_array($value)) {
                $should_clear = true;
            } elseif (is_string($value)) {
                $trimmed = trim($value);
                // Match "en,hu,de" pattern but not shortcodes
                if (preg_match('/^(en|hu|de)(\s*,\s*(en|hu|de))*$/i', $trimmed) && !preg_match('/\[.*\]/', $trimmed)) {
                    $should_clear = true;
                }
            }
            
            // Clear the old value
            if ($should_clear) {
                $options['header_languages'] = '';
                update_option('wheelfy-header-options', $options);
            }
        }
    }
}

/**
 * Services Post Type Meta Box
 */
add_action('cmb2_admin_init', 'wheelfy_register_service_metabox');
function wheelfy_register_service_metabox() {
    // Ensure CMB2 is available
    if (!function_exists('new_cmb2_box')) {
        return;
    }
    
    // Services Meta Box
    $service_cmb = new_cmb2_box(array(
        'id'            => 'wheelfy_service_metabox',
        'title'         => __('Service Settings', 'wheelfy'),
        'object_types'  => array('service'),
        'context'       => 'normal',
        'priority'      => 'high',
        'show_names'    => true,
    ));
    
    // Service Icon
    $service_cmb->add_field(array(
        'name'       => __('Service Icon', 'wheelfy'),
        'desc'       => __('Select an icon for this service', 'wheelfy'),
        'id'         => 'service_icon',
        'type'       => 'select',
        'options'    => array(
            'wrench' => 'Wrench (Maintenance)',
            'car' => 'Car (Sales)',
            'settings' => 'Settings Icon',
            'dollar-sign' => 'Dollar Sign (Pricing)',
            'clock' => 'Clock (Time)',
            'shield' => 'Shield (Security)',
            'star' => 'Star (Rating)',
            'check-circle' => 'Check Circle',
            'user' => 'User',
            'file-text' => 'File Text',
            'message-square' => 'Message Square',
            'credit-card' => 'Credit Card',
            'search' => 'Search',
            'heart' => 'Heart',
        ),
        'default'    => 'wrench',
    ));
    
    // Button Text
    $service_cmb->add_field(array(
        'name'       => __('Button Text', 'wheelfy'),
        'desc'       => __('Text for the CTA button (e.g., "Learn More", "Get Started")', 'wheelfy'),
        'id'         => 'service_button_text',
        'type'       => 'text',
        'default'    => 'Learn More',
        'attributes' => array(
            'placeholder' => 'Learn More',
        ),
    ));
    
    // Service Features (Repeater)
    $features_group = $service_cmb->add_field(array(
        'id'          => 'service_features',
        'type'        => 'group',
        'description' => __('Add feature tags for this service. Click "Add Feature" to add more.', 'wheelfy'),
        'options'     => array(
            'group_title'   => __('Feature {#}', 'wheelfy'),
            'add_button'    => __('Add Feature', 'wheelfy'),
            'remove_button' => __('Remove Feature', 'wheelfy'),
            'sortable'      => true,
            'closed'        => false,
        ),
    ));
    
    $service_cmb->add_group_field($features_group, array(
        'name'       => __('Feature Text', 'wheelfy'),
        'desc'       => __('Feature tag text (e.g., "Oil Changes", "Brake Service")', 'wheelfy'),
        'id'         => 'feature_text',
        'type'       => 'text',
    ));
    
    /**
     * FAQ Page Meta Box
     */
    $faq_cmb = new_cmb2_box(array(
        'id'            => 'wheelfy_faq_metabox',
        'title'         => __('FAQ Content', 'wheelfy'),
        'object_types'  => array('page'),
        'show_on'       => array('key' => 'page-template', 'value' => 'page-faq.php'),
        'context'       => 'normal',
        'priority'      => 'high',
        'show_names'    => true,
    ));
    
    // FAQ Title
    $faq_cmb->add_field(array(
        'name'       => __('FAQ Title', 'wheelfy'),
        'desc'       => __('Main title for the FAQ page', 'wheelfy'),
        'id'         => 'faq_title',
        'type'       => 'text',
        'default'    => 'Frequently Asked Questions',
    ));
    
    // FAQ Description
    $faq_cmb->add_field(array(
        'name'       => __('FAQ Description', 'wheelfy'),
        'desc'       => __('Subtitle/description below the main title', 'wheelfy'),
        'id'         => 'faq_description',
        'type'       => 'textarea_small',
        'default'    => 'Find answers to common questions about our platform.',
    ));
    
    // FAQ Items (Repeatable Group)
    $faq_items_group = $faq_cmb->add_field(array(
        'id'          => 'faq_items',
        'type'        => 'group',
        'description' => __('Add FAQ items. Click "Add FAQ Item" to add more.', 'wheelfy'),
        'options'     => array(
            'group_title'   => __('FAQ Item {#}', 'wheelfy'),
            'add_button'    => __('Add FAQ Item', 'wheelfy'),
            'remove_button' => __('Remove FAQ Item', 'wheelfy'),
            'sortable'      => true,
            'closed'        => false,
        ),
    ));
    
    // FAQ Question
    $faq_cmb->add_group_field($faq_items_group, array(
        'name'       => __('Question', 'wheelfy'),
        'desc'       => __('The question text', 'wheelfy'),
        'id'         => 'question',
        'type'       => 'text',
        'attributes' => array(
            'required' => 'required',
        ),
    ));
    
    // FAQ Answer
    $faq_cmb->add_group_field($faq_items_group, array(
        'name'       => __('Answer', 'wheelfy'),
        'desc'       => __('The answer text (supports line breaks)', 'wheelfy'),
        'id'         => 'answer',
        'type'       => 'textarea',
        'attributes' => array(
            'rows' => 4,
            'required' => 'required',
        ),
    ));
}

