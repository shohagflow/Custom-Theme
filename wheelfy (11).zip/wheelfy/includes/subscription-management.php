<?php
/**
 * Wheelfy Subscription Management System
 * 
 * Complete database-driven subscription system with:
 * - Custom database tables for plans and subscriptions
 * - CRUD operations for subscription plans
 * - Partner subscription management
 * - Revenue and statistics calculations
 * - AJAX endpoints for admin and partner operations
 * 
 * @package Wheelfy
 * @version 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * ============================================================================
 * SECTION 1: DATABASE SCHEMA & TABLE CREATION
 * ============================================================================
 */

/**
 * Create custom database tables for subscription system
 * Called on theme activation
 */
function wheelfy_create_subscription_tables() {
    global $wpdb;
    
    $charset_collate = $wpdb->get_charset_collate();
    
    // Table 1: Subscription Plans
    $table_plans = $wpdb->prefix . 'wheelfy_subscription_plans';
    
    // Check if table already exists
    $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table_plans'") === $table_plans;
    
    if (!$table_exists) {
        $sql_plans = "CREATE TABLE $table_plans (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            plan_slug varchar(100) NOT NULL,
            plan_name varchar(255) NOT NULL,
            price decimal(10,2) NOT NULL DEFAULT 0.00,
            currency varchar(10) NOT NULL DEFAULT 'HUF',
            billing_cycle varchar(20) NOT NULL DEFAULT 'monthly',
            commission_rate decimal(5,2) NOT NULL DEFAULT 0.00,
            has_commission tinyint(1) NOT NULL DEFAULT 1,
            bidding_restriction varchar(50) NOT NULL DEFAULT 'none',
            bidding_restriction_label varchar(255) DEFAULT NULL,
            features longtext DEFAULT NULL,
            features_list longtext DEFAULT NULL,
            is_popular tinyint(1) NOT NULL DEFAULT 0,
            is_active tinyint(1) NOT NULL DEFAULT 1,
            display_order int(11) NOT NULL DEFAULT 0,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY plan_slug (plan_slug),
            KEY is_active (is_active),
            KEY display_order (display_order)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql_plans);
        
        // If dbDelta fails, try direct query
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_plans'") !== $table_plans) {
            $wpdb->query($sql_plans);
        }
    }
    
    // Table 2: Partner Subscriptions
    $table_subscriptions = $wpdb->prefix . 'wheelfy_partner_subscriptions';
    $table_subs_exists = $wpdb->get_var("SHOW TABLES LIKE '$table_subscriptions'") === $table_subscriptions;
    
    if (!$table_subs_exists) {
        $sql_subscriptions = "CREATE TABLE $table_subscriptions (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id bigint(20) UNSIGNED NOT NULL,
            plan_id bigint(20) UNSIGNED NOT NULL,
            status varchar(20) NOT NULL DEFAULT 'pending',
            start_date datetime DEFAULT NULL,
            end_date datetime DEFAULT NULL,
            next_payment_date datetime DEFAULT NULL,
            billing_cycle varchar(20) NOT NULL DEFAULT 'monthly',
            payment_amount decimal(10,2) NOT NULL DEFAULT 0.00,
            currency varchar(10) NOT NULL DEFAULT 'HUF',
            auto_renew tinyint(1) NOT NULL DEFAULT 1,
            cancelled_at datetime DEFAULT NULL,
            cancellation_reason text DEFAULT NULL,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY plan_id (plan_id),
            KEY status (status),
            KEY start_date (start_date),
            KEY end_date (end_date)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql_subscriptions);
        
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_subscriptions'") !== $table_subscriptions) {
            $wpdb->query($sql_subscriptions);
        }
    }
    
    // Table 3: Subscription Payments
    $table_payments = $wpdb->prefix . 'wheelfy_subscription_payments';
    $table_pay_exists = $wpdb->get_var("SHOW TABLES LIKE '$table_payments'") === $table_payments;
    
    if (!$table_pay_exists) {
        $sql_payments = "CREATE TABLE $table_payments (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            subscription_id bigint(20) UNSIGNED NOT NULL,
            user_id bigint(20) UNSIGNED NOT NULL,
            plan_id bigint(20) UNSIGNED NOT NULL,
            amount decimal(10,2) NOT NULL,
            currency varchar(10) NOT NULL DEFAULT 'HUF',
            status varchar(20) NOT NULL DEFAULT 'pending',
            payment_method varchar(50) DEFAULT NULL,
            transaction_id varchar(255) DEFAULT NULL,
            invoice_number varchar(100) DEFAULT NULL,
            payment_date datetime DEFAULT NULL,
            notes text DEFAULT NULL,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY subscription_id (subscription_id),
            KEY user_id (user_id),
            KEY plan_id (plan_id),
            KEY status (status),
            KEY payment_date (payment_date),
            KEY transaction_id (transaction_id)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql_payments);
        
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_payments'") !== $table_payments) {
            $wpdb->query($sql_payments);
        }
    }
    
    // Store version for future migrations
    update_option('wheelfy_subscription_db_version', '1.0.0');
    
    // Insert default plans if none exist
    wheelfy_insert_default_plans();
}
add_action('after_switch_theme', 'wheelfy_create_subscription_tables');
add_action('admin_init', 'wheelfy_maybe_create_subscription_tables');

/**
 * Check and create tables if needed (for when theme is already active)
 */
function wheelfy_maybe_create_subscription_tables() {
    $db_version = get_option('wheelfy_subscription_db_version', '');
    if (empty($db_version) || version_compare($db_version, '1.0.0', '<')) {
        wheelfy_create_subscription_tables();
    }
}

/**
 * Insert default subscription plans
 */
function wheelfy_insert_default_plans() {
    global $wpdb;
    $table = $wpdb->prefix . 'wheelfy_subscription_plans';
    
    // Check if table exists
    $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table'") === $table;
    if (!$table_exists) {
        return; // Table doesn't exist yet
    }
    
    // Check if plans already exist
    $existing = $wpdb->get_var("SELECT COUNT(*) FROM $table");
    if ($existing > 0) {
        return;
    }
    
    // Default plans
    $default_plans = array(
        array(
            'plan_slug' => 'basic',
            'plan_name' => 'Basic Plan',
            'price' => 0.00,
            'currency' => 'HUF',
            'billing_cycle' => 'monthly',
            'commission_rate' => 6.90,
            'has_commission' => 1,
            'bidding_restriction' => 'top3',
            'bidding_restriction_label' => 'Top 3 lowest bidders only',
            'features' => json_encode(array(
                'No monthly fee',
                '6.9% commission per completed service',
                'Submit bids only if ranked within top 3 lowest bidders'
            )),
            'features_list' => json_encode(array(
                array('text' => 'No monthly fee', 'icon' => 'check'),
                array('text' => '6.9% commission per completed service', 'icon' => 'check'),
                array('text' => 'Submit bids only if ranked within top 3 lowest bidders', 'icon' => 'check')
            )),
            'is_popular' => 0,
            'is_active' => 1,
            'display_order' => 1
        ),
        array(
            'plan_slug' => 'premium',
            'plan_name' => 'Premium Plan',
            'price' => 24900.00,
            'currency' => 'HUF',
            'billing_cycle' => 'monthly',
            'commission_rate' => 6.90,
            'has_commission' => 1,
            'bidding_restriction' => 'none',
            'bidding_restriction_label' => 'No top 3 restriction',
            'features' => json_encode(array(
                'Monthly fee of 24,900 HUF',
                '6.9% commission per service',
                'Submit bids freely as long as quote status is open',
                'No top 3 restriction'
            )),
            'features_list' => json_encode(array(
                array('text' => 'Monthly fee of 24,900 HUF', 'icon' => 'check'),
                array('text' => '6.9% commission per service', 'icon' => 'check'),
                array('text' => 'Submit bids freely as long as quote status is open', 'icon' => 'check'),
                array('text' => 'No top 3 restriction', 'icon' => 'check')
            )),
            'is_popular' => 1,
            'is_active' => 1,
            'display_order' => 2
        ),
        array(
            'plan_slug' => 'exclusive',
            'plan_name' => 'Exclusive Plan',
            'price' => 99900.00,
            'currency' => 'HUF',
            'billing_cycle' => 'monthly',
            'commission_rate' => 0.00,
            'has_commission' => 0,
            'bidding_restriction' => 'none',
            'bidding_restriction_label' => 'Unlimited offers with no bidding restrictions',
            'features' => json_encode(array(
                'Monthly fee of 99,900 HUF',
                'No per-service commission (6.9% included in subscription)',
                'Unlimited offers with no bidding restrictions',
                'All services included'
            )),
            'features_list' => json_encode(array(
                array('text' => 'Monthly fee of 99,900 HUF', 'icon' => 'check'),
                array('text' => 'No per-service commission (6.9% included in subscription)', 'icon' => 'check'),
                array('text' => 'Unlimited offers with no bidding restrictions', 'icon' => 'check'),
                array('text' => 'All services included', 'icon' => 'check')
            )),
            'is_popular' => 0,
            'is_active' => 1,
            'display_order' => 3
        )
    );
    
    foreach ($default_plans as $plan) {
        $wpdb->insert($table, $plan);
    }
}

/**
 * ============================================================================
 * SECTION 2: SUBSCRIPTION PLAN CRUD OPERATIONS
 * ============================================================================
 */

/**
 * Get all subscription plans
 * 
 * @param bool $active_only Get only active plans
 * @param string $order_by Order by column
 * @param string $order Order direction
 * @return array Array of plan objects
 */
function wheelfy_get_subscription_plans_db($active_only = false, $order_by = 'display_order', $order = 'ASC') {
    global $wpdb;
    $table = $wpdb->prefix . 'wheelfy_subscription_plans';
    
    $where = '';
    if ($active_only) {
        $where = 'WHERE is_active = 1';
    }
    
    $order_by = sanitize_sql_orderby($order_by . ' ' . $order);
    if (!$order_by) {
        $order_by = 'display_order ASC';
    }
    
    $query = "SELECT * FROM $table $where ORDER BY $order_by";
    $plans = $wpdb->get_results($query);
    
    // Decode JSON fields
    foreach ($plans as &$plan) {
        $plan->features = json_decode($plan->features, true) ?: array();
        $plan->features_list = json_decode($plan->features_list, true) ?: array();
    }
    
    return $plans;
}

/**
 * Get a single subscription plan by ID
 * 
 * @param int $plan_id Plan ID
 * @return object|null Plan object or null
 */
function wheelfy_get_subscription_plan_by_id($plan_id) {
    global $wpdb;
    $table = $wpdb->prefix . 'wheelfy_subscription_plans';
    
    $plan = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id = %d", $plan_id));
    
    if ($plan) {
        $plan->features = json_decode($plan->features, true) ?: array();
        $plan->features_list = json_decode($plan->features_list, true) ?: array();
    }
    
    return $plan;
}

/**
 * Get a single subscription plan by slug
 * 
 * @param string $plan_slug Plan slug
 * @return object|null Plan object or null
 */
function wheelfy_get_subscription_plan_by_slug($plan_slug) {
    global $wpdb;
    $table = $wpdb->prefix . 'wheelfy_subscription_plans';
    
    $plan = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE plan_slug = %s", $plan_slug));
    
    if ($plan) {
        $plan->features = json_decode($plan->features, true) ?: array();
        $plan->features_list = json_decode($plan->features_list, true) ?: array();
    }
    
    return $plan;
}

/**
 * Create a new subscription plan
 * 
 * @param array $data Plan data
 * @return int|WP_Error Plan ID on success, WP_Error on failure
 */
function wheelfy_create_subscription_plan($data) {
    global $wpdb;
    $table = $wpdb->prefix . 'wheelfy_subscription_plans';
    
    // Ensure table exists
    wheelfy_ensure_subscription_tables_exist();
    
    // Generate slug if not provided
    if (empty($data['plan_slug'])) {
        $data['plan_slug'] = sanitize_title($data['plan_name']);
    }
    
    // Ensure unique slug
    $original_slug = $data['plan_slug'];
    $counter = 1;
    while (wheelfy_get_subscription_plan_by_slug($data['plan_slug'])) {
        $data['plan_slug'] = $original_slug . '-' . $counter;
        $counter++;
    }
    
    // Prepare data
    $insert_data = array(
        'plan_slug' => sanitize_text_field($data['plan_slug']),
        'plan_name' => sanitize_text_field($data['plan_name']),
        'price' => floatval($data['price'] ?? 0),
        'currency' => sanitize_text_field($data['currency'] ?? 'HUF'),
        'billing_cycle' => sanitize_text_field($data['billing_cycle'] ?? 'monthly'),
        'commission_rate' => floatval($data['commission_rate'] ?? 0),
        'has_commission' => intval($data['has_commission'] ?? 1),
        'bidding_restriction' => sanitize_text_field($data['bidding_restriction'] ?? 'none'),
        'bidding_restriction_label' => sanitize_text_field($data['bidding_restriction_label'] ?? ''),
        'features' => is_array($data['features'] ?? null) ? json_encode($data['features']) : ($data['features'] ?? '[]'),
        'features_list' => is_array($data['features_list'] ?? null) ? json_encode($data['features_list']) : ($data['features_list'] ?? '[]'),
        'is_popular' => intval($data['is_popular'] ?? 0),
        'is_active' => intval($data['is_active'] ?? 1),
        'display_order' => intval($data['display_order'] ?? 0)
    );
    
    // Define format for each field
    $format = array('%s', '%s', '%f', '%s', '%s', '%f', '%d', '%s', '%s', '%s', '%s', '%d', '%d', '%d');
    
    $result = $wpdb->insert($table, $insert_data, $format);
    
    if ($result === false) {
        // Log error for debugging
        error_log('Wheelfy Subscription Plan Insert Error: ' . $wpdb->last_error);
        return new WP_Error('db_insert_error', $wpdb->last_error ?: __('Database insert failed.', 'wheelfy'));
    }
    
    if ($wpdb->insert_id) {
        do_action('wheelfy_subscription_plan_created', $wpdb->insert_id, $insert_data);
        return $wpdb->insert_id;
    }
    
    return new WP_Error('unknown_error', __('Failed to create plan - no insert ID returned.', 'wheelfy'));
}

/**
 * Ensure subscription tables exist
 */
function wheelfy_ensure_subscription_tables_exist() {
    global $wpdb;
    $table = $wpdb->prefix . 'wheelfy_subscription_plans';
    
    // Check if table exists
    $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table'") === $table;
    
    if (!$table_exists) {
        wheelfy_create_subscription_tables();
    }
}

/**
 * Update a subscription plan
 * 
 * @param int $plan_id Plan ID
 * @param array $data Plan data
 * @return bool Success status
 */
function wheelfy_update_subscription_plan($plan_id, $data) {
    global $wpdb;
    $table = $wpdb->prefix . 'wheelfy_subscription_plans';
    
    // Get existing plan
    $existing_plan = wheelfy_get_subscription_plan_by_id($plan_id);
    if (!$existing_plan) {
        return false;
    }
    
    // Prepare update data
    $update_data = array();
    $format = array();
    
    if (isset($data['plan_name'])) {
        $update_data['plan_name'] = sanitize_text_field($data['plan_name']);
        $format[] = '%s';
    }
    
    if (isset($data['price'])) {
        $update_data['price'] = floatval($data['price']);
        $format[] = '%f';
    }
    
    if (isset($data['currency'])) {
        $update_data['currency'] = sanitize_text_field($data['currency']);
        $format[] = '%s';
    }
    
    if (isset($data['billing_cycle'])) {
        $update_data['billing_cycle'] = sanitize_text_field($data['billing_cycle']);
        $format[] = '%s';
    }
    
    if (isset($data['commission_rate'])) {
        $update_data['commission_rate'] = floatval($data['commission_rate']);
        $format[] = '%f';
    }
    
    if (isset($data['has_commission'])) {
        $update_data['has_commission'] = intval($data['has_commission']);
        $format[] = '%d';
    }
    
    if (isset($data['bidding_restriction'])) {
        $update_data['bidding_restriction'] = sanitize_text_field($data['bidding_restriction']);
        $format[] = '%s';
    }
    
    if (isset($data['bidding_restriction_label'])) {
        $update_data['bidding_restriction_label'] = sanitize_text_field($data['bidding_restriction_label']);
        $format[] = '%s';
    }
    
    if (isset($data['features'])) {
        $update_data['features'] = is_array($data['features']) ? json_encode($data['features']) : $data['features'];
        $format[] = '%s';
    }
    
    if (isset($data['features_list'])) {
        $update_data['features_list'] = is_array($data['features_list']) ? json_encode($data['features_list']) : $data['features_list'];
        $format[] = '%s';
    }
    
    if (isset($data['is_popular'])) {
        $update_data['is_popular'] = intval($data['is_popular']);
        $format[] = '%d';
    }
    
    if (isset($data['is_active'])) {
        $update_data['is_active'] = intval($data['is_active']);
        $format[] = '%d';
    }
    
    if (isset($data['display_order'])) {
        $update_data['display_order'] = intval($data['display_order']);
        $format[] = '%d';
    }
    
    if (empty($update_data)) {
        return true; // Nothing to update
    }
    
    $result = $wpdb->update($table, $update_data, array('id' => $plan_id), $format, array('%d'));
    
    if ($result !== false) {
        do_action('wheelfy_subscription_plan_updated', $plan_id, $update_data);
        return true;
    }
    
    return false;
}

/**
 * Delete a subscription plan
 * 
 * @param int $plan_id Plan ID
 * @return bool Success status
 */
function wheelfy_delete_subscription_plan($plan_id) {
    global $wpdb;
    $table = $wpdb->prefix . 'wheelfy_subscription_plans';
    
    // Check if any active subscriptions use this plan
    $active_subs = wheelfy_count_subscriptions_by_plan($plan_id, 'active');
    if ($active_subs > 0) {
        return new WP_Error('has_active_subscriptions', __('Cannot delete plan with active subscriptions.', 'wheelfy'));
    }
    
    $result = $wpdb->delete($table, array('id' => $plan_id), array('%d'));
    
    if ($result) {
        do_action('wheelfy_subscription_plan_deleted', $plan_id);
        return true;
    }
    
    return false;
}

/**
 * ============================================================================
 * SECTION 3: PARTNER SUBSCRIPTION MANAGEMENT
 * ============================================================================
 */

/**
 * Get partner's current active subscription
 * 
 * @param int $user_id Partner user ID
 * @return object|null Subscription object or null
 */
function wheelfy_get_partner_subscription($user_id) {
    global $wpdb;
    $table = $wpdb->prefix . 'wheelfy_partner_subscriptions';
    
    $subscription = $wpdb->get_row($wpdb->prepare(
        "SELECT s.*, p.plan_name, p.plan_slug, p.price as plan_price, p.commission_rate, p.bidding_restriction 
         FROM $table s
         LEFT JOIN {$wpdb->prefix}wheelfy_subscription_plans p ON s.plan_id = p.id
         WHERE s.user_id = %d AND s.status = 'active'
         ORDER BY s.start_date DESC
         LIMIT 1",
        $user_id
    ));
    
    return $subscription;
}

/**
 * Get all subscriptions for a partner
 * 
 * @param int $user_id Partner user ID
 * @return array Array of subscription objects
 */
function wheelfy_get_partner_subscriptions($user_id) {
    global $wpdb;
    $table = $wpdb->prefix . 'wheelfy_partner_subscriptions';
    
    return $wpdb->get_results($wpdb->prepare(
        "SELECT s.*, p.plan_name, p.plan_slug, p.price as plan_price
         FROM $table s
         LEFT JOIN {$wpdb->prefix}wheelfy_subscription_plans p ON s.plan_id = p.id
         WHERE s.user_id = %d
         ORDER BY s.created_at DESC",
        $user_id
    ));
}

/**
 * Create a new subscription for partner
 * 
 * @param int $user_id Partner user ID
 * @param int $plan_id Plan ID
 * @param array $data Additional subscription data
 * @return int|false Subscription ID or false
 */
function wheelfy_create_partner_subscription($user_id, $plan_id, $data = array()) {
    global $wpdb;
    $table = $wpdb->prefix . 'wheelfy_partner_subscriptions';
    
    // Get plan details
    $plan = wheelfy_get_subscription_plan_by_id($plan_id);
    if (!$plan) {
        return false;
    }
    
    // Cancel any existing active subscription
    $existing = wheelfy_get_partner_subscription($user_id);
    if ($existing) {
        wheelfy_cancel_subscription($existing->id, 'Upgraded to new plan');
    }
    
    // Calculate dates
    $start_date = current_time('mysql');
    $billing_cycle = $data['billing_cycle'] ?? $plan->billing_cycle ?? 'monthly';
    $end_date = wheelfy_calculate_subscription_end_date($start_date, $billing_cycle);
    $next_payment_date = $end_date;
    
    $insert_data = array(
        'user_id' => intval($user_id),
        'plan_id' => intval($plan_id),
        'status' => 'active',
        'start_date' => $start_date,
        'end_date' => $end_date,
        'next_payment_date' => $next_payment_date,
        'billing_cycle' => $billing_cycle,
        'payment_amount' => floatval($plan->price),
        'currency' => $plan->currency,
        'auto_renew' => intval($data['auto_renew'] ?? 1)
    );
    
    $result = $wpdb->insert($table, $insert_data);
    
    if ($result) {
        $subscription_id = $wpdb->insert_id;
        
        // Update user meta
        update_user_meta($user_id, 'subscription_plan', $plan->plan_slug);
        update_user_meta($user_id, 'subscription_plan_id', $plan_id);
        update_user_meta($user_id, 'subscription_status', 'active');
        update_user_meta($user_id, 'subscription_id', $subscription_id);
        
        do_action('wheelfy_subscription_created', $subscription_id, $user_id, $plan_id);
        
        return $subscription_id;
    }
    
    return false;
}

/**
 * Cancel a subscription
 * 
 * @param int $subscription_id Subscription ID
 * @param string $reason Cancellation reason
 * @return bool Success status
 */
function wheelfy_cancel_subscription($subscription_id, $reason = '') {
    global $wpdb;
    $table = $wpdb->prefix . 'wheelfy_partner_subscriptions';
    
    $subscription = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id = %d", $subscription_id));
    if (!$subscription) {
        return false;
    }
    
    $result = $wpdb->update(
        $table,
        array(
            'status' => 'cancelled',
            'cancelled_at' => current_time('mysql'),
            'cancellation_reason' => sanitize_text_field($reason),
            'auto_renew' => 0
        ),
        array('id' => $subscription_id),
        array('%s', '%s', '%s', '%d'),
        array('%d')
    );
    
    if ($result !== false) {
        // Update user meta
        update_user_meta($subscription->user_id, 'subscription_status', 'cancelled');
        
        do_action('wheelfy_subscription_cancelled', $subscription_id, $subscription->user_id);
        
        return true;
    }
    
    return false;
}

/**
 * Calculate subscription end date
 * 
 * @param string $start_date Start date
 * @param string $billing_cycle Billing cycle (monthly, yearly)
 * @return string End date
 */
function wheelfy_calculate_subscription_end_date($start_date, $billing_cycle = 'monthly') {
    $date = new DateTime($start_date);
    
    switch ($billing_cycle) {
        case 'yearly':
            $date->add(new DateInterval('P1Y'));
            break;
        case 'quarterly':
            $date->add(new DateInterval('P3M'));
            break;
        case 'monthly':
        default:
            $date->add(new DateInterval('P1M'));
            break;
    }
    
    return $date->format('Y-m-d H:i:s');
}

/**
 * ============================================================================
 * SECTION 4: PAYMENT MANAGEMENT
 * ============================================================================
 */

/**
 * Create a payment record
 * 
 * @param array $data Payment data
 * @return int|false Payment ID or false
 */
function wheelfy_create_subscription_payment($data) {
    global $wpdb;
    $table = $wpdb->prefix . 'wheelfy_subscription_payments';
    
    $insert_data = array(
        'subscription_id' => intval($data['subscription_id']),
        'user_id' => intval($data['user_id']),
        'plan_id' => intval($data['plan_id']),
        'amount' => floatval($data['amount']),
        'currency' => sanitize_text_field($data['currency'] ?? 'HUF'),
        'status' => sanitize_text_field($data['status'] ?? 'pending'),
        'payment_method' => sanitize_text_field($data['payment_method'] ?? ''),
        'transaction_id' => sanitize_text_field($data['transaction_id'] ?? ''),
        'invoice_number' => wheelfy_generate_invoice_number(),
        'payment_date' => $data['payment_date'] ?? current_time('mysql'),
        'notes' => sanitize_textarea_field($data['notes'] ?? '')
    );
    
    $result = $wpdb->insert($table, $insert_data);
    
    if ($result) {
        do_action('wheelfy_payment_created', $wpdb->insert_id, $insert_data);
        return $wpdb->insert_id;
    }
    
    return false;
}

/**
 * Generate invoice number
 * 
 * @return string Invoice number
 */
function wheelfy_generate_invoice_number() {
    $prefix = 'INV';
    $year = date('Y');
    $month = date('m');
    
    global $wpdb;
    $table = $wpdb->prefix . 'wheelfy_subscription_payments';
    
    $last_invoice = $wpdb->get_var("SELECT invoice_number FROM $table ORDER BY id DESC LIMIT 1");
    
    if ($last_invoice && preg_match('/INV-(\d{4})-(\d+)/', $last_invoice, $matches)) {
        $last_year = $matches[1];
        $last_number = intval($matches[2]);
        
        if ($last_year == $year) {
            $number = $last_number + 1;
        } else {
            $number = 1;
        }
    } else {
        $number = 1;
    }
    
    return sprintf('%s-%s-%04d', $prefix, $year, $number);
}

/**
 * Get all payments for admin view
 * 
 * @param array $args Query arguments
 * @return array Array of payment objects
 */
function wheelfy_get_subscription_payments($args = array()) {
    global $wpdb;
    $table = $wpdb->prefix . 'wheelfy_subscription_payments';
    
    $defaults = array(
        'status' => '',
        'user_id' => 0,
        'plan_id' => 0,
        'date_from' => '',
        'date_to' => '',
        'limit' => 50,
        'offset' => 0,
        'orderby' => 'payment_date',
        'order' => 'DESC'
    );
    
    $args = wp_parse_args($args, $defaults);
    
    $where_clauses = array('1=1');
    $values = array();
    
    if (!empty($args['status'])) {
        $where_clauses[] = 'p.status = %s';
        $values[] = $args['status'];
    }
    
    if ($args['user_id'] > 0) {
        $where_clauses[] = 'p.user_id = %d';
        $values[] = $args['user_id'];
    }
    
    if ($args['plan_id'] > 0) {
        $where_clauses[] = 'p.plan_id = %d';
        $values[] = $args['plan_id'];
    }
    
    if (!empty($args['date_from'])) {
        $where_clauses[] = 'p.payment_date >= %s';
        $values[] = $args['date_from'];
    }
    
    if (!empty($args['date_to'])) {
        $where_clauses[] = 'p.payment_date <= %s';
        $values[] = $args['date_to'];
    }
    
    $where_sql = implode(' AND ', $where_clauses);
    $order_sql = sanitize_sql_orderby($args['orderby'] . ' ' . $args['order']) ?: 'p.payment_date DESC';
    
    $query = "SELECT p.*, u.display_name as partner_name, u.user_email as partner_email, pl.plan_name
              FROM $table p
              LEFT JOIN {$wpdb->users} u ON p.user_id = u.ID
              LEFT JOIN {$wpdb->prefix}wheelfy_subscription_plans pl ON p.plan_id = pl.id
              WHERE $where_sql
              ORDER BY $order_sql
              LIMIT %d OFFSET %d";
    
    $values[] = $args['limit'];
    $values[] = $args['offset'];
    
    if (!empty($values)) {
        $query = $wpdb->prepare($query, ...$values);
    }
    
    return $wpdb->get_results($query);
}

/**
 * ============================================================================
 * SECTION 5: STATISTICS & REPORTING
 * ============================================================================
 */

/**
 * Get subscription statistics for admin dashboard
 * 
 * @return array Statistics array
 */
function wheelfy_get_subscription_statistics() {
    global $wpdb;
    $subs_table = $wpdb->prefix . 'wheelfy_partner_subscriptions';
    $payments_table = $wpdb->prefix . 'wheelfy_subscription_payments';
    
    // Total subscriptions
    $total_subscriptions = $wpdb->get_var("SELECT COUNT(*) FROM $subs_table");
    
    // Active subscriptions
    $active_subscriptions = $wpdb->get_var("SELECT COUNT(*) FROM $subs_table WHERE status = 'active'");
    
    // Expired subscriptions
    $expired_subscriptions = $wpdb->get_var("SELECT COUNT(*) FROM $subs_table WHERE status = 'expired'");
    
    // Cancelled subscriptions
    $cancelled_subscriptions = $wpdb->get_var("SELECT COUNT(*) FROM $subs_table WHERE status = 'cancelled'");
    
    // Monthly Recurring Revenue (MRR)
    $mrr = $wpdb->get_var("SELECT SUM(payment_amount) FROM $subs_table WHERE status = 'active' AND billing_cycle = 'monthly'");
    
    // Total Revenue
    $total_revenue = $wpdb->get_var("SELECT SUM(amount) FROM $payments_table WHERE status = 'completed'");
    
    // This month's revenue
    $first_day = date('Y-m-01 00:00:00');
    $last_day = date('Y-m-t 23:59:59');
    $monthly_revenue = $wpdb->get_var($wpdb->prepare(
        "SELECT SUM(amount) FROM $payments_table WHERE status = 'completed' AND payment_date BETWEEN %s AND %s",
        $first_day,
        $last_day
    ));
    
    // Completed payments
    $completed_payments = $wpdb->get_var("SELECT COUNT(*) FROM $payments_table WHERE status = 'completed'");
    
    // Failed payments
    $failed_payments = $wpdb->get_var("SELECT COUNT(*) FROM $payments_table WHERE status = 'failed'");
    
    return array(
        'total_subscriptions' => intval($total_subscriptions),
        'active_subscriptions' => intval($active_subscriptions),
        'expired_subscriptions' => intval($expired_subscriptions),
        'cancelled_subscriptions' => intval($cancelled_subscriptions),
        'monthly_recurring_revenue' => floatval($mrr) ?: 0,
        'total_revenue' => floatval($total_revenue) ?: 0,
        'monthly_revenue' => floatval($monthly_revenue) ?: 0,
        'completed_payments' => intval($completed_payments),
        'failed_payments' => intval($failed_payments)
    );
}

/**
 * Count subscriptions by plan
 * 
 * @param int $plan_id Plan ID
 * @param string $status Status filter
 * @return int Count
 */
function wheelfy_count_subscriptions_by_plan($plan_id, $status = '') {
    global $wpdb;
    $table = $wpdb->prefix . 'wheelfy_partner_subscriptions';
    
    $where = 'plan_id = %d';
    $values = array($plan_id);
    
    if (!empty($status)) {
        $where .= ' AND status = %s';
        $values[] = $status;
    }
    
    return intval($wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table WHERE $where", ...$values)));
}

/**
 * Get all subscriptions for admin view
 * 
 * @param array $args Query arguments
 * @return array Array of subscription objects
 */
function wheelfy_get_all_subscriptions($args = array()) {
    global $wpdb;
    $table = $wpdb->prefix . 'wheelfy_partner_subscriptions';
    
    $defaults = array(
        'status' => '',
        'plan_id' => 0,
        'search' => '',
        'limit' => 50,
        'offset' => 0,
        'orderby' => 'created_at',
        'order' => 'DESC'
    );
    
    $args = wp_parse_args($args, $defaults);
    
    $where_clauses = array('1=1');
    $values = array();
    
    if (!empty($args['status'])) {
        $where_clauses[] = 's.status = %s';
        $values[] = $args['status'];
    }
    
    if ($args['plan_id'] > 0) {
        $where_clauses[] = 's.plan_id = %d';
        $values[] = $args['plan_id'];
    }
    
    if (!empty($args['search'])) {
        $where_clauses[] = '(u.display_name LIKE %s OR u.user_email LIKE %s)';
        $search_term = '%' . $wpdb->esc_like($args['search']) . '%';
        $values[] = $search_term;
        $values[] = $search_term;
    }
    
    $where_sql = implode(' AND ', $where_clauses);
    $order_sql = sanitize_sql_orderby($args['orderby'] . ' ' . $args['order']) ?: 's.created_at DESC';
    
    $query = "SELECT s.*, u.display_name as partner_name, u.user_email as partner_email, p.plan_name, p.plan_slug
              FROM $table s
              LEFT JOIN {$wpdb->users} u ON s.user_id = u.ID
              LEFT JOIN {$wpdb->prefix}wheelfy_subscription_plans p ON s.plan_id = p.id
              WHERE $where_sql
              ORDER BY $order_sql
              LIMIT %d OFFSET %d";
    
    $values[] = $args['limit'];
    $values[] = $args['offset'];
    
    if (!empty($values)) {
        $query = $wpdb->prepare($query, ...$values);
    }
    
    return $wpdb->get_results($query);
}

/**
 * Get monthly revenue data for charts
 * 
 * @param int $months Number of months
 * @return array Monthly revenue data
 */
function wheelfy_get_monthly_subscription_revenue($months = 12) {
    global $wpdb;
    $table = $wpdb->prefix . 'wheelfy_subscription_payments';
    
    $data = array();
    
    for ($i = $months - 1; $i >= 0; $i--) {
        $date = new DateTime();
        $date->modify("-$i months");
        $year_month = $date->format('Y-m');
        $first_day = $date->format('Y-m-01 00:00:00');
        $last_day = $date->format('Y-m-t 23:59:59');
        
        $revenue = $wpdb->get_var($wpdb->prepare(
            "SELECT SUM(amount) FROM $table WHERE status = 'completed' AND payment_date BETWEEN %s AND %s",
            $first_day,
            $last_day
        ));
        
        $data[] = floatval($revenue) ?: 0;
    }
    
    return $data;
}

/**
 * ============================================================================
 * SECTION 6: AJAX HANDLERS
 * ============================================================================
 */

/**
 * AJAX: Get subscription plan (for edit modal)
 */
function wheelfy_ajax_get_plan_db() {
    check_ajax_referer('wheelfy_subscription_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => __('Insufficient permissions.', 'wheelfy')));
    }
    
    $plan_id = isset($_POST['plan_id']) ? intval($_POST['plan_id']) : 0;
    if (!$plan_id) {
        wp_send_json_error(array('message' => __('Invalid plan ID.', 'wheelfy')));
    }
    
    $plan = wheelfy_get_subscription_plan_by_id($plan_id);
    if (!$plan) {
        wp_send_json_error(array('message' => __('Plan not found.', 'wheelfy')));
    }
    
    wp_send_json_success(array('plan' => $plan));
}
add_action('wp_ajax_wheelfy_get_plan_db', 'wheelfy_ajax_get_plan_db');

/**
 * AJAX: Save subscription plan
 */
function wheelfy_ajax_save_plan_db() {
    check_ajax_referer('wheelfy_subscription_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => __('Insufficient permissions.', 'wheelfy')));
    }
    
    $plan_id = isset($_POST['plan_id']) ? intval($_POST['plan_id']) : 0;
    $plan_name = isset($_POST['plan_name']) ? sanitize_text_field($_POST['plan_name']) : '';
    
    if (empty($plan_name)) {
        wp_send_json_error(array('message' => __('Plan name is required.', 'wheelfy')));
    }
    
    // Prepare features_list
    $features_list = array();
    if (isset($_POST['plan_features_list_json']) && !empty($_POST['plan_features_list_json'])) {
        $json_data = stripslashes($_POST['plan_features_list_json']);
        $features_list = json_decode($json_data, true) ?: array();
    } elseif (isset($_POST['plan_features_list']) && is_array($_POST['plan_features_list'])) {
        $features_list = $_POST['plan_features_list'];
    }
    
    // Sanitize features_list
    $clean_features_list = array();
    foreach ($features_list as $feature) {
        if (is_array($feature) && isset($feature['text']) && !empty(trim($feature['text']))) {
            $clean_features_list[] = array(
                'text' => sanitize_text_field($feature['text']),
                'icon' => sanitize_text_field($feature['icon'] ?? 'check')
            );
        } elseif (is_string($feature) && !empty(trim($feature))) {
            $clean_features_list[] = array(
                'text' => sanitize_text_field($feature),
                'icon' => 'check'
            );
        }
    }
    
    // Prepare plan data
    $plan_data = array(
        'plan_name' => $plan_name,
        'price' => isset($_POST['plan_price']) ? floatval($_POST['plan_price']) : 0,
        'currency' => isset($_POST['plan_currency']) ? sanitize_text_field($_POST['plan_currency']) : 'HUF',
        'billing_cycle' => isset($_POST['plan_billing_cycle']) ? sanitize_text_field($_POST['plan_billing_cycle']) : 'monthly',
        'commission_rate' => isset($_POST['plan_commission_rate']) ? floatval($_POST['plan_commission_rate']) : 0,
        'has_commission' => isset($_POST['plan_has_commission']) ? intval($_POST['plan_has_commission']) : 1,
        'bidding_restriction' => isset($_POST['plan_bidding_restriction']) ? sanitize_text_field($_POST['plan_bidding_restriction']) : 'none',
        'bidding_restriction_label' => isset($_POST['plan_bidding_restriction_label']) ? sanitize_text_field($_POST['plan_bidding_restriction_label']) : '',
        'features' => $clean_features_list, // Store same as features_list
        'features_list' => $clean_features_list,
        'is_popular' => isset($_POST['plan_popular']) && $_POST['plan_popular'] === '1' ? 1 : 0,
        'is_active' => isset($_POST['plan_active']) ? intval($_POST['plan_active']) : 1
    );
    
    if ($plan_id > 0) {
        // Update existing plan
        $result = wheelfy_update_subscription_plan($plan_id, $plan_data);
        if ($result) {
            $plan = wheelfy_get_subscription_plan_by_id($plan_id);
            wp_send_json_success(array(
                'message' => __('Plan updated successfully.', 'wheelfy'),
                'plan' => $plan
            ));
        } else {
            wp_send_json_error(array('message' => __('Failed to update plan.', 'wheelfy')));
        }
    } else {
        // Create new plan
        $new_plan_id = wheelfy_create_subscription_plan($plan_data);
        
        if (is_wp_error($new_plan_id)) {
            wp_send_json_error(array('message' => $new_plan_id->get_error_message()));
        } elseif ($new_plan_id && is_numeric($new_plan_id)) {
            $plan = wheelfy_get_subscription_plan_by_id($new_plan_id);
            wp_send_json_success(array(
                'message' => __('Plan created successfully.', 'wheelfy'),
                'plan' => $plan
            ));
        } else {
            wp_send_json_error(array('message' => __('Failed to create plan. Please check database connection.', 'wheelfy')));
        }
    }
}
add_action('wp_ajax_wheelfy_save_plan_db', 'wheelfy_ajax_save_plan_db');

/**
 * AJAX: Delete subscription plan
 */
function wheelfy_ajax_delete_plan_db() {
    check_ajax_referer('wheelfy_subscription_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => __('Insufficient permissions.', 'wheelfy')));
    }
    
    $plan_id = isset($_POST['plan_id']) ? intval($_POST['plan_id']) : 0;
    if (!$plan_id) {
        wp_send_json_error(array('message' => __('Invalid plan ID.', 'wheelfy')));
    }
    
    $result = wheelfy_delete_subscription_plan($plan_id);
    
    if (is_wp_error($result)) {
        wp_send_json_error(array('message' => $result->get_error_message()));
    } elseif ($result) {
        wp_send_json_success(array('message' => __('Plan deleted successfully.', 'wheelfy')));
    } else {
        wp_send_json_error(array('message' => __('Failed to delete plan.', 'wheelfy')));
    }
}
add_action('wp_ajax_wheelfy_delete_plan_db', 'wheelfy_ajax_delete_plan_db');

/**
 * AJAX: Partner subscribe to plan
 */
function wheelfy_ajax_partner_subscribe() {
    check_ajax_referer('wheelfy_partner_subscription', 'nonce');
    
    $user_id = get_current_user_id();
    if (!$user_id) {
        wp_send_json_error(array('message' => __('Please login to subscribe.', 'wheelfy')));
    }
    
    // Verify user is a partner
    $user_type = get_user_meta($user_id, 'user_type', true);
    if ($user_type !== 'partner') {
        wp_send_json_error(array('message' => __('Only partners can subscribe to plans.', 'wheelfy')));
    }
    
    $plan_id = isset($_POST['plan_id']) ? intval($_POST['plan_id']) : 0;
    if (!$plan_id) {
        wp_send_json_error(array('message' => __('Invalid plan ID.', 'wheelfy')));
    }
    
    $plan = wheelfy_get_subscription_plan_by_id($plan_id);
    if (!$plan || !$plan->is_active) {
        wp_send_json_error(array('message' => __('Plan not available.', 'wheelfy')));
    }
    
    // Check if it's a free plan or paid plan
    if ($plan->price > 0) {
        // For paid plans, we need payment processing
        // For now, we'll create a pending subscription
        $subscription_id = wheelfy_create_partner_subscription($user_id, $plan_id);
        
        if ($subscription_id) {
            // Create a pending payment record
            wheelfy_create_subscription_payment(array(
                'subscription_id' => $subscription_id,
                'user_id' => $user_id,
                'plan_id' => $plan_id,
                'amount' => $plan->price,
                'currency' => $plan->currency,
                'status' => 'pending',
                'payment_method' => 'pending'
            ));
            
            wp_send_json_success(array(
                'message' => __('Subscription created. Please complete payment.', 'wheelfy'),
                'subscription_id' => $subscription_id,
                'requires_payment' => true,
                'amount' => $plan->price,
                'currency' => $plan->currency
            ));
        }
    } else {
        // Free plan - create active subscription immediately
        $subscription_id = wheelfy_create_partner_subscription($user_id, $plan_id);
        
        if ($subscription_id) {
            wp_send_json_success(array(
                'message' => __('You have successfully subscribed to the free plan.', 'wheelfy'),
                'subscription_id' => $subscription_id,
                'requires_payment' => false
            ));
        }
    }
    
    wp_send_json_error(array('message' => __('Failed to create subscription.', 'wheelfy')));
}
add_action('wp_ajax_wheelfy_partner_subscribe', 'wheelfy_ajax_partner_subscribe');

/**
 * AJAX: Get subscription statistics for admin
 */
function wheelfy_ajax_get_subscription_stats() {
    check_ajax_referer('wheelfy_subscription_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => __('Insufficient permissions.', 'wheelfy')));
    }
    
    $stats = wheelfy_get_subscription_statistics();
    wp_send_json_success($stats);
}
add_action('wp_ajax_wheelfy_get_subscription_stats', 'wheelfy_ajax_get_subscription_stats');

/**
 * AJAX: Get all subscriptions for admin table
 */
function wheelfy_ajax_get_subscriptions_list() {
    check_ajax_referer('wheelfy_subscription_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => __('Insufficient permissions.', 'wheelfy')));
    }
    
    $args = array(
        'status' => isset($_POST['status']) ? sanitize_text_field($_POST['status']) : '',
        'plan_id' => isset($_POST['plan_id']) ? intval($_POST['plan_id']) : 0,
        'search' => isset($_POST['search']) ? sanitize_text_field($_POST['search']) : '',
        'limit' => isset($_POST['limit']) ? intval($_POST['limit']) : 50,
        'offset' => isset($_POST['offset']) ? intval($_POST['offset']) : 0
    );
    
    $subscriptions = wheelfy_get_all_subscriptions($args);
    wp_send_json_success(array('subscriptions' => $subscriptions));
}
add_action('wp_ajax_wheelfy_get_subscriptions_list', 'wheelfy_ajax_get_subscriptions_list');

/**
 * AJAX: Cancel subscription (admin action)
 */
function wheelfy_ajax_admin_cancel_subscription() {
    check_ajax_referer('wheelfy_subscription_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => __('Insufficient permissions.', 'wheelfy')));
    }
    
    $subscription_id = isset($_POST['subscription_id']) ? intval($_POST['subscription_id']) : 0;
    $reason = isset($_POST['reason']) ? sanitize_text_field($_POST['reason']) : 'Cancelled by admin';
    
    if (!$subscription_id) {
        wp_send_json_error(array('message' => __('Invalid subscription ID.', 'wheelfy')));
    }
    
    $result = wheelfy_cancel_subscription($subscription_id, $reason);
    
    if ($result) {
        wp_send_json_success(array('message' => __('Subscription cancelled successfully.', 'wheelfy')));
    } else {
        wp_send_json_error(array('message' => __('Failed to cancel subscription.', 'wheelfy')));
    }
}
add_action('wp_ajax_wheelfy_admin_cancel_subscription', 'wheelfy_ajax_admin_cancel_subscription');

/**
 * ============================================================================
 * SECTION 7: HELPER FUNCTIONS
 * ============================================================================
 */

/**
 * Check if partner has active subscription
 * 
 * @param int $user_id Partner user ID
 * @return bool
 */
function wheelfy_partner_has_active_subscription($user_id) {
    $subscription = wheelfy_get_partner_subscription($user_id);
    return $subscription && $subscription->status === 'active';
}

/**
 * Get partner's current plan details
 * 
 * @param int $user_id Partner user ID
 * @return object|null Plan object or null
 */
function wheelfy_get_partner_current_plan($user_id) {
    $subscription = wheelfy_get_partner_subscription($user_id);
    if ($subscription && $subscription->plan_id) {
        return wheelfy_get_subscription_plan_by_id($subscription->plan_id);
    }
    
    // Return free/basic plan as default
    return wheelfy_get_subscription_plan_by_slug('basic');
}

/**
 * Check partner's bidding restriction
 * 
 * @param int $user_id Partner user ID
 * @return string Bidding restriction type
 */
function wheelfy_get_partner_bidding_restriction($user_id) {
    $plan = wheelfy_get_partner_current_plan($user_id);
    return $plan ? $plan->bidding_restriction : 'top3';
}

/**
 * Get partner's commission rate
 * 
 * @param int $user_id Partner user ID
 * @return float Commission rate
 */
function wheelfy_get_partner_commission_rate($user_id) {
    $plan = wheelfy_get_partner_current_plan($user_id);
    return $plan ? floatval($plan->commission_rate) : 6.9;
}

/**
 * Format price for display
 * 
 * @param float $price Price amount
 * @param string $currency Currency code
 * @return string Formatted price
 */
function wheelfy_format_subscription_price($price, $currency = 'HUF') {
    $price = floatval($price);
    
    switch ($currency) {
        case 'HUF':
            return number_format($price, 0, ',', ' ') . ' HUF';
        case 'EUR':
            return '€' . number_format($price, 2, ',', ' ');
        case 'USD':
            return '$' . number_format($price, 2, '.', ',');
        default:
            return number_format($price, 2) . ' ' . $currency;
    }
}

/**
 * Get subscription status label
 * 
 * @param string $status Status code
 * @return string Status label
 */
function wheelfy_get_subscription_status_label($status) {
    $labels = array(
        'active' => __('Active', 'wheelfy'),
        'pending' => __('Pending', 'wheelfy'),
        'expired' => __('Expired', 'wheelfy'),
        'cancelled' => __('Cancelled', 'wheelfy'),
        'suspended' => __('Suspended', 'wheelfy')
    );
    
    return $labels[$status] ?? ucfirst($status);
}

/**
 * Cron job: Check and expire subscriptions
 */
function wheelfy_check_expired_subscriptions() {
    global $wpdb;
    $table = $wpdb->prefix . 'wheelfy_partner_subscriptions';
    
    $now = current_time('mysql');
    
    // Find subscriptions that should be expired
    $expired = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM $table WHERE status = 'active' AND end_date < %s",
        $now
    ));
    
    foreach ($expired as $sub) {
        $wpdb->update(
            $table,
            array('status' => 'expired'),
            array('id' => $sub->id),
            array('%s'),
            array('%d')
        );
        
        // Update user meta
        update_user_meta($sub->user_id, 'subscription_status', 'expired');
        
        // Maybe downgrade to free plan
        $free_plan = wheelfy_get_subscription_plan_by_slug('basic');
        if ($free_plan) {
            update_user_meta($sub->user_id, 'subscription_plan', 'basic');
            update_user_meta($sub->user_id, 'subscription_plan_id', $free_plan->id);
        }
        
        do_action('wheelfy_subscription_expired', $sub->id, $sub->user_id);
    }
}
add_action('wheelfy_daily_subscription_check', 'wheelfy_check_expired_subscriptions');

// Schedule daily cron job
if (!wp_next_scheduled('wheelfy_daily_subscription_check')) {
    wp_schedule_event(time(), 'daily', 'wheelfy_daily_subscription_check');
}

/**
 * Migrate existing subscription data from options to database
 * Called once on upgrade
 */
function wheelfy_migrate_subscription_data() {
    // Check if migration already done
    if (get_option('wheelfy_subscription_migration_done', false)) {
        return;
    }
    
    // Migrate plans from options
    $old_plans = get_option('wheelfy_subscription_plans', array());
    if (!empty($old_plans) && is_array($old_plans)) {
        foreach ($old_plans as $old_plan) {
            $plan_data = array(
                'plan_slug' => sanitize_title($old_plan['id'] ?? $old_plan['name']),
                'plan_name' => $old_plan['name'] ?? '',
                'price' => floatval($old_plan['price'] ?? 0),
                'currency' => $old_plan['currency'] ?? 'HUF',
                'commission_rate' => floatval($old_plan['commission_rate'] ?? 0),
                'has_commission' => isset($old_plan['has_commission']) ? intval($old_plan['has_commission']) : 1,
                'bidding_restriction' => $old_plan['bidding_restriction'] ?? 'none',
                'bidding_restriction_label' => $old_plan['bidding_restriction_label'] ?? '',
                'features' => $old_plan['features'] ?? array(),
                'features_list' => $old_plan['features_list'] ?? array(),
                'is_popular' => isset($old_plan['popular']) ? intval($old_plan['popular']) : 0,
                'is_active' => 1
            );
            
            // Check if plan already exists
            $existing = wheelfy_get_subscription_plan_by_slug($plan_data['plan_slug']);
            if (!$existing) {
                wheelfy_create_subscription_plan($plan_data);
            }
        }
    }
    
    // Migrate user subscription data
    $partners = get_users(array(
        'meta_key' => 'user_type',
        'meta_value' => 'partner'
    ));
    
    foreach ($partners as $partner) {
        $plan_slug = get_user_meta($partner->ID, 'subscription_plan', true);
        if ($plan_slug) {
            $plan = wheelfy_get_subscription_plan_by_slug($plan_slug);
            if ($plan) {
                // Check if subscription already exists
                $existing_sub = wheelfy_get_partner_subscription($partner->ID);
                if (!$existing_sub) {
                    wheelfy_create_partner_subscription($partner->ID, $plan->id);
                }
            }
        }
    }
    
    update_option('wheelfy_subscription_migration_done', true);
}
add_action('admin_init', 'wheelfy_migrate_subscription_data', 20);
