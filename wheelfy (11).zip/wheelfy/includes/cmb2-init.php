<?php
/**
 * CMB2 Framework Initialization
 * 
 * This file initializes CMB2 framework for the Wheelfy theme.
 * CMB2 can be installed as a plugin or included in the theme.
 * 
 * @package Wheelfy
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Check if CMB2 is available
 * Supports both plugin and theme-included versions
 */
function wheelfy_cmb2_init() {
    // Check if CMB2 is installed as a plugin (most common)
    if (defined('CMB2_LOADED') || class_exists('CMB2')) {
        // CMB2 plugin is active, everything is ready
        return true;
    }
    
    // Check if CMB2 functions are available (plugin might be loaded but constant not set)
    if (function_exists('cmb2_get_metabox') || function_exists('new_cmb2_box')) {
        return true;
    }
    
    // Try to load CMB2 from theme includes directory (fallback)
    $cmb2_path = get_template_directory() . '/includes/CMB2/init.php';
    if (file_exists($cmb2_path)) {
        require_once $cmb2_path;
        return true;
    }
    
    // Show admin notice if CMB2 is not found
    if (is_admin()) {
        add_action('admin_notices', 'wheelfy_cmb2_missing_notice');
    }
    
    return false;
}

/**
 * Admin notice if CMB2 is missing
 */
function wheelfy_cmb2_missing_notice() {
    // Only show if CMB2 is actually missing
    if (defined('CMB2_LOADED') || class_exists('CMB2') || function_exists('cmb2_get_metabox')) {
        return; // CMB2 is available, don't show notice
    }
    ?>
    <div class="notice notice-error">
        <p>
            <strong><?php esc_html_e('Wheelfy Theme:', 'wheelfy'); ?></strong>
            <?php esc_html_e('CMB2 framework is required for this theme. Please install and activate the CMB2 plugin.', 'wheelfy'); ?>
            <a href="<?php echo esc_url(admin_url('plugin-install.php?s=cmb2&tab=search&type=term')); ?>" class="button button-primary" style="margin-left: 10px;">
                <?php esc_html_e('Install CMB2 Plugin', 'wheelfy'); ?>
            </a>
        </p>
    </div>
    <?php
}

/**
 * Verify CMB2 is ready for use
 * This function can be called anywhere to check if CMB2 is available
 */
function wheelfy_is_cmb2_ready() {
    return (defined('CMB2_LOADED') || class_exists('CMB2') || function_exists('cmb2_get_metabox') || function_exists('new_cmb2_box'));
}

// Initialize CMB2
wheelfy_cmb2_init();

