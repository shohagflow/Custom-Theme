<?php
/**
 * CMB2 Helper Functions
 * 
 * Utility functions to easily retrieve CMB2 field values
 * 
 * @package Wheelfy
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Get CMB2 field value with fallback
 * 
 * @param int    $post_id Post ID
 * @param string $field_id Field ID
 * @param mixed  $default Default value if field is empty
 * @return mixed Field value or default
 */
function wheelfy_get_cmb2_field($post_id, $field_id, $default = '') {
    if (!$post_id) {
        $post_id = get_the_ID();
    }
    
    $value = get_post_meta($post_id, $field_id, true);
    return !empty($value) ? $value : $default;
}

/**
 * Get CMB2 image URL
 * 
 * @param int    $post_id Post ID
 * @param string $field_id Field ID
 * @param string $size Image size
 * @param string $default Default image URL
 * @return string Image URL
 */
function wheelfy_get_cmb2_image($post_id, $field_id, $size = 'full', $default = '') {
    if (!$post_id) {
        $post_id = get_the_ID();
    }
    
    $image_id = get_post_meta($post_id, $field_id, true);
    if ($image_id) {
        $image_url = wp_get_attachment_image_url($image_id, $size);
        return $image_url ? $image_url : $default;
    }
    
    return $default;
}

/**
 * Get CMB2 repeater field
 * 
 * @param int    $post_id Post ID
 * @param string $field_id Field ID
 * @param array  $default Default array if field is empty
 * @return array Repeater field values
 */
function wheelfy_get_cmb2_repeater($post_id, $field_id, $default = array()) {
    if (!$post_id) {
        $post_id = get_the_ID();
    }
    
    $value = get_post_meta($post_id, $field_id, true);
    return !empty($value) && is_array($value) ? $value : $default;
}

/**
 * Get CMB2 file URL
 * 
 * @param int    $post_id Post ID
 * @param string $field_id Field ID
 * @param string $default Default URL
 * @return string File URL
 */
function wheelfy_get_cmb2_file($post_id, $field_id, $default = '') {
    if (!$post_id) {
        $post_id = get_the_ID();
    }
    
    $file_id = get_post_meta($post_id, $field_id, true);
    if ($file_id) {
        $file_url = wp_get_attachment_url($file_id);
        return $file_url ? $file_url : $default;
    }
    
    return $default;
}

/**
 * Get Header Option (from CMB2 options page)
 * 
 * @param string $option_id Option ID
 * @param mixed  $default Default value
 * @return mixed Option value or default
 */
function wheelfy_get_header_option($option_id, $default = '') {
    $options = get_option('wheelfy-header-options');
    
    if (!isset($options[$option_id])) {
        return $default;
    }
    
    $value = $options[$option_id];
    
    // Handle empty values
    if (empty($value) && $value !== '0' && $value !== 0) {
        return $default;
    }
    
    // Special handling for header_languages field - convert old array to empty string
    if ($option_id === 'header_languages') {
        // If it's an array (old multicheck format), return empty string
        if (is_array($value)) {
            return '';
        }
        // If it's a string that looks like old array values (comma-separated), return empty string
        if (is_string($value) && preg_match('/^(en|hu|de)(,|\s)*(en|hu|de)(,|\s)*(en|hu|de)?$/i', trim($value))) {
            return '';
        }
    }
    
    // Handle checkbox values
    if ($value === 'on' || $value === true || $value === '1') {
        return true;
    }
    if ($value === 'off' || $value === false || $value === '0' || $value === '') {
        return false;
    }
    
    return $value;
}

/**
 * Get Header Logo URL
 * 
 * @param string $default Default logo URL
 * @return string Logo URL
 */
function wheelfy_get_header_logo($default = '') {
    // Get the raw option value directly from the database
    $options = get_option('wheelfy-header-options', array());
    
    $logo_value = isset($options['header_logo']) ? $options['header_logo'] : '';
    
    // Also check for header_logo_id (CMB2 sometimes stores ID separately)
    $logo_id_value = isset($options['header_logo_id']) ? $options['header_logo_id'] : '';
    
    // If both are empty, return default
    if (empty($logo_value) && empty($logo_id_value)) {
        return $default;
    }
    
    // CMB2 file fields can store in multiple formats:
    // 1. Just the attachment ID (string/number): "123"
    // 2. Array with 'id' key: array('id' => 123)
    // 3. Array with numeric index: array(0 => 123)
    // 4. Array with 'url' key: array('url' => 'http://...')
    // 5. Direct URL string: "http://localhost/..."
    // 6. Serialized array string
    
    $logo_id = '';
    $logo_url_direct = '';
    
    // First, check if logo_id is set separately (CMB2 sometimes does this)
    if (!empty($logo_id_value) && is_numeric($logo_id_value)) {
        $logo_id = absint($logo_id_value);
    }
    
    // Handle array format
    if (is_array($logo_value)) {
        // Check for 'id' key first (most common CMB2 format)
        if (isset($logo_value['id']) && !empty($logo_value['id'])) {
            $logo_id = absint($logo_value['id']);
        }
        // Check for numeric index
        elseif (isset($logo_value[0]) && !empty($logo_value[0])) {
            $logo_id = absint($logo_value[0]);
        }
        // Check for direct URL in array
        elseif (isset($logo_value['url']) && !empty($logo_value['url'])) {
            $logo_url_direct = esc_url($logo_value['url']);
        }
    }
    // Handle string - could be URL or ID
    elseif (is_string($logo_value) && !empty($logo_value)) {
        // Check if it's a URL (starts with http:// or https://)
        if (preg_match('/^https?:\/\//', $logo_value)) {
            // It's a direct URL
            $logo_url_direct = esc_url($logo_value);
        }
        // Check if it's a serialized array
        elseif (maybe_unserialize($logo_value) !== false) {
            $unserialized = maybe_unserialize($logo_value);
            if (is_array($unserialized)) {
                if (isset($unserialized['id']) && !empty($unserialized['id'])) {
                    $logo_id = absint($unserialized['id']);
                } elseif (isset($unserialized[0]) && !empty($unserialized[0])) {
                    $logo_id = absint($unserialized[0]);
                } elseif (isset($unserialized['url']) && !empty($unserialized['url'])) {
                    $logo_url_direct = esc_url($unserialized['url']);
                }
            }
        }
        // Check if it's numeric (attachment ID as string)
        elseif (is_numeric($logo_value)) {
            $logo_id = absint($logo_value);
        }
    }
    // Handle numeric (direct attachment ID)
    elseif (is_numeric($logo_value)) {
        $logo_id = absint($logo_value);
    }
    
    // Priority 1: Use attachment ID if available (most reliable)
    if ($logo_id && $logo_id > 0) {
        // Verify the attachment exists
        $attachment = get_post($logo_id);
        if ($attachment && $attachment->post_type === 'attachment') {
            // Try wp_get_attachment_image_url first (better for images)
            $logo_url = wp_get_attachment_image_url($logo_id, 'full');
            if ($logo_url) {
                // Add cache busting parameter
                $attachment_time = get_post_modified_time('U', false, $logo_id);
                $option_time = get_option('wheelfy-header-options-updated', time());
                $cache_buster = max($attachment_time, $option_time);
                return esc_url(add_query_arg('v', $cache_buster, $logo_url));
            }
            
            // If that fails, try getting the URL directly
            $logo_url = wp_get_attachment_url($logo_id);
            if ($logo_url) {
                // Add cache busting parameter
                $attachment_time = get_post_modified_time('U', false, $logo_id);
                $option_time = get_option('wheelfy-header-options-updated', time());
                $cache_buster = max($attachment_time, $option_time);
                return esc_url(add_query_arg('v', $cache_buster, $logo_url));
            }
        }
    }
    
    // Priority 2: Use direct URL if available
    if (!empty($logo_url_direct)) {
        // Add cache busting parameter
        return esc_url(add_query_arg('v', time(), $logo_url_direct));
    }
    
    // If all else fails, return default
    return $default;
}

/**
 * Get Footer Option (from CMB2 options page)
 * 
 * @param string $option_id Option ID
 * @param mixed  $default Default value
 * @return mixed Option value or default
 */
function wheelfy_get_footer_option($option_id, $default = '') {
    $options = get_option('wheelfy-footer-options');
    
    if (!isset($options[$option_id])) {
        return $default;
    }
    
    $value = $options[$option_id];
    
    // Handle empty values
    if (empty($value) && $value !== '0' && $value !== 0) {
        return $default;
    }
    
    // Handle checkbox values
    if ($value === 'on' || $value === true || $value === '1') {
        return true;
    }
    if ($value === 'off' || $value === false || $value === '0' || $value === '') {
        return false;
    }
    
    // Replace {year} placeholder in copyright text
    if ($option_id === 'footer_copyright_text' && is_string($value)) {
        return str_replace('{year}', date('Y'), $value);
    }
    
    return $value;
}

/**
 * Get Footer Logo URL
 * 
 * @param string $default Default logo URL
 * @return string Logo URL
 */
function wheelfy_get_footer_logo($default = '') {
    $options = get_option('wheelfy-footer-options', array());
    $logo_value = isset($options['footer_logo']) ? $options['footer_logo'] : '';
    $logo_id_from_field = isset($options['footer_logo_id']) ? $options['footer_logo_id'] : '';

    $logo_url_direct = '';
    $logo_id = '';

    // Prioritize attachment ID if available
    if (!empty($logo_id_from_field) && is_numeric($logo_id_from_field)) {
        $logo_id = absint($logo_id_from_field);
    } elseif (is_array($logo_value) && isset($logo_value['id']) && !empty($logo_value['id'])) {
        $logo_id = absint($logo_value['id']);
    } elseif (is_numeric($logo_value)) {
        $logo_id = absint($logo_value);
    } elseif (is_string($logo_value) && (strpos($logo_value, 'http://') === 0 || strpos($logo_value, 'https://') === 0)) {
        $logo_url_direct = $logo_value;
    }

    if ($logo_id && is_numeric($logo_id) && $logo_id > 0) {
        $logo_url = wp_get_attachment_image_url($logo_id, 'full');
        if ($logo_url) {
            $attachment_time = get_post_modified_time('U', false, $logo_id);
            $option_time = get_option('wheelfy-footer-options-updated', time());
            $cache_buster = max($attachment_time, $option_time);
            return esc_url(add_query_arg('v', $cache_buster, $logo_url));
        }
    }
    
    // Fallback to direct URL if no ID or image URL from ID
    if (!empty($logo_url_direct)) {
        return esc_url(add_query_arg('v', time(), $logo_url_direct));
    }

    // If no footer logo is set, fall back to header logo
    if (empty($default)) {
        return wheelfy_get_header_logo(get_template_directory_uri() . '/assets/logo-main.png');
    }

    return $default;
}

/**
 * Get Contact & Social Option from CMB2
 * 
 * @param string $option_id Option ID
 * @param mixed  $default Default value
 * @return mixed Option value or default
 */
function wheelfy_get_contact_option($option_id, $default = '') {
    $options = get_option('wheelfy-contact-options');
    
    if (!isset($options[$option_id])) {
        // Fallback to old theme options for backward compatibility
        $old_options = get_option('wheelfy_theme_options');
        if (isset($old_options[$option_id])) {
            return $old_options[$option_id];
        }
        return $default;
    }
    
    $value = $options[$option_id];
    
    // Handle empty values
    if (empty($value) && $value !== '0' && $value !== 0) {
        // Fallback to old theme options for backward compatibility
        $old_options = get_option('wheelfy_theme_options');
        if (isset($old_options[$option_id])) {
            return $old_options[$option_id];
        }
        return $default;
    }
    
    return $value;
}

