<?php
/**
 * TGM Plugin Activation Configuration
 * 
 * This file registers the required plugins for the Wheelfy theme.
 * Place your plugin FOLDERS directly in the /plugins/ folder.
 * The plugins will be automatically copied to wp-content/plugins and activated.
 * 
 * @package Wheelfy
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * Auto-install bundled plugins from theme to wp-content/plugins
 * Supports both ZIP files and plugin folders
 */
function wheelfy_install_bundled_plugins() {
    // Only run for admin users
    if (!current_user_can('activate_plugins')) {
        return;
    }
    
    // Check for plugins in includes/plugins/ (ZIP files)
    $theme_plugins_zip_dir = get_template_directory() . '/includes/plugins';
    // Also check for plugins in plugins/ (folders)
    $theme_plugins_dir = get_template_directory() . '/plugins';
    $wp_plugins_dir = WP_PLUGIN_DIR;
    
    // Process ZIP files from includes/plugins/
    if (is_dir($theme_plugins_zip_dir)) {
        $zip_files = glob($theme_plugins_zip_dir . '/*.zip');
        
        foreach ($zip_files as $zip_file) {
            $zip_name = basename($zip_file, '.zip');
            
            // Skip if already installed
            $target_dir = $wp_plugins_dir . '/' . $zip_name;
            if (is_dir($target_dir)) {
                // Plugin already installed, just activate it
                wheelfy_activate_plugin($zip_name, $wp_plugins_dir);
                continue;
            }
            
            // Extract ZIP file
            $extract_to = $wp_plugins_dir;
            $result = wheelfy_extract_zip($zip_file, $extract_to);
            
            if ($result) {
                // Find the extracted plugin folder (might be nested)
                $extracted_plugin_dir = wheelfy_find_plugin_folder($extract_to, $zip_name);
                
                if ($extracted_plugin_dir) {
                    // Activate the plugin
                    $plugin_slug = basename($extracted_plugin_dir);
                    wheelfy_activate_plugin($plugin_slug, $wp_plugins_dir);
                }
            }
        }
    }
    
    // Process plugin folders from plugins/
    if (is_dir($theme_plugins_dir)) {
        $dirs = glob($theme_plugins_dir . '/*', GLOB_ONLYDIR);
        
        foreach ($dirs as $plugin_dir) {
            $plugin_slug = basename($plugin_dir);
            $target_dir = $wp_plugins_dir . '/' . $plugin_slug;
            
            // Skip if already installed
            if (is_dir($target_dir)) {
                wheelfy_activate_plugin($plugin_slug, $wp_plugins_dir);
                continue;
            }
            
            // Copy plugin folder
            wheelfy_copy_directory($plugin_dir, $target_dir);
            
            // Activate plugin
            wheelfy_activate_plugin($plugin_slug, $wp_plugins_dir);
        }
    }
}

/**
 * Extract ZIP file
 */
function wheelfy_extract_zip($zip_file, $extract_to) {
    if (!class_exists('ZipArchive')) {
        return false;
    }
    
    $zip = new ZipArchive();
    if ($zip->open($zip_file) === TRUE) {
        $zip->extractTo($extract_to);
        $zip->close();
        return true;
    }
    
    return false;
}

/**
 * Find plugin folder after extraction (handles nested folders)
 */
function wheelfy_find_plugin_folder($search_dir, $zip_name) {
    // First, check if plugin folder exists directly
    $direct_path = $search_dir . '/' . $zip_name;
    if (is_dir($direct_path)) {
        return $direct_path;
    }
    
    // Search for plugin folder (might be nested)
    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($search_dir, RecursiveDirectoryIterator::SKIP_DOTS),
        RecursiveIteratorIterator::SELF_FIRST
    );
    
    foreach ($iterator as $item) {
        if ($item->isDir() && basename($item) === $zip_name) {
            // Check if it's a valid plugin folder (has PHP files with Plugin Name header)
            $php_files = glob($item->getPathname() . '/*.php');
            foreach ($php_files as $php_file) {
                $content = @file_get_contents($php_file);
                if ($content && strpos($content, 'Plugin Name:') !== false) {
                    return $item->getPathname();
                }
            }
        }
    }
    
    return false;
}

/**
 * Activate plugin
 */
function wheelfy_activate_plugin($plugin_slug, $wp_plugins_dir) {
    if (!function_exists('is_plugin_active')) {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
    }
    
    // Find main plugin file
    $plugin_dir = $wp_plugins_dir . '/' . $plugin_slug;
    if (!is_dir($plugin_dir)) {
        return false;
    }
    
    $php_files = glob($plugin_dir . '/*.php');
    $main_file = null;
    
    // Try to find main plugin file by checking for Plugin Name header
    foreach ($php_files as $file) {
        $file_content = @file_get_contents($file);
        if ($file_content && strpos($file_content, 'Plugin Name:') !== false) {
            $main_file = basename($file);
            break;
        }
    }
    
    // If no main file found, use the first PHP file or slug.php
    if (!$main_file) {
        $main_file = file_exists($plugin_dir . '/' . $plugin_slug . '.php') 
            ? $plugin_slug . '.php' 
            : (!empty($php_files) ? basename($php_files[0]) : null);
    }
    
    if ($main_file) {
        $plugin_file = $plugin_slug . '/' . $main_file;
        if (file_exists($wp_plugins_dir . '/' . $plugin_file) && !is_plugin_active($plugin_file)) {
            activate_plugin($plugin_file);
            return true;
        }
    }
    
    return false;
}

/**
 * Copy directory recursively
 */
function wheelfy_copy_directory($source, $destination) {
    if (!is_dir($source)) {
        return false;
    }
    
    if (!is_dir($destination)) {
        wp_mkdir_p($destination);
    }
    
    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($source, RecursiveDirectoryIterator::SKIP_DOTS),
        RecursiveIteratorIterator::SELF_FIRST
    );
    
    foreach ($iterator as $item) {
        $dest_path = $destination . DIRECTORY_SEPARATOR . $iterator->getSubPathName();
        
        if ($item->isDir()) {
            if (!is_dir($dest_path)) {
                wp_mkdir_p($dest_path);
            }
        } else {
            @copy($item, $dest_path);
        }
    }
    
    return true;
}

/**
 * Remove directory recursively
 */
function wheelfy_remove_directory($dir) {
    if (!is_dir($dir)) {
        return false;
    }
    
    $files = array_diff(scandir($dir), array('.', '..'));
    
    foreach ($files as $file) {
        $path = $dir . '/' . $file;
        is_dir($path) ? wheelfy_remove_directory($path) : @unlink($path);
    }
    
    return @rmdir($dir);
}

/**
 * Get configured plugin slugs (helper function)
 */
function wheelfy_get_configured_plugin_slugs() {
    static $slugs = null;
    if ($slugs === null) {
        $slugs = array();
        // This will be set when plugins are registered
    }
    return $slugs;
}

/**
 * Register the required plugins for this theme.
 */
function wheelfy_register_required_plugins() {
    global $wheelfy_plugin_slugs;
    /**
     * Array of plugin arrays. Required keys are name, slug, source, and required.
     * 
     * IMPORTANT: Place your plugin FOLDERS (not ZIP files) in the /plugins/ folder.
     * The folder name should match the 'slug' below.
     * 
     * Example structure:
     * /plugins/
     *   /plugin-1-slug/
     *     plugin-1-slug.php
     *     ...
     *   /plugin-2-slug/
     *     plugin-2-slug.php
     *     ...
     */
    $plugins = array(
        // CMB2 Plugin
        array(
            'name'               => 'CMB2', // The plugin name (display name).
            'slug'               => 'cmb2', // The plugin slug (matches the ZIP filename without .zip).
            'source'             => get_template_directory() . '/includes/plugins/cmb2.zip', // The plugin source (ZIP file path).
            'required'           => true, // If false, the plugin is only 'recommended' instead of required.
            'version'            => '', // E.g. 1.0.0. If set, the active plugin must be this version or higher.
            'force_activation'   => true, // Automatically activate when theme is activated.
            'force_deactivation' => false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins.
            'external_url'       => '', // If set, overrides default API URL and points to an external URL.
        ),
        // GTranslate Plugin
        array(
            'name'               => 'GTranslate', // The plugin name (display name).
            'slug'               => 'gtranslate', // The plugin slug (matches the ZIP filename without .zip).
            'source'             => get_template_directory() . '/includes/plugins/gtranslate.zip', // The plugin source (ZIP file path).
            'required'           => true, // If false, the plugin is only 'recommended' instead of required.
            'version'            => '', // E.g. 1.0.0. If set, the active plugin must be this version or higher.
            'force_activation'   => true, // Automatically activate when theme is activated.
            'force_deactivation' => false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins.
            'external_url'       => '', // If set, overrides default API URL and points to an external URL.
        ),
        // WP Mail SMTP Plugin
        array(
            'name'               => 'WP Mail SMTP', // The plugin name (display name).
            'slug'               => 'wp-mail-smtp', // The plugin slug from WordPress repository.
            'required'           => true, // If false, the plugin is only 'recommended' instead of required.
            'version'            => '', // E.g. 1.0.0. If set, the active plugin must be this version or higher.
            'force_activation'   => true, // Automatically activate when theme is activated.
            'force_deactivation' => false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins.
            'external_url'       => '', // If set, overrides default API URL and points to an external URL.
        ),
    );
    
    // Store plugin slugs globally for the installer
    global $wheelfy_plugin_slugs;
    $wheelfy_plugin_slugs = array();
    foreach ($plugins as $plugin) {
        $wheelfy_plugin_slugs[] = $plugin['slug'];
    }

    /**
     * Array of configuration settings. Amend each line as needed.
     */
    $config = array(
        'id'           => 'wheelfy',                 // Unique ID for hashing notices for multiple instances of TGMPA.
        'default_path' => get_template_directory() . '/plugins/', // Default absolute path to bundled plugins.
        'menu'         => 'tgmpa-install-plugins', // Menu slug.
        'parent_slug'  => 'themes.php',            // Parent menu slug.
        'capability'   => 'edit_theme_options',    // Capability needed to view plugin install page, should be a capability associated with the parent menu used.
        'has_notices'  => true,                    // Show admin notices or not.
        'dismissable'  => true,                    // If false, a user cannot dismiss the notice.
        'dismiss_msg'  => '',                      // If 'dismissable' is false, this message will be output at top of nag.
        'is_automatic' => true,                    // Automatically activate plugins after installation or not.
        'message'      => '',                      // Message to output right before the plugins table.
        'strings'      => array(
            'page_title'                      => __( 'Install Required Plugins', 'wheelfy' ),
            'menu_title'                      => __( 'Install Plugins', 'wheelfy' ),
            'installing'                      => __( 'Installing Plugin: %s', 'wheelfy' ),
            'updating'                        => __( 'Updating Plugin: %s', 'wheelfy' ),
            'oops'                            => __( 'Something went wrong with the plugin API.', 'wheelfy' ),
            'notice_can_install_required'     => _n_noop(
                'This theme requires the following plugin: %1$s.',
                'This theme requires the following plugins: %1$s.',
                'wheelfy'
            ),
            'notice_can_install_recommended'  => _n_noop(
                'This theme recommends the following plugin: %1$s.',
                'This theme recommends the following plugins: %1$s.',
                'wheelfy'
            ),
            'notice_ask_to_update'            => _n_noop(
                'The following plugin needs to be updated to its latest version to ensure maximum compatibility with this theme: %1$s.',
                'The following plugins need to be updated to their latest version to ensure maximum compatibility with this theme: %1$s.',
                'wheelfy'
            ),
            'notice_ask_to_update_maybe'      => _n_noop(
                'There is an update available for: %1$s.',
                'There are updates available for the following plugins: %1$s.',
                'wheelfy'
            ),
            'notice_can_activate_required'    => _n_noop(
                'The following required plugin is currently inactive: %1$s.',
                'The following required plugins are currently inactive: %1$s.',
                'wheelfy'
            ),
            'notice_can_activate_recommended' => _n_noop(
                'The following recommended plugin is currently inactive: %1$s.',
                'The following recommended plugins are currently inactive: %1$1$s.',
                'wheelfy'
            ),
            'install_link'                    => _n_noop(
                'Begin installing plugin',
                'Begin installing plugins',
                'wheelfy'
            ),
            'update_link'                     => _n_noop(
                'Begin updating plugin',
                'Begin updating plugins',
                'wheelfy'
            ),
            'activate_link'                   => _n_noop(
                'Begin activating plugin',
                'Begin activating plugins',
                'wheelfy'
            ),
            'return'                          => __( 'Return to Required Plugins Installer', 'wheelfy' ),
            'plugin_activated'                => __( 'Plugin activated successfully.', 'wheelfy' ),
            'activated_successfully'          => __( 'The following plugin was activated successfully:', 'wheelfy' ),
            'plugin_already_active'           => __( 'No action taken. Plugin %1$s was already active.', 'wheelfy' ),
            'plugin_needs_higher_version'     => __( 'Plugin not activated. A higher version of %s is needed for this theme. Please update the plugin.', 'wheelfy' ),
            'complete'                        => __( 'All plugins installed and activated successfully. %1$s', 'wheelfy' ),
            'dismiss'                         => __( 'Dismiss this notice', 'wheelfy' ),
            'notice_cannot_install_activate'  => __( 'There are one or more required or recommended plugins to install, update or activate.', 'wheelfy' ),
            'contact_admin'                   => __( 'Please contact the administrator of this site for help.', 'wheelfy' ),
            'nag_type'                        => '', // Determines admin notice type - can be 'updated', 'update-nag', 'error'.
        ),
    );

    // Only register with TGM if TGM is available
    if (function_exists('tgmpa')) {
        tgmpa( $plugins, $config );
    }
}
add_action( 'tgmpa_register', 'wheelfy_register_required_plugins' );

// Auto-install bundled plugins on theme activation and admin init
// This works independently of TGM - it directly copies folders and activates plugins
add_action( 'after_switch_theme', 'wheelfy_install_bundled_plugins' );
add_action( 'admin_init', 'wheelfy_install_bundled_plugins', 1 );

