<?php
/**
 * Template Name: Login
 * 
 * @package Wheelfy
 */

get_header();

$login_type = isset($_GET['type']) && $_GET['type'] === 'partner' ? 'partner' : 'customer';
$login_error = isset($_GET['login']) && $_GET['login'] === 'failed';
$redirect_to = isset($_GET['redirect_to']) ? esc_url(urldecode($_GET['redirect_to'])) : '';
?>

<div class="container mx-auto px-4 lg:px-8 py-24">
    <div class="max-w-md mx-auto">
        <div class="bg-card rounded-3xl p-8 border border-border">
            <div class="text-center mb-8">
                <h1 class="text-3xl font-bold text-foreground mb-2 hero-title" style="font-size: 45px !important;">
                    <?php echo $login_type === 'partner' ? 'Partner Login' : 'Customer Login'; ?>
                </h1>
                <p class="text-muted-foreground">
                    Sign in to your account to continue
                </p>
            </div>

            <?php if ($redirect_to) : ?>
                <div class="mb-6 p-4 bg-primary/10 border border-primary/20 rounded-lg">
                    <p class="text-primary text-sm flex items-center gap-2">
                        <svg class="w-5 h-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        <span>Please login to continue with the form.</span>
                    </p>
                </div>
            <?php endif; ?>

            <?php if ($login_error) : ?>
                <div class="mb-6 p-4 bg-destructive/10 border border-destructive/20 rounded-lg">
                    <p class="text-destructive text-sm">Invalid username or password. Please try again.</p>
                </div>
            <?php endif; ?>

            <form method="post" action="" id="loginform" style="display: flex; flex-direction: column; gap: 2rem;">
                <?php wp_nonce_field('wheelfy_login', 'wheelfy_login_nonce'); ?>
                <div>
                    <label for="user_login" class="block text-sm font-medium text-foreground mb-2">
                        Email or Username
                    </label>
                    <input 
                        type="text" 
                        id="user_login" 
                        name="log" 
                        required 
                        class="w-full px-4 py-3 rounded-lg bg-secondary border border-border text-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                        placeholder="Enter your email or username"
                        autocomplete="username"
                    >
                </div>

                <div>
                    <label for="user_pass" class="block text-sm font-medium text-foreground mb-2">
                        Password
                    </label>
                    <input 
                        type="password" 
                        id="user_pass" 
                        name="pwd" 
                        required 
                        class="w-full px-4 py-3 rounded-lg bg-secondary border border-border text-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                        placeholder="Enter your password"
                        autocomplete="current-password"
                    >
                </div>

                <div class="flex items-center justify-between">
                    <label class="flex items-center gap-2">
                        <input type="checkbox" name="rememberme" value="forever" class="w-4 h-4 rounded border-border bg-secondary text-primary focus:ring-primary">
                        <span class="text-sm text-muted-foreground">Remember me</span>
                    </label>
                    <a href="<?php echo esc_url(wp_lostpassword_url()); ?>" class="text-sm text-primary hover:underline">
                        Forgot password?
                    </a>
                </div>

                <button type="submit" class="button button-hero w-full" id="login-submit-btn">
                    <span class="btn-text">Sign In</span>
                    <span class="btn-loading hidden">Signing in...</span>
                </button>

                <input type="hidden" name="login_type" value="<?php echo esc_attr($login_type); ?>">
                <?php if ($redirect_to) : ?>
                    <input type="hidden" name="redirect_to" value="<?php echo esc_url($redirect_to); ?>">
                <?php else : ?>
                    <input type="hidden" name="redirect_to" value="<?php echo esc_url($login_type === 'partner' ? home_url('/partner-dashboard') : home_url('/customer-dashboard')); ?>">
                <?php endif; ?>
            </form>

            <div class="mt-6 pt-6 border-t border-border text-center">
                <p class="text-sm text-muted-foreground">
                    Don't have an account? 
                    <a href="<?php echo esc_url($redirect_to ? add_query_arg('redirect_to', urlencode($redirect_to), home_url('/register')) : home_url('/register')); ?>" class="text-primary hover:underline font-medium">
                        Sign up here
                    </a>
                </p>
            </div>

            <?php if ($login_type === 'customer') : ?>
                <div class="mt-4 text-center">
                    <a href="<?php echo esc_url(home_url('/login?type=partner')); ?>" class="text-sm text-primary hover:underline">
                        Are you a partner? Login here
                    </a>
                </div>
            <?php else : ?>
                <div class="mt-4 text-center">
                    <a href="<?php echo esc_url(home_url('/login')); ?>" class="text-sm text-primary hover:underline">
                        Customer login
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('loginform');
    const submitBtn = document.getElementById('login-submit-btn');
    
    if (form && submitBtn) {
        const btnText = submitBtn.querySelector('.btn-text');
        const btnLoading = submitBtn.querySelector('.btn-loading');
        let isSubmitting = false;
        
        // Handle form submit event
        form.addEventListener('submit', function(e) {
            // Prevent double submission
            if (isSubmitting) {
                e.preventDefault();
                return false;
            }
            
            // Basic validation
            const username = document.getElementById('user_login').value.trim();
            const password = document.getElementById('user_pass').value;
            
            if (!username || !password) {
                e.preventDefault();
                alert('Please fill in all required fields.');
                return false;
            }
            
            // Show loading state
            isSubmitting = true;
            if (btnText && btnLoading) {
                submitBtn.disabled = true;
                btnText.classList.add('hidden');
                btnLoading.classList.remove('hidden');
            }
            
            // Allow form to submit - DO NOT prevent default
            return true;
        });
    }
});
</script>

<?php
get_footer();

