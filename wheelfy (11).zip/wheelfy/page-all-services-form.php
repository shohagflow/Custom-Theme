<?php
/**
 * Template Name: All Services Form
 * 
 * Page template for the all services form
 * Includes the form from form/all-services-form.php
 *
 * @package Wheelfy
 */

get_header();

// Include the form file properly
$form_file = get_template_directory() . '/form/all-services-form.php';
if (file_exists($form_file)) {
    // Set a flag so the form knows headers/footers are already called
    $wheelfy_headers_already_loaded = true;
    
    // Include the form file - it will execute PHP properly
    // The form file will skip get_header() and get_footer() because of the flag
    include $form_file;
} else {
    // Fallback: Show error message
    ?>
    <section class="py-20">
        <div class="container max-w-4xl">
            <div class="text-center mb-12">
                <h1 class="text-3xl sm:text-4xl font-bold text-foreground mb-4">All Services Form</h1>
                <p class="text-muted-foreground text-lg max-w-2xl mx-auto">Request a comprehensive service for your vehicle.</p>
            </div>
            <div class="card text-center">
                <p class="text-red-400">Form file not found. Please contact the administrator.</p>
            </div>
        </div>
    </section>
    <?php
}

get_footer();
?>

