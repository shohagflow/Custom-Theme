# PHASE 1: PARTNER SERVICES INTEGRATION ANALYSIS REPORT

## EXECUTIVE SUMMARY

This report analyzes the existing form-based request workflow system and identifies integration points for making Partner Services fully functional. The analysis confirms that **NO new request system needs to be created** - the existing workflow can be reused entirely.

---

## 1. EXISTING FORM-BASED REQUEST WORKFLOW (STEP-BY-STEP)

### 1.1 Form Submission Flow

**Files Involved:**
- `form/car-accessories-form.php` - Form HTML
- `functions.php` - Handler functions

**Step-by-Step Process:**

1. **Form Submission** (`form/car-accessories-form.php`)
   - Customer fills out form (make, model, year, services, etc.)
   - Form submits via POST to `home_url('/car-accessories-form')`
   - Nonce: `car_accessories_nonce` with action `car_accessories_form`

2. **Form Handler** (`functions.php` - `wheelfy_handle_all_services_form()`)
   - Hook: `add_action('init', 'wheelfy_handle_all_services_form', 0)`
   - Validates nonce: `car_accessories_form`
   - Sanitizes all form fields
   - Creates unique `request_id`: `uniqid('req_', true)`
   - Saves form data to **transient**: `car_accessories_request_{request_id}`
   - Transient expires in: `30 * DAY_IN_SECONDS`
   - Redirects to: `/select-partner?request_id={request_id}`

3. **Partner Selection** (`page-select-partner.php`)
   - Displays available partners (filtered by tier/type)
   - Customer selects one or more partners
   - Form submits via POST with nonce: `select_partner_nonce`

4. **Partner Selection Handler** (`functions.php` - `wheelfy_handle_partner_selection()`)
   - Hook: `add_action('init', 'wheelfy_handle_partner_selection', 0)`
   - Validates nonce: `select_partner`
   - Retrieves form data from transient using `request_id`
   - For each selected partner:
     - Creates partner-specific transient: `car_accessories_request_{request_id}_partner_{partner_id}`
     - Sets `status = 'pending'`
     - Sets `partner_id`, `customer_id`, `customer_email`, `selected_at`
     - Extends transient to 30 days
   - **Saves to User Meta** (if logged in):
     - Meta key: `customer_service_requests`
     - Structure:
       ```php
       array(
           'request_id' => $request_id,
           'partner_id' => $partner_id,
           'status' => 'pending',
           'created_at' => current_time('mysql'),
           'form_data' => $form_data
       )
       ```
   - **Creates Notifications**:
     - Calls `wheelfy_create_notification()` for each partner
     - Type: `new_request`
     - Includes request_id, customer_id, customer_name, link
   - **Sends Email Notifications**:
     - Calls `wheelfy_send_new_request_email_to_partner()` for each partner
   - Redirects to: `/partner-quotation?request_id={request_id}&partner_id={first_partner_id}`

### 1.2 Request Status Lifecycle

**Status Transitions:**
- `pending` → `accepted` / `rejected` / `deleted`
- `accepted` → `completed` (via completion request)

**Key Functions:**

1. **Update Request Status** (`functions.php` - `wheelfy_update_request_status()`)
   - AJAX Handler: `wp_ajax_update_request_status`
   - Nonce: `wheelfy_nonce`
   - Updates transient: `car_accessories_request_{request_id}_partner_{partner_id}`
   - Updates user meta: `customer_service_requests` (for logged-in customers)
   - Updates post meta (if request stored as post): `_proposal_status`, `partner_id`, `status_updated_at`
   - **On Accept**:
     - Creates chat thread: `wheelfy_get_or_create_thread($customer_id, $partner_id, $request_id)`
     - Creates notification for customer: `request_accepted`
     - Sends email: `wheelfy_send_request_accepted_email_to_customer()`
   - **On Reject/Delete**:
     - Creates notification for customer: `request_rejected`

2. **Get Partner Requests** (`functions.php` - `wheelfy_get_partner_requests()`)
   - AJAX Handler: `wp_ajax_get_partner_requests`
   - Calls: `wheelfy_get_partner_requests_data($partner_id, $status_filter)`
   - Returns requests from:
     - Transients: `car_accessories_request_*_partner_{partner_id}`
     - User meta: `customer_service_requests` (scans all customers)
     - Posts: Custom post type with `_proposal_request_type` meta

3. **Get Customer Requests** (`functions.php` - `wheelfy_ajax_get_customer_requests()`)
   - AJAX Handler: `wp_ajax_get_customer_requests`
   - Returns requests from:
     - User meta: `customer_service_requests`
     - Transients: `car_accessories_request_*`
     - Posts: Custom post type

### 1.3 Data Storage Structure

**Transient Storage:**
- Key pattern: `car_accessories_request_{request_id}_partner_{partner_id}`
- Contains: Full form data + `partner_id`, `status`, `customer_id`, `customer_email`, `selected_at`, `updated_at`
- Expiry: 30 days

**User Meta Storage:**
- Key: `customer_service_requests`
- Type: Array of request entries
- Structure:
  ```php
  array(
      array(
          'request_id' => 'req_xxx',
          'partner_id' => 123,
          'status' => 'pending',
          'created_at' => '2024-01-01 12:00:00',
          'form_data' => array(...)
      ),
      ...
  )
  ```

**Post Meta Storage (Alternative):**
- Post type: `post` (standard WordPress post)
- Meta keys:
  - `_proposal_request_type`
  - `_proposal_request_id`
  - `_proposal_status`
  - `partner_id`
  - `status_updated_at`

---

## 2. FILES & FUNCTIONS RESPONSIBLE FOR REQUEST LIFECYCLE

### 2.1 Form Submission Handlers

| Function | File | Hook | Purpose |
|----------|------|------|---------|
| `wheelfy_handle_all_services_form()` | `functions.php:3055` | `init` (priority 0) | Handles Car Accessories Form submission |
| `wheelfy_handle_sell_car_form()` | `functions.php:2800` | `init` (priority 0) | Handles Sell Car Form submission |
| `wheelfy_handle_service_book_form()` | `functions.php:2966` | `init` (priority 0) | Handles Service Book Form submission |
| `wheelfy_handle_previous_service_form()` | `functions.php:3042` | `init` (priority 0) | Handles Previous Service Form submission |

### 2.2 Partner Selection & Request Creation

| Function | File | Hook | Purpose |
|----------|------|------|---------|
| `wheelfy_handle_partner_selection()` | `functions.php:3126` | `init` (priority 0) | Creates requests for selected partners |

### 2.3 Request Status Management

| Function | File | Hook | Purpose |
|----------|------|------|---------|
| `wheelfy_update_request_status()` | `functions.php:3373` | `wp_ajax_update_request_status` | Updates request status (accept/reject/delete) |
| `wheelfy_get_partner_requests()` | `functions.php:3505` | `wp_ajax_get_partner_requests` | Fetches partner's requests |
| `wheelfy_get_partner_requests_data()` | `functions.php:3537` | N/A | Helper: Gets partner requests from all sources |
| `wheelfy_ajax_get_customer_requests()` | `functions.php:3983` | `wp_ajax_get_customer_requests` | Fetches customer's requests |

### 2.4 Notification & Email Functions

| Function | File | Purpose |
|----------|------|---------|
| `wheelfy_create_notification()` | `functions.php` | Creates dashboard notification |
| `wheelfy_send_new_request_email_to_partner()` | `functions.php` | Sends email to partner on new request |
| `wheelfy_send_request_accepted_email_to_customer()` | `functions.php` | Sends email to customer on acceptance |

### 2.5 Dashboard Display

| File | Purpose |
|------|---------|
| `page-dashboard-partner.php` | Partner dashboard - displays requests, handles accept/reject |
| `page-dashboard-customer.php` | Customer dashboard - displays requests, shows status |
| `page-select-partner.php` | Partner selection page after form submission |

---

## 3. HOW PARTNER SERVICES ARE CURRENTLY STORED & RENDERED

### 3.1 Current State: **NOT FUNCTIONAL**

**Storage:**
- ❌ **NO storage mechanism exists**
- Services are displayed using **hardcoded dummy data** in `page-dashboard-partner.php:5052-5075`

**Display:**
- ✅ Services UI exists in Partner Dashboard (`page-dashboard-partner.php:5037-5152`)
- ❌ Services are **NOT displayed** on Partner Public Profile (`page-partner-profile.php`)
- ❌ No JavaScript handlers for Add/Edit/Delete buttons

**Code Location:**
- `page-dashboard-partner.php:5050-5075` - Dummy services array
- `page-dashboard-partner.php:5042` - "Add Service" button (`id="addServiceBtn"`)
- `page-dashboard-partner.php:5132` - "Edit" button (`class="edit-service-btn"`)
- `page-dashboard-partner.php:5139` - "Delete" button (`class="delete-service-btn"`)

### 3.2 Missing Components

1. **JavaScript Handlers:**
   - No event listener for `addServiceBtn`
   - No event listener for `edit-service-btn`
   - No event listener for `delete-service-btn`
   - No service modal/form UI

2. **AJAX Handlers:**
   - No `wp_ajax_save_partner_service` handler
   - No `wp_ajax_delete_partner_service` handler
   - No `wp_ajax_get_partner_services` handler

3. **Storage:**
   - No user meta key for services (e.g., `partner_services`)
   - No custom post type for services
   - No custom table for services

4. **Public Profile Display:**
   - No services section in `page-partner-profile.php`
   - No service cards/listing

---

## 4. EXACT INTEGRATION POINTS TO REUSE EXISTING REQUEST SYSTEM

### 4.1 Service Storage Recommendation

**Option: User Meta (Recommended)**
- Meta key: `partner_services`
- Structure:
  ```php
  array(
      array(
          'id' => uniqid('svc_', true),
          'title' => 'Car Maintenance & Oil Change',
          'description' => '...',
          'price' => 45.00,
          'price_currency' => 'EUR',
          'duration' => '1-2 hours',
          'category' => 'Maintenance',
          'status' => 'active', // active, inactive
          'created_at' => current_time('mysql'),
          'updated_at' => current_time('mysql')
      ),
      ...
  )
  ```
- **Why User Meta?**
  - Simple, no custom tables needed
  - WordPress native storage
  - Easy to query and update
  - Consistent with existing pattern (`customer_service_requests`)

### 4.2 Request Creation from Service

**Integration Point: `wheelfy_handle_partner_selection()`**

**When customer selects a service from partner profile:**

1. **Create Form Data Structure:**
   ```php
   $form_data = array(
       'request_type' => 'service', // NEW: Identify as service-based request
       'service_id' => $service_id, // NEW: Service identifier
       'service_title' => $service['title'],
       'service_price' => $service['price'],
       'service_duration' => $service['duration'],
       'service_category' => $service['category'],
       'partner_id' => $partner_id, // Already known (service belongs to partner)
       'customer_id' => $current_user_id,
       'customer_email' => $customer_email,
       'status' => 'pending',
       'created_at' => current_time('mysql')
   );
   ```

2. **Reuse Existing Flow:**
   - Create `request_id`: `uniqid('req_', true)`
   - Save to transient: `car_accessories_request_{request_id}_partner_{partner_id}`
   - Save to user meta: `customer_service_requests`
   - Create notification: `wheelfy_create_notification()`
   - Send email: `wheelfy_send_new_request_email_to_partner()`
   - **NO changes needed** to `wheelfy_handle_partner_selection()` - it already handles this structure!

3. **Request Display:**
   - Partner dashboard: Already displays requests from transients/user meta
   - Customer dashboard: Already displays requests from user meta
   - **NO changes needed** - existing display logic will work

4. **Status Updates:**
   - Partner accepts: `wheelfy_update_request_status()` already handles this
   - Partner rejects: `wheelfy_update_request_status()` already handles this
   - Request completion: Existing completion flow works
   - **NO changes needed**

### 4.3 Service Selection UI on Partner Profile

**New Component Needed:**
- Add services section to `page-partner-profile.php`
- Display service cards with "Request Service" button
- On click, create request using existing workflow

**Implementation:**
```php
// In page-partner-profile.php
$partner_services = get_user_meta($partner_id, 'partner_services', true);
if (!is_array($partner_services)) {
    $partner_services = array();
}
// Filter active services only
$active_services = array_filter($partner_services, function($service) {
    return isset($service['status']) && $service['status'] === 'active';
});

// Display service cards
foreach ($active_services as $service) {
    // Show service card with "Request Service" button
    // Button links to: /request-service?service_id={id}&partner_id={partner_id}
}
```

**Request Handler:**
- New handler: `wheelfy_handle_service_request()` in `functions.php`
- Reuses `wheelfy_handle_partner_selection()` logic
- Creates request with `request_type = 'service'` and `service_id`

---

## 5. CONFIRMATION: NO NEW REQUEST LOGIC NEEDED

### ✅ Confirmed: Existing System is Fully Reusable

**Evidence:**

1. **Request Creation:**
   - `wheelfy_handle_partner_selection()` accepts any `form_data` array
   - It doesn't validate specific form fields - only requires `partner_id`, `customer_id`, `status`
   - Service data can be added to `form_data` without breaking existing logic

2. **Request Storage:**
   - Transient system is generic: `car_accessories_request_{request_id}_partner_{partner_id}`
   - User meta system is generic: `customer_service_requests` array
   - Both accept any data structure in `form_data`

3. **Request Display:**
   - Partner dashboard reads from transients/user meta - doesn't care about request source
   - Customer dashboard reads from user meta - doesn't care about request source
   - Both display `form_data` generically

4. **Status Updates:**
   - `wheelfy_update_request_status()` works with any request stored in transient/user meta
   - It only needs `request_id` and `partner_id` - doesn't validate request type

5. **Notifications & Emails:**
   - `wheelfy_create_notification()` accepts any metadata
   - Email functions accept `form_data` - can include service info

### ✅ Only New Components Needed:

1. **Service Management (CRUD):**
   - Save service: `wp_ajax_save_partner_service`
   - Delete service: `wp_ajax_delete_partner_service`
   - Get services: Read from `partner_services` user meta

2. **Service Display:**
   - Partner Dashboard: Replace dummy data with real services from user meta
   - Partner Profile: Add services section

3. **Service Request Creation:**
   - New handler: `wheelfy_handle_service_request()` (reuses existing logic)
   - Service selection UI on partner profile

---

## 6. GAP ANALYSIS: WHAT IS MISSING

### 6.1 Partner Services Management

| Component | Status | Location | Action Needed |
|-----------|--------|----------|---------------|
| Service Storage | ❌ Missing | N/A | Create user meta: `partner_services` |
| Add Service UI | ❌ Missing | `page-dashboard-partner.php` | Create modal/form |
| Add Service Handler | ❌ Missing | `functions.php` | Create `wp_ajax_save_partner_service` |
| Edit Service Handler | ❌ Missing | `functions.php` | Reuse `wp_ajax_save_partner_service` |
| Delete Service Handler | ❌ Missing | `functions.php` | Create `wp_ajax_delete_partner_service` |
| Service Display (Dashboard) | ⚠️ Dummy Data | `page-dashboard-partner.php:5052` | Replace with real data |
| Service Display (Profile) | ❌ Missing | `page-partner-profile.php` | Add services section |

### 6.2 Service Request Creation

| Component | Status | Location | Action Needed |
|-----------|--------|----------|---------------|
| Service Selection UI | ❌ Missing | `page-partner-profile.php` | Add service cards with "Request" button |
| Service Request Handler | ❌ Missing | `functions.php` | Create `wheelfy_handle_service_request()` |
| Request Type Identifier | ⚠️ Partial | `functions.php` | Add `request_type = 'service'` to form_data |

### 6.3 Integration with Existing System

| Integration Point | Status | Action Needed |
|-------------------|--------|---------------|
| Request Creation | ✅ Ready | Add service data to `form_data`, reuse `wheelfy_handle_partner_selection()` |
| Request Storage | ✅ Ready | No changes - transients/user meta accept any data |
| Request Display | ✅ Ready | No changes - existing display works |
| Status Updates | ✅ Ready | No changes - existing handlers work |
| Notifications | ✅ Ready | No changes - existing functions work |
| Emails | ✅ Ready | No changes - existing functions work |

---

## 7. SAFE EXTENSION POINTS

### 7.1 Functions That Can Be Extended (No Breaking Changes)

1. **`wheelfy_handle_partner_selection()`**
   - **Safe to use:** ✅
   - **Extension:** Add service-specific data to `form_data` before calling
   - **No modification needed:** Function already handles generic `form_data`

2. **`wheelfy_update_request_status()`**
   - **Safe to use:** ✅
   - **Extension:** None needed - works with any request
   - **No modification needed**

3. **`wheelfy_get_partner_requests_data()`**
   - **Safe to use:** ✅
   - **Extension:** None needed - reads from transients/user meta generically
   - **No modification needed**

4. **`wheelfy_ajax_get_customer_requests()`**
   - **Safe to use:** ✅
   - **Extension:** None needed - reads from user meta generically
   - **No modification needed**

### 7.2 New Functions to Create (No Conflicts)

1. **`wheelfy_save_partner_service()`**
   - New AJAX handler
   - Saves to `partner_services` user meta
   - No conflicts with existing code

2. **`wheelfy_delete_partner_service()`**
   - New AJAX handler
   - Removes from `partner_services` user meta
   - No conflicts with existing code

3. **`wheelfy_handle_service_request()`**
   - New form handler (similar to `wheelfy_handle_partner_selection()`)
   - Creates request with service data
   - Reuses existing notification/email functions
   - No conflicts with existing code

4. **`wheelfy_get_partner_services()`**
   - Helper function
   - Reads from `partner_services` user meta
   - No conflicts with existing code

---

## 8. SECURITY & QUALITY REQUIREMENTS (Already Met by Existing System)

### ✅ Nonce Verification
- All existing handlers use nonces
- New handlers must follow same pattern

### ✅ Input Sanitization
- All existing handlers sanitize inputs
- New handlers must follow same pattern

### ✅ Output Escaping
- All existing displays escape outputs
- New displays must follow same pattern

### ✅ Capability Checks
- Existing handlers check user roles (`partner`, `customer`)
- New handlers must follow same pattern

---

## 9. SUMMARY & RECOMMENDATIONS

### ✅ Confirmation: NO New Request System Needed

The existing form-based request workflow is **fully reusable** for service-based requests. The system is designed generically and accepts any data structure in `form_data`.

### 📋 Implementation Checklist

**Phase 2 Implementation Should Include:**

1. **Service Management:**
   - [ ] Create `partner_services` user meta storage
   - [ ] Add service modal/form UI in Partner Dashboard
   - [ ] Create `wp_ajax_save_partner_service` handler
   - [ ] Create `wp_ajax_delete_partner_service` handler
   - [ ] Replace dummy services with real data in Partner Dashboard
   - [ ] Add services section to Partner Public Profile

2. **Service Request Creation:**
   - [ ] Add service cards to Partner Profile with "Request Service" button
   - [ ] Create `wheelfy_handle_service_request()` handler
   - [ ] Ensure service data is included in `form_data` with `request_type = 'service'`

3. **Integration (No Changes Needed):**
   - [x] Request creation - Reuse `wheelfy_handle_partner_selection()` logic
   - [x] Request storage - Reuse transient/user meta system
   - [x] Request display - Reuse existing dashboard displays
   - [x] Status updates - Reuse `wheelfy_update_request_status()`
   - [x] Notifications - Reuse `wheelfy_create_notification()`
   - [x] Emails - Reuse existing email functions

### 🎯 Key Insight

**The existing request system is a generic workflow that doesn't care about the source of the request.** Whether it comes from a form submission or a service selection, the same storage, display, and status management logic applies. This makes integration straightforward and safe.

---

## END OF PHASE 1 REPORT

**Status:** ✅ Analysis Complete  
**Next Step:** Await user approval to proceed with Phase 2 Implementation  
**Confidence Level:** High - All integration points identified, no blockers found
