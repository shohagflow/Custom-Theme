<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <?php wp_head(); ?>
    <style>
    /* Dynamic Header Styles - Applied Immediately */
    <?php
    // Get all header settings for inline CSS
    $header_height_desktop = wheelfy_get_header_option('header_height_desktop', '80');
    $header_height_mobile = wheelfy_get_header_option('header_height_mobile', '60');
    $header_bg_color = wheelfy_get_header_option('header_bg_color', '#1a1d2e');
    $header_bg_opacity = wheelfy_get_header_option('header_bg_opacity', '100');
    $header_sticky = wheelfy_get_header_option('header_sticky', true);
    $header_show_border = wheelfy_get_header_option('header_show_border', true);
    $header_border_color = wheelfy_get_header_option('header_border_color', 'rgba(255, 255, 255, 0.05)');
    $menu_font_size = wheelfy_get_header_option('header_menu_font_size', '15');
    $menu_spacing = wheelfy_get_header_option('header_menu_spacing', '4');
    $mobile_animation_speed = wheelfy_get_header_option('header_mobile_animation_speed', '300');
    $mobile_bg_color = wheelfy_get_header_option('header_mobile_bg_color', '#000000');
    $logo_height_desktop = wheelfy_get_header_option('header_logo_height_desktop', '40');
    $logo_height_mobile = wheelfy_get_header_option('header_logo_height_mobile', '32');
    
    // Calculate background color with opacity
    $bg_color_rgb = '';
    if ($header_bg_color) {
        if (strpos($header_bg_color, '#') === 0) {
            $hex = str_replace('#', '', $header_bg_color);
            $r = hexdec(substr($hex, 0, 2));
            $g = hexdec(substr($hex, 2, 2));
            $b = hexdec(substr($hex, 4, 2));
            $opacity = $header_bg_opacity / 100;
            $bg_color_rgb = "rgba({$r}, {$g}, {$b}, {$opacity})";
        } else {
            $bg_color_rgb = $header_bg_color;
        }
    } else {
        $bg_color_rgb = "rgba(26, 29, 46, " . ($header_bg_opacity / 100) . ")";
    }
    ?>
    /* Header Layout - Dynamic Styles */
    .desktop-header {
        height: <?php echo esc_attr($header_height_desktop); ?>px !important;
        background-color: <?php echo esc_attr($bg_color_rgb); ?> !important;
        <?php if ($header_show_border && $header_border_color) : ?>
        border-bottom: 1px solid <?php echo esc_attr($header_border_color); ?> !important;
        <?php else : ?>
        border-bottom: none !important;
        <?php endif; ?>
        <?php if ($header_sticky) : ?>
        position: sticky !important;
        <?php else : ?>
        position: fixed !important;
        <?php endif; ?>
        z-index: 9999 !important;
    }
    
    @media (max-width: 1023px) {
        .mobile-header-layout {
            height: <?php echo esc_attr($header_height_mobile); ?>px !important;
        }
    }
    
    /* Logo Settings - Dynamic Heights */
    .desktop-header .desktop-header-layout img {
        max-height: <?php echo esc_attr($logo_height_desktop); ?>px !important;
        height: auto !important;
    }
    
    @media (max-width: 1023px) {
        .mobile-header-layout img {
            max-height: <?php echo esc_attr($logo_height_mobile); ?>px !important;
            height: auto !important;
        }
    }
    
    /* Navigation Menu - Dynamic Font Size and Spacing */
    .desktop-header-nav ul {
        font-size: <?php echo esc_attr($menu_font_size); ?>px !important;
        gap: <?php echo esc_attr($menu_spacing); ?>px !important;
    }
    
    .desktop-header-nav .button-nav {
        font-size: <?php echo esc_attr($menu_font_size); ?>px !important;
    }
    
    /* Header Container - Fixed max-width for all pages */
    .desktop-header .desktop-header-nav.container {
        max-width: 1400px !important;
        width: 100% !important;
    }
    
    header .desktop-header-nav.container {
        max-width: 1400px !important;
        width: 100% !important;
    }
    
    /* Mobile Menu - Dynamic Background and Animation */
    #mobile-menu {
        background-color: <?php echo esc_attr($mobile_bg_color); ?> !important;
        transition-duration: <?php echo esc_attr($mobile_animation_speed); ?>ms !important;
    }
    
    #mobile-menu-overlay {
        transition-duration: <?php echo esc_attr($mobile_animation_speed); ?>ms !important;
    }
    
    /* Profile Dropdown Styles */
    .profile-dropdown-container {
        position: relative;
        display: inline-block;
    }
    
    .profile-dropdown-menu {
min-width: fit-content;
    animation: fadeInDown 0.2s ease-out;
    right: -35px;
    top: 100%;
    margin-top: 8px;
    transform-origin: top right;
    }
    
    @keyframes fadeInDown {
        from {
            opacity: 0;
            transform: translateY(-10px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .profile-dropdown-menu a {
        text-decoration: none;
    }
    
    .profile-dropdown-menu a:hover {
        text-decoration: none;
    }
    
    /* Header Spacer */
    .header-spacer {
        height: <?php echo esc_attr($header_height_desktop); ?>px !important;
    }
    
    /* Notification Badge Styles - Image Style with Theme Colors */
    .profile-icon-link {
        position: relative;
        overflow: visible !important;
    }
    
    #headerNotificationBadge {
        position: absolute;
        top: -6px;
        right: -10px;
        min-width: 22px;
        height: 22px;
        width: 20px;
        padding: 0 8px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: linear-gradient(135deg, hsl(60 96% 79%), hsl(186 80% 19%));
        color:rgb(0, 0, 0);
        font-size: 11px;
        font-weight: 700;
        line-height: 1.2;
        border-radius: 10px; /* Rounded rectangular/oval shape */
        border: 1px solid rgb(255, 255, 255); /* White border like image */
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.25), 0 0 0 0.5px rgba(255, 255, 255, 0.5);
        z-index: 20;
        transition: all 0.2s ease;
        pointer-events: none; /* Allow clicks to pass through to profile button */
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
    }
    
    #headerNotificationBadge:hover {
        transform: scale(1.08);
        box-shadow: 0 3px 8px rgba(0, 0, 0, 0.35), 0 0 0 0.5px rgba(255, 255, 255, 0.6);
    }
    
    #headerNotificationCount {
        font-size: 11px;
        font-weight: 700;
        line-height: 1.2;
        letter-spacing: -0.2px;
        color: #ffffff;
        text-align: center;
        white-space: nowrap;
    }
    
    #headerNotificationBadge:empty {
        display: none !important;
    }
    
    /* Ensure profile image container allows overflow for badge */
    .profile-dropdown-container {
        overflow: visible;
    }
    
    /* For numbers 10+, make badge slightly wider */
    #headerNotificationBadge:has(#headerNotificationCount:contains("+")) {
        min-width: 26px;
        padding: 0 7px;
    }
    </style>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<?php
/**
 * Get Header Settings from CMB2 Options
 */
// Get logo URL using helper function - handles all CMB2 file field formats
$default_logo_path = get_template_directory() . '/assets/logo-main.png';
$default_logo_url = get_template_directory_uri() . '/assets/logo-main.png';

// Get raw logo value to check if custom logo is set
$options = get_option('wheelfy-header-options', array());
$logo_value_raw = isset($options['header_logo']) ? $options['header_logo'] : '';

// Get logo URL (will return default if no custom logo)
$header_logo_url = wheelfy_get_header_logo($default_logo_url);

// Check if a custom logo is actually set (not just default)
$has_custom_logo = !empty($logo_value_raw);

// Compare base URLs (without query parameters) to check if logo is custom
$header_logo_base = strtok($header_logo_url, '?'); // Remove query parameters
$default_logo_base = strtok($default_logo_url, '?'); // Remove query parameters
$is_custom_logo = $has_custom_logo && ($header_logo_base !== $default_logo_base);

$logo_height_desktop = wheelfy_get_header_option('header_logo_height_desktop', '40');
$logo_height_mobile = wheelfy_get_header_option('header_logo_height_mobile', '32');

$header_height_desktop = wheelfy_get_header_option('header_height_desktop', '80');
$header_height_mobile = wheelfy_get_header_option('header_height_mobile', '60');
$header_bg_color = wheelfy_get_header_option('header_bg_color', '#1a1d2e');
$header_bg_opacity = wheelfy_get_header_option('header_bg_opacity', '100');
$header_sticky = wheelfy_get_header_option('header_sticky', true);
$header_show_border = wheelfy_get_header_option('header_show_border', true);
$header_border_color = wheelfy_get_header_option('header_border_color', 'rgba(255, 255, 255, 0.05)');

$menu_font_size = wheelfy_get_header_option('header_menu_font_size', '15');
$menu_spacing = wheelfy_get_header_option('header_menu_spacing', '4');

$show_cta = wheelfy_get_header_option('header_show_cta', true);
$cta_text = wheelfy_get_header_option('header_cta_text', 'Register');
$cta_link = wheelfy_get_header_option('header_cta_link', '/register');

$show_login = wheelfy_get_header_option('header_show_login', true);
$login_text = wheelfy_get_header_option('header_login_text', 'Login');
$login_link = wheelfy_get_header_option('header_login_link', '/login');

$show_language = wheelfy_get_header_option('header_show_language', true);
$header_languages = wheelfy_get_header_option('header_languages', '');

// Get current language (from URL parameter, cookie, or default)
$current_lang = isset($_GET['lang']) ? sanitize_text_field($_GET['lang']) : (isset($_COOKIE['wheelfy_lang']) ? sanitize_text_field($_COOKIE['wheelfy_lang']) : 'en');

// Menu translations
$menu_translations = array(
    'en' => array(
        'home' => 'Home',
        'how_it_works' => 'How It Works',
        'car_maintenance' => 'Car Maintenance',
        'car_sales' => 'Car Sales',
        'partners' => 'Partners',
        'pricing' => 'Pricing',
        'login' => 'Login',
        'register' => 'Register',
    ),
    'hu' => array(
        'home' => 'Otthon',
        'how_it_works' => 'Hogyan működik',
        'car_maintenance' => 'Autókarbantartás',
        'car_sales' => 'Autóeladások',
        'partners' => 'Partnerek',
        'pricing' => 'Árazás',
        'login' => 'Bejelentkezés',
        'register' => 'Nyilvántartás',
    ),
    'de' => array(
        'home' => 'Startseite',
        'how_it_works' => 'Wie es funktioniert',
        'car_maintenance' => 'Autowartung',
        'car_sales' => 'Autoverkauf',
        'partners' => 'Partner',
        'pricing' => 'Preise',
        'login' => 'Anmelden',
        'register' => 'Registrieren',
    ),
);

// Get translations for current language, fallback to English
$menu_texts = isset($menu_translations[$current_lang]) ? $menu_translations[$current_lang] : $menu_translations['en'];

$mobile_bg_color = wheelfy_get_header_option('header_mobile_bg_color', '#000000');
$mobile_animation_speed = wheelfy_get_header_option('header_mobile_animation_speed', '300');

$header_additional_text = wheelfy_get_header_option('header_additional_text', '');
$show_widgets = wheelfy_get_header_option('header_show_widgets', true);

// Calculate background color with opacity
$bg_color_rgb = '';
if ($header_bg_color) {
    if (strpos($header_bg_color, '#') === 0) {
        $hex = str_replace('#', '', $header_bg_color);
        $r = hexdec(substr($hex, 0, 2));
        $g = hexdec(substr($hex, 2, 2));
        $b = hexdec(substr($hex, 4, 2));
        $opacity = $header_bg_opacity / 100;
        $bg_color_rgb = "rgba({$r}, {$g}, {$b}, {$opacity})";
    } else {
        $bg_color_rgb = $header_bg_color;
    }
} else {
    $bg_color_rgb = "rgba(26, 29, 46, " . ($header_bg_opacity / 100) . ")";
}

// Build inline styles for header
$header_style = "height: {$header_height_desktop}px !important;";
if ($bg_color_rgb) {
    $header_style .= " background-color: {$bg_color_rgb} !important;";
}
if ($header_show_border && $header_border_color) {
    $header_style .= " border-bottom: 1px solid {$header_border_color} !important;";
} elseif (!$header_show_border) {
    $header_style .= " border-bottom: none !important;";
}

// Sticky header positioning
$position_style = $header_sticky ? 'sticky' : 'fixed';
$header_style .= " position: {$position_style} !important;";
$header_style .= " z-index: 9999 !important;"; // Ensure header is always on top

// Build navigation menu inline styles
$nav_menu_style = "font-size: {$menu_font_size}px !important; gap: {$menu_spacing}px !important;";

// Mobile menu background color
$mobile_menu_style = "background-color: {$mobile_bg_color} !important; transition-duration: {$mobile_animation_speed}ms !important;";
$mobile_overlay_style = "transition-duration: {$mobile_animation_speed}ms !important;";
?>
<div class="min-h-screen flex flex-col">
    <header class="<?php echo esc_attr($position_style); ?> top-0 left-0 right-0 header-mobile desktop-header" style="<?php echo esc_attr($header_style); ?>">
        <nav class="container mx-auto px-4 lg:px-8 h-full desktop-header-nav">
            <!-- Desktop Layout: Logo | Navigation | Actions - All in One Line -->
            <div class="hidden lg:grid grid-cols-3 items-center h-full desktop-header-layout">
                <!-- Logo - Left -->
                <div class="flex items-center">
                    <a href="<?php echo esc_url(home_url('/')); ?>" class="flex items-center gap-3 hover:opacity-80 transition-opacity">
                        <?php 
                        // Priority: CMB2 logo > Default logo > Custom logo > Site name
                        // Use custom logo if set, otherwise use default
                        if ($is_custom_logo && $header_logo_url) : ?>
                            <img src="<?php echo esc_url($header_logo_url); ?>" alt="<?php echo esc_attr(get_bloginfo('name')); ?>" style="height: <?php echo esc_attr($logo_height_desktop); ?>px; width: auto; max-height: <?php echo esc_attr($logo_height_desktop); ?>px;" loading="eager">
                        <?php elseif (file_exists($default_logo_path)) : ?>
                            <img src="<?php echo esc_url($default_logo_url); ?>" alt="<?php echo esc_attr(get_bloginfo('name')); ?>" style="height: <?php echo esc_attr($logo_height_desktop); ?>px; width: auto; max-height: <?php echo esc_attr($logo_height_desktop); ?>px;" loading="eager">
                        <?php elseif (has_custom_logo()) : ?>
                            <?php the_custom_logo(); ?>
                        <?php else : ?>
                            <div class="w-10 h-10 rounded-xl bg-primary flex items-center justify-center">
                                <svg class="w-6 h-6 text-primary-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                                </svg>
                            </div>
                            <span class="text-xl font-bold text-white"><?php bloginfo('name'); ?></span>
                        <?php endif; ?>
                    </a>
                </div>

                <!-- Desktop Navigation - Center -->
                <div class="flex items-center justify-center w-full">
                    <nav role="navigation" aria-label="Primary Navigation" class="w-full flex justify-center">
                        <?php
                        // Dynamic WordPress Menu
                        wp_nav_menu(array(
                            'theme_location' => 'primary',
                            'container' => false,
                            'menu_class' => 'flex items-center justify-center',
                            'menu_id' => 'primary-menu',
                            'fallback_cb' => 'wheelfy_fallback_menu_desktop',
                            'items_wrap' => '<ul class="flex items-center justify-center" style="display: flex !important; list-style: none; margin: 0; padding: 0; ' . esc_attr($nav_menu_style) . '">%3$s</ul>',
                            'walker' => new Wheelfy_Walker_Header_Menu(),
                        ));
                        ?>
                    </nav>
                </div>

                <!-- Right Side Actions - Right -->
                <div class="flex items-center justify-end gap-4">
                    <?php if ($header_additional_text) : ?>
                        <span class="text-white text-sm"><?php echo esc_html($header_additional_text); ?></span>
                    <?php endif; ?>
                    
                    <!-- Header Widget Area -->
                    <?php if ($show_widgets && is_active_sidebar('header-widget-area')) : ?>
                        <div class="header-widget-area flex items-center gap-3">
                            <?php dynamic_sidebar('header-widget-area'); ?>
                        </div>
                    <?php endif; ?>
                    
                    <!-- Language Switcher -->
                    <?php if ($show_language && !empty($header_languages)) : ?>
                    <div class="header-language-switcher">
                        <?php 
                        // Output shortcode or HTML code
                        // First check if it's a shortcode (contains brackets)
                        if (preg_match('/\[.+\]/', $header_languages)) {
                            // It's a shortcode, process it
                            echo do_shortcode($header_languages);
                        } else {
                            // It's HTML code, output it directly (with proper escaping for security)
                            echo wp_kses_post($header_languages);
                        }
                        ?>
                    </div>
                    <?php endif; ?>

                    <?php if (is_user_logged_in()) : 
                        $current_user = wp_get_current_user();
                        $user_roles = $current_user->roles;
                        $user_id = $current_user->ID;
                        
                        // Determine dashboard URL based on user role
                        $dashboard_url = home_url('/customer-dashboard');
                        if (in_array('partner', $user_roles)) {
                            $dashboard_url = home_url('/partner-dashboard');
                        } elseif (in_array('administrator', $user_roles)) {
                            $dashboard_url = admin_url();
                        }
                        
                        // Get logout URL
                        $logout_url = wp_logout_url(home_url('/'));
                        
                        // Get user avatar - check for custom profile image first
                        $profile_image_id = get_user_meta($user_id, 'profile_image_id', true);
                        if ($profile_image_id && is_numeric($profile_image_id)) {
                            $user_avatar = wp_get_attachment_image_url($profile_image_id, 'thumbnail');
                        } else {
                            // Fall back to Gravatar
                            $user_avatar = get_avatar_url($user_id, array('size' => 40));
                        }
                        $user_name = $current_user->display_name ?: $current_user->user_login;
                        $user_initial = strtoupper(substr($user_name, 0, 1));
                        
                        // Get initial notification count
                        $initial_notification_count = wheelfy_get_unread_notification_count($user_id);
                    ?>
                        <!-- Profile Dropdown -->
                        <div class="relative profile-dropdown-container">
                            <!-- Profile Icon Button -->
                            <button type="button" class="profile-icon-link flex items-center justify-center w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 transition-colors cursor-pointer overflow-hidden focus:outline-none focus:ring-2 focus:ring-white/30 relative" id="profileDropdownBtn" aria-label="<?php echo esc_attr($user_name); ?>" aria-expanded="false" aria-haspopup="true">
                                <?php if ($user_avatar) : ?>
                                    <img src="<?php echo esc_url($user_avatar); ?>" alt="<?php echo esc_attr($user_name); ?>" class="w-full h-full rounded-full object-cover" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                                    <span class="text-white font-semibold text-sm hidden items-center justify-center w-full h-full"><?php echo esc_html($user_initial); ?></span>
                                <?php else : ?>
                                    <span class="text-white font-semibold text-sm"><?php echo esc_html($user_initial); ?></span>
                                <?php endif; ?>
                                <!-- Notification Badge -->
                                <span id="headerNotificationBadge" class="<?php echo ($initial_notification_count > 0) ? '' : 'hidden'; ?>">
                                    <span id="headerNotificationCount"><?php echo esc_html($initial_notification_count > 99 ? '99+' : $initial_notification_count); ?></span>
                                </span>
                            </button>
                            
                            <!-- Dropdown Menu -->
                            <div class="profile-dropdown-menu absolute right-0 w-48 bg-white rounded-lg shadow-lg border border-gray-200 py-1 z-50 hidden" id="profileDropdownMenu" role="menu">
                                <a href="<?php echo esc_url($dashboard_url); ?>" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 transition-colors flex items-center gap-2" role="menuitem">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path>
                                    </svg>
                                    <?php _e('Dashboard', 'wheelfy'); ?>
                                </a>
                                <div class="border-t border-gray-200 my-1"></div>
                                <a href="<?php echo esc_url($logout_url); ?>" class="block px-4 py-2 text-sm text-red-600 hover:bg-red-50 transition-colors flex items-center gap-2" role="menuitem">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path>
                                    </svg>
                                    <?php _e('Logout', 'wheelfy'); ?>
                                </a>
                            </div>
                        </div>
                    <?php else : ?>
                        <?php if ($show_login) : ?>
                        <a href="<?php echo esc_url(home_url($login_link)); ?>" class="px-4 py-2 text-white hover:text-[#fdfd96] transition-colors font-medium rounded-lg hover:bg-white/5">
                            <?php echo esc_html($menu_texts['login']); ?>
                        </a>
                        <?php endif; ?>
                        
                        <?php if ($show_cta) : ?>
                        <a href="<?php echo esc_url(home_url($cta_link)); ?>" class="button button-hero px-6 py-2.5 rounded-lg font-semibold">
                            <?php echo esc_html($menu_texts['register']); ?>
                        </a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Mobile Layout: Logo + Hamburger -->
            <div class="lg:hidden flex items-center justify-between h-full mobile-header-layout" style="height: <?php echo esc_attr($header_height_mobile); ?>px;">
                <!-- Logo - Left -->
                <div class="flex items-center">
                    <a href="<?php echo esc_url(home_url('/')); ?>" class="flex items-center gap-2 hover:opacity-80 transition-opacity">
                        <?php 
                        // Priority: CMB2 logo > Default logo > Custom logo > Site name
                        // Use custom logo if set, otherwise use default
                        if ($is_custom_logo && $header_logo_url) : ?>
                            <img src="<?php echo esc_url($header_logo_url); ?>" alt="<?php echo esc_attr(get_bloginfo('name')); ?>" style="height: <?php echo esc_attr($logo_height_mobile); ?>px; width: auto; max-height: <?php echo esc_attr($logo_height_mobile); ?>px;">
                        <?php elseif (file_exists($default_logo_path)) : ?>
                            <img src="<?php echo esc_url($default_logo_url); ?>" alt="<?php echo esc_attr(get_bloginfo('name')); ?>" style="height: <?php echo esc_attr($logo_height_mobile); ?>px; width: auto; max-height: <?php echo esc_attr($logo_height_mobile); ?>px;">
                        <?php elseif (has_custom_logo()) : ?>
                            <?php the_custom_logo(); ?>
                        <?php else : ?>
                            <div class="w-8 h-8 rounded-xl bg-primary flex items-center justify-center">
                                <svg class="w-5 h-5 text-primary-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                                </svg>
                            </div>
                        <?php endif; ?>
                    </a>
                </div>

                <!-- Mobile Menu Button - Right -->
                <button class="mobile-menu-btn" id="mobile-menu-toggle" aria-label="Toggle menu">
                    <svg class="w-6 h-6 hamburger-icon" id="menu-icon" fill="none" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid meet">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M4 6h16M4 12h16M4 18h16" />
                    </svg>
                    <svg class="w-6 h-6 hamburger-icon hidden" id="close-icon" fill="none" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid meet">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>
            </div>
        </nav>

        <!-- Mobile Menu Overlay/Backdrop -->
        <div class="lg:hidden fixed inset-0 bg-black/50 backdrop-blur-sm z-40 hidden transition-opacity" id="mobile-menu-overlay" style="<?php echo esc_attr($mobile_overlay_style); ?>"></div>
        
        <!-- Mobile Menu Offcanvas - Hidden off-screen by default -->
        <div class="lg:hidden fixed top-0 right-0 bottom-0 z-50 transform translate-x-full transition-transform ease-in-out" id="mobile-menu" style="width: 85vw; max-width: 400px; height: 100vh; <?php echo esc_attr($mobile_menu_style); ?>">
            <div class="flex flex-col" style="width: 100%; max-width: 100%; height: 100vh; overflow-y: auto; overflow-x: hidden; box-sizing: border-box;">
                <!-- Mobile Menu Header -->
                <div class="flex items-center justify-between px-4 py-4 border-b border-white/10">
                    <div class="flex items-center gap-3">
                    <?php
                        // Priority: CMB2 logo > Default logo
                        // Use custom logo if set, otherwise use default
                        if ($is_custom_logo && $header_logo_url) : ?>
                            <img src="<?php echo esc_url($header_logo_url); ?>" alt="<?php echo esc_attr(get_bloginfo('name')); ?>" style="height: <?php echo esc_attr($logo_height_mobile); ?>px; width: auto; max-height: <?php echo esc_attr($logo_height_mobile); ?>px;" loading="eager">
                        <?php elseif (file_exists($default_logo_path)) : ?>
                            <img src="<?php echo esc_url($default_logo_url); ?>" alt="<?php echo esc_attr(get_bloginfo('name')); ?>" style="height: <?php echo esc_attr($logo_height_mobile); ?>px; width: auto; max-height: <?php echo esc_attr($logo_height_mobile); ?>px;" loading="eager">
                        <?php endif; ?>
                    </div>
                    <button class="p-2 text-white hover:text-white transition-colors mobile-menu-close" id="mobile-menu-close" aria-label="Close menu" style="color: #ffffff !important;">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                        </svg>
                    </button>
                </div>
                
                <!-- Mobile Menu Content -->
                <div class="flex-1 overflow-y-auto px-4">
                    <nav role="navigation" aria-label="Mobile Navigation" class="py-4">
                        <?php
                        // Dynamic WordPress Menu for Mobile
                        wp_nav_menu(array(
                            'theme_location' => 'primary',
                            'container' => false,
                            'menu_class' => 'space-y-1 mobile-menu-list',
                            'menu_id' => 'mobile-primary-menu',
                            'fallback_cb' => 'wheelfy_fallback_menu_mobile',
                            'walker' => new Wheelfy_Walker_Nav_Menu_Mobile(),
                        ));
                        ?>
                    </nav>
                    
                    <!-- Separator -->
                    <div class="border-t border-white/10 my-4"></div>
                    
                    <!-- Login and Register Section / Profile -->
                    <div class="pb-4 space-y-3">
                        <?php if (is_user_logged_in()) : 
                            $current_user = wp_get_current_user();
                            $user_roles = $current_user->roles;
                            $user_id = $current_user->ID;
                            
                            // Determine dashboard URL based on user role
                            $dashboard_url = home_url('/customer-dashboard');
                            if (in_array('partner', $user_roles)) {
                                $dashboard_url = home_url('/partner-dashboard');
                            } elseif (in_array('administrator', $user_roles)) {
                                $dashboard_url = admin_url();
                            }
                            
                            // Get user avatar - check for custom profile image first
                            $profile_image_id = get_user_meta($user_id, 'profile_image_id', true);
                            if ($profile_image_id && is_numeric($profile_image_id)) {
                                $user_avatar = wp_get_attachment_image_url($profile_image_id, 'thumbnail');
                            } else {
                                // Fall back to Gravatar
                                $user_avatar = get_avatar_url($user_id, array('size' => 40));
                            }
                            $user_name = $current_user->display_name ?: $current_user->user_login;
                            $user_initial = strtoupper(substr($user_name, 0, 1));
                        ?>
                            <!-- Profile Section with Dropdown -->
                            <div class="space-y-2">
                                <a href="<?php echo esc_url($dashboard_url); ?>" class="flex items-center gap-3 px-4 py-3.5 rounded-lg hover:bg-white/5 transition-colors">
                                    <div class="flex items-center justify-center w-10 h-10 rounded-full bg-white/10 overflow-hidden">
                                        <?php if ($user_avatar) : ?>
                                            <img src="<?php echo esc_url($user_avatar); ?>" alt="<?php echo esc_attr($user_name); ?>" class="w-full h-full rounded-full object-cover" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                                            <span class="text-white font-semibold text-sm hidden items-center justify-center w-full h-full"><?php echo esc_html($user_initial); ?></span>
                                        <?php else : ?>
                                            <span class="text-white font-semibold text-sm"><?php echo esc_html($user_initial); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="flex-1">
                                        <div class="text-white font-medium"><?php echo esc_html($user_name); ?></div>
                                        <div class="text-white/60 text-sm"><?php echo esc_html(ucfirst(in_array('partner', $user_roles) ? 'Partner' : (in_array('customer', $user_roles) ? 'Customer' : 'User'))); ?></div>
                                    </div>
                                    <svg class="w-5 h-5 text-white/60" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                                    </svg>
                                </a>
                                
                                <!-- Logout Button -->
                                <a href="<?php echo esc_url(wp_logout_url(home_url('/'))); ?>" class="flex items-center gap-3 px-4 py-3.5 rounded-lg hover:bg-red-500/10 transition-colors text-red-400 hover:text-red-300">
                                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path>
                                    </svg>
                                    <span class="font-medium"><?php _e('Logout', 'wheelfy'); ?></span>
                                </a>
                            </div>
                        <?php else : ?>
                            <?php if ($show_login) : ?>
                            <a href="<?php echo esc_url(home_url($login_link)); ?>" class="block text-white hover:text-[#fdfd96] transition-colors font-medium text-base px-4 py-3.5 rounded-lg hover:bg-white/5">
                                <?php echo esc_html($login_text); ?>
                            </a>
                            <?php endif; ?>
                            
                            <?php if ($show_cta) : ?>
                            <a href="<?php echo esc_url(home_url($cta_link)); ?>" class="button button-hero w-full block text-center px-6 py-3 rounded-lg font-semibold">
                                <?php echo esc_html($cta_text); ?>
                            </a>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <main id="main-content" class="flex-1">

