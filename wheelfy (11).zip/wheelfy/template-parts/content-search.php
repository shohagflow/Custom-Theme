<?php
/**
 * Template part for displaying search results
 *
 * @package Wheelfy
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class('bg-card rounded-2xl p-6 border border-border card-hover-smooth'); ?>>
    <header class="mb-4">
        <?php the_title(sprintf('<h2 class="text-2xl font-bold text-foreground mb-2"><a href="%s" class="hover:text-primary transition-colors">', esc_url(get_permalink())), '</a></h2>'); ?>
        <div class="text-sm text-muted-foreground">
            <span><?php echo get_the_date(); ?></span>
            <?php if (get_post_type() === 'post') : ?>
                <span class="mx-2">•</span>
                <span><?php the_category(', '); ?></span>
            <?php endif; ?>
        </div>
    </header>

    <div class="text-muted-foreground">
        <?php the_excerpt(); ?>
    </div>

    <footer class="mt-4 pt-4 border-t border-border">
        <a href="<?php echo esc_url(get_permalink()); ?>" class="text-primary hover:underline text-sm font-medium">
            <?php esc_html_e('Read More', 'wheelfy'); ?> →
        </a>
    </footer>
</article>


