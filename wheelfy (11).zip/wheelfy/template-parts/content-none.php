<?php
/**
 * Template part for displaying a message that posts cannot be found
 *
 * @package Wheelfy
 */
?>

<section class="py-24">
    <div class="container mx-auto px-4 lg:px-8">
        <div class="text-center">
            <h1 class="text-4xl font-bold text-foreground mb-4">Nothing Found</h1>
            <p class="text-lg text-muted-foreground mb-8">
                <?php
                if (is_search()) {
                    echo 'Sorry, but nothing matched your search terms. Please try again with different keywords.';
                } else {
                    echo 'It seems we can\'t find what you\'re looking for. Perhaps searching can help.';
                }
                ?>
            </p>
            <?php get_search_form(); ?>
        </div>
    </div>
</section>

