<?php
/**
 * Template part for additional features
 *
 * @package Wheelfy
 */

// Get page ID
$page_id = get_the_ID();

// Get section title and description from meta fields
$features_section_title = get_post_meta($page_id, 'hiw_features_section_title', true);
if (empty($features_section_title)) {
    $features_section_title = 'Additional Features';
}

$features_section_description = get_post_meta($page_id, 'hiw_features_section_description', true);
if (empty($features_section_description)) {
    $features_section_description = 'Our platform offers more than just price comparison.';
}

// Get additional features from meta fields
$additionalFeatures = get_post_meta($page_id, 'hiw_additional_features', true);

// Fallback to default features if empty
if (empty($additionalFeatures) || !is_array($additionalFeatures) || count($additionalFeatures) === 0) {
$additionalFeatures = array(
    array(
        'icon' => 'message-square',
        'title' => 'Direct Communication',
        'description' => 'Chat directly with service providers to ask questions and negotiate terms.',
    ),
    array(
        'icon' => 'credit-card',
        'title' => 'Secure Payments',
        'description' => 'All transactions are protected with industry-standard security measures.',
    ),
    array(
        'icon' => 'star',
        'title' => 'Rate & Review',
        'description' => 'Share your experience and help other car owners make informed decisions.',
    ),
);
}
?>

<div class="text-center mb-16">
    <?php if (!empty($features_section_title)) : ?>
    <h2 class="text-foreground mb-4 section-title">
        <?php echo esc_html($features_section_title); ?>
    </h2>
    <?php endif; ?>
    <?php if (!empty($features_section_description)) : ?>
    <p class="text-lg text-muted-foreground max-w-2xl mx-auto">
        <?php echo esc_html($features_section_description); ?>
    </p>
    <?php endif; ?>
</div>

<div class="grid md:grid-cols-3 gap-8">
    <?php foreach ($additionalFeatures as $feature) : 
        // Get feature data (handle both CMB2 format and ensure keys exist)
        $feature_icon = isset($feature['icon']) ? $feature['icon'] : '';
        $feature_title = isset($feature['title']) ? $feature['title'] : '';
        $feature_description = isset($feature['description']) ? $feature['description'] : '';
        
        // Skip if no title
        if (empty($feature_title)) continue;
    ?>
        <div class="bg-card rounded-2xl p-8 border border-border text-center card-hover-smooth">
            <div class="w-16 h-16 mx-auto rounded-2xl bg-primary/10 flex items-center justify-center mb-6">
                <?php
                $icon_map = array(
                    'message-square' => '<svg class="w-8 h-8 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/></svg>',
                    'credit-card' => '<svg class="w-8 h-8 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"/></svg>',
                    'star' => '<svg class="w-8 h-8 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"/></svg>',
                );
                echo isset($icon_map[$feature_icon]) ? $icon_map[$feature_icon] : '';
                ?>
            </div>
            <h3 class="text-xl font-semibold text-foreground mb-3">
                <?php echo esc_html($feature_title); ?>
            </h3>
            <p class="text-muted-foreground">
                <?php echo esc_html($feature_description); ?>
            </p>
        </div>
    <?php endforeach; ?>
</div>

