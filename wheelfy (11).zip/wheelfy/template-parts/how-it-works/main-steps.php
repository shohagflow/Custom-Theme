<?php
/**
 * Template part for main steps in how it works
 *
 * @package Wheelfy
 */

// Get page ID
$page_id = get_the_ID();

// Get main steps from meta fields
$mainSteps = get_post_meta($page_id, 'hiw_main_steps', true);

// Fallback to default steps if empty
if (empty($mainSteps) || !is_array($mainSteps)) {
    $mainSteps = array(
        array(
            'number' => '01',
            'icon' => 'user-plus',
            'title' => 'Register for Free',
            'description' => 'Create your account in seconds. It\'s completely free and takes less than a minute. No credit card required.',
        ),
        array(
            'number' => '02',
            'icon' => 'car',
            'title' => 'Enter Your Car Details',
            'description' => 'Provide information about your vehicle including make, model, year, and the specific service you need.',
        ),
        array(
            'number' => '03',
            'icon' => 'send',
            'title' => 'Receive Multiple Offers',
            'description' => 'Our network of verified partners will send you competitive offers within 24-48 hours.',
        ),
        array(
            'number' => '04',
            'icon' => 'check-circle',
            'title' => 'Compare & Choose',
            'description' => 'Review all offers side by side, check ratings and reviews, then select the best one for you.',
        ),
    );
}
?>

<div class="space-y-16">
    <?php foreach ($mainSteps as $index => $step) : ?>
        <div class="flex flex-col md:flex-row items-center gap-8 mb-12 <?php echo ($index % 2 === 1) ? 'md:flex-row-reverse' : ''; ?>">
            <div class="flex-1">
                <div class="bg-card rounded-3xl p-8 md:p-12 border border-border relative overflow-hidden card-hover-smooth">
                    <span class="absolute top-4 right-4 text-8xl font-bold brand-gradient-number">
                        <?php echo esc_html(isset($step['number']) ? $step['number'] : ''); ?>
                    </span>
                    <div class="w-16 h-16 rounded-2xl bg-primary/20 flex items-center justify-center mb-6 relative z-10">
                        <?php
                        $icon_map = array(
                            'user-plus' => '<svg class="w-8 h-8 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z"/></svg>',
                            'car' => '<svg class="w-8 h-8 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.4 2.9A3.7 3.7 0 0 0 2 12v4c0 .6.4 1 1 1h2"/><circle cx="7" cy="17" r="2"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 17h6"/><circle cx="17" cy="17" r="2"/></svg>',
                            'send' => '<svg class="w-8 h-8 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"/></svg>',
                            'check-circle' => '<svg class="w-8 h-8 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>',
                        );
                        $step_icon = isset($step['icon']) ? $step['icon'] : '';
                        echo isset($icon_map[$step_icon]) ? $icon_map[$step_icon] : '';
                        ?>
                    </div>
                    <h3 class="text-2xl md:text-3xl font-bold text-foreground mb-4 relative z-10">
                        <?php echo esc_html(isset($step['title']) ? $step['title'] : ''); ?>
                    </h3>
                    <p class="text-lg text-muted-foreground relative z-10">
                        <?php echo esc_html(isset($step['description']) ? $step['description'] : ''); ?>
                    </p>
                </div>
            </div>
            <?php if ($index < count($mainSteps) - 1) : ?>
                <div class="flex-1 hidden md:flex items-center justify-center">
                    <div class="w-24 h-24 rounded-full border-2 border-dashed border-primary/50 flex items-center justify-center">
                        <svg class="w-8 h-8 text-primary rotate-90 md:rotate-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
                        </svg>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
</div>

