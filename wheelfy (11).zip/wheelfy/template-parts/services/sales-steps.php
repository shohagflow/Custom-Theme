<?php
/**
 * Template part for car sales steps
 *
 * @package Wheelfy
 */

// Get page ID
$page_id = get_the_ID();

// Get section title and description from meta fields
$section_title = get_post_meta($page_id, 'sales_steps_section_title', true);
if (empty($section_title)) {
    $section_title = 'How to sell your car';
}

$section_description = get_post_meta($page_id, 'sales_steps_section_description', true);
if (empty($section_description)) {
    $section_description = 'Three simple steps to sell your car at the best price.';
}

// Get steps from meta fields
$steps = get_post_meta($page_id, 'sales_steps', true);

// Fallback to default steps if empty
if (empty($steps) || !is_array($steps)) {
    $steps = array(
        array(
            'number' => '01',
            'title' => 'Tell us about your car',
            'description' => 'Enter your vehicle details and upload photos to get accurate valuations.',
        ),
        array(
            'number' => '02',
            'title' => 'Follow the bidding process',
            'description' => 'Watch as dealerships compete to offer you the best price for your car.',
        ),
        array(
            'number' => '03',
            'title' => 'Choose the best offer',
            'description' => 'Compare all offers, select the highest bidder, and finalize the sale.',
        ),
    );
}

// Get button text and link
$button_text = get_post_meta($page_id, 'sales_steps_button_text', true);
if (empty($button_text)) {
    $button_text = 'Get the Best Offers';
}

$button_link = get_post_meta($page_id, 'sales_steps_button_link', true);
if (empty($button_link)) {
    $button_link = home_url('/request-proposal?type=sales');
} else {
    // Handle relative URLs
    if (strpos($button_link, 'http') !== 0) {
        $button_link = home_url($button_link);
    }
}
?>

<div class="text-center mb-16">
    <?php if (!empty($section_title)) : ?>
    <h2 class="text-foreground mb-4 section-title">
        <?php echo esc_html($section_title); ?>
    </h2>
    <?php endif; ?>
    <?php if (!empty($section_description)) : ?>
    <p class="text-lg text-muted-foreground max-w-2xl mx-auto">
        <?php echo esc_html($section_description); ?>
    </p>
    <?php endif; ?>
</div>

<div class="grid md:grid-cols-3 gap-8 mb-12">
    <?php foreach ($steps as $step) : ?>
        <div class="relative bg-card rounded-2xl p-8 border border-border card-hover-smooth">
            <?php if (isset($step['number']) && !empty($step['number'])) : ?>
            <span class="text-6xl font-bold brand-gradient-number absolute top-4 right-4">
                <?php echo esc_html($step['number']); ?>
            </span>
            <?php endif; ?>
            <?php if (isset($step['title']) && !empty($step['title'])) : ?>
            <h3 class="text-xl font-semibold text-foreground mb-3 relative z-10">
                <?php echo esc_html($step['title']); ?>
            </h3>
            <?php endif; ?>
            <?php if (isset($step['description']) && !empty($step['description'])) : ?>
            <p class="text-muted-foreground relative z-10">
                <?php echo esc_html($step['description']); ?>
            </p>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
</div>

<div class="text-center">
    <a href="<?php echo esc_url($button_link); ?>" class="button button-hero button-lg group inline-flex items-center gap-2">
        <?php echo esc_html($button_text); ?>
        <svg class="w-5 h-5 transition-transform group-hover:translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
        </svg>
    </a>
</div>
