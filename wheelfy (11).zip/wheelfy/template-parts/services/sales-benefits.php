<?php
/**
 * Template part for sales benefits
 *
 * @package Wheelfy
 */

// Get page ID
$page_id = get_the_ID();

// Get benefits from meta fields
$benefits = get_post_meta($page_id, 'sales_benefits', true);

// Fallback to default benefits if empty
if (empty($benefits) || !is_array($benefits)) {
    $benefits = array(
        array('icon' => 'dollar-sign', 'title' => 'Best Price', 'description' => 'Multiple dealers compete for your car'),
        array('icon' => 'clock', 'title' => 'Fast Process', 'description' => 'Sell your car in as little as 3 days'),
        array('icon' => 'shield', 'title' => 'Safe & Secure', 'description' => 'Verified dealerships only'),
        array('icon' => 'users', 'title' => '500+ Dealers', 'description' => 'Large network across the country'),
    );
}
?>

<div class="grid grid-cols-2 lg:grid-cols-4 gap-6">
    <?php foreach ($benefits as $benefit) : ?>
        <div class="text-center p-6 rounded-2xl bg-card border border-border card-hover-smooth">
            <div class="w-14 h-14 mx-auto mb-4 rounded-xl bg-primary/10 flex items-center justify-center">
                <?php
                $icon_map = array(
                    'dollar-sign' => '<svg class="w-7 h-7 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>',
                    'clock' => '<svg class="w-7 h-7 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>',
                    'shield' => '<svg class="w-7 h-7 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>',
                    'users' => '<svg class="w-7 h-7 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"/></svg>',
                );
                $benefit_icon = isset($benefit['icon']) ? $benefit['icon'] : '';
                echo isset($icon_map[$benefit_icon]) ? $icon_map[$benefit_icon] : '';
                ?>
            </div>
            <?php if (isset($benefit['title']) && !empty($benefit['title'])) : ?>
            <h3 class="font-semibold text-foreground mb-1"><?php echo esc_html($benefit['title']); ?></h3>
            <?php endif; ?>
            <?php if (isset($benefit['description']) && !empty($benefit['description'])) : ?>
            <p class="text-sm text-muted-foreground"><?php echo esc_html($benefit['description']); ?></p>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
</div>

