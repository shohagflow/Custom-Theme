<?php
/**
 * Template part for maintenance benefits section
 *
 * @package Wheelfy
 */

// Get page ID
$page_id = get_the_ID();

// Get section title, subtitle, and description from meta fields
$benefits_section_title = get_post_meta($page_id, 'maintenance_benefits_section_title', true);
if (empty($benefits_section_title)) {
    $benefits_section_title = 'Why choose our';
}

$benefits_section_title_highlight = get_post_meta($page_id, 'maintenance_benefits_section_title_highlight', true);
if (empty($benefits_section_title_highlight)) {
    $benefits_section_title_highlight = 'maintenance platform?';
}

$benefits_section_description = get_post_meta($page_id, 'maintenance_benefits_section_description', true);
if (empty($benefits_section_description)) {
    $benefits_section_description = 'We\'ve partnered with hundreds of verified garages and workshops to bring you the best prices and service quality.';
}

// Get benefits list from meta fields
$benefits_list = get_post_meta($page_id, 'maintenance_benefits_list', true);

// Fallback to default benefits if empty
if (empty($benefits_list) || !is_array($benefits_list) || count($benefits_list) === 0) {
    $benefits_list = array(
        array('text' => 'Compare multiple offers at once'),
        array('text' => 'Only verified and rated shops'),
        array('text' => 'No hidden fees or charges'),
        array('text' => 'Book appointments instantly'),
        array('text' => 'Track your service history'),
        array('text' => 'Secure payment options'),
);
}

// Get CTA card fields
$cta_title = get_post_meta($page_id, 'maintenance_benefits_cta_title', true);
if (empty($cta_title)) {
    $cta_title = 'Get a Free Quote';
}

$cta_description = get_post_meta($page_id, 'maintenance_benefits_cta_description', true);
if (empty($cta_description)) {
    $cta_description = 'Tell us about your car and the service you need. We\'ll connect you with the best providers.';
}

$cta_button_text = get_post_meta($page_id, 'maintenance_benefits_cta_button_text', true);
if (empty($cta_button_text)) {
    $cta_button_text = 'Start Your Request';
}

$cta_button_link = get_post_meta($page_id, 'maintenance_benefits_cta_button_link', true);
if (empty($cta_button_link)) {
    $cta_button_link = home_url('/request-proposal?type=maintenance');
} else {
    // Handle relative URLs
    if (strpos($cta_button_link, 'http') !== 0) {
        $cta_button_link = home_url($cta_button_link);
    }
}
?>

<div class="grid lg:grid-cols-2 gap-16 items-center">
    <div>
        <?php if (!empty($benefits_section_title) || !empty($benefits_section_title_highlight)) : ?>
        <h2 class="text-foreground mb-6 section-title">
            <?php echo esc_html($benefits_section_title); ?>
            <?php if (!empty($benefits_section_title_highlight)) : ?>
            <span class="gradient-text block"><?php echo esc_html($benefits_section_title_highlight); ?></span>
            <?php endif; ?>
        </h2>
        <?php endif; ?>
        <?php if (!empty($benefits_section_description)) : ?>
        <p class="text-muted-foreground mb-8">
            <?php echo esc_html($benefits_section_description); ?>
        </p>
        <?php endif; ?>
        <ul class="space-y-4">
            <?php foreach ($benefits_list as $benefit) : ?>
                <li class="flex items-center gap-3">
                    <svg class="w-5 h-5 text-primary flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <span class="text-foreground"><?php echo esc_html(isset($benefit['text']) ? $benefit['text'] : ''); ?></span>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>

    <div class="bg-card rounded-3xl p-8 border border-border card-hover-smooth">
        <?php if (!empty($cta_title)) : ?>
        <h3 class="text-2xl font-bold text-foreground mb-6">
            <?php echo esc_html($cta_title); ?>
        </h3>
        <?php endif; ?>
        <?php if (!empty($cta_description)) : ?>
        <p class="text-muted-foreground mb-6">
            <?php echo esc_html($cta_description); ?>
        </p>
        <?php endif; ?>
        <?php if (!empty($cta_button_text)) : ?>
        <a href="<?php echo esc_url($cta_button_link); ?>" class="button button-hero button-lg w-full group inline-flex items-center justify-center gap-2">
            <?php echo esc_html($cta_button_text); ?>
            <svg class="w-5 h-5 transition-transform group-hover:translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
            </svg>
        </a>
        <?php endif; ?>
    </div>
</div>

