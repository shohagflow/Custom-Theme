<?php
/**
 * Template part for recent sales
 *
 * @package Wheelfy
 */

// Get page ID
$page_id = get_the_ID();

// Get section title and description from meta fields
$section_title = get_post_meta($page_id, 'sales_recent_section_title', true);
if (empty($section_title)) {
    $section_title = 'Customer Experiences';
}

$section_description = get_post_meta($page_id, 'sales_recent_section_description', true);
if (empty($section_description)) {
    $section_description = 'Take a look at our customers\' completed deals.';
}

// Get recent sales from meta fields
$recentSales = get_post_meta($page_id, 'sales_recent_sales', true);

// Fallback to default sales if empty
if (empty($recentSales) || !is_array($recentSales)) {
$recentSales = array(
    array('date' => '2025. January 20', 'car' => 'Mike\'s Ford Sierra', 'price' => '€12,405', 'days' => 3),
    array('date' => '2025. February 05', 'car' => 'Hannah\'s Tesla Model X', 'price' => '€35,564', 'offers' => 25),
    array('date' => '2025. January 12', 'car' => 'John\'s Ford Mondeo', 'price' => '€26,845', 'offers' => 20),
);
}
?>

<div class="text-center mb-16">
    <?php if (!empty($section_title)) : ?>
    <h2 class="text-foreground mb-4 section-title">
        <?php echo esc_html($section_title); ?>
    </h2>
    <?php endif; ?>
    <?php if (!empty($section_description)) : ?>
    <p class="text-lg text-muted-foreground max-w-2xl mx-auto">
        <?php echo esc_html($section_description); ?>
    </p>
    <?php endif; ?>
</div>

<div class="grid md:grid-cols-3 gap-6">
    <?php foreach ($recentSales as $sale) : ?>
        <div class="bg-card rounded-2xl p-6 border border-border card-hover-smooth">
            <?php if (isset($sale['date']) && !empty($sale['date'])) : ?>
            <p class="text-sm text-muted-foreground mb-2"><?php echo esc_html($sale['date']); ?></p>
            <?php endif; ?>
            <?php if (isset($sale['car']) && !empty($sale['car'])) : ?>
            <h3 class="text-lg font-semibold text-foreground mb-1"><?php echo esc_html($sale['car']); ?></h3>
            <?php endif; ?>
            <?php if (isset($sale['price']) && !empty($sale['price'])) : ?>
            <p class="text-3xl font-bold text-primary mb-4"><?php echo esc_html($sale['price']); ?></p>
            <?php endif; ?>
            <p class="text-sm text-muted-foreground flex items-center gap-2">
                <svg class="w-4 h-4 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                </svg>
                <?php
                if (isset($sale['days']) && !empty($sale['days'])) {
                    echo 'Sold in ' . esc_html($sale['days']) . ' days';
                } elseif (isset($sale['offers']) && !empty($sale['offers'])) {
                    echo esc_html($sale['offers']) . ' offers received';
                }
                ?>
            </p>
        </div>
    <?php endforeach; ?>
</div>

