<?php
/**
 * Template part for displaying posts
 *
 * @package Wheelfy
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class('bg-card rounded-2xl p-8 border border-border card-hover-smooth'); ?>>
    <header class="mb-6">
        <?php
        if (is_singular()) {
            the_title('<h1 class="text-4xl font-bold text-foreground mb-4">', '</h1>');
        } else {
            the_title(sprintf('<h2 class="text-2xl font-bold text-foreground mb-2"><a href="%s" class="hover:text-primary transition-colors">', esc_url(get_permalink())), '</a></h2>');
        }
        ?>
        <?php if (is_single() || is_home()) : ?>
            <div class="text-sm text-muted-foreground">
                <span><?php echo get_the_date(); ?></span>
                <?php if (get_the_author()) : ?>
                    <span class="mx-2">•</span>
                    <span><?php the_author(); ?></span>
                <?php endif; ?>
                <?php if (has_category()) : ?>
                    <span class="mx-2">•</span>
                    <span><?php the_category(', '); ?></span>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </header>

    <?php if (has_post_thumbnail() && !is_singular()) : ?>
        <div class="mb-6">
            <a href="<?php echo esc_url(get_permalink()); ?>">
                <?php the_post_thumbnail('large', array('class' => 'w-full h-auto rounded-lg')); ?>
            </a>
        </div>
    <?php endif; ?>

    <div class="prose prose-invert max-w-none text-muted-foreground">
        <?php
        if (is_singular()) {
            the_content();
            wp_link_pages(array(
                'before' => '<div class="page-links mt-8 pt-8 border-t border-border">' . esc_html__('Pages:', 'wheelfy'),
                'after'  => '</div>',
            ));
        } else {
            the_excerpt();
        }
        ?>
    </div>

    <?php if (is_single()) : ?>
        <footer class="mt-8 pt-8 border-t border-border">
            <?php if (has_tag()) : ?>
                <div class="flex flex-wrap gap-2 mb-4">
                    <span class="text-sm text-muted-foreground">Tags: </span>
                    <?php the_tags('', '', ''); ?>
                </div>
            <?php endif; ?>
        </footer>
    <?php elseif (!is_singular()) : ?>
        <footer class="mt-6 pt-6 border-t border-border">
            <a href="<?php echo esc_url(get_permalink()); ?>" class="text-primary hover:underline text-sm font-medium">
                <?php esc_html_e('Read More', 'wheelfy'); ?> →
            </a>
        </footer>
    <?php endif; ?>
</article>

