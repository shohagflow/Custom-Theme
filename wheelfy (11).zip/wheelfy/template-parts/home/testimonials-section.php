<?php
/**
 * Template part for displaying testimonials section
 *
 * @package Wheelfy
 */

// Get current page ID
if (is_front_page() && get_option('page_on_front')) {
    $page_id = get_option('page_on_front');
} elseif (is_page()) {
    $page_id = get_the_ID();
} else {
    // Fallback: get home page by slug
    $home_page = get_page_by_path('home');
    $page_id = $home_page ? $home_page->ID : get_the_ID();
}

// Get Testimonials Section data from CMB2
$testimonials_section_title = get_post_meta($page_id, 'testimonials_title', true);
if (empty($testimonials_section_title)) {
    $testimonials_section_title = 'What Our Customers Say';
}

$testimonials_section_description = get_post_meta($page_id, 'testimonials_description', true);
if (empty($testimonials_section_description)) {
    $testimonials_section_description = 'Join thousands of satisfied car owners who have saved time and money.';
}

// Get testimonials from CMB2 repeater
$testimonials = get_post_meta($page_id, 'testimonials_repeater', true);

// Fallback to defaults if empty
if (empty($testimonials) || !is_array($testimonials) || count($testimonials) === 0) {
    $testimonials = array(
        array(
            'testimonial_name' => 'Michael Schmidt',
            'testimonial_car' => 'BMW 320d',
            'testimonial_savings' => '€340',
            'testimonial_quote' => 'I saved over €340 on my brake service. The process was incredibly simple and I received 5 offers within 24 hours.',
            'testimonial_rating' => 5,
        ),
        array(
            'testimonial_name' => 'Anna Kovács',
            'testimonial_car' => 'Tesla Model 3',
            'testimonial_savings' => '€2,500',
            'testimonial_quote' => 'Sold my Tesla in just 3 days. Got 15 offers from dealerships and chose the highest bidder. Highly recommended!',
            'testimonial_rating' => 5,
        ),
        array(
            'testimonial_name' => 'Peter Nagy',
            'testimonial_car' => 'VW Golf',
            'testimonial_savings' => '€180',
            'testimonial_quote' => 'Great service for comparing tire prices. Found a trusted shop near me with excellent reviews.',
            'testimonial_rating' => 5,
        ),
    );
}
?>

<section class="py-24 section-gradient section-spacing">
    <div class="container mx-auto px-4 lg:px-8">
        <div class="text-center mb-16">
            <?php if ($testimonials_section_title) : ?>
            <h2 class="text-foreground mb-4 section-title">
                <?php echo esc_html($testimonials_section_title); ?>
            </h2>
            <?php endif; ?>
            <?php if ($testimonials_section_description) : ?>
            <p class="text-lg text-muted-foreground max-w-2xl mx-auto">
                <?php echo esc_html($testimonials_section_description); ?>
            </p>
            <?php endif; ?>
        </div>

        <div class="grid md:grid-cols-3 gap-8">
            <?php foreach ($testimonials as $index => $testimonial) : 
                // Get testimonial data (handle both CMB2 format and fallback format)
                $name = isset($testimonial['testimonial_name']) ? $testimonial['testimonial_name'] : (isset($testimonial['name']) ? $testimonial['name'] : '');
                $car = isset($testimonial['testimonial_car']) ? $testimonial['testimonial_car'] : (isset($testimonial['car']) ? $testimonial['car'] : '');
                $savings = isset($testimonial['testimonial_savings']) ? $testimonial['testimonial_savings'] : (isset($testimonial['savings']) ? $testimonial['savings'] : '');
                $quote = isset($testimonial['testimonial_quote']) ? $testimonial['testimonial_quote'] : (isset($testimonial['quote']) ? $testimonial['quote'] : '');
                $rating = isset($testimonial['testimonial_rating']) ? intval($testimonial['testimonial_rating']) : (isset($testimonial['rating']) ? intval($testimonial['rating']) : 5);
                
                // Skip if no name or quote
                if (empty($name) || empty($quote)) continue;
            ?>
                <div class="bg-card/80 backdrop-blur-sm rounded-3xl p-8 border border-border/50 hover:border-primary/50 card-hover-smooth relative" data-animate>
                    <svg class="absolute top-6 right-6 w-8 h-8 text-primary/20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                    </svg>
                    
                    <!-- Rating -->
                    <div class="flex gap-1 mb-4">
                        <?php for ($i = 0; $i < $rating; $i++) : ?>
                            <svg class="w-4 h-4 fill-primary text-primary" fill="currentColor" viewBox="0 0 24 24">
                                <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                            </svg>
                        <?php endfor; ?>
                    </div>

                    <p class="text-muted-foreground mb-6 leading-relaxed">
                        "<?php echo esc_html($quote); ?>"
                    </p>

                    <div class="flex items-center justify-between pt-4 border-t border-border">
                        <div>
                            <p class="font-semibold text-foreground"><?php echo esc_html($name); ?></p>
                            <?php if ($car) : ?>
                            <p class="text-sm text-muted-foreground"><?php echo esc_html($car); ?></p>
                            <?php endif; ?>
                        </div>
                        <?php if ($savings) : ?>
                        <div class="text-right">
                            <p class="text-sm text-muted-foreground">Saved</p>
                            <p class="text-lg font-bold text-primary"><?php echo esc_html($savings); ?></p>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

