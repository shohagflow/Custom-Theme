<?php
/**
 * Home Page Main Content Template
 * 
 * This template displays dynamic content from CMB2 fields
 * 
 * @package Wheelfy
 */

// Get current page ID - handle both front page and regular page
if (is_front_page() && get_option('page_on_front')) {
    $page_id = get_option('page_on_front');
} elseif (is_page()) {
    $page_id = get_the_ID();
} else {
    // Fallback: get home page by slug
    $home_page = get_page_by_path('home');
    $page_id = $home_page ? $home_page->ID : get_the_ID();
}

// Hero Section Fields
$hero_badge = get_post_meta($page_id, 'hero_badge_text', true);
if (empty($hero_badge)) {
    $hero_badge = 'Car Maintenance';
}

$hero_title = get_post_meta($page_id, 'hero_title', true);
if (empty($hero_title)) {
    $hero_title = 'When your car needs care, we help you';
}

$hero_title_highlight = get_post_meta($page_id, 'hero_title_highlight', true);
if (empty($hero_title_highlight)) {
    $hero_title_highlight = 'save money';
}

$hero_description = get_post_meta($page_id, 'hero_description', true);
if (empty($hero_description)) {
    $hero_description = 'Save time and money by comparing maintenance prices. Our service is completely free to use.';
}

// Hero Background Image - CMB2 file field stores attachment ID (can be array or ID)
$hero_bg_image_id_raw = get_post_meta($page_id, 'hero_background_image', true);
$hero_bg_image_id = '';
if (is_array($hero_bg_image_id_raw)) {
    // CMB2 file field can store as array with 'id' key
    if (isset($hero_bg_image_id_raw['id']) && !empty($hero_bg_image_id_raw['id'])) {
        $hero_bg_image_id = absint($hero_bg_image_id_raw['id']);
    } elseif (isset($hero_bg_image_id_raw[0]) && !empty($hero_bg_image_id_raw[0])) {
        $hero_bg_image_id = absint($hero_bg_image_id_raw[0]);
    }
} elseif (is_numeric($hero_bg_image_id_raw)) {
    $hero_bg_image_id = absint($hero_bg_image_id_raw);
} elseif (is_string($hero_bg_image_id_raw) && is_numeric($hero_bg_image_id_raw)) {
    $hero_bg_image_id = absint($hero_bg_image_id_raw);
}

$hero_bg_image = '';
if ($hero_bg_image_id && $hero_bg_image_id > 0) {
    $hero_bg_image = wp_get_attachment_image_url($hero_bg_image_id, 'full');
}
if (empty($hero_bg_image)) {
    $hero_bg_image = get_template_directory_uri() . '/assets/hero-maintenance.jpg';
}

// Hero CTA Button Text
$hero_cta_text = get_post_meta($page_id, 'hero_cta_text', true);
if (empty($hero_cta_text)) {
    $hero_cta_text = 'Compare Prices';
}

// Hero CTA Link - CMB2 text_url field stores URL (can be array with 'url' key or direct string)
$hero_cta_link_raw = get_post_meta($page_id, 'hero_cta_link', true);
$hero_cta_link = '';
if (is_array($hero_cta_link_raw)) {
    // CMB2 text_url stores as array with 'url' key
    if (isset($hero_cta_link_raw['url']) && !empty($hero_cta_link_raw['url'])) {
        $hero_cta_link = esc_url_raw($hero_cta_link_raw['url']);
    } elseif (isset($hero_cta_link_raw[0]) && !empty($hero_cta_link_raw[0])) {
        $hero_cta_link = esc_url_raw($hero_cta_link_raw[0]);
    }
} elseif (is_string($hero_cta_link_raw) && !empty($hero_cta_link_raw)) {
    $hero_cta_link = esc_url_raw($hero_cta_link_raw);
}

// Ensure URL is absolute (add home_url if relative) - only if link is provided
if (!empty($hero_cta_link) && !preg_match('/^https?:\/\//', $hero_cta_link)) {
    $hero_cta_link = home_url($hero_cta_link);
}

// Services Section Fields
$services_title = get_post_meta($page_id, 'services_section_title', true) ?: 'Maintenance Services';
$services_description = get_post_meta($page_id, 'services_section_description', true) ?: 'Browse our wide range of car maintenance services and get quotes from trusted professionals.';
$services = get_post_meta($page_id, 'services_repeater', true) ?: array();

// Benefits Section Fields
$benefits_title = get_post_meta($page_id, 'benefits_section_title', true);
if (empty($benefits_title)) {
    $benefits_title = 'Why choose our';
}

$benefits_title_highlight = get_post_meta($page_id, 'benefits_section_title_highlight', true);
if (empty($benefits_title_highlight)) {
    $benefits_title_highlight = 'maintenance platform?';
}

$benefits_description = get_post_meta($page_id, 'benefits_section_description', true);
if (empty($benefits_description)) {
    $benefits_description = 'We\'ve partnered with hundreds of verified garages and workshops to bring you the best prices and service quality.';
}

$benefits = get_post_meta($page_id, 'benefits_repeater', true);
if (empty($benefits) || !is_array($benefits)) {
    $benefits = array();
}

$benefits_cta_title = get_post_meta($page_id, 'benefits_cta_title', true);
if (empty($benefits_cta_title)) {
    $benefits_cta_title = 'Get a Free Quote';
}

$benefits_cta_description = get_post_meta($page_id, 'benefits_cta_description', true);
if (empty($benefits_cta_description)) {
    $benefits_cta_description = 'Tell us about your car and the service you need. We\'ll connect you with the best providers.';
}

$benefits_cta_button_text = get_post_meta($page_id, 'benefits_cta_button_text', true);
if (empty($benefits_cta_button_text)) {
    $benefits_cta_button_text = 'Start Your Request';
}

// Benefits CTA Link - CMB2 text_url field stores URL (can be array with 'url' key or direct string)
$benefits_cta_link_raw = get_post_meta($page_id, 'benefits_cta_button_link', true);
$benefits_cta_button_link = '';
if (is_array($benefits_cta_link_raw)) {
    // CMB2 text_url stores as array with 'url' key
    if (isset($benefits_cta_link_raw['url']) && !empty($benefits_cta_link_raw['url'])) {
        $benefits_cta_button_link = esc_url_raw($benefits_cta_link_raw['url']);
    } elseif (isset($benefits_cta_link_raw[0]) && !empty($benefits_cta_link_raw[0])) {
        $benefits_cta_button_link = esc_url_raw($benefits_cta_link_raw[0]);
    }
} elseif (is_string($benefits_cta_link_raw) && !empty($benefits_cta_link_raw)) {
    $benefits_cta_button_link = esc_url_raw($benefits_cta_link_raw);
}

// If empty, use default
if (empty($benefits_cta_button_link)) {
    $benefits_cta_button_link = home_url('/request-proposal?type=maintenance');
} else {
    // Ensure URL is absolute (add home_url if relative)
    if (!preg_match('/^https?:\/\//', $benefits_cta_button_link)) {
        $benefits_cta_button_link = home_url($benefits_cta_button_link);
    }
}
?>

<!-- Hero Section -->
<section class="relative min-h-[80vh] flex items-center overflow-hidden">
    <div class="absolute inset-0">
        <img src="<?php echo esc_url($hero_bg_image); ?>" alt="Car maintenance service" class="w-full h-full object-cover">
        <div class="absolute inset-0 hero-gradient"></div>
        <div class="absolute inset-0 bg-gradient-to-r from-background via-background/90 to-transparent"></div>
    </div>

    <div class="container mx-auto px-4 lg:px-8 relative z-10">
        <div class="max-w-2xl">
            <?php if ($hero_badge) : ?>
            <span class="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-6">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"></path>
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path>
                </svg>
                <?php echo esc_html($hero_badge); ?>
            </span>
            <?php endif; ?>

            <h1 class="text-foreground mb-6 hero-title">
                <?php echo esc_html($hero_title); ?>
                <?php if ($hero_title_highlight) : ?>
                <span class="gradient-text block"><?php echo esc_html($hero_title_highlight); ?></span>
                <?php endif; ?>
            </h1>

            <?php if ($hero_description) : ?>
            <p class="text-lg md:text-xl text-muted-foreground mb-10">
                <?php echo esc_html($hero_description); ?>
            </p>
            <?php endif; ?>

            <?php if ($hero_cta_text && $hero_cta_link) : ?>
            <a href="<?php echo esc_url($hero_cta_link); ?>" class="button button-hero button-xl group inline-flex items-center gap-2">
                <?php echo esc_html($hero_cta_text); ?>
                <svg class="w-5 h-5 transition-transform group-hover:translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                </svg>
            </a>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- Feature Highlights Section -->
<?php get_template_part('template-parts/home/features-section'); ?>

<!-- Benefits Section -->
<?php if (!empty($benefits) || $benefits_title) : ?>
<section class="py-24 section-gradient animate-fade-in-up">
    <div class="container mx-auto px-4 lg:px-8">
        <div class="grid lg:grid-cols-2 gap-16 items-center">
            <div>
                <?php if ($benefits_title || $benefits_title_highlight) : ?>
                <h2 class="text-foreground mb-6 section-title">
                    <?php echo esc_html($benefits_title); ?>
                    <?php if ($benefits_title_highlight) : ?>
                    <span class="gradient-text block"><?php echo esc_html($benefits_title_highlight); ?></span>
                    <?php endif; ?>
                </h2>
                <?php endif; ?>
                
                <?php if ($benefits_description) : ?>
                <p class="text-muted-foreground mb-8">
                    <?php echo esc_html($benefits_description); ?>
                </p>
                <?php endif; ?>
                
                <?php if (!empty($benefits)) : ?>
                <ul class="space-y-4">
                    <?php foreach ($benefits as $benefit) : 
                        $benefit_text = isset($benefit['benefit_text']) ? $benefit['benefit_text'] : '';
                        if ($benefit_text) :
                    ?>
                    <li class="flex items-center gap-3">
                        <svg class="w-5 h-5 text-primary flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                        </svg>
                        <span class="text-foreground"><?php echo esc_html($benefit_text); ?></span>
                    </li>
                    <?php 
                        endif;
                    endforeach; ?>
                </ul>
                <?php else : ?>
                <!-- Default Benefits (fallback) -->
                <ul class="space-y-4">
                    <li class="flex items-center gap-3">
                        <svg class="w-5 h-5 text-primary flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                        </svg>
                        <span class="text-foreground">Compare multiple offers at once</span>
                    </li>
                    <li class="flex items-center gap-3">
                        <svg class="w-5 h-5 text-primary flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                        </svg>
                        <span class="text-foreground">Only verified and rated shops</span>
                    </li>
                    <li class="flex items-center gap-3">
                        <svg class="w-5 h-5 text-primary flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                        </svg>
                        <span class="text-foreground">No hidden fees or charges</span>
                    </li>
                </ul>
                <?php endif; ?>
            </div>

            <?php if ($benefits_cta_title || $benefits_cta_description || ($benefits_cta_button_text && $benefits_cta_button_link)) : ?>
            <div class="bg-card rounded-3xl p-8 border border-border card-hover-smooth">
                <?php if ($benefits_cta_title) : ?>
                <h3 class="text-2xl font-bold text-foreground mb-6">
                    <?php echo esc_html($benefits_cta_title); ?>
                </h3>
                <?php endif; ?>
                
                <?php if ($benefits_cta_description) : ?>
                <p class="text-muted-foreground mb-6">
                    <?php echo esc_html($benefits_cta_description); ?>
                </p>
                <?php endif; ?>
                
                <?php if ($benefits_cta_button_text && $benefits_cta_button_link) : ?>
                <a href="<?php echo esc_url($benefits_cta_button_link); ?>" class="button button-hero button-lg w-full group inline-flex items-center justify-center gap-2">
                    <?php echo esc_html($benefits_cta_button_text); ?>
                    <svg class="w-5 h-5 transition-transform group-hover:translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                    </svg>
                </a>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- How It Works Section -->
<?php get_template_part('template-parts/home/how-it-works-section'); ?>

<!-- Our Services Section -->
<?php get_template_part('template-parts/home/services-section'); ?>

<!-- Testimonials Section -->
<?php get_template_part('template-parts/home/testimonials-section'); ?>

<!-- CTA Section -->
<?php get_template_part('template-parts/home/cta-section'); ?>
