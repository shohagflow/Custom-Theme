<?php
/**
 * Template part for displaying hero section
 *
 * @package Wheelfy
 */

// Get current page ID
$page_id = get_the_ID();

// Hero Section Fields - Dynamic from CMB2
$hero_badge = get_post_meta($page_id, 'hero_badge_text', true) ?: 'Car Maintenance';
$hero_title = get_post_meta($page_id, 'hero_title', true) ?: 'When your car needs care, we help you';
$hero_title_highlight = get_post_meta($page_id, 'hero_title_highlight', true) ?: 'save money';
$hero_description = get_post_meta($page_id, 'hero_description', true) ?: 'Save time and money by comparing maintenance prices. Our service is completely free to use.';
$hero_bg_image_id = get_post_meta($page_id, 'hero_background_image', true);
$hero_image = $hero_bg_image_id ? wp_get_attachment_image_url($hero_bg_image_id, 'full') : get_template_directory_uri() . '/assets/hero-maintenance.jpg';
?>

<section class="relative min-h-[90vh] flex items-center overflow-hidden hero-section-sticky">
    <!-- Background Image -->
    <div class="absolute inset-0">
        <img src="<?php echo esc_url($hero_image); ?>" alt="Premium automotive service" class="w-full h-full object-cover">
        <div class="absolute inset-0 hero-gradient"></div>
        <div class="absolute inset-0 bg-gradient-to-r from-background via-background/80 to-transparent"></div>
    </div>

    <!-- Content -->
    <div class="container mx-auto px-4 lg:px-8 relative z-10">
        <div class="max-w-3xl">
            <?php if ($hero_badge) : ?>
            <div class="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-6 animate-fade-in-up" data-animate>
                <span class="w-2 h-2 rounded-full bg-primary animate-pulse"></span>
                <?php echo esc_html($hero_badge); ?>
            </div>
            <?php endif; ?>

            <h1 class="text-foreground mb-6 animate-fade-in-up hero-title" style="animation-delay: 0.2s; opacity: 0;" data-animate>
                <?php echo esc_html($hero_title); ?>
                <?php if ($hero_title_highlight) : ?>
                <span class="gradient-text block"><?php echo esc_html($hero_title_highlight); ?></span>
                <?php endif; ?>
            </h1>

            <?php if ($hero_description) : ?>
            <p class="text-lg md:text-xl text-muted-foreground mb-10 max-w-xl animate-fade-in-up" style="animation-delay: 0.4s; opacity: 0;" data-animate>
                <?php echo esc_html($hero_description); ?>
            </p>
            <?php endif; ?>

            <div class="flex flex-col sm:flex-row gap-4 animate-fade-in-up" style="animation-delay: 0.6s; opacity: 0;" data-animate>
                <a href="<?php echo esc_url(home_url('/car-maintenance')); ?>" class="button button-hero button-xl w-full sm:w-auto group">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                    </svg>
                    Car Maintenance
                    <svg class="w-5 h-5 transition-transform group-hover:translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
                    </svg>
                </a>
                <a href="<?php echo esc_url(home_url('/car-sales')); ?>" class="button button-hero-outline button-xl w-full sm:w-auto group">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                    Sell Your Car
                    <svg class="w-5 h-5 transition-transform group-hover:translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
                    </svg>
                </a>
            </div>
        </div>
    </div>

    <!-- Decorative Elements -->
    <div class="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-background to-transparent"></div>
</section>

