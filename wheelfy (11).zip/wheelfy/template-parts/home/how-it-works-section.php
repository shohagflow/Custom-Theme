<?php
/**
 * Template part for displaying how it works section
 *
 * @package Wheelfy
 */

// Get current page ID
if (is_front_page() && get_option('page_on_front')) {
    $page_id = get_option('page_on_front');
} elseif (is_page()) {
    $page_id = get_the_ID();
} else {
    // Fallback: get home page by slug
    $home_page = get_page_by_path('home');
    $page_id = $home_page ? $home_page->ID : get_the_ID();
}

// Get How It Works section data from CMB2
$how_it_works_title = get_post_meta($page_id, 'how_it_works_title', true);
if (empty($how_it_works_title)) {
    $how_it_works_title = 'How It Works';
}

$how_it_works_description = get_post_meta($page_id, 'how_it_works_description', true);
if (empty($how_it_works_description)) {
    $how_it_works_description = 'Compare prices easily and totally free. We\'ve made the process simple so you can focus on what matters.';
}

$steps = get_post_meta($page_id, 'how_it_works_steps', true);

// Fallback to defaults if empty
if (empty($steps) || !is_array($steps) || count($steps) === 0) {
    $steps = array(
        array(
            'step_number' => '01',
            'step_icon' => 'user-plus',
            'step_title' => 'Register for Free',
            'step_description' => 'Create your account in seconds. It\'s completely free and takes less than a minute.',
        ),
        array(
            'step_number' => '02',
            'step_icon' => 'car',
            'step_title' => 'Enter Car Details',
            'step_description' => 'Provide information about your vehicle and the service you need.',
        ),
        array(
            'step_number' => '03',
            'step_icon' => 'send',
            'step_title' => 'Receive Offers',
            'step_description' => 'Get competitive offers from verified service providers and dealerships.',
        ),
        array(
            'step_number' => '04',
            'step_icon' => 'check-circle',
            'step_title' => 'Choose & Save',
            'step_description' => 'Compare offers, choose the best one, and save money on your service.',
        ),
    );
}

// Get CTA button data
$how_it_works_cta_text = get_post_meta($page_id, 'how_it_works_cta_text', true);
if (empty($how_it_works_cta_text)) {
    $how_it_works_cta_text = 'Start Comparing Prices';
}

// How It Works CTA Link - CMB2 text_url field stores URL (can be array with 'url' key or direct string)
$how_it_works_cta_link_raw = get_post_meta($page_id, 'how_it_works_cta_link', true);
$how_it_works_cta_link = '';
if (is_array($how_it_works_cta_link_raw)) {
    // CMB2 text_url stores as array with 'url' key
    if (isset($how_it_works_cta_link_raw['url']) && !empty($how_it_works_cta_link_raw['url'])) {
        $how_it_works_cta_link = esc_url_raw($how_it_works_cta_link_raw['url']);
    } elseif (isset($how_it_works_cta_link_raw[0]) && !empty($how_it_works_cta_link_raw[0])) {
        $how_it_works_cta_link = esc_url_raw($how_it_works_cta_link_raw[0]);
    }
} elseif (is_string($how_it_works_cta_link_raw) && !empty($how_it_works_cta_link_raw)) {
    $how_it_works_cta_link = esc_url_raw($how_it_works_cta_link_raw);
}

// If empty, use default
if (empty($how_it_works_cta_link)) {
    $how_it_works_cta_link = home_url('/request-proposal');
} else {
    // Ensure URL is absolute (add home_url if relative)
    if (!preg_match('/^https?:\/\//', $how_it_works_cta_link)) {
        $how_it_works_cta_link = home_url($how_it_works_cta_link);
    }
}
?>

<section class="py-24 section-gradient relative overflow-hidden section-spacing">
    <!-- Background Pattern -->
    <div class="absolute inset-0 opacity-5">
        <div class="absolute top-0 left-0 w-full h-full" style="background-image: radial-gradient(circle at 2px 2px, hsl(var(--primary)) 1px, transparent 0); background-size: 40px 40px;"></div>
    </div>
    
    <div class="container mx-auto px-4 lg:px-8 relative z-10">
        <div class="text-center mb-20">
            <div class="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 text-primary text-sm font-medium mb-6" data-animate>
                Simple Process
            </div>
            <?php if ($how_it_works_title) : ?>
            <h2 class="text-foreground mb-6 animate-fade-in-up section-title" data-animate>
                <?php echo esc_html($how_it_works_title); ?>
            </h2>
            <?php endif; ?>
            <?php if ($how_it_works_description) : ?>
            <p class="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed mb-16" data-animate>
                <?php echo esc_html($how_it_works_description); ?>
            </p>
            <?php endif; ?>
        </div>

        <div class="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
            <?php foreach ($steps as $index => $step) : 
                // Get step data (handle both CMB2 format and fallback format)
                $step_number = isset($step['step_number']) ? $step['step_number'] : (isset($step['number']) ? $step['number'] : str_pad($index + 1, 2, '0', STR_PAD_LEFT));
                $icon = isset($step['step_icon']) ? $step['step_icon'] : (isset($step['icon']) ? $step['icon'] : '');
                $title = isset($step['step_title']) ? $step['step_title'] : (isset($step['title']) ? $step['title'] : '');
                $description = isset($step['step_description']) ? $step['step_description'] : (isset($step['description']) ? $step['description'] : '');
                
                if (empty($title)) continue; // Skip if no title
            ?>
                <div class="relative mb-8">
                    <!-- Connector Line -->
                    <?php if ($index < count($steps) - 1) : ?>
                        <div class="hidden lg:block absolute top-10 left-[60%] w-full h-0.5 bg-gradient-to-r from-primary/50 to-transparent"></div>
                    <?php endif; ?>
                    
                    <div class="relative bg-card/80 backdrop-blur-sm rounded-3xl p-8 border border-border/50 hover:border-primary/50 card-hover-smooth h-full" data-animate>
                        <span class="absolute -top-4 left-6 text-5xl font-bold brand-gradient-number">
                            <?php echo esc_html($step_number); ?>
                        </span>
                        <div class="w-14 h-14 rounded-2xl bg-gradient-to-br from-primary/30 to-primary/10 flex items-center justify-center mb-6 mt-6 shadow-lg shadow-primary/20 group-hover:scale-110 transition-transform duration-300">
                            <?php 
                            // Icon mapping for all available icons
                            $icon_svgs = array(
                                'user-plus' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" />',
                                'car' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.4 2.9A3.7 3.7 0 0 0 2 12v4c0 .6.4 1 1 1h2" /><circle cx="7" cy="17" r="2" /><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 17h6" /><circle cx="17" cy="17" r="2" />',
                                'calendar' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />',
                                'send' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z" /><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m21.854 2.147-10.94 10.939" />',
                                'bell' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />',
                                'check-circle' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />',
                                'file-text' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />',
                                'message-square' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />',
                                'credit-card' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />',
                                'shield' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />',
                                'star' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" />',
                                'clock' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />',
                                'dollar-sign' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />',
                                'wrench' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.25 0a6.73 6.73 0 011.566 4.461c0 1.561-.424 3.145-1.899 4.153L12 14.5l-2.242-1.469a4.73 4.73 0 01-1.899-4.153 6.73 6.73 0 011.566-4.461zM15 10a4.5 4.5 0 11-9 0 4.5 4.5 0 019 0z" />',
                                'search' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />',
                                'heart' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />',
                            );
                            
                            $icon_path = isset($icon_svgs[$icon]) ? $icon_svgs[$icon] : $icon_svgs['check-circle'];
                            ?>
                            <svg class="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <?php echo $icon_path; ?>
                            </svg>
                        </div>
                        <h3 class="text-xl font-bold text-foreground mb-3 group-hover:text-primary transition-colors">
                            <?php echo esc_html($title); ?>
                        </h3>
                        <p class="text-muted-foreground text-base leading-relaxed">
                            <?php echo esc_html($description); ?>
                        </p>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <?php if ($how_it_works_cta_text && $how_it_works_cta_link) : ?>
        <div class="text-center" data-animate>
            <a href="<?php echo esc_url($how_it_works_cta_link); ?>" class="button button-hero button-xl group inline-flex items-center gap-3 px-8 py-4 rounded-xl font-semibold shadow-2xl shadow-primary/30 hover:shadow-primary/40 hover:scale-105 transition-all">
                <?php echo esc_html($how_it_works_cta_text); ?>
                <svg class="w-5 h-5 transition-transform group-hover:translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
                </svg>
            </a>
        </div>
        <?php endif; ?>
    </div>
</section>

