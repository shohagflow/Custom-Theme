<?php
/**
 * Template part for displaying services section
 *
 * @package Wheelfy
 */

// Get current page ID
if (is_front_page() && get_option('page_on_front')) {
    $page_id = get_option('page_on_front');
} elseif (is_page()) {
    $page_id = get_the_ID();
} else {
    // Fallback: get home page by slug
    $home_page = get_page_by_path('home');
    $page_id = $home_page ? $home_page->ID : get_the_ID();
}

// Get Services Section data from CMB2
$services_section_title = get_post_meta($page_id, 'services_section_title', true);
if (empty($services_section_title)) {
    $services_section_title = 'Our Services';
}

$services_section_description = get_post_meta($page_id, 'services_section_description', true);
if (empty($services_section_description)) {
    $services_section_description = 'Whether you need to maintain your vehicle or sell it, we\'ve got you covered.';
}

// Get services from Service Post Type
$services_query = new WP_Query(array(
    'post_type' => 'service',
    'posts_per_page' => -1,
    'post_status' => 'publish',
    'orderby' => 'menu_order',
    'order' => 'ASC',
));

$services = array();

if ($services_query->have_posts()) {
    while ($services_query->have_posts()) {
        the_post();
        $post_id = get_the_ID();
        
        // Get service meta fields
        $service_icon = get_post_meta($post_id, 'service_icon', true);
        if (empty($service_icon)) {
            $service_icon = 'wrench'; // Default icon
        }
        
        $service_button_text = get_post_meta($post_id, 'service_button_text', true);
        if (empty($service_button_text)) {
            $service_button_text = 'Learn More'; // Default button text
        }
        
        // Get featured image
        $featured_image = '';
        if (has_post_thumbnail($post_id)) {
            $featured_image = get_the_post_thumbnail_url($post_id, 'full');
        } else {
            // Fallback to default images
            if (strpos(strtolower(get_the_title()), 'maintenance') !== false) {
                $featured_image = get_template_directory_uri() . '/assets/hero-maintenance.jpg';
            } elseif (strpos(strtolower(get_the_title()), 'sales') !== false) {
                $featured_image = get_template_directory_uri() . '/assets/hero-sales.jpg';
            }
        }
        
        // Get features from repeater
        $service_features_raw = get_post_meta($post_id, 'service_features', true);
        $service_features = array();
        if (!empty($service_features_raw) && is_array($service_features_raw)) {
            foreach ($service_features_raw as $feature) {
                if (isset($feature['feature_text']) && !empty($feature['feature_text'])) {
                    $service_features[] = $feature['feature_text'];
                }
            }
        }
        
        // Get post link (use permalink or custom link if available)
        $service_link = get_permalink($post_id);
        
        // Get description (excerpt or content) - limit to 18 words
        $description = '';
        if (has_excerpt($post_id)) {
            $excerpt = get_the_excerpt($post_id);
            $description = wp_trim_words($excerpt, 18, '...');
        } else {
            $content = get_the_content(null, false, $post_id);
            // Strip HTML tags and get plain text
            $content = wp_strip_all_tags($content);
            $description = wp_trim_words($content, 18, '...');
        }
        
        $services[] = array(
            'title' => get_the_title(),
            'description' => $description,
            'image' => $featured_image,
            'icon' => $service_icon,
            'href' => $service_link,
            'features' => $service_features,
            'button_text' => $service_button_text,
        );
    }
    wp_reset_postdata();
}

// Fallback to defaults if no services found
if (empty($services)) {
    $services = array(
        array(
            'title' => 'Car Maintenance',
            'description' => 'When your car needs care, we help you save money. Compare prices from verified garages and workshops.',
            'image' => get_template_directory_uri() . '/assets/hero-maintenance.jpg',
            'icon' => 'wrench',
            'href' => home_url('/car-maintenance'),
            'features' => array('Oil Changes', 'Brake Service', 'Tire Replacement', 'General Repairs'),
            'button_text' => 'Learn More',
        ),
        array(
            'title' => 'Car Sales',
            'description' => 'Sell your car easily at the best price. Get competitive offers from verified dealerships.',
            'image' => get_template_directory_uri() . '/assets/hero-sales.jpg',
            'icon' => 'car',
            'href' => home_url('/car-sales'),
            'features' => array('Instant Valuation', 'Multiple Offers', 'Safe Transaction', 'Fast Payment'),
            'button_text' => 'Learn More',
        ),
    );
}
?>

<section class="py-24 bg-background section-spacing services-section">
    <div class="container mx-auto px-4 lg:px-8">
        <div class="text-center mb-16">
            <?php if ($services_section_title) : ?>
            <h2 class="text-foreground mb-4 section-title">
                <?php echo esc_html($services_section_title); ?>
            </h2>
            <?php endif; ?>
            <?php if ($services_section_description) : ?>
            <p class="text-lg text-muted-foreground max-w-2xl mx-auto">
                <?php echo esc_html($services_section_description); ?>
            </p>
            <?php endif; ?>
        </div>

        <div class="grid lg:grid-cols-2 gap-8 lg:gap-10">
            <?php foreach ($services as $index => $service) : ?>
                <div class="group relative overflow-hidden rounded-3xl border border-border/50 hover:border-primary/50 service-card" data-animate>
                    <!-- Background Image -->
                    <div class="absolute inset-0 overflow-hidden">
                        <img src="<?php echo esc_url($service['image']); ?>" alt="<?php echo esc_attr($service['title']); ?>" class="w-full h-full object-cover service-card-image">
                        <div class="absolute inset-0 bg-gradient-to-t from-background via-background/95 to-background/50 service-card-overlay"></div>
                    </div>

                    <!-- Content -->
                    <div class="relative p-8 md:p-12 min-h-[450px] flex flex-col justify-end">
                        <div class="w-16 h-16 rounded-2xl bg-gradient-to-br from-primary/30 to-primary/10 backdrop-blur-md flex items-center justify-center mb-6 shadow-lg shadow-primary/20 group-hover:scale-110 transition-transform duration-300">
                            <?php 
                            // Icon mapping for all available icons
                            $icon_svgs = array(
                                'wrench' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" /><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />',
                                'car' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.4 2.9A3.7 3.7 0 0 0 2 12v4c0 .6.4 1 1 1h2" /><circle cx="7" cy="17" r="2" /><path d="M9 17h6" /><circle cx="17" cy="17" r="2" />',
                                'settings' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" /><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />',
                                'dollar-sign' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />',
                                'clock' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />',
                                'shield' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />',
                                'star' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" />',
                                'check-circle' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />',
                                'user' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />',
                                'file-text' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />',
                                'message-square' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />',
                                'credit-card' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />',
                                'search' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />',
                                'heart' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />',
                            );
                            
                            $icon = isset($service['icon']) ? $service['icon'] : 'wrench';
                            $icon_path = isset($icon_svgs[$icon]) ? $icon_svgs[$icon] : $icon_svgs['wrench'];
                            ?>
                            <svg class="w-7 h-7 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <?php echo $icon_path; ?>
                            </svg>
                        </div>
                        <h3 class="text-3xl md:text-4xl font-bold text-foreground mb-4 service-card-title">
                            <?php echo esc_html($service['title']); ?>
                        </h3>
                        <p class="text-white mb-8 max-w-md text-lg leading-relaxed">
                            <?php echo esc_html($service['description']); ?>
                        </p>
                        
                        <!-- Features -->
                        <div class="flex flex-wrap gap-3 mb-8">
                            <?php foreach ($service['features'] as $feature) : ?>
                                <span class="px-4 py-2 text-sm font-medium rounded-full bg-card/80 backdrop-blur-sm border border-border/50 text-foreground service-card-feature">
                                    <?php echo esc_html($feature); ?>
                                </span>
                            <?php endforeach; ?>
                        </div>

                        <?php 
                        $button_text = isset($service['button_text']) ? $service['button_text'] : 'Learn More';
                        if ($button_text && $service['href']) : 
                        ?>
                        <a href="<?php echo esc_url($service['href']); ?>" class="button button-hero group/btn inline-flex items-center justify-center gap-2 px-8 py-4 rounded-xl font-semibold text-base shadow-lg shadow-primary/20 hover:shadow-xl hover:shadow-primary/30 transition-all">
                            <?php echo esc_html($button_text); ?>
                            <svg class="w-5 h-5 transition-transform group-hover/btn:translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
                            </svg>
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

