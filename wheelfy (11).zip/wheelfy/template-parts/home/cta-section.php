<?php
/**
 * Template part for displaying CTA section
 *
 * @package Wheelfy
 */

// Get current page ID
if (is_front_page() && get_option('page_on_front')) {
    $page_id = get_option('page_on_front');
} elseif (is_page()) {
    $page_id = get_the_ID();
} else {
    // Fallback: get home page by slug
    $home_page = get_page_by_path('home');
    $page_id = $home_page ? $home_page->ID : get_the_ID();
}

// Get CTA Section data from CMB2
$cta_badge = get_post_meta($page_id, 'cta_section_badge', true);
if (empty($cta_badge)) {
    $cta_badge = 'Start saving today';
}

$cta_title = get_post_meta($page_id, 'cta_section_title', true);
if (empty($cta_title)) {
    $cta_title = 'Ready to save on your';
}

$cta_title_highlight = get_post_meta($page_id, 'cta_section_title_highlight', true);
if (empty($cta_title_highlight)) {
    $cta_title_highlight = 'next car service?';
}

$cta_description = get_post_meta($page_id, 'cta_section_description', true);
if (empty($cta_description)) {
    $cta_description = 'Join thousands of car owners who trust us to find the best deals. It\'s free, fast, and simple.';
}

$cta_primary_button_text = get_post_meta($page_id, 'cta_section_primary_button_text', true);
if (empty($cta_primary_button_text)) {
    $cta_primary_button_text = 'Get Started Now';
}

// CTA Primary Button Link - CMB2 text_url field stores URL (can be array with 'url' key or direct string)
$cta_primary_button_link_raw = get_post_meta($page_id, 'cta_section_primary_button_link', true);
$cta_primary_button_link = '';
if (is_array($cta_primary_button_link_raw)) {
    // CMB2 text_url stores as array with 'url' key
    if (isset($cta_primary_button_link_raw['url']) && !empty($cta_primary_button_link_raw['url'])) {
        $cta_primary_button_link = esc_url_raw($cta_primary_button_link_raw['url']);
    } elseif (isset($cta_primary_button_link_raw[0]) && !empty($cta_primary_button_link_raw[0])) {
        $cta_primary_button_link = esc_url_raw($cta_primary_button_link_raw[0]);
    }
} elseif (is_string($cta_primary_button_link_raw) && !empty($cta_primary_button_link_raw)) {
    $cta_primary_button_link = esc_url_raw($cta_primary_button_link_raw);
}

// If empty, use default
if (empty($cta_primary_button_link)) {
    $cta_primary_button_link = home_url('/request-proposal');
} else {
    // Ensure URL is absolute (add home_url if relative)
    if (!preg_match('/^https?:\/\//', $cta_primary_button_link)) {
        $cta_primary_button_link = home_url($cta_primary_button_link);
    }
}

$cta_secondary_button_text = get_post_meta($page_id, 'cta_section_secondary_button_text', true);
if (empty($cta_secondary_button_text)) {
    $cta_secondary_button_text = 'Learn More';
}

// CTA Secondary Button Link - CMB2 text_url field stores URL (can be array with 'url' key or direct string)
$cta_secondary_button_link_raw = get_post_meta($page_id, 'cta_section_secondary_button_link', true);
$cta_secondary_button_link = '';
if (is_array($cta_secondary_button_link_raw)) {
    // CMB2 text_url stores as array with 'url' key
    if (isset($cta_secondary_button_link_raw['url']) && !empty($cta_secondary_button_link_raw['url'])) {
        $cta_secondary_button_link = esc_url_raw($cta_secondary_button_link_raw['url']);
    } elseif (isset($cta_secondary_button_link_raw[0]) && !empty($cta_secondary_button_link_raw[0])) {
        $cta_secondary_button_link = esc_url_raw($cta_secondary_button_link_raw[0]);
    }
} elseif (is_string($cta_secondary_button_link_raw) && !empty($cta_secondary_button_link_raw)) {
    $cta_secondary_button_link = esc_url_raw($cta_secondary_button_link_raw);
}

// If empty, use default
if (empty($cta_secondary_button_link)) {
    $cta_secondary_button_link = home_url('/how-it-works');
} else {
    // Ensure URL is absolute (add home_url if relative)
    if (!preg_match('/^https?:\/\//', $cta_secondary_button_link)) {
        $cta_secondary_button_link = home_url($cta_secondary_button_link);
    }
}
?>

<section class="py-24 bg-background relative overflow-hidden section-spacing">
    <!-- Modern Background Effects -->
    <div class="absolute inset-0 overflow-hidden">
        <div class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-gradient-to-r from-primary/10 via-primary/5 to-transparent rounded-full blur-3xl animate-pulse"></div>
        <div class="absolute top-1/4 right-1/4 w-[400px] h-[400px] bg-gradient-to-l from-primary/5 to-transparent rounded-full blur-2xl"></div>
    </div>

    <div class="container mx-auto px-4 lg:px-8 relative z-10">
        <div class="max-w-4xl mx-auto text-center">
            <?php if ($cta_badge) : ?>
            <div class="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 text-primary text-sm font-medium mb-8" data-animate>
                <span class="w-2 h-2 rounded-full bg-primary animate-pulse"></span>
                <?php echo esc_html($cta_badge); ?>
            </div>
            <?php endif; ?>
            
            <?php if ($cta_title || $cta_title_highlight) : ?>
            <h2 class="text-foreground mb-6 animate-fade-in-up section-title" data-animate>
                <?php if ($cta_title) : ?>
                    <?php echo esc_html($cta_title); ?>
                <?php endif; ?>
                <?php if ($cta_title_highlight) : ?>
                    <span class="gradient-text block mt-2"><?php echo esc_html($cta_title_highlight); ?></span>
                <?php endif; ?>
            </h2>
            <?php endif; ?>
            
            <?php if ($cta_description) : ?>
            <p class="text-xl text-muted-foreground mb-12 max-w-2xl mx-auto leading-relaxed" data-animate>
                <?php echo esc_html($cta_description); ?>
            </p>
            <?php endif; ?>
            
            <div class="flex flex-col sm:flex-row gap-6 justify-center" data-animate>
                <?php if ($cta_primary_button_text && $cta_primary_button_link) : ?>
                <a href="<?php echo esc_url($cta_primary_button_link); ?>" class="button button-hero button-xl group inline-flex items-center gap-3 px-8 py-4 rounded-xl font-semibold shadow-2xl shadow-primary/30 hover:shadow-primary/40 hover:scale-105 transition-all">
                    <?php echo esc_html($cta_primary_button_text); ?>
                    <svg class="w-5 h-5 transition-transform group-hover:translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
                    </svg>
                </a>
                <?php endif; ?>
                
                <?php if ($cta_secondary_button_text && $cta_secondary_button_link) : ?>
                <a href="<?php echo esc_url($cta_secondary_button_link); ?>" class="button button-hero-outline button-xl px-8 py-4 rounded-xl font-semibold border-2 hover:bg-primary/10 hover:border-primary/50 transition-all">
                    <?php echo esc_html($cta_secondary_button_text); ?>
                </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

