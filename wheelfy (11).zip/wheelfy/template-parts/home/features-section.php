<?php
/**
 * Template part for displaying features section
 *
 * @package Wheelfy
 */

// Get current page ID
if (is_front_page() && get_option('page_on_front')) {
    $page_id = get_option('page_on_front');
} elseif (is_page()) {
    $page_id = get_the_ID();
} else {
    // Fallback: get home page by slug
    $home_page = get_page_by_path('home');
    $page_id = $home_page ? $home_page->ID : get_the_ID();
}

// Get features from CMB2
$features = get_post_meta($page_id, 'features_repeater', true);

// Fallback to defaults if empty
if (empty($features) || !is_array($features) || count($features) === 0) {
    $features = array(
        array(
            'feature_icon' => 'dollar-sign',
            'feature_title' => 'Save Money',
            'feature_description' => 'Compare prices from multiple providers and get the best deal',
        ),
        array(
            'feature_icon' => 'clock',
            'feature_title' => 'Save Time',
            'feature_description' => 'Get multiple offers in one place without visiting each shop',
        ),
        array(
            'feature_icon' => 'shield',
            'feature_title' => 'Free to Use',
            'feature_description' => 'Our comparison service is completely free for customers',
        ),
        array(
            'feature_icon' => 'star',
            'feature_title' => 'Verified Partners',
            'feature_description' => 'Work only with trusted and reviewed service providers',
        ),
    );
}
?>

<section class="py-24 bg-background relative overflow-hidden section-spacing">
    <div class="container mx-auto px-4 lg:px-8 relative z-10">
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
            <?php foreach ($features as $feature) : 
                // Get feature data (handle both CMB2 format and fallback format)
                $icon = isset($feature['feature_icon']) ? $feature['feature_icon'] : (isset($feature['icon']) ? $feature['icon'] : '');
                $title = isset($feature['feature_title']) ? $feature['feature_title'] : (isset($feature['title']) ? $feature['title'] : '');
                $description = isset($feature['feature_description']) ? $feature['feature_description'] : (isset($feature['description']) ? $feature['description'] : '');
                
                if (empty($title)) continue; // Skip if no title
            ?>
                <div class="group relative text-center p-8 rounded-3xl bg-card/80 backdrop-blur-sm border border-border/50 hover:border-primary/50 card-hover-smooth" data-animate>
                    <div class="w-16 h-16 mx-auto mb-6 rounded-2xl bg-gradient-to-br from-primary/20 to-primary/10 flex items-center justify-center group-hover:scale-110 group-hover:bg-gradient-to-br group-hover:from-primary/30 group-hover:to-primary/20 transition-all duration-300 shadow-lg shadow-primary/20">
                        <?php if ($icon === 'dollar-sign') : ?>
                            <svg class="w-8 h-8 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                        <?php elseif ($icon === 'clock') : ?>
                            <svg class="w-8 h-8 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                        <?php elseif ($icon === 'shield') : ?>
                            <svg class="w-8 h-8 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                            </svg>
                        <?php elseif ($icon === 'star') : ?>
                            <svg class="w-8 h-8 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" />
                            </svg>
                        <?php elseif ($icon === 'check-circle') : ?>
                            <svg class="w-8 h-8 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                        <?php elseif ($icon === 'user') : ?>
                            <svg class="w-8 h-8 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                            </svg>
                        <?php elseif ($icon === 'car') : ?>
                            <svg class="w-8 h-8 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" />
                            </svg>
                        <?php elseif ($icon === 'wrench') : ?>
                            <svg class="w-8 h-8 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                                <path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                            </svg>
                        <?php else : ?>
                            <!-- Default icon if icon not found -->
                            <svg class="w-8 h-8 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                        <?php endif; ?>
                    </div>
                    <h3 class="text-xl font-bold text-foreground mb-3 group-hover:text-primary transition-colors">
                        <?php echo esc_html($title); ?>
                    </h3>
                    <p class="text-sm text-muted-foreground leading-relaxed">
                        <?php echo esc_html($description); ?>
                    </p>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

