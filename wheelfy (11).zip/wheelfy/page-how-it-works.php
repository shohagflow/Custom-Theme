<?php
/**
 * Template Name: How It Works
 * 
 * @package Wheelfy
 */

get_header();

// Get page ID
$page_id = get_the_ID();

// Get hero meta fields
$hero_badge = get_post_meta($page_id, 'hiw_hero_badge', true);
if (empty($hero_badge)) {
    $hero_badge = 'Simple Process';
}

$hero_title = get_post_meta($page_id, 'hiw_hero_title_text', true);
if (empty($hero_title)) {
    $hero_title = 'How It Works';
}

$hero_subtitle = get_post_meta($page_id, 'hiw_hero_subtitle', true);
if (empty($hero_subtitle)) {
    $hero_subtitle = 'Save Time & Money';
}

$hero_description = get_post_meta($page_id, 'hiw_hero_description', true);
if (empty($hero_description)) {
    $hero_description = 'Getting started is easy. Follow these simple steps to compare prices and save money on your car services.';
}

$hero_button_text = get_post_meta($page_id, 'hiw_hero_button_text', true);
if (empty($hero_button_text)) {
    $hero_button_text = 'Get Started';
}

$hero_button_link = get_post_meta($page_id, 'hiw_hero_button_link', true);
if (empty($hero_button_link)) {
    $hero_button_link = home_url('/request-proposal');
} else {
    // Handle relative URLs
    if (strpos($hero_button_link, 'http') !== 0) {
        $hero_button_link = home_url($hero_button_link);
    }
}

// Get hero background image
$hiw_hero_background_image = get_post_meta($page_id, 'hiw_hero_background_image', true);
$hiw_hero_background_image_id = get_post_meta($page_id, 'hiw_hero_background_image_id', true);
$hiw_hero_background_image_url = '';

// CMB2 file field can store URL or ID depending on configuration
// First, try to get from _id field (attachment ID)
if (!empty($hiw_hero_background_image_id) && is_numeric($hiw_hero_background_image_id)) {
    $hiw_hero_background_image_url = wp_get_attachment_image_url((int)$hiw_hero_background_image_id, 'full');
    if (empty($hiw_hero_background_image_url)) {
        $hiw_hero_background_image_url = wp_get_attachment_url((int)$hiw_hero_background_image_id);
    }
}

// If no URL found yet, check the main field (might be URL or ID)
if (empty($hiw_hero_background_image_url) && !empty($hiw_hero_background_image)) {
    // Check if it's a URL
    if (filter_var($hiw_hero_background_image, FILTER_VALIDATE_URL)) {
        $hiw_hero_background_image_url = $hiw_hero_background_image;
    } 
    // Check if it's an attachment ID
    elseif (is_numeric($hiw_hero_background_image)) {
        $hiw_hero_background_image_url = wp_get_attachment_image_url((int)$hiw_hero_background_image, 'full');
        if (empty($hiw_hero_background_image_url)) {
            $hiw_hero_background_image_url = wp_get_attachment_url((int)$hiw_hero_background_image);
        }
    }
    // Handle array format
    elseif (is_array($hiw_hero_background_image)) {
        $attachment_id = isset($hiw_hero_background_image['id']) ? $hiw_hero_background_image['id'] : (isset($hiw_hero_background_image[0]) ? $hiw_hero_background_image[0] : null);
        if (!empty($attachment_id) && is_numeric($attachment_id)) {
            $hiw_hero_background_image_url = wp_get_attachment_image_url((int)$attachment_id, 'full');
            if (empty($hiw_hero_background_image_url)) {
                $hiw_hero_background_image_url = wp_get_attachment_url((int)$attachment_id);
            }
        }
    }
}

// Fallback to default image if no image URL was found
if (empty($hiw_hero_background_image_url)) {
    $hiw_hero_background_image_url = get_template_directory_uri() . '/assets/about-workshop.jpg';
}
?>

<!-- Hero Section -->
<section class="relative min-h-[50vh] md:min-h-[80vh] flex items-center overflow-hidden">
    <!-- Background Image -->
    <div class="absolute inset-0">
        <img src="<?php echo esc_url($hiw_hero_background_image_url); ?>" alt="How It Works" class="w-full h-full object-cover">
        <div class="absolute inset-0 hero-gradient"></div>
        <div class="absolute inset-0 bg-gradient-to-r from-background via-background/90 to-transparent"></div>
    </div>
    
    <!-- Modern Background Effects -->
    <div class="absolute inset-0 overflow-hidden">
        <div class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-gradient-to-r from-primary/10 via-primary/5 to-transparent rounded-full blur-3xl animate-pulse opacity-50"></div>
    </div>
    
    <div class="container mx-auto px-4 lg:px-8 relative z-10" style="margin-top: 6rem;">
        <div class="max-w-3xl mx-auto text-center">
            <!-- Badge -->
            <?php if (!empty($hero_badge)) : ?>
            <div class="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 text-primary text-sm font-medium mb-6 animate-fade-in-up" data-animate>
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <span><?php echo esc_html($hero_badge); ?></span>
            </div>
            <?php endif; ?>
            
            <h1 class="text-foreground mb-6 hero-title animate-fade-in-up" style="animation-delay: 0.2s; opacity: 0;" data-animate>
                <?php echo esc_html($hero_title); ?>
                <?php if (!empty($hero_subtitle)) : ?>
                <span class="gradient-text block mt-2"><?php echo esc_html($hero_subtitle); ?></span>
                <?php endif; ?>
            </h1>
            
            <?php if (!empty($hero_description)) : ?>
            <p class="text-lg md:text-xl text-muted-foreground mb-10 max-w-2xl mx-auto leading-relaxed animate-fade-in-up" style="animation-delay: 0.4s; opacity: 0;" data-animate>
                <?php echo esc_html($hero_description); ?>
            </p>
            <?php endif; ?>
            
            <?php if (!empty($hero_button_text)) : ?>
            <div class="flex flex-col sm:flex-row gap-4 justify-center animate-fade-in-up" style="animation-delay: 0.6s; opacity: 0;" data-animate>
                <a href="<?php echo esc_url($hero_button_link); ?>" class="button button-hero button-xl group inline-flex items-center gap-2 px-8 py-4 rounded-xl font-semibold shadow-2xl shadow-primary/30 hover:shadow-primary/40 hover:scale-105 transition-all">
                    <?php echo esc_html($hero_button_text); ?>
                    <svg class="w-5 h-5 transition-transform group-hover:translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
                    </svg>
                </a>
            </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Decorative Elements -->
    <div class="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-background to-transparent"></div>
</section>

<!-- Main Steps -->
<section class="pt-20 pb-0 bg-background">
    <div class="container mx-auto px-4 lg:px-8">
        <?php get_template_part('template-parts/how-it-works/main-steps'); ?>
    </div>
</section>

<!-- Additional Features -->
<section class="py-20 section-gradient">
    <div class="container mx-auto px-4 lg:px-8">
        <?php get_template_part('template-parts/how-it-works/additional-features'); ?>
    </div>
</section>

<!-- CTA -->
<?php
// Get CTA meta fields
$cta_title = get_post_meta($page_id, 'hiw_cta_title_text', true);
if (empty($cta_title)) {
    $cta_title = 'Ready to get started?';
}

$cta_description = get_post_meta($page_id, 'hiw_cta_description', true);
if (empty($cta_description)) {
    $cta_description = 'Join thousands of car owners who are already saving time and money.';
}

$cta_button_text = get_post_meta($page_id, 'hiw_cta_button_text', true);
if (empty($cta_button_text)) {
    $cta_button_text = 'Submit a Request';
}

$cta_button_link = get_post_meta($page_id, 'hiw_cta_button_link', true);
if (empty($cta_button_link)) {
    $cta_button_link = home_url('/request-proposal');
} else {
    // Handle relative URLs
    if (strpos($cta_button_link, 'http') !== 0) {
        $cta_button_link = home_url($cta_button_link);
    }
}
?>
<section class="py-20 bg-background">
    <div class="container mx-auto px-4 lg:px-8">
        <div class="text-center max-w-2xl mx-auto">
            <?php if (!empty($cta_title)) : ?>
            <h2 class="text-foreground mb-6 section-title">
                <?php echo esc_html($cta_title); ?>
            </h2>
            <?php endif; ?>
            <?php if (!empty($cta_description)) : ?>
            <p class="text-lg text-muted-foreground mb-8">
                <?php echo esc_html($cta_description); ?>
            </p>
            <?php endif; ?>
            <?php if (!empty($cta_button_text)) : ?>
            <div class="flex flex-col sm:flex-row gap-4 justify-center">
                <a href="<?php echo esc_url($cta_button_link); ?>" class="button button-hero-outline button-lg">
                    <?php echo esc_html($cta_button_text); ?>
                </a>
            </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<?php
get_footer();

