<?php
/**
 * Template Name: Pricing
 * 
 * @package Wheelfy
 */

get_header();

// Get page ID
$page_id = get_the_ID();

// Get hero meta fields
$hero_badge = get_post_meta($page_id, 'pricing_hero_badge', true);
if (empty($hero_badge)) {
    $hero_badge = 'Transparent Pricing';
}

$hero_title = get_post_meta($page_id, 'pricing_hero_title_text', true);
if (empty($hero_title)) {
    $hero_title = 'Simple, Transparent';
}

$hero_subtitle = get_post_meta($page_id, 'pricing_hero_subtitle', true);
if (empty($hero_subtitle)) {
    $hero_subtitle = 'Pricing';
}

$hero_description = get_post_meta($page_id, 'pricing_hero_description', true);
if (empty($hero_description)) {
    $hero_description = 'Free for customers. Fair pricing for partners. No hidden fees. Choose the plan that works best for you.';
}

$hero_primary_button_text = get_post_meta($page_id, 'pricing_hero_primary_button_text', true);
if (empty($hero_primary_button_text)) {
    $hero_primary_button_text = 'Get Started Free';
}

$hero_primary_button_link = get_post_meta($page_id, 'pricing_hero_primary_button_link', true);
if (empty($hero_primary_button_link)) {
    $hero_primary_button_link = home_url('/request-proposal');
} else {
    // Handle relative URLs
    if (strpos($hero_primary_button_link, 'http') !== 0) {
        $hero_primary_button_link = home_url($hero_primary_button_link);
    }
}

$hero_secondary_button_text = get_post_meta($page_id, 'pricing_hero_secondary_button_text', true);
if (empty($hero_secondary_button_text)) {
    $hero_secondary_button_text = 'Become a Partner';
}

$hero_secondary_button_link = get_post_meta($page_id, 'pricing_hero_secondary_button_link', true);
if (empty($hero_secondary_button_link)) {
    $hero_secondary_button_link = home_url('/register?type=partner');
} else {
    // Handle relative URLs
    if (strpos($hero_secondary_button_link, 'http') !== 0) {
        $hero_secondary_button_link = home_url($hero_secondary_button_link);
    }
}

// Get hero background image
$pricing_hero_background_image = get_post_meta($page_id, 'pricing_hero_background_image', true);
$pricing_hero_background_image_id = get_post_meta($page_id, 'pricing_hero_background_image_id', true);
$pricing_hero_background_image_url = '';

// CMB2 file field can store URL or ID depending on configuration
// First, try to get from _id field (attachment ID)
if (!empty($pricing_hero_background_image_id) && is_numeric($pricing_hero_background_image_id)) {
    $pricing_hero_background_image_url = wp_get_attachment_image_url((int)$pricing_hero_background_image_id, 'full');
    if (empty($pricing_hero_background_image_url)) {
        $pricing_hero_background_image_url = wp_get_attachment_url((int)$pricing_hero_background_image_id);
    }
}

// If no URL found yet, check the main field (might be URL or ID)
if (empty($pricing_hero_background_image_url) && !empty($pricing_hero_background_image)) {
    // Check if it's a URL
    if (filter_var($pricing_hero_background_image, FILTER_VALIDATE_URL)) {
        $pricing_hero_background_image_url = $pricing_hero_background_image;
    } 
    // Check if it's an attachment ID
    elseif (is_numeric($pricing_hero_background_image)) {
        $pricing_hero_background_image_url = wp_get_attachment_image_url((int)$pricing_hero_background_image, 'full');
        if (empty($pricing_hero_background_image_url)) {
            $pricing_hero_background_image_url = wp_get_attachment_url((int)$pricing_hero_background_image);
        }
    }
    // Handle array format
    elseif (is_array($pricing_hero_background_image)) {
        $attachment_id = isset($pricing_hero_background_image['id']) ? $pricing_hero_background_image['id'] : (isset($pricing_hero_background_image[0]) ? $pricing_hero_background_image[0] : null);
        if (!empty($attachment_id) && is_numeric($attachment_id)) {
            $pricing_hero_background_image_url = wp_get_attachment_image_url((int)$attachment_id, 'full');
            if (empty($pricing_hero_background_image_url)) {
                $pricing_hero_background_image_url = wp_get_attachment_url((int)$attachment_id);
            }
        }
    }
}

// Fallback to default image if no image URL was found
if (empty($pricing_hero_background_image_url)) {
    $pricing_hero_background_image_url = get_template_directory_uri() . '/assets/hero-sales.jpg';
}
?>

<!-- Hero Section -->
<section class="relative min-h-[80vh] flex items-center overflow-hidden">
    <!-- Background Image -->
    <div class="absolute inset-0">
        <img src="<?php echo esc_url($pricing_hero_background_image_url); ?>" alt="Pricing plans" class="w-full h-full object-cover">
        <div class="absolute inset-0 hero-gradient"></div>
        <div class="absolute inset-0 bg-gradient-to-r from-background via-background/90 to-transparent"></div>
    </div>
    
    <!-- Modern Background Effects -->
    <div class="absolute inset-0 overflow-hidden">
        <div class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-gradient-to-r from-primary/10 via-primary/5 to-transparent rounded-full blur-3xl animate-pulse opacity-50"></div>
    </div>
    
    <div class="container mx-auto px-4 lg:px-8 relative z-10" style="margin-top: 6rem;">
        <div class="max-w-3xl mx-auto text-center">
            <!-- Badge -->
            <?php if (!empty($hero_badge)) : ?>
            <div class="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 text-primary text-sm font-medium mb-6 animate-fade-in-up" data-animate>
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <span><?php echo esc_html($hero_badge); ?></span>
            </div>
            <?php endif; ?>
            
            <h1 class="text-foreground mb-6 hero-title animate-fade-in-up" style="animation-delay: 0.2s; opacity: 0;" data-animate>
                <?php echo esc_html($hero_title); ?>
                <?php if (!empty($hero_subtitle)) : ?>
                <span class="gradient-text block mt-2"><?php echo esc_html($hero_subtitle); ?></span>
                <?php endif; ?>
            </h1>
            
            <?php if (!empty($hero_description)) : ?>
            <p class="text-lg md:text-xl text-muted-foreground mb-10 max-w-2xl mx-auto leading-relaxed animate-fade-in-up" style="animation-delay: 0.4s; opacity: 0;" data-animate>
                <?php echo esc_html($hero_description); ?>
            </p>
            <?php endif; ?>
            
            <div class="flex flex-col sm:flex-row gap-4 justify-center animate-fade-in-up" style="animation-delay: 0.6s; opacity: 0;" data-animate>
                <?php if (!empty($hero_primary_button_text)) : ?>
                <a href="<?php echo esc_url($hero_primary_button_link); ?>" class="button button-hero button-xl group inline-flex items-center gap-2 px-8 py-4 rounded-xl font-semibold shadow-2xl shadow-primary/30 hover:shadow-primary/40 hover:scale-105 transition-all">
                    <?php echo esc_html($hero_primary_button_text); ?>
                    <svg class="w-5 h-5 transition-transform group-hover:translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
                    </svg>
                </a>
                <?php endif; ?>
                <?php if (!empty($hero_secondary_button_text)) : ?>
                <a href="<?php echo esc_url($hero_secondary_button_link); ?>" class="button button-hero-outline button-xl px-8 py-4 rounded-xl font-semibold border-2 hover:bg-primary/10 hover:border-primary/50 transition-all">
                    <?php echo esc_html($hero_secondary_button_text); ?>
                </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Decorative Elements -->
    <div class="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-background to-transparent"></div>
</section>

<!-- Pricing Cards - Dynamic from Admin Dashboard Subscriptions -->
<?php
// Ensure subscription tables exist
if (function_exists('wheelfy_create_subscription_tables')) {
    wheelfy_create_subscription_tables();
}

// Get subscription plans from database (active plans only, ordered by display_order)
$subscription_plans = array();
if (function_exists('wheelfy_get_subscription_plans_db')) {
    $subscription_plans = wheelfy_get_subscription_plans_db(true, 'display_order', 'ASC');
}

// Helper function to format price display
if (!function_exists('wheelfy_format_plan_price')) {
    function wheelfy_format_plan_price($price, $currency = 'HUF', $billing_cycle = 'monthly') {
        if (floatval($price) <= 0) {
            return array(
                'price' => __('Free', 'wheelfy'),
                'suffix' => ''
            );
        }
        
        // Format price based on currency
        $formatted_price = number_format($price, 0, ',', ' ');
        
        // Determine billing cycle suffix
        $cycle_suffix = '';
        switch ($billing_cycle) {
            case 'monthly':
                $cycle_suffix = __('/month', 'wheelfy');
                break;
            case 'yearly':
                $cycle_suffix = __('/year', 'wheelfy');
                break;
            case 'one_time':
                $cycle_suffix = '';
                break;
            default:
                $cycle_suffix = '/' . $billing_cycle;
        }
        
        return array(
            'price' => $currency . ' ' . $formatted_price,
            'suffix' => $cycle_suffix
        );
    }
}

// Determine grid columns based on number of plans
$plan_count = count($subscription_plans);
$grid_cols = 'md:grid-cols-1';
if ($plan_count == 2) {
    $grid_cols = 'md:grid-cols-2';
} elseif ($plan_count >= 3) {
    $grid_cols = 'md:grid-cols-2 lg:grid-cols-3';
}

// Max width based on plan count
$max_width = 'max-w-md';
if ($plan_count == 2) {
    $max_width = 'max-w-4xl';
} elseif ($plan_count >= 3) {
    $max_width = 'max-w-6xl';
}
?>
<?php if (!empty($subscription_plans)) : ?>
<section class="py-24 bg-background">
    <div class="container mx-auto px-4 lg:px-8">
        <div class="grid <?php echo esc_attr($grid_cols); ?> gap-8 <?php echo esc_attr($max_width); ?> mx-auto">
            <?php foreach ($subscription_plans as $plan) : 
                // Parse features list - handle both JSON string and array
                $features_list = array();
                if (!empty($plan->features_list)) {
                    if (is_array($plan->features_list)) {
                        $features_list = $plan->features_list;
                    } elseif (is_string($plan->features_list)) {
                        $features_list = json_decode($plan->features_list, true);
                        if (!is_array($features_list)) {
                            $features_list = array();
                        }
                    }
                }
                
                // Fallback to features if features_list is empty
                if (empty($features_list) && !empty($plan->features)) {
                    if (is_array($plan->features)) {
                        $features = $plan->features;
                    } elseif (is_string($plan->features)) {
                        $features = json_decode($plan->features, true);
                    } else {
                        $features = array();
                    }
                    if (is_array($features)) {
                        foreach ($features as $feature) {
                            $features_list[] = array('text' => $feature, 'icon' => 'check');
                        }
                    }
                }
                
                // Check if popular
                $is_popular = !empty($plan->is_popular) && $plan->is_popular;
                
                // Format price for display
                $price_amount = floatval($plan->price);
                $is_free = $price_amount <= 0;
                $formatted_price = $is_free ? '' : number_format($price_amount, 0, ',', ' ');
                
                // Billing cycle text
                $billing_text = '';
                switch ($plan->billing_cycle) {
                    case 'monthly':
                        $billing_text = __('/monthly', 'wheelfy');
                        break;
                    case 'yearly':
                        $billing_text = __('/yearly', 'wheelfy');
                        break;
                }
                
                // Commission info
                $commission_rate = '';
                if (!empty($plan->commission_rate) && $plan->commission_rate > 0) {
                    $commission_rate = number_format($plan->commission_rate, 2) . '%';
                }
                
                // Bidding restriction label
                $bidding_label = !empty($plan->bidding_restriction_label) ? $plan->bidding_restriction_label : '';
            ?>
            <!-- Subscription Plan Card -->
            <div class="subscription-plan-card <?php echo $is_popular ? 'popular-plan' : ''; ?>">
                <?php if ($is_popular) : ?>
                <div class="plan-badge-popular"><?php _e('MOST POPULAR', 'wheelfy'); ?></div>
                <?php endif; ?>
                
                <!-- Plan Header -->
                <div class="plan-header">
                    <h3 class="plan-name"><?php echo esc_html($plan->plan_name); ?></h3>
                </div>
                
                <!-- Plan Price -->
                <div class="plan-price">
                    <?php if ($is_free) : ?>
                    <span class="price-amount"><?php _e('Free', 'wheelfy'); ?></span>
                    <?php else : ?>
                    <span class="price-amount"><?php echo esc_html($formatted_price); ?></span>
                    <span class="price-currency"><?php echo esc_html($plan->currency); ?></span>
                    <?php if (!empty($billing_text)) : ?>
                    <span class="price-period"><?php echo esc_html($billing_text); ?></span>
                    <?php endif; ?>
                    <?php endif; ?>
                </div>
                
                
                <!-- Features List -->
                <?php if (!empty($features_list)) : ?>
                <div class="plan-features">
                    <ul class="features-list">
                        <?php foreach ($features_list as $feature) : 
                            $feature_text = is_array($feature) ? (isset($feature['text']) ? $feature['text'] : '') : $feature;
                            if (empty($feature_text)) continue;
                        ?>
                        <li>
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <polyline points="20 6 9 17 4 12"></polyline>
                            </svg>
                            <?php echo esc_html($feature_text); ?>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <?php endif; ?>
                
                <!-- Plan Action Button -->
                <div class="plan-action">
                    <?php 
                    // Check login and user role for dynamic button behavior
                    $is_logged_in = is_user_logged_in();
                    $is_partner = false;
                    $checkout_url = '';
                    $login_url = '';
                    
                    if ($is_logged_in) {
                        $current_user = wp_get_current_user();
                        $is_partner = in_array('partner', (array) $current_user->roles);
                    }
                    
                    // Build URLs
                    $checkout_page = get_page_by_path('subscription-checkout');
                    if ($checkout_page) {
                        $checkout_url = add_query_arg('plan', $plan->id, get_permalink($checkout_page->ID));
                    } else {
                        $checkout_url = home_url('/subscription-checkout/?plan=' . $plan->id);
                    }
                    
                    // Login URL with redirect back to pricing page
                    $login_url = wp_login_url(get_permalink() . '?plan=' . $plan->id);
                    
                    if ($is_logged_in && $is_partner) :
                        // Partner logged in - direct to checkout
                    ?>
                        <a href="<?php echo esc_url($checkout_url); ?>" class="btn btn-primary">
                            <?php _e('Upgrade Now', 'wheelfy'); ?>
                        </a>
                    <?php else : 
                        // Not logged in or not a partner - show login prompt button
                    ?>
                        <button type="button" class="btn btn-primary upgrade-btn-login" 
                            data-plan-id="<?php echo esc_attr($plan->id); ?>" 
                            data-plan-name="<?php echo esc_attr($plan->plan_name); ?>"
                            data-checkout-url="<?php echo esc_url($checkout_url); ?>"
                            data-login-url="<?php echo esc_url($login_url); ?>"
                            data-is-logged-in="<?php echo $is_logged_in ? '1' : '0'; ?>"
                            data-is-partner="<?php echo $is_partner ? '1' : '0'; ?>">
                            <?php _e('Upgrade Now', 'wheelfy'); ?>
                        </button>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- Subscription Plan Cards Styles -->
<style>
/* Subscription Plan Card Base */
.subscription-plan-card {
    background: hsl(var(--card));
    border: 1px solid hsl(var(--border));
    border-radius: 1rem;
    padding: 1.5rem;
    display: flex;
    flex-direction: column;
    height: 100%;
    position: relative;
    transition: all 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94);
}
.subscription-plan-card:hover {
    transform: translateY(-8px);
    box-shadow: 0 20px 40px -10px rgba(0, 0, 0, 0.3);
    border-color: hsl(var(--primary) / 0.5);
}

/* Popular Plan Card */
.subscription-plan-card.popular-plan {
    border: 2px solid hsl(var(--primary));
    box-shadow: 0 4px 20px hsl(var(--primary) / 0.25);
}
.subscription-plan-card.popular-plan:hover {
    transform: translateY(-8px) scale(1.02);
    box-shadow: 0 8px 30px hsl(var(--primary) / 0.35);
}

/* Most Popular Badge */
.plan-badge-popular {
    position: absolute;
    top: -12px;
    right: 20px;
    background: hsl(var(--card));
    color: hsl(var(--primary));
    border: 2px solid hsl(var(--primary));
    padding: 0.4rem 1rem;
    border-radius: 0.5rem;
    font-size: 0.7rem;
    font-weight: 700;
    letter-spacing: 0.1em;
    text-transform: uppercase;
    box-shadow: 0 0 15px hsl(var(--primary) / 0.3);
    animation: badge-glow 2s ease-in-out infinite;
}
@keyframes badge-glow {
    0%, 100% {
        box-shadow: 0 0 15px hsl(var(--primary) / 0.3);
    }
    50% {
        box-shadow: 0 0 25px hsl(var(--primary) / 0.5);
    }
}

/* Plan Header */
.plan-header {
    margin-bottom: 0.5rem;
}
.plan-name {
    font-size: 1.25rem;
    font-weight: 700;
    color: hsl(var(--foreground));
    margin: 0;
}

/* Plan Price */
.plan-price {
    margin-bottom: 1rem;
    padding-bottom: 1rem;
    border-bottom: 1px solid hsl(var(--border) / 0.5);
    display: flex;
    align-items: baseline;
    flex-wrap: wrap;
    gap: 0.25rem;
}
.price-amount {
    font-size: 2.75rem;
    font-weight: 700;
    color: hsl(var(--foreground));
    line-height: 1;
}
.price-currency {
    font-size: 1rem;
    font-weight: 500;
    color: hsl(var(--muted-foreground));
}
.price-period {
    font-size: 0.875rem;
    color: hsl(var(--muted-foreground));
}

/* Plan Meta */
.plan-meta {
    padding: 0.75rem 0;
    margin-bottom: 0.75rem;
    border-bottom: 1px solid hsl(var(--border));
}
.plan-meta .meta-item {
    font-size: 0.8125rem;
    color: hsl(var(--muted-foreground));
    margin-bottom: 0.25rem;
}
.plan-meta .meta-item:last-child {
    margin-bottom: 0;
}
.plan-meta .meta-item strong {
    color: hsl(var(--foreground));
}

/* Plan Features */
.plan-features {
    flex-grow: 1;
    margin-bottom: 1.5rem;
}
.features-list {
    list-style: none;
    padding: 0;
    margin: 0;
}
.features-list li {
    display: flex;
    align-items: flex-start;
    gap: 0.75rem;
    font-size: 0.875rem;
    color: hsl(var(--foreground));
    margin-bottom: 0.75rem;
    line-height: 1.4;
}
.features-list li:last-child {
    margin-bottom: 0;
}
.features-list li svg {
    flex-shrink: 0;
    color: hsl(var(--primary));
    margin-top: 0.125rem;
}

/* Plan Action Button - Matching Website Branding */
.plan-action {
    margin-top: auto;
}
.plan-action .btn {
    display: block;
    width: 100%;
    padding: 0.875rem 1.5rem;
    font-size: 0.9375rem;
    font-weight: 600;
    text-align: center;
    text-decoration: none;
    border-radius: 0.75rem;
    transition: all 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94);
    cursor: pointer;
}
.plan-action .btn-primary {
    background: linear-gradient(135deg, hsl(60 96% 79%), hsl(186 80% 19%));
    color: hsl(var(--primary-foreground));
    border: none;
    box-shadow: 0 10px 15px -3px hsl(60 96% 79% / 0.3), 0 10px 15px -3px hsl(186 80% 19% / 0.2);
}
.plan-action .btn-primary:hover {
    background: linear-gradient(135deg, hsl(60 96% 82%), hsl(186 80% 22%));
    box-shadow: 0 20px 25px -5px hsl(60 96% 79% / 0.4), 0 20px 25px -5px hsl(186 80% 19% / 0.3);
    transform: translateY(-2px);
}

/* Responsive */
@media (max-width: 768px) {
    .subscription-plan-card {
        padding: 1.25rem;
    }
    .price-amount {
        font-size: 2.25rem;
    }
    .plan-badge-popular {
        right: 15px;
        font-size: 0.65rem;
        padding: 0.35rem 0.75rem;
    }
}
</style>

<?php else : ?>
<!-- Admin notice: No plans found -->
<?php if (current_user_can('administrator')) : ?>
<section class="py-24 bg-background">
    <div class="container mx-auto px-4 lg:px-8">
        <div class="max-w-xl mx-auto text-center">
            <div class="bg-card rounded-3xl p-8 border border-border">
                <svg class="w-16 h-16 text-muted-foreground mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <h3 class="text-xl font-bold text-foreground mb-2"><?php _e('No Subscription Plans Found', 'wheelfy'); ?></h3>
                <p class="text-muted-foreground mb-6"><?php _e('Add subscription plans from the admin dashboard to display them here.', 'wheelfy'); ?></p>
                <a href="<?php echo esc_url(admin_url('admin.php?page=wheelfy-subscriptions')); ?>" class="button button-hero inline-flex items-center gap-2">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                    </svg>
                    <?php _e('Add Plans', 'wheelfy'); ?>
                </a>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>
<?php endif; ?>

<!-- FAQ Section -->
<?php
// Get FAQ items from meta fields (only FAQ items are dynamic)
$faq_items = get_post_meta($page_id, 'pricing_faq_items', true);
if (empty($faq_items) || !is_array($faq_items) || count($faq_items) === 0) {
    $faq_items = array(
        array(
            'question' => 'Is it really free for customers?',
            'answer' => 'Yes! Our service is completely free for customers. You can compare prices from multiple service providers and dealerships without any cost. We make money from partners, not from you. No registration fees, no hidden charges, no subscription required.',
        ),
        array(
            'question' => 'How does partner pricing work?',
            'answer' => 'Partners only pay a 5% commission when they successfully complete a transaction with a customer they received through our platform. There are no upfront costs, no monthly fees, and no subscription charges. You only pay when you get business, making it a risk-free way to grow your customer base.',
        ),
        array(
            'question' => 'Are there any hidden fees?',
            'answer' => 'No hidden fees whatsoever. What you see is what you pay. For customers, the service is completely free. For partners, you only pay the 5% commission on successful transactions. We believe in complete transparency, so you\'ll always know exactly what you\'re paying for.',
        ),
        array(
            'question' => 'How quickly will I receive quotes?',
            'answer' => 'Most customers receive multiple quotes within 24 hours of submitting their request. Our verified partners are committed to responding quickly to provide you with competitive pricing. You can compare offers side-by-side and choose the best option for your needs.',
        ),
        array(
            'question' => 'What types of services can I compare?',
            'answer' => 'You can compare prices for car maintenance services, repairs, and car sales. Whether you need routine maintenance, major repairs, or want to sell your vehicle, our platform connects you with verified service providers and dealerships who can offer competitive pricing.',
        ),
        array(
            'question' => 'How do I become a partner?',
            'answer' => 'Becoming a partner is easy! Simply click the "Become a Partner" button and fill out our application form. We\'ll review your business credentials and get you set up on our platform. Once approved, you\'ll start receiving qualified leads from customers looking for your services.',
        ),
        array(
            'question' => 'Is my information secure?',
            'answer' => 'Absolutely. We take your privacy and security seriously. All your personal information is encrypted and protected. We only share necessary details with verified partners to facilitate quotes, and you have full control over who sees your information.',
        ),
        array(
            'question' => 'Can I cancel or change my request?',
            'answer' => 'Yes, you have complete control. You can modify or cancel your request at any time before accepting a quote. There are no penalties or fees for canceling. Simply contact us or use your dashboard to manage your requests.',
        ),
    );
}
?>
<section class="py-24 section-gradient">
    <div class="container mx-auto px-4 lg:px-8">
        <div class="max-w-4xl mx-auto">
            <div class="text-center mb-16">
                <div class="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 text-primary text-sm font-medium mb-6" data-animate>
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <span>Got Questions?</span>
                </div>
                <h2 class="text-foreground mb-6 section-title">
                    Frequently Asked Questions
                </h2>
                <p class="text-lg text-muted-foreground max-w-2xl mx-auto">
                    Find answers to common questions about our pricing and services.
                </p>
            </div>
            
            <div class="space-y-4">
                <?php foreach ($faq_items as $faq_item) : ?>
                <div class="faq-item bg-card rounded-2xl border border-border overflow-hidden card-hover-smooth">
                    <button class="faq-question w-full flex items-center justify-between p-6 text-left hover:bg-secondary/50 transition-colors" onclick="toggleFaq(this)">
                            <h3 class="text-xl font-semibold text-foreground pr-4"><?php echo esc_html(isset($faq_item['question']) ? $faq_item['question'] : ''); ?></h3>
                        <svg class="w-6 h-6 text-primary flex-shrink-0 faq-icon transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                        </svg>
                    </button>
                        <div class="faq-answer px-6 pb-6 hidden">
                            <p class="text-muted-foreground leading-relaxed"><?php echo esc_html(isset($faq_item['answer']) ? $faq_item['answer'] : ''); ?></p>
                </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>

<script>
function toggleFaq(button) {
    const faqItem = button.closest('.faq-item');
    const answer = faqItem.querySelector('.faq-answer');
    const icon = button.querySelector('.faq-icon');
    const isOpen = !answer.classList.contains('hidden');
    
    // Close all other FAQs
    document.querySelectorAll('.faq-item').forEach(item => {
        if (item !== faqItem) {
            item.querySelector('.faq-answer').classList.add('hidden');
            item.querySelector('.faq-icon').classList.remove('rotate-180');
        }
    });
    
    // Toggle current FAQ
    if (isOpen) {
        answer.classList.add('hidden');
        icon.classList.remove('rotate-180');
    } else {
        answer.classList.remove('hidden');
        icon.classList.add('rotate-180');
    }
}
</script>

<!-- Login Prompt Modal -->
<div id="pricingLoginModal" class="pricing-login-modal-overlay" style="display: none;">
    <div class="pricing-login-modal">
        <button type="button" class="modal-close-btn" onclick="closePricingLoginModal()">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <line x1="18" y1="6" x2="6" y2="18"></line>
                <line x1="6" y1="6" x2="18" y2="18"></line>
            </svg>
        </button>
        <div class="modal-icon">
            <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
                <path d="M9 12l2 2 4-4"/>
            </svg>
        </div>
        <h3 class="modal-title"><?php _e('Login Required', 'wheelfy'); ?></h3>
        <p class="modal-description" id="loginModalDescription">
            <?php _e('Please login to your partner account to upgrade your subscription plan.', 'wheelfy'); ?>
        </p>
        <div class="modal-actions">
            <a href="#" id="loginModalBtn" class="btn btn-primary">
                <?php _e('Login Now', 'wheelfy'); ?>
            </a>
            <a href="<?php echo esc_url(home_url('/register?type=partner')); ?>" class="btn btn-secondary">
                <?php _e('Register as Partner', 'wheelfy'); ?>
            </a>
        </div>
    </div>
</div>

<!-- Not Partner Modal -->
<div id="pricingNotPartnerModal" class="pricing-login-modal-overlay" style="display: none;">
    <div class="pricing-login-modal">
        <button type="button" class="modal-close-btn" onclick="closePricingNotPartnerModal()">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <line x1="18" y1="6" x2="6" y2="18"></line>
                <line x1="6" y1="6" x2="18" y2="18"></line>
            </svg>
        </button>
        <div class="modal-icon warning">
            <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <circle cx="12" cy="12" r="10"/>
                <line x1="12" y1="8" x2="12" y2="12"/>
                <line x1="12" y1="16" x2="12.01" y2="16"/>
            </svg>
        </div>
        <h3 class="modal-title"><?php _e('Partner Account Required', 'wheelfy'); ?></h3>
        <p class="modal-description">
            <?php _e('Subscription plans are only available for partner accounts. Please register as a partner to access these plans.', 'wheelfy'); ?>
        </p>
        <div class="modal-actions">
            <a href="<?php echo esc_url(home_url('/register?type=partner')); ?>" class="btn btn-primary">
                <?php _e('Register as Partner', 'wheelfy'); ?>
            </a>
            <button type="button" class="btn btn-secondary" onclick="closePricingNotPartnerModal()">
                <?php _e('Cancel', 'wheelfy'); ?>
            </button>
        </div>
    </div>
</div>

<style>
/* Login Modal Styles */
.pricing-login-modal-overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.7);
    backdrop-filter: blur(4px);
    z-index: 9999;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 1rem;
    animation: fadeIn 0.2s ease;
}

@keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
}

.pricing-login-modal {
    background: hsl(var(--card));
    border-radius: 1.5rem;
    padding: 2rem;
    max-width: 420px;
    width: 100%;
    text-align: center;
    position: relative;
    box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.4);
    animation: modalSlideIn 0.3s ease;
}

@keyframes modalSlideIn {
    from {
        opacity: 0;
        transform: scale(0.95) translateY(-20px);
    }
    to {
        opacity: 1;
        transform: scale(1) translateY(0);
    }
}

.pricing-login-modal .modal-close-btn {
    position: absolute;
    top: 1rem;
    right: 1rem;
    background: transparent;
    border: none;
    color: hsl(var(--muted-foreground));
    cursor: pointer;
    padding: 0.5rem;
    border-radius: 0.5rem;
    transition: all 0.2s;
}

.pricing-login-modal .modal-close-btn:hover {
    background: hsl(var(--secondary));
    color: hsl(var(--foreground));
}

.pricing-login-modal .modal-icon {
    width: 80px;
    height: 80px;
    margin: 0 auto 1.5rem;
    background: linear-gradient(135deg, hsl(60 96% 79% / 0.2), hsl(186 80% 19% / 0.2));
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: hsl(var(--primary));
}

.pricing-login-modal .modal-icon.warning {
    background: linear-gradient(135deg, hsl(45 100% 50% / 0.2), hsl(30 100% 50% / 0.2));
    color: hsl(45 100% 50%);
}

.pricing-login-modal .modal-title {
    font-size: 1.5rem;
    font-weight: 700;
    color: hsl(var(--foreground));
    margin: 0 0 0.75rem;
}

.pricing-login-modal .modal-description {
    color: hsl(var(--muted-foreground));
    font-size: 0.9375rem;
    line-height: 1.6;
    margin: 0 0 1.5rem;
}

.pricing-login-modal .modal-actions {
    display: flex;
    flex-direction: column;
    gap: 0.75rem;
}

.pricing-login-modal .btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 0.875rem 1.5rem;
    font-size: 0.9375rem;
    font-weight: 600;
    text-decoration: none;
    border-radius: 0.75rem;
    transition: all 0.3s ease;
    cursor: pointer;
    border: none;
}

.pricing-login-modal .btn-primary {
    background: linear-gradient(135deg, hsl(60 96% 79%), hsl(186 80% 19%));
    color: hsl(var(--primary-foreground));
    box-shadow: 0 10px 15px -3px hsl(60 96% 79% / 0.3);
}

.pricing-login-modal .btn-primary:hover {
    background: linear-gradient(135deg, hsl(60 96% 82%), hsl(186 80% 22%));
    box-shadow: 0 15px 20px -5px hsl(60 96% 79% / 0.4);
    transform: translateY(-2px);
}

.pricing-login-modal .btn-secondary {
    background: hsl(var(--secondary));
    color: hsl(var(--foreground));
}

.pricing-login-modal .btn-secondary:hover {
    background: hsl(var(--secondary) / 0.8);
}
</style>

<script>
// Handle upgrade button clicks for non-logged-in or non-partner users
document.addEventListener('DOMContentLoaded', function() {
    const upgradeButtons = document.querySelectorAll('.upgrade-btn-login');
    
    upgradeButtons.forEach(function(button) {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            
            const isLoggedIn = this.dataset.isLoggedIn === '1';
            const isPartner = this.dataset.isPartner === '1';
            const planName = this.dataset.planName;
            const loginUrl = this.dataset.loginUrl;
            const checkoutUrl = this.dataset.checkoutUrl;
            
            if (!isLoggedIn) {
                // Show login modal
                const loginBtn = document.getElementById('loginModalBtn');
                loginBtn.href = loginUrl;
                
                // Update description with plan name
                const description = document.getElementById('loginModalDescription');
                description.textContent = '<?php echo esc_js(__('Please login to your partner account to upgrade to', 'wheelfy')); ?> ' + planName + '.';
                
                document.getElementById('pricingLoginModal').style.display = 'flex';
            } else if (!isPartner) {
                // Show not partner modal
                document.getElementById('pricingNotPartnerModal').style.display = 'flex';
            }
        });
    });
    
    // Close modal on overlay click
    document.querySelectorAll('.pricing-login-modal-overlay').forEach(function(overlay) {
        overlay.addEventListener('click', function(e) {
            if (e.target === this) {
                this.style.display = 'none';
            }
        });
    });
    
    // Close modal on escape key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            document.querySelectorAll('.pricing-login-modal-overlay').forEach(function(modal) {
                modal.style.display = 'none';
            });
        }
    });
});

function closePricingLoginModal() {
    document.getElementById('pricingLoginModal').style.display = 'none';
}

function closePricingNotPartnerModal() {
    document.getElementById('pricingNotPartnerModal').style.display = 'none';
}
</script>

<?php
get_footer();


