    </main>

    <?php
    /**
     * Get Footer Layout Settings from CMB2 Options
     */
    $footer_padding_top = wheelfy_get_footer_option('footer_padding_top', '64');
    $footer_border_color = wheelfy_get_footer_option('footer_border_color', 'rgba(255, 255, 255, 0.1)');
    ?>
    <footer class="bg-card border-t border-border">
        <div class="container mx-auto px-4 lg:px-8 footer-container" style="padding-top: <?php echo esc_attr($footer_padding_top); ?>px;">
            <?php
            // Check if Footer Widget Area should be shown
            $footer_show_widgets = wheelfy_get_footer_option('footer_show_widgets', true);
            $footer_widget_columns = wheelfy_get_footer_option('footer_widget_columns', '4');
            
            // Determine grid columns based on whether widgets are shown
            $total_columns = 4; // Default: Brand, Quick Links, Menu Two, Contact
            if ($footer_show_widgets && is_active_sidebar('footer-widget-area')) {
                // If footer widget area is active, we might need to adjust layout
                // For now, keep 4 columns and add widget area conditionally
            }
            ?>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 footer-grid" style="margin-bottom: 60px;">
                <!-- Brand Info -->
                <?php
                /**
                 * Get Footer Logo Settings from CMB2 Options
                 */
                // Get footer logo
                $default_footer_logo_path = get_template_directory() . '/assets/logo-main.png';
                $default_footer_logo_url = get_template_directory_uri() . '/assets/logo-main.png';
                $footer_logo_url = wheelfy_get_footer_logo($default_footer_logo_url);
                $footer_logo_height = wheelfy_get_footer_option('footer_logo_height', '40');
                $footer_logo_description = wheelfy_get_footer_option('footer_logo_description', '');
                
                // Check if custom footer logo is set
                $options = get_option('wheelfy-footer-options', array());
                $footer_logo_value_raw = isset($options['footer_logo']) ? $options['footer_logo'] : '';
                $is_custom_footer_logo = !empty($footer_logo_value_raw);
                ?>
                <div class="space-y-4">
                    <a href="<?php echo esc_url(home_url('/')); ?>" class="flex items-center gap-2">
                        <?php 
                        // Priority: Footer logo > Header logo > Default logo > Custom logo > Site name
                        if ($is_custom_footer_logo && $footer_logo_url) : ?>
                            <img src="<?php echo esc_url($footer_logo_url); ?>" alt="<?php echo esc_attr(get_bloginfo('name')); ?>" style="height: <?php echo esc_attr($footer_logo_height); ?>px; width: auto; max-height: <?php echo esc_attr($footer_logo_height); ?>px;">
                        <?php elseif (file_exists($default_footer_logo_path)) : ?>
                            <img src="<?php echo esc_url($default_footer_logo_url); ?>" alt="<?php echo esc_attr(get_bloginfo('name')); ?>" style="height: <?php echo esc_attr($footer_logo_height); ?>px; width: auto; max-height: <?php echo esc_attr($footer_logo_height); ?>px;">
                        <?php elseif (has_custom_logo()) : ?>
                            <?php the_custom_logo(); ?>
                        <?php else : ?>
                            <div class="w-10 h-10 rounded-xl bg-primary flex items-center justify-center">
                                <svg class="w-6 h-6 text-primary-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                                </svg>
                            </div>
                            <span class="text-xl font-bold text-foreground"><?php bloginfo('name'); ?></span>
                        <?php endif; ?>
                    </a>
                    <?php if ($footer_logo_description) : ?>
                        <p class="text-muted-foreground text-sm leading-relaxed footer-logo-description">
                            <?php echo wp_kses_post($footer_logo_description); ?>
                        </p>
                    <?php else : ?>
                        <p class="text-muted-foreground text-sm leading-relaxed footer-logo-description">
                            <?php bloginfo('description'); ?>
                        </p>
                    <?php endif; ?>
                </div>

                <!-- Quick Links -->
                <?php 
                // Get Quick Links settings from CMB2
                $footer_show_quick_links = wheelfy_get_footer_option('footer_show_quick_links', true);
                $quick_links_heading = wheelfy_get_footer_option('footer_quick_links_heading', 'Quick Links');
                
                if ($footer_show_quick_links) : ?>
                <div id="quick-links-widget-area">
                    <h3 class="text-foreground font-semibold mb-4"><?php echo esc_html($quick_links_heading); ?></h3>
                    <?php 
                    // Priority 1: Check for CMB2 Quick Links (repeater field)
                    $options = get_option('wheelfy-footer-options', array());
                    $cmb2_quick_links = isset($options['footer_quick_links']) && is_array($options['footer_quick_links']) ? $options['footer_quick_links'] : array();
                    
                    // Filter out empty links
                    $cmb2_quick_links = array_filter($cmb2_quick_links, function($link) {
                        return !empty($link['link_text']) && !empty($link['link_url']);
                    });
                    
                    if (!empty($cmb2_quick_links)) {
                        // Display CMB2 Quick Links
                        ?>
                        <ul class="space-y-3 list-none" style="list-style: none !important; padding-left: 0 !important; margin-left: 0 !important;">
                            <?php foreach ($cmb2_quick_links as $link) : 
                                $link_text = isset($link['link_text']) ? sanitize_text_field($link['link_text']) : '';
                                $link_url = isset($link['link_url']) ? esc_url($link['link_url']) : '#';
                                if (!empty($link_text)) :
                            ?>
                                <li style="list-style: none !important; padding-left: 0 !important;">
                                    <a href="<?php echo $link_url; ?>" class="text-muted-foreground hover:text-primary transition-colors text-sm">
                                        <?php echo esc_html($link_text); ?>
                                    </a>
                                </li>
                            <?php 
                                endif;
                            endforeach; ?>
                        </ul>
                        <?php
                    } elseif (is_active_sidebar('quick-links-widget-area')) {
                        // Priority 2: Display widgets from Quick Links Widget Area
                        dynamic_sidebar('quick-links-widget-area');
                    } else {
                        // Priority 3: Fallback - Show default links if no widgets or CMB2 links are added
                        $default_links = array(
                            array('link_text' => 'Home', 'link_url' => home_url('/')),
                            array('link_text' => 'About', 'link_url' => home_url('/about')),
                            array('link_text' => 'FAQ', 'link_url' => home_url('/faq')),
                            array('link_text' => 'Become a Partner', 'link_url' => home_url('/become-partner')),
                        );
                        ?>
                        <ul class="space-y-3 list-none" style="list-style: none !important; padding-left: 0 !important; margin-left: 0 !important;">
                            <?php foreach ($default_links as $link) : ?>
                            <li style="list-style: none !important; padding-left: 0 !important;">
                                <a href="<?php echo esc_url($link['link_url']); ?>" class="text-muted-foreground hover:text-primary transition-colors text-sm">
                                    <?php echo esc_html($link['link_text']); ?>
                                </a>
                            </li>
                            <?php endforeach; ?>
                        </ul>
                        <?php
                    }
                    ?>
                </div>
                <?php endif; ?>

                <!-- Account & Services (Footer Menu Two) -->
                <?php 
                $footer_show_menu_two = wheelfy_get_footer_option('footer_show_menu_two', true);
                
                if ($footer_show_menu_two && is_active_sidebar('footer-menu-two')) : 
                ?>
                <div>
                    <?php dynamic_sidebar('footer-menu-two'); ?>
                </div>
                <?php else : ?>
                <!-- Fallback: Default Account & Services -->
                <div>
                    <h3 class="text-foreground font-semibold mb-4">Account & Services</h3>
                    <ul class="space-y-3 list-none" style="list-style: none !important; padding-left: 0 !important; margin-left: 0 !important;">
                        <li style="list-style: none !important; padding-left: 0 !important;"><a href="<?php echo esc_url(home_url('/login')); ?>" class="text-muted-foreground hover:text-primary transition-colors text-sm">Customer Login</a></li>
                        <li style="list-style: none !important; padding-left: 0 !important;"><a href="<?php echo esc_url(home_url('/login?type=partner')); ?>" class="text-muted-foreground hover:text-primary transition-colors text-sm">Partner Login</a></li>
                        <li style="list-style: none !important; padding-left: 0 !important;"><a href="<?php echo esc_url(home_url('/request-proposal')); ?>" class="text-muted-foreground hover:text-primary transition-colors text-sm">Request for Proposal</a></li>
                        <li style="list-style: none !important; padding-left: 0 !important;"><a href="<?php echo esc_url(home_url('/car-maintenance')); ?>" class="text-muted-foreground hover:text-primary transition-colors text-sm">Car Maintenance</a></li>
                        <li style="list-style: none !important; padding-left: 0 !important;"><a href="<?php echo esc_url(home_url('/car-sales')); ?>" class="text-muted-foreground hover:text-primary transition-colors text-sm">Car Sales</a></li>
                    </ul>
                </div>
                <?php endif; ?>

                <!-- Contact & Social -->
                <div>
                    <?php 
                    // Get dynamic heading from CMB2 Contact & Social settings
                    $contact_social_heading = wheelfy_get_contact_option('contact_social_text', 'Contact & Social');
                    ?>
                    <h3 class="text-foreground font-semibold mb-4"><?php echo esc_html($contact_social_heading); ?></h3>
                    <ul class="space-y-3 list-none" style="list-style: none !important; padding-left: 0 !important; margin-left: 0 !important;">
                        <?php 
                        // Get contact information from CMB2 Contact & Social settings
                        $contact_email = wheelfy_get_contact_option('contact_email', 'info@wheelfy.com');
                        if ($contact_email) : ?>
                        <li style="list-style: none !important; padding-left: 0 !important;">
                            <a href="mailto:<?php echo esc_attr($contact_email); ?>" class="flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors text-sm">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                                </svg>
                                <?php echo esc_html($contact_email); ?>
                            </a>
                        </li>
                        <?php endif; ?>
                        
                        <?php 
                        $contact_phone = wheelfy_get_contact_option('contact_phone', '+36 30 123 4567');
                        if ($contact_phone) : ?>
                        <li style="list-style: none !important; padding-left: 0 !important;">
                            <a href="tel:<?php echo esc_attr(preg_replace('/[^0-9+]/', '', $contact_phone)); ?>" class="flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors text-sm">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                                </svg>
                                <?php echo esc_html($contact_phone); ?>
                            </a>
                        </li>
                        <?php endif; ?>
                        
                        <?php 
                        $contact_city = wheelfy_get_contact_option('contact_city', 'Budapest');
                        $contact_country = wheelfy_get_contact_option('contact_country', 'Hungary');
                        $location = trim($contact_city . ($contact_country ? ', ' . $contact_country : ''));
                        if ($location) : ?>
                        <li class="flex items-center gap-2 text-muted-foreground text-sm" style="list-style: none !important; padding-left: 0 !important;">
                            <svg class="w-4 h-4 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                            </svg>
                            <?php echo esc_html($location); ?>
                        </li>
                        <?php endif; ?>
                    </ul>

                    <!-- Social Links (Icon Buttons - Horizontal) -->
                    <?php 
                    // Get social media links from CMB2 Contact & Social settings
                    $social_facebook = wheelfy_get_contact_option('social_facebook');
                    $social_instagram = wheelfy_get_contact_option('social_instagram');
                    $social_linkedin = wheelfy_get_contact_option('social_linkedin');
                    $social_twitter = wheelfy_get_contact_option('social_twitter');
                    $social_youtube = wheelfy_get_contact_option('social_youtube');
                    
                    if ($social_facebook || $social_instagram || $social_linkedin || $social_twitter || $social_youtube) : ?>
                    <div class="flex items-center gap-4 mt-6">
                        <?php if ($social_facebook) : ?>
                        <a href="<?php echo esc_url($social_facebook); ?>" target="_blank" rel="noopener noreferrer" class="w-10 h-10 rounded-lg bg-secondary flex items-center justify-center text-muted-foreground hover:text-primary hover:bg-secondary/80 transition-all">
                            <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                                <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                            </svg>
                        </a>
                        <?php endif; ?>
                        
                        <?php if ($social_instagram) : ?>
                        <a href="<?php echo esc_url($social_instagram); ?>" target="_blank" rel="noopener noreferrer" class="w-10 h-10 rounded-lg bg-secondary flex items-center justify-center text-muted-foreground hover:text-primary hover:bg-secondary/80 transition-all">
                            <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                                <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                            </svg>
                        </a>
                        <?php endif; ?>
                        
                        <?php if ($social_linkedin) : ?>
                        <a href="<?php echo esc_url($social_linkedin); ?>" target="_blank" rel="noopener noreferrer" class="w-10 h-10 rounded-lg bg-secondary flex items-center justify-center text-muted-foreground hover:text-primary hover:bg-secondary/80 transition-all">
                            <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                                <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
                            </svg>
                        </a>
                        <?php endif; ?>
                        
                        <?php if ($social_twitter) : ?>
                        <a href="<?php echo esc_url($social_twitter); ?>" target="_blank" rel="noopener noreferrer" class="w-10 h-10 rounded-lg bg-secondary flex items-center justify-center text-muted-foreground hover:text-primary hover:bg-secondary/80 transition-all">
                            <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                                <path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z"/>
                            </svg>
                        </a>
                        <?php endif; ?>
                        
                        <?php if ($social_youtube) : ?>
                        <a href="<?php echo esc_url($social_youtube); ?>" target="_blank" rel="noopener noreferrer" class="w-10 h-10 rounded-lg bg-secondary flex items-center justify-center text-muted-foreground hover:text-primary hover:bg-secondary/80 transition-all">
                            <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                                <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
                            </svg>
                        </a>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            


            

            
            <!-- Copyright Section - Bottom Center -->
            <div class="mt-12 pt-6 pb-0 footer-copyright-section" style="border-top: 1px solid <?php echo esc_attr($footer_border_color); ?>;">
                <div class="text-center footer-copyright-text">
                    <p class="text-sm text-muted-foreground">
                        <?php 
                        $footer_copyright = wheelfy_get_footer_option('footer_copyright_text', '&copy; {year} wheelfy &mdash; All rights reserved');
                        // Replace {year} with current year
                        $footer_copyright = str_replace('{year}', date('Y'), $footer_copyright);
                        echo wp_kses_post($footer_copyright);
                        ?>
                    </p>
                </div>
            </div>
        </div>
    </footer>

    <?php wp_footer(); ?>
    
    <!-- Profile Dropdown JavaScript -->
    <script>
    (function() {
        // Profile dropdown toggle functionality
        const profileBtn = document.getElementById('profileDropdownBtn');
        const profileMenu = document.getElementById('profileDropdownMenu');
        
        if (profileBtn && profileMenu) {
            // Toggle dropdown on button click
            profileBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                const isExpanded = profileBtn.getAttribute('aria-expanded') === 'true';
                profileBtn.setAttribute('aria-expanded', !isExpanded);
                profileMenu.classList.toggle('hidden');
            });
            
            // Close dropdown when clicking outside
            document.addEventListener('click', function(e) {
                if (!profileBtn.contains(e.target) && !profileMenu.contains(e.target)) {
                    profileBtn.setAttribute('aria-expanded', 'false');
                    profileMenu.classList.add('hidden');
                }
            });
            
            // Close dropdown on escape key
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape' && !profileMenu.classList.contains('hidden')) {
                    profileBtn.setAttribute('aria-expanded', 'false');
                    profileMenu.classList.add('hidden');
                }
            });
        }
    })();
    </script>
    
    <!-- Notification Counter Real-time Update -->
    <?php if (is_user_logged_in()) : ?>
    <script>
    (function() {
        const notificationBadge = document.getElementById('headerNotificationBadge');
        const notificationCount = document.getElementById('headerNotificationCount');
        
        if (!notificationBadge || !notificationCount) {
            return; // Exit if elements don't exist
        }
        
        // Function to update notification count
        function updateNotificationCount() {
            fetch('<?php echo esc_js(admin_url('admin-ajax.php')); ?>', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: new URLSearchParams({
                    action: 'get_notification_count'
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success && typeof data.data.unread_count !== 'undefined') {
                    const count = parseInt(data.data.unread_count) || 0;
                    
                    // Update count text
                    notificationCount.textContent = count > 99 ? '99+' : count.toString();
                    
                    // Show/hide badge based on count
                    if (count > 0) {
                        notificationBadge.classList.remove('hidden');
                    } else {
                        notificationBadge.classList.add('hidden');
                    }
                }
            })
            .catch(error => {
                console.error('Error fetching notification count:', error);
            });
        }
        
        // Initial load
        updateNotificationCount();
        
        // Update every 30 seconds (real-time polling)
        setInterval(updateNotificationCount, 30000);
        
        // Also update when page becomes visible (user switches back to tab)
        document.addEventListener('visibilitychange', function() {
            if (!document.hidden) {
                updateNotificationCount();
            }
        });
        
        // Update when user focuses the window
        window.addEventListener('focus', updateNotificationCount);
    })();
    </script>
    <?php endif; ?>
</div>
</body>
</html>

