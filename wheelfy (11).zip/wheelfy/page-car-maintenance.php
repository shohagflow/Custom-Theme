<?php
/**
 * Template Name: Car Maintenance
 * 
 * @package Wheelfy
 */

get_header();

// Get page ID
$page_id = get_the_ID();

// Get hero meta fields
$hero_badge = get_post_meta($page_id, 'maintenance_hero_badge', true);
if (empty($hero_badge)) {
    $hero_badge = 'Car Maintenance';
}

$hero_title = get_post_meta($page_id, 'maintenance_hero_title_text', true);
if (empty($hero_title)) {
    $hero_title = 'When your car needs care, we help you';
}

$hero_subtitle = get_post_meta($page_id, 'maintenance_hero_subtitle', true);
if (empty($hero_subtitle)) {
    $hero_subtitle = 'save money';
}

$hero_description = get_post_meta($page_id, 'maintenance_hero_description', true);
if (empty($hero_description)) {
    $hero_description = 'Save time and money by comparing maintenance prices. Our service is completely free to use.';
}

$hero_button_text = get_post_meta($page_id, 'maintenance_hero_button_text', true);
if (empty($hero_button_text)) {
    $hero_button_text = 'Compare Prices';
}

$hero_button_link = get_post_meta($page_id, 'maintenance_hero_button_link', true);
if (empty($hero_button_link)) {
    $hero_button_link = home_url('/request-proposal?type=maintenance');
} else {
    // Handle relative URLs
    if (strpos($hero_button_link, 'http') !== 0) {
        $hero_button_link = home_url($hero_button_link);
    }
}

// Get hero background image
$maintenance_hero_background_image = get_post_meta($page_id, 'maintenance_hero_background_image', true);
$maintenance_hero_background_image_id = get_post_meta($page_id, 'maintenance_hero_background_image_id', true);
$maintenance_hero_background_image_url = '';

// CMB2 file field can store URL or ID depending on configuration
// First, try to get from _id field (attachment ID)
if (!empty($maintenance_hero_background_image_id) && is_numeric($maintenance_hero_background_image_id)) {
    $maintenance_hero_background_image_url = wp_get_attachment_image_url((int)$maintenance_hero_background_image_id, 'full');
    if (empty($maintenance_hero_background_image_url)) {
        $maintenance_hero_background_image_url = wp_get_attachment_url((int)$maintenance_hero_background_image_id);
    }
}

// If no URL found yet, check the main field (might be URL or ID)
if (empty($maintenance_hero_background_image_url) && !empty($maintenance_hero_background_image)) {
    // Check if it's a URL
    if (filter_var($maintenance_hero_background_image, FILTER_VALIDATE_URL)) {
        $maintenance_hero_background_image_url = $maintenance_hero_background_image;
    } 
    // Check if it's an attachment ID
    elseif (is_numeric($maintenance_hero_background_image)) {
        $maintenance_hero_background_image_url = wp_get_attachment_image_url((int)$maintenance_hero_background_image, 'full');
        if (empty($maintenance_hero_background_image_url)) {
            $maintenance_hero_background_image_url = wp_get_attachment_url((int)$maintenance_hero_background_image);
        }
    }
    // Handle array format
    elseif (is_array($maintenance_hero_background_image)) {
        $attachment_id = isset($maintenance_hero_background_image['id']) ? $maintenance_hero_background_image['id'] : (isset($maintenance_hero_background_image[0]) ? $maintenance_hero_background_image[0] : null);
        if (!empty($attachment_id) && is_numeric($attachment_id)) {
            $maintenance_hero_background_image_url = wp_get_attachment_image_url((int)$attachment_id, 'full');
            if (empty($maintenance_hero_background_image_url)) {
                $maintenance_hero_background_image_url = wp_get_attachment_url((int)$attachment_id);
            }
        }
    }
}

// Fallback to default image if no image URL was found
if (empty($maintenance_hero_background_image_url)) {
    $maintenance_hero_background_image_url = get_template_directory_uri() . '/assets/hero-maintenance.jpg';
}
?>

<!-- Hero Section -->
<section class="relative min-h-[80vh] flex items-center overflow-hidden">
    <div class="absolute inset-0">
        <img src="<?php echo esc_url($maintenance_hero_background_image_url); ?>" alt="Car maintenance service" class="w-full h-full object-cover">
        <div class="absolute inset-0 hero-gradient"></div>
        <div class="absolute inset-0 bg-gradient-to-r from-background via-background/90 to-transparent"></div>
    </div>

    <div class="container mx-auto px-4 lg:px-8 relative z-10" style="margin-top: 6rem;">
        <div class="max-w-2xl">
            <?php if (!empty($hero_badge)) : ?>
            <span class="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-6">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                </svg>
                <?php echo esc_html($hero_badge); ?>
            </span>
            <?php endif; ?>

            <h1 class="text-foreground mb-6 hero-title">
                <?php echo esc_html($hero_title); ?>
                <?php if (!empty($hero_subtitle)) : ?>
                <span class="gradient-text block"><?php echo esc_html($hero_subtitle); ?></span>
                <?php endif; ?>
            </h1>

            <?php if (!empty($hero_description)) : ?>
            <p class="text-lg md:text-xl text-muted-foreground mb-10">
                <?php echo esc_html($hero_description); ?>
            </p>
            <?php endif; ?>

            <?php if (!empty($hero_button_text)) : ?>
            <a href="<?php echo esc_url($hero_button_link); ?>" class="button button-hero button-xl group inline-flex items-center gap-2">
                <?php echo esc_html($hero_button_text); ?>
                <svg class="w-5 h-5 transition-transform group-hover:translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
                </svg>
            </a>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- Services Grid -->
<section class="py-24 bg-background">
    <div class="container mx-auto px-4 lg:px-8">
        <?php get_template_part('template-parts/services/maintenance-grid'); ?>
    </div>
</section>

<!-- Benefits Section -->
<section class="py-24 section-gradient">
    <div class="container mx-auto px-4 lg:px-8">
        <?php get_template_part('template-parts/services/maintenance-benefits'); ?>
    </div>
</section>

<?php
get_footer();

