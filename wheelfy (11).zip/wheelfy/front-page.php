<?php
/**
 * The front page template
 * 
 * This template is automatically used when a static page is set as the front page.
 * 
 * @package Wheelfy
 */

get_header();

// Ensure we have the post data
while (have_posts()) {
    the_post();
    ?>
    <main id="main-content" class="flex-1">
        <?php get_template_part('template-parts/home/main-content'); ?>
    </main>
    <?php
}

get_footer();
?>
