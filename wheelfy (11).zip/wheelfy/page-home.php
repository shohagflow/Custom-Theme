<?php
/**
 * Template Name: Home
 * 
 * The template for displaying the home page
 * 
 * @package Wheelfy
 */

get_header();

// Ensure we have the post data
while (have_posts()) {
    the_post();
    ?>
    <main id="main-content" class="flex-1">
        <?php get_template_part('template-parts/home/main-content'); ?>
    </main>
    <?php
}

get_footer();
?>
