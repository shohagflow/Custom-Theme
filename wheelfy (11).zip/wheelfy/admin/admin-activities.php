<?php
/**
 * Admin Activities Page
 * 
 * @package Wheelfy
 */

if (!defined('ABSPATH')) {
    exit;
}

// Check if user is administrator
if (!current_user_can('administrator')) {
    wp_die(__('You do not have permission to access this page.', 'wheelfy'));
}

// Get statistics
require_once get_template_directory() . '/admin/admin-functions.php';

// Get all activities (with a higher limit for the full page)
$activities = wheelfy_get_recent_activities(100);
?>
<div class="wrap wheelfy-admin-activities">
    <h1 class="wp-heading-inline"><?php _e('Activities', 'wheelfy'); ?></h1>
    <hr class="wp-header-end">

    <div class="wheelfy-dashboard-section">
        <div class="activities-list">
            <?php if (!empty($activities)) : ?>
                <?php foreach ($activities as $activity) : ?>
                    <div class="activity-item">
                        <div class="activity-icon activity-<?php echo esc_attr($activity['type']); ?>">
                            <?php echo $activity['icon']; ?>
                        </div>
                        <div class="activity-content">
                            <p class="activity-text"><?php echo esc_html($activity['message']); ?></p>
                            <span class="activity-time"><?php echo esc_html($activity['time']); ?></span>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else : ?>
                <p class="no-activities"><?php _e('No activities found.', 'wheelfy'); ?></p>
            <?php endif; ?>
        </div>
    </div>
</div>

<style>
.wheelfy-admin-activities .activities-list {
    background: #fff;
    border: 1px solid #c3c4c7;
    border-radius: 4px;
    padding: 20px;
}

.wheelfy-admin-activities .activity-item {
    display: flex;
    align-items: flex-start;
    padding: 16px;
    border-bottom: 1px solid #f0f0f1;
}

.wheelfy-admin-activities .activity-item:last-child {
    border-bottom: none;
}

.wheelfy-admin-activities .activity-icon {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 16px;
    flex-shrink: 0;
}

.wheelfy-admin-activities .activity-content {
    flex: 1;
}

.wheelfy-admin-activities .activity-text {
    margin: 0 0 4px 0;
    font-size: 14px;
    color: #1d2327;
}

.wheelfy-admin-activities .activity-time {
    font-size: 12px;
    color: #646970;
}

.wheelfy-admin-activities .no-activities {
    padding: 40px;
    text-align: center;
    color: #646970;
    font-size: 14px;
}
</style>
