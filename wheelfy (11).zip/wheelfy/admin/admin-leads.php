<?php
/**
 * Admin Leads & Offers Management Page
 * 
 * @package Wheelfy
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!current_user_can('administrator')) {
    wp_die(__('You do not have permission to access this page.', 'wheelfy'));
}

// Dummy leads data
$dummy_leads = array(
    array('id' => 1, 'customer' => 'John Doe', 'service' => 'Oil Change', 'location' => 'Budapest', 'status' => 'open', 'date' => '2025-01-25', 'offers' => 3),
    array('id' => 2, 'customer' => 'Jane Smith', 'service' => 'Brake Repair', 'location' => 'Budapest', 'status' => 'offered', 'date' => '2025-01-24', 'offers' => 5),
    array('id' => 3, 'customer' => 'Mike Johnson', 'service' => 'Tire Replacement', 'location' => 'Debrecen', 'status' => 'accepted', 'date' => '2025-01-23', 'offers' => 4),
    array('id' => 4, 'customer' => 'Sarah Williams', 'service' => 'Engine Diagnostic', 'location' => 'Szeged', 'status' => 'closed', 'date' => '2025-01-22', 'offers' => 2),
    array('id' => 5, 'customer' => 'Tom Brown', 'service' => 'AC Repair', 'location' => 'Budapest', 'status' => 'open', 'date' => '2025-01-21', 'offers' => 1),
);

// Dummy offers data
$dummy_offers = array(
    array('id' => 1, 'lead_id' => 1, 'partner' => 'Auto Service Ltd', 'amount' => 45.00, 'distance' => '2.5 km', 'status' => 'pending', 'date' => '2025-01-25'),
    array('id' => 2, 'lead_id' => 1, 'partner' => 'Car Care Center', 'amount' => 42.00, 'distance' => '3.1 km', 'status' => 'pending', 'date' => '2025-01-25'),
    array('id' => 3, 'lead_id' => 1, 'partner' => 'Express Auto Repair', 'amount' => 48.00, 'distance' => '4.2 km', 'status' => 'pending', 'date' => '2025-01-25'),
    array('id' => 4, 'lead_id' => 2, 'partner' => 'Quick Fix Garage', 'amount' => 150.00, 'distance' => '1.8 km', 'status' => 'accepted', 'date' => '2025-01-24'),
    array('id' => 5, 'lead_id' => 2, 'partner' => 'Brake Masters', 'amount' => 165.00, 'distance' => '2.3 km', 'status' => 'pending', 'date' => '2025-01-24'),
    array('id' => 6, 'lead_id' => 2, 'partner' => 'Auto Experts', 'amount' => 140.00, 'distance' => '3.5 km', 'status' => 'pending', 'date' => '2025-01-24'),
    array('id' => 7, 'lead_id' => 2, 'partner' => 'City Brake Shop', 'amount' => 155.00, 'distance' => '4.1 km', 'status' => 'pending', 'date' => '2025-01-24'),
    array('id' => 8, 'lead_id' => 2, 'partner' => 'Premium Auto Care', 'amount' => 175.00, 'distance' => '5.8 km', 'status' => 'rejected', 'date' => '2025-01-24'),
    array('id' => 9, 'lead_id' => 3, 'partner' => 'Pro Mechanics', 'amount' => 320.00, 'distance' => '5.2 km', 'status' => 'accepted', 'date' => '2025-01-23'),
    array('id' => 10, 'lead_id' => 3, 'partner' => 'Tire World', 'amount' => 295.00, 'distance' => '2.7 km', 'status' => 'pending', 'date' => '2025-01-23'),
    array('id' => 11, 'lead_id' => 3, 'partner' => 'Wheel Experts', 'amount' => 310.00, 'distance' => '3.9 km', 'status' => 'pending', 'date' => '2025-01-23'),
    array('id' => 12, 'lead_id' => 3, 'partner' => 'Auto Tire Center', 'amount' => 280.00, 'distance' => '6.1 km', 'status' => 'rejected', 'date' => '2025-01-23'),
    array('id' => 13, 'lead_id' => 4, 'partner' => 'City Auto Shop', 'amount' => 85.00, 'distance' => '4.0 km', 'status' => 'rejected', 'date' => '2025-01-22'),
    array('id' => 14, 'lead_id' => 4, 'partner' => 'Diagnostic Pro', 'amount' => 90.00, 'distance' => '2.1 km', 'status' => 'accepted', 'date' => '2025-01-22'),
    array('id' => 15, 'lead_id' => 5, 'partner' => 'AC Specialists', 'amount' => 120.00, 'distance' => '1.5 km', 'status' => 'pending', 'date' => '2025-01-21'),
    array('id' => 16, 'lead_id' => 5, 'partner' => 'Cool Air Auto', 'amount' => 115.00, 'distance' => '3.2 km', 'status' => 'pending', 'date' => '2025-01-21'),
    array('id' => 17, 'lead_id' => 6, 'partner' => 'Master Auto Service', 'amount' => 55.00, 'distance' => '2.8 km', 'status' => 'pending', 'date' => '2025-01-20'),
    array('id' => 18, 'lead_id' => 6, 'partner' => 'Quick Lube Express', 'amount' => 50.00, 'distance' => '1.9 km', 'status' => 'accepted', 'date' => '2025-01-20'),
    array('id' => 19, 'lead_id' => 7, 'partner' => 'Transmission Experts', 'amount' => 450.00, 'distance' => '3.4 km', 'status' => 'pending', 'date' => '2025-01-19'),
    array('id' => 20, 'lead_id' => 7, 'partner' => 'Gear Box Pro', 'amount' => 480.00, 'distance' => '4.5 km', 'status' => 'pending', 'date' => '2025-01-19'),
    array('id' => 21, 'lead_id' => 7, 'partner' => 'Auto Transmission Center', 'amount' => 420.00, 'distance' => '2.2 km', 'status' => 'accepted', 'date' => '2025-01-19'),
    array('id' => 22, 'lead_id' => 8, 'partner' => 'Battery World', 'amount' => 95.00, 'distance' => '1.7 km', 'status' => 'pending', 'date' => '2025-01-18'),
    array('id' => 23, 'lead_id' => 8, 'partner' => 'Power Battery Shop', 'amount' => 88.00, 'distance' => '3.6 km', 'status' => 'pending', 'date' => '2025-01-18'),
    array('id' => 24, 'lead_id' => 8, 'partner' => 'Auto Battery Plus', 'amount' => 102.00, 'distance' => '5.3 km', 'status' => 'rejected', 'date' => '2025-01-18'),
    array('id' => 25, 'lead_id' => 9, 'partner' => 'Windshield Repair Pro', 'amount' => 180.00, 'distance' => '2.4 km', 'status' => 'accepted', 'date' => '2025-01-17'),
    array('id' => 26, 'lead_id' => 9, 'partner' => 'Glass Masters', 'amount' => 195.00, 'distance' => '3.8 km', 'status' => 'pending', 'date' => '2025-01-17'),
    array('id' => 27, 'lead_id' => 10, 'partner' => 'Exhaust System Specialists', 'amount' => 220.00, 'distance' => '2.9 km', 'status' => 'pending', 'date' => '2025-01-16'),
    array('id' => 28, 'lead_id' => 10, 'partner' => 'Muffler Man', 'amount' => 200.00, 'distance' => '1.6 km', 'status' => 'accepted', 'date' => '2025-01-16'),
    array('id' => 29, 'lead_id' => 10, 'partner' => 'Exhaust Pro', 'amount' => 235.00, 'distance' => '4.7 km', 'status' => 'rejected', 'date' => '2025-01-16'),
    array('id' => 30, 'lead_id' => 11, 'partner' => 'Radiator Repair Center', 'amount' => 160.00, 'distance' => '2.0 km', 'status' => 'pending', 'date' => '2025-01-15'),
    array('id' => 31, 'lead_id' => 11, 'partner' => 'Cooling System Experts', 'amount' => 175.00, 'distance' => '3.3 km', 'status' => 'pending', 'date' => '2025-01-15'),
    array('id' => 32, 'lead_id' => 12, 'partner' => 'Suspension Masters', 'amount' => 380.00, 'distance' => '2.6 km', 'status' => 'accepted', 'date' => '2025-01-14'),
    array('id' => 33, 'lead_id' => 12, 'partner' => 'Shock Absorber Pro', 'amount' => 395.00, 'distance' => '4.3 km', 'status' => 'pending', 'date' => '2025-01-14'),
    array('id' => 34, 'lead_id' => 13, 'partner' => 'Headlight Restoration', 'amount' => 75.00, 'distance' => '1.4 km', 'status' => 'accepted', 'date' => '2025-01-13'),
    array('id' => 35, 'lead_id' => 13, 'partner' => 'Light Works Auto', 'amount' => 80.00, 'distance' => '2.7 km', 'status' => 'pending', 'date' => '2025-01-13'),
);

// Calculate statistics
$total_leads = count($dummy_leads);
$open_leads = count(array_filter($dummy_leads, function($lead) { return $lead['status'] === 'open'; }));
$accepted_leads = count(array_filter($dummy_leads, function($lead) { return $lead['status'] === 'accepted'; }));
$total_offers = count($dummy_offers);
$pending_offers = count(array_filter($dummy_offers, function($offer) { return $offer['status'] === 'pending'; }));
$accepted_offers = count(array_filter($dummy_offers, function($offer) { return $offer['status'] === 'accepted'; }));
$total_revenue = array_sum(array_column(array_filter($dummy_offers, function($offer) { return $offer['status'] === 'accepted'; }), 'amount'));

$current_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'leads';
?>
<div class="wrap wheelfy-admin-leads">
    <!-- Header -->
    <div class="wheelfy-admin-header">
        <div>
            <h1 class="wp-heading-inline"><?php _e('Lead & Offer Management', 'wheelfy'); ?></h1>
            <p class="description"><?php _e('Manage customer service requests, partner offers, and track the complete workflow', 'wheelfy'); ?></p>
        </div>
    </div>
    <hr class="wp-header-end">

    <!-- KPI Cards -->
    <div class="wheelfy-kpi-grid">
        <div class="wheelfy-kpi-card">
            <div class="kpi-icon" style="background: #e3f2fd; color: #1976d2;">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M9 11l3 3L22 4"></path>
                    <path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11"></path>
                </svg>
            </div>
            <div class="kpi-content">
                <div class="kpi-label"><?php _e('Total Leads', 'wheelfy'); ?></div>
                <div class="kpi-value"><?php echo number_format($total_leads); ?></div>
            </div>
        </div>

        <div class="wheelfy-kpi-card">
            <div class="kpi-icon" style="background: #fff3e0; color: #f57c00;">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="12" cy="12" r="10"></circle>
                    <path d="M12 6v6l4 2"></path>
                </svg>
            </div>
            <div class="kpi-content">
                <div class="kpi-label"><?php _e('Open Leads', 'wheelfy'); ?></div>
                <div class="kpi-value"><?php echo number_format($open_leads); ?></div>
            </div>
        </div>

        <div class="wheelfy-kpi-card">
            <div class="kpi-icon" style="background: #e8f5e9; color: #388e3c;">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="20 6 9 17 4 12"></polyline>
                </svg>
            </div>
            <div class="kpi-content">
                <div class="kpi-label"><?php _e('Accepted Offers', 'wheelfy'); ?></div>
                <div class="kpi-value"><?php echo number_format($accepted_offers); ?></div>
            </div>
        </div>

        <div class="wheelfy-kpi-card">
            <div class="kpi-icon" style="background: #f3e5f5; color: #7b1fa2;">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <line x1="12" y1="1" x2="12" y2="23"></line>
                    <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
                </svg>
            </div>
            <div class="kpi-content">
                <div class="kpi-label"><?php _e('Total Revenue', 'wheelfy'); ?></div>
                <div class="kpi-value">€<?php echo number_format($total_revenue, 2); ?></div>
            </div>
        </div>
    </div>

    <!-- Tabs Navigation -->
    <nav class="nav-tab-wrapper wheelfy-subscription-tabs">
        <a href="<?php echo esc_url(add_query_arg('tab', 'leads', admin_url('admin.php?page=wheelfy-leads'))); ?>" 
           class="nav-tab <?php echo $current_tab === 'leads' ? 'nav-tab-active' : ''; ?>" 
           data-tab="leads">
            <?php _e('Service Requests (Leads)', 'wheelfy'); ?>
        </a>
        <a href="<?php echo esc_url(add_query_arg('tab', 'offers', admin_url('admin.php?page=wheelfy-leads'))); ?>" 
           class="nav-tab <?php echo $current_tab === 'offers' ? 'nav-tab-active' : ''; ?>" 
           data-tab="offers">
            <?php _e('Partner Offers', 'wheelfy'); ?>
        </a>
        <a href="<?php echo esc_url(add_query_arg('tab', 'workflow', admin_url('admin.php?page=wheelfy-leads'))); ?>" 
           class="nav-tab <?php echo $current_tab === 'workflow' ? 'nav-tab-active' : ''; ?>" 
           data-tab="workflow">
            <?php _e('Workflow Tracking', 'wheelfy'); ?>
        </a>
    </nav>

    <!-- Tab Content -->
    <div class="wheelfy-tab-content <?php echo $current_tab === 'leads' ? 'active' : ''; ?>" id="tab-leads">
            <div class="wheelfy-dashboard-card">
                <div class="card-header">
                    <div>
                        <h2><?php _e('Service Requests (Leads)', 'wheelfy'); ?></h2>
                        <p class="card-description"><?php _e('View and manage all customer service requests', 'wheelfy'); ?></p>
                    </div>
                    <div class="header-filters">
                        <input type="text" class="search-input" placeholder="<?php esc_attr_e('Search leads...', 'wheelfy'); ?>" id="search-leads">
                        <select class="filter-select" id="filter-lead-status">
                            <option value="all"><?php _e('All Status', 'wheelfy'); ?></option>
                            <option value="open"><?php _e('Open', 'wheelfy'); ?></option>
                            <option value="offered"><?php _e('Offered', 'wheelfy'); ?></option>
                            <option value="accepted"><?php _e('Accepted', 'wheelfy'); ?></option>
                            <option value="closed"><?php _e('Closed', 'wheelfy'); ?></option>
                        </select>
                    </div>
                </div>
                <div class="card-body">
                    <table class="wp-list-table widefat fixed striped table-view-list">
                        <thead>
                            <tr>
                                <th class="column-id"><?php _e('#', 'wheelfy'); ?></th>
                                <th class="column-customer"><?php _e('Customer', 'wheelfy'); ?></th>
                                <th class="column-service"><?php _e('Service', 'wheelfy'); ?></th>
                                <th class="column-location"><?php _e('Location', 'wheelfy'); ?></th>
                                <th class="column-status"><?php _e('Status', 'wheelfy'); ?></th>
                                <th class="column-offers"><?php _e('Offers', 'wheelfy'); ?></th>
                                <th class="column-date"><?php _e('Date', 'wheelfy'); ?></th>
                                <th class="column-actions"><?php _e('Actions', 'wheelfy'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $lead_count = 0;
                            foreach ($dummy_leads as $lead) : 
                                $lead_count++;
                            ?>
                                <tr>
                                    <td class="column-id"><?php echo $lead_count; ?></td>
                                    <td class="column-customer"><strong><?php echo esc_html($lead['customer']); ?></strong></td>
                                    <td class="column-service"><?php echo esc_html($lead['service']); ?></td>
                                    <td class="column-location"><?php echo esc_html($lead['location']); ?></td>
                                    <td class="column-status">
                                        <span class="status-badge status-<?php echo esc_attr($lead['status']); ?>">
                                            <?php echo esc_html(ucfirst($lead['status'])); ?>
                                        </span>
                                    </td>
                                    <td class="column-offers">
                                        <span class="badge-count"><?php echo $lead['offers']; ?></span>
                                    </td>
                                    <td class="column-date"><?php echo esc_html($lead['date']); ?></td>
                                    <td class="column-actions">
                                        <div class="row-actions">
                                            <a href="#" class="button button-small"><?php _e('View', 'wheelfy'); ?></a>
                                            <a href="#" class="button button-small"><?php _e('Edit', 'wheelfy'); ?></a>
                                            <a href="#" class="button button-small button-link-delete"><?php _e('Delete', 'wheelfy'); ?></a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="wheelfy-tab-content <?php echo $current_tab === 'offers' ? 'active' : ''; ?>" id="tab-offers">
            <div class="wheelfy-dashboard-card">
                <div class="card-header">
                    <div>
                        <h2><?php _e('Partner Offers', 'wheelfy'); ?></h2>
                        <p class="card-description"><?php _e('Monitor and manage all partner offers submitted for leads', 'wheelfy'); ?></p>
                    </div>
                    <div class="header-filters">
                        <input type="text" class="search-input" placeholder="<?php esc_attr_e('Search offers...', 'wheelfy'); ?>" id="search-offers">
                        <select class="filter-select" id="filter-offer-status">
                            <option value="all"><?php _e('All Status', 'wheelfy'); ?></option>
                            <option value="pending"><?php _e('Pending', 'wheelfy'); ?></option>
                            <option value="accepted"><?php _e('Accepted', 'wheelfy'); ?></option>
                            <option value="rejected"><?php _e('Rejected', 'wheelfy'); ?></option>
                        </select>
                    </div>
                </div>
                <div class="card-body">
                    <table class="wp-list-table widefat fixed striped table-view-list">
                        <thead>
                            <tr>
                                <th class="column-id"><?php _e('#', 'wheelfy'); ?></th>
                                <th class="column-lead-id"><?php _e('Lead ID', 'wheelfy'); ?></th>
                                <th class="column-partner"><?php _e('Partner', 'wheelfy'); ?></th>
                                <th class="column-amount"><?php _e('Amount', 'wheelfy'); ?></th>
                                <th class="column-distance"><?php _e('Distance', 'wheelfy'); ?></th>
                                <th class="column-status"><?php _e('Status', 'wheelfy'); ?></th>
                                <th class="column-date"><?php _e('Date', 'wheelfy'); ?></th>
                                <th class="column-actions"><?php _e('Actions', 'wheelfy'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $offer_count = 0;
                            foreach ($dummy_offers as $offer) : 
                                $offer_count++;
                            ?>
                                <tr>
                                    <td class="column-id"><?php echo $offer_count; ?></td>
                                    <td class="column-lead-id"><a href="#">#<?php echo $offer['lead_id']; ?></a></td>
                                    <td class="column-partner"><strong><?php echo esc_html($offer['partner']); ?></strong></td>
                                    <td class="column-amount"><strong>€<?php echo number_format($offer['amount'], 2); ?></strong></td>
                                    <td class="column-distance"><?php echo esc_html($offer['distance']); ?></td>
                                    <td class="column-status">
                                        <span class="status-badge status-<?php echo esc_attr($offer['status']); ?>">
                                            <?php echo esc_html(ucfirst($offer['status'])); ?>
                                        </span>
                                    </td>
                                    <td class="column-date"><?php echo esc_html($offer['date']); ?></td>
                                    <td class="column-actions">
                                        <div class="row-actions">
                                            <a href="#" class="button button-small"><?php _e('View', 'wheelfy'); ?></a>
                                            <a href="#" class="button button-small"><?php _e('Verify Distance', 'wheelfy'); ?></a>
                                            <a href="#" class="button button-small button-link-delete"><?php _e('Remove', 'wheelfy'); ?></a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="wheelfy-tab-content <?php echo $current_tab === 'workflow' ? 'active' : ''; ?>" id="tab-workflow">
            <div class="wheelfy-dashboard-card">
                <div class="card-header">
                    <div>
                        <h2><?php _e('Workflow Tracking', 'wheelfy'); ?></h2>
                        <p class="card-description"><?php _e('Track the complete workflow from lead creation to offer acceptance', 'wheelfy'); ?></p>
                    </div>
                </div>
                <div class="card-body">
                    <div class="workflow-info">
                        <div class="info-box">
                            <h4><?php _e('Distance Matching', 'wheelfy'); ?></h4>
                            <p><?php _e('System automatically matches partners within 10km radius. Last verified: 2025-01-25', 'wheelfy'); ?></p>
                        </div>
                        <div class="info-box">
                            <h4><?php _e('Offer Acceptance Rate', 'wheelfy'); ?></h4>
                            <p><?php 
                                $acceptance_rate = $total_offers > 0 ? round(($accepted_offers / $total_offers) * 100, 1) : 0;
                                printf(__('%s%% of offers are accepted', 'wheelfy'), $acceptance_rate); 
                            ?></p>
                        </div>
                    </div>

                    <!-- Recent Activity Timeline -->
                    <div class="workflow-timeline-section">
                        <h3 style="margin: 0 0 20px 0; font-size: 18px; font-weight: 600; color: #1d2327;"><?php _e('Recent Activity Timeline', 'wheelfy'); ?></h3>
                        <div class="activity-timeline">
                            <div class="timeline-item">
                                <div class="timeline-marker" style="background: #e8f5e9; color: #388e3c;">
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <polyline points="20 6 9 17 4 12"></polyline>
                                    </svg>
                                </div>
                                <div class="timeline-content">
                                    <div class="timeline-header">
                                        <strong><?php _e('Offer Accepted', 'wheelfy'); ?></strong>
                                        <span class="timeline-date">2025-01-25 14:32</span>
                                    </div>
                                    <p><?php _e('Lead #2 - Quick Fix Garage accepted offer of €150.00 for Brake Repair', 'wheelfy'); ?></p>
                                </div>
                            </div>

                            <div class="timeline-item">
                                <div class="timeline-marker" style="background: #fff3e0; color: #f57c00;">
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <circle cx="12" cy="12" r="10"></circle>
                                        <path d="M12 6v6l4 2"></path>
                                    </svg>
                                </div>
                                <div class="timeline-content">
                                    <div class="timeline-header">
                                        <strong><?php _e('New Offer Submitted', 'wheelfy'); ?></strong>
                                        <span class="timeline-date">2025-01-25 13:15</span>
                                    </div>
                                    <p><?php _e('Lead #1 - Express Auto Repair submitted offer of €48.00 for Oil Change', 'wheelfy'); ?></p>
                                </div>
                            </div>

                            <div class="timeline-item">
                                <div class="timeline-marker" style="background: #e3f2fd; color: #1976d2;">
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <path d="M9 11l3 3L22 4"></path>
                                        <path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11"></path>
                                    </svg>
                                </div>
                                <div class="timeline-content">
                                    <div class="timeline-header">
                                        <strong><?php _e('New Lead Created', 'wheelfy'); ?></strong>
                                        <span class="timeline-date">2025-01-25 10:45</span>
                                    </div>
                                    <p><?php _e('John Doe created a new service request: Oil Change in Budapest', 'wheelfy'); ?></p>
                                </div>
                            </div>

                            <div class="timeline-item">
                                <div class="timeline-marker" style="background: #e8f5e9; color: #388e3c;">
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <polyline points="20 6 9 17 4 12"></polyline>
                                    </svg>
                                </div>
                                <div class="timeline-content">
                                    <div class="timeline-header">
                                        <strong><?php _e('Offer Accepted', 'wheelfy'); ?></strong>
                                        <span class="timeline-date">2025-01-24 16:20</span>
                                    </div>
                                    <p><?php _e('Lead #3 - Pro Mechanics accepted offer of €320.00 for Tire Replacement', 'wheelfy'); ?></p>
                                </div>
                            </div>

                            <div class="timeline-item">
                                <div class="timeline-marker" style="background: #ffebee; color: #c62828;">
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <line x1="18" y1="6" x2="6" y2="18"></line>
                                        <line x1="6" y1="6" x2="18" y2="18"></line>
                                    </svg>
                                </div>
                                <div class="timeline-content">
                                    <div class="timeline-header">
                                        <strong><?php _e('Offer Rejected', 'wheelfy'); ?></strong>
                                        <span class="timeline-date">2025-01-24 11:30</span>
                                    </div>
                                    <p><?php _e('Lead #2 - Premium Auto Care offer of €175.00 was rejected (distance exceeded)', 'wheelfy'); ?></p>
                                </div>
                            </div>

                            <div class="timeline-item">
                                <div class="timeline-marker" style="background: #f3e5f5; color: #7b1fa2;">
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                                        <line x1="16" y1="2" x2="16" y2="6"></line>
                                        <line x1="8" y1="2" x2="8" y2="6"></line>
                                        <line x1="3" y1="10" x2="21" y2="10"></line>
                                    </svg>
                                </div>
                                <div class="timeline-content">
                                    <div class="timeline-header">
                                        <strong><?php _e('Lead Closed', 'wheelfy'); ?></strong>
                                        <span class="timeline-date">2025-01-23 09:15</span>
                                    </div>
                                    <p><?php _e('Lead #4 - Service completed and closed. Total revenue: €90.00', 'wheelfy'); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
/* Hide WordPress Admin Footer on this page */
body.wp-admin.admin-color-scheme-light #wpfooter,
body.wp-admin.admin-color-scheme-dark #wpfooter,
body.wp-admin #wpfooter {
    display: none !important;
    visibility: hidden !important;
    height: 0 !important;
    margin: 0 !important;
    padding: 0 !important;
    overflow: hidden !important;
    opacity: 0 !important;
}

/* Header Styles */
.wheelfy-admin-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 20px;
}

.wheelfy-admin-header h1 {
    margin: 0 0 8px 0;
    font-size: 28px;
    font-weight: 600;
}

.wheelfy-admin-header .description {
    margin: 0;
    color: #646970;
    font-size: 14px;
}

/* KPI Cards */
.wheelfy-kpi-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
    gap: 20px;
    margin: 30px 0;
}

.wheelfy-kpi-card {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 12px;
    padding: 24px;
    display: flex;
    align-items: center;
    gap: 20px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.04);
    transition: all 0.3s ease;
}

.wheelfy-kpi-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 8px 24px rgba(0,0,0,0.12);
    border-color: #2271b1;
}

.kpi-icon {
    width: 64px;
    height: 64px;
    border-radius: 16px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.kpi-icon svg {
    display: block;
    margin: 0 auto;
    width: 24px;
    height: 24px;
}

.kpi-content {
    flex: 1;
}

.kpi-label {
    font-size: 13px;
    color: #646970;
    margin-bottom: 8px;
    font-weight: 500;
}

.kpi-value {
    font-size: 28px;
    font-weight: 700;
    color: #1d2327;
    line-height: 1.2;
}

/* Tab Navigation */
.wheelfy-subscription-tabs {
    margin: 20px 0 0 0;
    border-bottom: 1px solid #ccc;
}

.wheelfy-subscription-tabs .nav-tab {
    margin-left: 0;
    margin-right: 8px;
    padding: 10px 20px;
    font-size: 14px;
    font-weight: 600;
}

.wheelfy-subscription-tabs .nav-tab:last-child {
    margin-right: 0;
}

.wheelfy-subscription-tabs .nav-tab-active {
    border-bottom-color: #fff;
    background: #fff;
    color: #2271b1;
}

/* Tab Content */
.wheelfy-tab-content {
    display: none;
    margin-top: 0;
}

.wheelfy-tab-content.active {
    display: block;
}

/* Dashboard Card */
.wheelfy-dashboard-card {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    margin-top: 20px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.05);
}

.card-header {
    padding: 24px;
    border-bottom: 1px solid #ddd;
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    background: #f8f9fa;
}

.card-header h2 {
    margin: 0 0 4px 0;
    font-size: 20px;
    font-weight: 600;
}

.card-description {
    margin: 0;
    color: #646970;
    font-size: 13px;
}

.header-filters {
    display: flex;
    gap: 10px;
    align-items: center;
    flex-wrap: wrap;
}

.search-input,
.filter-select {
    padding: 6px 12px;
    border: 1px solid #8c8f94;
    border-radius: 4px;
    font-size: 14px;
}

.search-input {
    min-width: 200px;
}

.filter-select {
    min-width: 140px;
}

.card-body {
    padding: 24px;
}

/* Table Styles */
.table-view-list {
    margin: 0;
    border: none;
    width: 100%;
}

/* Tables should extend to card edges */
.card-body > .table-view-list {
    margin: -24px;
    width: calc(100% + 48px);
}

/* But nested content should respect padding */
.card-body > .workflow-info,
.card-body > .workflow-timeline-section {
    margin-left: 0;
    margin-right: 0;
}

.table-view-list thead th {
    background: #f6f7f7;
    font-weight: 600;
    padding: 12px;
    border-bottom: 2px solid #ddd;
}

.table-view-list tbody td {
    padding: 12px;
    vertical-align: middle;
}

.table-view-list tbody tr:hover {
    background: #f9f9f9;
}

/* Status Badges */
.status-badge {
    display: inline-block;
    padding: 4px 12px;
    border-radius: 12px;
    font-size: 12px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.status-open {
    background: #fff3e0;
    color: #f57c00;
}

.status-offered {
    background: #e3f2fd;
    color: #1976d2;
}

.status-accepted {
    background: #e8f5e9;
    color: #388e3c;
}

.status-closed {
    background: #f5f5f5;
    color: #646970;
}

.status-pending {
    background: #fff3e0;
    color: #f57c00;
}

.status-rejected {
    background: #ffebee;
    color: #c62828;
}

/* Badge Count */
.badge-count {
    display: inline-block;
    padding: 4px 10px;
    background: #e3f2fd;
    color: #1976d2;
    border-radius: 12px;
    font-weight: 600;
    font-size: 12px;
}

/* Row Actions */
.row-actions {
    display: flex;
    gap: 6px;
    flex-wrap: wrap;
    align-items: center;
}

.row-actions .button {
    margin: 0;
    white-space: nowrap;
}

/* Workflow Info */
.workflow-info {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 20px;
    margin: 0 0 30px 0;
}

.info-box {
    background: #f8f9fa;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 20px;
}

.info-box h4 {
    margin: 0 0 8px 0;
    font-size: 16px;
    font-weight: 600;
    color: #1d2327;
}

.info-box p {
    margin: 0;
    font-size: 14px;
    color: #646970;
    line-height: 1.6;
}

/* Activity Timeline */
.workflow-timeline-section {
    margin-top: 0;
    padding-top: 30px;
    border-top: 1px solid #ddd;
}

.activity-timeline {
    position: relative;
    padding-left: 30px;
}

.activity-timeline::before {
    content: '';
    position: absolute;
    left: 15px;
    top: 0;
    bottom: 0;
    width: 2px;
    background: #e0e0e0;
}

.timeline-item {
    position: relative;
    margin-bottom: 24px;
    display: flex;
    align-items: flex-start;
    gap: 16px;
}

.timeline-item:last-child {
    margin-bottom: 0;
}

.timeline-marker {
    position: absolute;
    left: -24px;
    width: 32px;
    height: 32px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    border: 3px solid #fff;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    z-index: 1;
}

.timeline-marker svg {
    width: 16px;
    height: 16px;
}

.timeline-content {
    flex: 1;
    background: #fff;
    border: 1px solid #e0e0e0;
    border-radius: 8px;
    padding: 16px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    transition: all 0.3s ease;
}

.timeline-content:hover {
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    border-color: #2271b1;
}

.timeline-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 8px;
}

.timeline-header strong {
    font-size: 14px;
    font-weight: 600;
    color: #1d2327;
}

.timeline-date {
    font-size: 12px;
    color: #646970;
}

.timeline-content p {
    margin: 0;
    font-size: 13px;
    color: #646970;
    line-height: 1.6;
}

/* Responsive */
@media (max-width: 782px) {
    .wheelfy-admin-header {
        flex-direction: column;
        gap: 16px;
    }

    .header-filters {
        width: 100%;
    }

    .header-filters .search-input,
    .header-filters .filter-select {
        flex: 1;
        min-width: 0;
    }

    .wheelfy-kpi-grid {
        grid-template-columns: 1fr;
    }

    .workflow-info {
        grid-template-columns: 1fr;
    }

    .row-actions {
        flex-direction: column;
        align-items: flex-start;
    }

    .card-body .table-view-list {
        margin: -24px;
        width: calc(100% + 48px);
    }
}
</style>

<script>
jQuery(document).ready(function($) {
    // Hide WordPress admin footer
    $('#wpfooter').hide();
    $('p:contains("Thank you for creating")').hide();
    $('p:contains("Version")').hide();
    
    // Tab switching
    $('.wheelfy-subscription-tabs .nav-tab').on('click', function(e) {
        e.preventDefault();
        const tab = $(this).data('tab');
        
        // Update active tab
        $('.wheelfy-subscription-tabs .nav-tab').removeClass('nav-tab-active');
        $(this).addClass('nav-tab-active');
        
        // Show/hide tab content
        $('.wheelfy-tab-content').removeClass('active');
        $('#tab-' + tab).addClass('active');
        
        // Update URL without reload
        const url = new URL(window.location);
        url.searchParams.set('tab', tab);
        window.history.pushState({}, '', url);
    });
    
    // Search functionality (placeholder)
    $('#search-leads, #search-offers').on('keyup', function() {
        const searchTerm = $(this).val().toLowerCase();
        const table = $(this).closest('.wheelfy-dashboard-card').find('table tbody');
        table.find('tr').each(function() {
            const text = $(this).text().toLowerCase();
            $(this).toggle(text.indexOf(searchTerm) > -1);
        });
    });
    
    // Filter functionality (placeholder)
    $('#filter-lead-status, #filter-offer-status').on('change', function() {
        const filterValue = $(this).val();
        const table = $(this).closest('.wheelfy-dashboard-card').find('table tbody');
        
        if (filterValue === 'all') {
            table.find('tr').show();
        } else {
            table.find('tr').each(function() {
                const status = $(this).find('.status-badge').attr('class').match(/status-(\w+)/);
                if (status && status[1] === filterValue) {
                    $(this).show();
                } else {
                    $(this).hide();
                }
            });
        }
    });
});
</script>
