<?php
/**
 * Admin Reviews Moderation - Backend Functions
 * 
 * Handles review moderation, status updates, and data retrieval
 * 
 * @package Wheelfy
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Get all reviews for moderation
 * Collects reviews from all customers and formats them for admin display
 * 
 * @param array $filters Optional filters (status, rating, partner_id, customer_id)
 * @return array Formatted reviews array
 */
function wheelfy_get_all_reviews_for_moderation($filters = array()) {
    global $wpdb;
    
    $reviews = array();
    
    // Get all customers
    $customers = get_users(array(
        'role' => 'customer',
        'meta_key' => 'wheelfy_reviews_given',
        'meta_compare' => 'EXISTS'
    ));
    
    foreach ($customers as $customer) {
        $customer_reviews = get_user_meta($customer->ID, 'wheelfy_reviews_given', true);
        if (!is_array($customer_reviews)) {
            continue;
        }
        
        foreach ($customer_reviews as $review) {
            // Skip cancelled reviews (soft delete)
            if (isset($review['status']) && $review['status'] === 'cancelled') {
                continue;
            }
            
            // Get customer info
            $customer_name = $customer->display_name;
            if (empty($customer_name)) {
                $customer_name = $customer->user_login;
            }
            
            // Get partner info
            $partner_id = isset($review['partner_id']) ? intval($review['partner_id']) : 0;
            $partner = get_userdata($partner_id);
            $partner_name = $partner ? ($partner->display_name ?: $partner->user_login) : __('Unknown Partner', 'wheelfy');
            $business_name = get_user_meta($partner_id, 'business_name', true);
            if (!empty($business_name)) {
                $partner_name = $business_name;
            }
            
            // Determine review status for moderation
            // Default to 'approved' if status is 'published', otherwise use the status directly
            $review_status = 'approved'; // Default
            if (isset($review['status'])) {
                if ($review['status'] === 'published') {
                    $review_status = 'approved';
                } elseif ($review['status'] === 'pending') {
                    $review_status = 'pending';
                } elseif ($review['status'] === 'rejected') {
                    $review_status = 'rejected';
                } elseif ($review['status'] === 'approved') {
                    $review_status = 'approved';
                } else {
                    // For new reviews, default to pending for moderation
                    $review_status = 'pending';
                }
            } else {
                // If no status set, treat as pending for moderation
                $review_status = 'pending';
            }
            
            // Apply filters
            if (!empty($filters['status']) && $filters['status'] !== 'all') {
                if ($review_status !== $filters['status']) {
                    continue;
                }
            }
            
            if (!empty($filters['rating']) && $filters['rating'] !== 'all') {
                $rating = isset($review['rating']) ? intval($review['rating']) : 0;
                if ($rating != intval($filters['rating'])) {
                    continue;
                }
            }
            
            if (!empty($filters['partner_id'])) {
                if ($partner_id != intval($filters['partner_id'])) {
                    continue;
                }
            }
            
            if (!empty($filters['customer_id'])) {
                if ($customer->ID != intval($filters['customer_id'])) {
                    continue;
                }
            }
            
            // Check if review is reported (this would need to be stored somewhere)
            $reported = isset($review['reported']) && $review['reported'] === true;
            
            // Format date
            $created_date = '';
            if (isset($review['created_at'])) {
                $created_date = date_i18n(get_option('date_format'), strtotime($review['created_at']));
            } elseif (isset($review['created_timestamp'])) {
                $created_date = date_i18n(get_option('date_format'), $review['created_timestamp']);
            }
            
            // Get service/request info if available
            $service_name = '';
            if (isset($review['request_id'])) {
                // Could fetch request details here if needed
                $service_name = __('Service Request', 'wheelfy');
            }
            
            // Get review ID (check both 'id' and 'review_id' fields for compatibility)
            // If neither exists, generate a unique ID based on customer, partner, and timestamp
            $review_id_val = isset($review['id']) ? $review['id'] : (isset($review['review_id']) ? $review['review_id'] : '');
            
            // If still empty, generate an ID for backward compatibility
            if (empty($review_id_val)) {
                $created_timestamp = isset($review['created_at']) ? strtotime($review['created_at']) : time();
                $review_id_val = 'review_' . $created_timestamp . '_' . $customer->ID . '_' . $partner_id;
            }
            
            $reviews[] = array(
                'id' => $review_id_val,
                'review_id' => $review_id_val,
                'customer_id' => $customer->ID,
                'customer_name' => $customer_name,
                'partner_id' => $partner_id,
                'partner_name' => $partner_name,
                'rating' => isset($review['rating']) ? intval($review['rating']) : 0,
                'review_text' => isset($review['review_text']) ? $review['review_text'] : '',
                'status' => $review_status,
                'created_at' => isset($review['created_at']) ? $review['created_at'] : '',
                'created_date' => $created_date,
                'reported' => $reported,
                'service' => $service_name,
                'target_type' => 'partner' // Reviews are for partners
            );
        }
    }
    
    // Sort by date (newest first)
    usort($reviews, function($a, $b) {
        $date_a = isset($a['created_at']) ? strtotime($a['created_at']) : 0;
        $date_b = isset($b['created_at']) ? strtotime($b['created_at']) : 0;
        return $date_b - $date_a;
    });
    
    return $reviews;
}

/**
 * Update review status
 * 
 * @param string $review_id Review ID
 * @param string $new_status New status (approved, rejected, pending, cancelled)
 * @return bool Success
 */
function wheelfy_update_review_status($review_id, $new_status) {
    if (!in_array($new_status, array('approved', 'rejected', 'pending', 'cancelled'))) {
        return false;
    }
    
    // Find the review in customer's reviews
    $customers = get_users(array('role' => 'customer'));
    
    foreach ($customers as $customer) {
        $reviews = get_user_meta($customer->ID, 'wheelfy_reviews_given', true);
        if (!is_array($reviews)) {
            continue;
        }
        
        $found = false;
        foreach ($reviews as $index => $review) {
            // Check both 'id' and 'review_id' fields for compatibility
            $current_review_id = isset($review['id']) ? $review['id'] : (isset($review['review_id']) ? $review['review_id'] : '');
            if ($current_review_id === $review_id) {
                // Update status
                if ($new_status === 'approved') {
                    $reviews[$index]['status'] = 'published';
                } elseif ($new_status === 'rejected') {
                    $reviews[$index]['status'] = 'rejected';
                } elseif ($new_status === 'pending') {
                    $reviews[$index]['status'] = 'pending';
                } elseif ($new_status === 'cancelled') {
                    $reviews[$index]['status'] = 'cancelled';
                }
                
                $reviews[$index]['moderated_at'] = current_time('mysql');
                $reviews[$index]['moderated_by'] = get_current_user_id();
                
                // Save customer reviews
                update_user_meta($customer->ID, 'wheelfy_reviews_given', $reviews);
                
                // Also update partner's received reviews
                $partner_id = isset($review['partner_id']) ? intval($review['partner_id']) : 0;
                if ($partner_id > 0) {
                    $partner_reviews = get_user_meta($partner_id, 'wheelfy_reviews_received', true);
                    if (is_array($partner_reviews)) {
                        foreach ($partner_reviews as $p_index => $p_review) {
                            // Check both 'id' and 'review_id' fields for compatibility
                            $p_current_review_id = isset($p_review['id']) ? $p_review['id'] : (isset($p_review['review_id']) ? $p_review['review_id'] : '');
                            if ($p_current_review_id === $review_id) {
                                if ($new_status === 'approved') {
                                    $partner_reviews[$p_index]['status'] = 'published';
                                } elseif ($new_status === 'rejected') {
                                    $partner_reviews[$p_index]['status'] = 'rejected';
                                } elseif ($new_status === 'pending') {
                                    $partner_reviews[$p_index]['status'] = 'pending';
                                } elseif ($new_status === 'cancelled') {
                                    $partner_reviews[$p_index]['status'] = 'cancelled';
                                }
                                
                                $partner_reviews[$p_index]['moderated_at'] = current_time('mysql');
                                $partner_reviews[$p_index]['moderated_by'] = get_current_user_id();
                                break;
                            }
                        }
                        update_user_meta($partner_id, 'wheelfy_reviews_received', $partner_reviews);
                    }
                }
                
                $found = true;
                break;
            }
        }
        
        if ($found) {
            return true;
        }
    }
    
    return false;
}

/**
 * AJAX: Approve Review
 */
function wheelfy_ajax_approve_review() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_moderate_review')) {
        wp_send_json_error(array('message' => __('Security check failed.', 'wheelfy')));
    }
    
    // Check capability
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => __('Permission denied.', 'wheelfy')));
    }
    
    $review_id = isset($_POST['review_id']) ? sanitize_text_field($_POST['review_id']) : '';
    if (empty($review_id)) {
        wp_send_json_error(array('message' => __('Review ID is required.', 'wheelfy')));
    }
    
    $success = wheelfy_update_review_status($review_id, 'approved');
    
    if ($success) {
        wp_send_json_success(array('message' => __('Review approved successfully.', 'wheelfy')));
    } else {
        wp_send_json_error(array('message' => __('Failed to approve review.', 'wheelfy')));
    }
}
add_action('wp_ajax_wheelfy_approve_review', 'wheelfy_ajax_approve_review');

/**
 * AJAX: Reject Review
 */
function wheelfy_ajax_reject_review() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_moderate_review')) {
        wp_send_json_error(array('message' => __('Security check failed.', 'wheelfy')));
    }
    
    // Check capability
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => __('Permission denied.', 'wheelfy')));
    }
    
    $review_id = isset($_POST['review_id']) ? sanitize_text_field($_POST['review_id']) : '';
    if (empty($review_id)) {
        wp_send_json_error(array('message' => __('Review ID is required.', 'wheelfy')));
    }
    
    $success = wheelfy_update_review_status($review_id, 'rejected');
    
    if ($success) {
        wp_send_json_success(array('message' => __('Review rejected successfully.', 'wheelfy')));
    } else {
        wp_send_json_error(array('message' => __('Failed to reject review.', 'wheelfy')));
    }
}
add_action('wp_ajax_wheelfy_reject_review', 'wheelfy_ajax_reject_review');

/**
 * AJAX: Delete Review (Soft Delete)
 */
function wheelfy_ajax_delete_review() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_moderate_review')) {
        wp_send_json_error(array('message' => __('Security check failed.', 'wheelfy')));
    }
    
    // Check capability
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => __('Permission denied.', 'wheelfy')));
    }
    
    $review_id = isset($_POST['review_id']) ? sanitize_text_field($_POST['review_id']) : '';
    if (empty($review_id)) {
        wp_send_json_error(array('message' => __('Review ID is required.', 'wheelfy')));
    }
    
    $success = wheelfy_update_review_status($review_id, 'cancelled');
    
    if ($success) {
        wp_send_json_success(array('message' => __('Review deleted successfully.', 'wheelfy')));
    } else {
        wp_send_json_error(array('message' => __('Failed to delete review.', 'wheelfy')));
    }
}
add_action('wp_ajax_wheelfy_delete_review', 'wheelfy_ajax_delete_review');

/**
 * Get aggregated partner ratings for moderation tab
 * 
 * @return array Partner ratings data
 */
function wheelfy_get_partner_ratings_for_moderation() {
    $partner_ratings = array();
    $partners = get_users(array('role' => 'partner'));

    foreach ($partners as $partner) {
        $reviews_received = get_user_meta($partner->ID, 'wheelfy_reviews_received', true);
        if (!is_array($reviews_received)) {
            $reviews_received = array();
        }

        // Filter to only approved/published reviews
        $active_reviews = array_filter($reviews_received, function($review) {
            $status = isset($review['status']) ? $review['status'] : 'pending';
            return $status === 'published' || $status === 'approved';
        });
        $active_reviews = array_values($active_reviews);

        $total_reviews = count($active_reviews);
        $average_rating = 0;
        if ($total_reviews > 0) {
            $total_rating_sum = array_sum(array_column($active_reviews, 'rating'));
            $average_rating = round($total_rating_sum / $total_reviews, 1);
        }

        $recent_review_date = '';
        if (!empty($active_reviews)) {
            usort($active_reviews, function($a, $b) {
                $date_a = isset($a['created_timestamp']) ? $a['created_timestamp'] : (isset($a['created_at']) ? strtotime($a['created_at']) : 0);
                $date_b = isset($b['created_timestamp']) ? $b['created_timestamp'] : (isset($b['created_at']) ? strtotime($b['created_at']) : 0);
                return $date_b - $date_a;
            });
            $recent_review = $active_reviews[0];
            if (isset($recent_review['created_at'])) {
                $recent_review_date = wp_date(get_option('date_format'), strtotime($recent_review['created_at']));
            } elseif (isset($recent_review['created_timestamp'])) {
                $recent_review_date = wp_date(get_option('date_format'), $recent_review['created_timestamp']);
            }
        }

        $business_name = get_user_meta($partner->ID, 'business_name', true);
        $partner_name = !empty($business_name) ? $business_name : ($partner->display_name ?: $partner->user_login);

        $partner_ratings[] = array(
            'partner_id' => $partner->ID,
            'partner_name' => $partner_name,
            'total_reviews' => $total_reviews,
            'average_rating' => $average_rating,
            'recent_review' => $recent_review_date ?: '-',
        );
    }

    // Sort by average rating (highest first), then by total reviews
    usort($partner_ratings, function($a, $b) {
        if ($b['average_rating'] == $a['average_rating']) {
            return $b['total_reviews'] - $a['total_reviews'];
        }
        return $b['average_rating'] <=> $a['average_rating'];
    });

    return $partner_ratings;
}

/**
 * Recalculate partner ratings
 * 
 * @param int $partner_id Partner user ID
 * @return array Updated ratings data
 */
function wheelfy_recalculate_partner_ratings($partner_id) {
    $partner = get_userdata($partner_id);
    if (!$partner || !in_array('partner', $partner->roles)) {
        return false;
    }
    
    $reviews_received = get_user_meta($partner_id, 'wheelfy_reviews_received', true);
    if (!is_array($reviews_received)) {
        $reviews_received = array();
    }
    
    // Filter to only approved/published reviews
    $active_reviews = array_filter($reviews_received, function($review) {
        $status = isset($review['status']) ? $review['status'] : 'pending';
        return $status === 'published' || $status === 'approved';
    });
    $active_reviews = array_values($active_reviews);
    
    $total_reviews = count($active_reviews);
    $average_rating = 0;
    if ($total_reviews > 0) {
        $total_rating_sum = array_sum(array_column($active_reviews, 'rating'));
        $average_rating = round($total_rating_sum / $total_reviews, 1);
    }
    
    $recent_review_date = '';
    if (!empty($active_reviews)) {
        usort($active_reviews, function($a, $b) {
            $date_a = isset($a['created_timestamp']) ? $a['created_timestamp'] : (isset($a['created_at']) ? strtotime($a['created_at']) : 0);
            $date_b = isset($b['created_timestamp']) ? $b['created_timestamp'] : (isset($b['created_at']) ? strtotime($b['created_at']) : 0);
            return $date_b - $date_a;
        });
        $recent_review = $active_reviews[0];
        if (isset($recent_review['created_at'])) {
            $recent_review_date = wp_date(get_option('date_format'), strtotime($recent_review['created_at']));
        } elseif (isset($recent_review['created_timestamp'])) {
            $recent_review_date = wp_date(get_option('date_format'), $recent_review['created_timestamp']);
        }
    }
    
    return array(
        'partner_id' => $partner_id,
        'total_reviews' => $total_reviews,
        'average_rating' => $average_rating,
        'recent_review' => $recent_review_date ?: '-',
    );
}

/**
 * AJAX: Recalculate Partner Ratings
 */
function wheelfy_ajax_recalculate_partner_ratings() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_moderate_review')) {
        wp_send_json_error(array('message' => __('Security check failed.', 'wheelfy')));
    }
    
    // Check capability
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => __('Permission denied.', 'wheelfy')));
    }
    
    $partner_id = isset($_POST['partner_id']) ? intval($_POST['partner_id']) : 0;
    if ($partner_id <= 0) {
        wp_send_json_error(array('message' => __('Invalid partner ID.', 'wheelfy')));
    }
    
    $ratings_data = wheelfy_recalculate_partner_ratings($partner_id);
    
    if ($ratings_data !== false) {
        wp_send_json_success(array(
            'message' => __('Partner ratings recalculated successfully.', 'wheelfy'),
            'average_rating' => $ratings_data['average_rating'],
            'total_reviews' => $ratings_data['total_reviews'],
            'recent_review' => $ratings_data['recent_review'],
        ));
    } else {
        wp_send_json_error(array('message' => __('Failed to recalculate ratings.', 'wheelfy')));
    }
}
add_action('wp_ajax_wheelfy_recalculate_partner_ratings', 'wheelfy_ajax_recalculate_partner_ratings');
