<?php
/**
 * Admin Chat Moderation Page
 * 
 * @package Wheelfy
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!current_user_can('administrator')) {
    wp_die(__('You do not have permission to access this page.', 'wheelfy'));
}

// Dummy chat conversations
$dummy_conversations = array(
    array('id' => 1, 'customer' => 'John Doe', 'customer_id' => 101, 'partner' => 'Auto Service Ltd', 'partner_id' => 4, 'last_message' => 'Thank you for the excellent service! Everything was perfect.', 'messages' => 12, 'status' => 'active', 'last_activity' => '2025-01-25 14:30', 'started' => '2025-01-25 10:15', 'reported' => false),
    array('id' => 2, 'customer' => 'Jane Smith', 'customer_id' => 102, 'partner' => 'Car Care Center', 'partner_id' => 5, 'last_message' => 'When can you come to fix my brakes?', 'messages' => 8, 'status' => 'active', 'last_activity' => '2025-01-25 13:15', 'started' => '2025-01-25 12:00', 'reported' => false),
    array('id' => 3, 'customer' => 'Mike Johnson', 'customer_id' => 103, 'partner' => 'Quick Fix Garage', 'partner_id' => 6, 'last_message' => 'The price seems too high. Can you negotiate?', 'messages' => 15, 'status' => 'dispute', 'last_activity' => '2025-01-24 16:45', 'started' => '2025-01-24 14:20', 'reported' => true),
    array('id' => 4, 'customer' => 'Sarah Williams', 'customer_id' => 104, 'partner' => 'Pro Mechanics', 'partner_id' => 7, 'last_message' => 'Great, see you tomorrow at 10 AM', 'messages' => 5, 'status' => 'closed', 'last_activity' => '2025-01-23 10:20', 'started' => '2025-01-23 09:00', 'reported' => false),
    array('id' => 5, 'customer' => 'Tom Brown', 'customer_id' => 105, 'partner' => 'City Auto Shop', 'partner_id' => 8, 'last_message' => 'Can you provide a detailed quote?', 'messages' => 3, 'status' => 'active', 'last_activity' => '2025-01-25 15:00', 'started' => '2025-01-25 14:45', 'reported' => false),
    array('id' => 6, 'customer' => 'Emily Davis', 'customer_id' => 106, 'partner' => 'Express Auto Repair', 'partner_id' => 9, 'last_message' => 'Perfect! I\'ll book the appointment.', 'messages' => 7, 'status' => 'active', 'last_activity' => '2025-01-25 11:30', 'started' => '2025-01-25 10:00', 'reported' => false),
    array('id' => 7, 'customer' => 'Robert Wilson', 'customer_id' => 107, 'partner' => 'Auto Service Ltd', 'partner_id' => 4, 'last_message' => 'What warranty do you offer?', 'messages' => 9, 'status' => 'active', 'last_activity' => '2025-01-25 09:15', 'started' => '2025-01-24 16:00', 'reported' => false),
    array('id' => 8, 'customer' => 'Lisa Anderson', 'customer_id' => 108, 'partner' => 'Car Care Center', 'partner_id' => 5, 'last_message' => 'This is unacceptable! I want a refund!', 'messages' => 20, 'status' => 'dispute', 'last_activity' => '2025-01-24 18:30', 'started' => '2025-01-24 15:00', 'reported' => true),
    array('id' => 9, 'customer' => 'David Martinez', 'customer_id' => 109, 'partner' => 'Quick Fix Garage', 'partner_id' => 6, 'last_message' => 'Thanks for the quick response!', 'messages' => 4, 'status' => 'closed', 'last_activity' => '2025-01-22 17:00', 'started' => '2025-01-22 16:30', 'reported' => false),
    array('id' => 10, 'customer' => 'Jennifer Taylor', 'customer_id' => 110, 'partner' => 'Pro Mechanics', 'partner_id' => 7, 'last_message' => 'Do you accept credit cards?', 'messages' => 6, 'status' => 'active', 'last_activity' => '2025-01-25 12:45', 'started' => '2025-01-25 11:20', 'reported' => false),
    array('id' => 11, 'customer' => 'Michael White', 'customer_id' => 111, 'partner' => 'City Auto Shop', 'partner_id' => 8, 'last_message' => 'How long will the repair take?', 'messages' => 11, 'status' => 'active', 'last_activity' => '2025-01-25 08:30', 'started' => '2025-01-24 20:00', 'reported' => false),
    array('id' => 12, 'customer' => 'Amanda Harris', 'customer_id' => 112, 'partner' => 'Auto Service Ltd', 'partner_id' => 4, 'last_message' => 'You are a scam! I will report you!', 'messages' => 18, 'status' => 'dispute', 'last_activity' => '2025-01-24 19:15', 'started' => '2025-01-24 14:00', 'reported' => true),
    array('id' => 13, 'customer' => 'Christopher Lee', 'customer_id' => 113, 'partner' => 'Car Care Center', 'partner_id' => 5, 'last_message' => 'See you next week!', 'messages' => 5, 'status' => 'closed', 'last_activity' => '2025-01-21 15:30', 'started' => '2025-01-21 14:00', 'reported' => false),
    array('id' => 14, 'customer' => 'Michelle Clark', 'customer_id' => 114, 'partner' => 'Express Auto Repair', 'partner_id' => 9, 'last_message' => 'Can I get a discount?', 'messages' => 8, 'status' => 'active', 'last_activity' => '2025-01-25 10:20', 'started' => '2025-01-25 09:00', 'reported' => false),
    array('id' => 15, 'customer' => 'James Lewis', 'customer_id' => 115, 'partner' => 'Quick Fix Garage', 'partner_id' => 6, 'last_message' => 'Thank you so much!', 'messages' => 6, 'status' => 'closed', 'last_activity' => '2025-01-20 16:00', 'started' => '2025-01-20 13:30', 'reported' => false),
    array('id' => 16, 'customer' => 'Patricia Walker', 'customer_id' => 116, 'partner' => 'Pro Mechanics', 'partner_id' => 7, 'last_message' => 'What is your availability?', 'messages' => 7, 'status' => 'active', 'last_activity' => '2025-01-25 07:45', 'started' => '2025-01-24 18:00', 'reported' => false),
    array('id' => 17, 'customer' => 'Daniel Hall', 'customer_id' => 117, 'partner' => 'City Auto Shop', 'partner_id' => 8, 'last_message' => 'I need urgent help!', 'messages' => 10, 'status' => 'active', 'last_activity' => '2025-01-25 06:30', 'started' => '2025-01-25 05:00', 'reported' => false),
    array('id' => 18, 'customer' => 'Nancy Allen', 'customer_id' => 118, 'partner' => 'Auto Service Ltd', 'partner_id' => 4, 'last_message' => 'Perfect timing!', 'messages' => 4, 'status' => 'closed', 'last_activity' => '2025-01-19 12:00', 'started' => '2025-01-19 11:00', 'reported' => false),
    array('id' => 19, 'customer' => 'Mark Young', 'customer_id' => 119, 'partner' => 'Car Care Center', 'partner_id' => 5, 'last_message' => 'This is ridiculous!', 'messages' => 14, 'status' => 'dispute', 'last_activity' => '2025-01-23 20:00', 'started' => '2025-01-23 16:00', 'reported' => true),
    array('id' => 20, 'customer' => 'Susan King', 'customer_id' => 120, 'partner' => 'Express Auto Repair', 'partner_id' => 9, 'last_message' => 'Great service, highly recommended!', 'messages' => 3, 'status' => 'closed', 'last_activity' => '2025-01-18 14:00', 'started' => '2025-01-18 13:30', 'reported' => false),
);

// Dummy blocked users
$dummy_blocked = array(
    array('id' => 1, 'user' => 'John Doe', 'user_id' => 101, 'user_type' => 'customer', 'reason' => 'Abusive Language', 'blocked_date' => '2025-01-20', 'blocked_by' => 'Admin', 'status' => 'active'),
    array('id' => 2, 'user' => 'Mike Johnson', 'user_id' => 103, 'user_type' => 'customer', 'reason' => 'Spam Messages', 'blocked_date' => '2025-01-18', 'blocked_by' => 'Admin', 'status' => 'active'),
    array('id' => 3, 'user' => 'Lisa Anderson', 'user_id' => 108, 'user_type' => 'customer', 'reason' => 'Harassment', 'blocked_date' => '2025-01-24', 'blocked_by' => 'Admin', 'status' => 'active'),
    array('id' => 4, 'user' => 'Amanda Harris', 'user_id' => 112, 'user_type' => 'customer', 'reason' => 'Threatening Behavior', 'blocked_date' => '2025-01-24', 'blocked_by' => 'Admin', 'status' => 'active'),
    array('id' => 5, 'user' => 'Mark Young', 'user_id' => 119, 'user_type' => 'customer', 'reason' => 'Inappropriate Content', 'blocked_date' => '2025-01-23', 'blocked_by' => 'Admin', 'status' => 'active'),
    array('id' => 6, 'user' => 'Scam Auto Shop', 'user_id' => 201, 'user_type' => 'partner', 'reason' => 'Fraudulent Activity', 'blocked_date' => '2025-01-15', 'blocked_by' => 'Admin', 'status' => 'active'),
);

// Dummy reported messages
$dummy_reported = array(
    array('id' => 1, 'conversation_id' => 3, 'customer' => 'Mike Johnson', 'partner' => 'Quick Fix Garage', 'message' => 'You are cheating me! This is fraud!', 'reported_by' => 'partner', 'reported_date' => '2025-01-24 16:30', 'status' => 'pending', 'reason' => 'Abusive Language'),
    array('id' => 2, 'conversation_id' => 8, 'customer' => 'Lisa Anderson', 'partner' => 'Car Care Center', 'message' => 'This is unacceptable! I want a refund!', 'reported_by' => 'partner', 'reported_date' => '2025-01-24 18:15', 'status' => 'pending', 'reason' => 'Threatening Behavior'),
    array('id' => 3, 'conversation_id' => 12, 'customer' => 'Amanda Harris', 'partner' => 'Auto Service Ltd', 'message' => 'You are a scam! I will report you!', 'reported_by' => 'partner', 'reported_date' => '2025-01-24 19:00', 'status' => 'reviewed', 'reason' => 'Abusive Language'),
    array('id' => 4, 'conversation_id' => 19, 'customer' => 'Mark Young', 'partner' => 'Car Care Center', 'message' => 'This is ridiculous! You ruined my car!', 'reported_by' => 'partner', 'reported_date' => '2025-01-23 20:15', 'status' => 'pending', 'reason' => 'False Accusations'),
    array('id' => 5, 'conversation_id' => 3, 'customer' => 'Mike Johnson', 'partner' => 'Quick Fix Garage', 'message' => 'I will leave negative reviews everywhere!', 'reported_by' => 'partner', 'reported_date' => '2025-01-24 17:00', 'status' => 'dismissed', 'reason' => 'Threatening Behavior'),
    array('id' => 6, 'conversation_id' => 8, 'customer' => 'Lisa Anderson', 'partner' => 'Car Care Center', 'message' => 'You better refund me or else!', 'reported_by' => 'partner', 'reported_date' => '2025-01-24 18:30', 'status' => 'pending', 'reason' => 'Threatening Behavior'),
);

// Dummy warnings
$dummy_warnings = array(
    array('id' => 1, 'user' => 'John Doe', 'user_id' => 101, 'user_type' => 'customer', 'type' => 'Abusive Language', 'date' => '2025-01-20', 'status' => 'active', 'warnings_count' => 2),
    array('id' => 2, 'user' => 'Mike Johnson', 'user_id' => 103, 'user_type' => 'customer', 'type' => 'Spam Messages', 'date' => '2025-01-18', 'status' => 'resolved', 'warnings_count' => 1),
    array('id' => 3, 'user' => 'Lisa Anderson', 'user_id' => 108, 'user_type' => 'customer', 'type' => 'Harassment', 'date' => '2025-01-24', 'status' => 'active', 'warnings_count' => 3),
    array('id' => 4, 'user' => 'Amanda Harris', 'user_id' => 112, 'user_type' => 'customer', 'type' => 'Threatening Behavior', 'date' => '2025-01-24', 'status' => 'active', 'warnings_count' => 2),
    array('id' => 5, 'user' => 'Mark Young', 'user_id' => 119, 'user_type' => 'customer', 'type' => 'Inappropriate Content', 'date' => '2025-01-23', 'status' => 'active', 'warnings_count' => 1),
);

// Calculate statistics
$total_conversations = count($dummy_conversations);
$active_conversations = count(array_filter($dummy_conversations, function($c) { return $c['status'] === 'active'; }));
$dispute_conversations = count(array_filter($dummy_conversations, function($c) { return $c['status'] === 'dispute'; }));
$closed_conversations = count(array_filter($dummy_conversations, function($c) { return $c['status'] === 'closed'; }));
$reported_conversations = count(array_filter($dummy_conversations, function($c) { return $c['reported'] === true; }));
$total_messages = array_sum(array_column($dummy_conversations, 'messages'));
$blocked_users = count($dummy_blocked);
$pending_reports = count(array_filter($dummy_reported, function($r) { return $r['status'] === 'pending'; }));

// Get blocked contact info statistics
$blocked_stats = array('total' => 0, 'today' => 0, 'this_week' => 0);
if (class_exists('Wheelfy_Chat_Security')) {
    $security = Wheelfy_Chat_Security::get_instance();
    $blocked_stats = $security->get_blocked_statistics();
}

$current_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'all';
if (!in_array($current_tab, array('all', 'active', 'blocked', 'reported', 'history', 'warnings', 'contact-blocked'))) {
    $current_tab = 'all';
}
?>
<div class="wrap wheelfy-admin-chat">
    <!-- Header -->
    <div class="wheelfy-admin-header">
        <div>
            <h1 class="wp-heading-inline"><?php _e('Chat Moderation', 'wheelfy'); ?></h1>
            <p class="description"><?php _e('Monitor conversations, moderate content, and manage user access', 'wheelfy'); ?></p>
        </div>
    </div>
    <hr class="wp-header-end">

    <!-- KPI Cards -->
    <div class="wheelfy-kpi-grid">
        <div class="wheelfy-kpi-card">
            <div class="kpi-icon" style="background: #e3f2fd; color: #1976d2;">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
                </svg>
            </div>
            <div class="kpi-content">
                <div class="kpi-label"><?php _e('Total Conversations', 'wheelfy'); ?></div>
                <div class="kpi-value"><?php echo number_format($total_conversations); ?></div>
            </div>
        </div>

        <div class="wheelfy-kpi-card">
            <div class="kpi-icon" style="background: #e8f5e9; color: #388e3c;">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="12" cy="12" r="10"></circle>
                    <path d="M12 6v6l4 2"></path>
                </svg>
            </div>
            <div class="kpi-content">
                <div class="kpi-label"><?php _e('Active Chats', 'wheelfy'); ?></div>
                <div class="kpi-value"><?php echo number_format($active_conversations); ?></div>
            </div>
        </div>

        <div class="wheelfy-kpi-card">
            <div class="kpi-icon" style="background: #fff3cd; color: #856404;">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path>
                    <line x1="12" y1="9" x2="12" y2="13"></line>
                    <line x1="12" y1="17" x2="12.01" y2="17"></line>
                </svg>
            </div>
            <div class="kpi-content">
                <div class="kpi-label"><?php _e('Disputes', 'wheelfy'); ?></div>
                <div class="kpi-value"><?php echo number_format($dispute_conversations); ?></div>
            </div>
        </div>

        <div class="wheelfy-kpi-card">
            <div class="kpi-icon" style="background: #ffebee; color: #c62828;">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"></path>
                    <line x1="4" y1="22" x2="4" y2="15"></line>
                </svg>
            </div>
            <div class="kpi-content">
                <div class="kpi-label"><?php _e('Reported Messages', 'wheelfy'); ?></div>
                <div class="kpi-value"><?php echo number_format($pending_reports); ?></div>
            </div>
        </div>

        <div class="wheelfy-kpi-card">
            <div class="kpi-icon" style="background: #fce4ec; color: #c2185b;">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M18.36 6.64a9 9 0 1 1-12.73 0"></path>
                    <line x1="12" y1="2" x2="12" y2="12"></line>
                </svg>
            </div>
            <div class="kpi-content">
                <div class="kpi-label"><?php _e('Contact Info Blocked', 'wheelfy'); ?></div>
                <div class="kpi-value"><?php echo number_format($blocked_stats['total']); ?></div>
            </div>
        </div>
    </div>

    <!-- Tabs Navigation -->
    <nav class="nav-tab-wrapper wheelfy-subscription-tabs">
        <a href="<?php echo esc_url(add_query_arg('tab', 'all', admin_url('admin.php?page=wheelfy-chat'))); ?>" 
           class="nav-tab <?php echo $current_tab === 'all' ? 'nav-tab-active' : ''; ?>" 
           data-tab="all">
            <?php _e('All Chats', 'wheelfy'); ?>
        </a>
        <a href="<?php echo esc_url(add_query_arg('tab', 'active', admin_url('admin.php?page=wheelfy-chat'))); ?>" 
           class="nav-tab <?php echo $current_tab === 'active' ? 'nav-tab-active' : ''; ?>" 
           data-tab="active">
            <?php _e('Active Conversations', 'wheelfy'); ?>
        </a>
        <a href="<?php echo esc_url(add_query_arg('tab', 'blocked', admin_url('admin.php?page=wheelfy-chat'))); ?>" 
           class="nav-tab <?php echo $current_tab === 'blocked' ? 'nav-tab-active' : ''; ?>" 
           data-tab="blocked">
            <?php _e('Blocked Users', 'wheelfy'); ?>
        </a>
        <a href="<?php echo esc_url(add_query_arg('tab', 'reported', admin_url('admin.php?page=wheelfy-chat'))); ?>" 
           class="nav-tab <?php echo $current_tab === 'reported' ? 'nav-tab-active' : ''; ?>" 
           data-tab="reported">
            <?php _e('Reported Messages', 'wheelfy'); ?>
        </a>
        <a href="<?php echo esc_url(add_query_arg('tab', 'history', admin_url('admin.php?page=wheelfy-chat'))); ?>" 
           class="nav-tab <?php echo $current_tab === 'history' ? 'nav-tab-active' : ''; ?>" 
           data-tab="history">
            <?php _e('Chat History', 'wheelfy'); ?>
        </a>
        <a href="<?php echo esc_url(add_query_arg('tab', 'warnings', admin_url('admin.php?page=wheelfy-chat'))); ?>" 
           class="nav-tab <?php echo $current_tab === 'warnings' ? 'nav-tab-active' : ''; ?>" 
           data-tab="warnings">
            <?php _e('User Warnings', 'wheelfy'); ?>
        </a>
        <a href="<?php echo esc_url(add_query_arg('tab', 'contact-blocked', admin_url('admin.php?page=wheelfy-chat'))); ?>" 
           class="nav-tab <?php echo $current_tab === 'contact-blocked' ? 'nav-tab-active' : ''; ?>" 
           data-tab="contact-blocked">
            <?php _e('Contact Info Blocked', 'wheelfy'); ?>
            <?php if ($blocked_stats['today'] > 0) : ?>
                <span class="badge-new" style="background:#c2185b;color:#fff;padding:2px 6px;border-radius:10px;font-size:11px;margin-left:4px;"><?php echo $blocked_stats['today']; ?></span>
            <?php endif; ?>
        </a>
    </nav>

    <!-- All Chats Tab -->
    <div class="wheelfy-tab-content <?php echo $current_tab === 'all' ? 'active' : ''; ?>" id="tab-all">
        <div class="wheelfy-dashboard-card">
            <div class="card-header">
                <div>
                    <h2><?php _e('All Chats', 'wheelfy'); ?></h2>
                    <p class="card-description"><?php _e('View and monitor all chat conversations', 'wheelfy'); ?></p>
                </div>
                <div class="header-filters">
                    <input type="text" id="search-all-chats" class="search-input" placeholder="<?php esc_attr_e('Search conversations...', 'wheelfy'); ?>">
                    <select id="filter-status-all" class="filter-select">
                        <option value="all"><?php _e('All Status', 'wheelfy'); ?></option>
                        <option value="active"><?php _e('Active', 'wheelfy'); ?></option>
                        <option value="dispute"><?php _e('Dispute', 'wheelfy'); ?></option>
                        <option value="closed"><?php _e('Closed', 'wheelfy'); ?></option>
                    </select>
                </div>
            </div>
            <div class="card-body">
                <table class="wp-list-table widefat fixed striped table-view-list">
                    <thead>
                        <tr>
                            <th class="column-id"><?php _e('#', 'wheelfy'); ?></th>
                            <th class="column-customer"><?php _e('Customer', 'wheelfy'); ?></th>
                            <th class="column-partner"><?php _e('Partner', 'wheelfy'); ?></th>
                            <th class="column-message"><?php _e('Last Message', 'wheelfy'); ?></th>
                            <th class="column-messages"><?php _e('Messages', 'wheelfy'); ?></th>
                            <th class="column-status"><?php _e('Status', 'wheelfy'); ?></th>
                            <th class="column-activity"><?php _e('Last Activity', 'wheelfy'); ?></th>
                            <th class="column-actions"><?php _e('Actions', 'wheelfy'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $chat_count = 0;
                        foreach ($dummy_conversations as $conv) : 
                            $chat_count++;
                        ?>
                            <tr>
                                <td class="column-id"><?php echo $chat_count; ?></td>
                                <td class="column-customer"><strong><?php echo esc_html($conv['customer']); ?></strong></td>
                                <td class="column-partner"><?php echo esc_html($conv['partner']); ?></td>
                                <td class="column-message"><?php echo esc_html(substr($conv['last_message'], 0, 50)) . (strlen($conv['last_message']) > 50 ? '...' : ''); ?></td>
                                <td class="column-messages"><?php echo $conv['messages']; ?></td>
                                <td class="column-status">
                                    <span class="status-badge status-<?php echo esc_attr($conv['status']); ?>">
                                        <?php echo esc_html(ucfirst($conv['status'])); ?>
                                    </span>
                                    <?php if ($conv['reported']) : ?>
                                        <span class="dashicons dashicons-flag reported-flag" title="<?php esc_attr_e('Reported', 'wheelfy'); ?>"></span>
                                    <?php endif; ?>
                                </td>
                                <td class="column-activity"><?php echo esc_html($conv['last_activity']); ?></td>
                                <td class="column-actions">
                                    <div class="row-actions">
                                        <a href="javascript:void(0);" class="button button-small"><?php _e('View Chat', 'wheelfy'); ?></a>
                                        <?php if ($conv['status'] === 'dispute') : ?>
                                            <a href="javascript:void(0);" class="button button-small" style="background: #dc3232; color: white;"><?php _e('Review Dispute', 'wheelfy'); ?></a>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Active Conversations Tab -->
    <div class="wheelfy-tab-content <?php echo $current_tab === 'active' ? 'active' : ''; ?>" id="tab-active">
        <div class="wheelfy-dashboard-card">
            <div class="card-header">
                <div>
                    <h2><?php _e('Active Conversations', 'wheelfy'); ?></h2>
                    <p class="card-description"><?php _e('Currently ongoing chat conversations', 'wheelfy'); ?></p>
                </div>
                <div class="header-filters">
                    <input type="text" id="search-active" class="search-input" placeholder="<?php esc_attr_e('Search conversations...', 'wheelfy'); ?>">
                </div>
            </div>
            <div class="card-body">
                <table class="wp-list-table widefat fixed striped table-view-list">
                    <thead>
                        <tr>
                            <th class="column-id"><?php _e('#', 'wheelfy'); ?></th>
                            <th class="column-customer"><?php _e('Customer', 'wheelfy'); ?></th>
                            <th class="column-partner"><?php _e('Partner', 'wheelfy'); ?></th>
                            <th class="column-message"><?php _e('Last Message', 'wheelfy'); ?></th>
                            <th class="column-messages"><?php _e('Messages', 'wheelfy'); ?></th>
                            <th class="column-activity"><?php _e('Last Activity', 'wheelfy'); ?></th>
                            <th class="column-actions"><?php _e('Actions', 'wheelfy'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $active_count = 0;
                        $active_conversations_list = array_filter($dummy_conversations, function($c) { return $c['status'] === 'active'; });
                        foreach ($active_conversations_list as $conv) : 
                            $active_count++;
                        ?>
                            <tr>
                                <td class="column-id"><?php echo $active_count; ?></td>
                                <td class="column-customer"><strong><?php echo esc_html($conv['customer']); ?></strong></td>
                                <td class="column-partner"><?php echo esc_html($conv['partner']); ?></td>
                                <td class="column-message"><?php echo esc_html(substr($conv['last_message'], 0, 50)) . (strlen($conv['last_message']) > 50 ? '...' : ''); ?></td>
                                <td class="column-messages"><?php echo $conv['messages']; ?></td>
                                <td class="column-activity"><?php echo esc_html($conv['last_activity']); ?></td>
                                <td class="column-actions">
                                    <div class="row-actions">
                                        <a href="javascript:void(0);" class="button button-small"><?php _e('View Chat', 'wheelfy'); ?></a>
                                        <a href="javascript:void(0);" class="button button-small"><?php _e('Monitor', 'wheelfy'); ?></a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        <?php if (empty($active_conversations_list)) : ?>
                            <tr>
                                <td colspan="7" style="text-align: center; padding: 40px;">
                                    <?php _e('No active conversations found.', 'wheelfy'); ?>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Blocked Users Tab -->
    <div class="wheelfy-tab-content <?php echo $current_tab === 'blocked' ? 'active' : ''; ?>" id="tab-blocked">
        <div class="wheelfy-dashboard-card">
            <div class="card-header">
                <div>
                    <h2><?php _e('Blocked Users', 'wheelfy'); ?></h2>
                    <p class="card-description"><?php _e('Users who have been blocked from using the chat system', 'wheelfy'); ?></p>
                </div>
                <div class="header-filters">
                    <input type="text" id="search-blocked" class="search-input" placeholder="<?php esc_attr_e('Search users...', 'wheelfy'); ?>">
                    <button class="button button-primary" id="block-user-btn"><?php _e('Block User', 'wheelfy'); ?></button>
                </div>
            </div>
            <div class="card-body">
                <table class="wp-list-table widefat fixed striped table-view-list">
                    <thead>
                        <tr>
                            <th class="column-id"><?php _e('#', 'wheelfy'); ?></th>
                            <th class="column-user"><?php _e('User', 'wheelfy'); ?></th>
                            <th class="column-type"><?php _e('User Type', 'wheelfy'); ?></th>
                            <th class="column-reason"><?php _e('Reason', 'wheelfy'); ?></th>
                            <th class="column-date"><?php _e('Blocked Date', 'wheelfy'); ?></th>
                            <th class="column-blocked-by"><?php _e('Blocked By', 'wheelfy'); ?></th>
                            <th class="column-status"><?php _e('Status', 'wheelfy'); ?></th>
                            <th class="column-actions"><?php _e('Actions', 'wheelfy'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $blocked_count = 0;
                        foreach ($dummy_blocked as $blocked) : 
                            $blocked_count++;
                        ?>
                            <tr>
                                <td class="column-id"><?php echo $blocked_count; ?></td>
                                <td class="column-user"><strong><?php echo esc_html($blocked['user']); ?></strong></td>
                                <td class="column-type">
                                    <span class="status-badge status-<?php echo esc_attr($blocked['user_type']); ?>">
                                        <?php echo esc_html(ucfirst($blocked['user_type'])); ?>
                                    </span>
                                </td>
                                <td class="column-reason"><?php echo esc_html($blocked['reason']); ?></td>
                                <td class="column-date"><?php echo esc_html($blocked['blocked_date']); ?></td>
                                <td class="column-blocked-by"><?php echo esc_html($blocked['blocked_by']); ?></td>
                                <td class="column-status">
                                    <span class="status-badge status-<?php echo esc_attr($blocked['status']); ?>">
                                        <?php echo esc_html(ucfirst($blocked['status'])); ?>
                                    </span>
                                </td>
                                <td class="column-actions">
                                    <div class="row-actions">
                                        <a href="javascript:void(0);" class="button button-small"><?php _e('View Details', 'wheelfy'); ?></a>
                                        <a href="javascript:void(0);" class="button button-small button-primary"><?php _e('Unblock', 'wheelfy'); ?></a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Reported Messages Tab -->
    <div class="wheelfy-tab-content <?php echo $current_tab === 'reported' ? 'active' : ''; ?>" id="tab-reported">
        <div class="wheelfy-dashboard-card">
            <div class="card-header">
                <div>
                    <h2><?php _e('Reported Messages', 'wheelfy'); ?></h2>
                    <p class="card-description"><?php _e('Messages that have been flagged for review', 'wheelfy'); ?></p>
                </div>
                <div class="header-filters">
                    <input type="text" id="search-reported" class="search-input" placeholder="<?php esc_attr_e('Search reports...', 'wheelfy'); ?>">
                    <select id="filter-report-status" class="filter-select">
                        <option value="all"><?php _e('All Status', 'wheelfy'); ?></option>
                        <option value="pending"><?php _e('Pending', 'wheelfy'); ?></option>
                        <option value="reviewed"><?php _e('Reviewed', 'wheelfy'); ?></option>
                        <option value="dismissed"><?php _e('Dismissed', 'wheelfy'); ?></option>
                    </select>
                </div>
            </div>
            <div class="card-body">
                <table class="wp-list-table widefat fixed striped table-view-list">
                    <thead>
                        <tr>
                            <th class="column-id"><?php _e('#', 'wheelfy'); ?></th>
                            <th class="column-conversation"><?php _e('Conversation', 'wheelfy'); ?></th>
                            <th class="column-message"><?php _e('Reported Message', 'wheelfy'); ?></th>
                            <th class="column-reason"><?php _e('Reason', 'wheelfy'); ?></th>
                            <th class="column-reported-by"><?php _e('Reported By', 'wheelfy'); ?></th>
                            <th class="column-date"><?php _e('Reported Date', 'wheelfy'); ?></th>
                            <th class="column-status"><?php _e('Status', 'wheelfy'); ?></th>
                            <th class="column-actions"><?php _e('Actions', 'wheelfy'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $reported_count = 0;
                        foreach ($dummy_reported as $report) : 
                            $reported_count++;
                        ?>
                            <tr>
                                <td class="column-id"><?php echo $reported_count; ?></td>
                                <td class="column-conversation">
                                    <strong><?php echo esc_html($report['customer']); ?></strong><br>
                                    <small><?php echo esc_html($report['partner']); ?></small>
                                </td>
                                <td class="column-message"><?php echo esc_html($report['message']); ?></td>
                                <td class="column-reason"><?php echo esc_html($report['reason']); ?></td>
                                <td class="column-reported-by">
                                    <span class="status-badge status-<?php echo esc_attr($report['reported_by']); ?>">
                                        <?php echo esc_html(ucfirst($report['reported_by'])); ?>
                                    </span>
                                </td>
                                <td class="column-date"><?php echo esc_html($report['reported_date']); ?></td>
                                <td class="column-status">
                                    <span class="status-badge status-<?php echo esc_attr($report['status']); ?>">
                                        <?php echo esc_html(ucfirst($report['status'])); ?>
                                    </span>
                                </td>
                                <td class="column-actions">
                                    <div class="row-actions">
                                        <a href="javascript:void(0);" class="button button-small"><?php _e('View Context', 'wheelfy'); ?></a>
                                        <?php if ($report['status'] === 'pending') : ?>
                                            <a href="javascript:void(0);" class="button button-small button-primary"><?php _e('Review', 'wheelfy'); ?></a>
                                            <a href="javascript:void(0);" class="button button-small"><?php _e('Dismiss', 'wheelfy'); ?></a>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Chat History Tab -->
    <div class="wheelfy-tab-content <?php echo $current_tab === 'history' ? 'active' : ''; ?>" id="tab-history">
        <div class="wheelfy-dashboard-card">
            <div class="card-header">
                <div>
                    <h2><?php _e('Chat History', 'wheelfy'); ?></h2>
                    <p class="card-description"><?php _e('Archive of completed and closed conversations', 'wheelfy'); ?></p>
                </div>
                <div class="header-filters">
                    <input type="text" id="search-history" class="search-input" placeholder="<?php esc_attr_e('Search history...', 'wheelfy'); ?>">
                    <select id="filter-history-status" class="filter-select">
                        <option value="all"><?php _e('All Status', 'wheelfy'); ?></option>
                        <option value="closed"><?php _e('Closed', 'wheelfy'); ?></option>
                        <option value="dispute"><?php _e('Dispute', 'wheelfy'); ?></option>
                    </select>
                </div>
            </div>
            <div class="card-body">
                <table class="wp-list-table widefat fixed striped table-view-list">
                    <thead>
                        <tr>
                            <th class="column-id"><?php _e('#', 'wheelfy'); ?></th>
                            <th class="column-customer"><?php _e('Customer', 'wheelfy'); ?></th>
                            <th class="column-partner"><?php _e('Partner', 'wheelfy'); ?></th>
                            <th class="column-message"><?php _e('Last Message', 'wheelfy'); ?></th>
                            <th class="column-messages"><?php _e('Messages', 'wheelfy'); ?></th>
                            <th class="column-status"><?php _e('Status', 'wheelfy'); ?></th>
                            <th class="column-activity"><?php _e('Last Activity', 'wheelfy'); ?></th>
                            <th class="column-actions"><?php _e('Actions', 'wheelfy'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $history_count = 0;
                        $history_conversations = array_filter($dummy_conversations, function($c) { return $c['status'] === 'closed' || $c['status'] === 'dispute'; });
                        foreach ($history_conversations as $conv) : 
                            $history_count++;
                        ?>
                            <tr>
                                <td class="column-id"><?php echo $history_count; ?></td>
                                <td class="column-customer"><strong><?php echo esc_html($conv['customer']); ?></strong></td>
                                <td class="column-partner"><?php echo esc_html($conv['partner']); ?></td>
                                <td class="column-message"><?php echo esc_html(substr($conv['last_message'], 0, 50)) . (strlen($conv['last_message']) > 50 ? '...' : ''); ?></td>
                                <td class="column-messages"><?php echo $conv['messages']; ?></td>
                                <td class="column-status">
                                    <span class="status-badge status-<?php echo esc_attr($conv['status']); ?>">
                                        <?php echo esc_html(ucfirst($conv['status'])); ?>
                                    </span>
                                </td>
                                <td class="column-activity"><?php echo esc_html($conv['last_activity']); ?></td>
                                <td class="column-actions">
                                    <div class="row-actions">
                                        <a href="javascript:void(0);" class="button button-small"><?php _e('View Chat', 'wheelfy'); ?></a>
                                        <a href="javascript:void(0);" class="button button-small"><?php _e('Export', 'wheelfy'); ?></a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- User Warnings Tab -->
    <div class="wheelfy-tab-content <?php echo $current_tab === 'warnings' ? 'active' : ''; ?>" id="tab-warnings">
        <div class="wheelfy-dashboard-card">
            <div class="card-header">
                <div>
                    <h2><?php _e('User Warnings', 'wheelfy'); ?></h2>
                    <p class="card-description"><?php _e('Track warnings issued to users for inappropriate behavior', 'wheelfy'); ?></p>
                </div>
                <div class="header-filters">
                    <input type="text" id="search-warnings" class="search-input" placeholder="<?php esc_attr_e('Search users...', 'wheelfy'); ?>">
                    <button class="button button-primary" id="issue-warning-btn"><?php _e('Issue Warning', 'wheelfy'); ?></button>
                </div>
            </div>
            <div class="card-body">
                <table class="wp-list-table widefat fixed striped table-view-list">
                    <thead>
                        <tr>
                            <th class="column-id"><?php _e('#', 'wheelfy'); ?></th>
                            <th class="column-user"><?php _e('User', 'wheelfy'); ?></th>
                            <th class="column-type"><?php _e('User Type', 'wheelfy'); ?></th>
                            <th class="column-warning-type"><?php _e('Warning Type', 'wheelfy'); ?></th>
                            <th class="column-warnings"><?php _e('Warnings', 'wheelfy'); ?></th>
                            <th class="column-date"><?php _e('Date', 'wheelfy'); ?></th>
                            <th class="column-status"><?php _e('Status', 'wheelfy'); ?></th>
                            <th class="column-actions"><?php _e('Actions', 'wheelfy'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $warning_count = 0;
                        foreach ($dummy_warnings as $warning) : 
                            $warning_count++;
                        ?>
                            <tr>
                                <td class="column-id"><?php echo $warning_count; ?></td>
                                <td class="column-user"><strong><?php echo esc_html($warning['user']); ?></strong></td>
                                <td class="column-type">
                                    <span class="status-badge status-<?php echo esc_attr($warning['user_type']); ?>">
                                        <?php echo esc_html(ucfirst($warning['user_type'])); ?>
                                    </span>
                                </td>
                                <td class="column-warning-type"><?php echo esc_html($warning['type']); ?></td>
                                <td class="column-warnings">
                                    <span class="badge-count"><?php echo $warning['warnings_count']; ?></span>
                                </td>
                                <td class="column-date"><?php echo esc_html($warning['date']); ?></td>
                                <td class="column-status">
                                    <span class="status-badge status-<?php echo esc_attr($warning['status']); ?>">
                                        <?php echo esc_html(ucfirst($warning['status'])); ?>
                                    </span>
                                </td>
                                <td class="column-actions">
                                    <div class="row-actions">
                                        <a href="javascript:void(0);" class="button button-small"><?php _e('View Details', 'wheelfy'); ?></a>
                                        <a href="javascript:void(0);" class="button button-small"><?php _e('Issue Warning', 'wheelfy'); ?></a>
                                        <a href="javascript:void(0);" class="button button-small button-link-delete"><?php _e('Block User', 'wheelfy'); ?></a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Contact Info Blocked Tab -->
    <div class="wheelfy-tab-content <?php echo $current_tab === 'contact-blocked' ? 'active' : ''; ?>" id="tab-contact-blocked">
        <div class="wheelfy-dashboard-card">
            <div class="card-header">
                <div>
                    <h2><?php _e('Contact Information Blocked', 'wheelfy'); ?></h2>
                    <p class="card-description"><?php _e('Messages blocked for containing email, phone, or social media information', 'wheelfy'); ?></p>
                </div>
                <div class="header-filters">
                    <input type="text" id="search-contact-blocked" class="search-input" placeholder="<?php esc_attr_e('Search blocked messages...', 'wheelfy'); ?>">
                    <select id="filter-contact-type" class="filter-select">
                        <option value="all"><?php _e('All Types', 'wheelfy'); ?></option>
                        <option value="email"><?php _e('Email', 'wheelfy'); ?></option>
                        <option value="phone"><?php _e('Phone', 'wheelfy'); ?></option>
                        <option value="social"><?php _e('Social Media', 'wheelfy'); ?></option>
                    </select>
                </div>
            </div>
            <div class="card-body">
                <!-- Statistics Summary -->
                <div class="blocked-stats-summary" style="display:flex;gap:1.5rem;margin-bottom:1.5rem;flex-wrap:wrap;">
                    <div style="background:#f8f9fa;padding:1rem 1.5rem;border-radius:8px;text-align:center;flex:1;min-width:150px;">
                        <div style="font-size:2rem;font-weight:700;color:#c2185b;"><?php echo number_format($blocked_stats['total']); ?></div>
                        <div style="font-size:0.875rem;color:#666;"><?php _e('Total Blocked', 'wheelfy'); ?></div>
                    </div>
                    <div style="background:#f8f9fa;padding:1rem 1.5rem;border-radius:8px;text-align:center;flex:1;min-width:150px;">
                        <div style="font-size:2rem;font-weight:700;color:#1976d2;"><?php echo number_format($blocked_stats['today']); ?></div>
                        <div style="font-size:0.875rem;color:#666;"><?php _e('Today', 'wheelfy'); ?></div>
                    </div>
                    <div style="background:#f8f9fa;padding:1rem 1.5rem;border-radius:8px;text-align:center;flex:1;min-width:150px;">
                        <div style="font-size:2rem;font-weight:700;color:#388e3c;"><?php echo number_format($blocked_stats['this_week']); ?></div>
                        <div style="font-size:0.875rem;color:#666;"><?php _e('This Week', 'wheelfy'); ?></div>
                    </div>
                    <div style="background:#f8f9fa;padding:1rem 1.5rem;border-radius:8px;text-align:center;flex:1;min-width:150px;">
                        <div style="font-size:2rem;font-weight:700;color:#f57c00;"><?php echo number_format($blocked_stats['this_month']); ?></div>
                        <div style="font-size:0.875rem;color:#666;"><?php _e('This Month', 'wheelfy'); ?></div>
                    </div>
                </div>

                <!-- By Type Breakdown -->
                <?php if (!empty($blocked_stats['by_type'])) : ?>
                <div style="margin-bottom:1.5rem;">
                    <h4 style="margin:0 0 0.75rem;font-size:0.875rem;color:#666;"><?php _e('By Type:', 'wheelfy'); ?></h4>
                    <div style="display:flex;gap:1rem;flex-wrap:wrap;">
                        <?php foreach ($blocked_stats['by_type'] as $type => $count) : ?>
                            <span class="status-badge status-<?php echo esc_attr($type); ?>" style="padding:6px 12px;">
                                <?php echo esc_html(ucfirst($type)); ?>: <?php echo number_format($count); ?>
                            </span>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>

                <table class="wp-list-table widefat fixed striped table-view-list">
                    <thead>
                        <tr>
                            <th class="column-id"><?php _e('#', 'wheelfy'); ?></th>
                            <th class="column-user"><?php _e('User', 'wheelfy'); ?></th>
                            <th class="column-thread"><?php _e('Thread', 'wheelfy'); ?></th>
                            <th class="column-message"><?php _e('Blocked Message', 'wheelfy'); ?></th>
                            <th class="column-type"><?php _e('Pattern Type', 'wheelfy'); ?></th>
                            <th class="column-detected"><?php _e('Detected Content', 'wheelfy'); ?></th>
                            <th class="column-date"><?php _e('Blocked At', 'wheelfy'); ?></th>
                            <th class="column-actions"><?php _e('Actions', 'wheelfy'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $blocked_attempts = array();
                        if (class_exists('Wheelfy_Chat_Security')) {
                            $security = Wheelfy_Chat_Security::get_instance();
                            $blocked_attempts = $security->get_blocked_attempts(array('limit' => 50));
                        }
                        
                        if (!empty($blocked_attempts)) :
                            $block_count = 0;
                            foreach ($blocked_attempts as $attempt) : 
                                $block_count++;
                                $user = get_user_by('ID', $attempt->user_id);
                                $user_name = $user ? $user->display_name : __('Unknown User', 'wheelfy');
                                $user_role = $user ? implode(', ', $user->roles) : '';
                        ?>
                            <tr data-type="<?php echo esc_attr($attempt->detected_pattern); ?>">
                                <td class="column-id"><?php echo $block_count; ?></td>
                                <td class="column-user">
                                    <strong><?php echo esc_html($user_name); ?></strong>
                                    <br><small class="text-muted"><?php echo esc_html(ucfirst($user_role)); ?></small>
                                </td>
                                <td class="column-thread">
                                    <code style="font-size:0.75rem;background:#f0f0f0;padding:2px 6px;border-radius:3px;"><?php echo esc_html(substr($attempt->thread_id, 0, 20)); ?></code>
                                </td>
                                <td class="column-message" style="max-width:250px;">
                                    <span title="<?php echo esc_attr($attempt->message_text); ?>">
                                        <?php echo esc_html(substr($attempt->message_text, 0, 80)); ?><?php echo strlen($attempt->message_text) > 80 ? '...' : ''; ?>
                                    </span>
                                </td>
                                <td class="column-type">
                                    <span class="status-badge status-<?php echo esc_attr($attempt->detected_pattern); ?>">
                                        <?php echo esc_html(ucfirst($attempt->detected_pattern)); ?>
                                    </span>
                                </td>
                                <td class="column-detected" style="max-width:150px;">
                                    <code style="font-size:0.75rem;background:#ffebee;color:#c62828;padding:2px 6px;border-radius:3px;word-break:break-all;">
                                        <?php echo esc_html(substr($attempt->detected_content, 0, 50)); ?><?php echo strlen($attempt->detected_content) > 50 ? '...' : ''; ?>
                                    </code>
                                </td>
                                <td class="column-date"><?php echo esc_html($attempt->blocked_at); ?></td>
                                <td class="column-actions">
                                    <div class="row-actions">
                                        <a href="javascript:void(0);" class="button button-small view-blocked-details" data-message="<?php echo esc_attr($attempt->message_text); ?>" data-detected="<?php echo esc_attr($attempt->detected_content); ?>" data-ip="<?php echo esc_attr($attempt->ip_address); ?>">
                                            <?php _e('View Details', 'wheelfy'); ?>
                                        </a>
                                        <a href="<?php echo esc_url(admin_url('user-edit.php?user_id=' . $attempt->user_id)); ?>" class="button button-small">
                                            <?php _e('View User', 'wheelfy'); ?>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php 
                            endforeach;
                        else : 
                        ?>
                            <tr>
                                <td colspan="8" style="text-align: center; padding: 40px;">
                                    <div style="font-size: 3rem; margin-bottom: 1rem;">🛡️</div>
                                    <h3 style="margin: 0 0 0.5rem; font-size: 1.125rem;"><?php _e('No Blocked Messages', 'wheelfy'); ?></h3>
                                    <p style="margin: 0; color: #666;"><?php _e('No contact information sharing attempts have been blocked yet.', 'wheelfy'); ?></p>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<style>
/* Admin Chat Page Styles */
.wheelfy-admin-chat {
    margin: 20px 0 0 0;
}

.wheelfy-admin-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 20px;
}

.wheelfy-admin-header h1 {
    margin: 0 0 8px 0;
    font-size: 23px;
    font-weight: 400;
}

.wheelfy-admin-header .description {
    margin: 0;
    color: #646970;
    font-size: 14px;
}

/* KPI Cards */
.wheelfy-kpi-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
    margin: 20px 0;
    padding-left: 20px;
}

.wheelfy-kpi-card {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 20px;
    display: flex;
    align-items: center;
    gap: 16px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    transition: all 0.3s ease;
}

.wheelfy-kpi-card:hover {
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    border-color: #2271b1;
}

.kpi-icon {
    width: 48px;
    height: 48px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.kpi-icon svg {
    display: block;
    margin: 0 auto;
    width: 24px;
    height: 24px;
}

.kpi-content {
    flex: 1;
}

.kpi-label {
    font-size: 13px;
    color: #646970;
    margin-bottom: 4px;
}

.kpi-value {
    font-size: 28px;
    font-weight: 600;
    color: #1d2327;
    line-height: 1.2;
}

/* Tabs */
.nav-tab-wrapper {
    margin: 20px 0 0 0;
    border-bottom: 1px solid #ccc;
}

.nav-tab-wrapper .nav-tab {
    margin-bottom: -1px;
    padding: 10px 15px;
    font-size: 14px;
    text-decoration: none;
    border: 1px solid transparent;
    border-bottom: none;
    background: transparent;
    color: #50575e;
    cursor: pointer;
    transition: all 0.2s ease;
}

.nav-tab-wrapper .nav-tab:hover {
    color: #2271b1;
    background: #f6f7f7;
}

.nav-tab-wrapper .nav-tab.nav-tab-active {
    color: #2271b1;
    background: #fff;
    border-color: #ccc;
    border-bottom-color: #fff;
}

/* Tab Content */
.wheelfy-tab-content {
    display: none;
    margin-top: 20px;
}

.wheelfy-tab-content.active {
    display: block;
}

/* Dashboard Card */
.wheelfy-dashboard-card {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    margin-bottom: 20px;
}

.card-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    padding: 20px 24px;
    border-bottom: 1px solid #ddd;
    flex-wrap: wrap;
    gap: 16px;
}

.card-header h2 {
    margin: 0 0 4px 0;
    font-size: 18px;
    font-weight: 600;
    color: #1d2327;
}

.card-description {
    margin: 0;
    font-size: 13px;
    color: #646970;
}

.header-filters {
    display: flex;
    gap: 10px;
    align-items: center;
    flex-wrap: wrap;
}

.search-input {
    padding: 6px 12px;
    border: 1px solid #8c8f94;
    border-radius: 4px;
    font-size: 14px;
    min-width: 200px;
}

.filter-select {
    padding: 6px 12px;
    border: 1px solid #8c8f94;
    border-radius: 4px;
    font-size: 14px;
    min-width: 140px;
}

.card-body {
    padding: 24px;
}

/* Table Styles */
.table-view-list {
    margin: 0;
    border: none;
    width: 100%;
}

.card-body > .table-view-list {
    margin: -24px;
    width: calc(100% + 48px);
}

.table-view-list thead th {
    background: #f6f7f7;
    font-weight: 600;
    padding: 12px;
    border-bottom: 2px solid #ddd;
}

.table-view-list tbody td {
    padding: 12px;
    vertical-align: middle;
}

.table-view-list tbody tr:hover {
    background: #f9f9f9;
}

/* Status Badges */
.status-badge {
    display: inline-block;
    padding: 4px 12px;
    border-radius: 12px;
    font-size: 12px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.status-active {
    background: #e8f5e9;
    color: #388e3c;
}

.status-dispute {
    background: #fff3cd;
    color: #856404;
}

.status-closed {
    background: #d1ecf1;
    color: #0c5460;
}

.status-pending {
    background: #fff3e0;
    color: #f57c00;
}

.status-reviewed {
    background: #e3f2fd;
    color: #1976d2;
}

.status-dismissed {
    background: #f5f5f5;
    color: #646970;
}

.status-resolved {
    background: #d4edda;
    color: #155724;
}

.status-customer {
    background: #e3f2fd;
    color: #1976d2;
}

.status-partner {
    background: #e8f5e9;
    color: #388e3c;
}

.status-email {
    background: #e3f2fd;
    color: #1565c0;
}

.status-phone {
    background: #fff3e0;
    color: #e65100;
}

.status-social {
    background: #fce4ec;
    color: #c2185b;
}

.reported-flag {
    color: #dc3232;
    margin-left: 6px;
    font-size: 16px;
    vertical-align: middle;
}

/* Badge Count */
.badge-count {
    display: inline-block;
    padding: 4px 10px;
    background: #e3f2fd;
    color: #1976d2;
    border-radius: 12px;
    font-weight: 600;
    font-size: 12px;
}

/* Row Actions */
.row-actions {
    display: flex !important;
    gap: 6px;
    flex-wrap: wrap;
    align-items: center;
    visibility: visible !important;
    opacity: 1 !important;
}

.row-actions .button {
    margin: 0;
    white-space: nowrap;
}

/* Hide WordPress Footer */
#wpfooter {
    display: none !important;
}

/* Responsive */
@media (max-width: 782px) {
    .wheelfy-admin-header {
        flex-direction: column;
        gap: 16px;
    }

    .header-filters {
        width: 100%;
    }

    .header-filters .search-input,
    .header-filters .filter-select {
        flex: 1;
        min-width: 0;
    }

    .wheelfy-kpi-grid {
        grid-template-columns: 1fr;
        padding-left: 0;
    }

    .row-actions {
        flex-direction: column;
        align-items: flex-start;
    }

    .card-body .table-view-list {
        margin: -24px;
        width: calc(100% + 48px);
    }
}
</style>

<script>
jQuery(document).ready(function($) {
    // Hide WordPress admin footer
    $('#wpfooter').hide();
    $('p:contains("Thank you for creating")').hide();
    $('p:contains("Version")').hide();
    
    // Tab switching
    $('.wheelfy-subscription-tabs .nav-tab').on('click', function(e) {
        e.preventDefault();
        const tab = $(this).data('tab');
        
        // Update active tab
        $('.wheelfy-subscription-tabs .nav-tab').removeClass('nav-tab-active');
        $(this).addClass('nav-tab-active');
        
        // Show/hide tab content
        $('.wheelfy-tab-content').removeClass('active');
        $('#tab-' + tab).addClass('active');
        
        // Update URL without reload
        const url = new URL(window.location);
        url.searchParams.set('tab', tab);
        window.history.pushState({}, '', url);
    });
    
    // Search functionality
    $('#search-all-chats, #search-active, #search-blocked, #search-reported, #search-history, #search-warnings').on('keyup', function() {
        const searchTerm = $(this).val().toLowerCase();
        const table = $(this).closest('.wheelfy-dashboard-card').find('table tbody');
        table.find('tr').each(function() {
            const text = $(this).text().toLowerCase();
            $(this).toggle(text.indexOf(searchTerm) > -1);
        });
    });
    
    // Filter by status
    $('#filter-status-all, #filter-history-status').on('change', function() {
        const filterValue = $(this).val();
        const table = $(this).closest('.wheelfy-dashboard-card').find('table tbody');
        
        if (filterValue === 'all') {
            table.find('tr').show();
        } else {
            table.find('tr').each(function() {
                const status = $(this).find('.status-badge').attr('class').match(/status-(\w+)/);
                if (status && status[1] === filterValue) {
                    $(this).show();
                } else {
                    $(this).hide();
                }
            });
        }
    });
    
    // Filter report status
    $('#filter-report-status').on('change', function() {
        const filterValue = $(this).val();
        const table = $(this).closest('.wheelfy-dashboard-card').find('table tbody');
        
        if (filterValue === 'all') {
            table.find('tr').show();
        } else {
            table.find('tr').each(function() {
                const status = $(this).find('.status-badge').last().attr('class').match(/status-(\w+)/);
                if (status && status[1] === filterValue) {
                    $(this).show();
                } else {
                    $(this).hide();
                }
            });
        }
    });
    
    // Action buttons - prevent default
    $('.row-actions a').on('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
    });
    
    // Block user button
    $('#block-user-btn, #issue-warning-btn').on('click', function(e) {
        e.preventDefault();
        alert('<?php echo esc_js(__('Feature coming soon. This will open a modal to block/issue warning.', 'wheelfy')); ?>');
    });
    
    // Contact blocked tab search
    $('#search-contact-blocked').on('keyup', function() {
        const searchTerm = $(this).val().toLowerCase();
        $('#tab-contact-blocked table tbody tr').each(function() {
            const text = $(this).text().toLowerCase();
            $(this).toggle(text.indexOf(searchTerm) > -1);
        });
    });
    
    // Contact blocked tab filter by type
    $('#filter-contact-type').on('change', function() {
        const filterValue = $(this).val();
        $('#tab-contact-blocked table tbody tr').each(function() {
            if (filterValue === 'all') {
                $(this).show();
            } else {
                const rowType = $(this).attr('data-type');
                $(this).toggle(rowType === filterValue);
            }
        });
    });
    
    // View blocked message details
    $('.view-blocked-details').on('click', function() {
        const message = $(this).data('message');
        const detected = $(this).data('detected');
        const ip = $(this).data('ip');
        
        let details = '<?php echo esc_js(__('Full Message:', 'wheelfy')); ?>\n' + message + '\n\n';
        details += '<?php echo esc_js(__('Detected Content:', 'wheelfy')); ?>\n' + detected + '\n\n';
        details += '<?php echo esc_js(__('IP Address:', 'wheelfy')); ?> ' + ip;
        
        alert(details);
    });
    
    // Force actions visible
    function forceActionsVisible() {
        $('.row-actions').css({
            'display': 'flex !important',
            'visibility': 'visible !important',
            'opacity': '1 !important'
        });
    }
    
    // Use MutationObserver to ensure actions stay visible
    const observer = new MutationObserver(function(mutations) {
        forceActionsVisible();
    });
    
    $('.row-actions').each(function() {
        observer.observe(this, {
            attributes: true,
            attributeFilter: ['style', 'class']
        });
    });
    
    // Initial call
    forceActionsVisible();
    setTimeout(forceActionsVisible, 100);
    setTimeout(forceActionsVisible, 500);
});
</script>
