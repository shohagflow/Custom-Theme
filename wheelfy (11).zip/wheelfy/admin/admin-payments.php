<?php
/**
 * Admin Payment Settings Page
 * 
 * @package Wheelfy
 */

// Security check
if (!defined('ABSPATH')) {
    exit;
}

// Check user permissions
if (!current_user_can('manage_options')) {
    wp_die(__('You do not have sufficient permissions to access this page.', 'wheelfy'));
}

// Handle form submission
if (isset($_POST['save_payment_settings']) && check_admin_referer('wheelfy_payment_settings_nonce')) {
    // Save payment gateway settings
    $payment_methods = isset($_POST['payment_methods']) ? $_POST['payment_methods'] : array();
    update_option('wheelfy_payment_methods', $payment_methods);
    
    // Save individual gateway settings
    $gateways = array('stripe', 'paypal', 'bank_transfer', 'cash_on_delivery');
    foreach ($gateways as $gateway) {
        $enabled = isset($_POST[$gateway . '_enabled']) ? 'yes' : 'no';
        $title = isset($_POST[$gateway . '_title']) ? sanitize_text_field($_POST[$gateway . '_title']) : '';
        $description = isset($_POST[$gateway . '_description']) ? sanitize_textarea_field($_POST[$gateway . '_description']) : '';
        
        update_option('wheelfy_' . $gateway . '_enabled', $enabled);
        update_option('wheelfy_' . $gateway . '_title', $title);
        update_option('wheelfy_' . $gateway . '_description', $description);
        
        // Save gateway-specific settings
        if ($gateway === 'stripe') {
            update_option('wheelfy_stripe_publishable_key', isset($_POST['stripe_publishable_key']) ? sanitize_text_field($_POST['stripe_publishable_key']) : '');
            update_option('wheelfy_stripe_secret_key', isset($_POST['stripe_secret_key']) ? sanitize_text_field($_POST['stripe_secret_key']) : '');
            update_option('wheelfy_stripe_test_mode', isset($_POST['stripe_test_mode']) ? 'yes' : 'no');
        } elseif ($gateway === 'paypal') {
            update_option('wheelfy_paypal_client_id', isset($_POST['paypal_client_id']) ? sanitize_text_field($_POST['paypal_client_id']) : '');
            update_option('wheelfy_paypal_secret', isset($_POST['paypal_secret']) ? sanitize_text_field($_POST['paypal_secret']) : '');
            update_option('wheelfy_paypal_sandbox', isset($_POST['paypal_sandbox']) ? 'yes' : 'no');
        } elseif ($gateway === 'bank_transfer') {
            update_option('wheelfy_bank_account_name', isset($_POST['bank_account_name']) ? sanitize_text_field($_POST['bank_account_name']) : '');
            update_option('wheelfy_bank_account_number', isset($_POST['bank_account_number']) ? sanitize_text_field($_POST['bank_account_number']) : '');
            update_option('wheelfy_bank_name', isset($_POST['bank_name']) ? sanitize_text_field($_POST['bank_name']) : '');
            update_option('wheelfy_bank_iban', isset($_POST['bank_iban']) ? sanitize_text_field($_POST['bank_iban']) : '');
        }
    }
    
    // Save general settings
    if (isset($_POST['currency'])) {
        update_option('wheelfy_currency', sanitize_text_field($_POST['currency']));
    }
    if (isset($_POST['currency_symbol'])) {
        update_option('wheelfy_currency_symbol', sanitize_text_field($_POST['currency_symbol']));
    }
    
    echo '<div class="notice notice-success is-dismissible"><p>' . __('Payment settings saved successfully!', 'wheelfy') . '</p></div>';
}

$current_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'gateways';

// Handle bank transfer verification
if (isset($_POST['verify_bank_transfer']) && check_admin_referer('wheelfy_verify_bank_transfer_nonce')) {
    $transaction_id = isset($_POST['transaction_id']) ? sanitize_text_field($_POST['transaction_id']) : '';
    if ($transaction_id && function_exists('wheelfy_admin_complete_bank_transfer')) {
        $result = wheelfy_admin_complete_bank_transfer($transaction_id);
        if (!is_wp_error($result)) {
            echo '<div class="notice notice-success is-dismissible"><p>' . __('Payment verified and subscription activated!', 'wheelfy') . '</p></div>';
        } else {
            echo '<div class="notice notice-error is-dismissible"><p>' . esc_html($result->get_error_message()) . '</p></div>';
        }
    }
}

// Calculate statistics
$enabled_gateways = 0;
$gateways_list = array('stripe', 'paypal', 'bank_transfer', 'cash_on_delivery');
foreach ($gateways_list as $gateway) {
    if (get_option('wheelfy_' . $gateway . '_enabled') === 'yes') {
        $enabled_gateways++;
    }
}

$total_gateways = count($gateways_list);
$currency = get_option('wheelfy_currency', 'HUF');
$currency_symbol = get_option('wheelfy_currency_symbol', 'Ft');

// Get payment statistics
$payment_stats = function_exists('wheelfy_get_payment_statistics') ? wheelfy_get_payment_statistics() : array(
    'total_transactions' => 0,
    'total_revenue' => 0,
    'monthly_revenue' => 0,
    'pending_payments' => 0
);
?>

<style>
.wheelfy-admin-payments {
    margin: 20px 20px 0 0;
}

.wheelfy-admin-header {
    margin-bottom: 20px;
}

.wheelfy-admin-header h1 {
    font-size: 23px;
    font-weight: 400;
    margin: 0;
    padding: 9px 0 4px 0;
    line-height: 1.3;
}

.wheelfy-admin-header .description {
    margin: 0;
    color: #646970;
    font-size: 13px;
}

.wheelfy-kpi-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
    margin-bottom: 30px;
}

.wheelfy-kpi-card {
    background: #fff;
    border: 1px solid #c3c4c7;
    border-radius: 8px;
    padding: 20px;
    display: flex;
    align-items: center;
    gap: 16px;
    box-shadow: 0 1px 1px rgba(0,0,0,.04);
}

.kpi-icon {
    width: 56px;
    height: 56px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.kpi-content {
    flex: 1;
}

.kpi-label {
    font-size: 13px;
    color: #646970;
    margin-bottom: 4px;
}

.kpi-value {
    font-size: 28px;
    font-weight: 600;
    color: #1d2327;
    line-height: 1.2;
}

.wheelfy-subscription-tabs {
    margin: 0;
    padding: 0;
    border-bottom: 1px solid #c3c4c7;
}

.wheelfy-subscription-tabs .nav-tab {
    margin-left: 0;
    margin-bottom: -1px;
}

.wheelfy-subscription-tabs .nav-tab-active {
    border-bottom-color: #fff;
    background: #fff;
}

.wheelfy-dashboard-card {
    background: #fff;
    border: 1px solid #c3c4c7;
    border-radius: 4px;
    box-shadow: 0 1px 1px rgba(0,0,0,.04);
    margin-top: 20px;
    margin-bottom: 20px;
}

.card-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    padding: 20px;
    border-bottom: 1px solid #c3c4c7;
}

.card-header h2 {
    font-size: 18px;
    font-weight: 600;
    margin: 0 0 4px 0;
    color: #1d2327;
}

.card-description {
    font-size: 13px;
    color: #646970;
    margin: 0;
}

.card-body {
    padding: 20px;
}

.wheelfy-payment-gateway {
    border: 1px solid #c3c4c7;
    border-radius: 4px;
    padding: 20px;
    margin-bottom: 20px;
    background: #f6f7f7;
}

.wheelfy-payment-gateway-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 16px;
}

.wheelfy-payment-gateway-title {
    font-size: 16px;
    font-weight: 600;
    color: #1d2327;
    margin: 0;
    display: flex;
    align-items: center;
    gap: 8px;
}

.wheelfy-payment-gateway-title svg {
    width: 20px;
    height: 20px;
}

.wheelfy-payment-toggle {
    position: relative;
    display: inline-block;
    width: 50px;
    height: 26px;
}

.wheelfy-payment-toggle input {
    opacity: 0;
    width: 0;
    height: 0;
}

.wheelfy-payment-slider {
    position: absolute;
    cursor: pointer;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: #c3c4c7;
    transition: .4s;
    border-radius: 26px;
}

.wheelfy-payment-slider:before {
    position: absolute;
    content: "";
    height: 20px;
    width: 20px;
    left: 3px;
    bottom: 3px;
    background-color: white;
    transition: .4s;
    border-radius: 50%;
}

.wheelfy-payment-toggle input:checked + .wheelfy-payment-slider {
    background-color: #2271b1;
}

.wheelfy-payment-toggle input:checked + .wheelfy-payment-slider:before {
    transform: translateX(24px);
}

.wheelfy-payment-gateway-content {
    display: none;
    margin-top: 20px;
    padding-top: 20px;
    border-top: 1px solid #c3c4c7;
}

.wheelfy-payment-gateway.enabled .wheelfy-payment-gateway-content {
    display: block;
}

.wheelfy-form-group {
    margin-bottom: 20px;
}

.wheelfy-form-group:last-child {
    margin-bottom: 0;
}

.wheelfy-form-group label {
    display: block;
    font-weight: 600;
    color: #1d2327;
    margin-bottom: 6px;
    font-size: 14px;
}

.wheelfy-form-group input[type="text"],
.wheelfy-form-group input[type="password"],
.wheelfy-form-group textarea {
    width: 100%;
    padding: 8px 12px;
    border: 1px solid #8c8f94;
    border-radius: 4px;
    font-size: 14px;
    transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
}

.wheelfy-form-group input[type="text"]:focus,
.wheelfy-form-group input[type="password"]:focus,
.wheelfy-form-group textarea:focus {
    outline: none;
    border-color: #2271b1;
    box-shadow: 0 0 0 1px #2271b1;
}

.wheelfy-form-group textarea {
    resize: vertical;
    min-height: 100px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
}

.wheelfy-form-group .description {
    margin-top: 6px;
    font-size: 13px;
    color: #646970;
    font-style: normal;
}

.wheelfy-checkbox-group {
    display: flex;
    align-items: center;
    gap: 8px;
}

.wheelfy-checkbox-group input[type="checkbox"] {
    width: 18px;
    height: 18px;
    cursor: pointer;
}

.wheelfy-checkbox-group label {
    margin: 0;
    cursor: pointer;
    font-weight: normal;
}

@media (max-width: 782px) {
    .wheelfy-kpi-grid {
        grid-template-columns: 1fr;
    }
    
    .card-header {
        flex-direction: column;
        gap: 12px;
    }
}
</style>

<div class="wrap wheelfy-admin-payments">
    <!-- Header -->
    <div class="wheelfy-admin-header">
        <h1 class="wp-heading-inline"><?php _e('Payment Settings', 'wheelfy'); ?></h1>
        <p class="description"><?php _e('Configure payment gateways and manage payment methods for your platform', 'wheelfy'); ?></p>
    </div>
    <hr class="wp-header-end">

    <!-- KPI Cards -->
    <div class="wheelfy-kpi-grid">
        <div class="wheelfy-kpi-card">
            <div class="kpi-icon" style="background: #e3f2fd; color: #1976d2;">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"></path>
                </svg>
            </div>
            <div class="kpi-content">
                <div class="kpi-label"><?php _e('Enabled Gateways', 'wheelfy'); ?></div>
                <div class="kpi-value"><?php echo number_format($enabled_gateways); ?> / <?php echo $total_gateways; ?></div>
            </div>
        </div>

        <div class="wheelfy-kpi-card">
            <div class="kpi-icon" style="background: #e8f5e9; color: #388e3c;">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M12 2v20M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"></path>
                </svg>
            </div>
            <div class="kpi-content">
                <div class="kpi-label"><?php _e('Total Revenue', 'wheelfy'); ?></div>
                <div class="kpi-value" style="font-size: 20px;"><?php echo number_format($payment_stats['total_revenue'], 0, ',', ' '); ?> <?php echo esc_html($currency_symbol); ?></div>
            </div>
        </div>

        <div class="wheelfy-kpi-card">
            <div class="kpi-icon" style="background: #fff3e0; color: #f57c00;">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                    <line x1="16" y1="2" x2="16" y2="6"></line>
                    <line x1="8" y1="2" x2="8" y2="6"></line>
                    <line x1="3" y1="10" x2="21" y2="10"></line>
                </svg>
            </div>
            <div class="kpi-content">
                <div class="kpi-label"><?php _e('Monthly Revenue', 'wheelfy'); ?></div>
                <div class="kpi-value" style="font-size: 20px;"><?php echo number_format($payment_stats['monthly_revenue'], 0, ',', ' '); ?> <?php echo esc_html($currency_symbol); ?></div>
            </div>
        </div>

        <div class="wheelfy-kpi-card">
            <div class="kpi-icon" style="background: #fef3c7; color: #d97706;">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="12" cy="12" r="10"></circle>
                    <polyline points="12 6 12 12 16 14"></polyline>
                </svg>
            </div>
            <div class="kpi-content">
                <div class="kpi-label"><?php _e('Pending Payments', 'wheelfy'); ?></div>
                <div class="kpi-value"><?php echo number_format($payment_stats['pending_payments']); ?></div>
            </div>
        </div>
    </div>

    <!-- Tabs Navigation -->
    <nav class="nav-tab-wrapper wheelfy-subscription-tabs">
        <a href="<?php echo esc_url(add_query_arg('tab', 'gateways', admin_url('admin.php?page=wheelfy-payments'))); ?>" 
           class="nav-tab <?php echo $current_tab === 'gateways' ? 'nav-tab-active' : ''; ?>">
            <?php _e('Payment Gateways', 'wheelfy'); ?>
        </a>
        <a href="<?php echo esc_url(add_query_arg('tab', 'transactions', admin_url('admin.php?page=wheelfy-payments'))); ?>" 
           class="nav-tab <?php echo $current_tab === 'transactions' ? 'nav-tab-active' : ''; ?>">
            <?php _e('Transactions', 'wheelfy'); ?>
            <?php if ($payment_stats['pending_payments'] > 0) : ?>
                <span style="background:#d97706;color:white;padding:2px 8px;border-radius:10px;font-size:11px;margin-left:6px;"><?php echo $payment_stats['pending_payments']; ?></span>
            <?php endif; ?>
        </a>
    </nav>

    <form method="POST" action="">
        <?php wp_nonce_field('wheelfy_payment_settings_nonce'); ?>
        
        <?php if ($current_tab === 'gateways') : ?>
            <div class="wheelfy-dashboard-card">
                <div class="card-header">
                    <div>
                        <h2><?php _e('Payment Gateways', 'wheelfy'); ?></h2>
                        <p class="card-description"><?php _e('Enable and configure payment methods for your customers', 'wheelfy'); ?></p>
                    </div>
                </div>
                <div class="card-body">
                    <!-- Stripe -->
                    <div class="wheelfy-payment-gateway <?php echo (get_option('wheelfy_stripe_enabled') === 'yes') ? 'enabled' : ''; ?>" id="gateway-stripe">
                        <div class="wheelfy-payment-gateway-header">
                            <h3 class="wheelfy-payment-gateway-title">
                                <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                                </svg>
                                Stripe
                            </h3>
                            <label class="wheelfy-payment-toggle">
                                <input type="checkbox" name="stripe_enabled" value="1" <?php checked(get_option('wheelfy_stripe_enabled'), 'yes'); ?> onchange="document.getElementById('gateway-stripe').classList.toggle('enabled', this.checked)">
                                <span class="wheelfy-payment-slider"></span>
                            </label>
                        </div>
                        <div class="wheelfy-payment-gateway-content">
                            <div class="wheelfy-form-group">
                                <label for="stripe_title">Title</label>
                                <input type="text" id="stripe_title" name="stripe_title" value="<?php echo esc_attr(get_option('wheelfy_stripe_title', 'Credit Card (Stripe)')); ?>" placeholder="Credit Card (Stripe)">
                                <p class="description">This controls the title which the user sees during checkout.</p>
                            </div>
                            <div class="wheelfy-form-group">
                                <label for="stripe_description">Description</label>
                                <textarea id="stripe_description" name="stripe_description" placeholder="Pay securely using your credit card via Stripe"><?php echo esc_textarea(get_option('wheelfy_stripe_description', '')); ?></textarea>
                                <p class="description">Payment method description that the customer will see on your checkout.</p>
                            </div>
                            <div class="wheelfy-form-group">
                                <label for="stripe_publishable_key">Publishable Key</label>
                                <input type="text" id="stripe_publishable_key" name="stripe_publishable_key" value="<?php echo esc_attr(get_option('wheelfy_stripe_publishable_key', '')); ?>" placeholder="pk_test_...">
                                <p class="description">Your Stripe publishable key from your Stripe account.</p>
                            </div>
                            <div class="wheelfy-form-group">
                                <label for="stripe_secret_key">Secret Key</label>
                                <input type="password" id="stripe_secret_key" name="stripe_secret_key" value="<?php echo esc_attr(get_option('wheelfy_stripe_secret_key', '')); ?>" placeholder="sk_test_...">
                                <p class="description">Your Stripe secret key from your Stripe account.</p>
                            </div>
                            <div class="wheelfy-form-group">
                                <div class="wheelfy-checkbox-group">
                                    <input type="checkbox" id="stripe_test_mode" name="stripe_test_mode" value="1" <?php checked(get_option('wheelfy_stripe_test_mode'), 'yes'); ?>>
                                    <label for="stripe_test_mode">Enable Test Mode</label>
                                </div>
                                <p class="description">Place the payment gateway in test mode using test API keys.</p>
                            </div>
                        </div>
                    </div>

                    <!-- PayPal -->
                    <div class="wheelfy-payment-gateway <?php echo (get_option('wheelfy_paypal_enabled') === 'yes') ? 'enabled' : ''; ?>" id="gateway-paypal">
                        <div class="wheelfy-payment-gateway-header">
                            <h3 class="wheelfy-payment-gateway-title">
                                <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z" />
                                </svg>
                                PayPal
                            </h3>
                            <label class="wheelfy-payment-toggle">
                                <input type="checkbox" name="paypal_enabled" value="1" <?php checked(get_option('wheelfy_paypal_enabled'), 'yes'); ?> onchange="document.getElementById('gateway-paypal').classList.toggle('enabled', this.checked)">
                                <span class="wheelfy-payment-slider"></span>
                            </label>
                        </div>
                        <div class="wheelfy-payment-gateway-content">
                            <div class="wheelfy-form-group">
                                <label for="paypal_title">Title</label>
                                <input type="text" id="paypal_title" name="paypal_title" value="<?php echo esc_attr(get_option('wheelfy_paypal_title', 'PayPal')); ?>" placeholder="PayPal">
                                <p class="description">This controls the title which the user sees during checkout.</p>
                            </div>
                            <div class="wheelfy-form-group">
                                <label for="paypal_description">Description</label>
                                <textarea id="paypal_description" name="paypal_description" placeholder="Pay via PayPal; you can pay with your credit card if you don't have a PayPal account."><?php echo esc_textarea(get_option('wheelfy_paypal_description', '')); ?></textarea>
                                <p class="description">Payment method description that the customer will see on your checkout.</p>
                            </div>
                            <div class="wheelfy-form-group">
                                <label for="paypal_client_id">Client ID</label>
                                <input type="text" id="paypal_client_id" name="paypal_client_id" value="<?php echo esc_attr(get_option('wheelfy_paypal_client_id', '')); ?>" placeholder="PayPal Client ID">
                                <p class="description">Your PayPal Client ID from the PayPal Developer Dashboard.</p>
                            </div>
                            <div class="wheelfy-form-group">
                                <label for="paypal_secret">Secret Key</label>
                                <input type="password" id="paypal_secret" name="paypal_secret" value="<?php echo esc_attr(get_option('wheelfy_paypal_secret', '')); ?>" placeholder="PayPal Secret Key">
                                <p class="description">Your PayPal Secret Key from the PayPal Developer Dashboard.</p>
                            </div>
                            <div class="wheelfy-form-group">
                                <div class="wheelfy-checkbox-group">
                                    <input type="checkbox" id="paypal_sandbox" name="paypal_sandbox" value="1" <?php checked(get_option('wheelfy_paypal_sandbox'), 'yes'); ?>>
                                    <label for="paypal_sandbox">Enable Sandbox Mode</label>
                                </div>
                                <p class="description">Place the payment gateway in sandbox mode for testing.</p>
                            </div>
                        </div>
                    </div>

                    <!-- Bank Transfer -->
                    <div class="wheelfy-payment-gateway <?php echo (get_option('wheelfy_bank_transfer_enabled') === 'yes') ? 'enabled' : ''; ?>" id="gateway-bank_transfer">
                        <div class="wheelfy-payment-gateway-header">
                            <h3 class="wheelfy-payment-gateway-title">
                                <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 14v3m4-3v3m4-3v3M3 21h18M3 10h18M3 7l9-4 9 4M4 10h16v11H4V10z" />
                                </svg>
                                Bank Transfer
                            </h3>
                            <label class="wheelfy-payment-toggle">
                                <input type="checkbox" name="bank_transfer_enabled" value="1" <?php checked(get_option('wheelfy_bank_transfer_enabled'), 'yes'); ?> onchange="document.getElementById('gateway-bank_transfer').classList.toggle('enabled', this.checked)">
                                <span class="wheelfy-payment-slider"></span>
                            </label>
                        </div>
                        <div class="wheelfy-payment-gateway-content">
                            <div class="wheelfy-form-group">
                                <label for="bank_transfer_title">Title</label>
                                <input type="text" id="bank_transfer_title" name="bank_transfer_title" value="<?php echo esc_attr(get_option('wheelfy_bank_transfer_title', 'Direct Bank Transfer')); ?>" placeholder="Direct Bank Transfer">
                                <p class="description">This controls the title which the user sees during checkout.</p>
                            </div>
                            <div class="wheelfy-form-group">
                                <label for="bank_transfer_description">Description</label>
                                <textarea id="bank_transfer_description" name="bank_transfer_description" placeholder="Make your payment directly into our bank account. Please use your Order ID as the payment reference."><?php echo esc_textarea(get_option('wheelfy_bank_transfer_description', '')); ?></textarea>
                                <p class="description">Payment method description that the customer will see on your checkout.</p>
                            </div>
                            <div class="wheelfy-form-group">
                                <label for="bank_account_name">Account Name</label>
                                <input type="text" id="bank_account_name" name="bank_account_name" value="<?php echo esc_attr(get_option('wheelfy_bank_account_name', '')); ?>" placeholder="Account Holder Name">
                            </div>
                            <div class="wheelfy-form-group">
                                <label for="bank_account_number">Account Number</label>
                                <input type="text" id="bank_account_number" name="bank_account_number" value="<?php echo esc_attr(get_option('wheelfy_bank_account_number', '')); ?>" placeholder="1234567890">
                            </div>
                            <div class="wheelfy-form-group">
                                <label for="bank_name">Bank Name</label>
                                <input type="text" id="bank_name" name="bank_name" value="<?php echo esc_attr(get_option('wheelfy_bank_name', '')); ?>" placeholder="Bank Name">
                            </div>
                            <div class="wheelfy-form-group">
                                <label for="bank_iban">IBAN / SWIFT</label>
                                <input type="text" id="bank_iban" name="bank_iban" value="<?php echo esc_attr(get_option('wheelfy_bank_iban', '')); ?>" placeholder="IBAN or SWIFT Code">
                            </div>
                        </div>
                    </div>

                    <!-- Cash on Delivery -->
                    <div class="wheelfy-payment-gateway <?php echo (get_option('wheelfy_cash_on_delivery_enabled') === 'yes') ? 'enabled' : ''; ?>" id="gateway-cash_on_delivery">
                        <div class="wheelfy-payment-gateway-header">
                            <h3 class="wheelfy-payment-gateway-title">
                                <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z" />
                                </svg>
                                Cash on Delivery
                            </h3>
                            <label class="wheelfy-payment-toggle">
                                <input type="checkbox" name="cash_on_delivery_enabled" value="1" <?php checked(get_option('wheelfy_cash_on_delivery_enabled'), 'yes'); ?> onchange="document.getElementById('gateway-cash_on_delivery').classList.toggle('enabled', this.checked)">
                                <span class="wheelfy-payment-slider"></span>
                            </label>
                        </div>
                        <div class="wheelfy-payment-gateway-content">
                            <div class="wheelfy-form-group">
                                <label for="cash_on_delivery_title">Title</label>
                                <input type="text" id="cash_on_delivery_title" name="cash_on_delivery_title" value="<?php echo esc_attr(get_option('wheelfy_cash_on_delivery_title', 'Cash on Delivery')); ?>" placeholder="Cash on Delivery">
                                <p class="description">This controls the title which the user sees during checkout.</p>
                            </div>
                            <div class="wheelfy-form-group">
                                <label for="cash_on_delivery_description">Description</label>
                                <textarea id="cash_on_delivery_description" name="cash_on_delivery_description" placeholder="Pay with cash upon delivery."><?php echo esc_textarea(get_option('wheelfy_cash_on_delivery_description', '')); ?></textarea>
                                <p class="description">Payment method description that the customer will see on your checkout.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php if ($current_tab === 'transactions') : ?>
            <?php
            $transactions = function_exists('wheelfy_get_all_transactions') ? wheelfy_get_all_transactions(array('limit' => 50)) : array();
            ?>
            <div class="wheelfy-dashboard-card">
                <div class="card-header">
                    <div>
                        <h2><?php _e('Payment Transactions', 'wheelfy'); ?></h2>
                        <p class="card-description"><?php _e('View and manage all payment transactions', 'wheelfy'); ?></p>
                    </div>
                    <div style="display: flex; gap: 10px; align-items: center;">
                        <select id="filter-status" style="padding: 6px 12px; border-radius: 4px; border: 1px solid #8c8f94;">
                            <option value="all"><?php _e('All Status', 'wheelfy'); ?></option>
                            <option value="completed"><?php _e('Completed', 'wheelfy'); ?></option>
                            <option value="pending"><?php _e('Pending', 'wheelfy'); ?></option>
                            <option value="awaiting_payment"><?php _e('Awaiting Payment', 'wheelfy'); ?></option>
                            <option value="failed"><?php _e('Failed', 'wheelfy'); ?></option>
                            <option value="cancelled"><?php _e('Cancelled', 'wheelfy'); ?></option>
                        </select>
                        <select id="filter-gateway" style="padding: 6px 12px; border-radius: 4px; border: 1px solid #8c8f94;">
                            <option value="all"><?php _e('All Gateways', 'wheelfy'); ?></option>
                            <option value="stripe"><?php _e('Stripe', 'wheelfy'); ?></option>
                            <option value="paypal"><?php _e('PayPal', 'wheelfy'); ?></option>
                            <option value="bank_transfer"><?php _e('Bank Transfer', 'wheelfy'); ?></option>
                            <option value="cash_on_delivery"><?php _e('Cash on Delivery', 'wheelfy'); ?></option>
                        </select>
                    </div>
                </div>
                <div class="card-body" style="padding: 0;">
                    <table class="wp-list-table widefat fixed striped">
                        <thead>
                            <tr>
                                <th style="width: 150px;"><?php _e('Transaction ID', 'wheelfy'); ?></th>
                                <th><?php _e('User', 'wheelfy'); ?></th>
                                <th><?php _e('Plan', 'wheelfy'); ?></th>
                                <th style="width: 100px;"><?php _e('Amount', 'wheelfy'); ?></th>
                                <th style="width: 120px;"><?php _e('Gateway', 'wheelfy'); ?></th>
                                <th style="width: 120px;"><?php _e('Status', 'wheelfy'); ?></th>
                                <th style="width: 150px;"><?php _e('Date', 'wheelfy'); ?></th>
                                <th style="width: 150px;"><?php _e('Actions', 'wheelfy'); ?></th>
                            </tr>
                        </thead>
                        <tbody id="transactions-table">
                            <?php if (!empty($transactions)) : ?>
                                <?php foreach ($transactions as $txn) : ?>
                                    <tr data-status="<?php echo esc_attr($txn->status); ?>" data-gateway="<?php echo esc_attr($txn->gateway); ?>">
                                        <td>
                                            <code style="font-size: 11px; background: #f0f0f0; padding: 2px 6px; border-radius: 3px;">
                                                <?php echo esc_html($txn->transaction_id); ?>
                                            </code>
                                        </td>
                                        <td>
                                            <strong><?php echo esc_html($txn->user_name ?? __('Unknown', 'wheelfy')); ?></strong>
                                            <br><small style="color: #666;"><?php echo esc_html($txn->user_email ?? ''); ?></small>
                                        </td>
                                        <td><?php echo esc_html($txn->plan_name ?? '-'); ?></td>
                                        <td>
                                            <strong><?php echo number_format($txn->amount, 0, ',', ' '); ?> <?php echo esc_html($currency_symbol); ?></strong>
                                        </td>
                                        <td>
                                            <span style="display: inline-flex; align-items: center; gap: 4px;">
                                                <?php
                                                $gateway_icons = array(
                                                    'stripe' => '💳',
                                                    'paypal' => '🅿️',
                                                    'bank_transfer' => '🏦',
                                                    'cash_on_delivery' => '💵',
                                                    'free' => '🆓'
                                                );
                                                echo $gateway_icons[$txn->gateway] ?? '💰';
                                                echo ' ' . esc_html(ucfirst(str_replace('_', ' ', $txn->gateway)));
                                                ?>
                                            </span>
                                        </td>
                                        <td>
                                            <?php
                                            $status_colors = array(
                                                'completed' => '#10b981',
                                                'pending' => '#f59e0b',
                                                'awaiting_payment' => '#3b82f6',
                                                'pending_payment' => '#f59e0b',
                                                'failed' => '#ef4444',
                                                'cancelled' => '#6b7280'
                                            );
                                            $status_color = $status_colors[$txn->status] ?? '#6b7280';
                                            ?>
                                            <span style="display: inline-block; padding: 4px 12px; border-radius: 12px; font-size: 12px; font-weight: 600; background: <?php echo $status_color; ?>20; color: <?php echo $status_color; ?>;">
                                                <?php echo esc_html(ucfirst(str_replace('_', ' ', $txn->status))); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <span title="<?php echo esc_attr($txn->created_at); ?>">
                                                <?php echo esc_html(date_i18n(get_option('date_format') . ' H:i', strtotime($txn->created_at))); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <?php if ($txn->status === 'awaiting_payment' && $txn->gateway === 'bank_transfer') : ?>
                                                <form method="POST" style="display: inline;">
                                                    <?php wp_nonce_field('wheelfy_verify_bank_transfer_nonce'); ?>
                                                    <input type="hidden" name="transaction_id" value="<?php echo esc_attr($txn->transaction_id); ?>">
                                                    <button type="submit" name="verify_bank_transfer" class="button button-primary button-small" onclick="return confirm('<?php echo esc_js(__('Are you sure you want to verify this payment?', 'wheelfy')); ?>');">
                                                        <?php _e('Verify Payment', 'wheelfy'); ?>
                                                    </button>
                                                </form>
                                            <?php elseif ($txn->status === 'completed') : ?>
                                                <span style="color: #10b981;">✓ <?php _e('Verified', 'wheelfy'); ?></span>
                                            <?php else : ?>
                                                <span style="color: #6b7280;">-</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else : ?>
                                <tr>
                                    <td colspan="8" style="text-align: center; padding: 40px;">
                                        <div style="font-size: 48px; margin-bottom: 16px;">📊</div>
                                        <h3 style="margin: 0 0 8px;"><?php _e('No Transactions Yet', 'wheelfy'); ?></h3>
                                        <p style="color: #666; margin: 0;"><?php _e('Transactions will appear here when partners purchase subscriptions.', 'wheelfy'); ?></p>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <script>
            jQuery(document).ready(function($) {
                // Filter transactions
                $('#filter-status, #filter-gateway').on('change', function() {
                    const statusFilter = $('#filter-status').val();
                    const gatewayFilter = $('#filter-gateway').val();
                    
                    $('#transactions-table tr').each(function() {
                        const status = $(this).data('status');
                        const gateway = $(this).data('gateway');
                        
                        const statusMatch = statusFilter === 'all' || status === statusFilter;
                        const gatewayMatch = gatewayFilter === 'all' || gateway === gatewayFilter;
                        
                        $(this).toggle(statusMatch && gatewayMatch);
                    });
                });
            });
            </script>
        <?php endif; ?>

        <p class="submit">
            <button type="submit" name="save_payment_settings" class="button button-primary">
                <?php _e('Save Changes', 'wheelfy'); ?>
            </button>
        </p>
    </form>
</div>
