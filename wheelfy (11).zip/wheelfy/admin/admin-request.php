<?php
/**
 * Admin Request Management Page
 * 
 * @package Wheelfy
 */

// Security check
if (!defined('ABSPATH')) {
    exit;
}

// Check user permissions
if (!current_user_can('manage_options')) {
    wp_die(__('You do not have sufficient permissions to access this page.', 'wheelfy'));
}

$current_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'all';

// Get statistics for all tabs
$all_args = array(
    'post_type' => 'post',
    'posts_per_page' => -1,
    'post_status' => 'publish', // Only count published posts
    'meta_query' => array(
        array(
            'key' => '_proposal_request_type',
            'compare' => 'EXISTS',
        ),
    ),
    'fields' => 'ids',
);

$all_requests = new WP_Query($all_args);
$total_requests = $all_requests->found_posts;

$maintenance_args = array(
    'post_type' => 'post',
    'posts_per_page' => -1,
    'post_status' => 'publish', // Only count published posts
    'meta_query' => array(
        array(
            'key' => '_proposal_request_type',
            'value' => 'maintenance',
            'compare' => '=',
        ),
    ),
    'fields' => 'ids',
);
$maintenance_requests = new WP_Query($maintenance_args);
$total_maintenance = $maintenance_requests->found_posts;

$sell_args = array(
    'post_type' => 'post',
    'posts_per_page' => -1,
    'post_status' => 'publish', // Only count published posts
    'meta_query' => array(
        array(
            'key' => '_proposal_request_type',
            'value' => 'sell',
            'compare' => '=',
        ),
    ),
    'fields' => 'ids',
);
$sell_requests = new WP_Query($sell_args);
$total_sell = $sell_requests->found_posts;

// Get today's requests
$today = date('Y-m-d');
$today_args = array(
    'post_type' => 'post',
    'posts_per_page' => -1,
    'post_status' => 'publish', // Only count published posts
    'date_query' => array(
        array(
            'after' => $today,
            'inclusive' => true,
        ),
    ),
    'meta_query' => array(
        array(
            'key' => '_proposal_request_type',
            'compare' => 'EXISTS',
        ),
    ),
    'fields' => 'ids',
);
$today_requests = new WP_Query($today_args);
$total_today = $today_requests->found_posts;

// Get pending requests count
$pending_args = array(
    'post_type' => 'post',
    'posts_per_page' => -1,
    'post_status' => 'publish',
    'meta_query' => array(
        'relation' => 'OR',
        array(
            'key' => '_proposal_status',
            'compare' => 'NOT EXISTS',
        ),
        array(
            'key' => '_proposal_status',
            'value' => 'pending',
            'compare' => '=',
        ),
    ),
    'fields' => 'ids',
);
$pending_requests = new WP_Query($pending_args);
$total_pending = $pending_requests->found_posts;

// Get accepted requests count
$accepted_args = array(
    'post_type' => 'post',
    'posts_per_page' => -1,
    'post_status' => 'publish',
    'meta_query' => array(
        array(
            'key' => '_proposal_status',
            'value' => 'accepted',
            'compare' => '=',
        ),
    ),
    'fields' => 'ids',
);
$accepted_requests = new WP_Query($accepted_args);
$total_accepted = $accepted_requests->found_posts;

// Clean up count query objects - we don't need wp_reset_postdata() since we didn't loop
unset($all_requests, $maintenance_requests, $sell_requests, $today_requests, $pending_requests, $accepted_requests);
?>

<style>
.wheelfy-admin-request {
    margin: 20px 20px 0 0;
}

.wheelfy-admin-header {
    margin-bottom: 20px;
}

.wheelfy-admin-header h1 {
    font-size: 23px;
    font-weight: 400;
    margin: 0;
    padding: 9px 0 4px 0;
    line-height: 1.3;
}

.wheelfy-admin-header .description {
    margin: 0;
    color: #646970;
    font-size: 13px;
}

.wheelfy-kpi-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
    margin-bottom: 30px;
}

.wheelfy-kpi-card {
    background: #fff;
    border: 1px solid #c3c4c7;
    border-radius: 8px;
    padding: 20px;
    display: flex;
    align-items: center;
    gap: 16px;
    box-shadow: 0 1px 1px rgba(0,0,0,.04);
}

.kpi-icon {
    width: 56px;
    height: 56px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.kpi-content {
    flex: 1;
}

.kpi-label {
    font-size: 13px;
    color: #646970;
    margin-bottom: 4px;
}

.kpi-value {
    font-size: 28px;
    font-weight: 600;
    color: #1d2327;
    line-height: 1.2;
}

.wheelfy-subscription-tabs {
    margin: 0;
    padding: 0;
    border-bottom: 1px solid #c3c4c7;
}

.wheelfy-subscription-tabs .nav-tab {
    margin-left: 0;
    margin-bottom: -1px;
}

.wheelfy-subscription-tabs .nav-tab-active {
    border-bottom-color: #fff;
    background: #fff;
}

.wheelfy-dashboard-card {
    background: #fff;
    border: 1px solid #c3c4c7;
    border-radius: 4px;
    box-shadow: 0 1px 1px rgba(0,0,0,.04);
    margin-top: 20px;
    margin-bottom: 20px;
}

.card-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    padding: 20px;
    border-bottom: 1px solid #c3c4c7;
    flex-wrap: wrap;
    gap: 16px;
}

.header-filters {
    display: flex;
    gap: 10px;
    align-items: center;
    flex-wrap: wrap;
}

.search-input {
    padding: 6px 12px;
    border: 1px solid #8c8f94;
    border-radius: 4px;
    font-size: 14px;
    min-width: 200px;
}

.card-header h2 {
    font-size: 18px;
    font-weight: 600;
    margin: 0 0 4px 0;
    color: #1d2327;
}

.card-description {
    font-size: 13px;
    color: #646970;
    margin: 0;
}

.card-body {
    padding: 0;
}

@media (max-width: 782px) {
    .wheelfy-kpi-grid {
        grid-template-columns: 1fr;
    }
    
    .card-header {
        flex-direction: column;
        gap: 12px;
    }
}

/* Request Details Modal Styles */
.wheelfy-request-modal-overlay {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: rgba(0, 0, 0, 0.6);
    backdrop-filter: blur(4px);
    z-index: 100000;
    align-items: center;
    justify-content: center;
    padding: 20px;
}

.wheelfy-request-modal-overlay.active {
    display: flex;
}

.wheelfy-request-modal {
    background: #fff;
    border-radius: 4px;
    max-width: 800px;
    width: 100%;
    max-height: 90vh;
    overflow-y: auto;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
    border: 1px solid #c3c4c7;
    position: relative;
    animation: modalSlideIn 0.3s ease-out;
}

@keyframes modalSlideIn {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.wheelfy-request-modal-header {
    padding: 1.5rem 2rem;
    border-bottom: 1px solid #c3c4c7;
    display: flex;
    justify-content: space-between;
    align-items: center;
    background: #fff;
    border-radius: 4px 4px 0 0;
}

.wheelfy-request-modal-header h2 {
    margin: 0;
    font-size: 18px;
    font-weight: 600;
    color: #1d2327;
    display: flex;
    align-items: center;
    gap: 0.75rem;
}

.wheelfy-request-modal-close {
    background: transparent;
    border: none;
    font-size: 24px;
    cursor: pointer;
    color: #646970;
    padding: 4px;
    line-height: 1;
    border-radius: 4px;
    transition: all 0.2s;
    width: 32px;
    height: 32px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.wheelfy-request-modal-close:hover {
    background: #f0f0f1;
    color: #1d2327;
}

.wheelfy-request-modal-body {
    padding: 2rem;
}

.wheelfy-request-modal-section {
    margin-bottom: 2rem;
}

.wheelfy-request-modal-section:last-child {
    margin-bottom: 0;
}

.wheelfy-request-modal-section-title {
    font-size: 16px;
    font-weight: 600;
    color: #1d2327;
    margin: 0 0 1rem 0;
    padding-bottom: 0.5rem;
    border-bottom: 1px solid #c3c4c7;
}

.wheelfy-request-modal-info-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 1rem;
}

.wheelfy-request-modal-info-item {
    display: flex;
    flex-direction: column;
    gap: 0.25rem;
}

.wheelfy-request-modal-info-label {
    font-size: 13px;
    font-weight: 600;
    color: #646970;
    margin-bottom: 4px;
}

.wheelfy-request-modal-info-value {
    font-size: 14px;
    color: #1d2327;
    font-weight: 400;
}

.wheelfy-request-modal-info-value a {
    color: #2271b1;
    text-decoration: none;
}

.wheelfy-request-modal-info-value a:hover {
    color: #135e96;
    text-decoration: underline;
}

.wheelfy-request-modal-badge {
    display: inline-block;
    padding: 0.375rem 0.75rem;
    border-radius: 9999px;
    font-size: 0.875rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.05em;
}

.wheelfy-request-modal-badge.maintenance {
    background: #e8f5e9;
    color: #2e7d32;
    border: 1px solid #a5d6a7;
}

.wheelfy-request-modal-badge.sell {
    background: #fff3e0;
    color: #e65100;
    border: 1px solid #ffcc80;
}

.wheelfy-request-modal-description {
    background: #f6f7f7;
    padding: 12px;
    border-radius: 4px;
    border-left: 4px solid #2271b1;
    color: #1d2327;
    line-height: 1.6;
    white-space: pre-wrap;
    font-size: 14px;
}

.wheelfy-request-modal-full-width {
    grid-column: 1 / -1;
}

.wheelfy-request-modal-photos {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
    gap: 1rem;
    margin-top: 1rem;
}

.wheelfy-request-modal-photo-item {
    position: relative;
    aspect-ratio: 1;
    border-radius: 0.5rem;
    overflow: hidden;
    border: 2px solid #e5e7eb;
    cursor: pointer;
    transition: all 0.2s ease;
}

.wheelfy-request-modal-photo-item:hover {
    border-color: #2271b1;
    transform: translateY(-2px);
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.wheelfy-request-modal-photo-item img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.wheelfy-request-modal-photo-lightbox {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.9);
    z-index: 100001;
    align-items: center;
    justify-content: center;
    padding: 20px;
}

.wheelfy-request-modal-photo-lightbox.active {
    display: flex;
}

.wheelfy-request-modal-photo-lightbox img {
    max-width: 90%;
    max-height: 90%;
    object-fit: contain;
}

.wheelfy-request-modal-photo-lightbox-close {
    position: absolute;
    top: 20px;
    right: 20px;
    background: rgba(255, 255, 255, 0.2);
    border: none;
    color: white;
    font-size: 2rem;
    width: 40px;
    height: 40px;
    border-radius: 50%;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: background 0.2s;
}

.wheelfy-request-modal-photo-lightbox-close:hover {
    background: rgba(255, 255, 255, 0.3);
}

@media (max-width: 768px) {
    .wheelfy-request-modal-info-grid {
        grid-template-columns: 1fr;
    }
    
    .wheelfy-request-modal {
        margin: 10px;
        max-height: 95vh;
    }
    
    .wheelfy-request-modal-body {
        padding: 1.5rem;
    }
}
</style>

<div class="wrap wheelfy-admin-request">
    <!-- Header -->
    <div class="wheelfy-admin-header">
        <h1 class="wp-heading-inline"><?php _e('Request Management', 'wheelfy'); ?></h1>
        <p class="description"><?php _e('Manage all proposal requests and submissions from customers', 'wheelfy'); ?></p>
    </div>
    <hr class="wp-header-end">

    <!-- KPI Cards -->
    <div class="wheelfy-kpi-grid">
        <div class="wheelfy-kpi-card">
            <div class="kpi-icon" style="background: #e3f2fd; color: #1976d2;">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                </svg>
            </div>
            <div class="kpi-content">
                <div class="kpi-label"><?php _e('Total Requests', 'wheelfy'); ?></div>
                <div class="kpi-value"><?php echo number_format($total_requests); ?></div>
            </div>
        </div>

        <div class="wheelfy-kpi-card">
            <div class="kpi-icon" style="background: #e8f5e9; color: #388e3c;">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"></path>
                    <path d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path>
                </svg>
            </div>
            <div class="kpi-content">
                <div class="kpi-label"><?php _e('Maintenance Requests', 'wheelfy'); ?></div>
                <div class="kpi-value"><?php echo number_format($total_maintenance); ?></div>
            </div>
        </div>

        <div class="wheelfy-kpi-card">
            <div class="kpi-icon" style="background: #fff3e0; color: #f57c00;">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.4 2.9A3.7 3.7 0 0 0 2 12v4c0 .6.4 1 1 1h2"></path>
                    <circle cx="7" cy="17" r="2"></circle>
                    <path d="M9 17h6"></path>
                    <circle cx="17" cy="17" r="2"></circle>
                </svg>
            </div>
            <div class="kpi-content">
                <div class="kpi-label"><?php _e('Sell Car Requests', 'wheelfy'); ?></div>
                <div class="kpi-value"><?php echo number_format($total_sell); ?></div>
            </div>
        </div>

        <div class="wheelfy-kpi-card">
            <div class="kpi-icon" style="background: #f3e5f5; color: #7b1fa2;">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="12" cy="12" r="10"></circle>
                    <path d="M12 6v6l4 2"></path>
                </svg>
            </div>
            <div class="kpi-content">
                <div class="kpi-label"><?php _e('Today\'s Requests', 'wheelfy'); ?></div>
                <div class="kpi-value"><?php echo number_format($total_today); ?></div>
            </div>
        </div>
    </div>

    <!-- Tabs Navigation -->
    <nav class="nav-tab-wrapper wheelfy-subscription-tabs">
        <a href="<?php echo esc_url(add_query_arg('tab', 'all', admin_url('admin.php?page=wheelfy-request'))); ?>" 
           class="nav-tab <?php echo $current_tab === 'all' ? 'nav-tab-active' : ''; ?>" 
           data-tab="all">
            <?php _e('All Requests', 'wheelfy'); ?> (<?php echo number_format($total_requests); ?>)
        </a>
        <a href="<?php echo esc_url(add_query_arg('tab', 'in_progress', admin_url('admin.php?page=wheelfy-request'))); ?>" 
           class="nav-tab <?php echo $current_tab === 'in_progress' ? 'nav-tab-active' : ''; ?>" 
           data-tab="in_progress">
            <?php _e('In Progress', 'wheelfy'); ?>
        </a>
        <a href="<?php echo esc_url(add_query_arg('tab', 'pending_completion', admin_url('admin.php?page=wheelfy-request'))); ?>" 
           class="nav-tab <?php echo $current_tab === 'pending_completion' ? 'nav-tab-active' : ''; ?>" 
           data-tab="pending_completion">
            <?php _e('Pending Completion', 'wheelfy'); ?>
        </a>
        <a href="<?php echo esc_url(add_query_arg('tab', 'maintenance', admin_url('admin.php?page=wheelfy-request'))); ?>" 
           class="nav-tab <?php echo $current_tab === 'maintenance' ? 'nav-tab-active' : ''; ?>" 
           data-tab="maintenance">
            <?php _e('Maintenance Requests', 'wheelfy'); ?> (<?php echo number_format($total_maintenance); ?>)
        </a>
        <a href="<?php echo esc_url(add_query_arg('tab', 'sell', admin_url('admin.php?page=wheelfy-request'))); ?>" 
           class="nav-tab <?php echo $current_tab === 'sell' ? 'nav-tab-active' : ''; ?>" 
           data-tab="sell">
            <?php _e('Sell Car Requests', 'wheelfy'); ?> (<?php echo number_format($total_sell); ?>)
        </a>
    </nav>

    <div class="wheelfy-dashboard-card">
        <div class="card-header">
            <div>
                <h2>
                    <?php 
                    if ($current_tab === 'pending') {
                        _e('Pending Requests', 'wheelfy');
                    } elseif ($current_tab === 'accepted') {
                        _e('Accepted Requests', 'wheelfy');
                    } elseif ($current_tab === 'maintenance') {
                        _e('Maintenance Requests', 'wheelfy');
                    } elseif ($current_tab === 'sell') {
                        _e('Sell Car Requests', 'wheelfy');
                    } else {
                        _e('All Requests', 'wheelfy');
                    }
                    ?>
                </h2>
                <p class="card-description">
                    <?php 
                    if ($current_tab === 'pending') {
                        _e('Review and manage pending customer requests', 'wheelfy');
                    } elseif ($current_tab === 'accepted') {
                        _e('View all accepted customer requests', 'wheelfy');
                    } elseif ($current_tab === 'in_progress') {
                        _e('View requests that are currently being worked on by partners', 'wheelfy');
                    } elseif ($current_tab === 'pending_completion') {
                        _e('Review and confirm completed requests from partners', 'wheelfy');
                    } elseif ($current_tab === 'maintenance') {
                        _e('Manage car maintenance service requests from customers', 'wheelfy');
                    } elseif ($current_tab === 'sell') {
                        _e('Manage car selling requests from customers', 'wheelfy');
                    } else {
                        _e('View and manage all customer requests and submissions', 'wheelfy');
                    }
                    ?>
                </p>
            </div>
            <div class="header-filters">
                <input type="text" id="search-requests" class="search-input" placeholder="<?php esc_attr_e('Search requests...', 'wheelfy'); ?>">
            </div>
        </div>
        <div class="card-body">
        <?php
        // Query proposals based on current tab
        $args = array(
            'post_type' => 'post',
            'posts_per_page' => 20,
            'post_status' => 'publish', // Only show published posts (not trashed)
            'meta_query' => array(
                array(
                    'key' => '_proposal_request_type',
                    'compare' => 'EXISTS',
                ),
            ),
            'orderby' => 'date',
            'order' => 'DESC',
        );

        if ($current_tab === 'pending') {
            // Show only pending requests (status is pending or doesn't exist)
            $args['meta_query'] = array(
                'relation' => 'AND',
                array(
                    'key' => '_proposal_request_type',
                    'compare' => 'EXISTS',
                ),
                array(
                    'relation' => 'OR',
                    array(
                        'key' => '_proposal_status',
                        'compare' => 'NOT EXISTS',
                    ),
                    array(
                        'key' => '_proposal_status',
                        'value' => 'pending',
                        'compare' => '=',
                    ),
                ),
            );
        } elseif ($current_tab === 'accepted') {
            // Show only accepted requests
            $args['meta_query'] = array(
                'relation' => 'AND',
                array(
                    'key' => '_proposal_request_type',
                    'compare' => 'EXISTS',
                ),
                array(
                    'key' => '_proposal_status',
                    'value' => 'accepted',
                    'compare' => '=',
                ),
            );
        } elseif ($current_tab === 'pending_completion') {
            // Show only pending_completion requests
            $args['meta_query'] = array(
                'relation' => 'AND',
                array(
                    'key' => '_proposal_request_type',
                    'compare' => 'EXISTS',
                ),
                array(
                    'key' => '_proposal_status',
                    'value' => 'pending_completion',
                    'compare' => '=',
                ),
            );
        } elseif ($current_tab === 'maintenance') {
            $args['meta_query'][0]['value'] = 'maintenance';
            $args['meta_query'][0]['compare'] = '=';
        } elseif ($current_tab === 'sell') {
            $args['meta_query'][0]['value'] = 'sell';
            $args['meta_query'][0]['compare'] = '=';
        } else {
            // For 'all' tab, just check that the meta key exists
            $args['meta_query'][0]['compare'] = 'EXISTS';
        }

        // Ensure args are valid - add no_found_rows for better performance if needed
        if (!isset($args['fields'])) {
            $args['fields'] = 'all'; // Ensure fields is set explicitly
        }
        
        // Ensure meta_query is always an array
        if (!isset($args['meta_query']) || !is_array($args['meta_query'])) {
            $args['meta_query'] = array(
                array(
                    'key' => '_proposal_request_type',
                    'compare' => 'EXISTS',
                ),
            );
        }
        
        $proposals = new WP_Query($args);
        
        // Check if query was successful, has posts array, and has posts
        if ($proposals && isset($proposals->posts) && is_array($proposals->posts) && $proposals->have_posts()) :
        ?>
            <table class="wp-list-table widefat fixed striped table-view-list">
                <thead>
                    <tr>
                        <th><?php _e('Date', 'wheelfy'); ?></th>
                        <th><?php _e('Name', 'wheelfy'); ?></th>
                        <th><?php _e('Car Details', 'wheelfy'); ?></th>
                        <th><?php _e('Request Type', 'wheelfy'); ?></th>
                        <th><?php _e('Status', 'wheelfy'); ?></th>
                        <th><?php _e('Email', 'wheelfy'); ?></th>
                        <th><?php _e('Phone', 'wheelfy'); ?></th>
                        <th><?php _e('Actions', 'wheelfy'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($proposals->have_posts()) : $proposals->the_post(); 
                        $post_id = get_the_ID();
                        $request_type = get_post_meta($post_id, '_proposal_request_type', true);
                        $status = get_post_meta($post_id, '_proposal_status', true);
                        // Default to pending if status doesn't exist
                        if (empty($status)) {
                            $status = 'pending';
                        }
                        $full_name = get_post_meta($post_id, '_proposal_full_name', true);
                        $email = get_post_meta($post_id, '_proposal_email', true);
                        $phone = get_post_meta($post_id, '_proposal_phone', true);
                        $location = get_post_meta($post_id, '_proposal_location', true);
                        $car_brand = get_post_meta($post_id, '_proposal_car_brand', true);
                        $car_model = get_post_meta($post_id, '_proposal_car_model', true);
                        $car_year = get_post_meta($post_id, '_proposal_car_year', true);
                        $car_fuel_type = get_post_meta($post_id, '_proposal_fuel_type', true);
                        $car_mileage = get_post_meta($post_id, '_proposal_mileage', true);
                        $car_license_plate = get_post_meta($post_id, '_proposal_license_plate', true);
                        $service_type = get_post_meta($post_id, '_proposal_service_type', true);
                        $service_description = get_post_meta($post_id, '_proposal_service_description', true);
                        $preferred_date = get_post_meta($post_id, '_proposal_preferred_date', true);
                        $car_photos = get_post_meta($post_id, '_proposal_car_photos', true);
                        
                        // Get image URLs for car photos
                        $car_photo_urls = array();
                        if (!empty($car_photos) && is_array($car_photos)) {
                            foreach ($car_photos as $photo_id) {
                                if (is_numeric($photo_id)) {
                                    $image_url = wp_get_attachment_image_url($photo_id, 'medium');
                                    if ($image_url) {
                                        $car_photo_urls[] = array(
                                            'id' => $photo_id,
                                            'url' => $image_url,
                                            'full_url' => wp_get_attachment_image_url($photo_id, 'full')
                                        );
                                    }
                                }
                            }
                        }
                    ?>
                        <tr>
                            <td><?php echo get_the_date(); ?></td>
                            <td><strong><?php echo esc_html($full_name); ?></strong></td>
                            <td><?php echo esc_html($car_brand . ' ' . $car_model . ' (' . $car_year . ')'); ?></td>
                            <td><span class="badge"><?php echo esc_html(ucfirst($request_type)); ?></span></td>
                            <td>
                                <?php 
                                $status_class = '';
                                $status_text = '';
                                if ($status === 'accepted') {
                                    $status_class = 'background: #e8f5e9; color: #2e7d32; border: 1px solid #a5d6a7;';
                                    $status_text = __('Accepted', 'wheelfy');
                                } elseif ($status === 'in_progress') {
                                    $status_class = 'background: #fff9c4; color: #f57f17; border: 1px solid #fdd835;';
                                    $status_text = __('In Progress', 'wheelfy');
                                } elseif ($status === 'pending_completion') {
                                    $status_class = 'background: #e3f2fd; color: #1976d2; border: 1px solid #90caf9;';
                                    $status_text = __('Pending Completion', 'wheelfy');
                                } elseif ($status === 'complete' || $status === 'completed') {
                                    $status_class = 'background: #f3e5f5; color: #7b1fa2; border: 1px solid #ce93d8;';
                                    $status_text = __('Completed', 'wheelfy');
                                } else {
                                    $status_class = 'background: #fff3e0; color: #f57c00; border: 1px solid #ffcc80;';
                                    $status_text = __('Pending', 'wheelfy');
                                }
                                ?>
                                <span class="badge" style="display: inline-block; padding: 0.375rem 0.75rem; border-radius: 9999px; font-size: 0.875rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em; <?php echo $status_class; ?>">
                                    <?php echo $status_text; ?>
                                </span>
                            </td>
                            <td><?php echo esc_html($email); ?></td>
                            <td><?php echo esc_html($phone); ?></td>
                            <td>
                                <div style="display: flex; gap: 5px; align-items: center; flex-wrap: wrap;">
                                <button type="button" 
                                        class="button button-small view-request-btn" 
                                        data-post-id="<?php echo esc_attr($post_id); ?>"
                                        data-request-data='<?php 
                                            echo esc_attr(json_encode(array(
                                                'post_id' => $post_id,
                                                'full_name' => $full_name,
                                                'email' => $email,
                                                'phone' => $phone,
                                                'location' => $location,
                                                'request_type' => $request_type,
                                                'car_brand' => $car_brand,
                                                'car_model' => $car_model,
                                                'car_year' => $car_year,
                                                'car_fuel_type' => $car_fuel_type,
                                                'car_mileage' => $car_mileage,
                                                'car_license_plate' => $car_license_plate,
                                                'service_type' => $service_type,
                                                'service_description' => $service_description,
                                                'preferred_date' => $preferred_date,
                                                'car_photos' => $car_photo_urls,
                                                'date' => get_the_date('F j, Y g:i A')
                                            )));
                                        ?>'>
                                    View
                                </button>
                                    <?php if ($status === 'pending') : ?>
                                    <button type="button" 
                                            class="button button-small button-primary accept-request-btn" 
                                            data-post-id="<?php echo esc_attr($post_id); ?>"
                                            title="Accept Request">
                                        Accept
                                    </button>
                                    <?php elseif ($status === 'pending_completion') : 
                                        // Check if this is a new workflow request (customer should confirm, not admin)
                                        $offer_price = get_post_meta($post_id, '_proposal_offer_price', true);
                                        $workflow_version = get_post_meta($post_id, '_proposal_workflow_version', true);
                                        $is_new_workflow = ($workflow_version === 'v2' || floatval($offer_price) > 0);
                                        
                                        if ($is_new_workflow) : ?>
                                    <span class="button button-small" style="background: #f0f6fc; color: #0073aa; border-color: #c3c4c7; cursor: default;" title="Customer will confirm this request">
                                        ⏳ Waiting for Customer
                                    </span>
                                        <?php else : ?>
                                    <button type="button" 
                                            class="button button-small button-primary confirm-completion-btn" 
                                            data-post-id="<?php echo esc_attr($post_id); ?>"
                                            title="Confirm Completion">
                                        ✓ Confirm Completion
                                    </button>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    <button type="button" 
                                            class="button button-small delete-request-btn" 
                                            data-post-id="<?php echo esc_attr($post_id); ?>"
                                            style="color: #b32d2e; border-color: #b32d2e;"
                                            title="Delete Request">
                                        Delete
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else : ?>
            <div style="padding: 40px 20px; text-align: center; color: #646970;">
                <p style="font-size: 14px; margin: 0;">
                    <?php 
                    if ($current_tab === 'pending') {
                        _e('No pending requests found.', 'wheelfy');
                    } elseif ($current_tab === 'accepted') {
                        _e('No accepted requests found.', 'wheelfy');
                    } else {
                        _e('No requests found.', 'wheelfy');
                    }
                    ?>
                </p>
            </div>
        <?php 
        endif;
        
        // Properly reset post data after query loop
        if (isset($proposals) && $proposals) {
            wp_reset_postdata();
            // Clean up the query object
            unset($proposals);
        }
        ?>
        </div>
    </div>
</div>

<!-- Request Details Modal -->
<div id="wheelfy-request-modal" class="wheelfy-request-modal-overlay">
    <div class="wheelfy-request-modal">
        <div class="wheelfy-request-modal-header">
            <h2>
                <svg width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
                Request Details
            </h2>
            <button type="button" class="wheelfy-request-modal-close" aria-label="Close">&times;</button>
        </div>
        <div class="wheelfy-request-modal-body" id="wheelfy-request-modal-body">
            <!-- Content will be populated by JavaScript -->
        </div>
    </div>
</div>

<script>
(function() {
    const modal = document.getElementById('wheelfy-request-modal');
    const modalBody = document.getElementById('wheelfy-request-modal-body');
    const closeBtn = document.querySelector('.wheelfy-request-modal-close');
    const viewButtons = document.querySelectorAll('.view-request-btn');

    // Helper function to escape HTML
    function escapeHtml(text) {
        if (!text) return 'N/A';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    function openModal(data) {
        const requestData = typeof data === 'string' ? JSON.parse(data) : data;
        
        let html = '';
        
        // Contact Information Section
        html += '<div class="wheelfy-request-modal-section">';
        html += '<h3 class="wheelfy-request-modal-section-title">Contact Information</h3>';
        html += '<div class="wheelfy-request-modal-info-grid">';
        html += '<div class="wheelfy-request-modal-info-item"><span class="wheelfy-request-modal-info-label">Full Name</span><span class="wheelfy-request-modal-info-value">' + escapeHtml(requestData.full_name || 'N/A') + '</span></div>';
        html += '<div class="wheelfy-request-modal-info-item"><span class="wheelfy-request-modal-info-label">Email</span><span class="wheelfy-request-modal-info-value"><a href="mailto:' + escapeHtml(requestData.email || '') + '">' + escapeHtml(requestData.email || 'N/A') + '</a></span></div>';
        html += '<div class="wheelfy-request-modal-info-item"><span class="wheelfy-request-modal-info-label">Phone</span><span class="wheelfy-request-modal-info-value"><a href="tel:' + escapeHtml(requestData.phone || '') + '">' + escapeHtml(requestData.phone || 'N/A') + '</a></span></div>';
        if (requestData.location) {
            html += '<div class="wheelfy-request-modal-info-item"><span class="wheelfy-request-modal-info-label">Location</span><span class="wheelfy-request-modal-info-value">' + escapeHtml(requestData.location) + '</span></div>';
        }
        html += '<div class="wheelfy-request-modal-info-item"><span class="wheelfy-request-modal-info-label">Request Type</span><span class="wheelfy-request-modal-info-value"><span class="wheelfy-request-modal-badge ' + escapeHtml(requestData.request_type || '') + '">' + (requestData.request_type ? escapeHtml(requestData.request_type.charAt(0).toUpperCase() + requestData.request_type.slice(1)) : 'N/A') + '</span></span></div>';
        html += '<div class="wheelfy-request-modal-info-item"><span class="wheelfy-request-modal-info-label">Submitted Date</span><span class="wheelfy-request-modal-info-value">' + escapeHtml(requestData.date || 'N/A') + '</span></div>';
        html += '</div></div>';
        
        // Car Details Section
        html += '<div class="wheelfy-request-modal-section">';
        html += '<h3 class="wheelfy-request-modal-section-title">Car Details</h3>';
        html += '<div class="wheelfy-request-modal-info-grid">';
        html += '<div class="wheelfy-request-modal-info-item"><span class="wheelfy-request-modal-info-label">Brand</span><span class="wheelfy-request-modal-info-value">' + escapeHtml(requestData.car_brand || 'N/A') + '</span></div>';
        html += '<div class="wheelfy-request-modal-info-item"><span class="wheelfy-request-modal-info-label">Model</span><span class="wheelfy-request-modal-info-value">' + escapeHtml(requestData.car_model || 'N/A') + '</span></div>';
        html += '<div class="wheelfy-request-modal-info-item"><span class="wheelfy-request-modal-info-label">Year</span><span class="wheelfy-request-modal-info-value">' + escapeHtml(requestData.car_year || 'N/A') + '</span></div>';
        html += '<div class="wheelfy-request-modal-info-item"><span class="wheelfy-request-modal-info-label">Fuel Type</span><span class="wheelfy-request-modal-info-value">' + escapeHtml(requestData.car_fuel_type || 'N/A') + '</span></div>';
        if (requestData.car_mileage) {
            html += '<div class="wheelfy-request-modal-info-item"><span class="wheelfy-request-modal-info-label">Mileage</span><span class="wheelfy-request-modal-info-value">' + escapeHtml(requestData.car_mileage) + ' km</span></div>';
        }
        if (requestData.car_license_plate) {
            html += '<div class="wheelfy-request-modal-info-item"><span class="wheelfy-request-modal-info-label">License Plate</span><span class="wheelfy-request-modal-info-value">' + escapeHtml(requestData.car_license_plate) + '</span></div>';
        }
        html += '</div></div>';
        
        // Service/Request Details Section
        if (requestData.request_type === 'maintenance') {
            html += '<div class="wheelfy-request-modal-section">';
            html += '<h3 class="wheelfy-request-modal-section-title">Service Information</h3>';
            html += '<div class="wheelfy-request-modal-info-grid">';
            if (requestData.service_type) {
                html += '<div class="wheelfy-request-modal-info-item"><span class="wheelfy-request-modal-info-label">Service Type</span><span class="wheelfy-request-modal-info-value">' + escapeHtml(requestData.service_type) + '</span></div>';
            }
            if (requestData.preferred_date) {
                html += '<div class="wheelfy-request-modal-info-item"><span class="wheelfy-request-modal-info-label">Preferred Date</span><span class="wheelfy-request-modal-info-value">' + escapeHtml(requestData.preferred_date) + '</span></div>';
            }
            html += '</div>';
            if (requestData.service_description) {
                html += '<div class="wheelfy-request-modal-info-item wheelfy-request-modal-full-width" style="margin-top: 1rem;"><span class="wheelfy-request-modal-info-label">Description</span><div class="wheelfy-request-modal-description">' + escapeHtml(requestData.service_description) + '</div></div>';
            }
            html += '</div>';
        } else if (requestData.request_type === 'sell') {
            html += '<div class="wheelfy-request-modal-section">';
            html += '<h3 class="wheelfy-request-modal-section-title">Additional Details</h3>';
            if (requestData.service_description) {
                html += '<div class="wheelfy-request-modal-info-item"><span class="wheelfy-request-modal-info-label">Description</span><div class="wheelfy-request-modal-description">' + escapeHtml(requestData.service_description) + '</div></div>';
            }
            html += '</div>';
        }
        
        // Car Photos Section (for sell requests)
        if (requestData.request_type === 'sell' && requestData.car_photos && requestData.car_photos.length > 0) {
            html += '<div class="wheelfy-request-modal-section">';
            html += '<h3 class="wheelfy-request-modal-section-title">Car Photos</h3>';
            html += '<div class="wheelfy-request-modal-photos">';
            requestData.car_photos.forEach(function(photo, index) {
                html += '<div class="wheelfy-request-modal-photo-item" data-full-url="' + escapeHtml(photo.full_url || photo.url) + '">';
                html += '<img src="' + escapeHtml(photo.url) + '" alt="Car Photo ' + (index + 1) + '" />';
                html += '</div>';
            });
            html += '</div>';
            html += '</div>';
        }

        modalBody.innerHTML = html;
        modal.classList.add('active');
        document.body.style.overflow = 'hidden';
        
        // Add photo lightbox functionality
        const photoItems = modalBody.querySelectorAll('.wheelfy-request-modal-photo-item');
        photoItems.forEach(function(item) {
            item.addEventListener('click', function() {
                const fullUrl = this.getAttribute('data-full-url');
                if (fullUrl) {
                    openPhotoLightbox(fullUrl);
                }
            });
        });
    }
    
    function openPhotoLightbox(imageUrl) {
        let lightbox = document.getElementById('wheelfy-request-photo-lightbox');
        if (!lightbox) {
            lightbox = document.createElement('div');
            lightbox.id = 'wheelfy-request-photo-lightbox';
            lightbox.className = 'wheelfy-request-modal-photo-lightbox';
            lightbox.innerHTML = '<img src="" alt="Car Photo" /><button type="button" class="wheelfy-request-modal-photo-lightbox-close">&times;</button>';
            document.body.appendChild(lightbox);
            
            const closeBtn = lightbox.querySelector('.wheelfy-request-modal-photo-lightbox-close');
            closeBtn.addEventListener('click', function() {
                lightbox.classList.remove('active');
                document.body.style.overflow = '';
            });
            
            lightbox.addEventListener('click', function(e) {
                if (e.target === lightbox) {
                    lightbox.classList.remove('active');
                    document.body.style.overflow = '';
                }
            });
            
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape' && lightbox.classList.contains('active')) {
                    lightbox.classList.remove('active');
                    document.body.style.overflow = '';
                }
            });
        }
        
        lightbox.querySelector('img').src = imageUrl;
        lightbox.classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    function closeModal() {
        modal.classList.remove('active');
        document.body.style.overflow = '';
        modalBody.innerHTML = '';
    }

    // Event listeners
    viewButtons.forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            const data = this.getAttribute('data-request-data');
            openModal(data);
        });
    });

    if (closeBtn) {
        closeBtn.addEventListener('click', closeModal);
    }

    // Close on overlay click
    modal.addEventListener('click', function(e) {
        if (e.target === modal) {
            closeModal();
        }
    });

    // Close on ESC key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && modal.classList.contains('active')) {
            closeModal();
        }
    });
    
    // Handle Accept Request
    document.querySelectorAll('.accept-request-btn').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            const postId = this.getAttribute('data-post-id');
            const row = this.closest('tr');
            const button = this;
            
            if (!confirm('Are you sure you want to accept this request?')) {
                return;
            }
            
            // Disable button during request
            button.disabled = true;
            button.textContent = 'Processing...';
            
            // Send AJAX request
            const formData = new FormData();
            formData.append('action', 'wheelfy_accept_request');
            formData.append('post_id', postId);
            formData.append('nonce', '<?php echo wp_create_nonce("wheelfy_request_action"); ?>');
            
            fetch(ajaxurl, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Update UI
                    row.style.opacity = '0.7';
                    row.style.backgroundColor = '#e8f5e9';
                    button.textContent = 'Accepted';
                    button.classList.remove('button-primary');
                    button.classList.add('button-secondary');
                    button.disabled = true;
                    
                    // Show success message
                    if (data.data && data.data.message) {
                        alert(data.data.message);
                    }
                    
                    // Reload page after 1 second to refresh data
                    setTimeout(function() {
                        window.location.reload();
                    }, 1000);
                } else {
                    alert(data.data && data.data.message ? data.data.message : 'Failed to accept request. Please try again.');
                    button.disabled = false;
                    button.textContent = 'Accept';
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred. Please try again.');
                button.disabled = false;
                button.textContent = 'Accept';
            });
        });
    });
    
    // Handle Confirm Completion
    document.querySelectorAll('.confirm-completion-btn').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            const postId = this.getAttribute('data-post-id');
            const row = this.closest('tr');
            const button = this;
            
            if (!confirm('Are you sure you want to confirm this request as completed? The customer will be notified.')) {
                return;
            }
            
            // Disable button during request
            button.disabled = true;
            button.textContent = 'Processing...';
            
            // Send AJAX request
            const formData = new FormData();
            formData.append('action', 'wheelfy_confirm_completion');
            formData.append('post_id', postId);
            formData.append('nonce', '<?php echo wp_create_nonce("wheelfy_request_action"); ?>');
            
            fetch(ajaxurl, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Update UI
                    row.style.opacity = '0.7';
                    row.style.backgroundColor = '#f3e5f5';
                    button.textContent = 'Completed';
                    button.classList.remove('button-primary');
                    button.classList.add('button-secondary');
                    button.disabled = true;
                    
                    // Update status badge
                    const statusCell = row.querySelector('td:nth-child(5)');
                    if (statusCell) {
                        statusCell.innerHTML = '<span class="badge" style="display: inline-block; padding: 0.375rem 0.75rem; border-radius: 9999px; font-size: 0.875rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em; background: #f3e5f5; color: #7b1fa2; border: 1px solid #ce93d8;">Completed</span>';
                    }
                    
                    // Show success message
                    if (data.data && data.data.message) {
                        alert(data.data.message);
                    }
                    
                    // Reload page after 1 second to refresh data
                    setTimeout(function() {
                        window.location.reload();
                    }, 1000);
                } else {
                    alert(data.data && data.data.message ? data.data.message : 'Failed to confirm completion. Please try again.');
                    button.disabled = false;
                    button.textContent = '✓ Confirm Completion';
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred. Please try again.');
                button.disabled = false;
                button.textContent = '✓ Confirm Completion';
            });
        });
    });
    
    // Handle Delete Request
    document.querySelectorAll('.delete-request-btn').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            const postId = this.getAttribute('data-post-id');
            const row = this.closest('tr');
            const button = this;
            
            if (!confirm('Are you sure you want to delete this request? This action cannot be undone.')) {
                return;
            }
            
            // Disable button during request
            button.disabled = true;
            button.textContent = 'Deleting...';
            
            // Send AJAX request
            const formData = new FormData();
            formData.append('action', 'wheelfy_delete_request');
            formData.append('post_id', postId);
            formData.append('nonce', '<?php echo wp_create_nonce("wheelfy_request_action"); ?>');
            
            fetch(ajaxurl, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Animate row removal
                    row.style.transition = 'opacity 0.3s ease';
                    row.style.opacity = '0';
                    
                    setTimeout(function() {
                        row.remove();
                        
                        // Check if table is empty
                        const tbody = document.querySelector('.wp-list-table tbody');
                        if (tbody && tbody.children.length === 0) {
                            tbody.innerHTML = '<tr><td colspan="8" style="padding: 40px 20px; text-align: center; color: #646970;"><p style="font-size: 14px; margin: 0;">No requests found.</p></td></tr>';
                        }
                    }, 300);
                } else {
                    alert(data.data && data.data.message ? data.data.message : 'Failed to delete request. Please try again.');
                    button.disabled = false;
                    button.textContent = 'Delete';
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred. Please try again.');
                button.disabled = false;
                button.textContent = 'Delete';
            });
        });
    });
    
    // Fix search to work without jQuery dependency (fallback to vanilla JS)
    const searchInput = document.getElementById('search-requests');
    if (searchInput) {
        let searchTimeout;
        
        searchInput.addEventListener('input', function(e) {
            clearTimeout(searchTimeout);
            const searchTerm = this.value.trim().toLowerCase();
            
            const table = document.querySelector('.table-view-list tbody');
            if (!table) return;
            
            const rows = table.querySelectorAll('tr');
            
            if (searchTerm.length < 2) {
                // Show all rows
                rows.forEach(row => {
                    row.style.display = '';
                });
                return;
            }
            
            searchTimeout = setTimeout(function() {
                rows.forEach(row => {
                    const cells = row.querySelectorAll('td');
                    if (cells.length < 7) return;
                    
                    const name = (cells[1].textContent || '').toLowerCase();
                    const carDetails = (cells[2].textContent || '').toLowerCase();
                    const requestType = (cells[3].textContent || '').toLowerCase();
                    const email = (cells[5].textContent || '').toLowerCase();
                    const phone = (cells[6].textContent || '').toLowerCase();
                    
                    const fullText = (name + ' ' + carDetails + ' ' + requestType + ' ' + email + ' ' + phone).toLowerCase();
                    
                    if (fullText.indexOf(searchTerm) > -1) {
                        row.style.display = '';
                    } else {
                        row.style.display = 'none';
                    }
                });
            }, 300);
        });
    }
    
    // Search functionality with autocomplete/suggestions (jQuery version - kept for compatibility)
    let searchTimeout;
    const $searchInput = jQuery('#search-requests');
    const $searchWrapper = $searchInput.parent();
    
    // Create suggestions dropdown
    if (jQuery('#search-suggestions').length === 0) {
        $searchWrapper.css('position', 'relative');
        $searchWrapper.append('<div id="search-suggestions" style="display:none;position:absolute;top:100%;left:0;right:0;background:#fff;border:1px solid #8c8f94;border-top:none;border-radius:0 0 4px 4px;max-height:300px;overflow-y:auto;z-index:1000;box-shadow:0 2px 8px rgba(0,0,0,0.1);"></div>');
    }
    
    const $suggestions = jQuery('#search-suggestions');
    
    $searchInput.on('keyup', function(e) {
        clearTimeout(searchTimeout);
        const searchTerm = jQuery(this).val().trim();
        
        // Clear suggestions if less than 2 characters
        if (searchTerm.length < 2) {
            $suggestions.hide().empty();
            // Show all rows
            jQuery('.table-view-list tbody tr').show();
            return;
        }
        
        searchTimeout = setTimeout(function() {
            const searchLower = searchTerm.toLowerCase();
            const table = jQuery('.table-view-list tbody');
            const matches = [];
            
            table.find('tr').each(function() {
                const $row = jQuery(this);
                const name = $row.find('td:nth-child(2) strong').text().toLowerCase();
                const carDetails = $row.find('td:nth-child(3)').text().toLowerCase();
                const requestType = $row.find('td:nth-child(4)').text().toLowerCase();
                const email = $row.find('td:nth-child(6)').text().toLowerCase();
                const phone = $row.find('td:nth-child(7)').text().toLowerCase();
                const fullText = (name + ' ' + carDetails + ' ' + requestType + ' ' + email + ' ' + phone).toLowerCase();
                
                if (fullText.indexOf(searchLower) > -1) {
                    $row.show();
                    matches.push({
                        name: $row.find('td:nth-child(2) strong').text(),
                        carDetails: $row.find('td:nth-child(3)').text(),
                        email: $row.find('td:nth-child(6)').text(),
                        row: $row
                    });
                } else {
                    $row.hide();
                }
            });
            
            // Show suggestions
            if (matches.length > 0 && matches.length <= 10) {
                $suggestions.empty();
                matches.forEach(function(match) {
                    const $suggestion = jQuery('<div class="search-suggestion-item" style="padding:8px 12px;cursor:pointer;border-bottom:1px solid #f0f0f0;"></div>');
                    $suggestion.html('<strong>' + match.name + '</strong><br><small style="color:#666;">' + match.carDetails + ' - ' + match.email + '</small>');
                    
                    $suggestion.on('mouseenter', function() {
                        jQuery(this).css('background', '#f6f7f7');
                    }).on('mouseleave', function() {
                        jQuery(this).css('background', '#fff');
                    });
                    
                    $suggestion.on('click', function() {
                        $searchInput.val(match.name);
                        $suggestions.hide();
                        // Show only this row
                        table.find('tr').hide();
                        match.row.show();
                    });
                    
                    $suggestions.append($suggestion);
                });
                $suggestions.show();
            } else {
                $suggestions.hide();
            }
        }, 300);
    });
    
    // Hide suggestions when clicking outside
    jQuery(document).on('click', function(e) {
        if (!jQuery(e.target).closest('.header-filters').length) {
            $suggestions.hide();
        }
    });
    
    // Clear search
    $searchInput.on('focus', function() {
        if (jQuery(this).val().length >= 2) {
            jQuery(this).trigger('keyup');
        }
    });
})();
</script>
