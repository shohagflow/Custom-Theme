<?php
/**
 * Admin Reviews & Ratings Control Page
 * 
 * @package Wheelfy
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!current_user_can('administrator')) {
    wp_die(__('You do not have permission to access this page.', 'wheelfy'));
}

// Load reviews functions if not already loaded
if (!function_exists('wheelfy_get_all_reviews_for_moderation')) {
    require_once get_template_directory() . '/admin/admin-reviews-functions.php';
}

$current_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'all';
if (!in_array($current_tab, array('all', 'pending', 'reported', 'ratings'))) {
    $current_tab = 'all';
}

// Get filters
$status_filter = 'all';
if ($current_tab === 'pending') {
    $status_filter = 'pending';
} elseif ($current_tab === 'reported') {
    $status_filter = 'reported';
}

// Get real reviews data
$reviews_filters = array();
if ($status_filter !== 'all') {
    $reviews_filters['status'] = $status_filter;
}

// Check if filtering by partner_id (from "View Reviews" button)
$partner_id_filter = isset($_GET['partner_id']) ? intval($_GET['partner_id']) : 0;
if ($partner_id_filter > 0) {
    $reviews_filters['partner_id'] = $partner_id_filter;
}

$all_reviews = wheelfy_get_all_reviews_for_moderation($reviews_filters);

// For "reported" tab, filter by reported status
if ($current_tab === 'reported') {
    $all_reviews = array_filter($all_reviews, function($r) {
        return isset($r['reported']) && $r['reported'] === true;
    });
    $all_reviews = array_values($all_reviews);
}

// Calculate statistics from real data
$total_reviews = count($all_reviews);
$pending_reviews = count(array_filter($all_reviews, function($r) { return isset($r['status']) && $r['status'] === 'pending'; }));
$reported_reviews = count(array_filter($all_reviews, function($r) { return isset($r['reported']) && $r['reported'] === true; }));
$approved_reviews = count(array_filter($all_reviews, function($r) { return isset($r['status']) && $r['status'] === 'approved'; }));
$rejected_reviews = count(array_filter($all_reviews, function($r) { return isset($r['status']) && $r['status'] === 'rejected'; }));

// Calculate average rating
$total_rating_sum = array_sum(array_column($all_reviews, 'rating'));
$average_rating = $total_reviews > 0 ? round($total_rating_sum / $total_reviews, 1) : 0;

// Rating distribution
$rating_distribution = array(
    5 => count(array_filter($all_reviews, function($r) { return isset($r['rating']) && $r['rating'] === 5; })),
    4 => count(array_filter($all_reviews, function($r) { return isset($r['rating']) && $r['rating'] === 4; })),
    3 => count(array_filter($all_reviews, function($r) { return isset($r['rating']) && $r['rating'] === 3; })),
    2 => count(array_filter($all_reviews, function($r) { return isset($r['rating']) && $r['rating'] === 2; })),
    1 => count(array_filter($all_reviews, function($r) { return isset($r['rating']) && $r['rating'] === 1; })),
);

// Get real partner ratings data
$partner_ratings = wheelfy_get_partner_ratings_for_moderation();
?>
<div class="wrap wheelfy-admin-reviews">
    <!-- Header -->
    <div class="wheelfy-admin-header">
        <div>
            <h1 class="wp-heading-inline"><?php _e('Review & Rating Control', 'wheelfy'); ?></h1>
            <p class="description"><?php _e('Manage customer reviews, moderate content, and monitor partner ratings', 'wheelfy'); ?></p>
        </div>
    </div>
    <hr class="wp-header-end">

    <!-- KPI Cards -->
    <div class="wheelfy-kpi-grid">
        <div class="wheelfy-kpi-card">
            <div class="kpi-icon" style="background: #e3f2fd; color: #1976d2;">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
                </svg>
            </div>
            <div class="kpi-content">
                <div class="kpi-label"><?php _e('Total Reviews', 'wheelfy'); ?></div>
                <div class="kpi-value"><?php echo number_format($total_reviews); ?></div>
            </div>
        </div>

        <div class="wheelfy-kpi-card">
            <div class="kpi-icon" style="background: #fff3e0; color: #f57c00;">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="12" cy="12" r="10"></circle>
                    <path d="M12 6v6l4 2"></path>
                </svg>
            </div>
            <div class="kpi-content">
                <div class="kpi-label"><?php _e('Pending Reviews', 'wheelfy'); ?></div>
                <div class="kpi-value"><?php echo number_format($pending_reviews); ?></div>
            </div>
        </div>

        <div class="wheelfy-kpi-card">
            <div class="kpi-icon" style="background: #fff8e1; color: #f9a825;">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
                </svg>
            </div>
            <div class="kpi-content">
                <div class="kpi-label"><?php _e('Average Rating', 'wheelfy'); ?></div>
                <div class="kpi-value"><?php echo number_format($average_rating, 1); ?></div>
            </div>
        </div>

        <div class="wheelfy-kpi-card">
            <div class="kpi-icon" style="background: #ffebee; color: #c62828;">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path>
                    <line x1="12" y1="9" x2="12" y2="13"></line>
                    <line x1="12" y1="17" x2="12.01" y2="17"></line>
                </svg>
            </div>
            <div class="kpi-content">
                <div class="kpi-label"><?php _e('Reported Reviews', 'wheelfy'); ?></div>
                <div class="kpi-value"><?php echo number_format($reported_reviews); ?></div>
            </div>
        </div>
    </div>

    <!-- Tabs Navigation -->
    <nav class="nav-tab-wrapper wheelfy-subscription-tabs">
        <a href="<?php echo esc_url(add_query_arg('tab', 'all', admin_url('admin.php?page=wheelfy-reviews'))); ?>" 
           class="nav-tab <?php echo $current_tab === 'all' ? 'nav-tab-active' : ''; ?>" 
           data-tab="all">
            <?php _e('All Reviews', 'wheelfy'); ?>
        </a>
        <a href="<?php echo esc_url(add_query_arg('tab', 'pending', admin_url('admin.php?page=wheelfy-reviews'))); ?>" 
           class="nav-tab <?php echo $current_tab === 'pending' ? 'nav-tab-active' : ''; ?>" 
           data-tab="pending">
            <?php _e('Pending Reviews', 'wheelfy'); ?>
        </a>
        <a href="<?php echo esc_url(add_query_arg('tab', 'reported', admin_url('admin.php?page=wheelfy-reviews'))); ?>" 
           class="nav-tab <?php echo $current_tab === 'reported' ? 'nav-tab-active' : ''; ?>" 
           data-tab="reported">
            <?php _e('Reported Reviews', 'wheelfy'); ?>
        </a>
        <a href="<?php echo esc_url(add_query_arg('tab', 'ratings', admin_url('admin.php?page=wheelfy-reviews'))); ?>" 
           class="nav-tab <?php echo $current_tab === 'ratings' ? 'nav-tab-active' : ''; ?>" 
           data-tab="ratings">
            <?php _e('Partner Ratings', 'wheelfy'); ?>
        </a>
    </nav>

    <!-- All Reviews Tab -->
    <div class="wheelfy-tab-content <?php echo $current_tab === 'all' ? 'active' : ''; ?>" id="tab-all">
        <div class="wheelfy-dashboard-card">
            <div class="card-header">
                <div>
                    <h2><?php _e('All Reviews', 'wheelfy'); ?></h2>
                    <p class="card-description">
                        <?php 
                        if ($partner_id_filter > 0) {
                            $partner = get_userdata($partner_id_filter);
                            $partner_name = $partner ? ($partner->display_name ?: $partner->user_login) : __('Unknown Partner', 'wheelfy');
                            $business_name = get_user_meta($partner_id_filter, 'business_name', true);
                            if (!empty($business_name)) {
                                $partner_name = $business_name;
                            }
                            echo sprintf(__('Showing reviews for partner: %s', 'wheelfy'), '<strong>' . esc_html($partner_name) . '</strong>');
                            echo ' <a href="' . esc_url(remove_query_arg('partner_id', admin_url('admin.php?page=wheelfy-reviews&tab=all'))) . '" style="margin-left: 10px; color: #2271b1; text-decoration: none;">' . __('Show All Reviews', 'wheelfy') . '</a>';
                        } else {
                            _e('View and manage all customer reviews', 'wheelfy');
                        }
                        ?>
                    </p>
                </div>
                <div class="header-filters">
                    <input type="text" id="search-reviews" class="search-input" placeholder="<?php esc_attr_e('Search reviews...', 'wheelfy'); ?>">
                    <select id="filter-rating" class="filter-select">
                        <option value="all"><?php _e('All Ratings', 'wheelfy'); ?></option>
                        <option value="5">5 Stars</option>
                        <option value="4">4 Stars</option>
                        <option value="3">3 Stars</option>
                        <option value="2">2 Stars</option>
                        <option value="1">1 Star</option>
                    </select>
                    <select id="filter-status" class="filter-select">
                        <option value="all"><?php _e('All Status', 'wheelfy'); ?></option>
                        <option value="approved"><?php _e('Approved', 'wheelfy'); ?></option>
                        <option value="pending"><?php _e('Pending', 'wheelfy'); ?></option>
                        <option value="rejected"><?php _e('Rejected', 'wheelfy'); ?></option>
                    </select>
                </div>
            </div>
            <div class="card-body">
                <table class="wp-list-table widefat fixed striped table-view-list">
                    <thead>
                        <tr>
                            <th class="column-id"><?php _e('#', 'wheelfy'); ?></th>
                            <th class="column-customer"><?php _e('Customer', 'wheelfy'); ?></th>
                            <th class="column-partner"><?php _e('Partner', 'wheelfy'); ?></th>
                            <th class="column-service"><?php _e('Service', 'wheelfy'); ?></th>
                            <th class="column-rating"><?php _e('Rating', 'wheelfy'); ?></th>
                            <th class="column-comment"><?php _e('Comment', 'wheelfy'); ?></th>
                            <th class="column-status"><?php _e('Status', 'wheelfy'); ?></th>
                            <th class="column-date"><?php _e('Date', 'wheelfy'); ?></th>
                            <th class="column-actions"><?php _e('Actions', 'wheelfy'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        if (!empty($all_reviews)) :
                        $review_count = 0;
                            foreach ($all_reviews as $review) : 
                            $review_count++;
                                $review_id = isset($review['review_id']) ? $review['review_id'] : (isset($review['id']) ? $review['id'] : '');
                                $review_status = isset($review['status']) ? $review['status'] : 'approved';
                        ?>
                            <tr data-review-id="<?php echo esc_attr($review_id); ?>" data-review-status="<?php echo esc_attr($review_status); ?>">
                                <td class="column-id"><?php echo $review_count; ?></td>
                                <td class="column-customer"><strong><?php echo esc_html($review['customer_name']); ?></strong></td>
                                <td class="column-partner"><?php echo esc_html($review['partner_name']); ?></td>
                                <td class="column-service"><?php echo esc_html($review['service'] ?: '-'); ?></td>
                                <td class="column-rating">
                                    <div class="rating-stars">
                                        <?php 
                                        $rating = isset($review['rating']) ? intval($review['rating']) : 0;
                                        for ($i = 1; $i <= 5; $i++) : ?>
                                            <span class="star <?php echo $i <= $rating ? 'filled' : ''; ?>">★</span>
                                        <?php endfor; ?>
                                        <span class="rating-number">(<?php echo $rating; ?>)</span>
                                    </div>
                                </td>
                                <td class="column-comment"><?php 
                                    $comment = isset($review['review_text']) ? $review['review_text'] : '';
                                    echo esc_html(mb_substr($comment, 0, 60)) . (mb_strlen($comment) > 60 ? '...' : ''); 
                                ?></td>
                                <td class="column-status">
                                    <span class="status-badge status-<?php echo esc_attr($review_status); ?>">
                                        <?php echo esc_html(ucfirst($review_status)); ?>
                                    </span>
                                    <?php if (isset($review['reported']) && $review['reported']) : ?>
                                        <span class="dashicons dashicons-flag reported-flag" title="<?php esc_attr_e('Reported', 'wheelfy'); ?>"></span>
                                    <?php endif; ?>
                                </td>
                                <td class="column-date"><?php echo esc_html($review['created_date'] ?: '-'); ?></td>
                                <td class="column-actions">
                                    <div class="row-actions">
                                        <?php if ($review_status === 'pending') : ?>
                                            <a href="javascript:void(0);" class="button button-small button-primary wheelfy-approve-review" data-review-id="<?php echo esc_attr($review_id); ?>"><?php _e('Approve', 'wheelfy'); ?></a>
                                            <a href="javascript:void(0);" class="button button-small wheelfy-reject-review" data-review-id="<?php echo esc_attr($review_id); ?>"><?php _e('Reject', 'wheelfy'); ?></a>
                                        <?php endif; ?>
                                        <a href="javascript:void(0);" class="button button-small button-link-delete wheelfy-delete-review" data-review-id="<?php echo esc_attr($review_id); ?>"><?php _e('Delete', 'wheelfy'); ?></a>
                                    </div>
                                </td>
                            </tr>
                        <?php 
                            endforeach;
                        else :
                        ?>
                            <tr>
                                <td colspan="9" style="text-align: center; padding: 40px;">
                                    <?php _e('No reviews found.', 'wheelfy'); ?>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Pending Reviews Tab -->
    <div class="wheelfy-tab-content <?php echo $current_tab === 'pending' ? 'active' : ''; ?>" id="tab-pending">
        <div class="wheelfy-dashboard-card">
            <div class="card-header">
                <div>
                    <h2><?php _e('Pending Reviews', 'wheelfy'); ?></h2>
                    <p class="card-description"><?php _e('Reviews awaiting moderation', 'wheelfy'); ?></p>
                </div>
                <div class="header-filters">
                    <input type="text" id="search-pending" class="search-input" placeholder="<?php esc_attr_e('Search reviews...', 'wheelfy'); ?>">
                    <select id="filter-pending-rating" class="filter-select">
                        <option value="all"><?php _e('All Ratings', 'wheelfy'); ?></option>
                        <option value="5">5 Stars</option>
                        <option value="4">4 Stars</option>
                        <option value="3">3 Stars</option>
                        <option value="2">2 Stars</option>
                        <option value="1">1 Star</option>
                    </select>
                </div>
            </div>
            <div class="card-body">
                <table class="wp-list-table widefat fixed striped table-view-list">
                    <thead>
                        <tr>
                            <th class="column-id"><?php _e('#', 'wheelfy'); ?></th>
                            <th class="column-customer"><?php _e('Customer', 'wheelfy'); ?></th>
                            <th class="column-partner"><?php _e('Partner', 'wheelfy'); ?></th>
                            <th class="column-service"><?php _e('Service', 'wheelfy'); ?></th>
                            <th class="column-rating"><?php _e('Rating', 'wheelfy'); ?></th>
                            <th class="column-comment"><?php _e('Comment', 'wheelfy'); ?></th>
                            <th class="column-date"><?php _e('Date', 'wheelfy'); ?></th>
                            <th class="column-actions"><?php _e('Actions', 'wheelfy'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $pending_reviews_list = array_filter($all_reviews, function($r) { return isset($r['status']) && $r['status'] === 'pending'; });
                        $pending_reviews_list = array_values($pending_reviews_list);
                        if (!empty($pending_reviews_list)) :
                        $pending_count = 0;
                        foreach ($pending_reviews_list as $review) : 
                            $pending_count++;
                                $review_id = isset($review['review_id']) ? $review['review_id'] : (isset($review['id']) ? $review['id'] : '');
                        ?>
                            <tr data-review-id="<?php echo esc_attr($review_id); ?>">
                                <td class="column-id"><?php echo $pending_count; ?></td>
                                <td class="column-customer"><strong><?php echo esc_html($review['customer_name']); ?></strong></td>
                                <td class="column-partner"><?php echo esc_html($review['partner_name']); ?></td>
                                <td class="column-service"><?php echo esc_html($review['service'] ?: '-'); ?></td>
                                <td class="column-rating">
                                    <div class="rating-stars">
                                        <?php 
                                        $rating = isset($review['rating']) ? intval($review['rating']) : 0;
                                        for ($i = 1; $i <= 5; $i++) : ?>
                                            <span class="star <?php echo $i <= $rating ? 'filled' : ''; ?>">★</span>
                                        <?php endfor; ?>
                                        <span class="rating-number">(<?php echo $rating; ?>)</span>
                                    </div>
                                </td>
                                <td class="column-comment"><?php 
                                    $comment = isset($review['review_text']) ? $review['review_text'] : '';
                                    echo esc_html(mb_substr($comment, 0, 60)) . (mb_strlen($comment) > 60 ? '...' : ''); 
                                ?></td>
                                <td class="column-date"><?php echo esc_html($review['created_date'] ?: '-'); ?></td>
                                <td class="column-actions">
                                    <div class="row-actions">
                                        <a href="javascript:void(0);" class="button button-small button-primary wheelfy-approve-review" data-review-id="<?php echo esc_attr($review_id); ?>"><?php _e('Approve', 'wheelfy'); ?></a>
                                        <a href="javascript:void(0);" class="button button-small wheelfy-reject-review" data-review-id="<?php echo esc_attr($review_id); ?>"><?php _e('Reject', 'wheelfy'); ?></a>
                                    </div>
                                </td>
                            </tr>
                        <?php 
                            endforeach;
                        else :
                        ?>
                            <tr>
                                <td colspan="8" style="text-align: center; padding: 40px;">
                                    <?php _e('No pending reviews found.', 'wheelfy'); ?>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Reported Reviews Tab -->
    <div class="wheelfy-tab-content <?php echo $current_tab === 'reported' ? 'active' : ''; ?>" id="tab-reported">
        <div class="wheelfy-dashboard-card">
            <div class="card-header">
                <div>
                    <h2><?php _e('Reported Reviews', 'wheelfy'); ?></h2>
                    <p class="card-description"><?php _e('Reviews that have been flagged for review', 'wheelfy'); ?></p>
                </div>
                <div class="header-filters">
                    <input type="text" id="search-reported" class="search-input" placeholder="<?php esc_attr_e('Search reviews...', 'wheelfy'); ?>">
                </div>
            </div>
            <div class="card-body">
                <table class="wp-list-table widefat fixed striped table-view-list">
                    <thead>
                        <tr>
                            <th class="column-id"><?php _e('#', 'wheelfy'); ?></th>
                            <th class="column-customer"><?php _e('Customer', 'wheelfy'); ?></th>
                            <th class="column-partner"><?php _e('Partner', 'wheelfy'); ?></th>
                            <th class="column-service"><?php _e('Service', 'wheelfy'); ?></th>
                            <th class="column-rating"><?php _e('Rating', 'wheelfy'); ?></th>
                            <th class="column-comment"><?php _e('Comment', 'wheelfy'); ?></th>
                            <th class="column-status"><?php _e('Status', 'wheelfy'); ?></th>
                            <th class="column-date"><?php _e('Date', 'wheelfy'); ?></th>
                            <th class="column-actions"><?php _e('Actions', 'wheelfy'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        // $all_reviews is already filtered for reported reviews at the top of the file
                        if (!empty($all_reviews)) :
                        $reported_count = 0;
                            foreach ($all_reviews as $review) : 
                            $reported_count++;
                                $review_id = isset($review['review_id']) ? $review['review_id'] : (isset($review['id']) ? $review['id'] : '');
                                $review_status = isset($review['status']) ? $review['status'] : 'approved';
                        ?>
                            <tr data-review-id="<?php echo esc_attr($review_id); ?>" data-review-status="<?php echo esc_attr($review_status); ?>">
                                <td class="column-id"><?php echo $reported_count; ?></td>
                                <td class="column-customer"><strong><?php echo esc_html($review['customer_name']); ?></strong></td>
                                <td class="column-partner"><?php echo esc_html($review['partner_name']); ?></td>
                                <td class="column-service"><?php echo esc_html($review['service'] ?: '-'); ?></td>
                                <td class="column-rating">
                                    <div class="rating-stars">
                                        <?php 
                                        $rating = isset($review['rating']) ? intval($review['rating']) : 0;
                                        for ($i = 1; $i <= 5; $i++) : ?>
                                            <span class="star <?php echo $i <= $rating ? 'filled' : ''; ?>">★</span>
                                        <?php endfor; ?>
                                        <span class="rating-number">(<?php echo $rating; ?>)</span>
                                    </div>
                                </td>
                                <td class="column-comment"><?php 
                                    $comment = isset($review['review_text']) ? $review['review_text'] : '';
                                    echo esc_html(mb_substr($comment, 0, 60)) . (mb_strlen($comment) > 60 ? '...' : ''); 
                                ?></td>
                                <td class="column-status">
                                    <span class="status-badge status-<?php echo esc_attr($review_status); ?>">
                                        <?php echo esc_html(ucfirst($review_status)); ?>
                                    </span>
                                    <span class="dashicons dashicons-flag reported-flag" title="<?php esc_attr_e('Reported', 'wheelfy'); ?>"></span>
                                </td>
                                <td class="column-date"><?php echo esc_html($review['created_date'] ?: '-'); ?></td>
                                <td class="column-actions">
                                    <div class="row-actions">
                                        <?php if ($review_status === 'pending') : ?>
                                            <a href="javascript:void(0);" class="button button-small button-primary wheelfy-approve-review" data-review-id="<?php echo esc_attr($review_id); ?>"><?php _e('Approve', 'wheelfy'); ?></a>
                                            <a href="javascript:void(0);" class="button button-small wheelfy-reject-review" data-review-id="<?php echo esc_attr($review_id); ?>"><?php _e('Reject', 'wheelfy'); ?></a>
                                        <?php endif; ?>
                                        <a href="javascript:void(0);" class="button button-small button-link-delete wheelfy-delete-review" data-review-id="<?php echo esc_attr($review_id); ?>"><?php _e('Delete', 'wheelfy'); ?></a>
                                    </div>
                                </td>
                            </tr>
                        <?php 
                            endforeach;
                        else :
                        ?>
                            <tr>
                                <td colspan="9" style="text-align: center; padding: 40px;">
                                    <?php _e('No reported reviews found.', 'wheelfy'); ?>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Partner Ratings Tab -->
    <div class="wheelfy-tab-content <?php echo $current_tab === 'ratings' ? 'active' : ''; ?>" id="tab-ratings">
        <div class="wheelfy-dashboard-card">
            <div class="card-header">
                <div>
                    <h2><?php _e('Partner Ratings', 'wheelfy'); ?></h2>
                    <p class="card-description"><?php _e('Overview of partner ratings and review statistics', 'wheelfy'); ?></p>
                </div>
                <div class="header-filters">
                    <input type="text" id="search-partners" class="search-input" placeholder="<?php esc_attr_e('Search partners...', 'wheelfy'); ?>">
                    <button class="button button-primary" id="recalculate-ratings"><?php _e('Recalculate All Ratings', 'wheelfy'); ?></button>
                </div>
            </div>
            <div class="card-body">
                <table class="wp-list-table widefat fixed striped table-view-list">
                    <thead>
                        <tr>
                            <th class="column-id"><?php _e('#', 'wheelfy'); ?></th>
                            <th class="column-partner"><?php _e('Partner', 'wheelfy'); ?></th>
                            <th class="column-rating"><?php _e('Average Rating', 'wheelfy'); ?></th>
                            <th class="column-total"><?php _e('Total Reviews', 'wheelfy'); ?></th>
                            <th class="column-recent"><?php _e('Recent Review', 'wheelfy'); ?></th>
                            <th class="column-actions"><?php _e('Actions', 'wheelfy'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        if (!empty($partner_ratings)) :
                        $partner_count = 0;
                            foreach ($partner_ratings as $partner) : 
                            $partner_count++;
                                $partner_name = isset($partner['partner_name']) ? $partner['partner_name'] : __('Unknown Partner', 'wheelfy');
                                $partner_id = isset($partner['partner_id']) ? intval($partner['partner_id']) : 0;
                                $average_rating = isset($partner['average_rating']) ? floatval($partner['average_rating']) : 0;
                                $total_reviews = isset($partner['total_reviews']) ? intval($partner['total_reviews']) : 0;
                                $recent_review = isset($partner['recent_review']) ? $partner['recent_review'] : '-';
                                $avg_rating_rounded = round($average_rating);
                        ?>
                            <tr>
                                <td class="column-id"><?php echo $partner_count; ?></td>
                                <td class="column-partner"><strong><?php echo esc_html($partner_name); ?></strong></td>
                                <td class="column-rating">
                                    <div class="rating-stars">
                                        <?php 
                                        for ($i = 1; $i <= 5; $i++) : ?>
                                            <span class="star <?php echo $i <= $avg_rating_rounded ? 'filled' : ''; ?>">★</span>
                                        <?php endfor; ?>
                                        <span class="rating-number"><?php echo number_format($average_rating, 1); ?></span>
                                    </div>
                                </td>
                                <td class="column-total">
                                    <strong><?php echo number_format($total_reviews); ?></strong>
                                </td>
                                <td class="column-recent"><?php echo esc_html($recent_review); ?></td>
                                <td class="column-actions">
                                    <div class="row-actions">
                                        <a href="<?php echo esc_url(add_query_arg(array('page' => 'wheelfy-reviews', 'tab' => 'all', 'partner_id' => $partner_id), admin_url('admin.php'))); ?>" class="button button-small"><?php _e('View Reviews', 'wheelfy'); ?></a>
                                        <a href="javascript:void(0);" class="button button-small wheelfy-recalculate-partner-ratings" data-partner-id="<?php echo esc_attr($partner_id); ?>"><?php _e('Recalculate', 'wheelfy'); ?></a>
                                    </div>
                                </td>
                            </tr>
                        <?php 
                            endforeach;
                        else :
                        ?>
                            <tr>
                                <td colspan="6" style="text-align: center; padding: 40px;">
                                    <?php _e('No partner ratings found.', 'wheelfy'); ?>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<style>
/* Admin Reviews Page Styles */
.wheelfy-admin-reviews {
    margin: 20px 0 0 0;
}

.wheelfy-admin-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 20px;
}

.wheelfy-admin-header h1 {
    margin: 0 0 8px 0;
    font-size: 23px;
    font-weight: 400;
}

.wheelfy-admin-header .description {
    margin: 0;
    color: #646970;
    font-size: 14px;
}

/* KPI Cards */
.wheelfy-kpi-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
    margin: 20px 0;
    padding-left: 20px;
}

.wheelfy-kpi-card {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 20px;
    display: flex;
    align-items: center;
    gap: 16px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    transition: all 0.3s ease;
}

.wheelfy-kpi-card:hover {
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    border-color: #2271b1;
}

.kpi-icon {
    width: 48px;
    height: 48px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.kpi-icon svg {
    display: block;
    margin: 0 auto;
    width: 24px;
    height: 24px;
}

.kpi-content {
    flex: 1;
}

.kpi-label {
    font-size: 13px;
    color: #646970;
    margin-bottom: 4px;
}

.kpi-value {
    font-size: 28px;
    font-weight: 600;
    color: #1d2327;
    line-height: 1.2;
}

/* Tabs */
.nav-tab-wrapper {
    margin: 20px 0 0 0;
    border-bottom: 1px solid #ccc;
}

.nav-tab-wrapper .nav-tab {
    margin-bottom: -1px;
    padding: 10px 15px;
    font-size: 14px;
    text-decoration: none;
    border: 1px solid transparent;
    border-bottom: none;
    background: transparent;
    color: #50575e;
    cursor: pointer;
    transition: all 0.2s ease;
}

.nav-tab-wrapper .nav-tab:hover {
    color: #2271b1;
    background: #f6f7f7;
}

.nav-tab-wrapper .nav-tab.nav-tab-active {
    color: #2271b1;
    background: #fff;
    border-color: #ccc;
    border-bottom-color: #fff;
}

/* Tab Content */
.wheelfy-tab-content {
    display: none;
    margin-top: 20px;
}

.wheelfy-tab-content.active {
    display: block;
}

/* Dashboard Card */
.wheelfy-dashboard-card {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    margin-bottom: 20px;
}

.card-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    padding: 20px 24px;
    border-bottom: 1px solid #ddd;
    flex-wrap: wrap;
    gap: 16px;
}

.card-header h2 {
    margin: 0 0 4px 0;
    font-size: 18px;
    font-weight: 600;
    color: #1d2327;
}

.card-description {
    margin: 0;
    font-size: 13px;
    color: #646970;
}

.header-filters {
    display: flex;
    gap: 10px;
    align-items: center;
    flex-wrap: wrap;
}

.search-input {
    padding: 6px 12px;
    border: 1px solid #8c8f94;
    border-radius: 4px;
    font-size: 14px;
    min-width: 200px;
}

.filter-select {
    padding: 6px 12px;
    border: 1px solid #8c8f94;
    border-radius: 4px;
    font-size: 14px;
    min-width: 140px;
}

.card-body {
    padding: 24px;
}

/* Table Styles */
.table-view-list {
    margin: 0;
    border: none;
    width: 100%;
}

.card-body > .table-view-list {
    margin: -24px;
    width: calc(100% + 48px);
}

.table-view-list thead th {
    background: #f6f7f7;
    font-weight: 600;
    padding: 12px;
    border-bottom: 2px solid #ddd;
}

.table-view-list tbody td {
    padding: 12px;
    vertical-align: middle;
}

.table-view-list tbody tr:hover {
    background: #f9f9f9;
}

/* Partner Ratings Table Column Widths */
#tab-ratings .card-body {
    padding: 24px;
    overflow-x: auto;
}

#tab-ratings .card-body > .table-view-list {
    margin: -24px -24px -24px -24px;
    width: calc(100% + 48px);
}

#tab-ratings .table-view-list {
    table-layout: fixed;
    width: 100%;
}

#tab-ratings .table-view-list .column-id {
    width: 5%;
    padding: 12px 8px;
}

#tab-ratings .table-view-list .column-partner {
    width: 25%;
    padding: 12px;
}

#tab-ratings .table-view-list .column-rating {
    width: 20%;
    padding: 12px;
}

#tab-ratings .table-view-list .column-total {
    width: 12%;
    padding: 12px;
    text-align: center;
}

#tab-ratings .table-view-list .column-recent {
    width: 15%;
    padding: 12px;
    text-align: center;
}

#tab-ratings .table-view-list .column-actions {
    width: 23%;
    padding: 12px 24px 12px 12px;
}

/* Rating Stars */
.rating-stars {
    display: flex;
    align-items: center;
    gap: 4px;
}

.star {
    color: #ddd;
    font-size: 16px;
    line-height: 1;
}

.star.filled {
    color: #ffc107;
}

.rating-number {
    margin-left: 8px;
    font-weight: 600;
    color: #666;
    font-size: 14px;
}

/* Status Badges */
.status-badge {
    display: inline-block;
    padding: 4px 12px;
    border-radius: 12px;
    font-size: 12px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.status-approved {
    background: #e8f5e9;
    color: #388e3c;
}

.status-pending {
    background: #fff3e0;
    color: #f57c00;
}

.status-rejected {
    background: #ffebee;
    color: #c62828;
}

.reported-flag {
    color: #dc3232;
    margin-left: 6px;
    font-size: 16px;
    vertical-align: middle;
}

/* Row Actions */
.row-actions {
    display: flex !important;
    gap: 6px;
    flex-wrap: wrap;
    align-items: center;
    visibility: visible !important;
    opacity: 1 !important;
}

.row-actions .button {
    margin: 0;
    white-space: nowrap;
}

/* Hide WordPress Footer */
#wpfooter {
    display: none !important;
}

/* Responsive */
@media (max-width: 782px) {
    .wheelfy-admin-header {
        flex-direction: column;
        gap: 16px;
    }

    .header-filters {
        width: 100%;
    }

    .header-filters .search-input,
    .header-filters .filter-select {
        flex: 1;
        min-width: 0;
    }

    .wheelfy-kpi-grid {
        grid-template-columns: 1fr;
        padding-left: 0;
    }

    .row-actions {
        flex-direction: column;
        align-items: flex-start;
    }

    .card-body .table-view-list {
        margin: -24px;
        width: calc(100% + 48px);
    }
}
</style>

<script>
jQuery(document).ready(function($) {
    // Hide WordPress admin footer
    $('#wpfooter').hide();
    $('p:contains("Thank you for creating")').hide();
    $('p:contains("Version")').hide();
    
    // Tab switching
    $('.wheelfy-subscription-tabs .nav-tab').on('click', function(e) {
        e.preventDefault();
        const tab = $(this).data('tab');
        
        // Update active tab
        $('.wheelfy-subscription-tabs .nav-tab').removeClass('nav-tab-active');
        $(this).addClass('nav-tab-active');
        
        // Show/hide tab content
        $('.wheelfy-tab-content').removeClass('active');
        $('#tab-' + tab).addClass('active');
        
        // Update URL without reload
        const url = new URL(window.location);
        url.searchParams.set('tab', tab);
        window.history.pushState({}, '', url);
    });
    
    // Combined filter function for All Reviews tab
    function applyAllReviewsFilters() {
        const table = $('#tab-all').find('table tbody');
        const searchTerm = $('#search-reviews').val().toLowerCase().trim();
        const ratingFilter = $('#filter-rating').val();
        const statusFilter = $('#filter-status').val();
        
        table.find('tr').each(function() {
            let show = true;
            const $row = $(this);
            
            // Skip empty rows
            if ($row.find('td').length <= 1) {
                return;
            }
            
            // Search filter
            if (searchTerm) {
                const text = $row.text().toLowerCase();
                if (text.indexOf(searchTerm) === -1) {
                    show = false;
                }
            }
            
            // Rating filter
            if (show && ratingFilter !== 'all') {
                const ratingMatch = $row.find('.rating-number').text().match(/\((\d+)\)/);
                if (!ratingMatch || ratingMatch[1] !== ratingFilter) {
                    show = false;
                }
            }
            
            // Status filter - use data-review-status attribute for reliable filtering
            if (show && statusFilter !== 'all') {
                const rowStatus = $row.attr('data-review-status');
                if (!rowStatus || rowStatus !== statusFilter) {
                    show = false;
                }
            }
            
            // Show or hide row
            $row.toggle(show);
        });
    }
    
    // Search functionality
    $('#search-reviews, #search-pending, #search-reported, #search-partners').on('keyup', function() {
        const searchId = $(this).attr('id');
        if (searchId === 'search-reviews') {
            applyAllReviewsFilters();
        } else {
        const searchTerm = $(this).val().toLowerCase();
        const table = $(this).closest('.wheelfy-dashboard-card').find('table tbody');
        table.find('tr').each(function() {
            const text = $(this).text().toLowerCase();
            $(this).toggle(text.indexOf(searchTerm) > -1);
        });
        }
    });
    
    // Filter by rating
    $('#filter-rating, #filter-pending-rating').on('change', function() {
        const filterId = $(this).attr('id');
        if (filterId === 'filter-rating') {
            applyAllReviewsFilters();
        } else {
        const filterValue = $(this).val();
        const table = $(this).closest('.wheelfy-dashboard-card').find('table tbody');
        
        if (filterValue === 'all') {
            table.find('tr').show();
        } else {
            table.find('tr').each(function() {
                const rating = $(this).find('.rating-number').text().match(/\((\d+)\)/);
                if (rating && rating[1] === filterValue) {
                    $(this).show();
                } else {
                    $(this).hide();
                }
            });
            }
        }
    });
    
    // Filter by status
    $('#filter-status').on('change', function() {
        applyAllReviewsFilters();
    });
    
    // Define ajaxurl if not defined
    if (typeof ajaxurl === 'undefined') {
        var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';
    }
    
    var moderation_nonce = '<?php echo wp_create_nonce('wheelfy_moderate_review'); ?>';
    
    // Approve Review
    $(document).on('click', '.wheelfy-approve-review', function(e) {
        e.preventDefault();
        e.stopPropagation();
        var $button = $(this);
        var review_id = $button.data('review-id');
        var $row = $button.closest('tr');
        
        if (!review_id) {
            alert('<?php echo esc_js(__('Invalid review ID.', 'wheelfy')); ?>');
            return;
        }
        
        $button.prop('disabled', true).text('<?php echo esc_js(__('Processing...', 'wheelfy')); ?>');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'wheelfy_approve_review',
                nonce: moderation_nonce,
                review_id: review_id
            },
            success: function(response) {
                if (response.success) {
                    // Update status badge
                    $row.find('.status-badge').removeClass('status-pending status-rejected').addClass('status-approved').text('<?php echo esc_js(__('Approved', 'wheelfy')); ?>');
                    $row.attr('data-review-status', 'approved');
                    
                    // Remove approve/reject buttons, keep delete
                    $row.find('.wheelfy-approve-review, .wheelfy-reject-review').remove();
                    
                    // Show success message
                    alert(response.data.message || '<?php echo esc_js(__('Review approved successfully.', 'wheelfy')); ?>');
        } else {
                    alert(response.data.message || '<?php echo esc_js(__('Failed to approve review.', 'wheelfy')); ?>');
                    $button.prop('disabled', false).text('<?php echo esc_js(__('Approve', 'wheelfy')); ?>');
                }
            },
            error: function() {
                alert('<?php echo esc_js(__('Error processing request.', 'wheelfy')); ?>');
                $button.prop('disabled', false).text('<?php echo esc_js(__('Approve', 'wheelfy')); ?>');
            }
        });
    });
    
    // Reject Review
    $(document).on('click', '.wheelfy-reject-review', function(e) {
        e.preventDefault();
        e.stopPropagation();
        var $button = $(this);
        var review_id = $button.data('review-id');
        var $row = $button.closest('tr');
        
        if (!review_id) {
            alert('<?php echo esc_js(__('Invalid review ID.', 'wheelfy')); ?>');
            return;
        }
        
        if (!confirm('<?php echo esc_js(__('Are you sure you want to reject this review?', 'wheelfy')); ?>')) {
            return;
        }
        
        $button.prop('disabled', true).text('<?php echo esc_js(__('Processing...', 'wheelfy')); ?>');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'wheelfy_reject_review',
                nonce: moderation_nonce,
                review_id: review_id
            },
            success: function(response) {
                if (response.success) {
                    // Update status badge
                    $row.find('.status-badge').removeClass('status-pending status-approved').addClass('status-rejected').text('<?php echo esc_js(__('Rejected', 'wheelfy')); ?>');
                    $row.attr('data-review-status', 'rejected');
                    
                    // Remove approve/reject buttons, keep delete
                    $row.find('.wheelfy-approve-review, .wheelfy-reject-review').remove();
                    
                    // Show success message
                    alert(response.data.message || '<?php echo esc_js(__('Review rejected successfully.', 'wheelfy')); ?>');
                } else {
                    alert(response.data.message || '<?php echo esc_js(__('Failed to reject review.', 'wheelfy')); ?>');
                    $button.prop('disabled', false).text('<?php echo esc_js(__('Reject', 'wheelfy')); ?>');
                }
            },
            error: function() {
                alert('<?php echo esc_js(__('Error processing request.', 'wheelfy')); ?>');
                $button.prop('disabled', false).text('<?php echo esc_js(__('Reject', 'wheelfy')); ?>');
            }
        });
    });
    
    // Delete Review (Soft Delete)
    $(document).on('click', '.wheelfy-delete-review', function(e) {
        e.preventDefault();
        e.stopPropagation();
        var $button = $(this);
        var review_id = $button.data('review-id');
        var $row = $button.closest('tr');
        
        if (!review_id) {
            alert('<?php echo esc_js(__('Invalid review ID.', 'wheelfy')); ?>');
            return;
        }
        
        if (!confirm('<?php echo esc_js(__('Are you sure you want to delete this review?', 'wheelfy')); ?>')) {
            return;
        }
        
        $button.prop('disabled', true).text('<?php echo esc_js(__('Deleting...', 'wheelfy')); ?>');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'wheelfy_delete_review',
                nonce: moderation_nonce,
                review_id: review_id
            },
            success: function(response) {
                if (response.success) {
                    // Fade out and remove row
                    $row.fadeOut(300, function() {
                        $(this).remove();
    });
    
                    // Show success message
                    alert(response.data.message || '<?php echo esc_js(__('Review deleted successfully.', 'wheelfy')); ?>');
                } else {
                    alert(response.data.message || '<?php echo esc_js(__('Failed to delete review.', 'wheelfy')); ?>');
                    $button.prop('disabled', false).text('<?php echo esc_js(__('Delete', 'wheelfy')); ?>');
                }
            },
            error: function() {
                alert('<?php echo esc_js(__('Error processing request.', 'wheelfy')); ?>');
                $button.prop('disabled', false).text('<?php echo esc_js(__('Delete', 'wheelfy')); ?>');
            }
        });
    });
    
    // Recalculate single partner ratings
    $(document).on('click', '.wheelfy-recalculate-partner-ratings', function(e) {
        e.preventDefault();
        e.stopPropagation();
        var $button = $(this);
        var partner_id = $button.data('partner-id');
        var $row = $button.closest('tr');
        
        if (!partner_id) {
            alert('<?php echo esc_js(__('Invalid partner ID.', 'wheelfy')); ?>');
            return;
        }
        
        $button.prop('disabled', true).text('<?php echo esc_js(__('Recalculating...', 'wheelfy')); ?>');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'wheelfy_recalculate_partner_ratings',
                nonce: moderation_nonce,
                partner_id: partner_id
            },
            success: function(response) {
                if (response.success) {
                    // Update the row with new data
                    if (response.data && response.data.average_rating !== undefined) {
                        var avgRating = parseFloat(response.data.average_rating);
                        var totalReviews = parseInt(response.data.total_reviews) || 0;
                        var recentReview = response.data.recent_review || '-';
                        
                        // Update average rating display
                        var $ratingCell = $row.find('.column-rating');
                        var starsHtml = '';
                        var roundedRating = Math.round(avgRating);
                        for (var i = 1; i <= 5; i++) {
                            starsHtml += '<span class="star ' + (i <= roundedRating ? 'filled' : '') + '">★</span>';
                        }
                        $ratingCell.find('.rating-stars').html(starsHtml + '<span class="rating-number">' + avgRating.toFixed(1) + '</span>');
                        
                        // Update total reviews
                        $row.find('.column-total strong').text(totalReviews);
                        
                        // Update recent review
                        $row.find('.column-recent').text(recentReview);
                    }
                    
                    alert(response.data.message || '<?php echo esc_js(__('Partner ratings recalculated successfully.', 'wheelfy')); ?>');
                } else {
                    alert(response.data.message || '<?php echo esc_js(__('Failed to recalculate ratings.', 'wheelfy')); ?>');
                }
                $button.prop('disabled', false).text('<?php echo esc_js(__('Recalculate', 'wheelfy')); ?>');
            },
            error: function() {
                alert('<?php echo esc_js(__('Error processing request.', 'wheelfy')); ?>');
                $button.prop('disabled', false).text('<?php echo esc_js(__('Recalculate', 'wheelfy')); ?>');
            }
        });
    });
    
    // Prevent default for other action buttons (non-functional ones)
    $(document).on('click', '.row-actions a:not(.wheelfy-approve-review):not(.wheelfy-reject-review):not(.wheelfy-delete-review):not(.wheelfy-recalculate-partner-ratings)', function(e) {
        // Allow "View Reviews" link to work normally
        if ($(this).attr('href') && $(this).attr('href').indexOf('partner_id') > -1) {
            return; // Let the link work normally
        }
        e.preventDefault();
        e.stopPropagation();
    });
    
    // Recalculate ratings button
    $('#recalculate-ratings').on('click', function(e) {
        e.preventDefault();
        var $button = $(this);
        
        if (!confirm('<?php echo esc_js(__('Are you sure you want to recalculate all partner ratings? This will refresh the ratings data.', 'wheelfy')); ?>')) {
            return;
        }
        
        $button.prop('disabled', true).text('<?php echo esc_js(__('Recalculating...', 'wheelfy')); ?>');
        
        // Reload the page to refresh ratings (since ratings are calculated on page load)
        window.location.reload();
    });
    
    // Force actions visible
    function forceActionsVisible() {
        $('.row-actions').css({
            'display': 'flex !important',
            'visibility': 'visible !important',
            'opacity': '1 !important'
        });
    }
    
    // Use MutationObserver to ensure actions stay visible
    const observer = new MutationObserver(function(mutations) {
        forceActionsVisible();
    });
    
    $('.row-actions').each(function() {
        observer.observe(this, {
            attributes: true,
            attributeFilter: ['style', 'class']
        });
    });
    
    // Initial call
    forceActionsVisible();
    setTimeout(forceActionsVisible, 100);
    setTimeout(forceActionsVisible, 500);
    
    // Apply filters on page load if filters are set
    if ($('#tab-all').hasClass('active')) {
        applyAllReviewsFilters();
    }
});
</script>
