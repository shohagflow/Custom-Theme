<?php
/**
 * Admin Dashboard Main Page
 * 
 * @package Wheelfy
 */

if (!defined('ABSPATH')) {
    exit;
}

// Check if user is administrator
if (!current_user_can('administrator')) {
    wp_die(__('You do not have permission to access this page.', 'wheelfy'));
}

// Get statistics
require_once get_template_directory() . '/admin/admin-functions.php';

$stats = wheelfy_get_admin_statistics();
$recent_activities = wheelfy_get_recent_activities(10);

// Get monthly chart data (default to 12 months)
$chart_months = 12;
$monthly_users_data = wheelfy_get_monthly_users_data($chart_months);
$monthly_requests_data = wheelfy_get_monthly_requests_data($chart_months);
$monthly_revenue_data = wheelfy_get_monthly_revenue_data($chart_months);
$monthly_offers_data = wheelfy_get_monthly_offers_data($chart_months);
?>
<div class="wrap wheelfy-admin-dashboard">
    <h1 class="wp-heading-inline"><?php _e('Wheelfy Admin Dashboard', 'wheelfy'); ?></h1>
    <hr class="wp-header-end">

    <!-- KPI Overview Cards -->
    <div class="wheelfy-kpi-grid">
        <div class="wheelfy-kpi-card">
            <div class="kpi-icon users-icon">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                    <circle cx="9" cy="7" r="4"></circle>
                    <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                    <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                </svg>
            </div>
            <div class="kpi-content">
                <h3><?php echo number_format($stats['total_users']); ?></h3>
                <p><?php _e('Total Users', 'wheelfy'); ?></p>
            </div>
        </div>

        <div class="wheelfy-kpi-card">
            <div class="kpi-icon customers-icon">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                    <circle cx="12" cy="7" r="4"></circle>
                </svg>
            </div>
            <div class="kpi-content">
                <h3><?php echo number_format($stats['total_customers']); ?></h3>
                <p><?php _e('Customers', 'wheelfy'); ?></p>
            </div>
        </div>

        <div class="wheelfy-kpi-card">
            <div class="kpi-icon partners-icon">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                    <circle cx="9" cy="7" r="4"></circle>
                    <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                    <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                </svg>
            </div>
            <div class="kpi-content">
                <h3><?php echo number_format($stats['total_partners']); ?></h3>
                <p><?php _e('Partners', 'wheelfy'); ?></p>
            </div>
        </div>

        <div class="wheelfy-kpi-card">
            <div class="kpi-icon subscriptions-icon">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <rect x="3" y="8" width="18" height="4" rx="1"></rect>
                    <path d="M12 8v13"></path>
                    <path d="M19 12v7a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2v-7"></path>
                    <path d="M7.5 8a2.5 2.5 0 0 1 0-5A4.8 8 0 0 1 12 8a4.8 8 0 0 1 4.5-5 2.5 2.5 0 0 1 0 5"></path>
                </svg>
            </div>
            <div class="kpi-content">
                <h3><?php echo number_format($stats['active_subscriptions']); ?></h3>
                <p><?php _e('Active Subscriptions', 'wheelfy'); ?></p>
            </div>
        </div>

        <div class="wheelfy-kpi-card">
            <div class="kpi-icon leads-icon">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M9 11l3 3L22 4"></path>
                    <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path>
                </svg>
            </div>
            <div class="kpi-content">
                <h3><?php echo number_format($stats['total_leads']); ?></h3>
                <p><?php _e('Service Requests', 'wheelfy'); ?></p>
            </div>
        </div>

        <div class="wheelfy-kpi-card">
            <div class="kpi-icon offers-icon">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M12 2L2 7l10 5 10-5-10-5z"></path>
                    <path d="M2 17l10 5 10-5"></path>
                    <path d="M2 12l10 5 10-5"></path>
                </svg>
            </div>
            <div class="kpi-content">
                <h3><?php echo number_format($stats['accepted_offers']); ?></h3>
                <p><?php _e('Accepted Offers', 'wheelfy'); ?></p>
            </div>
        </div>

        <div class="wheelfy-kpi-card">
            <div class="kpi-icon revenue-icon">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <line x1="12" y1="1" x2="12" y2="23"></line>
                    <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
                </svg>
            </div>
            <div class="kpi-content">
                <h3><?php echo '€' . number_format($stats['total_revenue'], 2); ?></h3>
                <p><?php _e('Total Revenue', 'wheelfy'); ?></p>
            </div>
        </div>

        <div class="wheelfy-kpi-card">
            <div class="kpi-icon pending-icon">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="12" cy="12" r="10"></circle>
                    <polyline points="12 6 12 12 16 14"></polyline>
                </svg>
            </div>
            <div class="kpi-content">
                <h3><?php echo number_format($stats['pending_approvals']); ?></h3>
                <p><?php _e('Pending Approvals', 'wheelfy'); ?></p>
            </div>
        </div>
    </div>

    <!-- Analytics Charts -->
    <div class="wheelfy-dashboard-section">
        <div class="section-header">
            <h2><?php _e('Monthly Analytics', 'wheelfy'); ?></h2>
            <select id="chart-period" class="chart-period-select">
                <option value="6"><?php _e('Last 6 Months', 'wheelfy'); ?></option>
                <option value="12" selected><?php _e('Last 12 Months', 'wheelfy'); ?></option>
            </select>
        </div>
        <div class="charts-grid">
            <div class="chart-card">
                <div class="chart-header">
                    <h3><?php _e('Users Growth', 'wheelfy'); ?></h3>
                    <p class="chart-description"><?php _e('New users registered per month', 'wheelfy'); ?></p>
                </div>
                <div class="chart-container">
                    <canvas id="usersChart"></canvas>
                </div>
            </div>

            <div class="chart-card">
                <div class="chart-header">
                    <h3><?php _e('Revenue Trend', 'wheelfy'); ?></h3>
                    <p class="chart-description"><?php _e('Monthly revenue in EUR', 'wheelfy'); ?></p>
                </div>
                <div class="chart-container">
                    <canvas id="revenueChart"></canvas>
                </div>
            </div>

            <div class="chart-card">
                <div class="chart-header">
                    <h3><?php _e('Service Requests', 'wheelfy'); ?></h3>
                    <p class="chart-description"><?php _e('Leads created per month', 'wheelfy'); ?></p>
                </div>
                <div class="chart-container">
                    <canvas id="leadsChart"></canvas>
                </div>
            </div>

            <div class="chart-card">
                <div class="chart-header">
                    <h3><?php _e('Offers & Conversions', 'wheelfy'); ?></h3>
                    <p class="chart-description"><?php _e('Offers submitted vs accepted', 'wheelfy'); ?></p>
                </div>
                <div class="chart-container">
                    <canvas id="offersChart"></canvas>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Activities -->
    <div class="wheelfy-dashboard-section">
        <div class="section-header">
            <h2><?php _e('Recent Activities', 'wheelfy'); ?></h2>
            <a href="<?php echo admin_url('admin.php?page=wheelfy-activities'); ?>" class="button"><?php _e('View All', 'wheelfy'); ?></a>
        </div>
        <div class="activities-list">
            <?php if (!empty($recent_activities)) : ?>
                <?php foreach ($recent_activities as $activity) : ?>
                    <div class="activity-item">
                        <div class="activity-icon activity-<?php echo esc_attr($activity['type']); ?>">
                            <?php echo $activity['icon']; ?>
                        </div>
                        <div class="activity-content">
                            <p class="activity-text"><?php echo esc_html($activity['message']); ?></p>
                            <span class="activity-time"><?php echo esc_html($activity['time']); ?></span>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else : ?>
                <p class="no-activities"><?php _e('No recent activities.', 'wheelfy'); ?></p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="wheelfy-dashboard-section">
        <div class="section-header">
            <h2><?php _e('Quick Actions', 'wheelfy'); ?></h2>
        </div>
        <div class="quick-actions-grid">
            <a href="<?php echo admin_url('admin.php?page=wheelfy-users'); ?>" class="quick-action-card">
                <div class="action-icon">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                        <circle cx="9" cy="7" r="4"></circle>
                        <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                        <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                    </svg>
                </div>
                <h3><?php _e('Manage Users', 'wheelfy'); ?></h3>
                <p><?php _e('View and manage customers and partners', 'wheelfy'); ?></p>
            </a>

            <a href="<?php echo admin_url('admin.php?page=wheelfy-subscriptions'); ?>" class="quick-action-card">
                <div class="action-icon">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <rect x="3" y="8" width="18" height="4" rx="1"></rect>
                        <path d="M12 8v13"></path>
                        <path d="M19 12v7a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2v-7"></path>
                    </svg>
                </div>
                <h3><?php _e('Subscriptions', 'wheelfy'); ?></h3>
                <p><?php _e('Manage subscription plans and payments', 'wheelfy'); ?></p>
            </a>

            <!-- Leads & Offers - REMOVED -->
            <!-- <a href="<?php echo admin_url('admin.php?page=wheelfy-leads'); ?>" class="quick-action-card">
                <div class="action-icon">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M9 11l3 3L22 4"></path>
                        <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path>
                    </svg>
                </div>
                <h3><?php _e('Leads & Offers', 'wheelfy'); ?></h3>
                <p><?php _e('Monitor service requests and offers', 'wheelfy'); ?></p>
            </a> -->

            <a href="<?php echo admin_url('admin.php?page=wheelfy-reviews'); ?>" class="quick-action-card">
                <div class="action-icon">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
                    </svg>
                </div>
                <h3><?php _e('Reviews', 'wheelfy'); ?></h3>
                <p><?php _e('Moderate reviews and ratings', 'wheelfy'); ?></p>
            </a>

            <!-- Chat Moderation - REMOVED -->
            <!-- <a href="<?php echo admin_url('admin.php?page=wheelfy-chat'); ?>" class="quick-action-card">
                <div class="action-icon">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
                    </svg>
                </div>
                <h3><?php _e('Chat Moderation', 'wheelfy'); ?></h3>
                <p><?php _e('Monitor and moderate conversations', 'wheelfy'); ?></p>
            </a> -->

            <a href="<?php echo admin_url('admin.php?page=wheelfy-reports'); ?>" class="quick-action-card">
                <div class="action-icon">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                        <polyline points="14 2 14 8 20 8"></polyline>
                        <line x1="16" y1="13" x2="8" y2="13"></line>
                        <line x1="16" y1="17" x2="8" y2="17"></line>
                        <polyline points="10 9 9 9 8 9"></polyline>
                    </svg>
                </div>
                <h3><?php _e('Reports & Export', 'wheelfy'); ?></h3>
                <p><?php _e('Generate and export reports', 'wheelfy'); ?></p>
            </a>
        </div>
    </div>
</div>

<!-- Chart.js Library -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>

<script>
// Pass chart data to JavaScript
var wheelfyChartData = {
    users: <?php echo json_encode($monthly_users_data); ?>,
    requests: <?php echo json_encode($monthly_requests_data); ?>,
    revenue: <?php echo json_encode($monthly_revenue_data); ?>,
    offersSubmitted: <?php echo json_encode($monthly_offers_data['submitted']); ?>,
    offersAccepted: <?php echo json_encode($monthly_offers_data['accepted']); ?>,
    ajaxUrl: '<?php echo admin_url('admin-ajax.php'); ?>',
    nonce: '<?php echo wp_create_nonce('wheelfy_chart_data'); ?>'
};
</script>

<style>
/* Charts Section */
.charts-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(500px, 1fr));
    gap: 20px;
    margin-top: 20px;
}

.chart-card {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 24px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.05);
}

.chart-header {
    margin-bottom: 20px;
    padding-bottom: 16px;
    border-bottom: 1px solid #eee;
}

.chart-header h3 {
    margin: 0 0 4px 0;
    font-size: 18px;
    font-weight: 600;
    color: #1d2327;
}

.chart-description {
    margin: 0;
    font-size: 13px;
    color: #646970;
}

.chart-container {
    position: relative;
    height: 300px;
    width: 100%;
}

.chart-period-select {
    padding: 6px 12px;
    border: 1px solid #8c8f94;
    border-radius: 4px;
    font-size: 14px;
    background: #fff;
}

.section-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}

.section-header h2 {
    margin: 0;
    font-size: 20px;
    font-weight: 600;
    color: #1d2327;
}

@media (max-width: 1200px) {
    .charts-grid {
        grid-template-columns: 1fr;
    }
}
</style>

<script>
jQuery(document).ready(function($) {
    // Store chart instances
    let usersChart, revenueChart, leadsChart, offersChart;

    // Generate monthly labels for the last N months
    function getMonthlyLabels(months = 12) {
        const labels = [];
        const now = new Date();
        for (let i = months - 1; i >= 0; i--) {
            const date = new Date(now.getFullYear(), now.getMonth() - i, 1);
            const monthName = date.toLocaleDateString('en-US', { month: 'short' });
            labels.push(monthName + ' ' + date.getFullYear());
        }
        return labels;
    }

    // Get chart data from server (default data or fetch via AJAX)
    function getChartData(dataType, months) {
        // Use existing data if available, otherwise return empty array
        if (typeof wheelfyChartData === 'undefined') {
            return new Array(months).fill(0);
        }
        
        switch(dataType) {
            case 'users':
                return wheelfyChartData.users.slice(-months);
            case 'requests':
                return wheelfyChartData.requests.slice(-months);
            case 'revenue':
                return wheelfyChartData.revenue.slice(-months);
            case 'offersSubmitted':
                return wheelfyChartData.offersSubmitted.slice(-months);
            case 'offersAccepted':
                return wheelfyChartData.offersAccepted.slice(-months);
            default:
                return new Array(months).fill(0);
        }
    }
    
    // Fetch chart data via AJAX for period changes
    function fetchChartData(months, callback) {
        if (typeof wheelfyChartData === 'undefined' || !wheelfyChartData.ajaxUrl) {
            if (callback) callback(null);
            return;
        }
        
        $.ajax({
            url: wheelfyChartData.ajaxUrl,
            type: 'POST',
            data: {
                action: 'wheelfy_get_chart_data',
                nonce: wheelfyChartData.nonce,
                months: months
            },
            success: function(response) {
                if (response.success && callback) {
                    callback(response.data);
        }
            },
            error: function() {
                if (callback) callback(null);
            }
        });
    }

    // Chart configuration
    const chartConfig = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                display: true,
                position: 'top',
            },
            tooltip: {
                mode: 'index',
                intersect: false,
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                grid: {
                    color: 'rgba(0,0,0,0.05)'
                }
            },
            x: {
                grid: {
                    display: false
                }
            }
        }
    };

    // Users Growth Chart
    const usersCtx = document.getElementById('usersChart');
    if (usersCtx) {
        usersChart = new Chart(usersCtx, {
            type: 'line',
            data: {
                labels: getMonthlyLabels(12),
                datasets: [{
                    label: 'New Users',
                    data: getChartData('users', 12),
                    borderColor: '#1976d2',
                    backgroundColor: 'rgba(25, 118, 210, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: chartConfig
        });
    }

    // Revenue Trend Chart
    const revenueCtx = document.getElementById('revenueChart');
    if (revenueCtx) {
        revenueChart = new Chart(revenueCtx, {
            type: 'bar',
            data: {
                labels: getMonthlyLabels(12),
                datasets: [{
                    label: 'Revenue (€)',
                    data: getChartData('revenue', 12),
                    backgroundColor: 'rgba(56, 142, 60, 0.8)',
                    borderColor: '#388e3c',
                    borderWidth: 1
                }]
            },
            options: chartConfig
        });
    }

    // Leads Chart
    const leadsCtx = document.getElementById('leadsChart');
    if (leadsCtx) {
        leadsChart = new Chart(leadsCtx, {
            type: 'line',
            data: {
                labels: getMonthlyLabels(12),
                datasets: [{
                    label: 'Service Requests',
                    data: getChartData('requests', 12),
                    borderColor: '#f57c00',
                    backgroundColor: 'rgba(245, 124, 0, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: chartConfig
        });
    }

    // Offers Chart
    const offersCtx = document.getElementById('offersChart');
    if (offersCtx) {
        offersChart = new Chart(offersCtx, {
            type: 'bar',
            data: {
                labels: getMonthlyLabels(12),
                datasets: [{
                    label: 'Offers Submitted',
                    data: getChartData('offersSubmitted', 12),
                    backgroundColor: 'rgba(25, 118, 210, 0.6)',
                    borderColor: '#1976d2',
                    borderWidth: 1
                }, {
                    label: 'Offers Accepted',
                    data: getChartData('offersAccepted', 12),
                    backgroundColor: 'rgba(56, 142, 60, 0.6)',
                    borderColor: '#388e3c',
                    borderWidth: 1
                }]
            },
            options: chartConfig
        });
    }

    // Period selector
    $('#chart-period').on('change', function() {
        const months = parseInt($(this).val());
        const labels = getMonthlyLabels(months);
        
        // Fetch updated data via AJAX
        fetchChartData(months, function(data) {
            if (data) {
                // Use fetched data
                if (usersChart) {
                    usersChart.data.labels = labels;
                    usersChart.data.datasets[0].data = data.users.slice(-months);
                    usersChart.update();
                }
                
                if (revenueChart) {
                    revenueChart.data.labels = labels;
                    revenueChart.data.datasets[0].data = data.revenue.slice(-months);
                    revenueChart.update();
                }
                
                if (leadsChart) {
                    leadsChart.data.labels = labels;
                    leadsChart.data.datasets[0].data = data.requests.slice(-months);
                    leadsChart.update();
                }
                
                if (offersChart) {
                    offersChart.data.labels = labels;
                    offersChart.data.datasets[0].data = data.offersSubmitted.slice(-months);
                    offersChart.data.datasets[1].data = data.offersAccepted.slice(-months);
                    offersChart.update();
                }
            } else {
                // Fallback to client-side data slicing
        if (usersChart) {
            usersChart.data.labels = labels;
                    usersChart.data.datasets[0].data = getChartData('users', months);
            usersChart.update();
        }
        
        if (revenueChart) {
            revenueChart.data.labels = labels;
                    revenueChart.data.datasets[0].data = getChartData('revenue', months);
            revenueChart.update();
        }
        
        if (leadsChart) {
            leadsChart.data.labels = labels;
                    leadsChart.data.datasets[0].data = getChartData('requests', months);
            leadsChart.update();
        }
        
        if (offersChart) {
            offersChart.data.labels = labels;
                    offersChart.data.datasets[0].data = getChartData('offersSubmitted', months);
                    offersChart.data.datasets[1].data = getChartData('offersAccepted', months);
            offersChart.update();
        }
            }
        });
    });
});
</script>

