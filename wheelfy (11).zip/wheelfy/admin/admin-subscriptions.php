<?php
/**
 * Admin Subscriptions Management Page
 * Database-driven subscription management system
 * 
 * @package Wheelfy
 * @version 2.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!current_user_can('administrator')) {
    wp_die(__('You do not have permission to access this page.', 'wheelfy'));
}

// Ensure subscription tables exist - force create if needed
if (function_exists('wheelfy_create_subscription_tables')) {
    wheelfy_create_subscription_tables();
}

// Get subscription plans from database
$subscription_plans = wheelfy_get_subscription_plans_db(false, 'display_order', 'ASC');

// Get all subscriptions from database
$all_subscriptions = wheelfy_get_all_subscriptions(array(
    'limit' => 100,
    'orderby' => 'created_at',
    'order' => 'DESC'
));

// Get all payments from database
$all_payments = wheelfy_get_subscription_payments(array(
    'limit' => 100,
    'orderby' => 'payment_date',
    'order' => 'DESC'
));

// Get dynamic statistics from database
$stats = wheelfy_get_subscription_statistics();
$total_subscriptions = $stats['total_subscriptions'];
$active_subscriptions = $stats['active_subscriptions'];
$expired_subscriptions = $stats['expired_subscriptions'];
$cancelled_subscriptions = $stats['cancelled_subscriptions'];
$total_revenue = $stats['total_revenue'];
$monthly_recurring_revenue = $stats['monthly_recurring_revenue'];
$completed_payments = $stats['completed_payments'];
$failed_payments = $stats['failed_payments'];

// Get current tab from URL
$current_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'plans';
if (!in_array($current_tab, array('plans', 'subscriptions', 'payments'))) {
    $current_tab = 'plans';
}
?>
<div class="wrap wheelfy-admin-subscriptions">
    <div class="wheelfy-admin-header">
        <div>
            <h1 class="wp-heading-inline"><?php _e('Subscription Management', 'wheelfy'); ?></h1>
            <p class="description"><?php _e('Manage subscription plans, partner subscriptions, and payment history', 'wheelfy'); ?></p>
        </div>
    </div>
    <hr class="wp-header-end">

    <!-- Statistics Cards -->
    <div class="wheelfy-kpi-grid">
        <div class="wheelfy-kpi-card">
            <div class="kpi-icon" style="background: #e3f2fd; color: #1976d2;">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M12 2L2 7l10 5 10-5-10-5z"></path>
                    <path d="M2 17l10 5 10-5M2 12l10 5 10-5"></path>
                </svg>
            </div>
            <div class="kpi-content">
                <div class="kpi-label"><?php _e('Total Subscriptions', 'wheelfy'); ?></div>
                <div class="kpi-value"><?php echo number_format($total_subscriptions); ?></div>
            </div>
        </div>

        <div class="wheelfy-kpi-card">
            <div class="kpi-icon" style="background: #e8f5e9; color: #388e3c;">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="20 6 9 17 4 12"></polyline>
                </svg>
            </div>
            <div class="kpi-content">
                <div class="kpi-label"><?php _e('Active Subscriptions', 'wheelfy'); ?></div>
                <div class="kpi-value"><?php echo number_format($active_subscriptions); ?></div>
            </div>
        </div>

        <div class="wheelfy-kpi-card">
            <div class="kpi-icon" style="background: #fff3e0; color: #f57c00;">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <line x1="12" y1="1" x2="12" y2="23"></line>
                    <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
                </svg>
            </div>
            <div class="kpi-content">
                <div class="kpi-label"><?php _e('Monthly Recurring Revenue', 'wheelfy'); ?></div>
                <div class="kpi-value">€<?php echo number_format($monthly_recurring_revenue, 2); ?></div>
            </div>
        </div>

        <div class="wheelfy-kpi-card">
            <div class="kpi-icon" style="background: #f3e5f5; color: #7b1fa2;">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="12" cy="12" r="10"></circle>
                    <path d="M12 6v6l4 2"></path>
                </svg>
            </div>
            <div class="kpi-content">
                <div class="kpi-label"><?php _e('Total Revenue', 'wheelfy'); ?></div>
                <div class="kpi-value">€<?php echo number_format($total_revenue, 2); ?></div>
            </div>
        </div>
    </div>

    <!-- Tabs Navigation -->
    <nav class="nav-tab-wrapper wheelfy-subscription-tabs">
        <a href="<?php echo esc_url(add_query_arg('tab', 'plans', admin_url('admin.php?page=wheelfy-subscriptions'))); ?>" 
           class="nav-tab <?php echo $current_tab === 'plans' ? 'nav-tab-active' : ''; ?>" 
           data-tab="plans">
            <?php _e('Subscription Plans', 'wheelfy'); ?>
        </a>
        <a href="<?php echo esc_url(add_query_arg('tab', 'subscriptions', admin_url('admin.php?page=wheelfy-subscriptions'))); ?>" 
           class="nav-tab <?php echo $current_tab === 'subscriptions' ? 'nav-tab-active' : ''; ?>" 
           data-tab="subscriptions">
            <?php _e('Partner Subscriptions', 'wheelfy'); ?>
        </a>
        <a href="<?php echo esc_url(add_query_arg('tab', 'payments', admin_url('admin.php?page=wheelfy-subscriptions'))); ?>" 
           class="nav-tab <?php echo $current_tab === 'payments' ? 'nav-tab-active' : ''; ?>" 
           data-tab="payments">
            <?php _e('Payment History', 'wheelfy'); ?>
        </a>
    </nav>

    <!-- Subscription Plans Tab -->
    <div class="wheelfy-tab-content <?php echo $current_tab === 'plans' ? 'active' : ''; ?>" id="tab-plans">
    <div class="wheelfy-dashboard-card">
        <div class="card-header">
            <div>
                <h2><?php _e('Subscription Plans', 'wheelfy'); ?></h2>
                <p class="card-description"><?php _e('Manage available subscription plans for partners', 'wheelfy'); ?></p>
            </div>
            <button class="button button-primary" id="addPlanBtnTop">
                <span class="dashicons dashicons-plus-alt"></span>
                <?php _e('Add New Plan', 'wheelfy'); ?>
            </button>
        </div>
        <div class="card-body">
            <div class="plans-grid">
                <?php foreach ($subscription_plans as $plan) : 
                    // Get subscriber count from database
                    $subscriber_count = wheelfy_count_subscriptions_by_plan($plan->id, 'active');
                ?>
                    <div class="plan-card <?php echo $plan->is_popular ? 'popular-plan' : ''; ?>" data-plan-id="<?php echo esc_attr($plan->id); ?>">
                        <?php if ($plan->is_popular) : ?>
                            <div class="popular-badge"><?php _e('Most Popular', 'wheelfy'); ?></div>
                        <?php endif; ?>
                        <?php if (!$plan->is_active) : ?>
                            <div class="inactive-badge" style="position: absolute; top: -12px; left: 24px; background: #dc3545; color: #fff; padding: 4px 12px; border-radius: 12px; font-size: 11px; font-weight: 600;"><?php _e('Inactive', 'wheelfy'); ?></div>
                        <?php endif; ?>
                        <div class="plan-header">
                            <h3><?php echo esc_html($plan->plan_name); ?></h3>
                            <div class="plan-price">
                                <?php 
                                $currency = $plan->currency ?: 'EUR';
                                $price_display = number_format($plan->price, 0, ',', ' ');
                                
                                if ($plan->price > 0) : 
                                    $currency_symbol = ($currency === 'HUF') ? 'HUF' : '€';
                                    ?>
                                    <span class="amount"><?php echo esc_html($price_display); ?></span>
                                    <span class="currency"> <?php echo esc_html($currency_symbol); ?></span>
                                    <span class="period"> /<?php echo esc_html($plan->billing_cycle); ?></span>
                                <?php else : ?>
                                    <span class="amount"><?php _e('Free', 'wheelfy'); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="plan-features">
                            <?php 
                            // Get features from features_list (stored as array)
                            $features_display = is_array($plan->features_list) ? $plan->features_list : array();
                            ?>
                            <ul class="features-list-display">
                                <?php if (!empty($features_display)) : ?>
                                    <?php foreach ($features_display as $feature) : 
                                        $feature_text = is_array($feature) && isset($feature['text']) ? $feature['text'] : (is_string($feature) ? $feature : '');
                                        $feature_icon = is_array($feature) && isset($feature['icon']) ? $feature['icon'] : 'check';
                                        $icon_symbol = ($feature_icon === 'cross') ? '✗' : '✓';
                                        $icon_color = ($feature_icon === 'cross') ? '#ef4444' : '#46b450';
                                        if (empty(trim($feature_text))) continue;
                                    ?>
                                        <li><span style="color: <?php echo esc_attr($icon_color); ?>; font-weight: bold; margin-right: 8px;"><?php echo esc_html($icon_symbol); ?></span><?php echo esc_html($feature_text); ?></li>
                                    <?php endforeach; ?>
                                <?php else : ?>
                                    <li><?php _e('No features added yet', 'wheelfy'); ?></li>
                                <?php endif; ?>
                            </ul>
                        </div>

                        <div class="plan-actions">
                            <a href="javascript:void(0);" class="button button-secondary plan-edit-btn" 
                               data-plan-id="<?php echo esc_attr($plan->id); ?>">
                                <span class="dashicons dashicons-edit"></span>
                                <?php _e('Edit', 'wheelfy'); ?>
                            </a>
                            <a href="javascript:void(0);" class="button button-link-delete plan-delete-btn" 
                               data-plan-id="<?php echo esc_attr($plan->id); ?>">
                                <span class="dashicons dashicons-trash"></span>
                                <?php _e('Delete', 'wheelfy'); ?>
                            </a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    </div>

    <!-- Partner Subscriptions Tab -->
    <div class="wheelfy-tab-content <?php echo $current_tab === 'subscriptions' ? 'active' : ''; ?>" id="tab-subscriptions">
    <div class="wheelfy-dashboard-card">
        <div class="card-header">
            <div>
                <h2><?php _e('Partner Subscriptions', 'wheelfy'); ?></h2>
                <p class="card-description"><?php _e('View and manage partner subscription statuses', 'wheelfy'); ?></p>
            </div>
            <div class="header-filters">
                <input type="search" id="search-subscriptions" class="search-input" placeholder="<?php esc_attr_e('Search partners...', 'wheelfy'); ?>">
                <select id="filter-status" class="filter-select">
                    <option value="all"><?php _e('All Status', 'wheelfy'); ?></option>
                    <option value="active"><?php _e('Active', 'wheelfy'); ?></option>
                    <option value="expired"><?php _e('Expired', 'wheelfy'); ?></option>
                    <option value="cancelled"><?php _e('Cancelled', 'wheelfy'); ?></option>
                </select>
                <select id="filter-plan" class="filter-select">
                    <option value="all"><?php _e('All Plans', 'wheelfy'); ?></option>
                    <option value="free"><?php _e('Free', 'wheelfy'); ?></option>
                    <option value="basic"><?php _e('Basic', 'wheelfy'); ?></option>
                    <option value="premium"><?php _e('Premium', 'wheelfy'); ?></option>
                </select>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="wp-list-table widefat fixed striped subscriptions-table">
                    <thead>
                        <tr>
                            <th class="column-partner"><?php _e('Partner', 'wheelfy'); ?></th>
                            <th class="column-plan"><?php _e('Plan', 'wheelfy'); ?></th>
                            <th class="column-status"><?php _e('Status', 'wheelfy'); ?></th>
                            <th class="column-dates"><?php _e('Start Date', 'wheelfy'); ?></th>
                            <th class="column-dates"><?php _e('Next Payment', 'wheelfy'); ?></th>
                            <th class="column-billing"><?php _e('Billing Cycle', 'wheelfy'); ?></th>
                            <th class="column-amount"><?php _e('Amount', 'wheelfy'); ?></th>
                            <th class="column-auto-renew"><?php _e('Auto Renew', 'wheelfy'); ?></th>
                            <th class="column-actions"><?php _e('Actions', 'wheelfy'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($all_subscriptions)) : ?>
                            <?php foreach ($all_subscriptions as $sub) : ?>
                                <tr data-status="<?php echo esc_attr($sub->status); ?>" data-plan="<?php echo esc_attr($sub->plan_slug); ?>" data-partner="<?php echo esc_attr(strtolower($sub->partner_name)); ?>">
                                    <td class="column-partner">
                                        <strong><?php echo esc_html($sub->partner_name ?: 'Unknown'); ?></strong>
                                        <div style="font-size: 12px; color: #646970;"><?php echo esc_html($sub->partner_email); ?></div>
                                    </td>
                                    <td class="column-plan">
                                        <span class="plan-badge plan-<?php echo esc_attr($sub->plan_slug); ?>">
                                            <?php echo esc_html($sub->plan_name ?: 'Unknown Plan'); ?>
                                        </span>
                                    </td>
                                    <td class="column-status">
                                        <span class="status-badge status-<?php echo esc_attr($sub->status); ?>">
                                            <?php echo esc_html(wheelfy_get_subscription_status_label($sub->status)); ?>
                                        </span>
                                    </td>
                                    <td class="column-dates">
                                        <?php echo $sub->start_date ? esc_html(date_i18n(get_option('date_format'), strtotime($sub->start_date))) : '-'; ?>
                                    </td>
                                    <td class="column-dates">
                                        <?php if ($sub->status === 'active' && $sub->next_payment_date) : ?>
                                            <?php echo esc_html(date_i18n(get_option('date_format'), strtotime($sub->next_payment_date))); ?>
                                        <?php elseif ($sub->status === 'expired') : ?>
                                            <span class="text-muted"><?php _e('Expired', 'wheelfy'); ?></span>
                                        <?php elseif ($sub->status === 'cancelled') : ?>
                                            <span class="text-muted"><?php _e('Cancelled', 'wheelfy'); ?></span>
                                        <?php else : ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="column-billing">
                                        <?php echo esc_html(ucfirst($sub->billing_cycle)); ?>
                                    </td>
                                    <td class="column-amount">
                                        <strong><?php echo esc_html(wheelfy_format_subscription_price($sub->payment_amount, $sub->currency)); ?></strong>
                                    </td>
                                    <td class="column-auto-renew">
                                        <?php if ($sub->auto_renew) : ?>
                                            <span class="dashicons dashicons-yes-alt" style="color: #46b450;" title="<?php _e('Auto-renew enabled', 'wheelfy'); ?>"></span>
                                        <?php else : ?>
                                            <span class="dashicons dashicons-dismiss" style="color: #dc3232;" title="<?php _e('Auto-renew disabled', 'wheelfy'); ?>"></span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="column-actions">
                                        <div class="row-actions">
                                            <a href="javascript:void(0);" class="button button-small action-view" data-sub-id="<?php echo esc_attr($sub->id); ?>" title="<?php esc_attr_e('View Details', 'wheelfy'); ?>">
                                                <span class="dashicons dashicons-visibility"></span>
                                                <?php _e('View', 'wheelfy'); ?>
                                            </a>
                                            <?php if ($sub->status === 'active') : ?>
                                                <a href="javascript:void(0);" class="button button-small action-cancel-subscription" data-sub-id="<?php echo esc_attr($sub->id); ?>" title="<?php esc_attr_e('Cancel Subscription', 'wheelfy'); ?>">
                                                    <span class="dashicons dashicons-dismiss"></span>
                                                    <?php _e('Cancel', 'wheelfy'); ?>
                                                </a>
                                            <?php endif; ?>
                                            <a href="<?php echo esc_url(home_url('/partner-dashboard?user_id=' . $sub->user_id)); ?>" target="_blank" class="button button-small action-view-partner" data-partner-id="<?php echo esc_attr($sub->user_id); ?>" title="<?php esc_attr_e('View Partner Dashboard', 'wheelfy'); ?>">
                                                <span class="dashicons dashicons-external"></span>
                                                <?php _e('Partner', 'wheelfy'); ?>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else : ?>
                            <tr>
                                <td colspan="9" class="text-center" style="padding: 40px; text-align: center; color: #646970;">
                                    <?php _e('No subscriptions found. Partner subscriptions will appear here when partners subscribe to plans.', 'wheelfy'); ?>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    </div>

    <!-- Payment History Tab -->
    <div class="wheelfy-tab-content <?php echo $current_tab === 'payments' ? 'active' : ''; ?>" id="tab-payments">
    <div class="wheelfy-dashboard-card">
        <div class="card-header">
            <div>
                <h2><?php _e('Payment History', 'wheelfy'); ?></h2>
                <p class="card-description"><?php _e('Track all subscription payments and transactions', 'wheelfy'); ?></p>
            </div>
            <div class="header-filters">
                <input type="search" id="search-payments" class="search-input" placeholder="<?php esc_attr_e('Search payments...', 'wheelfy'); ?>">
                <input type="date" id="filter-date-from" class="date-input" placeholder="<?php esc_attr_e('From', 'wheelfy'); ?>">
                <input type="date" id="filter-date-to" class="date-input" placeholder="<?php esc_attr_e('To', 'wheelfy'); ?>">
                <select id="filter-payment-status" class="filter-select">
                    <option value="all"><?php _e('All Status', 'wheelfy'); ?></option>
                    <option value="completed"><?php _e('Completed', 'wheelfy'); ?></option>
                    <option value="failed"><?php _e('Failed', 'wheelfy'); ?></option>
                    <option value="pending"><?php _e('Pending', 'wheelfy'); ?></option>
                </select>
                <button class="button" id="filter-payments-btn"><?php _e('Filter', 'wheelfy'); ?></button>
                <button class="button button-secondary" id="export-payments-btn">
                    <span class="dashicons dashicons-download"></span>
                    <?php _e('Export', 'wheelfy'); ?>
                </button>
            </div>
        </div>
        <div class="card-body">
            <div class="payment-stats-bar">
                <div class="stat-item">
                    <span class="stat-label"><?php _e('Total Payments:', 'wheelfy'); ?></span>
                    <span class="stat-value"><?php echo count($all_payments); ?></span>
                </div>
                <div class="stat-item">
                    <span class="stat-label"><?php _e('Completed:', 'wheelfy'); ?></span>
                    <span class="stat-value success"><?php echo number_format($completed_payments); ?></span>
                </div>
                <div class="stat-item">
                    <span class="stat-label"><?php _e('Failed:', 'wheelfy'); ?></span>
                    <span class="stat-value error"><?php echo number_format($failed_payments); ?></span>
                </div>
                <div class="stat-item">
                    <span class="stat-label"><?php _e('Total Revenue:', 'wheelfy'); ?></span>
                    <span class="stat-value"><?php echo esc_html(wheelfy_format_subscription_price($total_revenue, 'HUF')); ?></span>
                </div>
            </div>
            <div class="table-responsive">
                <table class="wp-list-table widefat fixed striped payments-table">
                    <thead>
                        <tr>
                            <th class="column-date"><?php _e('Date', 'wheelfy'); ?></th>
                            <th class="column-partner"><?php _e('Partner', 'wheelfy'); ?></th>
                            <th class="column-amount"><?php _e('Amount', 'wheelfy'); ?></th>
                            <th class="column-status"><?php _e('Status', 'wheelfy'); ?></th>
                            <th class="column-method"><?php _e('Payment Method', 'wheelfy'); ?></th>
                            <th class="column-transaction"><?php _e('Transaction ID', 'wheelfy'); ?></th>
                            <th class="column-invoice"><?php _e('Invoice', 'wheelfy'); ?></th>
                            <th class="column-actions"><?php _e('Actions', 'wheelfy'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($all_payments)) : ?>
                            <?php foreach ($all_payments as $payment) : ?>
                                <tr data-status="<?php echo esc_attr($payment->status); ?>" data-partner="<?php echo esc_attr(strtolower($payment->partner_name ?: '')); ?>">
                                    <td class="column-date">
                                        <?php echo $payment->payment_date ? esc_html(date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($payment->payment_date))) : '-'; ?>
                                    </td>
                                    <td class="column-partner">
                                        <strong><?php echo esc_html($payment->partner_name ?: 'Unknown'); ?></strong>
                                        <div style="font-size: 12px; color: #646970;"><?php echo esc_html($payment->partner_email); ?></div>
                                    </td>
                                    <td class="column-amount">
                                        <strong><?php echo esc_html(wheelfy_format_subscription_price($payment->amount, $payment->currency)); ?></strong>
                                    </td>
                                    <td class="column-status">
                                        <span class="status-badge status-<?php echo esc_attr($payment->status); ?>">
                                            <?php echo esc_html(ucfirst($payment->status)); ?>
                                        </span>
                                    </td>
                                    <td class="column-method">
                                        <span class="payment-method-badge">
                                            <?php echo esc_html($payment->payment_method ?: '-'); ?>
                                        </span>
                                    </td>
                                    <td class="column-transaction">
                                        <?php if ($payment->transaction_id) : ?>
                                            <code class="transaction-id"><?php echo esc_html($payment->transaction_id); ?></code>
                                        <?php else : ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="column-invoice">
                                        <?php if ($payment->invoice_number) : ?>
                                            <a href="#" class="invoice-link"><?php echo esc_html($payment->invoice_number); ?></a>
                                        <?php else : ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="column-actions">
                                        <div class="row-actions">
                                            <a href="javascript:void(0);" class="button button-small action-view-payment" data-payment-id="<?php echo esc_attr($payment->id); ?>" title="<?php esc_attr_e('View Details', 'wheelfy'); ?>">
                                                <span class="dashicons dashicons-visibility"></span>
                                                <?php _e('View', 'wheelfy'); ?>
                                            </a>
                                            <?php if ($payment->status === 'failed') : ?>
                                                <a href="javascript:void(0);" class="button button-small action-retry-payment" data-payment-id="<?php echo esc_attr($payment->id); ?>" title="<?php esc_attr_e('Retry Payment', 'wheelfy'); ?>">
                                                    <span class="dashicons dashicons-update"></span>
                                                    <?php _e('Retry', 'wheelfy'); ?>
                                                </a>
                                            <?php endif; ?>
                                            <?php if ($payment->invoice_number) : ?>
                                                <a href="javascript:void(0);" class="button button-small action-download-invoice" data-payment-id="<?php echo esc_attr($payment->id); ?>" title="<?php esc_attr_e('Download Invoice', 'wheelfy'); ?>">
                                                    <span class="dashicons dashicons-media-document"></span>
                                                    <?php _e('Invoice', 'wheelfy'); ?>
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else : ?>
                            <tr>
                                <td colspan="8" class="text-center" style="padding: 40px; text-align: center; color: #646970;">
                                    <?php _e('No payment records found. Payments will appear here when partners make subscription payments.', 'wheelfy'); ?>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    </div>
</div>

<!-- Plan Modal -->
<div id="wheelfyPlanModal" class="wheelfy-plan-modal">
    <div class="wheelfy-plan-modal-content">
        <div class="wheelfy-plan-modal-header">
            <h2 id="planModalTitle"><?php _e('Add New Plan', 'wheelfy'); ?></h2>
            <button class="wheelfy-plan-modal-close">&times;</button>
        </div>
        <form id="planForm">
            <div class="wheelfy-plan-modal-body">
                <input type="hidden" id="plan_id" name="plan_id" value="">
                
                <div class="form-field">
                    <label for="plan_name"><?php _e('Plan Name', 'wheelfy'); ?> <span class="required">*</span></label>
                    <input type="text" id="plan_name" name="plan_name" class="regular-text" required>
                </div>
                
                <div class="form-field">
                    <label for="plan_currency"><?php _e('Currency', 'wheelfy'); ?></label>
                    <select id="plan_currency" name="plan_currency" class="regular-text">
                        <option value="EUR">EUR (€)</option>
                        <option value="HUF" selected>HUF</option>
                        <option value="USD">USD ($)</option>
                        <option value="GBP">GBP (£)</option>
                    </select>
                    <p class="description"><?php _e('Select the currency for this plan', 'wheelfy'); ?></p>
                </div>
                
                <div class="form-field">
                    <label for="plan_price"><?php _e('Price', 'wheelfy'); ?></label>
                    <input type="number" id="plan_price" name="plan_price" class="regular-text" step="1" min="0" value="0">
                    <p class="description"><?php _e('Enter 0 for free plan. Enter amount in the selected currency (e.g., 24900 for 24,900 HUF)', 'wheelfy'); ?></p>
                </div>
                
                <div class="form-field">
                    <label for="plan_billing_cycle"><?php _e('Billing Cycle', 'wheelfy'); ?></label>
                    <select id="plan_billing_cycle" name="plan_billing_cycle" class="regular-text">
                        <option value="monthly" selected><?php _e('Monthly', 'wheelfy'); ?></option>
                        <option value="yearly"><?php _e('Yearly', 'wheelfy'); ?></option>
                        <option value="one_time"><?php _e('One Time', 'wheelfy'); ?></option>
                    </select>
                    <p class="description"><?php _e('Select how often this plan is billed', 'wheelfy'); ?></p>
                </div>
                
                <div class="form-field">
                    <label for="plan_commission_rate"><?php _e('Commission Rate (%)', 'wheelfy'); ?></label>
                    <input type="number" id="plan_commission_rate" name="plan_commission_rate" class="regular-text" step="0.1" min="0" max="100" value="6.9">
                    <p class="description"><?php _e('Commission rate per completed service. Set to 0 if commission is included in subscription', 'wheelfy'); ?></p>
                </div>
                
                <div class="form-field">
                    <label for="plan_bidding_restriction"><?php _e('Bidding Restriction', 'wheelfy'); ?></label>
                    <select id="plan_bidding_restriction" name="plan_bidding_restriction" class="regular-text">
                        <option value="top3"><?php _e('Top 3 Lowest Bidders Only', 'wheelfy'); ?></option>
                        <option value="none" selected><?php _e('No Restrictions (Free Bidding)', 'wheelfy'); ?></option>
                    </select>
                    <p class="description"><?php _e('Restrict bidding to top 3 lowest bidders, or allow free bidding', 'wheelfy'); ?></p>
                </div>
                
                <div class="form-field">
                    <label><?php _e('Additional Features', 'wheelfy'); ?></label>
                    <div id="plan-features-repeater" class="features-repeater">
                        <div class="features-list"></div>
                        <button type="button" class="button button-secondary add-feature-btn">
                            <span class="dashicons dashicons-plus-alt"></span>
                            <?php _e('Add Feature', 'wheelfy'); ?>
                        </button>
                    </div>
                    <p class="description"><?php _e('Add multiple features that will be displayed as a list on the plan card', 'wheelfy'); ?></p>
                </div>
                
                <div class="form-field">
                    <label>
                        <input type="checkbox" id="plan_popular" name="plan_popular" value="1">
                        <?php _e('Mark as Most Popular', 'wheelfy'); ?>
                    </label>
                </div>
            </div>
            <div class="wheelfy-plan-modal-footer">
                <button type="button" class="button" id="planModalCancel"><?php _e('Cancel', 'wheelfy'); ?></button>
                <button type="submit" class="button button-primary" id="planModalSave"><?php _e('Save Plan', 'wheelfy'); ?></button>
            </div>
        </form>
    </div>
</div>

<style>
/* Modern Subscription Management Styles */
.wheelfy-admin-subscriptions {
    max-width: 1600px;
    margin: 20px 0;
}

/* Tab Navigation Styles */
.wheelfy-subscription-tabs {
    margin: 20px 0 0 0;
    border-bottom: 1px solid #ccc;
}

.wheelfy-subscription-tabs .nav-tab {
    margin-left: 0;
    margin-right: 8px;
    padding: 10px 20px;
    font-size: 14px;
    font-weight: 600;
}

.wheelfy-subscription-tabs .nav-tab:last-child {
    margin-right: 0;
}

.wheelfy-subscription-tabs .nav-tab-active {
    border-bottom-color: #fff;
    background: #fff;
    color: #2271b1;
}

/* Tab Content Styles */
.wheelfy-tab-content {
    display: none;
    margin-top: 0;
}

.wheelfy-tab-content.active {
    display: block;
}

.wheelfy-admin-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 20px;
}

.wheelfy-admin-header h1 {
    margin: 0 0 8px 0;
    font-size: 28px;
    font-weight: 600;
}

.wheelfy-admin-header .description {
    margin: 0;
    color: #646970;
    font-size: 14px;
}

.header-actions {
    display: flex;
    gap: 10px;
    align-items: center;
}

/* KPI Cards */
.wheelfy-kpi-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
    gap: 20px;
    margin: 30px 0;
}

.wheelfy-kpi-card {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 12px;
    padding: 24px;
    display: flex;
    align-items: center;
    gap: 20px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.04);
    transition: all 0.3s ease;
}

.wheelfy-kpi-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 8px 24px rgba(0,0,0,0.12);
    border-color: #2271b1;
}

.kpi-icon {
    width: 64px;
    height: 64px;
    border-radius: 16px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.kpi-icon svg {
    display: block;
    margin: 0 auto;
    width: 24px;
    height: 24px;
}

.kpi-content {
    flex: 1;
}

.kpi-label {
    font-size: 13px;
    color: #646970;
    margin-bottom: 8px;
    font-weight: 500;
}

.kpi-value {
    font-size: 32px;
    font-weight: 700;
    color: #1d2327;
    line-height: 1;
}

/* Dashboard Cards */
.wheelfy-dashboard-card {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 12px;
    margin-bottom: 30px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.04);
    overflow: hidden;
}

.card-header {
    padding: 24px;
    border-bottom: 1px solid #ddd;
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    background: #f8f9fa;
}

.card-header h2 {
    margin: 0 0 4px 0;
    font-size: 20px;
    font-weight: 600;
}

.card-description {
    margin: 0;
    color: #646970;
    font-size: 13px;
}

.header-filters {
    display: flex;
    gap: 10px;
    align-items: center;
    flex-wrap: wrap;
}

.search-input,
.filter-select,
.date-input {
    padding: 6px 12px;
    border: 1px solid #8c8f94;
    border-radius: 4px;
    font-size: 14px;
}

.search-input {
    min-width: 200px;
}

.date-input {
    min-width: 150px;
}

.filter-select {
    min-width: 140px;
}

/* Plans Grid */
.plans-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 24px;
    padding: 24px;
}

.plan-card {
    background: #fff;
    border: 2px solid #ddd;
    border-radius: 12px;
    padding: 24px;
    position: relative;
    transition: all 0.3s ease;
}

.plan-card:hover {
    border-color: #2271b1;
    box-shadow: 0 8px 24px rgba(0,0,0,0.1);
    transform: translateY(-4px);
}

.plan-card.popular-plan {
    border-color: #2271b1;
    box-shadow: 0 4px 16px rgba(34, 113, 177, 0.15);
}

.popular-badge {
    position: absolute;
    top: -12px;
    right: 24px;
    background: #2271b1;
    color: #fff;
    padding: 4px 12px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
}

.plan-header {
    margin-bottom: 20px;
}

.plan-header h3 {
    margin: 0 0 12px 0;
    font-size: 24px;
    font-weight: 600;
    color: #1d2327;
}

.plan-price {
    display: flex;
    align-items: baseline;
    gap: 4px;
}

.plan-price .currency {
    font-size: 20px;
    font-weight: 600;
    color: #646970;
}

.plan-price .amount {
    font-size: 36px;
    font-weight: 700;
    color: #1d2327;
}

.plan-price .period {
    font-size: 16px;
    color: #646970;
}

.plan-features {
    margin-bottom: 20px;
    padding-bottom: 20px;
    border-bottom: 1px solid #e5e5e5;
}

.plan-features p {
    margin: 0;
    color: #646970;
    line-height: 1.6;
}

.plan-features .features-list-display {
    list-style: none;
    padding: 0;
    margin: 0;
}

.plan-features .features-list-display li {
    color: #646970;
    font-size: 14px;
    line-height: 1.8;
    padding-left: 24px;
    position: relative;
    margin-bottom: 8px;
    padding-top: 2px;
    padding-bottom: 2px;
}

.plan-features .features-list-display li:last-child {
    margin-bottom: 0;
}

.plan-features .features-list-display li:before {
    content: "✓";
    position: absolute;
    left: 0;
    color: #46b450;
    font-weight: bold;
    font-size: 16px;
    top: 0;
    line-height: 1.8;
    width: 20px;
    display: inline-block;
}

.plan-features .features-list-display {
    margin-top: 8px;
    margin-bottom: 8px;
}

.plan-stats {
    margin-bottom: 20px;
}

.stat-item {
    display: flex;
    flex-direction: column;
    gap: 4px;
}

.stat-value {
    font-size: 24px;
    font-weight: 700;
    color: #1d2327;
}

.stat-label {
    font-size: 13px;
    color: #646970;
}

.plan-actions {
    display: flex;
    gap: 8px;
}

.plan-actions .button {
    flex: 1;
    justify-content: center;
}

/* Tables */
.table-responsive {
    overflow-x: auto;
}

.subscriptions-table,
.payments-table {
    margin: 0;
}

.subscriptions-table th,
.payments-table th {
    font-weight: 600;
    padding: 12px;
    background: #f6f7f7;
}

.subscriptions-table td,
.payments-table td {
    padding: 12px;
    vertical-align: middle;
}

.plan-badge {
    display: inline-block;
    padding: 4px 12px;
    border-radius: 12px;
    font-size: 12px;
    font-weight: 600;
    text-transform: uppercase;
}

.plan-badge.plan-free {
    background: #e5e5e5;
    color: #646970;
}

.plan-badge.plan-basic {
    background: #e3f2fd;
    color: #1976d2;
}

.plan-badge.plan-premium {
    background: #fff3e0;
    color: #f57c00;
}

.payment-method-badge {
    display: inline-block;
    padding: 4px 10px;
    background: #f0f0f1;
    border-radius: 4px;
    font-size: 12px;
    color: #646970;
}

.transaction-id {
    background: #f0f0f1;
    padding: 4px 8px;
    border-radius: 4px;
    font-family: monospace;
    font-size: 12px;
}

.invoice-link {
    color: #2271b1;
    text-decoration: none;
    font-weight: 500;
}

.invoice-link:hover {
    text-decoration: underline;
}

/* Status Badges */
.status-badge {
    display: inline-block;
    padding: 4px 12px;
    border-radius: 12px;
    font-size: 12px;
    font-weight: 600;
    text-transform: uppercase;
}

.status-badge.status-active {
    background: #d4edda;
    color: #155724;
}

.status-badge.status-expired {
    background: #f8d7da;
    color: #721c24;
}

.status-badge.status-cancelled {
    background: #d1ecf1;
    color: #0c5460;
}

.status-badge.status-completed {
    background: #d4edda;
    color: #155724;
}

.status-badge.status-failed {
    background: #f8d7da;
    color: #721c24;
}

.status-badge.status-pending {
    background: #fff3cd;
    color: #856404;
}

/* Payment Stats Bar */
.payment-stats-bar {
    display: flex;
    gap: 24px;
    padding: 16px 24px;
    background: #f8f9fa;
    border-bottom: 1px solid #ddd;
    flex-wrap: wrap;
}

.payment-stats-bar .stat-item {
    display: flex;
    align-items: center;
    gap: 8px;
}

.payment-stats-bar .stat-label {
    font-size: 13px;
    color: #646970;
}

.payment-stats-bar .stat-value {
    font-size: 16px;
    font-weight: 600;
    color: #1d2327;
}

.payment-stats-bar .stat-value.success {
    color: #155724;
}

.payment-stats-bar .stat-value.error {
    color: #721c24;
}

/* Row Actions - Force visibility */
.row-actions,
.wheelfy-admin-subscriptions .row-actions,
.wheelfy-admin-subscriptions .wp-list-table .row-actions,
.wheelfy-admin-subscriptions .wp-list-table tbody tr .row-actions,
.wheelfy-admin-subscriptions .wp-list-table tbody tr td .row-actions,
.wheelfy-admin-subscriptions table.wp-list-table .row-actions,
.wheelfy-admin-subscriptions table.wp-list-table tbody tr .row-actions,
.wheelfy-admin-subscriptions table.wp-list-table tbody tr td .row-actions {
    display: flex !important;
    visibility: visible !important;
    opacity: 1 !important;
    gap: 6px;
    flex-wrap: wrap;
}

.row-actions .button,
.wheelfy-admin-subscriptions .row-actions .button,
.wheelfy-admin-subscriptions .row-actions a {
    display: inline-flex !important;
    visibility: visible !important;
    opacity: 1 !important;
    align-items: center;
    gap: 4px;
    padding: 4px 8px;
    font-size: 12px;
    position: relative !important;
    height: auto !important;
    width: auto !important;
}

.row-actions .dashicons {
    font-size: 16px;
    width: 16px;
    height: 16px;
}

/* Ensure Actions column is visible */
.column-actions {
    width: auto !important;
    min-width: 250px;
    text-align: left;
}

.column-actions .row-actions {
    display: flex !important;
    visibility: visible !important;
    opacity: 1 !important;
    gap: 6px;
    flex-wrap: wrap;
    align-items: center;
}

/* Ensure action buttons are properly styled */
.column-actions .row-actions .button {
    margin: 0;
    white-space: nowrap;
    min-width: auto;
}

.text-muted {
    color: #646970;
}

/* Responsive */
@media (max-width: 1200px) {
    .plans-grid {
        grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    }
}

@media (max-width: 782px) {
    .wheelfy-admin-header {
        flex-direction: column;
        gap: 16px;
    }

    .header-filters {
        width: 100%;
    }

    .header-filters .search-input,
    .header-filters .filter-select,
    .header-filters .date-input {
        flex: 1;
        min-width: 0;
    }

    .plans-grid {
        grid-template-columns: 1fr;
    }

    .payment-stats-bar {
        flex-direction: column;
        gap: 12px;
    }
}

/* Plan Modal Styles */
.wheelfy-plan-modal {
    display: none;
    position: fixed;
    z-index: 100000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    overflow: auto;
    background-color: rgba(0,0,0,0.5);
    align-items: center;
    justify-content: center;
}

.wheelfy-plan-modal.active {
    display: flex;
}

.wheelfy-plan-modal-content {
    background-color: #fff;
    margin: auto;
    padding: 0;
    border: 1px solid #ddd;
    width: 90%;
    max-width: 600px;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0,0,0,0.2);
    position: relative;
}

.wheelfy-plan-modal-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 20px 24px;
    border-bottom: 1px solid #ddd;
}

.wheelfy-plan-modal-header h2 {
    margin: 0;
    font-size: 20px;
    font-weight: 600;
    color: #1d2327;
}

.wheelfy-plan-modal-close {
    color: #aaa;
    font-size: 28px;
    font-weight: bold;
    cursor: pointer;
    background: none;
    border: none;
    padding: 0;
    line-height: 1;
}

.wheelfy-plan-modal-close:hover,
.wheelfy-plan-modal-close:focus {
    color: #000;
}

.wheelfy-plan-modal-body {
    padding: 24px;
}

.form-field {
    margin-bottom: 20px;
}

.form-field label {
    display: block;
    margin-bottom: 8px;
    font-weight: 600;
    color: #1d2327;
}

.form-field .required {
    color: #d63638;
}

.form-field input[type="text"],
.form-field input[type="number"],
.form-field textarea {
    width: 100%;
    padding: 8px 12px;
    border: 1px solid #8c8f94;
    border-radius: 4px;
    font-size: 14px;
}

.form-field .description {
    margin-top: 6px;
    font-size: 13px;
    color: #646970;
}

.form-field input[type="checkbox"] {
    margin-right: 8px;
}

/* Features Repeater Styles */
.features-repeater {
    margin-top: 8px;
}

.features-list {
    margin-bottom: 12px;
}

.feature-row {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 8px;
}

.feature-row .feature-icon-select {
    width: 150px;
    flex-shrink: 0;
    padding: 8px 12px;
    border: 1px solid #8c8f94;
    border-radius: 4px;
    background: #fff;
    font-size: 13px;
    cursor: pointer;
}

.feature-row .feature-icon-select:focus {
    border-color: #2271b1;
    box-shadow: 0 0 0 1px #2271b1;
    outline: none;
}

.feature-row input[type="text"] {
    flex: 1;
    padding: 8px 12px;
    border: 1px solid #8c8f94;
    border-radius: 4px;
    font-size: 14px;
}

.feature-row .remove-feature-btn {
    padding: 8px 12px;
    min-width: auto;
    color: #d63638;
    border-color: #d63638;
}

.feature-row .remove-feature-btn:hover {
    background: #d63638;
    color: #fff;
}

.add-feature-btn {
    margin-top: 8px;
}

.plan-additional-features {
    margin-top: 6px;
}
.features-list-display-inline {
    list-style: none;
    padding: 0;
    margin: 0;
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
}
.features-list-display-inline li {
    color: #646970;
    font-size: 13px;
    padding-left: 18px;
    position: relative;
}
.features-list-display-inline li:before {
    content: "•";
    position: absolute;
    left: 0;
    color: #46b450;
    font-weight: bold;
}

.wheelfy-plan-modal-footer {
    display: flex;
    justify-content: flex-end;
    gap: 10px;
    padding: 16px 24px;
    border-top: 1px solid #ddd;
    background: #f6f7f7;
}

.wheelfy-plan-modal-footer .button {
    min-width: 100px;
}
</style>

<script>
jQuery(document).ready(function($) {
    'use strict';
    
    // Tab Navigation
    $('.wheelfy-subscription-tabs .nav-tab').on('click', function(e) {
        e.preventDefault();
        const tab = $(this).data('tab');
        
        // Update active tab
        $('.wheelfy-subscription-tabs .nav-tab').removeClass('nav-tab-active');
        $(this).addClass('nav-tab-active');
        
        // Show/hide tab content
        $('.wheelfy-tab-content').removeClass('active');
        $('#tab-' + tab).addClass('active');
        
        // Update URL without reload
        const url = new URL(window.location);
        url.searchParams.set('tab', tab);
        window.history.pushState({}, '', url);
    });
    
    // Force row-actions to always be visible
    function forceActionsVisible() {
        $('.wheelfy-admin-subscriptions .row-actions').each(function() {
            $(this).css({
                'display': 'flex',
                'visibility': 'visible',
                'opacity': '1'
            });
        });
        
        $('.wheelfy-admin-subscriptions .row-actions .button, .wheelfy-admin-subscriptions .row-actions a').each(function() {
            $(this).css({
                'display': 'inline-flex',
                'visibility': 'visible',
                'opacity': '1'
            });
        });
    }
    
    // Run immediately and after delays
    forceActionsVisible();
    setTimeout(forceActionsVisible, 100);
    setTimeout(forceActionsVisible, 500);
    setTimeout(forceActionsVisible, 1000);
    
    // Use MutationObserver to ensure actions stay visible
    if (typeof MutationObserver !== 'undefined') {
        const observer = new MutationObserver(function(mutations) {
            forceActionsVisible();
        });
        
        const targetNode = document.querySelector('.wheelfy-admin-subscriptions');
        if (targetNode) {
            observer.observe(targetNode, {
                childList: true,
                subtree: true,
                attributes: true,
                attributeFilter: ['style', 'class']
            });
        }
    }
    
    // Search functionality for subscriptions
    $('#search-subscriptions').on('input', function() {
        const searchTerm = $(this).val().toLowerCase();
        $('.subscriptions-table tbody tr').each(function() {
            const partnerName = $(this).find('.column-partner').text().toLowerCase();
            if (partnerName.includes(searchTerm)) {
                $(this).show();
            } else {
                $(this).hide();
            }
        });
    });
    
    // Filter by status
    $('#filter-status').on('change', function() {
        const status = $(this).val();
        $('.subscriptions-table tbody tr').each(function() {
            if (status === 'all' || $(this).data('status') === status) {
                $(this).show();
            } else {
                $(this).hide();
            }
        });
    });
    
    // Filter by plan
    $('#filter-plan').on('change', function() {
        const plan = $(this).val();
        $('.subscriptions-table tbody tr').each(function() {
            if (plan === 'all' || $(this).data('plan') === plan) {
                $(this).show();
            } else {
                $(this).hide();
            }
        });
    });
    
    // Search functionality for payments
    $('#search-payments').on('input', function() {
        const searchTerm = $(this).val().toLowerCase();
        $('.payments-table tbody tr').each(function() {
            const partnerName = $(this).find('.column-partner').text().toLowerCase();
            const transactionId = $(this).find('.transaction-id').text().toLowerCase();
            if (partnerName.includes(searchTerm) || transactionId.includes(searchTerm)) {
                $(this).show();
            } else {
                $(this).hide();
            }
        });
    });
    
    // Filter payments by date and status
    $('#filter-payments-btn').on('click', function() {
        const fromDate = $('#filter-date-from').val();
        const toDate = $('#filter-date-to').val();
        const status = $('#filter-payment-status').val();
        
        $('.payments-table tbody tr').each(function() {
            let show = true;
            const $row = $(this);
            
            // Filter by status
            if (status !== 'all' && $row.data('status') !== status) {
                show = false;
            }
            
            // Filter by date range
            if (show && (fromDate || toDate)) {
                const rowDate = $row.find('.column-date').text().trim();
                // Simple date comparison (you may want to improve this)
                if (fromDate && rowDate < fromDate) {
                    show = false;
                }
                if (toDate && rowDate > toDate) {
                    show = false;
                }
            }
            
            if (show) {
                $row.show();
            } else {
                $row.hide();
            }
        });
    });
    
    // Plan Management Modal
    const planModal = $('#wheelfyPlanModal');
    const planForm = $('#planForm');
    let isEditMode = false;
    let currentPlanId = null;
    
    // Features Repeater Functions
    function addFeatureRow(value = '', iconType = 'check') {
        const escapedValue = value ? value.replace(/"/g, '&quot;').replace(/'/g, '&#039;') : '';
        const row = $('<div class="feature-row">' +
            '<select class="feature-icon-select regular-text" title="<?php echo esc_js(__('Feature Permission', 'wheelfy')); ?>">' +
            '<option value="check" ' + (iconType === 'check' ? 'selected' : '') + '>✓ <?php echo esc_js(__('Allowed', 'wheelfy')); ?></option>' +
            '<option value="cross" ' + (iconType === 'cross' ? 'selected' : '') + '>✗ <?php echo esc_js(__('Not Allowed', 'wheelfy')); ?></option>' +
            '</select>' +
            '<input type="text" class="feature-input regular-text" value="' + escapedValue + '" placeholder="<?php echo esc_js(__('Enter feature', 'wheelfy')); ?>">' +
            '<button type="button" class="button remove-feature-btn" title="<?php echo esc_js(__('Remove', 'wheelfy')); ?>">' +
            '<span class="dashicons dashicons-trash"></span>' +
            '</button>' +
            '</div>');
        $('.features-list').append(row);
        
        // Attach event listener to new input for real-time updates
        row.find('.feature-input').on('input keyup paste', function() {
            updatePlanCardFeatures();
        });
        
        // Attach event listener to icon selector
        row.find('.feature-icon-select').on('change', function() {
            updatePlanCardFeatures();
        });
        
        // Trigger update immediately when row is added
        updatePlanCardFeatures();
    }
    
    function loadFeatures(features) {
        $('.features-list').empty();
        console.log('loadFeatures called with:', features); // Debug
        if (features && Array.isArray(features) && features.length > 0) {
            features.forEach(function(feature) {
                let featureText = '';
                let iconType = 'check';
                
                if (typeof feature === 'string') {
                    featureText = feature.trim();
                } else if (typeof feature === 'object' && feature !== null) {
                    featureText = feature.text || feature.name || '';
                    iconType = feature.icon || feature.icon_type || 'check';
                }
                
                if (featureText) {
                    addFeatureRow(featureText, iconType);
                }
            });
            console.log('Loaded ' + features.length + ' features'); // Debug
        } else {
            console.log('No features to load or invalid format'); // Debug
        }
    }
    
    function getFeatures() {
        const features = [];
        // Make sure we're looking inside the modal
        const $modal = $('#wheelfyPlanModal');
        const $featureRows = $modal.find('.feature-row');
        
        console.log('getFeatures: Found', $featureRows.length, 'feature rows');
        
        $featureRows.each(function() {
            const $row = $(this);
            const $input = $row.find('.feature-input');
            const text = $input.length ? $input.val() : '';
            const iconType = $row.find('.feature-icon-select').val() || 'check';
            
            console.log('getFeatures: Input value:', text, 'Icon:', iconType);
            
            // Include text even if it's being typed (not trimmed yet)
            const trimmedText = text ? text.trim() : '';
            if (trimmedText.length > 0) {
                features.push({
                    text: trimmedText,
                    icon: iconType
                });
            }
        });
        
        console.log('getFeatures: Returning', features.length, 'features');
        return features;
    }
    
    // Function to update plan card features list dynamically
    let updateFeaturesTimeout;
    function updatePlanCardFeatures() {
        clearTimeout(updateFeaturesTimeout);
        
        // Function to perform the actual update
        function performUpdate() {
            // Update if modal is open (either adding or editing)
            const $modal = $('#wheelfyPlanModal');
            if (!$modal.hasClass('active')) {
                return; // Modal not open, skip update
            }
            
            const features = getFeatures();
            console.log('updatePlanCardFeatures: Found', features.length, 'features');
            
            // Find the card being edited (use currentPlanId if available, otherwise find from modal)
            let $card = null;
            let planIdToFind = currentPlanId;
            
            if (!planIdToFind) {
                // Fallback: find card from modal context
                planIdToFind = $modal.find('#plan_id').val();
            }
            
            console.log('updatePlanCardFeatures: Looking for plan ID:', planIdToFind);
            
            if (planIdToFind) {
                // Try both card types
                $card = $('.plan-card[data-plan-id="' + planIdToFind + '"], .nidfil-plan-card[data-plan-id="' + planIdToFind + '"]');
                console.log('updatePlanCardFeatures: Card found:', $card.length > 0);
            } else {
                console.log('updatePlanCardFeatures: No plan ID found, cannot update card');
            }
            
            if ($card && $card.length) {
                let featuresHtml = '';
                
                // Filter out empty features
                const validFeatures = features.filter(function(f) {
                    const text = typeof f === 'object' && f.text ? f.text : f;
                    return text && typeof text === 'string' && text.trim().length > 0;
                });
                
                console.log('updatePlanCardFeatures: Valid features:', validFeatures.length);
                
                if (validFeatures.length > 0) {
                    featuresHtml = '<ul class="features-list-display">';
                    validFeatures.forEach(function(f) {
                        const featureText = typeof f === 'object' && f.text ? f.text : f;
                        const iconType = typeof f === 'object' && f.icon ? f.icon : 'check';
                        const iconSymbol = iconType === 'cross' ? '✗' : '✓';
                        const iconColor = iconType === 'cross' ? '#ef4444' : '#46b450';
                        featuresHtml += '<li><span style="color: ' + iconColor + '; font-weight: bold; margin-right: 8px;">' + iconSymbol + '</span>' + $('<div>').text(featureText).html() + '</li>';
                    });
                    featuresHtml += '</ul>';
                } else {
                    featuresHtml = '<ul class="features-list-display"><li><?php echo esc_js(__('No features added yet', 'wheelfy')); ?></li></ul>';
                }
                
                const $featuresContainer = $card.find('.plan-features');
                if ($featuresContainer.length) {
                    $featuresContainer.html(featuresHtml);
                    console.log('updatePlanCardFeatures: Updated card features HTML');
                } else {
                    console.log('updatePlanCardFeatures: Features container not found in card');
                }
            } else {
                console.log('updatePlanCardFeatures: Card not found, cannot update');
            }
        }
        
        // Debounce: wait 50ms before updating (faster response for better UX)
        updateFeaturesTimeout = setTimeout(performUpdate, 50);
    }
    
    // Add feature button
    $(document).on('click', '.add-feature-btn', function(e) {
        e.preventDefault();
        addFeatureRow();
        updatePlanCardFeatures();
    });
    
    // Remove feature button
    $(document).on('click', '.remove-feature-btn', function(e) {
        e.preventDefault();
        $(this).closest('.feature-row').remove();
        updatePlanCardFeatures();
    });
    
    // Real-time updates for feature inputs (including existing ones)
    $(document).on('input keyup paste change', '.feature-input', function() {
        updatePlanCardFeatures();
    });
    
    // Real-time updates for icon selector
    $(document).on('change', '.feature-icon-select', function() {
        updatePlanCardFeatures();
    });
    
    // Open modal for adding new plan
    $('#addPlanBtnTop').on('click', function(e) {
        e.preventDefault();
        isEditMode = false;
        currentPlanId = null;
        $('#planModalTitle').text('<?php echo esc_js(__('Add New Plan', 'wheelfy')); ?>');
        $('#planForm')[0].reset();
        $('#plan_id').val('');
        $('.features-list').empty(); // Clear repeater features
        planModal.addClass('active');
    });
    
    // Open modal for editing plan
    $(document).on('click', '.plan-edit-btn', function(e) {
        e.preventDefault();
        e.stopPropagation();
        const planId = $(this).data('plan-id');
        if (!planId) return;
        
        isEditMode = true;
        currentPlanId = planId;
        $('#planModalTitle').text('<?php echo esc_js(__('Edit Plan', 'wheelfy')); ?>');
        
        // Clear form and features list first
        planForm[0].reset();
        $('.features-list').empty();
        
        // Load plan data via AJAX from database
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'wheelfy_get_plan_db',
                plan_id: planId,
                nonce: '<?php echo wp_create_nonce('wheelfy_subscription_nonce'); ?>'
            },
            success: function(response) {
                if (response && response.success && response.data.plan) {
                    const plan = response.data.plan;
                    $('#plan_id').val(plan.id);
                    $('#plan_name').val(plan.plan_name || plan.name);
                    $('#plan_price').val(plan.price);
                    $('#plan_currency').val(plan.currency || 'HUF');
                    $('#plan_billing_cycle').val(plan.billing_cycle || 'monthly');
                    $('#plan_commission_rate').val(plan.commission_rate || 0);
                    $('#plan_bidding_restriction').val(plan.bidding_restriction || 'none');
                    
                    // Load repeater features (Additional Features) - from features_list
                    const repeaterFeatures = (plan.features_list && Array.isArray(plan.features_list) && plan.features_list.length > 0) ? plan.features_list : [];
                    console.log('Loading plan features_list:', repeaterFeatures);
                    loadFeatures(repeaterFeatures);
                    
                    $('#plan_popular').prop('checked', plan.is_popular == 1 || plan.is_popular === true || plan.popular === true);
                    planModal.addClass('active');
                } else {
                    alert('<?php echo esc_js(__('Failed to load plan data.', 'wheelfy')); ?>');
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', status, error); // Debug
                alert('<?php echo esc_js(__('An error occurred while loading plan data.', 'wheelfy')); ?>');
            }
        });
        
        return false;
    });
    
    // Delete plan
    $(document).on('click', '.plan-delete-btn', function(e) {
        e.preventDefault();
        e.stopPropagation();
        const planId = $(this).data('plan-id');
        if (!planId) return;
        
        if (!confirm('<?php echo esc_js(__('Are you sure you want to delete this plan? This action cannot be undone.', 'wheelfy')); ?>')) {
            return false;
        }
        
        const $btn = $(this);
        $btn.prop('disabled', true);
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'wheelfy_delete_plan_db',
                plan_id: planId,
                nonce: '<?php echo wp_create_nonce('wheelfy_subscription_nonce'); ?>'
            },
            success: function(response) {
                if (response && response.success) {
                    // Remove plan card from DOM
                    $btn.closest('.plan-card').fadeOut(300, function() {
                        $(this).remove();
                    });
                    showAdminNotice(response.data.message || '<?php echo esc_js(__('Plan deleted successfully.', 'wheelfy')); ?>', 'success');
                    // Reload page after a short delay to refresh statistics
                    setTimeout(function() {
                        location.reload();
                    }, 1000);
                } else {
                    alert(response.data.message || '<?php echo esc_js(__('Failed to delete plan.', 'wheelfy')); ?>');
                    $btn.prop('disabled', false);
                }
            },
            error: function() {
                alert('<?php echo esc_js(__('An error occurred while deleting the plan.', 'wheelfy')); ?>');
                $btn.prop('disabled', false);
            }
        });
        
        return false;
    });
    
    // Close modal
    $('.wheelfy-plan-modal-close, #planModalCancel').on('click', function() {
        planModal.removeClass('active');
        planForm[0].reset();
    });
    
    // Close modal when clicking outside
    planModal.on('click', function(e) {
        if ($(e.target).is(planModal)) {
            planModal.removeClass('active');
            planForm[0].reset();
        }
    });
    
    // Save plan form
    planForm.on('submit', function(e) {
        e.preventDefault();
        
        const $submitBtn = $('#planModalSave');
        $submitBtn.prop('disabled', true).text('<?php echo esc_js(__('Saving...', 'wheelfy')); ?>');
        
        // Collect features RIGHT before submitting (ensure we have latest values)
        const repeaterFeatures = getFeatures();
        
        console.log('Features to save:', repeaterFeatures);
        
        const commissionRate = parseFloat($('#plan_commission_rate').val()) || 0;
        const biddingRestriction = $('#plan_bidding_restriction').val() || 'none';
        const currency = $('#plan_currency').val() || 'EUR';
        const price = parseFloat($('#plan_price').val()) || 0;
        
        // Generate bidding restriction label
        let biddingLabel = '';
        if (biddingRestriction === 'top3') {
            biddingLabel = '<?php echo esc_js(__('Top 3 lowest bidders only', 'wheelfy')); ?>';
        } else {
            biddingLabel = commissionRate === 0 ? '<?php echo esc_js(__('Unlimited offers', 'wheelfy')); ?>' : '<?php echo esc_js(__('No restrictions', 'wheelfy')); ?>';
        }
        
        // Get billing cycle
        const billingCycle = $('#plan_billing_cycle').val() || 'monthly';
        
        // Build form data
        const formData = {
            action: 'wheelfy_save_plan_db',
            nonce: '<?php echo wp_create_nonce('wheelfy_subscription_nonce'); ?>',
            plan_id: $('#plan_id').val(),
            plan_name: $('#plan_name').val(),
            plan_price: price,
            plan_currency: currency,
            plan_billing_cycle: billingCycle,
            plan_price_display: price > 0 ? price.toLocaleString('hu-HU') : '0',
            plan_commission_rate: commissionRate,
            plan_has_commission: commissionRate > 0,
            plan_bidding_restriction: biddingRestriction,
            plan_bidding_restriction_label: biddingLabel,
            plan_features: $('#plan_features').val() || '',
            plan_popular: $('#plan_popular').is(':checked') ? '1' : '0'
        };
        
        // Build features array for WordPress - send as JSON string for reliable parsing
        if (repeaterFeatures.length > 0) {
            formData['plan_features_list_json'] = JSON.stringify(repeaterFeatures);
        }
        
        // Also send in indexed format for backward compatibility
        repeaterFeatures.forEach(function(feature, index) {
            const featureText = typeof feature === 'object' && feature.text ? feature.text : feature;
            const featureIcon = typeof feature === 'object' && feature.icon ? feature.icon : 'check';
            formData['plan_features_list[' + index + '][text]'] = featureText;
            formData['plan_features_list[' + index + '][icon]'] = featureIcon;
        });
        
        console.log('Sending features:', repeaterFeatures.length, 'items');
        console.log('Features JSON:', formData['plan_features_list_json']);
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: formData,
            traditional: false, // We're manually formatting the array
            success: function(response) {
                console.log('AJAX Response received:', response);
                
                if (response && response.success && response.data && response.data.plan) {
                    const plan = response.data.plan;
                    
                    // Debug: Log plan data
                    console.log('=== PLAN SAVED SUCCESSFULLY ===');
                    console.log('Plan object:', plan);
                    console.log('Plan ID:', plan.id);
                    console.log('Plan features_list:', plan.features_list);
                    console.log('Plan features_list type:', typeof plan.features_list);
                    console.log('Plan features_list is array:', Array.isArray(plan.features_list));
                    console.log('Plan features_list length:', plan.features_list ? plan.features_list.length : 0);
                    console.log('Plan features_list content:', JSON.stringify(plan.features_list));
                    
                    // Update card in place (no reload)
                    const $card = $('.nidfil-plan-card[data-plan-id="' + plan.id + '"], .plan-card[data-plan-id="' + plan.id + '"]');
                    console.log('Looking for card with ID:', plan.id);
                    console.log('Cards found:', $card.length);
                    
                    if ($card.length) {
                        console.log('Card found! Updating...');
                        // Title and price
                        $card.find('.plan-header h3').text(plan.name);
                        const currencySymbol = (plan.currency === 'HUF') ? 'HUF' : '€';
                        if (parseFloat(plan.price) > 0) {
                            const priceDisplay = plan.price_display || (plan.currency === 'HUF' ? parseFloat(plan.price).toLocaleString('hu-HU') : parseFloat(plan.price).toFixed(2));
                            $card.find('.plan-price').html('<span class="amount">' + priceDisplay + '</span><span class="currency"> ' + currencySymbol + '</span><span class="period"> /month</span>');
                        } else {
                            $card.find('.plan-price').html('<span class="amount"><?php echo esc_js(__('Free', 'wheelfy')); ?></span>');
                        }
                        
                        // Update plan meta (commission and bidding)
                        let metaHtml = '';
                        if ((plan.commission_rate !== undefined && plan.commission_rate > 0) || (plan.has_commission !== undefined && !plan.has_commission) || plan.bidding_restriction_label) {
                            metaHtml += '<div class="plan-meta" style="margin-top: 12px; padding-top: 12px; border-top: 1px solid #e5e5e5;">';
                            if (plan.commission_rate !== undefined && plan.commission_rate > 0) {
                                metaHtml += '<div style="font-size: 13px; color: #646970; margin-bottom: 4px;"><strong><?php echo esc_js(__('Commission:', 'wheelfy')); ?></strong> ' + plan.commission_rate + '%</div>';
                            } else if (plan.has_commission !== undefined && !plan.has_commission) {
                                metaHtml += '<div style="font-size: 13px; color: #46b450; margin-bottom: 4px;"><strong><?php echo esc_js(__('Commission:', 'wheelfy')); ?></strong> <?php echo esc_js(__('Included', 'wheelfy')); ?></div>';
                            }
                            if (plan.bidding_restriction_label) {
                                metaHtml += '<div style="font-size: 13px; color: #646970;"><strong><?php echo esc_js(__('Bidding:', 'wheelfy')); ?></strong> ' + plan.bidding_restriction_label + '</div>';
                            }
                            metaHtml += '</div>';
                        }
                        
                        // Update or create plan meta section
                        $card.find('.plan-meta').remove();
                        if (metaHtml) {
                            $card.find('.plan-header').append(metaHtml);
                        }
                        
                        // Popular badge
                        if (plan.popular) {
                            if ($card.find('.popular-badge').length === 0) {
                                $card.prepend('<div class="popular-badge"><?php echo esc_js(__('Most Popular', 'wheelfy')); ?></div>');
                            }
                        } else {
                            $card.find('.popular-badge').remove();
                        }
                        // Combine features from all sources (textarea + repeater)
                        let allFeatures = [];
                        
                        // Get features from textarea (if exists)
                        if (plan.features) {
                            if (Array.isArray(plan.features)) {
                                allFeatures = allFeatures.concat(plan.features);
                            } else if (typeof plan.features === 'string') {
                                const textFeatures = plan.features.split('\n').filter(f => f.trim());
                                allFeatures = allFeatures.concat(textFeatures);
                            }
                        }
                        
                        // Get features from repeater (features_list) - this is the main source now
                        console.log('Plan features_list from server:', plan.features_list);
                        console.log('Plan features_list type:', typeof plan.features_list);
                        console.log('Plan features_list is array:', Array.isArray(plan.features_list));
                        
                        if (plan.features_list) {
                            if (Array.isArray(plan.features_list)) {
                                plan.features_list.forEach(function(f) {
                                    if (f && typeof f === 'object' && f.text && f.text.trim()) {
                                        allFeatures.push({
                                            text: f.text.trim(),
                                            icon: f.icon || 'check'
                                        });
                                    } else if (f && typeof f === 'string' && f.trim()) {
                                        allFeatures.push({
                                            text: f.trim(),
                                            icon: 'check'
                                        });
                                    }
                                });
                            } else if (typeof plan.features_list === 'string' && plan.features_list.trim()) {
                                // Handle case where features_list might be a string
                                const featuresArray = plan.features_list.split(',').map(f => ({
                                    text: f.trim(),
                                    icon: 'check'
                                })).filter(f => f.text);
                                allFeatures = allFeatures.concat(featuresArray);
                            }
                        }
                        
                        console.log('All features collected (before dedup):', allFeatures);
                        
                        // Remove duplicates (case-insensitive) and filter out empty values
                        const uniqueFeatures = [];
                        const seenLowercase = [];
                        allFeatures.forEach(function(f) {
                            const featureText = (typeof f === 'object' && f.text) ? f.text : (typeof f === 'string' ? f : '');
                            const featureIcon = (typeof f === 'object' && f.icon) ? f.icon : 'check';
                            
                            if (featureText && typeof featureText === 'string') {
                                const trimmed = featureText.trim();
                                if (trimmed && trimmed.length > 0 && trimmed !== '') {
                                    const lower = trimmed.toLowerCase();
                                    if (seenLowercase.indexOf(lower) === -1) {
                                        uniqueFeatures.push({
                                            text: trimmed,
                                            icon: featureIcon
                                        });
                                        seenLowercase.push(lower);
                                    }
                                }
                            }
                        });
                        
                        console.log('Unique features after dedup:', uniqueFeatures);
                        console.log('Unique features count:', uniqueFeatures.length);
                        
                        // Update features list dynamically - only show "No features" if truly empty
                        let featuresHtml = '';
                        if (uniqueFeatures.length > 0) {
                            featuresHtml += '<ul class="features-list-display">';
                            uniqueFeatures.forEach(function(f) {
                                const featureText = f.text || f;
                                const iconType = f.icon || 'check';
                                const iconSymbol = iconType === 'cross' ? '✗' : '✓';
                                const iconColor = iconType === 'cross' ? '#ef4444' : '#46b450';
                                
                                if (featureText && featureText.trim() && featureText.trim().length > 0) {
                                    featuresHtml += '<li><span style="color: ' + iconColor + '; font-weight: bold; margin-right: 8px;">' + iconSymbol + '</span>' + $('<div>').text(featureText).html() + '</li>';
                                }
                            });
                            featuresHtml += '</ul>';
                        } else {
                            // Only show "No features" if we're sure there are none
                            featuresHtml = '<ul class="features-list-display"><li><?php echo esc_js(__('No features added yet', 'wheelfy')); ?></li></ul>';
                        }
                        $card.find('.plan-features').html(featuresHtml);
                        
                        // Debug: Log features update
                        console.log('Final features HTML:', featuresHtml);
                        
                        // Force update the card's features section
                        const $featuresContainer = $card.find('.plan-features');
                        if ($featuresContainer.length) {
                            $featuresContainer.html(featuresHtml);
                            console.log('Features container updated successfully');
                            
                            // Double-check: verify features are actually there
                            setTimeout(function() {
                                const checkFeatures = $card.find('.features-list-display li');
                                const hasFeatures = checkFeatures.length > 0 && !checkFeatures.first().text().includes('No features');
                                console.log('Verification - Features count:', checkFeatures.length, 'Has features:', hasFeatures);
                                
                                if (!hasFeatures && uniqueFeatures.length > 0) {
                                    console.warn('Features update failed, reloading page...');
                                    location.reload();
                                }
                            }, 100);
                        } else {
                            console.error('Features container not found in card! Reloading...');
                            showAdminNotice(response.data.message || '<?php echo esc_js(__('Plan saved successfully.', 'wheelfy')); ?>', 'success');
                            setTimeout(function() {
                                location.reload();
                            }, 1000);
                            $submitBtn.prop('disabled', false).text('<?php echo esc_js(__('Save Plan', 'wheelfy')); ?>');
                            return;
                        }
                    } else {
                        // Card not found, reload page to show new/updated plan
                        console.log('Card not found for plan ID:', plan.id, '- Reloading page');
                        showAdminNotice(response.data.message || '<?php echo esc_js(__('Plan saved successfully.', 'wheelfy')); ?>', 'success');
                        setTimeout(function() {
                            location.reload();
                        }, 1000);
                        $submitBtn.prop('disabled', false).text('<?php echo esc_js(__('Save Plan', 'wheelfy')); ?>');
                        return;
                    }
                    
                    // Verify features were saved before reloading
                    console.log('=== SAVE RESPONSE VERIFICATION ===');
                    console.log('Response plan features_list:', plan.features_list);
                    console.log('Response plan features_list length:', plan.features_list ? plan.features_list.length : 0);
                    console.log('Features sent to server:', repeaterFeatures);
                    console.log('Features match:', JSON.stringify(plan.features_list) === JSON.stringify(repeaterFeatures));
                    
                    showAdminNotice(response.data.message || '<?php echo esc_js(__('Plan saved successfully.', 'wheelfy')); ?>', 'success');
                    
                    // Close modal first
                    planModal.removeClass('active');
                    
                    // Reload page after save to ensure features are displayed correctly
                    // Give server time to save the data
                    setTimeout(function() {
                        console.log('Reloading page to show saved features...');
                        location.reload();
                    }, 500);
                } else {
                    alert((response && response.data && response.data.message) ? response.data.message : '<?php echo esc_js(__('Failed to save plan.', 'wheelfy')); ?>');
                    $submitBtn.prop('disabled', false).text('<?php echo esc_js(__('Save Plan', 'wheelfy')); ?>');
                }
            },
            error: function() {
                alert('<?php echo esc_js(__('An error occurred while saving the plan.', 'wheelfy')); ?>');
                $submitBtn.prop('disabled', false).text('<?php echo esc_js(__('Save Plan', 'wheelfy')); ?>');
            }
        });
        
        return false;
    });
    
    // Other action buttons (subscription actions, payment actions)
    $(document).on('click', '.action-upgrade, .action-downgrade, .action-toggle-badge, .action-view, .action-view-payment, .action-retry-payment, .action-download-invoice', function(e) {
        e.preventDefault();
        e.stopPropagation();
        const $btn = $(this);
        const action = $btn.hasClass('action-upgrade') ? 'Upgrade Subscription' :
                      $btn.hasClass('action-downgrade') ? 'Downgrade Subscription' :
                      $btn.hasClass('action-toggle-badge') ? 'Toggle Badge' :
                      $btn.hasClass('action-view') ? 'View Subscription' :
                      $btn.hasClass('action-view-payment') ? 'View Payment' :
                      $btn.hasClass('action-retry-payment') ? 'Retry Payment' :
                      'Download Invoice';
        // TODO: Implement actual functionality
        alert(action + ' feature will be implemented soon.');
        return false;
    });
    
    // Note: action-view-partner opens partner dashboard in new tab, no handler needed
    
    // Function to show admin notice
    function showAdminNotice(message, type) {
        type = type || 'success';
        const noticeClass = type === 'success' ? 'notice-success' : 'notice-error';
        const notice = $('<div class="notice ' + noticeClass + ' is-dismissible"><p>' + message + '</p></div>');
        $('.wrap').first().prepend(notice);
        
        // Auto-dismiss after 3 seconds
        setTimeout(function() {
            notice.fadeOut(function() {
                $(this).remove();
            });
        }, 3000);
    }
    
    $('#export-payments-btn').on('click', function(e) {
        e.preventDefault();
        // TODO: Export payments to CSV/PDF
        alert('Export feature will be implemented soon.');
    });
});
</script>
