<?php
/**
 * Admin Dashboard Helper Functions
 * 
 * @package Wheelfy
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * AJAX handler to get user profile data for admin view
 */
function wheelfy_get_user_profile_ajax() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !isset($_POST['user_id'])) {
        wp_send_json_error(array('message' => __('Invalid request.', 'wheelfy')));
    }
    
    $user_id = intval($_POST['user_id']);
    $nonce = sanitize_text_field($_POST['nonce']);
    
    // Verify nonce
    if (!wp_verify_nonce($nonce, 'wheelfy_view_profile_' . $user_id)) {
        wp_send_json_error(array('message' => __('Security check failed.', 'wheelfy')));
    }
    
    // Check if user is admin
    if (!current_user_can('administrator')) {
        wp_send_json_error(array('message' => __('You do not have permission to view profiles.', 'wheelfy')));
    }
    
    // Get user data
    $user = get_userdata($user_id);
    if (!$user) {
        wp_send_json_error(array('message' => __('User not found.', 'wheelfy')));
    }
    
    // Get user meta
    $profile_image_id = get_user_meta($user_id, 'profile_image_id', true);
    $user_bio = get_user_meta($user_id, 'user_bio', true);
    $phone_number = get_user_meta($user_id, 'phone_number', true);
    $location = get_user_meta($user_id, 'location', true);
    $user_type = get_user_meta($user_id, 'user_type', true);
    $user_status = get_user_meta($user_id, 'user_status', true);
    
    // Get profile image URL
    $profile_image_url = '';
    if ($profile_image_id) {
        $profile_image_url = wp_get_attachment_image_url($profile_image_id, 'thumbnail');
    }
    
    // Get user initials
    $user_name = $user->display_name ? $user->display_name : $user->user_login;
    $user_initials = strtoupper(substr($user_name, 0, 1));
    
    // Build HTML
    ob_start();
    ?>
    <div class="wheelfy-profile-image-section">
        <?php if ($profile_image_url) : ?>
            <img src="<?php echo esc_url($profile_image_url); ?>" alt="<?php echo esc_attr($user_name); ?>" class="wheelfy-profile-image">
        <?php else : ?>
            <div class="wheelfy-profile-initials"><?php echo esc_html($user_initials); ?></div>
        <?php endif; ?>
        <h2 class="wheelfy-profile-name"><?php echo esc_html($user_name); ?></h2>
        <p class="wheelfy-profile-email"><?php echo esc_html($user->user_email); ?></p>
    </div>
    
    <div class="wheelfy-profile-info-section">
        <h3><?php _e('Account Information', 'wheelfy'); ?></h3>
        <div class="wheelfy-profile-info-item">
            <span class="wheelfy-profile-info-label"><?php _e('Username:', 'wheelfy'); ?></span>
            <span class="wheelfy-profile-info-value"><?php echo esc_html($user->user_login); ?></span>
        </div>
        <div class="wheelfy-profile-info-item">
            <span class="wheelfy-profile-info-label"><?php _e('Email:', 'wheelfy'); ?></span>
            <span class="wheelfy-profile-info-value"><?php echo esc_html($user->user_email); ?></span>
        </div>
        <?php if ($phone_number) : ?>
        <div class="wheelfy-profile-info-item">
            <span class="wheelfy-profile-info-label"><?php _e('Phone:', 'wheelfy'); ?></span>
            <span class="wheelfy-profile-info-value"><?php echo esc_html($phone_number); ?></span>
        </div>
        <?php endif; ?>
        <?php if ($location) : ?>
        <div class="wheelfy-profile-info-item">
            <span class="wheelfy-profile-info-label"><?php _e('Location:', 'wheelfy'); ?></span>
            <span class="wheelfy-profile-info-value"><?php echo esc_html($location); ?></span>
        </div>
        <?php endif; ?>
        <div class="wheelfy-profile-info-item">
            <span class="wheelfy-profile-info-label"><?php _e('User Type:', 'wheelfy'); ?></span>
            <span class="wheelfy-profile-info-value"><?php echo esc_html(ucfirst($user_type ? $user_type : 'customer')); ?></span>
        </div>
        <div class="wheelfy-profile-info-item">
            <span class="wheelfy-profile-info-label"><?php _e('Role:', 'wheelfy'); ?></span>
            <span class="wheelfy-profile-info-value"><?php echo esc_html(implode(', ', array_map('ucfirst', $user->roles))); ?></span>
        </div>
        <div class="wheelfy-profile-info-item">
            <span class="wheelfy-profile-info-label"><?php _e('Status:', 'wheelfy'); ?></span>
            <span class="wheelfy-profile-info-value">
                <span class="status-badge status-<?php echo esc_attr($user_status ? $user_status : 'active'); ?>">
                    <?php echo esc_html(ucfirst($user_status ? $user_status : 'active')); ?>
                </span>
            </span>
        </div>
        <div class="wheelfy-profile-info-item">
            <span class="wheelfy-profile-info-label"><?php _e('Registered:', 'wheelfy'); ?></span>
            <span class="wheelfy-profile-info-value"><?php echo date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($user->user_registered)); ?></span>
        </div>
    </div>
    
    <?php if ($user_bio) : ?>
    <div class="wheelfy-profile-info-section">
        <h3><?php _e('Biography', 'wheelfy'); ?></h3>
        <div class="wheelfy-profile-bio"><?php echo esc_html($user_bio); ?></div>
    </div>
    <?php else : ?>
    <div class="wheelfy-profile-info-section">
        <h3><?php _e('Biography', 'wheelfy'); ?></h3>
        <div class="wheelfy-profile-bio empty"><?php _e('No biography added yet.', 'wheelfy'); ?></div>
    </div>
    <?php endif; ?>
    <?php
    $html = ob_get_clean();
    
    wp_send_json_success(array('html' => $html));
}
add_action('wp_ajax_wheelfy_get_user_profile', 'wheelfy_get_user_profile_ajax');

/**
 * Get Admin Dashboard Statistics
 */
function wheelfy_get_admin_statistics() {
    global $wpdb;
    
    // Total users
    $total_users = count_users();
    $total_users_count = $total_users['total_users'];
    
    // Count customers
    $customers_query = new WP_User_Query(array(
        'meta_key' => 'user_type',
        'meta_value' => 'customer',
        'count_total' => true,
    ));
    $total_customers = $customers_query->get_total();
    
    // Count partners
    $partners_query = new WP_User_Query(array(
        'meta_key' => 'user_type',
        'meta_value' => 'partner',
        'count_total' => true,
    ));
    $total_partners = $partners_query->get_total();
    
    // Active subscriptions (placeholder - implement based on your subscription system)
    $subscriptions_query = new WP_User_Query(array(
        'meta_key' => 'user_type',
        'meta_value' => 'partner',
        'meta_query' => array(
            array(
                'key' => 'subscription_status',
                'value' => 'active',
                'compare' => '='
            )
        ),
        'count_total' => true,
    ));
    $active_subscriptions = $subscriptions_query->get_total();
    
    // Total leads (placeholder - implement based on your leads system)
    $total_leads = 0; // Get from custom post type or meta
    $leads_posts = get_posts(array(
        'post_type' => 'service_request', // Adjust based on your post type
        'post_status' => 'publish',
        'posts_per_page' => -1,
        'fields' => 'ids',
    ));
    $total_leads = count($leads_posts);
    
    // Accepted offers (placeholder)
    $accepted_offers = 0; // Get from custom post type or meta
    $offers_posts = get_posts(array(
        'post_type' => 'offer', // Adjust based on your post type
        'meta_key' => 'offer_status',
        'meta_value' => 'accepted',
        'posts_per_page' => -1,
        'fields' => 'ids',
    ));
    $accepted_offers = count($offers_posts);
    
    // Total revenue (placeholder - implement based on your payment system)
    $total_revenue = 0;
    $revenue_meta = $wpdb->get_var("
        SELECT SUM(meta_value) 
        FROM {$wpdb->usermeta} 
        WHERE meta_key = 'total_revenue'
    ");
    $total_revenue = $revenue_meta ? floatval($revenue_meta) : 0;
    
    // Pending approvals
    $pending_query = new WP_User_Query(array(
        'meta_key' => 'user_status',
        'meta_value' => 'pending',
        'count_total' => true,
    ));
    $pending_approvals = $pending_query->get_total();
    
    return array(
        'total_users' => $total_users_count,
        'total_customers' => $total_customers,
        'total_partners' => $total_partners,
        'active_subscriptions' => $active_subscriptions,
        'total_leads' => $total_leads,
        'accepted_offers' => $accepted_offers,
        'total_revenue' => $total_revenue,
        'pending_approvals' => $pending_approvals,
    );
}

/**
 * Get Recent Activities
 */
function wheelfy_get_recent_activities($limit = 10) {
    global $wpdb;
    
    $activities = array();
    
    // 1. Recent user registrations
    $recent_users = get_users(array(
        'number' => 10,
        'orderby' => 'registered',
        'order' => 'DESC',
    ));
    
    foreach ($recent_users as $user) {
        $user_type = get_user_meta($user->ID, 'user_type', true);
        $type_label = $user_type === 'partner' ? 'Partner' : 'Customer';
        
        $activities[] = array(
            'type' => 'registration',
            'timestamp' => strtotime($user->user_registered),
            'icon' => '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="8.5" cy="7" r="4"></circle><line x1="20" y1="8" x2="20" y2="14"></line><line x1="23" y1="11" x2="17" y2="11"></line></svg>',
            'message' => sprintf(__('New %s registered: %s', 'wheelfy'), $type_label, $user->user_login),
            'time' => human_time_diff(strtotime($user->user_registered), current_time('timestamp')) . ' ago',
        );
    }
    
    // 2. Recent service requests
    $users_with_requests = get_users(array(
        'meta_key' => 'customer_service_requests',
        'number' => 50, // Limit to avoid too many queries
    ));
    
    foreach ($users_with_requests as $user) {
        $requests = get_user_meta($user->ID, 'customer_service_requests', true);
        $requests = maybe_unserialize($requests);
        
        if (!is_array($requests)) {
            continue;
        }
        
        foreach ($requests as $request) {
            if (!is_array($request) || empty($request['request_id'])) {
                continue;
            }
            
            // Get service name/type - check form_data first (as per reports structure)
            $service_name = __('Service Request', 'wheelfy');
            if (!empty($request['form_data']['service_type'])) {
                $service_name = $request['form_data']['service_type'];
            } elseif (!empty($request['service_type'])) {
                $service_name = $request['service_type'];
            } elseif (!empty($request['service_name'])) {
                $service_name = $request['service_name'];
            }
            
            // Get customer name
            $customer_data = get_userdata($user->ID);
            $customer_name = $customer_data ? ($customer_data->display_name ?: $customer_data->user_login) : __('Unknown', 'wheelfy');
            
            // Get timestamp
            $request_timestamp = current_time('timestamp');
            if (!empty($request['created_at'])) {
                $request_timestamp = strtotime($request['created_at']);
            } elseif (!empty($request['timestamp'])) {
                $request_timestamp = is_numeric($request['timestamp']) ? $request['timestamp'] : strtotime($request['timestamp']);
            }
            
    $activities[] = array(
        'type' => 'lead',
                'timestamp' => $request_timestamp,
        'icon' => '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 11l3 3L22 4"></path><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path></svg>',
                'message' => sprintf(__('New service request: %s from %s', 'wheelfy'), $service_name, $customer_name),
                'time' => human_time_diff($request_timestamp, current_time('timestamp')) . ' ago',
            );
            
            // Check if this request has an accepted offer
            if (!empty($request['status']) && $request['status'] === 'accepted' && !empty($request['selected_partner'])) {
                $partner_id = is_numeric($request['selected_partner']) ? $request['selected_partner'] : null;
                $partner_name = '';
                
                if ($partner_id) {
                    $partner_data = get_userdata($partner_id);
                    $partner_name = $partner_data ? ($partner_data->display_name ?: $partner_data->user_login) : '';
                } elseif (!empty($request['partner_name'])) {
                    $partner_name = $request['partner_name'];
                } else {
                    $partner_name = __('Partner', 'wheelfy');
                }
                
                // Get offer acceptance timestamp (use request updated timestamp or created_at)
                $accept_timestamp = $request_timestamp;
                if (!empty($request['updated_at'])) {
                    $accept_timestamp = strtotime($request['updated_at']);
                }
    
    $activities[] = array(
        'type' => 'offer',
                    'timestamp' => $accept_timestamp,
                    'icon' => '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 11l3 3L22 4"></path><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path></svg>',
                    'message' => sprintf(__('Offer accepted: %s for service request #%s', 'wheelfy'), $partner_name, $request['request_id']),
                    'time' => human_time_diff($accept_timestamp, current_time('timestamp')) . ' ago',
                );
            }
        }
    }
    
    // 3. Payments (if stored in user meta or separate system)
    // Note: Payment tracking may need to be implemented based on your payment system
    // This is a placeholder that can be expanded when payment data is available
    $users_with_payments = get_users(array(
        'meta_key' => 'wheelfy_payments',
        'number' => 10,
    ));
    
    foreach ($users_with_payments as $user) {
        $payments = get_user_meta($user->ID, 'wheelfy_payments', true);
        
        if (is_array($payments)) {
            foreach ($payments as $payment) {
                if (!is_array($payment) || empty($payment['amount'])) {
                    continue;
                }
                
                $payment_timestamp = current_time('timestamp');
                if (!empty($payment['date'])) {
                    $payment_timestamp = is_numeric($payment['date']) ? $payment['date'] : strtotime($payment['date']);
                }
                
                $partner_name = '';
                if (!empty($payment['partner_id'])) {
                    $partner_data = get_userdata($payment['partner_id']);
                    $partner_name = $partner_data ? ($partner_data->display_name ?: $partner_data->user_login) : __('Partner', 'wheelfy');
                } elseif (!empty($payment['partner_name'])) {
                    $partner_name = $payment['partner_name'];
                }
                
                $amount = number_format(floatval($payment['amount']), 2);
                $currency = !empty($payment['currency']) ? $payment['currency'] : '€';
    
    $activities[] = array(
        'type' => 'payment',
                    'timestamp' => $payment_timestamp,
        'icon' => '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="1" x2="12" y2="23"></line><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path></svg>',
                    'message' => sprintf(__('Payment received: %s%s from %s', 'wheelfy'), $currency, $amount, $partner_name ?: __('Customer', 'wheelfy')),
                    'time' => human_time_diff($payment_timestamp, current_time('timestamp')) . ' ago',
    );
            }
        }
    }
    
    // Sort all activities by timestamp (most recent first)
    usort($activities, function($a, $b) {
        $timestamp_a = isset($a['timestamp']) ? $a['timestamp'] : 0;
        $timestamp_b = isset($b['timestamp']) ? $b['timestamp'] : 0;
        return $timestamp_b - $timestamp_a;
    });
    
    // Return limited results
    return array_slice($activities, 0, $limit);
}

/**
 * Get User List by Type (Not role-based, uses user_type meta)
 * CRITICAL: Excludes administrators - only returns customers and partners
 */
function wheelfy_get_users_by_type($type = 'customer', $args = array()) {
    $default_args = array(
        'meta_key' => 'user_type',
        'meta_value' => $type,
        'role__not_in' => array('administrator'), // Always exclude administrators
        'number' => 20,
        'paged' => 1,
    );
    
    $args = wp_parse_args($args, $default_args);
    
    // Ensure administrators are always excluded
    if (!isset($args['role__not_in']) || !in_array('administrator', $args['role__not_in'])) {
        $args['role__not_in'] = array('administrator');
    }
    
    $users = get_users($args);
    
    // Additional safety filter: Remove any administrators that might slip through
    $users = array_filter($users, function($user) {
        return !in_array('administrator', $user->roles);
    });
    
    return $users;
}

/**
 * Update User Status
 */
function wheelfy_update_user_status($user_id, $status) {
    return update_user_meta($user_id, 'user_status', $status);
}

/**
 * Get User Status
 */
function wheelfy_get_user_status($user_id) {
    $status = get_user_meta($user_id, 'user_status', true);
    return $status ? $status : 'active';
}

/**
 * AJAX handler to update user status (Suspend/Activate/Approve/Reject)
 */
function wheelfy_update_user_status_ajax() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !isset($_POST['user_id']) || !isset($_POST['status_action'])) {
        wp_send_json_error(array('message' => __('Invalid request.', 'wheelfy')));
    }
    
    $user_id = intval($_POST['user_id']);
    $nonce = sanitize_text_field($_POST['nonce']);
    $status_action = sanitize_text_field($_POST['status_action']);
    
    // Verify nonce
    if (!wp_verify_nonce($nonce, 'wheelfy_user_action_' . $user_id)) {
        wp_send_json_error(array('message' => __('Security check failed.', 'wheelfy')));
    }
    
    // Check if user is admin
    if (!current_user_can('administrator')) {
        wp_send_json_error(array('message' => __('You do not have permission to perform this action.', 'wheelfy')));
    }
    
    // Get user data
    $user = get_userdata($user_id);
    if (!$user) {
        wp_send_json_error(array('message' => __('User not found.', 'wheelfy')));
    }
    
    // Handle delete action separately
    if ($status_action === 'delete') {
        // Delete the user
        $deleted = wp_delete_user($user_id);
        
        if ($deleted) {
            wp_send_json_success(array(
                'message' => __('User deleted successfully.', 'wheelfy'),
                'action' => 'delete'
            ));
        } else {
            wp_send_json_error(array('message' => __('Failed to delete user.', 'wheelfy')));
        }
    }
    
    // Handle toggle-verification action separately
    if ($status_action === 'toggle-verification') {
        $current_verified = get_user_meta($user_id, 'partner_verified', true);
        $new_verified = $current_verified ? false : true;
        $updated = update_user_meta($user_id, 'partner_verified', $new_verified);
        
        if ($updated !== false) {
            wp_send_json_success(array(
                'message' => $new_verified ? __('Partner verified successfully.', 'wheelfy') : __('Partner unverified successfully.', 'wheelfy'),
                'action' => 'toggle-verification',
                'verified' => $new_verified ? '1' : '0'
            ));
        } else {
            wp_send_json_error(array('message' => __('Failed to update verification status.', 'wheelfy')));
        }
    }
    
    // Map action to status
    $status_map = array(
        'approve' => 'active',
        'suspend' => 'suspended',
        'reject' => 'rejected',
        'activate' => 'active'
    );
    
    if (!isset($status_map[$status_action])) {
        wp_send_json_error(array('message' => __('Invalid action.', 'wheelfy')));
    }
    
    $new_status = $status_map[$status_action];
    
    // Update user status
    $updated = wheelfy_update_user_status($user_id, $new_status);
    
    if ($updated) {
        $messages = array(
            'approve' => __('User activated successfully.', 'wheelfy'),
            'suspend' => __('User suspended successfully.', 'wheelfy'),
            'reject' => __('User rejected successfully.', 'wheelfy'),
            'activate' => __('User activated successfully.', 'wheelfy')
        );
        
        wp_send_json_success(array(
            'message' => $messages[$status_action],
            'new_status' => $new_status
        ));
    } else {
        wp_send_json_error(array('message' => __('Failed to update user status.', 'wheelfy')));
    }
}
add_action('wp_ajax_wheelfy_update_user_status', 'wheelfy_update_user_status_ajax');

/**
 * AJAX handler to get subscription plan data
 */
function wheelfy_get_subscription_plan_ajax() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !isset($_POST['plan_id'])) {
        wp_send_json_error(array('message' => __('Invalid request.', 'wheelfy')));
    }
    
    $plan_id = sanitize_text_field($_POST['plan_id']);
    $nonce = sanitize_text_field($_POST['nonce']);
    
    // Verify nonce
    if (!wp_verify_nonce($nonce, 'wheelfy_subscription_plan_' . $plan_id)) {
        wp_send_json_error(array('message' => __('Security check failed.', 'wheelfy')));
    }
    
    // Check if user is admin
    if (!current_user_can('administrator')) {
        wp_send_json_error(array('message' => __('You do not have permission.', 'wheelfy')));
    }
    
    // Get plans
    $plans = get_option('wheelfy_subscription_plans', array());
    $plan = null;
    
    foreach ($plans as $p) {
        if ($p['id'] === $plan_id) {
            $plan = $p;
            break;
        }
    }
    
    if (!$plan) {
        wp_send_json_error(array('message' => __('Plan not found.', 'wheelfy')));
    }
    
    // Ensure features_list is always an array
    if (!isset($plan['features_list']) || !is_array($plan['features_list'])) {
        $plan['features_list'] = array();
    }
    
    // Ensure features is always an array (for consistency)
    if (!isset($plan['features']) || (!is_array($plan['features']) && empty($plan['features']))) {
        // If features is a string, convert to array
        if (is_string($plan['features']) && !empty($plan['features'])) {
            $plan['features'] = array_filter(array_map('trim', explode("\n", $plan['features'])));
        } else {
            $plan['features'] = array();
        }
    }
    
    wp_send_json_success(array('plan' => $plan));
}
add_action('wp_ajax_wheelfy_get_subscription_plan', 'wheelfy_get_subscription_plan_ajax');

/**
 * AJAX handler to save subscription plan (add or update)
 */
function wheelfy_save_subscription_plan_ajax() {
    // Verify nonce
    if (!isset($_POST['nonce'])) {
        wp_send_json_error(array('message' => __('Invalid request.', 'wheelfy')));
    }
    
    $nonce = sanitize_text_field($_POST['nonce']);
    
    // Verify nonce
    if (!wp_verify_nonce($nonce, 'wheelfy_save_subscription_plan')) {
        wp_send_json_error(array('message' => __('Security check failed.', 'wheelfy')));
    }
    
    // Check if user is admin
    if (!current_user_can('administrator')) {
        wp_send_json_error(array('message' => __('You do not have permission.', 'wheelfy')));
    }
    
    // Get form data
    $plan_id = isset($_POST['plan_id']) ? sanitize_text_field($_POST['plan_id']) : '';
    $name = isset($_POST['plan_name']) ? sanitize_text_field($_POST['plan_name']) : '';
    $price = isset($_POST['plan_price']) ? floatval($_POST['plan_price']) : 0;
    
    // Handle textarea features (regular features)
    $features = array();
    if (isset($_POST['plan_features']) && !empty($_POST['plan_features'])) {
        $features_str = sanitize_textarea_field($_POST['plan_features']);
        if (!empty($features_str)) {
            $features = array_filter(array_map('trim', explode("\n", $features_str)));
        }
    }
    
    // Handle repeater features (Additional Features) separately
    $features_list = array();
    
    // Priority 1: Check for JSON format (most reliable)
    if (isset($_POST['plan_features_list_json']) && !empty($_POST['plan_features_list_json'])) {
        $json_data = stripslashes($_POST['plan_features_list_json']);
        $json_features = json_decode($json_data, true);
        if (is_array($json_features) && !empty($json_features)) {
            foreach ($json_features as $feature) {
                if (is_array($feature) && isset($feature['text'])) {
                    $feature_text = sanitize_text_field($feature['text']);
                    $feature_icon = isset($feature['icon']) ? sanitize_text_field($feature['icon']) : 'check';
                    if (!empty($feature_text) && trim($feature_text) !== '') {
                        $features_list[] = array(
                            'text' => trim($feature_text),
                            'icon' => in_array($feature_icon, array('check', 'cross')) ? $feature_icon : 'check'
                        );
                    }
                } elseif (is_string($feature) && !empty(trim($feature))) {
                    $features_list[] = array(
                        'text' => trim($feature),
                        'icon' => 'check'
                    );
                }
            }
        }
    }
    
    // Priority 2: Check for WordPress parsed array format
    if (empty($features_list) && isset($_POST['plan_features_list']) && is_array($_POST['plan_features_list'])) {
        foreach ($_POST['plan_features_list'] as $feature) {
            if (is_array($feature) && isset($feature['text'])) {
                $feature_text = sanitize_text_field($feature['text']);
                $feature_icon = isset($feature['icon']) ? sanitize_text_field($feature['icon']) : 'check';
                if (!empty($feature_text) && trim($feature_text) !== '') {
                    $features_list[] = array(
                        'text' => trim($feature_text),
                        'icon' => in_array($feature_icon, array('check', 'cross')) ? $feature_icon : 'check'
                    );
                }
            } elseif (is_string($feature) && !empty(trim($feature))) {
                $features_list[] = array(
                    'text' => trim($feature),
                    'icon' => 'check'
                );
            }
        }
    }
    
    // Priority 3: Check for manual indexed format plan_features_list[0][text]
    if (empty($features_list)) {
        $index = 0;
        while (isset($_POST['plan_features_list[' . $index . '][text]'])) {
            $feature_text = sanitize_text_field($_POST['plan_features_list[' . $index . '][text]']);
            $feature_icon = isset($_POST['plan_features_list[' . $index . '][icon]']) ? sanitize_text_field($_POST['plan_features_list[' . $index . '][icon]']) : 'check';
            
            if (!empty($feature_text) && trim($feature_text) !== '') {
                $features_list[] = array(
                    'text' => trim($feature_text),
                    'icon' => in_array($feature_icon, array('check', 'cross')) ? $feature_icon : 'check'
                );
            }
            $index++;
        }
    }
    
    $popular = isset($_POST['plan_popular']) && $_POST['plan_popular'] === '1' ? true : false;
    
    // Validation
    if (empty($name)) {
        wp_send_json_error(array('message' => __('Plan name is required.', 'wheelfy')));
    }
    
    if ($price < 0) {
        wp_send_json_error(array('message' => __('Price must be 0 or greater.', 'wheelfy')));
    }
    
    // Get existing plans
    $plans = get_option('wheelfy_subscription_plans', array());
    
    // Generate ID if new plan
    if (empty($plan_id)) {
        $plan_id = sanitize_title($name);
        // Ensure unique ID
        $original_id = $plan_id;
        $counter = 1;
        while (array_search($plan_id, array_column($plans, 'id')) !== false) {
            $plan_id = $original_id . '-' . $counter;
            $counter++;
        }
    }
    
    // Ensure features_list is always an array
    if (!is_array($features_list)) {
        $features_list = array();
    }
    
    // Ensure features is always an array (for consistency)
    if (!is_array($features)) {
        $features = array();
    }
    
    // Create/update plan
    $plan = array(
        'id' => $plan_id,
        'name' => $name,
        'price' => $price,
        'features' => $features, // Textarea features (for backward compatibility)
        'features_list' => $features_list, // Repeater features (Additional Features)
        'popular' => $popular,
        'subscribers' => 0 // Will be calculated dynamically
    );
    
    // Update existing plan or add new
    $found = false;
    foreach ($plans as $key => $p) {
        if ($p['id'] === $plan_id) {
            // Preserve subscriber count
            $plan['subscribers'] = isset($p['subscribers']) ? $p['subscribers'] : 0;
            // Preserve existing features (textarea) if none provided in this request
            if (empty($plan['features']) && isset($p['features']) && !empty($p['features'])) {
                $plan['features'] = $p['features'];
            }
            // For features_list: Always use the new value from the request
            // If features_list is empty array, that means user wants to clear all features
            // features_list is already set in $plan from line 599, so we use that value
            // Ensure features_list is always an array
            if (!is_array($plan['features_list'])) {
                $plan['features_list'] = array();
            }
            
            $plans[$key] = $plan;
            $found = true;
            break;
        }
    }
    
    if (!$found) {
        $plans[] = $plan;
    }
    
    // Save plans
    update_option('wheelfy_subscription_plans', $plans);
    
    wp_send_json_success(array(
        'message' => $found ? __('Plan updated successfully.', 'wheelfy') : __('Plan added successfully.', 'wheelfy'),
        'plan' => $plan
    ));
}
add_action('wp_ajax_wheelfy_save_subscription_plan', 'wheelfy_save_subscription_plan_ajax');

/**
 * AJAX handler to delete subscription plan
 */
function wheelfy_delete_subscription_plan_ajax() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !isset($_POST['plan_id'])) {
        wp_send_json_error(array('message' => __('Invalid request.', 'wheelfy')));
    }
    
    $plan_id = sanitize_text_field($_POST['plan_id']);
    $nonce = sanitize_text_field($_POST['nonce']);
    
    // Verify nonce
    if (!wp_verify_nonce($nonce, 'wheelfy_delete_subscription_plan_' . $plan_id)) {
        wp_send_json_error(array('message' => __('Security check failed.', 'wheelfy')));
    }
    
    // Check if user is admin
    if (!current_user_can('administrator')) {
        wp_send_json_error(array('message' => __('You do not have permission.', 'wheelfy')));
    }
    
    // Get plans
    $plans = get_option('wheelfy_subscription_plans', array());
    
    // Remove plan
    $plans = array_filter($plans, function($plan) use ($plan_id) {
        return $plan['id'] !== $plan_id;
    });
    
    // Re-index array
    $plans = array_values($plans);
    
    // Save plans
    update_option('wheelfy_subscription_plans', $plans);
    
    wp_send_json_success(array('message' => __('Plan deleted successfully.', 'wheelfy')));
}
add_action('wp_ajax_wheelfy_delete_subscription_plan', 'wheelfy_delete_subscription_plan_ajax');

/**
 * Get Monthly Users Growth Data
 */
function wheelfy_get_monthly_users_data($months = 12) {
    global $wpdb;
    
    $data = array();
    $now = current_time('mysql');
    $current_date = new DateTime($now);
    
    // Initialize all months with 0
    for ($i = $months - 1; $i >= 0; $i--) {
        $date = clone $current_date;
        $date->modify("-{$i} months");
        $month_key = $date->format('Y-m');
        $data[$month_key] = 0;
    }
    
    // Query users registered in the last N months
    $start_date = clone $current_date;
    $start_date->modify("-{$months} months");
    $start_date_str = $start_date->format('Y-m-d 00:00:00');
    
    $users = $wpdb->get_results($wpdb->prepare("
        SELECT DATE_FORMAT(user_registered, '%%Y-%%m') as month, COUNT(*) as count
        FROM {$wpdb->users}
        WHERE user_registered >= %s
        GROUP BY month
        ORDER BY month ASC
    ", $start_date_str));
    
    foreach ($users as $user) {
        if (isset($data[$user->month])) {
            $data[$user->month] = (int) $user->count;
        }
    }
    
    return array_values($data);
}

/**
 * Get Monthly Service Requests Data
 */
function wheelfy_get_monthly_requests_data($months = 12) {
    global $wpdb;
    
    $data = array();
    $now = current_time('mysql');
    $current_date = new DateTime($now);
    
    // Initialize all months with 0
    for ($i = $months - 1; $i >= 0; $i--) {
        $date = clone $current_date;
        $date->modify("-{$i} months");
        $month_key = $date->format('Y-m');
        $data[$month_key] = 0;
    }
    
    // Get all users with customer_service_requests meta
    $users = $wpdb->get_results("
        SELECT user_id, meta_value
        FROM {$wpdb->usermeta}
        WHERE meta_key = 'customer_service_requests'
        AND meta_value != ''
        AND meta_value != 'a:0:{}'
    ");
    
    foreach ($users as $user_meta) {
        $requests = maybe_unserialize($user_meta->meta_value);
        if (!is_array($requests)) {
            continue;
        }
        
        foreach ($requests as $request) {
            if (!isset($request['created_at']) && !isset($request['timestamp'])) {
                continue;
            }
            
            $request_date = isset($request['created_at']) ? $request['created_at'] : $request['timestamp'];
            $date = new DateTime($request_date);
            $month_key = $date->format('Y-m');
            
            if (isset($data[$month_key])) {
                $data[$month_key]++;
            }
        }
    }
    
    return array_values($data);
}

/**
 * Get Monthly Revenue Data
 */
function wheelfy_get_monthly_revenue_data($months = 12) {
    global $wpdb;
    
    $data = array();
    $now = current_time('mysql');
    $current_date = new DateTime($now);
    
    // Initialize all months with 0
    for ($i = $months - 1; $i >= 0; $i--) {
        $date = clone $current_date;
        $date->modify("-{$i} months");
        $month_key = $date->format('Y-m');
        $data[$month_key] = 0;
    }
    
    // Get revenue from user meta total_revenue (this is cumulative, so we need to track monthly separately)
    // For now, we'll calculate from accepted service requests if they have revenue data
    // This is a simplified version - you may need to adjust based on your revenue tracking system
    
    // Try to get revenue from payments/transactions if stored monthly
    // For now, return zeros as revenue tracking per month needs to be implemented properly
    // You may want to store revenue per transaction with dates in a separate table
    
    return array_values($data);
}

/**
 * Get Monthly Offers Data (Submitted and Accepted)
 */
function wheelfy_get_monthly_offers_data($months = 12) {
    global $wpdb;
    
    $submitted_data = array();
    $accepted_data = array();
    $now = current_time('mysql');
    $current_date = new DateTime($now);
    
    // Initialize all months with 0
    for ($i = $months - 1; $i >= 0; $i--) {
        $date = clone $current_date;
        $date->modify("-{$i} months");
        $month_key = $date->format('Y-m');
        $submitted_data[$month_key] = 0;
        $accepted_data[$month_key] = 0;
    }
    
    // Get all users with customer_service_requests meta to count offers
    $users = $wpdb->get_results("
        SELECT user_id, meta_value
        FROM {$wpdb->usermeta}
        WHERE meta_key = 'customer_service_requests'
        AND meta_value != ''
        AND meta_value != 'a:0:{}'
    ");
    
    foreach ($users as $user_meta) {
        $requests = maybe_unserialize($user_meta->meta_value);
        if (!is_array($requests)) {
            continue;
        }
        
        foreach ($requests as $request) {
            // Count each request as one offer submitted
            if (isset($request['created_at']) || isset($request['timestamp'])) {
                $request_date = isset($request['created_at']) ? $request['created_at'] : $request['timestamp'];
                $date = new DateTime($request_date);
                $month_key = $date->format('Y-m');
                
                if (isset($submitted_data[$month_key])) {
                    $submitted_data[$month_key]++;
                }
                
                // Count accepted offers
                if (isset($request['status']) && $request['status'] === 'accepted') {
                    if (isset($accepted_data[$month_key])) {
                        $accepted_data[$month_key]++;
                    }
                }
            }
        }
    }
    
    return array(
        'submitted' => array_values($submitted_data),
        'accepted' => array_values($accepted_data)
    );
}
