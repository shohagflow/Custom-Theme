<?php
/**
 * Reports & Export Module - Backend Functions
 * 
 * Handles report generation, storage, view/download, and data retrieval
 * 
 * @package Wheelfy
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Create Reports Database Table
 * Stores metadata for generated reports
 */
function wheelfy_create_reports_table() {
    global $wpdb;
    
    $table_name = $wpdb->prefix . 'wheelfy_reports';
    $charset_collate = $wpdb->get_charset_collate();
    
    $sql = "CREATE TABLE $table_name (
        id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        report_type varchar(100) NOT NULL,
        report_name varchar(255) NOT NULL,
        file_path varchar(500) NOT NULL,
        file_url varchar(500) NOT NULL,
        file_format varchar(10) NOT NULL DEFAULT 'csv',
        file_size bigint(20) UNSIGNED DEFAULT 0,
        date_range_from date DEFAULT NULL,
        date_range_to date DEFAULT NULL,
        generated_by bigint(20) UNSIGNED NOT NULL,
        generated_at datetime DEFAULT CURRENT_TIMESTAMP,
        status varchar(20) DEFAULT 'completed',
        metadata longtext DEFAULT NULL,
        PRIMARY KEY  (id),
        KEY report_type (report_type),
        KEY generated_by (generated_by),
        KEY generated_at (generated_at),
        KEY status (status)
    ) $charset_collate;";
    
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}
add_action('after_switch_theme', 'wheelfy_create_reports_table');
add_action('admin_init', 'wheelfy_create_reports_table'); // Also run on admin_init for safety

/**
 * Get Reports Directory
 * Returns the uploads directory path for reports
 */
function wheelfy_get_reports_directory() {
    $upload_dir = wp_upload_dir();
    $reports_dir = $upload_dir['basedir'] . '/wheelfy-reports';
    
    // Create directory if it doesn't exist
    if (!file_exists($reports_dir)) {
        wp_mkdir_p($reports_dir);
        // Add .htaccess to prevent direct access
        file_put_contents($reports_dir . '/.htaccess', "deny from all\n");
        // Add index.php for security
        file_put_contents($reports_dir . '/index.php', "<?php\n// Silence is golden.\n");
    }
    
    return $reports_dir;
}

/**
 * Get Reports URL
 * Returns the URL to reports directory
 */
function wheelfy_get_reports_url() {
    $upload_dir = wp_upload_dir();
    return $upload_dir['baseurl'] . '/wheelfy-reports';
}

/**
 * Get System Report Summaries
 * Generates system report summaries from real data (not CSV files)
 * 
 * @return array Array of system report summaries
 */
function wheelfy_get_system_report_summaries() {
    $summaries = array();
    
    // Get real data
    $chat_reports = wheelfy_get_chat_reports_for_tab(array('status' => 'all'));
    $partner_reports = wheelfy_get_partner_reports_for_tab();
    $customer_reports = wheelfy_get_customer_reports_for_tab();
    
    // Chat Report Summary
    if (!empty($chat_reports)) {
        $total_messages = array_sum(array_column($chat_reports, 'messages'));
        $summaries[] = array(
            'id' => 'system_chat',
            'report_type' => 'chat',
            'report_name' => __('Chat Report', 'wheelfy'),
            'date_range_from' => null,
            'date_range_to' => null,
            'file_format' => 'system',
            'file_size' => 0,
            'generated_by' => 0,
            'generated_at' => current_time('mysql'),
            'status' => 'live_data',
            'metadata' => array(
                'type' => 'system',
                'total_conversations' => count($chat_reports),
                'total_messages' => $total_messages
            )
        );
    }
    
    // Partner Report Summary
    if (!empty($partner_reports)) {
        $summaries[] = array(
            'id' => 'system_partner',
            'report_type' => 'partner',
            'report_name' => __('Partner Report', 'wheelfy'),
            'date_range_from' => null,
            'date_range_to' => null,
            'file_format' => 'system',
            'file_size' => 0,
            'generated_by' => 0,
            'generated_at' => current_time('mysql'),
            'status' => 'live_data',
            'metadata' => array(
                'type' => 'system',
                'total_partners' => count($partner_reports)
            )
        );
    }
    
    // Customer Report Summary
    if (!empty($customer_reports)) {
        $summaries[] = array(
            'id' => 'system_customer',
            'report_type' => 'customer',
            'report_name' => __('Customer Report', 'wheelfy'),
            'date_range_from' => null,
            'date_range_to' => null,
            'file_format' => 'system',
            'file_size' => 0,
            'generated_by' => 0,
            'generated_at' => current_time('mysql'),
            'status' => 'live_data',
            'metadata' => array(
                'type' => 'system',
                'total_customers' => count($customer_reports)
            )
        );
    }
    
    return $summaries;
}

/**
 * Get All Reports
 * Fetches reports from database with optional filters, includes system summaries if no CSV reports exist
 * 
 * @param array $filters Optional filters (type, format, date_from, date_to)
 * @param bool $include_system Whether to include system summaries when no CSV reports exist
 * @return array Array of report records
 */
function wheelfy_get_reports($filters = array(), $include_system = true) {
    global $wpdb;
    
    $table_name = $wpdb->prefix . 'wheelfy_reports';
    
    $where = array('1=1');
    $where_values = array();
    
    // Filter by report type
    if (!empty($filters['type'])) {
        $where[] = 'report_type = %s';
        $where_values[] = sanitize_text_field($filters['type']);
    }
    
    // Filter by format
    if (!empty($filters['format'])) {
        $where[] = 'file_format = %s';
        $where_values[] = sanitize_text_field($filters['format']);
    }
    
    // Filter by date range
    if (!empty($filters['date_from'])) {
        $where[] = 'DATE(generated_at) >= %s';
        $where_values[] = sanitize_text_field($filters['date_from']);
    }
    
    if (!empty($filters['date_to'])) {
        $where[] = 'DATE(generated_at) <= %s';
        $where_values[] = sanitize_text_field($filters['date_to']);
    }
    
    $where_clause = implode(' AND ', $where);
    
    if (!empty($where_values)) {
        $query = $wpdb->prepare(
            "SELECT * FROM $table_name WHERE $where_clause ORDER BY generated_at DESC",
            $where_values
        );
    } else {
        $query = "SELECT * FROM $table_name WHERE $where_clause ORDER BY generated_at DESC";
    }
    
    $results = $wpdb->get_results($query, ARRAY_A);
    $csv_reports = $results ? $results : array();
    
    // If no CSV reports and include_system is true, add system summaries
    if ($include_system && empty($csv_reports) && empty($filters)) {
        $system_summaries = wheelfy_get_system_report_summaries();
        return $system_summaries;
    }
    
    return $csv_reports;
}

/**
 * Get Single Report by ID
 * 
 * @param int $report_id Report ID
 * @return array|false Report data or false if not found
 */
function wheelfy_get_report($report_id) {
    global $wpdb;
    
    $table_name = $wpdb->prefix . 'wheelfy_reports';
    
    $report = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $table_name WHERE id = %d",
        $report_id
    ), ARRAY_A);
    
    return $report ? $report : false;
}

/**
 * Generate CSV Content
 * Generates CSV content from data array
 * 
 * @param array $data Data to convert to CSV
 * @param array $headers Optional headers (if not provided, uses array keys)
 * @return string CSV content
 */
function wheelfy_generate_csv_content($data, $headers = array()) {
    $lines = array();
    
    // Add UTF-8 BOM for Excel compatibility
    $csv_content = "\xEF\xBB\xBF";
    
    // Add headers
    if (!empty($headers)) {
        $csv_content .= implode(',', array_map(function($field) {
            return '"' . str_replace('"', '""', $field) . '"';
        }, $headers)) . "\n";
    } elseif (!empty($data) && is_array($data[0])) {
        $csv_content .= implode(',', array_map(function($field) {
            return '"' . str_replace('"', '""', $field) . '"';
        }, array_keys($data[0]))) . "\n";
    }
    
    // Add data rows
    foreach ($data as $row) {
        if (is_array($row)) {
            $csv_content .= implode(',', array_map(function($field) {
                return '"' . str_replace('"', '""', $field) . '"';
            }, $row)) . "\n";
        }
    }
    
    return $csv_content;
}

/**
 * Generate Report File
 * Generates and saves report file, stores metadata in database
 * 
 * @param string $report_type Type of report (users, chat, leads, etc.)
 * @param string $report_name Display name for the report
 * @param string $format File format (csv, pdf, xlsx)
 * @param array $options Additional options (date_from, date_to, filters, etc.)
 * @return array|false Report metadata array or false on failure
 */
function wheelfy_generate_report($report_type, $report_name, $format = 'csv', $options = array()) {
    // Validate format
    $allowed_formats = array('csv', 'pdf', 'xlsx');
    if (!in_array($format, $allowed_formats)) {
        return false;
    }
    
    // Get report data based on type
    $report_data = wheelfy_get_report_data($report_type, $options);
    
    if (empty($report_data) || empty($report_data['data'])) {
        return false;
    }
    
    // Create filename
    $timestamp = current_time('Y-m-d_His');
    $file_extension = $format === 'xlsx' ? 'xlsx' : ($format === 'pdf' ? 'html' : 'csv');
    $filename = sanitize_file_name($report_type . '_' . $timestamp . '.' . $file_extension);
    
    // Get reports directory
    $reports_dir = wheelfy_get_reports_directory();
    $file_path = $reports_dir . '/' . $filename;
    
    // Generate content based on format
    $file_content = '';
    switch ($format) {
        case 'csv':
            $file_content = wheelfy_generate_csv_content($report_data['data'], $report_data['headers']);
            break;
        case 'xlsx':
            $file_content = wheelfy_generate_excel_content($report_data['data'], $report_data['headers'], $report_name);
            $filename = str_replace('.xlsx', '.xml', $filename); // Use XML format for Excel
            $file_path = str_replace('.xlsx', '.xml', $file_path);
            break;
        case 'pdf':
            $file_content = wheelfy_generate_pdf_content($report_data['data'], $report_data['headers'], $report_name, $options);
            break;
    }
    
    // Save file
    $file_saved = file_put_contents($file_path, $file_content);
    
    if ($file_saved === false) {
        return false;
    }
    
    // Get file URL and size
    $reports_url = wheelfy_get_reports_url();
    $file_url = $reports_url . '/' . basename($file_path);
    $file_size = filesize($file_path);
    
    // Store metadata in database
    global $wpdb;
    $table_name = $wpdb->prefix . 'wheelfy_reports';
    
    $date_from = !empty($options['date_from']) ? sanitize_text_field($options['date_from']) : null;
    $date_to = !empty($options['date_to']) ? sanitize_text_field($options['date_to']) : null;
    
    $metadata = array(
        'filters' => $options,
        'rows_count' => count($report_data['data'])
    );
    
    $inserted = $wpdb->insert(
        $table_name,
        array(
            'report_type' => sanitize_text_field($report_type),
            'report_name' => sanitize_text_field($report_name),
            'file_path' => $file_path,
            'file_url' => $file_url,
            'file_format' => $format,
            'file_size' => $file_size,
            'date_range_from' => $date_from,
            'date_range_to' => $date_to,
            'generated_by' => get_current_user_id(),
            'status' => 'completed',
            'metadata' => maybe_serialize($metadata)
        ),
        array('%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%d', '%s', '%s')
    );
    
    if ($inserted === false) {
        // If database insert fails, delete the file
        @unlink($file_path);
        return false;
    }
    
    $report_id = $wpdb->insert_id;
    
    // Return report metadata
    return wheelfy_get_report($report_id);
}

/**
 * Generate Excel Content (XML Spreadsheet Format)
 * Creates an XML file that Excel can open directly
 * 
 * @param array $data Report data
 * @param array $headers Column headers
 * @param string $report_name Report title
 * @return string XML content
 */
function wheelfy_generate_excel_content($data, $headers, $report_name) {
    $xml = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml .= '<?mso-application progid="Excel.Sheet"?>' . "\n";
    $xml .= '<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"' . "\n";
    $xml .= ' xmlns:o="urn:schemas-microsoft-com:office:office"' . "\n";
    $xml .= ' xmlns:x="urn:schemas-microsoft-com:office:excel"' . "\n";
    $xml .= ' xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"' . "\n";
    $xml .= ' xmlns:html="http://www.w3.org/TR/REC-html40">' . "\n";
    
    // Styles
    $xml .= '<Styles>' . "\n";
    $xml .= '<Style ss:ID="Default" ss:Name="Normal">' . "\n";
    $xml .= '<Alignment ss:Vertical="Bottom"/>' . "\n";
    $xml .= '<Font ss:FontName="Calibri" ss:Size="11" ss:Color="#000000"/>' . "\n";
    $xml .= '</Style>' . "\n";
    $xml .= '<Style ss:ID="Header">' . "\n";
    $xml .= '<Alignment ss:Horizontal="Center" ss:Vertical="Center"/>' . "\n";
    $xml .= '<Font ss:FontName="Calibri" ss:Size="11" ss:Bold="1" ss:Color="#FFFFFF"/>' . "\n";
    $xml .= '<Interior ss:Color="#2271b1" ss:Pattern="Solid"/>' . "\n";
    $xml .= '<Borders>' . "\n";
    $xml .= '<Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>' . "\n";
    $xml .= '<Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>' . "\n";
    $xml .= '<Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>' . "\n";
    $xml .= '<Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>' . "\n";
    $xml .= '</Borders>' . "\n";
    $xml .= '</Style>' . "\n";
    $xml .= '<Style ss:ID="Title">' . "\n";
    $xml .= '<Font ss:FontName="Calibri" ss:Size="16" ss:Bold="1" ss:Color="#1d2327"/>' . "\n";
    $xml .= '</Style>' . "\n";
    $xml .= '<Style ss:ID="Data">' . "\n";
    $xml .= '<Borders>' . "\n";
    $xml .= '<Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#DDDDDD"/>' . "\n";
    $xml .= '<Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#DDDDDD"/>' . "\n";
    $xml .= '<Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#DDDDDD"/>' . "\n";
    $xml .= '</Borders>' . "\n";
    $xml .= '</Style>' . "\n";
    $xml .= '</Styles>' . "\n";
    
    // Worksheet
    $xml .= '<Worksheet ss:Name="' . esc_attr($report_name) . '">' . "\n";
    $xml .= '<Table>' . "\n";
    
    // Set column widths
    foreach ($headers as $header) {
        $xml .= '<Column ss:AutoFitWidth="1" ss:Width="120"/>' . "\n";
    }
    
    // Title row
    $xml .= '<Row ss:Height="30">' . "\n";
    $xml .= '<Cell ss:StyleID="Title"><Data ss:Type="String">' . esc_html($report_name) . ' - ' . date_i18n(get_option('date_format') . ' ' . get_option('time_format')) . '</Data></Cell>' . "\n";
    $xml .= '</Row>' . "\n";
    
    // Empty row
    $xml .= '<Row></Row>' . "\n";
    
    // Header row
    $xml .= '<Row>' . "\n";
    foreach ($headers as $header) {
        $xml .= '<Cell ss:StyleID="Header"><Data ss:Type="String">' . esc_html($header) . '</Data></Cell>' . "\n";
    }
    $xml .= '</Row>' . "\n";
    
    // Data rows
    foreach ($data as $row) {
        $xml .= '<Row>' . "\n";
        foreach ($headers as $header) {
            $value = isset($row[$header]) ? $row[$header] : '';
            $type = is_numeric($value) ? 'Number' : 'String';
            $xml .= '<Cell ss:StyleID="Data"><Data ss:Type="' . $type . '">' . esc_html($value) . '</Data></Cell>' . "\n";
        }
        $xml .= '</Row>' . "\n";
    }
    
    $xml .= '</Table>' . "\n";
    $xml .= '</Worksheet>' . "\n";
    $xml .= '</Workbook>';
    
    return $xml;
}

/**
 * Generate PDF Content (HTML with Print Styles)
 * Creates an HTML file optimized for printing/saving as PDF
 * 
 * @param array $data Report data
 * @param array $headers Column headers
 * @param string $report_name Report title
 * @param array $options Report options
 * @return string HTML content
 */
function wheelfy_generate_pdf_content($data, $headers, $report_name, $options = array()) {
    $include_summary = !empty($options['include_summary']);
    $include_charts = !empty($options['include_charts']);
    
    // Calculate summary statistics
    $total_rows = count($data);
    $generated_date = date_i18n(get_option('date_format') . ' ' . get_option('time_format'));
    $generated_by = wp_get_current_user();
    
    $html = '<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>' . esc_html($report_name) . '</title>
    <style>
        @page {
            size: A4 landscape;
            margin: 15mm;
        }
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        body {
            font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
            font-size: 11px;
            line-height: 1.4;
            color: #1d2327;
            background: #fff;
            padding: 20px;
        }
        .report-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            border-bottom: 3px solid #2271b1;
            padding-bottom: 15px;
            margin-bottom: 20px;
        }
        .report-title {
            font-size: 24px;
            font-weight: 700;
            color: #1d2327;
            margin-bottom: 5px;
        }
        .report-subtitle {
            font-size: 12px;
            color: #646970;
        }
        .report-meta {
            text-align: right;
            font-size: 11px;
            color: #646970;
        }
        .report-meta strong {
            color: #1d2327;
        }
        .summary-section {
            background: #f6f7f7;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 15px 20px;
            margin-bottom: 20px;
            display: flex;
            gap: 30px;
        }
        .summary-item {
            text-align: center;
        }
        .summary-label {
            font-size: 10px;
            color: #646970;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .summary-value {
            font-size: 24px;
            font-weight: 700;
            color: #2271b1;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
            font-size: 10px;
        }
        thead {
            background: #2271b1;
        }
        th {
            color: #fff;
            font-weight: 600;
            padding: 10px 8px;
            text-align: left;
            border: 1px solid #1a5a8e;
        }
        td {
            padding: 8px;
            border: 1px solid #ddd;
            vertical-align: top;
        }
        tbody tr:nth-child(even) {
            background: #f9f9f9;
        }
        tbody tr:hover {
            background: #f0f6fc;
        }
        .report-footer {
            margin-top: 30px;
            padding-top: 15px;
            border-top: 1px solid #ddd;
            font-size: 10px;
            color: #646970;
            display: flex;
            justify-content: space-between;
        }
        .print-btn {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #2271b1;
            color: #fff;
            border: none;
            padding: 12px 24px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            box-shadow: 0 2px 8px rgba(0,0,0,0.2);
            z-index: 1000;
        }
        .print-btn:hover {
            background: #135e96;
        }
        @media print {
            .print-btn {
                display: none !important;
            }
            body {
                padding: 0;
            }
            .summary-section {
                break-inside: avoid;
            }
            thead {
                display: table-header-group;
            }
            tr {
                page-break-inside: avoid;
            }
        }
        .chart-section {
            margin: 20px 0;
            padding: 15px;
            background: #f9f9f9;
            border-radius: 8px;
        }
        .chart-title {
            font-size: 14px;
            font-weight: 600;
            margin-bottom: 10px;
        }
        .bar-chart {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }
        .bar-item {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .bar-label {
            width: 120px;
            font-size: 11px;
            text-align: right;
        }
        .bar-container {
            flex: 1;
            height: 20px;
            background: #e5e5e5;
            border-radius: 4px;
            overflow: hidden;
        }
        .bar-fill {
            height: 100%;
            background: linear-gradient(90deg, #2271b1, #135e96);
            border-radius: 4px;
            transition: width 0.3s;
        }
        .bar-value {
            width: 50px;
            font-size: 11px;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <button class="print-btn" onclick="window.print()">🖨️ Print / Save as PDF</button>
    
    <div class="report-header">
        <div>
            <h1 class="report-title">' . esc_html($report_name) . '</h1>
            <p class="report-subtitle">Generated from Wheelfy Admin Dashboard</p>
        </div>
        <div class="report-meta">
            <div><strong>Generated:</strong> ' . $generated_date . '</div>
            <div><strong>By:</strong> ' . esc_html($generated_by->display_name) . '</div>
            <div><strong>Total Records:</strong> ' . number_format($total_rows) . '</div>
        </div>
    </div>';
    
    // Summary section
    if ($include_summary) {
        $html .= '
    <div class="summary-section">
        <div class="summary-item">
            <div class="summary-label">Total Records</div>
            <div class="summary-value">' . number_format($total_rows) . '</div>
        </div>
        <div class="summary-item">
            <div class="summary-label">Columns</div>
            <div class="summary-value">' . count($headers) . '</div>
        </div>
        <div class="summary-item">
            <div class="summary-label">Report Type</div>
            <div class="summary-value" style="font-size: 16px;">' . esc_html(ucfirst(str_replace('_', ' ', $report_name))) . '</div>
        </div>
    </div>';
    }
    
    // Charts section (simple bar chart based on first numeric column)
    if ($include_charts && !empty($data)) {
        $chart_data = array();
        $max_value = 0;
        
        // Find numeric columns for chart
        foreach ($headers as $header) {
            if (isset($data[0][$header]) && is_numeric($data[0][$header])) {
                $sum = 0;
                foreach ($data as $row) {
                    $sum += isset($row[$header]) ? floatval($row[$header]) : 0;
                }
                $chart_data[$header] = $sum;
                $max_value = max($max_value, $sum);
            }
        }
        
        if (!empty($chart_data) && $max_value > 0) {
            $html .= '
    <div class="chart-section">
        <div class="chart-title">📊 Data Summary</div>
        <div class="bar-chart">';
            
            foreach ($chart_data as $label => $value) {
                $percentage = ($value / $max_value) * 100;
                $html .= '
            <div class="bar-item">
                <div class="bar-label">' . esc_html($label) . '</div>
                <div class="bar-container">
                    <div class="bar-fill" style="width: ' . $percentage . '%"></div>
                </div>
                <div class="bar-value">' . number_format($value) . '</div>
            </div>';
            }
            
            $html .= '
        </div>
    </div>';
        }
    }
    
    // Data table
    $html .= '
    <table>
        <thead>
            <tr>';
    
    foreach ($headers as $header) {
        $html .= '
                <th>' . esc_html($header) . '</th>';
    }
    
    $html .= '
            </tr>
        </thead>
        <tbody>';
    
    foreach ($data as $row) {
        $html .= '
            <tr>';
        foreach ($headers as $header) {
            $value = isset($row[$header]) ? $row[$header] : '';
            $html .= '
                <td>' . esc_html($value) . '</td>';
        }
        $html .= '
            </tr>';
    }
    
    $html .= '
        </tbody>
    </table>
    
    <div class="report-footer">
        <div>© ' . date('Y') . ' Wheelfy - All Rights Reserved</div>
        <div>Page 1 of 1 | Confidential Report</div>
    </div>
</body>
</html>';
    
    return $html;
}

/**
 * Get Report Data
 * Fetches data for a specific report type
 * 
 * @param string $report_type Type of report
 * @param array $options Filter options
 * @return array Array with 'headers' and 'data' keys
 */
function wheelfy_get_report_data($report_type, $options = array()) {
    $data = array(
        'headers' => array(),
        'data' => array()
    );
    
    switch ($report_type) {
        case 'users':
            $data = wheelfy_get_users_report_data($options);
            break;
        case 'chat':
            $data = wheelfy_get_chat_report_data($options);
            break;
        case 'leads':
            $data = wheelfy_get_leads_report_data($options);
            break;
        case 'offers':
            $data = wheelfy_get_offers_report_data($options);
            break;
        case 'revenue':
            $data = wheelfy_get_revenue_report_data($options);
            break;
        case 'subscriptions':
            $data = wheelfy_get_subscriptions_report_data($options);
            break;
        case 'reviews':
            $data = wheelfy_get_reviews_report_data($options);
            break;
        case 'partner':
            $data = wheelfy_get_partner_report_data($options);
            break;
        case 'customer':
            $data = wheelfy_get_customer_report_data($options);
            break;
        default:
            return $data;
    }
    
    return $data;
}

/**
 * Get Users Report Data
 */
function wheelfy_get_users_report_data($options = array()) {
    $headers = array('ID', 'Username', 'Email', 'User Type', 'Role', 'Registered Date', 'Status');
    $data = array();
    
    $args = array(
        'number' => -1,
        'orderby' => 'registered',
        'order' => 'DESC'
    );
    
    // Filter by date range
    if (!empty($options['date_from']) || !empty($options['date_to'])) {
        $args['date_query'] = array();
        if (!empty($options['date_from'])) {
            $args['date_query']['after'] = $options['date_from'];
        }
        if (!empty($options['date_to'])) {
            $args['date_query']['before'] = $options['date_to'] . ' 23:59:59';
        }
    }
    
    $users = get_users($args);
    
    foreach ($users as $user) {
        $user_type = get_user_meta($user->ID, 'user_type', true);
        $user_status = get_user_meta($user->ID, 'user_status', true);
        
        $data[] = array(
            'ID' => $user->ID,
            'Username' => $user->user_login,
            'Email' => $user->user_email,
            'User Type' => $user_type ? ucfirst($user_type) : '-',
            'Role' => implode(', ', $user->roles),
            'Registered Date' => $user->user_registered,
            'Status' => $user_status ? ucfirst($user_status) : 'Active'
        );
    }
    
    return array('headers' => $headers, 'data' => $data);
}

/**
 * Get Chat Report Data
 * Note: Currently uses options API for threads/messages
 */
function wheelfy_get_chat_report_data($options = array()) {
    global $wpdb;
    
    $headers = array('Thread ID', 'Customer', 'Customer ID', 'Partner', 'Partner ID', 'Messages Count', 'Status', 'Started', 'Last Activity');
    $data = array();
    
    // Get all thread options (wheelfy_thread_*)
    $thread_options = $wpdb->get_results(
        "SELECT option_name, option_value FROM $wpdb->options WHERE option_name LIKE 'wheelfy_thread_%'",
        ARRAY_A
    );
    
    foreach ($thread_options as $thread_option) {
        $thread = maybe_unserialize($thread_option['option_value']);
        
        if (!is_array($thread) || empty($thread['customer_id']) || empty($thread['partner_id'])) {
            continue;
        }
        
        $thread_id = str_replace('wheelfy_thread_', '', $thread_option['option_name']);
        
        // Get customer and partner info
        $customer = get_userdata($thread['customer_id']);
        $partner = get_userdata($thread['partner_id']);
        
        if (!$customer || !$partner) {
            continue;
        }
        
        // Get messages count
        $messages = get_option('wheelfy_messages_' . $thread_id, array());
        $messages_count = is_array($messages) ? count($messages) : 0;
        
        // Determine status (active/closed) - simplified logic
        $status = 'active';
        if (!empty($thread['last_message_at'])) {
            $last_message_time = strtotime($thread['last_message_at']);
            $days_since = (current_time('timestamp') - $last_message_time) / DAY_IN_SECONDS;
            if ($days_since > 7) {
                $status = 'closed';
            }
        }
        
        $data[] = array(
            'Thread ID' => $thread_id,
            'Customer' => $customer->display_name ?: $customer->user_login,
            'Customer ID' => $customer->ID,
            'Partner' => $partner->display_name ?: $partner->user_login,
            'Partner ID' => $partner->ID,
            'Messages Count' => $messages_count,
            'Status' => ucfirst($status),
            'Started' => !empty($thread['created_at']) ? $thread['created_at'] : '-',
            'Last Activity' => !empty($thread['last_message_at']) ? $thread['last_message_at'] : '-'
        );
    }
    
    return array('headers' => $headers, 'data' => $data);
}

/**
 * Get Leads Report Data
 * Note: Uses user meta for service requests
 */
function wheelfy_get_leads_report_data($options = array()) {
    $headers = array('Request ID', 'Customer', 'Customer ID', 'Service Type', 'Status', 'Created Date');
    $data = array();
    
    // Get all users with service requests
    $users = get_users(array('meta_key' => 'customer_service_requests', 'number' => -1));
    
    foreach ($users as $user) {
        $requests = get_user_meta($user->ID, 'customer_service_requests', true);
        
        if (!is_array($requests)) {
            continue;
        }
        
        foreach ($requests as $request) {
            if (!is_array($request) || empty($request['request_id'])) {
                continue;
            }
            
            $service_type = 'General Service';
            if (!empty($request['form_data']['service_type'])) {
                $service_type = $request['form_data']['service_type'];
            }
            
            $data[] = array(
                'Request ID' => $request['request_id'],
                'Customer' => $user->display_name ?: $user->user_login,
                'Customer ID' => $user->ID,
                'Service Type' => $service_type,
                'Status' => !empty($request['status']) ? ucfirst($request['status']) : 'Pending',
                'Created Date' => !empty($request['created_at']) ? $request['created_at'] : '-'
            );
        }
    }
    
    return array('headers' => $headers, 'data' => $data);
}

/**
 * Get Offers Report Data
 * Note: Simplified - would need offer post type or custom table
 */
function wheelfy_get_offers_report_data($options = array()) {
    $headers = array('Offer ID', 'Request ID', 'Partner', 'Partner ID', 'Amount', 'Status', 'Created Date');
    $data = array();
    
    // Placeholder - would need offer storage system
    // For now, return empty data
    return array('headers' => $headers, 'data' => $data);
}

/**
 * Get Revenue Report Data
 * Note: Simplified - would need transaction system
 */
function wheelfy_get_revenue_report_data($options = array()) {
    $headers = array('Transaction ID', 'Date', 'Amount', 'Type', 'Status');
    $data = array();
    
    // Placeholder - would need transaction system
    return array('headers' => $headers, 'data' => $data);
}

/**
 * Get Subscriptions Report Data
 */
function wheelfy_get_subscriptions_report_data($options = array()) {
    $headers = array('Partner', 'Partner ID', 'Plan Name', 'Plan ID', 'Status', 'Start Date', 'Next Payment');
    $data = array();
    
    $partners = get_users(array('role' => 'partner', 'number' => -1));
    
    foreach ($partners as $partner) {
        $subscription_status = get_user_meta($partner->ID, 'subscription_status', true);
        $subscription_plan = get_user_meta($partner->ID, 'subscription_plan', true);
        
        if (!$subscription_plan) {
            continue;
        }
        
        $plans = get_option('wheelfy_subscription_plans', array());
        $plan_data = null;
        
        foreach ($plans as $plan) {
            if (isset($plan['id']) && $plan['id'] === $subscription_plan) {
                $plan_data = $plan;
                break;
            }
        }
        
        $plan_name = $plan_data ? $plan_data['name'] : $subscription_plan;
        
        $data[] = array(
            'Partner' => $partner->display_name ?: $partner->user_login,
            'Partner ID' => $partner->ID,
            'Plan Name' => $plan_name,
            'Plan ID' => $subscription_plan,
            'Status' => $subscription_status ? ucfirst($subscription_status) : 'Active',
            'Start Date' => get_user_meta($partner->ID, 'subscription_start_date', true) ?: '-',
            'Next Payment' => get_user_meta($partner->ID, 'subscription_next_payment', true) ?: '-'
        );
    }
    
    return array('headers' => $headers, 'data' => $data);
}

/**
 * Get Reviews Report Data
 * Note: Would need review storage system
 */
function wheelfy_get_reviews_report_data($options = array()) {
    $headers = array('Review ID', 'Customer', 'Partner', 'Rating', 'Status', 'Date');
    $data = array();
    
    // Placeholder - would need review storage system
    return array('headers' => $headers, 'data' => $data);
}

/**
 * Get Partner Report Data
 */
function wheelfy_get_partner_report_data($options = array()) {
    $headers = array('Partner ID', 'Business Name', 'Email', 'Total Chats', 'Active Chats', 'Subscription Plan', 'Status');
    $data = array();
    
    $partners = get_users(array('role' => 'partner', 'number' => -1));
    
    foreach ($partners as $partner) {
        $business_name = get_user_meta($partner->ID, 'business_name', true);
        $subscription_plan = get_user_meta($partner->ID, 'subscription_plan', true);
        $user_status = get_user_meta($partner->ID, 'user_status', true);
        
        // Count chats (threads)
        $threads = get_user_meta($partner->ID, 'wheelfy_chat_threads', true);
        $total_chats = is_array($threads) ? count($threads) : 0;
        
        // Count active chats (simplified)
        $active_chats = 0; // Would need more logic to determine active
        
        $data[] = array(
            'Partner ID' => $partner->ID,
            'Business Name' => $business_name ?: $partner->display_name,
            'Email' => $partner->user_email,
            'Total Chats' => $total_chats,
            'Active Chats' => $active_chats,
            'Subscription Plan' => $subscription_plan ?: 'None',
            'Status' => $user_status ? ucfirst($user_status) : 'Active'
        );
    }
    
    return array('headers' => $headers, 'data' => $data);
}

/**
 * Get Customer Report Data
 */
function wheelfy_get_customer_report_data($options = array()) {
    $headers = array('Customer ID', 'Name', 'Email', 'Total Requests', 'Active Requests', 'Status');
    $data = array();
    
    $customers = get_users(array('role' => 'customer', 'number' => -1));
    
    foreach ($customers as $customer) {
        $user_status = get_user_meta($customer->ID, 'user_status', true);
        
        // Count service requests
        $requests = get_user_meta($customer->ID, 'customer_service_requests', true);
        $total_requests = is_array($requests) ? count($requests) : 0;
        
        // Count active requests
        $active_requests = 0;
        if (is_array($requests)) {
            foreach ($requests as $request) {
                if (!empty($request['status']) && in_array($request['status'], array('pending', 'accepted'))) {
                    $active_requests++;
                }
            }
        }
        
        $data[] = array(
            'Customer ID' => $customer->ID,
            'Name' => $customer->display_name ?: $customer->user_login,
            'Email' => $customer->user_email,
            'Total Requests' => $total_requests,
            'Active Requests' => $active_requests,
            'Status' => $user_status ? ucfirst($user_status) : 'Active'
        );
    }
    
    return array('headers' => $headers, 'data' => $data);
}

/**
 * Get Chat Reports Data for Tab Display
 * Returns formatted data for By Chat tab (more detailed than CSV export)
 * 
 * @param array $filters Optional filters (status)
 * @return array Array of chat report data
 */
function wheelfy_get_chat_reports_for_tab($filters = array()) {
    global $wpdb;
    
    $chat_reports = array();
    
    // Get all thread options (wheelfy_thread_*)
    $thread_options = $wpdb->get_results(
        "SELECT option_name, option_value FROM $wpdb->options WHERE option_name LIKE 'wheelfy_thread_%'",
        ARRAY_A
    );
    
    foreach ($thread_options as $thread_option) {
        $thread = maybe_unserialize($thread_option['option_value']);
        
        if (!is_array($thread) || empty($thread['customer_id']) || empty($thread['partner_id'])) {
            continue;
        }
        
        $thread_id = str_replace('wheelfy_thread_', '', $thread_option['option_name']);
        
        // Get customer and partner info
        $customer = get_userdata($thread['customer_id']);
        $partner = get_userdata($thread['partner_id']);
        
        if (!$customer || !$partner) {
            continue;
        }
        
        // Get messages
        $messages = get_option('wheelfy_messages_' . $thread_id, array());
        $messages_count = is_array($messages) ? count($messages) : 0;
        
        // Calculate duration
        $started = !empty($thread['created_at']) ? strtotime($thread['created_at']) : current_time('timestamp');
        $last_activity = !empty($thread['last_message_at']) ? strtotime($thread['last_message_at']) : $started;
        $duration_seconds = $last_activity - $started;
        
        $duration_hours = floor($duration_seconds / 3600);
        $duration_minutes = floor(($duration_seconds % 3600) / 60);
        
        if ($duration_hours > 0) {
            $duration = $duration_hours . 'h ' . $duration_minutes . 'm';
        } else {
            $duration = $duration_minutes . 'm';
        }
        
        // Determine status
        $status = 'active';
        if (!empty($thread['last_message_at'])) {
            $last_message_time = strtotime($thread['last_message_at']);
            $days_since = (current_time('timestamp') - $last_message_time) / DAY_IN_SECONDS;
            if ($days_since > 7) {
                $status = 'closed';
            }
        }
        
        // Check for dispute status (if thread has dispute flag)
        if (!empty($thread['status']) && $thread['status'] === 'dispute') {
            $status = 'dispute';
        }
        
        // Calculate average response time (simplified - based on message count and duration)
        $avg_response_seconds = $messages_count > 1 ? ($duration_seconds / ($messages_count - 1)) : 0;
        $avg_response_minutes = floor($avg_response_seconds / 60);
        $avg_response_seconds_remainder = floor($avg_response_seconds % 60);
        $avg_response_time = $avg_response_minutes . 'm ' . $avg_response_seconds_remainder . 's';
        
        // Apply filters
        if (!empty($filters['status']) && $filters['status'] !== 'all' && $status !== $filters['status']) {
            continue;
        }
        
        $chat_reports[] = array(
            'id' => count($chat_reports) + 1,
            'conversation_id' => $thread_id,
            'customer' => $customer->display_name ?: $customer->user_login,
            'customer_id' => $customer->ID,
            'partner' => $partner->display_name ?: $partner->user_login,
            'partner_id' => $partner->ID,
            'messages' => $messages_count,
            'duration' => $duration,
            'status' => $status,
            'started' => !empty($thread['created_at']) ? date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($thread['created_at'])) : '-',
            'ended' => !empty($thread['last_message_at']) && $status === 'closed' ? date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($thread['last_message_at'])) : null,
            'avg_response_time' => $avg_response_time
        );
    }
    
    // Sort by started date (newest first)
    usort($chat_reports, function($a, $b) {
        return strcmp($b['started'], $a['started']);
    });
    
    return $chat_reports;
}

/**
 * Get Partner Reports Data for Tab Display
 * Returns formatted data for By Partner tab
 * 
 * @return array Array of partner report data
 */
function wheelfy_get_partner_reports_for_tab() {
    $partner_reports = array();
    
    $partners = get_users(array('role' => 'partner', 'number' => -1));
    
    foreach ($partners as $partner) {
        $business_name = get_user_meta($partner->ID, 'business_name', true);
        
        // Get all threads for this partner
        $thread_ids = get_user_meta($partner->ID, 'wheelfy_chat_threads', true);
        $thread_ids = is_array($thread_ids) ? $thread_ids : array();
        
        $total_chats = count($thread_ids);
        $active_chats = 0;
        $closed_chats = 0;
        $dispute_chats = 0;
        $total_messages = 0;
        $total_response_seconds = 0;
        $response_count = 0;
        
        foreach ($thread_ids as $thread_id) {
            $thread = get_option('wheelfy_thread_' . $thread_id, false);
            if (!$thread || !is_array($thread)) {
                continue;
            }
            
            // Get messages count
            $messages = get_option('wheelfy_messages_' . $thread_id, array());
            $messages_count = is_array($messages) ? count($messages) : 0;
            $total_messages += $messages_count;
            
            // Determine status
            $status = 'active';
            if (!empty($thread['last_message_at'])) {
                $last_message_time = strtotime($thread['last_message_at']);
                $days_since = (current_time('timestamp') - $last_message_time) / DAY_IN_SECONDS;
                if ($days_since > 7) {
                    $status = 'closed';
                }
            }
            
            if (!empty($thread['status']) && $thread['status'] === 'dispute') {
                $status = 'dispute';
                $dispute_chats++;
            } elseif ($status === 'closed') {
                $closed_chats++;
            } else {
                $active_chats++;
            }
            
            // Calculate response time (simplified)
            if ($messages_count > 1 && !empty($thread['created_at']) && !empty($thread['last_message_at'])) {
                $duration = strtotime($thread['last_message_at']) - strtotime($thread['created_at']);
                $avg_response = $duration / ($messages_count - 1);
                $total_response_seconds += $avg_response;
                $response_count++;
            }
        }
        
        // Calculate average response time
        $avg_response_minutes = $response_count > 0 ? floor(($total_response_seconds / $response_count) / 60) : 0;
        $avg_response_seconds = $response_count > 0 ? floor((($total_response_seconds / $response_count) % 60)) : 0;
        $avg_response_time = $avg_response_minutes . 'm ' . $avg_response_seconds . 's';
        
        // Satisfaction rate (placeholder - would need review system)
        $satisfaction_rate = '-';
        
        $partner_reports[] = array(
            'partner' => $business_name ?: $partner->display_name,
            'partner_id' => $partner->ID,
            'total_chats' => $total_chats,
            'active_chats' => $active_chats,
            'closed_chats' => $closed_chats,
            'dispute_chats' => $dispute_chats,
            'total_messages' => $total_messages,
            'avg_response_time' => $avg_response_time,
            'satisfaction_rate' => $satisfaction_rate
        );
    }
    
    return $partner_reports;
}

/**
 * Get Customer Reports Data for Tab Display
 * Returns formatted data for By Customer tab
 * 
 * @return array Array of customer report data
 */
function wheelfy_get_customer_reports_for_tab() {
    $customer_reports = array();
    
    $customers = get_users(array('role' => 'customer', 'number' => -1));
    
    foreach ($customers as $customer) {
        // Get service requests
        $requests = get_user_meta($customer->ID, 'customer_service_requests', true);
        $requests = is_array($requests) ? $requests : array();
        
        $total_requests = count($requests);
        $active_requests = 0;
        $closed_requests = 0;
        $dispute_requests = 0;
        
        foreach ($requests as $request) {
            if (!is_array($request)) {
                continue;
            }
            
            $status = !empty($request['status']) ? $request['status'] : 'pending';
            
            if ($status === 'dispute') {
                $dispute_requests++;
            } elseif (in_array($status, array('completed', 'cancelled'))) {
                $closed_requests++;
            } else {
                $active_requests++;
            }
        }
        
        // Get chat threads
        $thread_ids = get_user_meta($customer->ID, 'wheelfy_chat_threads', true);
        $thread_ids = is_array($thread_ids) ? $thread_ids : array();
        
        $total_chats = count($thread_ids);
        $active_chats = 0;
        $closed_chats = 0;
        $dispute_chats = 0;
        $total_messages = 0;
        
        foreach ($thread_ids as $thread_id) {
            $thread = get_option('wheelfy_thread_' . $thread_id, false);
            if (!$thread || !is_array($thread)) {
                continue;
            }
            
            $messages = get_option('wheelfy_messages_' . $thread_id, array());
            $messages_count = is_array($messages) ? count($messages) : 0;
            $total_messages += $messages_count;
            
            $status = 'active';
            if (!empty($thread['last_message_at'])) {
                $last_message_time = strtotime($thread['last_message_at']);
                $days_since = (current_time('timestamp') - $last_message_time) / DAY_IN_SECONDS;
                if ($days_since > 7) {
                    $status = 'closed';
                }
            }
            
            if (!empty($thread['status']) && $thread['status'] === 'dispute') {
                $status = 'dispute';
                $dispute_chats++;
            } elseif ($status === 'closed') {
                $closed_chats++;
            } else {
                $active_chats++;
            }
        }
        
        // Calculate average response time (simplified)
        $avg_response_time = '-';
        
        $customer_reports[] = array(
            'customer' => $customer->display_name ?: $customer->user_login,
            'customer_id' => $customer->ID,
            'total_chats' => $total_chats,
            'active_chats' => $active_chats,
            'closed_chats' => $closed_chats,
            'dispute_chats' => $dispute_chats,
            'total_messages' => $total_messages,
            'avg_response_time' => $avg_response_time
        );
    }
    
    return $customer_reports;
}

/**
 * Handle Report Generation (admin_post handler)
 */
function wheelfy_handle_generate_report() {
    // Verify nonce
    if (!isset($_POST['wheelfy_report_nonce']) || !wp_verify_nonce($_POST['wheelfy_report_nonce'], 'wheelfy_generate_report')) {
        wp_die(__('Security check failed.', 'wheelfy'), __('Error', 'wheelfy'), array('response' => 403));
    }
    
    // Check capability
    if (!current_user_can('manage_options')) {
        wp_die(__('You do not have permission to generate reports.', 'wheelfy'), __('Permission Denied', 'wheelfy'), array('response' => 403));
    }
    
    // Get form data
    $report_type = isset($_POST['report_type']) ? sanitize_text_field($_POST['report_type']) : '';
    $format = isset($_POST['format']) ? sanitize_text_field($_POST['format']) : 'csv';
    $date_from = isset($_POST['date_from']) ? sanitize_text_field($_POST['date_from']) : '';
    $date_to = isset($_POST['date_to']) ? sanitize_text_field($_POST['date_to']) : '';
    
    if (empty($report_type)) {
        wp_redirect(add_query_arg(array('page' => 'wheelfy-reports', 'tab' => 'export', 'error' => 'missing_type'), admin_url('admin.php')));
        exit;
    }
    
    // Validate format
    if (!in_array($format, array('csv', 'pdf', 'xlsx'))) {
        wp_redirect(add_query_arg(array('page' => 'wheelfy-reports', 'tab' => 'export', 'error' => 'unsupported_format'), admin_url('admin.php')));
        exit;
    }
    
    // Map report types to display names
    $report_names = array(
        'users' => __('Users Report', 'wheelfy'),
        'chat' => __('Chat Report', 'wheelfy'),
        'leads' => __('Leads Report', 'wheelfy'),
        'offers' => __('Offers Report', 'wheelfy'),
        'revenue' => __('Revenue Report', 'wheelfy'),
        'subscriptions' => __('Subscriptions Report', 'wheelfy'),
        'reviews' => __('Reviews Report', 'wheelfy'),
        'partner' => __('Partner Report', 'wheelfy'),
        'customer' => __('Customer Report', 'wheelfy')
    );
    
    $report_name = isset($report_names[$report_type]) ? $report_names[$report_type] : ucfirst($report_type) . ' Report';
    
    // Prepare options
    $options = array(
        'date_from' => $date_from,
        'date_to' => $date_to,
        'include_details' => isset($_POST['include_details']) ? true : false,
        'include_summary' => isset($_POST['include_summary']) ? true : false
    );
    
    // Generate report
    $report = wheelfy_generate_report($report_type, $report_name, $format, $options);
    
    if ($report) {
        wp_redirect(add_query_arg(array('page' => 'wheelfy-reports', 'tab' => 'overview', 'report_generated' => '1'), admin_url('admin.php')));
    } else {
        wp_redirect(add_query_arg(array('page' => 'wheelfy-reports', 'tab' => 'export', 'error' => 'generation_failed'), admin_url('admin.php')));
    }
    
    exit;
}
add_action('admin_post_wheelfy_generate_report', 'wheelfy_handle_generate_report');

/**
 * Handle Report View (admin_init handler)
 */
function wheelfy_handle_report_view() {
    // Only process on reports page
    if (!isset($_GET['page']) || $_GET['page'] !== 'wheelfy-reports') {
        return;
    }
    
    if (!isset($_GET['action']) || $_GET['action'] !== 'view' || !isset($_GET['report_id'])) {
        return;
    }
    
    // Verify nonce
    if (!isset($_GET['nonce']) || !wp_verify_nonce($_GET['nonce'], 'wheelfy_view_report_' . $_GET['report_id'])) {
        wp_die(__('Security check failed.', 'wheelfy'), __('Error', 'wheelfy'), array('response' => 403));
    }
    
    // Check capability
    if (!current_user_can('manage_options')) {
        wp_die(__('You do not have permission to view reports.', 'wheelfy'), __('Permission Denied', 'wheelfy'), array('response' => 403));
    }
    
    $report_id = intval($_GET['report_id']);
    $report = wheelfy_get_report($report_id);
    
    if (!$report || !file_exists($report['file_path'])) {
        wp_die(__('Report not found.', 'wheelfy'), __('Error', 'wheelfy'), array('response' => 404));
    }
    
    // Clear output buffers
    while (ob_get_level()) {
        ob_end_clean();
    }
    
    // Determine content type based on format
    $format = $report['file_format'];
    $content_type = 'text/plain; charset=UTF-8';
    
    switch ($format) {
        case 'csv':
            $content_type = 'text/csv; charset=UTF-8';
            break;
        case 'xlsx':
            $content_type = 'application/xml; charset=UTF-8';
            break;
        case 'pdf':
            $content_type = 'text/html; charset=UTF-8';
            break;
    }
    
    // Set headers for viewing
    header('Content-Type: ' . $content_type);
    header('Content-Disposition: inline; filename="' . basename($report['file_path']) . '"');
    header('Content-Length: ' . filesize($report['file_path']));
    
    // Output file
    readfile($report['file_path']);
    exit;
}
add_action('admin_init', 'wheelfy_handle_report_view', 1);

/**
 * Handle Report Download (admin_init handler)
 */
function wheelfy_handle_report_download() {
    // Only process on reports page
    if (!isset($_GET['page']) || $_GET['page'] !== 'wheelfy-reports') {
        return;
    }
    
    if (!isset($_GET['action']) || $_GET['action'] !== 'download' || !isset($_GET['report_id'])) {
        return;
    }
    
    // Verify nonce
    if (!isset($_GET['nonce']) || !wp_verify_nonce($_GET['nonce'], 'wheelfy_download_report_' . $_GET['report_id'])) {
        wp_die(__('Security check failed.', 'wheelfy'), __('Error', 'wheelfy'), array('response' => 403));
    }
    
    // Check capability
    if (!current_user_can('manage_options')) {
        wp_die(__('You do not have permission to download reports.', 'wheelfy'), __('Permission Denied', 'wheelfy'), array('response' => 403));
    }
    
    $report_id = intval($_GET['report_id']);
    $report = wheelfy_get_report($report_id);
    
    if (!$report || !file_exists($report['file_path'])) {
        wp_die(__('Report not found.', 'wheelfy'), __('Error', 'wheelfy'), array('response' => 404));
    }
    
    // Clear output buffers
    while (ob_get_level()) {
        ob_end_clean();
    }
    
    // Determine content type and filename based on format
    $format = $report['file_format'];
    $content_type = 'application/octet-stream';
    $filename = basename($report['file_path']);
    
    switch ($format) {
        case 'csv':
            $content_type = 'text/csv; charset=UTF-8';
            break;
        case 'xlsx':
            $content_type = 'application/vnd.ms-excel';
            // Rename .xml to .xls for better Excel compatibility
            $filename = str_replace('.xml', '.xls', $filename);
            break;
        case 'pdf':
            $content_type = 'text/html; charset=UTF-8';
            break;
    }
    
    // Set headers for download
    nocache_headers();
    header('Content-Type: ' . $content_type);
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Content-Length: ' . filesize($report['file_path']));
    
    // Output file
    readfile($report['file_path']);
    exit;
}
add_action('admin_init', 'wheelfy_handle_report_download', 1);

/**
 * Handle System Report Download (admin_post handler)
 * Generates reports on-demand for system reports in various formats
 */
function wheelfy_handle_system_report_download() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_download_system_report')) {
        wp_die(__('Security check failed.', 'wheelfy'), __('Error', 'wheelfy'), array('response' => 403));
    }
    
    // Check capability
    if (!current_user_can('manage_options')) {
        wp_die(__('Permission denied.', 'wheelfy'), __('Error', 'wheelfy'), array('response' => 403));
    }
    
    $report_type = isset($_POST['report_type']) ? sanitize_text_field($_POST['report_type']) : '';
    $format = isset($_POST['format']) ? sanitize_text_field($_POST['format']) : 'csv';
    
    // Validate format
    if (!in_array($format, array('csv', 'pdf', 'xlsx'))) {
        wp_die(__('Invalid format.', 'wheelfy'), __('Error', 'wheelfy'), array('response' => 400));
    }
    
    // Validate report type
    $valid_types = array('chat', 'partner', 'customer');
    if (!in_array($report_type, $valid_types)) {
        wp_die(__('Invalid report type.', 'wheelfy'), __('Error', 'wheelfy'), array('response' => 400));
    }
    
    // Get report data
    $report_data = null;
    $report_name = '';
    switch ($report_type) {
        case 'chat':
            $report_data = wheelfy_get_chat_report_data(array());
            $report_name = __('Chat Report', 'wheelfy');
            break;
        case 'partner':
            $report_data = wheelfy_get_partner_report_data(array());
            $report_name = __('Partner Report', 'wheelfy');
            break;
        case 'customer':
            $report_data = wheelfy_get_customer_report_data(array());
            $report_name = __('Customer Report', 'wheelfy');
            break;
    }
    
    if (empty($report_data) || empty($report_data['data'])) {
        wp_die(__('No data available for this report.', 'wheelfy'), __('Error', 'wheelfy'), array('response' => 404));
    }
    
    // Generate content based on format
    $timestamp = current_time('Y-m-d_His');
    $content = '';
    $filename = '';
    $content_type = '';
    
    switch ($format) {
        case 'csv':
            $content = wheelfy_generate_csv_content($report_data['data'], $report_data['headers']);
            $filename = sanitize_file_name($report_type . '_report_' . $timestamp . '.csv');
            $content_type = 'text/csv; charset=UTF-8';
            break;
        case 'xlsx':
            $content = wheelfy_generate_excel_content($report_data['data'], $report_data['headers'], $report_name);
            $filename = sanitize_file_name($report_type . '_report_' . $timestamp . '.xls');
            $content_type = 'application/vnd.ms-excel';
            break;
        case 'pdf':
            $content = wheelfy_generate_pdf_content($report_data['data'], $report_data['headers'], $report_name, array('include_summary' => true, 'include_charts' => true));
            $filename = sanitize_file_name($report_type . '_report_' . $timestamp . '.html');
            $content_type = 'text/html; charset=UTF-8';
            break;
    }
    
    // Clear output buffers
    while (ob_get_level()) {
        ob_end_clean();
    }
    
    // Set headers for download
    nocache_headers();
    header('Content-Type: ' . $content_type);
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Content-Length: ' . strlen($content));
    
    // Output content
    echo $content;
    exit;
}
add_action('admin_post_wheelfy_download_system_report', 'wheelfy_handle_system_report_download');

/**
 * AJAX: View System Report (Get Paginated Data)
 * Returns paginated data for viewing in modal/page
 */
function wheelfy_ajax_view_system_report() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_view_system_report')) {
        wp_send_json_error(array('message' => __('Security check failed.', 'wheelfy')));
    }
    
    // Check capability
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => __('Permission denied.', 'wheelfy')));
    }
    
    $report_type = isset($_POST['report_type']) ? sanitize_text_field($_POST['report_type']) : '';
    $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
    $per_page = isset($_POST['per_page']) ? intval($_POST['per_page']) : 20;
    
    // Validate report type
    $valid_types = array('chat', 'partner', 'customer');
    if (!in_array($report_type, $valid_types)) {
        wp_send_json_error(array('message' => __('Invalid report type.', 'wheelfy')));
    }
    
    // Get report data
    $report_data = null;
    switch ($report_type) {
        case 'chat':
            $report_data = wheelfy_get_chat_report_data(array());
            break;
        case 'partner':
            $report_data = wheelfy_get_partner_report_data(array());
            break;
        case 'customer':
            $report_data = wheelfy_get_customer_report_data(array());
            break;
    }
    
    if (empty($report_data) || empty($report_data['data'])) {
        wp_send_json_success(array(
            'headers' => array(),
            'data' => array(),
            'total' => 0,
            'page' => 1,
            'per_page' => $per_page,
            'total_pages' => 0
        ));
    }
    
    $all_data = $report_data['data'];
    $total = count($all_data);
    $total_pages = ceil($total / $per_page);
    $page = max(1, min($page, $total_pages));
    
    // Paginate data
    $offset = ($page - 1) * $per_page;
    $paginated_data = array_slice($all_data, $offset, $per_page);
    
    wp_send_json_success(array(
        'headers' => $report_data['headers'],
        'data' => $paginated_data,
        'total' => $total,
        'page' => $page,
        'per_page' => $per_page,
        'total_pages' => $total_pages
    ));
}
add_action('wp_ajax_wheelfy_view_system_report', 'wheelfy_ajax_view_system_report');

/**
 * AJAX: Filter Reports (Overview Tab)
 * Returns filtered reports based on type filter
 */
function wheelfy_ajax_filter_reports() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_filter_reports')) {
        wp_send_json_error(array('message' => __('Security check failed.', 'wheelfy')));
    }
    
    // Check capability
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => __('Permission denied.', 'wheelfy')));
    }
    
    $filter_type = isset($_POST['filter_type']) ? sanitize_text_field($_POST['filter_type']) : 'all';
    
    // Get reports with filter
    $filters = array();
    if ($filter_type !== 'all') {
        $filters['type'] = $filter_type;
    }
    
    // Get CSV reports
    $csv_reports = wheelfy_get_reports($filters, false); // Don't include system when filtering
    
    // Get system summaries if filter is 'all' or matches
    $system_reports = array();
    if ($filter_type === 'all' || in_array($filter_type, array('chat', 'partner', 'customer'))) {
        $system_summaries = wheelfy_get_system_report_summaries();
        foreach ($system_summaries as $summary) {
            if ($filter_type === 'all' || $summary['report_type'] === $filter_type) {
                $system_reports[] = $summary;
            }
        }
    }
    
    // Combine: CSV reports first, then system reports
    $all_reports = array_merge($csv_reports, $system_reports);
    
    // Format reports for display
    $formatted_reports = array();
    foreach ($all_reports as $report) {
        $is_system_report = (isset($report['file_format']) && $report['file_format'] === 'system') || 
                           (isset($report['status']) && $report['status'] === 'live_data');
        
        // Format date range
        $date_range = '-';
        if (!empty($report['date_range_from']) || !empty($report['date_range_to'])) {
            $from = !empty($report['date_range_from']) ? date_i18n(get_option('date_format'), strtotime($report['date_range_from'])) : '';
            $to = !empty($report['date_range_to']) ? date_i18n(get_option('date_format'), strtotime($report['date_range_to'])) : '';
            if ($from && $to) {
                $date_range = $from . ' to ' . $to;
            } elseif ($from) {
                $date_range = __('From', 'wheelfy') . ' ' . $from;
            } elseif ($to) {
                $date_range = __('Until', 'wheelfy') . ' ' . $to;
            }
        }
        
        $formatted_reports[] = array(
            'id' => is_numeric($report['id']) ? $report['id'] : '-',
            'report_name' => $report['report_name'],
            'report_type' => $report['report_type'],
            'date_range' => $date_range,
            'file_format' => $report['file_format'],
            'generated_date' => $is_system_report ? __('Live Data', 'wheelfy') : date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($report['generated_at'])),
            'file_size' => $is_system_report ? '-' : size_format($report['file_size'], 2),
            'status' => $report['status'],
            'is_system' => $is_system_report
        );
    }
    
    wp_send_json_success(array('reports' => $formatted_reports));
}
add_action('wp_ajax_wheelfy_filter_reports', 'wheelfy_ajax_filter_reports');

/**
 * AJAX: Delete Report
 * Deletes a report file and its database record
 */
function wheelfy_ajax_delete_report() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_delete_report')) {
        wp_send_json_error(array('message' => __('Security check failed.', 'wheelfy')));
    }
    
    // Check capability
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => __('Permission denied.', 'wheelfy')));
    }
    
    $report_id = isset($_POST['report_id']) ? intval($_POST['report_id']) : 0;
    
    if (!$report_id) {
        wp_send_json_error(array('message' => __('Invalid report ID.', 'wheelfy')));
    }
    
    // Get report data
    $report = wheelfy_get_report($report_id);
    
    if (!$report) {
        wp_send_json_error(array('message' => __('Report not found.', 'wheelfy')));
    }
    
    // Delete the file if it exists
    if (!empty($report['file_path']) && file_exists($report['file_path'])) {
        @unlink($report['file_path']);
    }
    
    // Delete from database
    global $wpdb;
    $table_name = $wpdb->prefix . 'wheelfy_reports';
    
    $deleted = $wpdb->delete(
        $table_name,
        array('id' => $report_id),
        array('%d')
    );
    
    if ($deleted === false) {
        wp_send_json_error(array('message' => __('Failed to delete report from database.', 'wheelfy')));
    }
    
    wp_send_json_success(array('message' => __('Report deleted successfully.', 'wheelfy')));
}
add_action('wp_ajax_wheelfy_delete_report', 'wheelfy_ajax_delete_report');
