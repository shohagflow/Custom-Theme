<?php
/**
 * Admin Reports & Export Page
 * 
 * @package Wheelfy
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!current_user_can('administrator')) {
    wp_die(__('You do not have permission to access this page.', 'wheelfy'));
}

// Load reports functions (ensure they're available)
if (!function_exists('wheelfy_get_reports')) {
    require_once get_template_directory() . '/admin/admin-reports-functions.php';
}

// Get real data for tabs
$chat_status_filter = isset($_GET['filter_chat_status']) ? sanitize_text_field($_GET['filter_chat_status']) : 'all';

// Ensure functions exist before calling them
if (function_exists('wheelfy_get_chat_reports_for_tab')) {
    $chat_reports = wheelfy_get_chat_reports_for_tab(array('status' => $chat_status_filter));
} else {
    $chat_reports = array();
}

if (function_exists('wheelfy_get_partner_reports_for_tab')) {
    $partner_reports = wheelfy_get_partner_reports_for_tab();
} else {
    $partner_reports = array();
}

if (function_exists('wheelfy_get_customer_reports_for_tab')) {
    $customer_reports = wheelfy_get_customer_reports_for_tab();
} else {
    $customer_reports = array();
}

// Get reports from database (includes system summaries if no CSV reports)
$report_filters = array();
if (isset($_GET['filter_report_type']) && !empty($_GET['filter_report_type']) && $_GET['filter_report_type'] !== 'all') {
    $report_filters['type'] = sanitize_text_field($_GET['filter_report_type']);
}
$reports = wheelfy_get_reports($report_filters, true); // Include system summaries

// Calculate statistics from real data
$total_chats = count($chat_reports);
$active_chats = count(array_filter($chat_reports, function($c) { return $c['status'] === 'active'; }));
$closed_chats = count(array_filter($chat_reports, function($c) { return $c['status'] === 'closed'; }));
$dispute_chats = count(array_filter($chat_reports, function($c) { return $c['status'] === 'dispute'; }));
$total_messages = array_sum(array_column($chat_reports, 'messages'));
$total_partners = count($partner_reports);
$total_customers = count($customer_reports);

// Count available report types (system reports with data)
$available_report_types = 0;
if (!empty($chat_reports)) $available_report_types++;
if (!empty($partner_reports)) $available_report_types++;
if (!empty($customer_reports)) $available_report_types++;

// Count CSV reports (exclude system reports)
$csv_reports = array_filter($reports, function($r) {
    return !isset($r['file_format']) || $r['file_format'] !== 'system';
});
$total_reports_generated = count($csv_reports);
$total_available_reports = count($reports); // Includes system reports

// Determine most requested report type (by data volume)
$most_requested = 'Chat Report';
$max_count = $total_chats;
if ($total_partners > $max_count) {
    $most_requested = 'Partner Report';
    $max_count = $total_partners;
}
if ($total_customers > $max_count) {
    $most_requested = 'Customer Report';
}

$current_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'overview';
if (!in_array($current_tab, array('overview', 'by-chat', 'by-partner', 'by-customer', 'export'))) {
    $current_tab = 'overview';
}
?>
<div class="wrap wheelfy-admin-reports">
    <!-- Header -->
    <div class="wheelfy-admin-header">
        <div>
            <h1 class="wp-heading-inline"><?php _e('Reports & Export', 'wheelfy'); ?></h1>
            <p class="description"><?php _e('Generate comprehensive reports and export data for analysis', 'wheelfy'); ?></p>
        </div>
    </div>
    <hr class="wp-header-end">

    <!-- KPI Cards -->
    <div class="wheelfy-kpi-grid">
        <div class="wheelfy-kpi-card">
            <div class="kpi-icon" style="background: #e3f2fd; color: #1976d2;">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                    <polyline points="14 2 14 8 20 8"></polyline>
                    <line x1="16" y1="13" x2="8" y2="13"></line>
                    <line x1="16" y1="17" x2="8" y2="17"></line>
                    <polyline points="10 9 9 9 8 9"></polyline>
                </svg>
            </div>
            <div class="kpi-content">
                <div class="kpi-label"><?php _e('Total Reports', 'wheelfy'); ?></div>
                <div class="kpi-value"><?php echo number_format($total_reports_generated); ?></div>
            </div>
        </div>

        <div class="wheelfy-kpi-card">
            <div class="kpi-icon" style="background: #e8f5e9; color: #388e3c;">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
                </svg>
            </div>
            <div class="kpi-content">
                <div class="kpi-label"><?php _e('Total Chats', 'wheelfy'); ?></div>
                <div class="kpi-value"><?php echo number_format($total_chats); ?></div>
            </div>
        </div>

        <div class="wheelfy-kpi-card">
            <div class="kpi-icon" style="background: #fff3e0; color: #f57c00;">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                    <circle cx="9" cy="7" r="4"></circle>
                    <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                    <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                </svg>
            </div>
            <div class="kpi-content">
                <div class="kpi-label"><?php _e('Total Messages', 'wheelfy'); ?></div>
                <div class="kpi-value"><?php echo number_format($total_messages); ?></div>
            </div>
        </div>

        <div class="wheelfy-kpi-card">
            <div class="kpi-icon" style="background: #f3e5f5; color: #7b1fa2;">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                    <circle cx="8.5" cy="7" r="4"></circle>
                    <path d="M20 8v6"></path>
                    <path d="M23 11h-6"></path>
                </svg>
            </div>
            <div class="kpi-content">
                <div class="kpi-label"><?php _e('Active Partners', 'wheelfy'); ?></div>
                <div class="kpi-value"><?php echo number_format($total_partners); ?></div>
            </div>
        </div>
    </div>

    <!-- Tabs Navigation -->
    <nav class="nav-tab-wrapper wheelfy-subscription-tabs">
        <a href="<?php echo esc_url(add_query_arg('tab', 'overview', admin_url('admin.php?page=wheelfy-reports'))); ?>" 
           class="nav-tab <?php echo $current_tab === 'overview' ? 'nav-tab-active' : ''; ?>" 
           data-tab="overview">
            <?php _e('Overview', 'wheelfy'); ?>
        </a>
        <a href="<?php echo esc_url(add_query_arg('tab', 'export', admin_url('admin.php?page=wheelfy-reports'))); ?>" 
           class="nav-tab <?php echo $current_tab === 'export' ? 'nav-tab-active' : ''; ?>" 
           data-tab="export">
            <?php _e('Export', 'wheelfy'); ?>
        </a>
    </nav>

    <!-- Overview Tab -->
    <div class="wheelfy-tab-content <?php echo $current_tab === 'overview' ? 'active' : ''; ?>" id="tab-overview">
        <div class="wheelfy-dashboard-card">
            <div class="card-header">
                <div>
                    <h2><?php _e('Report Overview', 'wheelfy'); ?></h2>
                    <p class="card-description"><?php _e('Quick insights and recent report activity', 'wheelfy'); ?></p>
                </div>
            </div>
            <div class="card-body">
                <div class="insights-grid">
                    <div class="insight-card">
                        <div class="insight-icon" style="background: #e3f2fd; color: #1976d2;">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                                <polyline points="14 2 14 8 20 8"></polyline>
                            </svg>
                        </div>
                        <div class="insight-content">
                            <h3><?php _e('Available Reports', 'wheelfy'); ?></h3>
                            <p class="insight-number"><?php echo number_format($available_report_types); ?></p>
                            <p class="insight-label"><?php _e('report types with data', 'wheelfy'); ?></p>
                        </div>
                    </div>
                    <div class="insight-card">
                        <div class="insight-icon" style="background: #e8f5e9; color: #388e3c;">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
                            </svg>
                        </div>
                        <div class="insight-content">
                            <h3><?php _e('Most Requested Report', 'wheelfy'); ?></h3>
                            <p class="insight-text"><?php echo esc_html($most_requested); ?></p>
                        </div>
                    </div>
                    <div class="insight-card">
                        <div class="insight-icon" style="background: #fff3e0; color: #f57c00;">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <circle cx="12" cy="12" r="10"></circle>
                                <path d="M12 6v6l4 2"></path>
                            </svg>
                        </div>
                        <div class="insight-content">
                            <h3><?php _e('CSV Reports Generated', 'wheelfy'); ?></h3>
                            <p class="insight-number"><?php echo number_format($total_reports_generated); ?></p>
                            <p class="insight-label"><?php _e('files available', 'wheelfy'); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="wheelfy-dashboard-card">
            <div class="card-header">
                <div>
                    <h2><?php _e('Recent Reports', 'wheelfy'); ?></h2>
                    <p class="card-description"><?php _e('Recently generated reports available for download', 'wheelfy'); ?></p>
                </div>
                <div class="header-filters">
                    <select id="filter-report-type-overview" class="filter-select">
                        <option value="all" <?php selected(!isset($_GET['filter_report_type']) || $_GET['filter_report_type'] === 'all'); ?>><?php _e('All Types', 'wheelfy'); ?></option>
                        <option value="chat" <?php selected(isset($_GET['filter_report_type']) && $_GET['filter_report_type'] === 'chat'); ?>><?php _e('Chat', 'wheelfy'); ?></option>
                        <option value="partner" <?php selected(isset($_GET['filter_report_type']) && $_GET['filter_report_type'] === 'partner'); ?>><?php _e('Partner', 'wheelfy'); ?></option>
                        <option value="customer" <?php selected(isset($_GET['filter_report_type']) && $_GET['filter_report_type'] === 'customer'); ?>><?php _e('Customer', 'wheelfy'); ?></option>
                    </select>
                </div>
            </div>
            <div class="card-body">
                <table id="wheelfy-reports-table" class="wp-list-table widefat fixed striped table-view-list">
                    <thead>
                        <tr>
                            <th class="column-id"><?php _e('#', 'wheelfy'); ?></th>
                            <th class="column-type"><?php _e('Report Type', 'wheelfy'); ?></th>
                            <th class="column-date-range"><?php _e('Date Range', 'wheelfy'); ?></th>
                            <th class="column-format"><?php _e('Format', 'wheelfy'); ?></th>
                            <th class="column-generated"><?php _e('Generated', 'wheelfy'); ?></th>
                            <th class="column-size"><?php _e('Size', 'wheelfy'); ?></th>
                            <th class="column-status"><?php _e('Status', 'wheelfy'); ?></th>
                            <th class="column-actions"><?php _e('Actions', 'wheelfy'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        if (empty($reports)) : ?>
                            <tr>
                                <td colspan="8" style="text-align: center; padding: 40px;">
                                    <?php _e('No data available.', 'wheelfy'); ?>
                                </td>
                            </tr>
                        <?php else :
                            foreach ($reports as $report) : 
                                // Check if this is a system report
                                $is_system_report = (isset($report['file_format']) && $report['file_format'] === 'system') || 
                                                   (isset($report['status']) && $report['status'] === 'live_data') ||
                                                   (isset($report['metadata']['type']) && $report['metadata']['type'] === 'system');
                                
                                // Format date range
                                $date_range = '-';
                                if (!empty($report['date_range_from']) || !empty($report['date_range_to'])) {
                                    $from = !empty($report['date_range_from']) ? date_i18n(get_option('date_format'), strtotime($report['date_range_from'])) : '';
                                    $to = !empty($report['date_range_to']) ? date_i18n(get_option('date_format'), strtotime($report['date_range_to'])) : '';
                                    if ($from && $to) {
                                        $date_range = $from . ' to ' . $to;
                                    } elseif ($from) {
                                        $date_range = __('From', 'wheelfy') . ' ' . $from;
                                    } elseif ($to) {
                                        $date_range = __('Until', 'wheelfy') . ' ' . $to;
                                    }
                                }
                                
                                // Format file size
                                $file_size_formatted = $is_system_report ? '-' : size_format($report['file_size'], 2);
                                
                                // Format generated date
                                $generated_date = $is_system_report ? __('Live Data', 'wheelfy') : date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($report['generated_at']));
                                
                                // Create action URLs
                                if ($is_system_report) {
                                    // For system reports, use AJAX handlers
                                    $view_url = '#'; // Will be handled by JavaScript
                                    $download_url = '#'; // Will be handled by JavaScript
                                    $report_type_attr = $report['report_type'];
                                } else {
                                    // For CSV reports, use view/download handlers
                                    $view_url = add_query_arg(array(
                                        'page' => 'wheelfy-reports',
                                        'action' => 'view',
                                        'report_id' => $report['id'],
                                        'nonce' => wp_create_nonce('wheelfy_view_report_' . $report['id'])
                                    ), admin_url('admin.php'));
                                    
                                    $download_url = add_query_arg(array(
                                        'page' => 'wheelfy-reports',
                                        'action' => 'download',
                                        'report_id' => $report['id'],
                                        'nonce' => wp_create_nonce('wheelfy_download_report_' . $report['id'])
                                    ), admin_url('admin.php'));
                                    $report_type_attr = '';
                                }
                        ?>
                            <tr>
                                <td class="column-id"><?php echo is_numeric($report['id']) ? $report['id'] : '-'; ?></td>
                                <td class="column-type"><strong><?php echo esc_html($report['report_name']); ?></strong></td>
                                <td class="column-date-range"><?php echo esc_html($date_range); ?></td>
                                <td class="column-format">
                                    <span class="format-badge format-<?php echo strtolower($report['file_format']); ?>">
                                        <?php echo esc_html(strtoupper($report['file_format'])); ?>
                                    </span>
                                </td>
                                <td class="column-generated"><?php echo esc_html($generated_date); ?></td>
                                <td class="column-size"><?php echo esc_html($file_size_formatted); ?></td>
                                <td class="column-status">
                                    <span class="status-badge status-<?php echo esc_attr($report['status']); ?>">
                                        <?php echo esc_html(ucfirst(str_replace('_', ' ', $report['status']))); ?>
                                    </span>
                                </td>
                                <td class="column-actions">
                                    <div class="row-actions">
                                        <a href="<?php echo esc_url($download_url); ?>" 
                                           class="button button-small <?php echo $is_system_report ? 'wheelfy-download-system-report' : ''; ?>"
                                           <?php if ($is_system_report) : ?>
                                           data-report-type="<?php echo esc_attr($report_type_attr); ?>"
                                           data-format="csv"
                                           <?php endif; ?>
                                           ><?php _e('Download', 'wheelfy'); ?></a>
                                        <?php if (!$is_system_report) : ?>
                                        <button type="button" 
                                           class="button button-small button-link-delete wheelfy-delete-report"
                                           data-report-id="<?php echo esc_attr($report['id']); ?>"
                                           data-report-name="<?php echo esc_attr($report['report_name']); ?>"
                                           ><?php _e('Delete', 'wheelfy'); ?></button>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php 
                            endforeach;
                        endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- Report View Modal -->
        <div id="wheelfy-report-view-modal" class="wheelfy-modal" style="display: none;">
            <div class="wheelfy-modal-overlay"></div>
            <div class="wheelfy-modal-content">
                <div class="wheelfy-modal-header">
                    <h2 id="wheelfy-modal-title"><?php _e('Report Preview', 'wheelfy'); ?></h2>
                    <button type="button" class="wheelfy-modal-close" aria-label="<?php esc_attr_e('Close', 'wheelfy'); ?>">&times;</button>
                </div>
                <div class="wheelfy-modal-body">
                    <div id="wheelfy-report-view-content">
                        <p class="loading"><?php _e('Loading report data...', 'wheelfy'); ?></p>
                    </div>
                </div>
                <div class="wheelfy-modal-footer">
                    <div id="wheelfy-report-pagination"></div>
                </div>
            </div>
        </div>
    </div>

    <div class="wheelfy-tab-content <?php echo $current_tab === 'export' ? 'active' : ''; ?>" id="tab-export">
        <div class="wheelfy-dashboard-card">
            <div class="card-header">
                <div>
                    <h2><?php _e('Generate Reports', 'wheelfy'); ?></h2>
                    <p class="card-description"><?php _e('Create custom reports and export data in various formats', 'wheelfy'); ?></p>
                </div>
            </div>
            <div class="card-body">
                <?php
                // Show error messages
                if (isset($_GET['error'])) {
                    $error_message = '';
                    switch ($_GET['error']) {
                        case 'missing_type':
                            $error_message = __('Please select a report type.', 'wheelfy');
                            break;
                        case 'unsupported_format':
                            $error_message = __('Invalid export format selected. Please select CSV, PDF, or Excel.', 'wheelfy');
                            break;
                        case 'generation_failed':
                            $error_message = __('Report generation failed. Please try again.', 'wheelfy');
                            break;
                        default:
                            $error_message = __('An error occurred. Please try again.', 'wheelfy');
                    }
                    if ($error_message) {
                        echo '<div class="notice notice-error"><p>' . esc_html($error_message) . '</p></div>';
                    }
                }
                if (isset($_GET['report_generated']) && $_GET['report_generated'] == '1') {
                    echo '<div class="notice notice-success"><p>' . esc_html__('Report generated successfully!', 'wheelfy') . '</p></div>';
                }
                ?>
                <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" class="report-form">
                    <input type="hidden" name="action" value="wheelfy_generate_report">
                    <?php wp_nonce_field('wheelfy_generate_report', 'wheelfy_report_nonce'); ?>
                    <div class="form-grid">
                        <div class="form-field">
                            <label for="report_type"><?php _e('Report Type', 'wheelfy'); ?> <span class="required">*</span></label>
                            <select name="report_type" id="report_type" class="regular-text" required>
                                <option value=""><?php _e('Select Report Type', 'wheelfy'); ?></option>
                                <option value="users"><?php _e('Users Report', 'wheelfy'); ?></option>
                                <option value="chat"><?php _e('Chat Report', 'wheelfy'); ?></option>
                                <option value="offers"><?php _e('Offers Report', 'wheelfy'); ?></option>
                                <option value="revenue"><?php _e('Revenue Report', 'wheelfy'); ?></option>
                                <option value="subscriptions"><?php _e('Subscriptions Report', 'wheelfy'); ?></option>
                                <option value="reviews"><?php _e('Reviews Report', 'wheelfy'); ?></option>
                                <option value="partner"><?php _e('Partner Report', 'wheelfy'); ?></option>
                                <option value="customer"><?php _e('Customer Report', 'wheelfy'); ?></option>
                            </select>
                            <p class="description"><?php _e('Select the type of report you want to generate.', 'wheelfy'); ?></p>
                        </div>

                        <div class="form-field">
                            <label for="date_from"><?php _e('Date Range', 'wheelfy'); ?></label>
                            <div class="date-range-inputs">
                                <input type="date" name="date_from" id="date_from" class="regular-text">
                                <span class="date-separator"><?php _e('to', 'wheelfy'); ?></span>
                                <input type="date" name="date_to" id="date_to" class="regular-text">
                            </div>
                            <p class="description"><?php _e('Leave empty to include all dates.', 'wheelfy'); ?></p>
                        </div>

                        <div class="form-field">
                            <label><?php _e('Export Format', 'wheelfy'); ?></label>
                            <div class="format-options">
                                <label class="format-option">
                                    <input type="radio" name="format" value="csv" checked>
                                    <span class="format-label">
                                        <strong>CSV</strong>
                                        <small><?php _e('Excel compatible', 'wheelfy'); ?></small>
                                    </span>
                                </label>
                                <label class="format-option">
                                    <input type="radio" name="format" value="pdf">
                                    <span class="format-label">
                                        <strong>PDF</strong>
                                        <small><?php _e('Formatted document', 'wheelfy'); ?></small>
                                    </span>
                                </label>
                                <label class="format-option">
                                    <input type="radio" name="format" value="xlsx">
                                    <span class="format-label">
                                        <strong>Excel</strong>
                                        <small><?php _e('Advanced formatting', 'wheelfy'); ?></small>
                                    </span>
                                </label>
                            </div>
                        </div>

                        <div class="form-field">
                            <label><?php _e('Additional Options', 'wheelfy'); ?></label>
                            <div class="checkbox-options">
                                <label class="checkbox-option">
                                    <input type="checkbox" name="include_details" id="include_details" value="1" checked>
                                    <span><?php _e('Include detailed information', 'wheelfy'); ?></span>
                                </label>
                                <label class="checkbox-option">
                                    <input type="checkbox" name="include_charts" id="include_charts" value="1">
                                    <span><?php _e('Include charts and graphs (PDF/Excel only)', 'wheelfy'); ?></span>
                                </label>
                                <label class="checkbox-option">
                                    <input type="checkbox" name="include_summary" id="include_summary" value="1" checked>
                                    <span><?php _e('Include summary statistics', 'wheelfy'); ?></span>
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="form-actions">
                        <button type="submit" name="generate_report" class="button button-primary button-large">
                            <span class="dashicons dashicons-download"></span>
                            <?php _e('Generate Report', 'wheelfy'); ?>
                        </button>
                        <button type="button" class="button button-secondary" id="preview-report">
                            <?php _e('Preview', 'wheelfy'); ?>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<style>
/* Admin Reports Page Styles */
.wheelfy-admin-reports {
    margin: 20px 0 0 0;
}

.wheelfy-admin-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 20px;
}

.wheelfy-admin-header h1 {
    margin: 0 0 8px 0;
    font-size: 23px;
    font-weight: 400;
}

.wheelfy-admin-header .description {
    margin: 0;
    color: #646970;
    font-size: 14px;
}

/* KPI Cards */
.wheelfy-kpi-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
    margin: 20px 0;
    padding-left: 20px;
}

.wheelfy-kpi-card {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 20px;
    display: flex;
    align-items: center;
    gap: 16px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    transition: all 0.3s ease;
}

.wheelfy-kpi-card:hover {
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    border-color: #2271b1;
}

.kpi-icon {
    width: 48px;
    height: 48px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.kpi-icon svg {
    display: block;
    margin: 0 auto;
    width: 24px;
    height: 24px;
}

.kpi-content {
    flex: 1;
}

.kpi-label {
    font-size: 13px;
    color: #646970;
    margin-bottom: 4px;
}

.kpi-value {
    font-size: 28px;
    font-weight: 600;
    color: #1d2327;
    line-height: 1.2;
}

/* Tabs */
.nav-tab-wrapper {
    margin: 20px 0 0 0;
    border-bottom: 1px solid #ccc;
}

.nav-tab-wrapper .nav-tab {
    margin-bottom: -1px;
    padding: 10px 15px;
    font-size: 14px;
    text-decoration: none;
    border: 1px solid transparent;
    border-bottom: none;
    background: transparent;
    color: #50575e;
    cursor: pointer;
    transition: all 0.2s ease;
}

.nav-tab-wrapper .nav-tab:hover {
    color: #2271b1;
    background: #f6f7f7;
}

.nav-tab-wrapper .nav-tab.nav-tab-active {
    color: #2271b1;
    background: #fff;
    border-color: #ccc;
    border-bottom-color: #fff;
}

/* Tab Content */
.wheelfy-tab-content {
    display: none;
    margin-top: 20px;
}

.wheelfy-tab-content.active {
    display: block;
}

/* Dashboard Card */
.wheelfy-dashboard-card {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    margin-bottom: 20px;
}

.card-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    padding: 20px 24px;
    border-bottom: 1px solid #ddd;
    flex-wrap: wrap;
    gap: 16px;
}

.card-header h2 {
    margin: 0 0 4px 0;
    font-size: 18px;
    font-weight: 600;
    color: #1d2327;
}

.card-description {
    margin: 0;
    font-size: 13px;
    color: #646970;
}

.header-filters {
    display: flex;
    gap: 10px;
    align-items: center;
    flex-wrap: wrap;
}

.search-input {
    padding: 6px 12px;
    border: 1px solid #8c8f94;
    border-radius: 4px;
    font-size: 14px;
    min-width: 200px;
}

.filter-select {
    padding: 6px 12px;
    border: 1px solid #8c8f94;
    border-radius: 4px;
    font-size: 14px;
    min-width: 140px;
}

.card-body {
    padding: 24px;
}

/* Table Styles */
.table-view-list {
    margin: 0;
    border: none;
    width: 100%;
}

.card-body > .table-view-list {
    margin: -24px;
    width: calc(100% + 48px);
}

.table-view-list thead th {
    background: #f6f7f7;
    font-weight: 600;
    padding: 12px;
    border-bottom: 2px solid #ddd;
}

.table-view-list tbody td {
    padding: 12px;
    vertical-align: middle;
}

.table-view-list tbody tr:hover {
    background: #f9f9f9;
}

/* Status Badges */
.status-badge {
    display: inline-block;
    padding: 4px 12px;
    border-radius: 12px;
    font-size: 12px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.status-active {
    background: #e8f5e9;
    color: #388e3c;
}

.status-closed {
    background: #d1ecf1;
    color: #0c5460;
}

.status-dispute {
    background: #fff3cd;
    color: #856404;
}

.status-completed {
    background: #d4edda;
    color: #155724;
}

/* Format Badges */
.format-badge {
    padding: 4px 12px;
    border-radius: 12px;
    font-size: 12px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.format-badge.format-csv {
    background: #e8f5e9;
    color: #2e7d32;
}

.format-badge.format-pdf {
    background: #fff3e0;
    color: #e65100;
}

.format-badge.format-xlsx {
    background: #e3f2fd;
    color: #1976d2;
}

/* Badge Count */
.badge-count {
    display: inline-block;
    padding: 4px 10px;
    background: #e3f2fd;
    color: #1976d2;
    border-radius: 12px;
    font-weight: 600;
    font-size: 12px;
}

/* Insights Grid */
.insights-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 20px;
}

.insight-card {
    background: #f8f9fa;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 24px;
    display: flex;
    align-items: center;
    gap: 16px;
    transition: all 0.3s ease;
}

.insight-card:hover {
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    border-color: #2271b1;
}

.insight-icon {
    width: 48px;
    height: 48px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.insight-icon svg {
    width: 20px;
    height: 20px;
}

.insight-content {
    flex: 1;
}

.insight-content h3 {
    margin: 0 0 8px 0;
    font-size: 13px;
    color: #646970;
    font-weight: 600;
    text-transform: uppercase;
}

.insight-number {
    font-size: 32px;
    font-weight: 700;
    color: #1d2327;
    margin: 0;
    line-height: 1.2;
}

.insight-text {
    font-size: 18px;
    font-weight: 600;
    color: #1d2327;
    margin: 0;
}

.insight-label {
    font-size: 12px;
    color: #646970;
    margin: 4px 0 0 0;
}

/* Form Styles */
.report-form {
    max-width: 900px;
}

.form-grid {
    display: grid;
    gap: 24px;
}

.form-field {
    display: flex;
    flex-direction: column;
    gap: 8px;
}

.form-field label {
    font-weight: 600;
    color: #1d2327;
}

.form-field .required {
    color: #dc3232;
}

.form-field .description {
    margin: 0;
    font-size: 13px;
    color: #646970;
}

.date-range-inputs {
    display: flex;
    align-items: center;
    gap: 12px;
}

.date-range-inputs input {
    flex: 1;
}

.date-separator {
    color: #646970;
    font-weight: 600;
}

.format-options {
    display: flex;
    gap: 16px;
    flex-wrap: wrap;
}

.format-option {
    display: flex;
    align-items: center;
    padding: 12px 16px;
    border: 2px solid #ddd;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.2s ease;
}

.format-option:hover {
    border-color: #2271b1;
    background: #f0f6fc;
}

.format-option input[type="radio"] {
    margin-right: 12px;
}

.format-option input[type="radio"]:checked + .format-label {
    color: #2271b1;
}

.format-label {
    display: flex;
    flex-direction: column;
}

.format-label strong {
    font-size: 14px;
    font-weight: 600;
}

.format-label small {
    font-size: 12px;
    color: #646970;
}

.checkbox-options {
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.checkbox-option {
    display: flex;
    align-items: center;
    gap: 8px;
    cursor: pointer;
}

.checkbox-option input[type="checkbox"] {
    margin: 0;
}

.form-actions {
    display: flex;
    gap: 12px;
    margin-top: 24px;
    padding-top: 24px;
    border-top: 1px solid #ddd;
}

.form-actions .button {
    display: inline-flex;
    align-items: center;
    gap: 8px;
}

/* Row Actions */
.row-actions {
    display: flex !important;
    gap: 6px;
    flex-wrap: wrap;
    align-items: center;
    visibility: visible !important;
    opacity: 1 !important;
}

.row-actions .button {
    margin: 0;
    white-space: nowrap;
}

.row-actions .button-link-delete {
    color: #b32d2e;
    border-color: #b32d2e;
}

.row-actions .button-link-delete:hover {
    background: #b32d2e;
    color: #fff;
    border-color: #b32d2e;
}

.row-actions .button-link-delete:disabled {
    opacity: 0.6;
    cursor: not-allowed;
}

/* Hide WordPress Footer */
#wpfooter {
    display: none !important;
}

/* Responsive */
@media (max-width: 782px) {
    .wheelfy-admin-header {
        flex-direction: column;
        gap: 16px;
    }

    .header-filters {
        width: 100%;
    }

    .header-filters .search-input,
    .header-filters .filter-select {
        flex: 1;
        min-width: 0;
    }

    .wheelfy-kpi-grid {
        grid-template-columns: 1fr;
        padding-left: 0;
    }

    .insights-grid {
        grid-template-columns: 1fr;
    }

    .format-options {
        flex-direction: column;
    }

    .row-actions {
        flex-direction: column;
        align-items: flex-start;
    }

    .card-body .table-view-list {
        margin: -24px;
        width: calc(100% + 48px);
    }
}
</style>

<script>
jQuery(document).ready(function($) {
    // Hide WordPress admin footer
    $('#wpfooter').hide();
    $('p:contains("Thank you for creating")').hide();
    $('p:contains("Version")').hide();
    
    // Tab switching
    $('.wheelfy-subscription-tabs .nav-tab').on('click', function(e) {
        e.preventDefault();
        const tab = $(this).data('tab');
        
        // Update active tab
        $('.wheelfy-subscription-tabs .nav-tab').removeClass('nav-tab-active');
        $(this).addClass('nav-tab-active');
        
        // Show/hide tab content
        $('.wheelfy-tab-content').removeClass('active');
        $('#tab-' + tab).addClass('active');
        
        // Update URL without reload
        const url = new URL(window.location);
        url.searchParams.set('tab', tab);
        window.history.pushState({}, '', url);
    });
    
    // Search functionality
    $('#search-chat-reports, #search-partner-reports, #search-customer-reports').on('keyup', function() {
        const searchTerm = $(this).val().toLowerCase();
        const table = $(this).closest('.wheelfy-dashboard-card').find('table tbody');
        table.find('tr').each(function() {
            const text = $(this).text().toLowerCase();
            $(this).toggle(text.indexOf(searchTerm) > -1);
        });
    });
    
    // Filter by status - Now handled by form submission, so this JS is not needed
    
    // Filter report type (replaced with AJAX filtering)
    // See new implementation below
    
    // Export buttons - now redirect to export tab, so no JS handler needed
    
    // Preview button handler is in the second jQuery block (where modal functions are defined)
    
    // Action buttons - prevent default (but allow system report buttons)
    $(document).on('click', '.row-actions a', function(e) {
        // Allow system report buttons and CSV report buttons to work
        var $link = $(this);
        var href = $link.attr('href');
        if ($link.hasClass('wheelfy-download-system-report') || 
            $link.hasClass('wheelfy-view-system-report') ||
            (href && href !== '#' && !href.match(/^#/))) {
            return; // Don't prevent default for functional buttons
        }
        e.preventDefault();
        e.stopPropagation();
    });
    
    // Force actions visible
    function forceActionsVisible() {
        $('.row-actions').css({
            'display': 'flex !important',
            'visibility': 'visible !important',
            'opacity': '1 !important'
        });
    }
    
    // Use MutationObserver to ensure actions stay visible
    const observer = new MutationObserver(function(mutations) {
        forceActionsVisible();
    });
    
    $('.row-actions').each(function() {
        observer.observe(this, {
            attributes: true,
            attributeFilter: ['style', 'class']
        });
    });
    
    // Initial call
    forceActionsVisible();
    setTimeout(forceActionsVisible, 100);
    setTimeout(forceActionsVisible, 500);
    
    // ============================================
    // NEW SYSTEM REPORT FUNCTIONALITY
    // ============================================
    
    // Define ajaxurl if not defined (WordPress admin standard)
    if (typeof ajaxurl === 'undefined') {
        var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';
    }
    
    var currentReportType = '';
    var currentPage = 1;
    var currentPerPage = 20;
    var totalPages = 0;
    
    // Download System Report
    $(document).on('click', '.wheelfy-download-system-report', function(e) {
        e.preventDefault();
        var $btn = $(this);
        var reportType = $btn.data('report-type');
        var format = $btn.data('format') || 'csv';
        
        // Create form and submit
        var form = $('<form>', {
            method: 'POST',
            action: '<?php echo admin_url('admin-post.php'); ?>'
        });
        form.append($('<input>', {
            type: 'hidden',
            name: 'action',
            value: 'wheelfy_download_system_report'
        }));
        form.append($('<input>', {
            type: 'hidden',
            name: 'nonce',
            value: '<?php echo wp_create_nonce('wheelfy_download_system_report'); ?>'
        }));
        form.append($('<input>', {
            type: 'hidden',
            name: 'report_type',
            value: reportType
        }));
        form.append($('<input>', {
            type: 'hidden',
            name: 'format',
            value: format
        }));
        $('body').append(form);
        form.submit();
        form.remove();
    });
    
    // Delete Report
    $(document).on('click', '.wheelfy-delete-report', function(e) {
        e.preventDefault();
        var $btn = $(this);
        var reportId = $btn.data('report-id');
        var reportName = $btn.data('report-name');
        
        if (!confirm('<?php echo esc_js(__('Are you sure you want to delete this report?', 'wheelfy')); ?>\n\n' + reportName)) {
            return;
        }
        
        $btn.prop('disabled', true).text('<?php echo esc_js(__('Deleting...', 'wheelfy')); ?>');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'wheelfy_delete_report',
                nonce: '<?php echo wp_create_nonce('wheelfy_delete_report'); ?>',
                report_id: reportId
            },
            success: function(response) {
                if (response.success) {
                    $btn.closest('tr').fadeOut(300, function() {
                        $(this).remove();
                    });
                } else {
                    alert(response.data.message || '<?php echo esc_js(__('Error deleting report.', 'wheelfy')); ?>');
                    $btn.prop('disabled', false).text('<?php echo esc_js(__('Delete', 'wheelfy')); ?>');
                }
            },
            error: function() {
                alert('<?php echo esc_js(__('Error deleting report.', 'wheelfy')); ?>');
                $btn.prop('disabled', false).text('<?php echo esc_js(__('Delete', 'wheelfy')); ?>');
            }
        });
    });
    
    // View System Report
    $(document).on('click', '.wheelfy-view-system-report', function(e) {
        e.preventDefault();
        var $btn = $(this);
        currentReportType = $btn.data('report-type');
        currentPage = 1;
        
        $('#wheelfy-modal-title').text($btn.closest('tr').find('.column-type strong').text());
        $('#wheelfy-report-view-modal').show();
        loadReportData();
    });
    
    // Preview Report (from Export tab)
    $('#preview-report').on('click', function(e) {
        e.preventDefault();
        var reportType = $('#report_type').val();
        if (!reportType) {
            alert('<?php echo esc_js(__('Please select a report type first.', 'wheelfy')); ?>');
            return;
        }
        
        // Show modal with preview data
        $('#wheelfy-modal-title').text('<?php echo esc_js(__('Report Preview', 'wheelfy')); ?>');
        $('#wheelfy-report-view-modal').show();
        
        // Set current report type for preview
        currentReportType = reportType;
        currentPage = 1;
        loadReportData();
    });
    
    // Close Modal
    $(document).on('click', '.wheelfy-modal-close, .wheelfy-modal-overlay', function(e) {
        if (e.target === this) {
            $('#wheelfy-report-view-modal').hide();
        }
    });
    
    // Load Report Data
    function loadReportData() {
        $('#wheelfy-report-view-content').html('<p class="loading"><?php _e('Loading report data...', 'wheelfy'); ?></p>');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'wheelfy_view_system_report',
                nonce: '<?php echo wp_create_nonce('wheelfy_view_system_report'); ?>',
                report_type: currentReportType,
                page: currentPage,
                per_page: currentPerPage
            },
            success: function(response) {
                if (response.success) {
                    renderReportTable(response.data);
                    renderPagination(response.data);
                } else {
                    $('#wheelfy-report-view-content').html('<p class="error">' + (response.data.message || '<?php _e('Error loading report.', 'wheelfy'); ?>') + '</p>');
                }
            },
            error: function() {
                $('#wheelfy-report-view-content').html('<p class="error"><?php _e('Error loading report.', 'wheelfy'); ?></p>');
            }
        });
    }
    
    // Render Report Table
    function renderReportTable(data) {
        if (!data.headers || !data.data || data.data.length === 0) {
            $('#wheelfy-report-view-content').html('<p><?php _e('No data available.', 'wheelfy'); ?></p>');
            return;
        }
        
        var html = '<table class="wp-list-table widefat fixed striped"><thead><tr>';
        data.headers.forEach(function(header) {
            html += '<th>' + escapeHtml(header) + '</th>';
        });
        html += '</tr></thead><tbody>';
        
        data.data.forEach(function(row) {
            html += '<tr>';
            data.headers.forEach(function(header) {
                var value = row[header] !== undefined ? row[header] : '';
                html += '<td>' + escapeHtml(value) + '</td>';
            });
            html += '</tr>';
        });
        
        html += '</tbody></table>';
        $('#wheelfy-report-view-content').html(html);
        totalPages = data.total_pages;
    }
    
    // Render Pagination
    function renderPagination(data) {
        if (totalPages <= 1) {
            $('#wheelfy-report-pagination').html('');
            return;
        }
        
        var html = '';
        if (currentPage > 1) {
            html += '<button class="button" data-page="' + (currentPage - 1) + '"><?php _e('Previous', 'wheelfy'); ?></button>';
        }
        html += '<span class="page-info"><?php _e('Page', 'wheelfy'); ?> ' + currentPage + ' <?php _e('of', 'wheelfy'); ?> ' + totalPages + ' (<?php _e('Total', 'wheelfy'); ?>: ' + data.total + ')</span>';
        if (currentPage < totalPages) {
            html += '<button class="button" data-page="' + (currentPage + 1) + '"><?php _e('Next', 'wheelfy'); ?></button>';
        }
        $('#wheelfy-report-pagination').html(html);
    }
    
    // Pagination Click
    $(document).on('click', '#wheelfy-report-pagination button', function(e) {
        e.preventDefault();
        currentPage = parseInt($(this).data('page'));
        loadReportData();
    });
    
    // Filter Reports (AJAX) - Replace old filter
    $('#filter-report-type-overview').off('change').on('change', function() {
        var filterType = $(this).val();
        var $tableBody = $('#wheelfy-reports-table tbody');
        
        $tableBody.html('<tr><td colspan="8" style="text-align: center; padding: 20px;"><?php _e('Loading...', 'wheelfy'); ?></td></tr>');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'wheelfy_filter_reports',
                nonce: '<?php echo wp_create_nonce('wheelfy_filter_reports'); ?>',
                filter_type: filterType
            },
            success: function(response) {
                if (response.success && response.data.reports) {
                    renderFilteredReports(response.data.reports);
                } else {
                    $tableBody.html('<tr><td colspan="8" style="text-align: center; padding: 20px;"><?php _e('No reports found.', 'wheelfy'); ?></td></tr>');
                }
            },
            error: function() {
                $tableBody.html('<tr><td colspan="8" style="text-align: center; padding: 20px;"><?php _e('Error filtering reports.', 'wheelfy'); ?></td></tr>');
            }
        });
    });
    
    // Render Filtered Reports
    function renderFilteredReports(reports) {
        if (reports.length === 0) {
            $('#wheelfy-reports-table tbody').html('<tr><td colspan="8" style="text-align: center; padding: 40px;"><?php _e('No data available.', 'wheelfy'); ?></td></tr>');
            return;
        }
        
        var html = '';
        reports.forEach(function(report) {
            html += '<tr>';
            html += '<td class="column-id">' + escapeHtml(report.id) + '</td>';
            html += '<td class="column-type"><strong>' + escapeHtml(report.report_name) + '</strong></td>';
            html += '<td class="column-date-range">' + escapeHtml(report.date_range) + '</td>';
            html += '<td class="column-format"><span class="format-badge format-' + report.file_format.toLowerCase() + '">' + report.file_format.toUpperCase() + '</span></td>';
            html += '<td class="column-generated">' + escapeHtml(report.generated_date) + '</td>';
            html += '<td class="column-size">' + escapeHtml(report.file_size) + '</td>';
            html += '<td class="column-status"><span class="status-badge status-' + report.status.replace('_', '-') + '">' + escapeHtml(report.status.replace('_', ' ').replace(/\b\w/g, function(l) { return l.toUpperCase(); })) + '</span></td>';
            html += '<td class="column-actions"><div class="row-actions">';
            
            if (report.is_system) {
                html += '<a href="#" class="button button-small wheelfy-download-system-report" data-report-type="' + escapeHtml(report.report_type) + '" data-format="csv"><?php _e('Download', 'wheelfy'); ?></a>';
            } else {
                html += '<a href="<?php echo admin_url('admin.php?page=wheelfy-reports&action=download&report_id='); ?>' + report.id + '&nonce=<?php echo wp_create_nonce('wheelfy_download_report_'); ?>' + report.id + '" class="button button-small"><?php _e('Download', 'wheelfy'); ?></a> ';
                html += '<button type="button" class="button button-small button-link-delete wheelfy-delete-report" data-report-id="' + report.id + '" data-report-name="' + escapeHtml(report.report_name) + '"><?php _e('Delete', 'wheelfy'); ?></button>';
            }
            
            html += '</div></td>';
            html += '</tr>';
        });
        
        $('#wheelfy-reports-table tbody').html(html);
    }
    
    // Escape HTML
    function escapeHtml(text) {
        if (text === null || text === undefined) return '';
        var map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        return String(text).replace(/[&<>"']/g, function(m) { return map[m]; });
    }
});
</script>

<style>
.wheelfy-modal {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    z-index: 100000;
}
.wheelfy-modal-overlay {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.7);
}
.wheelfy-modal-content {
    position: relative;
    background: #fff;
    margin: 50px auto;
    max-width: 90%;
    max-height: 90%;
    display: flex;
    flex-direction: column;
    border-radius: 4px;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
}
.wheelfy-modal-header {
    padding: 20px;
    border-bottom: 1px solid #ddd;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.wheelfy-modal-header h2 {
    margin: 0;
}
.wheelfy-modal-close {
    background: none;
    border: none;
    font-size: 28px;
    cursor: pointer;
    color: #666;
    padding: 0;
    width: 30px;
    height: 30px;
    line-height: 1;
}
.wheelfy-modal-close:hover {
    color: #000;
}
.wheelfy-modal-body {
    padding: 20px;
    overflow-y: auto;
    flex: 1;
}
.wheelfy-modal-footer {
    padding: 15px 20px;
    border-top: 1px solid #ddd;
    background: #f9f9f9;
}
#wheelfy-report-view-content table {
    width: 100%;
    border-collapse: collapse;
}
#wheelfy-report-view-content table th,
#wheelfy-report-view-content table td {
    padding: 10px;
    text-align: left;
    border: 1px solid #ddd;
}
#wheelfy-report-view-content table th {
    background: #f5f5f5;
    font-weight: 600;
}
#wheelfy-report-pagination {
    display: flex;
    justify-content: center;
    gap: 10px;
    align-items: center;
}
#wheelfy-report-pagination button {
    padding: 5px 10px;
}
#wheelfy-report-pagination .page-info {
    margin: 0 10px;
}
</style>
