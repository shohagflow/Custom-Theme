<?php
/**
 * Admin Users Management Page
 * 
 * @package Wheelfy
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!current_user_can('administrator')) {
    wp_die(__('You do not have permission to access this page.', 'wheelfy'));
}

require_once get_template_directory() . '/admin/admin-functions.php';

// Handle actions - MUST be before any output
if (isset($_GET['action']) && isset($_GET['user_id']) && isset($_GET['_wpnonce'])) {
    // Verify nonce
    if (!wp_verify_nonce($_GET['_wpnonce'], 'wheelfy_user_action')) {
        wp_die(__('Security check failed.', 'wheelfy'));
    }
    
    $user_id = intval($_GET['user_id']);
    $action = sanitize_text_field($_GET['action']);
    $current_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'customers';
    $redirect_url = admin_url('admin.php?page=wheelfy-users&tab=' . $current_tab);
    
    // Clear any output buffers
    while (ob_get_level()) {
        ob_end_clean();
    }
    
    switch ($action) {
        case 'approve':
            wheelfy_update_user_status($user_id, 'active');
            $redirect_url = add_query_arg('approved', '1', $redirect_url);
            wp_safe_redirect($redirect_url);
            exit;
            
        case 'suspend':
            wheelfy_update_user_status($user_id, 'suspended');
            $redirect_url = add_query_arg('suspended', '1', $redirect_url);
            wp_safe_redirect($redirect_url);
            exit;
            
        case 'reject':
            wheelfy_update_user_status($user_id, 'rejected');
            $redirect_url = add_query_arg('rejected', '1', $redirect_url);
            wp_safe_redirect($redirect_url);
            exit;
            
        case 'delete':
            if (isset($_GET['confirm']) && $_GET['confirm'] === 'yes') {
                wp_delete_user($user_id);
                $redirect_url = add_query_arg('deleted', '1', $redirect_url);
                wp_safe_redirect($redirect_url);
                exit;
            }
            break;
            
        case 'toggle-verification':
            $current_verified = get_user_meta($user_id, 'partner_verified', true);
            update_user_meta($user_id, 'partner_verified', $current_verified ? false : true);
            $redirect_url = add_query_arg('verification_updated', '1', $redirect_url);
            wp_safe_redirect($redirect_url);
            exit;
            break;
            
        case 'view-profile':
            // Don't redirect - show profile in modal
            // This will be handled by JavaScript
            break;
    }
}

// Show success messages using admin_notices hook
add_action('admin_notices', function() {
    if (isset($_GET['approved']) && $_GET['approved'] === '1') {
        echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__('User approved successfully.', 'wheelfy') . '</p></div>';
    }
    
    if (isset($_GET['suspended']) && $_GET['suspended'] === '1') {
        echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__('User suspended successfully.', 'wheelfy') . '</p></div>';
    }
    
    if (isset($_GET['deleted']) && $_GET['deleted'] === '1') {
        echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__('User deleted successfully.', 'wheelfy') . '</p></div>';
    }
    
    if (isset($_GET['rejected']) && $_GET['rejected'] === '1') {
        echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__('User rejected successfully.', 'wheelfy') . '</p></div>';
    }
    
    if (isset($_GET['verification_updated']) && $_GET['verification_updated'] === '1') {
        echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__('Partner verification status updated.', 'wheelfy') . '</p></div>';
    }
});

// Get current tab
$current_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'customers';
$paged = isset($_GET['paged']) ? intval($_GET['paged']) : 1;
$partner_type_filter = isset($_GET['partner_type']) ? sanitize_text_field($_GET['partner_type']) : '';

// Get total counts dynamically for BOTH tabs (always calculate both)
// Customers count
$customers_count_query = new WP_User_Query(array(
    'meta_key' => 'user_type',
    'meta_value' => 'customer',
    'role__not_in' => array('administrator'),
    'count_total' => true,
));
$total_customers = $customers_count_query->get_total();

// Partners count
$partners_count_query = new WP_User_Query(array(
    'meta_key' => 'user_type',
    'meta_value' => 'partner',
    'role__not_in' => array('administrator'),
    'count_total' => true,
));
$total_partners = $partners_count_query->get_total();

// Get users for current tab - Exclude administrators, only show customers and partners
if ($current_tab === 'customers') {
    // Get all users with customer user_type, EXCLUDE administrators
    $users_query = new WP_User_Query(array(
        'meta_key' => 'user_type',
        'meta_value' => 'customer',
        'role__not_in' => array('administrator'), // Exclude administrators
        'number' => 20,
        'paged' => $paged,
        'count_total' => true,
    ));
    $users = $users_query->get_results();
    
    // Additional filter: Remove any administrators that might have customer user_type
    $users = array_filter($users, function($user) {
        return !in_array('administrator', $user->roles);
    });
} else {
    // Get all users with partner user_type, EXCLUDE administrators
    $partner_query_args = array(
        'meta_key' => 'user_type',
        'meta_value' => 'partner',
        'role__not_in' => array('administrator'), // Exclude administrators
        'number' => 20,
        'paged' => $paged,
        'count_total' => true,
    );
    
    // Add partner type filter if selected
    if (!empty($partner_type_filter) && in_array($partner_type_filter, array('repair_shop', 'car_dealership'))) {
        $partner_query_args['meta_query'] = array(
            'relation' => 'AND',
            array(
                'key' => 'user_type',
                'value' => 'partner',
                'compare' => '='
            ),
            array(
                'key' => 'partner_type',
                'value' => $partner_type_filter,
                'compare' => '='
            )
        );
        unset($partner_query_args['meta_key']);
        unset($partner_query_args['meta_value']);
    }
    
    $users_query = new WP_User_Query($partner_query_args);
    $users = $users_query->get_results();
    
    // Additional filter: Remove any administrators that might have partner user_type
    $users = array_filter($users, function($user) {
        return !in_array('administrator', $user->roles);
    });
}
?>
<div class="wrap wheelfy-admin-users">
    <!-- Header -->
    <div class="wheelfy-admin-header">
        <div>
            <h1 class="wp-heading-inline"><?php _e('User Management', 'wheelfy'); ?></h1>
            <p class="description"><?php _e('Manage customers and partners, approve registrations, and control user access', 'wheelfy'); ?></p>
        </div>
    </div>
    <hr class="wp-header-end">

    <!-- KPI Cards -->
    <div class="wheelfy-kpi-grid">
        <div class="wheelfy-kpi-card">
            <div class="kpi-icon" style="background: #e3f2fd; color: #1976d2;">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                    <circle cx="9" cy="7" r="4"></circle>
                    <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                    <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                </svg>
            </div>
            <div class="kpi-content">
                <div class="kpi-label"><?php _e('Total Customers', 'wheelfy'); ?></div>
                <div class="kpi-value"><?php echo number_format($total_customers); ?></div>
            </div>
        </div>

        <div class="wheelfy-kpi-card">
            <div class="kpi-icon" style="background: #e8f5e9; color: #388e3c;">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                    <circle cx="8.5" cy="7" r="4"></circle>
                    <path d="M20 8v6"></path>
                    <path d="M23 11h-6"></path>
                </svg>
            </div>
            <div class="kpi-content">
                <div class="kpi-label"><?php _e('Total Partners', 'wheelfy'); ?></div>
                <div class="kpi-value"><?php echo number_format($total_partners); ?></div>
            </div>
        </div>

        <div class="wheelfy-kpi-card">
            <div class="kpi-icon" style="background: #fff3e0; color: #f57c00;">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="12" cy="12" r="10"></circle>
                    <path d="M12 6v6l4 2"></path>
                </svg>
            </div>
            <div class="kpi-content">
                <div class="kpi-label"><?php _e('Pending Users', 'wheelfy'); ?></div>
                <div class="kpi-value">
                    <?php
                    $pending_query = new WP_User_Query(array(
                        'meta_key' => 'user_status',
                        'meta_value' => 'pending',
                        'role__not_in' => array('administrator'),
                        'count_total' => true,
                    ));
                    echo number_format($pending_query->get_total());
                    ?>
                </div>
            </div>
        </div>

        <div class="wheelfy-kpi-card">
            <div class="kpi-icon" style="background: #e8f5e9; color: #388e3c;">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                    <polyline points="22 4 12 14.01 9 11.01"></polyline>
                </svg>
            </div>
            <div class="kpi-content">
                <div class="kpi-label"><?php _e('Active Users', 'wheelfy'); ?></div>
                <div class="kpi-value">
                    <?php
                    $active_query = new WP_User_Query(array(
                        'meta_key' => 'user_status',
                        'meta_value' => 'active',
                        'role__not_in' => array('administrator'),
                        'count_total' => true,
                    ));
                    echo number_format($active_query->get_total());
                    ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Tabs with Dynamic Count -->
    <nav class="nav-tab-wrapper wheelfy-subscription-tabs">
        <a href="<?php echo admin_url('admin.php?page=wheelfy-users&tab=customers'); ?>" 
           class="nav-tab <?php echo $current_tab === 'customers' ? 'nav-tab-active' : ''; ?>"
           data-tab="customers">
            <?php _e('Customers', 'wheelfy'); ?> 
            <span class="count">(<?php echo isset($total_customers) ? $total_customers : 0; ?>)</span>
        </a>
        <a href="<?php echo admin_url('admin.php?page=wheelfy-users&tab=partners'); ?>" 
           class="nav-tab <?php echo $current_tab === 'partners' ? 'nav-tab-active' : ''; ?>"
           data-tab="partners">
            <?php _e('Partners', 'wheelfy'); ?> 
            <span class="count">(<?php echo isset($total_partners) ? $total_partners : 0; ?>)</span>
        </a>
    </nav>

    <!-- Users Table -->
    <div class="wheelfy-dashboard-card">
        <div class="card-header">
            <div>
                <h2><?php echo $current_tab === 'customers' ? __('Customers', 'wheelfy') : __('Partners', 'wheelfy'); ?></h2>
                <p class="card-description"><?php echo $current_tab === 'customers' ? __('Manage customer accounts and access', 'wheelfy') : __('Manage partner accounts, verification, and access', 'wheelfy'); ?></p>
            </div>
            <div class="header-filters">
                <?php if ($current_tab === 'partners') : ?>
                    <select id="filter-partner-type" class="search-input" style="margin-right: 10px; min-width: 180px;">
                        <option value=""><?php _e('All Partner Types', 'wheelfy'); ?></option>
                        <option value="repair_shop" <?php selected($partner_type_filter, 'repair_shop'); ?>><?php _e('Repair Shop', 'wheelfy'); ?></option>
                        <option value="car_dealership" <?php selected($partner_type_filter, 'car_dealership'); ?>><?php _e('Car Dealership', 'wheelfy'); ?></option>
                    </select>
                    <script>
                    document.addEventListener('DOMContentLoaded', function() {
                        var partnerTypeFilter = document.getElementById('filter-partner-type');
                        if (partnerTypeFilter) {
                            partnerTypeFilter.addEventListener('change', function() {
                                var url = new URL(window.location.href);
                                if (this.value) {
                                    url.searchParams.set('partner_type', this.value);
                                } else {
                                    url.searchParams.delete('partner_type');
                                }
                                window.location.href = url.toString();
                            });
                        }
                    });
                    </script>
                <?php endif; ?>
                <input type="text" id="search-users" class="search-input" placeholder="<?php esc_attr_e('Search users...', 'wheelfy'); ?>">
            </div>
        </div>
        <div class="card-body">
            <table class="wp-list-table widefat fixed striped table-view-list">
        <thead>
            <tr>
                <th><?php _e('#', 'wheelfy'); ?></th>
                <th><?php _e('Username', 'wheelfy'); ?></th>
                <th><?php _e('Name', 'wheelfy'); ?></th>
                <th><?php _e('Email', 'wheelfy'); ?></th>
                <?php if ($current_tab === 'partners') : ?>
                    <th><?php _e('Partner Type', 'wheelfy'); ?></th>
                <?php endif; ?>
                <th><?php _e('Status', 'wheelfy'); ?></th>
                <th><?php _e('Registered', 'wheelfy'); ?></th>
                <th><?php _e('Actions', 'wheelfy'); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($users)) : ?>
                <?php 
                $count = 0;
                foreach ($users as $user) : 
                    // CRITICAL: Skip administrators - they should not appear in customer/partner lists
                    if (in_array('administrator', $user->roles)) {
                        continue;
                    }
                    
                    $count++;
                    $status = wheelfy_get_user_status($user->ID);
                    $is_verified = get_user_meta($user->ID, 'partner_verified', true);
                ?>
                    <tr>
                        <td><?php echo $count; ?></td>
                        <td>
                            <?php
                            // If user has a custom profile image, show it before the username
                            $profile_image_id = get_user_meta($user->ID, 'profile_image_id', true);
                            // Prefer custom profile image; fallback to WordPress avatar
                            $avatar_url = '';
                            if ($profile_image_id && is_numeric($profile_image_id)) {
                                $avatar_url = wp_get_attachment_image_url($profile_image_id, 'thumbnail');
                            }
                            if (empty($avatar_url)) {
                                $avatar_url = get_avatar_url($user->ID, array('size' => 40));
                            }
                            if (!empty($avatar_url)) {
                                echo '<img src="' . esc_url($avatar_url) . '" alt="' . esc_attr($user->display_name ?: $user->user_login) . '" style="width:40px;height:40px;border-radius:50%;object-fit:cover;margin-right:8px;vertical-align:middle;">';
                            }
                            ?>
                            <strong><?php echo esc_html($user->user_login); ?></strong>
                            <?php if ($current_tab === 'partners' && $is_verified) : ?>
                                <span class="dashicons dashicons-yes-alt" style="color: #46b450;" title="<?php _e('Verified Partner', 'wheelfy'); ?>"></span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php
                            // Get user's display name or full name
                            $user_display_name = $user->display_name;
                            
                            // If display_name is empty or same as username, try to get first_name and last_name
                            if (empty($user_display_name) || $user_display_name === $user->user_login) {
                                $first_name = get_user_meta($user->ID, 'first_name', true);
                                $last_name = get_user_meta($user->ID, 'last_name', true);
                                
                                if (!empty($first_name) || !empty($last_name)) {
                                    $user_display_name = trim($first_name . ' ' . $last_name);
                                } else {
                                    // If no first_name or last_name, and display_name is same as username, show empty
                                    $user_display_name = '';
                                }
                            }
                            
                            // Only show name if it's set and different from username
                            if (!empty($user_display_name) && $user_display_name !== $user->user_login) {
                                echo esc_html($user_display_name);
                            } else {
                                // Show empty (dash) if no name is set
                                echo '<span style="color: #999;">—</span>';
                            }
                            ?>
                        </td>
                        <td><?php echo esc_html($user->user_email); ?></td>
                        <?php if ($current_tab === 'partners') : ?>
                            <td>
                                <?php
                                $partner_type = get_user_meta($user->ID, 'partner_type', true);
                                if ($partner_type === 'repair_shop') {
                                    echo '<span style="padding: 4px 12px; background: #e3f2fd; color: #1976d2; border-radius: 4px; font-size: 12px; font-weight: 500;">' . __('Repair Shop', 'wheelfy') . '</span>';
                                } elseif ($partner_type === 'car_dealership') {
                                    echo '<span style="padding: 4px 12px; background: #fff3e0; color: #f57c00; border-radius: 4px; font-size: 12px; font-weight: 500;">' . __('Car Dealership', 'wheelfy') . '</span>';
                                } else {
                                    echo '<span style="color: #999;">—</span>';
                                }
                                ?>
                            </td>
                        <?php endif; ?>
                        <td>
                            <span class="status-badge status-<?php echo esc_attr($status); ?>" data-user-id="<?php echo $user->ID; ?>">
                                <?php echo esc_html(ucfirst($status)); ?>
                            </span>
                        </td>
                        <td><?php echo date_i18n(get_option('date_format'), strtotime($user->user_registered)); ?></td>
                        <td>
                            <div class="row-actions" data-user-id="<?php echo $user->ID; ?>" data-user-status="<?php echo esc_attr($status); ?>">
                                <a href="javascript:void(0);" 
                                   class="button button-small view-profile-btn" 
                                   data-user-id="<?php echo $user->ID; ?>"
                                   data-nonce="<?php echo wp_create_nonce('wheelfy_view_profile_' . $user->ID); ?>">
                                    <?php _e('View Profile', 'wheelfy'); ?>
                                </a>
                                
                                <?php if ($status === 'pending') : ?>
                                    <a href="javascript:void(0);" 
                                       class="button button-small user-action-btn" 
                                       data-action="approve"
                                       data-user-id="<?php echo $user->ID; ?>"
                                       data-nonce="<?php echo wp_create_nonce('wheelfy_user_action_' . $user->ID); ?>"
                                       data-tab="<?php echo $current_tab; ?>">
                                        <?php _e('Approve', 'wheelfy'); ?>
                                    </a>
                                    <a href="javascript:void(0);" 
                                       class="button button-small user-action-btn" 
                                       data-action="reject"
                                       data-user-id="<?php echo $user->ID; ?>"
                                       data-nonce="<?php echo wp_create_nonce('wheelfy_user_action_' . $user->ID); ?>"
                                       data-tab="<?php echo $current_tab; ?>"
                                       data-confirm="<?php echo esc_js(__('Are you sure you want to reject this user?', 'wheelfy')); ?>">
                                        <?php _e('Reject', 'wheelfy'); ?>
                                    </a>
                                <?php elseif ($status === 'active') : ?>
                                    <a href="javascript:void(0);" 
                                       class="button button-small user-action-btn" 
                                       data-action="suspend"
                                       data-user-id="<?php echo $user->ID; ?>"
                                       data-nonce="<?php echo wp_create_nonce('wheelfy_user_action_' . $user->ID); ?>"
                                       data-tab="<?php echo $current_tab; ?>">
                                        <?php _e('Suspend', 'wheelfy'); ?>
                                    </a>
                                <?php elseif ($status === 'suspended') : ?>
                                    <a href="javascript:void(0);" 
                                       class="button button-small user-action-btn" 
                                       data-action="activate"
                                       data-user-id="<?php echo $user->ID; ?>"
                                       data-nonce="<?php echo wp_create_nonce('wheelfy_user_action_' . $user->ID); ?>"
                                       data-tab="<?php echo $current_tab; ?>">
                                        <?php _e('Activate', 'wheelfy'); ?>
                                    </a>
                                <?php endif; ?>
                                
                                <?php if ($current_tab === 'partners') : ?>
                                    <a href="javascript:void(0);" 
                                       class="button button-small partner-action-btn"
                                       data-action="toggle-verification"
                                       data-user-id="<?php echo $user->ID; ?>"
                                       data-nonce="<?php echo wp_create_nonce('wheelfy_user_action_' . $user->ID); ?>"
                                       data-tab="<?php echo $current_tab; ?>"
                                       data-verified="<?php echo $is_verified ? '1' : '0'; ?>">
                                        <?php echo $is_verified ? __('Unverify', 'wheelfy') : __('Verify', 'wheelfy'); ?>
                                    </a>
                                    <a href="<?php echo esc_url(add_query_arg('user_id', $user->ID, home_url('/partner-dashboard'))); ?>" 
                                       class="button button-small"
                                       target="_blank"
                                       title="<?php echo esc_attr(sprintf(__('View %s\'s Dashboard', 'wheelfy'), $user->display_name ? $user->display_name : $user->user_login)); ?>">
                                        <?php _e('Edit', 'wheelfy'); ?>
                                    </a>
                                <?php endif; ?>
                                
                                <a href="javascript:void(0);" 
                                   class="button button-small button-link-delete user-action-btn" 
                                   data-action="delete"
                                   data-user-id="<?php echo $user->ID; ?>"
                                   data-nonce="<?php echo wp_create_nonce('wheelfy_user_action_' . $user->ID); ?>"
                                   data-tab="<?php echo $current_tab; ?>"
                                   data-confirm="<?php echo esc_js(__('Are you sure you want to delete this user? This action cannot be undone.', 'wheelfy')); ?>">
                                    <?php _e('Delete', 'wheelfy'); ?>
                                </a>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else : ?>
                <tr>
                    <td colspan="7"><?php _e('No users found.', 'wheelfy'); ?></td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
        </div>
    </div>
</div>

<style>
/* Admin Users Page Styles */
.wheelfy-admin-users {
    margin: 20px 0 0 0;
}

.wheelfy-admin-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 20px;
}

.wheelfy-admin-header h1 {
    margin: 0 0 8px 0;
    font-size: 23px;
    font-weight: 400;
}

.wheelfy-admin-header .description {
    margin: 0;
    color: #646970;
    font-size: 14px;
}

/* KPI Cards */
.wheelfy-kpi-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
    margin: 20px 0;
    padding-left: 20px;
}

.wheelfy-kpi-card {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 20px;
    display: flex;
    align-items: center;
    gap: 16px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    transition: all 0.3s ease;
}

.wheelfy-kpi-card:hover {
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    border-color: #2271b1;
}

.kpi-icon {
    width: 48px;
    height: 48px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.kpi-icon svg {
    display: block;
    margin: 0 auto;
    width: 24px;
    height: 24px;
}

.kpi-content {
    flex: 1;
}

.kpi-label {
    font-size: 13px;
    color: #646970;
    margin-bottom: 4px;
}

.kpi-value {
    font-size: 28px;
    font-weight: 600;
    color: #1d2327;
    line-height: 1.2;
}

/* Tabs */
.nav-tab-wrapper {
    margin: 20px 0 0 0;
    border-bottom: 1px solid #ccc;
}

.nav-tab-wrapper .nav-tab {
    margin-bottom: -1px;
    padding: 10px 15px;
    font-size: 14px;
    text-decoration: none;
    border: 1px solid transparent;
    border-bottom: none;
    background: transparent;
    color: #50575e;
    cursor: pointer;
    transition: all 0.2s ease;
}

.nav-tab-wrapper .nav-tab:hover {
    color: #2271b1;
    background: #f6f7f7;
}

.nav-tab-wrapper .nav-tab.nav-tab-active {
    color: #2271b1;
    background: #fff;
    border-color: #ccc;
    border-bottom-color: #fff;
}

.nav-tab-wrapper .nav-tab .count {
    font-weight: 600;
    color: #646970;
}

/* Dashboard Card */
.wheelfy-dashboard-card {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    margin-top: 20px;
    margin-bottom: 20px;
}

.card-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    padding: 20px 24px;
    border-bottom: 1px solid #ddd;
    flex-wrap: wrap;
    gap: 16px;
}

.card-header h2 {
    margin: 0 0 4px 0;
    font-size: 18px;
    font-weight: 600;
    color: #1d2327;
}

.card-description {
    margin: 0;
    font-size: 13px;
    color: #646970;
}

.header-filters {
    display: flex;
    gap: 10px;
    align-items: center;
    flex-wrap: wrap;
}

.search-input {
    padding: 6px 12px;
    border: 1px solid #8c8f94;
    border-radius: 4px;
    font-size: 14px;
    min-width: 200px;
}

.card-body {
    padding: 24px;
}

/* Table Styles */
.table-view-list {
    margin: 0;
    border: none;
    width: 100%;
}

.card-body > .table-view-list {
    margin: -24px;
    width: calc(100% + 48px);
}

.table-view-list thead th {
    background: #f6f7f7;
    font-weight: 600;
    padding: 12px;
    border-bottom: 2px solid #ddd;
}

.table-view-list tbody td {
    padding: 12px;
    vertical-align: middle;
}

.table-view-list tbody tr:hover {
    background: #f9f9f9;
}

/* Reduce gap between first (#) and second (Username) columns to 5px */
.table-view-list thead th:first-child,
.table-view-list tbody td:first-child {
    width: 20px;
    min-width: 20px;
    padding-right: 5px;
}
.table-view-list thead th:nth-child(2),
.table-view-list tbody td:nth-child(2) {
    padding-left: 5px;
}

.wheelfy-admin-users .status-badge {
    padding: 4px 8px;
    border-radius: 4px;
    font-size: 12px;
    font-weight: 600;
    text-transform: uppercase;
}

.status-badge.status-active {
    background: #d4edda;
    color: #155724;
}

.status-badge.status-pending {
    background: #fff3cd;
    color: #856404;
}

.status-badge.status-suspended {
    background: #f8d7da;
    color: #721c24;
}

.status-badge.status-rejected {
    background: #ffebee;
    color: #c62828;
}

/* Row Actions */
.row-actions {
    display: flex !important;
    gap: 6px;
    flex-wrap: wrap;
    align-items: center;
    visibility: visible !important;
    opacity: 1 !important;
}

.row-actions .button {
    margin: 0;
    white-space: nowrap;
}

/* Hide WordPress Footer */
#wpfooter {
    display: none !important;
}

/* Responsive */
@media (max-width: 782px) {
    .wheelfy-admin-header {
        flex-direction: column;
        gap: 16px;
    }

    .header-filters {
        width: 100%;
    }

    .header-filters .search-input {
        flex: 1;
        min-width: 0;
    }

    .wheelfy-kpi-grid {
        grid-template-columns: 1fr;
        padding-left: 0;
    }

    .row-actions {
        flex-direction: column;
        align-items: flex-start;
    }

    .card-body .table-view-list {
        margin: -24px;
        width: calc(100% + 48px);
    }
}

/* Profile Modal Styles */
.wheelfy-profile-modal {
    display: none;
    position: fixed;
    z-index: 100000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    overflow: auto;
    background-color: rgba(0, 0, 0, 0.5);
}

.wheelfy-profile-modal.active {
    display: flex;
    align-items: center;
    justify-content: center;
}

.wheelfy-profile-modal-content {
    background-color: #fff;
    margin: auto;
    padding: 0;
    border: 1px solid #ddd;
    width: 90%;
    max-width: 600px;
    border-radius: 8px;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
    max-height: 90vh;
    overflow-y: auto;
}

.wheelfy-profile-modal-header {
    padding: 20px 24px;
    border-bottom: 1px solid #ddd;
    display: flex;
    justify-content: space-between;
    align-items: center;
    background: #f8f9fa;
    border-radius: 8px 8px 0 0;
}

.wheelfy-profile-modal-header h2 {
    margin: 0;
    font-size: 20px;
    font-weight: 600;
    color: #23282d;
}

.wheelfy-profile-modal-close {
    color: #666;
    font-size: 28px;
    font-weight: bold;
    cursor: pointer;
    line-height: 1;
    background: none;
    border: none;
    padding: 0;
    width: 30px;
    height: 30px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.wheelfy-profile-modal-close:hover {
    color: #000;
}

.wheelfy-profile-modal-body {
    padding: 24px;
}

.wheelfy-profile-image-section {
    text-align: center;
    margin-bottom: 24px;
    padding-bottom: 24px;
    border-bottom: 1px solid #eee;
}

.wheelfy-profile-image {
    width: 120px;
    height: 120px;
    border-radius: 50%;
    object-fit: cover;
    border: 4px solid #f0f0f0;
    margin: 0 auto 16px;
    display: block;
}

.wheelfy-profile-initials {
    width: 120px;
    height: 120px;
    border-radius: 50%;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: #fff;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 48px;
    font-weight: 600;
    margin: 0 auto 16px;
}

.wheelfy-profile-name {
    font-size: 24px;
    font-weight: 600;
    color: #23282d;
    margin: 0 0 8px;
}

.wheelfy-profile-email {
    font-size: 16px;
    color: #666;
    margin: 0;
}

.wheelfy-profile-info-section {
    margin-bottom: 24px;
}

.wheelfy-profile-info-section h3 {
    font-size: 16px;
    font-weight: 600;
    color: #23282d;
    margin: 0 0 12px;
    padding-bottom: 8px;
    border-bottom: 2px solid #f0f0f0;
}

.wheelfy-profile-info-item {
    display: flex;
    margin-bottom: 12px;
    align-items: flex-start;
}

.wheelfy-profile-info-label {
    font-weight: 600;
    color: #555;
    min-width: 120px;
    margin-right: 12px;
}

.wheelfy-profile-info-value {
    color: #23282d;
    flex: 1;
}

.wheelfy-profile-bio {
    background: #f8f9fa;
    padding: 16px;
    border-radius: 6px;
    color: #23282d;
    line-height: 1.6;
    margin-top: 8px;
    white-space: pre-wrap;
}

.wheelfy-profile-bio.empty {
    color: #999;
    font-style: italic;
}

.wheelfy-profile-loading {
    text-align: center;
    padding: 40px;
    color: #666;
}

.wheelfy-profile-error {
    text-align: center;
    padding: 40px;
    color: #d63638;
}
</style>

<!-- Profile Modal -->
<div id="wheelfyProfileModal" class="wheelfy-profile-modal">
    <div class="wheelfy-profile-modal-content">
        <div class="wheelfy-profile-modal-header">
            <h2><?php _e('User Profile', 'wheelfy'); ?></h2>
            <button class="wheelfy-profile-modal-close">&times;</button>
        </div>
        <div class="wheelfy-profile-modal-body" id="wheelfyProfileModalBody">
            <div class="wheelfy-profile-loading"><?php _e('Loading profile...', 'wheelfy'); ?></div>
        </div>
    </div>
</div>


<script>
jQuery(document).ready(function($) {
    // Hide WordPress admin footer
    $('#wpfooter').hide();
    $('p:contains("Thank you for creating")').hide();
    $('p:contains("Version")').hide();
    
    // Search functionality with autocomplete/suggestions
    let searchTimeout;
    const $searchInput = $('#search-users');
    const $searchWrapper = $searchInput.parent();
    
    // Create suggestions dropdown
    if ($('#search-suggestions').length === 0) {
        $searchWrapper.css('position', 'relative');
        $searchWrapper.append('<div id="search-suggestions" style="display:none;position:absolute;top:100%;left:0;right:0;background:#fff;border:1px solid #8c8f94;border-top:none;border-radius:0 0 4px 4px;max-height:300px;overflow-y:auto;z-index:1000;box-shadow:0 2px 8px rgba(0,0,0,0.1);"></div>');
    }
    
    const $suggestions = $('#search-suggestions');
    
    $searchInput.on('keyup', function(e) {
        clearTimeout(searchTimeout);
        const searchTerm = $(this).val().trim();
        
        // Clear suggestions if less than 2 characters
        if (searchTerm.length < 2) {
            $suggestions.hide().empty();
            // Show all rows
            $('.table-view-list tbody tr').show();
            return;
        }
        
        searchTimeout = setTimeout(function() {
            const searchLower = searchTerm.toLowerCase();
            const table = $('.table-view-list tbody');
            const matches = [];
            
            table.find('tr').each(function() {
                const $row = $(this);
                const username = $row.find('td:nth-child(2) strong').text().toLowerCase();
                const name = $row.find('td:nth-child(3)').text().toLowerCase();
                const email = $row.find('td:nth-child(4)').text().toLowerCase();
                const fullText = (username + ' ' + name + ' ' + email).toLowerCase();
                
                if (fullText.indexOf(searchLower) > -1) {
                    $row.show();
                    matches.push({
                        username: $row.find('td:nth-child(2) strong').text(),
                        name: $row.find('td:nth-child(3)').text(),
                        email: $row.find('td:nth-child(4)').text(),
                        row: $row
                    });
                } else {
                    $row.hide();
                }
            });
            
            // Show suggestions
            if (matches.length > 0 && matches.length <= 10) {
                $suggestions.empty();
                matches.forEach(function(match) {
                    const $suggestion = $('<div class="search-suggestion-item" style="padding:8px 12px;cursor:pointer;border-bottom:1px solid #f0f0f0;"></div>');
                    $suggestion.html('<strong>' + match.username + '</strong><br><small style="color:#666;">' + match.name + ' - ' + match.email + '</small>');
                    
                    $suggestion.on('mouseenter', function() {
                        $(this).css('background', '#f6f7f7');
                    }).on('mouseleave', function() {
                        $(this).css('background', '#fff');
                    });
                    
                    $suggestion.on('click', function() {
                        $searchInput.val(match.username);
                        $suggestions.hide();
                        // Show only this row
                        table.find('tr').hide();
                        match.row.show();
                    });
                    
                    $suggestions.append($suggestion);
                });
                $suggestions.show();
            } else {
                $suggestions.hide();
            }
        }, 300);
    });
    
    // Hide suggestions when clicking outside
    $(document).on('click', function(e) {
        if (!$(e.target).closest('.header-filters').length) {
            $suggestions.hide();
        }
    });
    
    // Clear search
    $searchInput.on('focus', function() {
        if ($(this).val().length >= 2) {
            $(this).trigger('keyup');
        }
    });
    
    // Force actions visible
    function forceActionsVisible() {
        $('.row-actions').css({
            'display': 'flex !important',
            'visibility': 'visible !important',
            'opacity': '1 !important'
        });
    }
    
    // Use MutationObserver to ensure actions stay visible
    const observer = new MutationObserver(function(mutations) {
        forceActionsVisible();
    });
    
    $('.row-actions').each(function() {
        observer.observe(this, {
            attributes: true,
            attributeFilter: ['style', 'class']
        });
    });
    
    // Initial call
    forceActionsVisible();
    setTimeout(forceActionsVisible, 100);
    setTimeout(forceActionsVisible, 500);
    
    // View Profile button handler
    $('.view-profile-btn').on('click', function(e) {
        e.preventDefault();
        const userId = $(this).data('user-id');
        const nonce = $(this).data('nonce');
        
        $('#wheelfyProfileModal').addClass('active');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'wheelfy_get_user_profile',
                user_id: userId,
                nonce: nonce
            },
            success: function(response) {
                if (response && response.success) {
                    $('#wheelfyProfileModalBody').html(response.data.html);
                } else {
                    $('#wheelfyProfileModalBody').html('<div class="wheelfy-profile-error">Failed to load profile.</div>');
                }
            }
        });
    });
    
    // Close modal
    $('.wheelfy-profile-modal-close').on('click', function() {
        $('#wheelfyProfileModal').removeClass('active');
    });
    
    // Function to show admin notice
    function showAdminNotice(message, type) {
        type = type || 'success';
        const noticeClass = type === 'success' ? 'notice-success' : 'notice-error';
        const notice = $('<div class="notice ' + noticeClass + ' is-dismissible"><p>' + message + '</p></div>');
        $('.wrap').first().prepend(notice);
        
        // Auto-dismiss after 3 seconds
        setTimeout(function() {
            notice.fadeOut(function() {
                $(this).remove();
            });
        }, 3000);
    }
    
    // User action buttons (Suspend, Approve, Reject, Activate, Delete)
    $('.user-action-btn').on('click', function(e) {
        e.preventDefault();
        const $btn = $(this);
        const action = $btn.data('action');
        const userId = $btn.data('user-id');
        const nonce = $btn.data('nonce');
        const tab = $btn.data('tab');
        
        // Disable button during request
        $btn.prop('disabled', true);
        const originalText = $btn.text();
        $btn.text('Processing...');
        
        if (action === 'delete') {
            if (confirm('Are you sure you want to delete this user?')) {
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'wheelfy_update_user_status',
                        user_id: userId,
                        status_action: action,
                        nonce: nonce,
                        tab: tab
                    },
                    success: function(response) {
                        if (response && response.success) {
                            showAdminNotice(response.data.message || 'User deleted successfully.', 'success');
                            setTimeout(function() {
                                location.reload();
                            }, 1000);
                        } else {
                            showAdminNotice(response.data.message || 'Action failed.', 'error');
                            $btn.prop('disabled', false);
                            $btn.text(originalText);
                        }
                    },
                    error: function() {
                        showAdminNotice('An error occurred. Please try again.', 'error');
                        $btn.prop('disabled', false);
                        $btn.text(originalText);
                    }
                });
            } else {
                $btn.prop('disabled', false);
                $btn.text(originalText);
            }
        } else {
            // Check if confirmation is needed (for reject action)
            const confirmMsg = $btn.data('confirm');
            if (confirmMsg && !confirm(confirmMsg)) {
                $btn.prop('disabled', false);
                $btn.text(originalText);
                return;
            }
            
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'wheelfy_update_user_status',
                    user_id: userId,
                    status_action: action,
                    nonce: nonce,
                    tab: tab
                },
                success: function(response) {
                    if (response && response.success) {
                        showAdminNotice(response.data.message || 'Action completed successfully.', 'success');
                        setTimeout(function() {
                            location.reload();
                        }, 1000);
                    } else {
                        showAdminNotice(response.data.message || 'Action failed.', 'error');
                        $btn.prop('disabled', false);
                        $btn.text(originalText);
                    }
                },
                error: function() {
                    showAdminNotice('An error occurred. Please try again.', 'error');
                    $btn.prop('disabled', false);
                    $btn.text(originalText);
                }
            });
        }
    });
    
    // Partner action buttons (Verify/Unverify)
    $('.partner-action-btn').on('click', function(e) {
        e.preventDefault();
        const $btn = $(this);
        const action = $btn.data('action');
        const userId = $btn.data('user-id');
        const nonce = $btn.data('nonce');
        const tab = $btn.data('tab');
        const isVerified = $btn.data('verified') === '1' || $btn.data('verified') === 1;
        
        // Disable button during request
        $btn.prop('disabled', true);
        const originalText = $btn.text();
        $btn.text('<?php _e('Processing...', 'wheelfy'); ?>');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'wheelfy_update_user_status',
                user_id: userId,
                status_action: action,
                nonce: nonce,
                tab: tab
            },
            success: function(response) {
                if (response && response.success) {
                    showAdminNotice(response.data.message || '<?php _e('Verification status updated successfully.', 'wheelfy'); ?>', 'success');
                    
                    // Toggle button text and data attribute without page reload
                    const newVerified = response.data.verified === '1' || response.data.verified === 1;
                    $btn.data('verified', newVerified ? '1' : '0');
                    $btn.text(newVerified ? '<?php _e('Unverify', 'wheelfy'); ?>' : '<?php _e('Verify', 'wheelfy'); ?>');
                    
                    // Toggle verification badge icon next to username
                    const $row = $btn.closest('tr');
                    const $usernameCell = $row.find('td:nth-child(2)');
                    const $existingBadge = $usernameCell.find('.dashicons-yes-alt');
                    
                    if (newVerified) {
                        // Add badge if not exists
                        if ($existingBadge.length === 0) {
                            $usernameCell.append('<span class="dashicons dashicons-yes-alt" style="color: #46b450;" title="<?php _e('Verified Partner', 'wheelfy'); ?>"></span>');
                        }
                    } else {
                        // Remove badge
                        $existingBadge.remove();
                    }
                    
                    $btn.prop('disabled', false);
                } else {
                    showAdminNotice(response.data.message || '<?php _e('Action failed.', 'wheelfy'); ?>', 'error');
                    $btn.prop('disabled', false);
                    $btn.text(originalText);
                }
            },
            error: function() {
                showAdminNotice('<?php _e('An error occurred. Please try again.', 'wheelfy'); ?>', 'error');
                $btn.prop('disabled', false);
                $btn.text(originalText);
            }
        });
    });
});
</script>

