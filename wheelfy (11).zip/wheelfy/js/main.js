/**
 * Wheelfy Theme JavaScript
 */

(function() {
    'use strict';

    // Mobile Menu Toggle - Offcanvas
    const mobileMenuToggle = document.getElementById('mobile-menu-toggle');
    const mobileMenu = document.getElementById('mobile-menu');
    const mobileMenuOverlay = document.getElementById('mobile-menu-overlay');
    const mobileMenuClose = document.getElementById('mobile-menu-close');
    const menuIcon = document.getElementById('menu-icon');
    const closeIcon = document.getElementById('close-icon');
    const body = document.body;
    const html = document.documentElement;

    // Store scroll position before locking
    let scrollPosition = 0;
    
    // Initialize: Ensure menu is hidden off-screen on page load
    if (mobileMenu) {
        mobileMenu.classList.add('translate-x-full');
        mobileMenu.classList.remove('translate-x-0');
        mobileMenu.style.transform = 'translateX(100%)';
    }
    
    // Ensure overlay is hidden on page load
    if (mobileMenuOverlay) {
        mobileMenuOverlay.classList.add('hidden');
        mobileMenuOverlay.style.opacity = '0';
        mobileMenuOverlay.style.visibility = 'hidden';
    }
    
    // Prevent horizontal scroll globally
    html.style.overflowX = 'hidden';
    body.style.overflowX = 'hidden';
    html.style.maxWidth = '100vw';
    body.style.maxWidth = '100vw';

    function openMobileMenu() {
        // Prevent body scroll when menu is open - store scroll position first
        scrollPosition = window.pageYOffset || document.documentElement.scrollTop;
        body.classList.add('menu-open');
        body.style.top = '-' + scrollPosition + 'px';
        body.style.width = '100%';
        body.style.maxWidth = '100vw';
        
        // Prevent horizontal scroll
        document.documentElement.style.overflowX = 'hidden';
        body.style.overflowX = 'hidden';
        
        if (mobileMenuOverlay) {
            mobileMenuOverlay.classList.remove('hidden');
            // Use requestAnimationFrame for smooth transition
            requestAnimationFrame(() => {
                mobileMenuOverlay.classList.remove('opacity-0');
                mobileMenuOverlay.classList.add('opacity-100');
            });
        }
        
        if (mobileMenu) {
            // Ensure menu starts off-screen
            mobileMenu.style.transform = 'translateX(100%)';
            // Use requestAnimationFrame for smooth transition
            requestAnimationFrame(() => {
                requestAnimationFrame(() => {
                    mobileMenu.classList.remove('translate-x-full');
                    mobileMenu.classList.add('translate-x-0');
                    mobileMenu.style.transform = 'translateX(0)';
                });
            });
        }
        
        if (menuIcon) menuIcon.classList.add('hidden');
        if (closeIcon) closeIcon.classList.remove('hidden');
    }

    function closeMobileMenu() {
        if (mobileMenu) {
            mobileMenu.classList.remove('translate-x-0');
            mobileMenu.classList.add('translate-x-full');
            mobileMenu.style.transform = 'translateX(100%)';
        }
        if (mobileMenuOverlay) {
            mobileMenuOverlay.classList.add('opacity-0');
            setTimeout(() => {
                if (mobileMenuOverlay) {
                    mobileMenuOverlay.classList.add('hidden');
                }
            }, 300);
        }
        if (menuIcon) menuIcon.classList.remove('hidden');
        if (closeIcon) closeIcon.classList.add('hidden');
        
        // Restore body scroll - restore scroll position after animation
        setTimeout(() => {
            body.classList.remove('menu-open');
            body.style.top = '';
            body.style.width = '';
            body.style.maxWidth = '';
            body.style.overflowX = '';
            document.documentElement.style.overflowX = '';
            window.scrollTo(0, scrollPosition);
        }, 300);
    }

    if (mobileMenuToggle) {
        mobileMenuToggle.addEventListener('click', function(e) {
            e.stopPropagation();
            openMobileMenu();
        });
    }

    if (mobileMenuClose) {
        mobileMenuClose.addEventListener('click', function(e) {
            e.stopPropagation();
            closeMobileMenu();
        });
    }

    // Close menu when clicking overlay
    if (mobileMenuOverlay) {
        mobileMenuOverlay.addEventListener('click', function() {
            closeMobileMenu();
        });
    }

    // Dynamic Dropdown Toggle for all menu dropdowns with professional animations
    document.querySelectorAll('[data-dropdown-toggle]').forEach(function(toggle) {
        const dropdownId = toggle.getAttribute('data-dropdown-toggle');
        const dropdownMenu = toggle.closest('.menu-item').querySelector('[data-dropdown]');
        const dropdownArrow = toggle.querySelector('.dropdown-arrow');
        
        if (dropdownMenu) {
            toggle.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                
                // Prevent any layout shifts by locking parent position
                const menuItem = toggle.closest('.menu-item-has-children');
                if (menuItem) {
                    // Store current position to prevent any shifts
                    const rect = menuItem.getBoundingClientRect();
                    menuItem.style.position = 'relative';
                    menuItem.style.top = 'auto';
                    menuItem.style.left = 'auto';
                }
                
                const isHidden = dropdownMenu.classList.contains('hidden');
                
                // Close all other dropdowns first
                document.querySelectorAll('[data-dropdown]').forEach(function(dropdown) {
                    if (dropdown !== dropdownMenu) {
                        dropdown.classList.add('hidden');
                        const otherToggle = dropdown.closest('.menu-item').querySelector('[data-dropdown-toggle]');
                        if (otherToggle) {
                            const otherArrow = otherToggle.querySelector('.dropdown-arrow');
                            if (otherArrow) {
                                otherArrow.style.transform = 'rotate(0deg)';
                            }
                        }
                    }
                });
                
                // Toggle current dropdown
                dropdownMenu.classList.toggle('hidden');
                
                // Animate arrow - only transform the arrow, not the parent
                if (dropdownArrow) {
                    if (isHidden) {
                        dropdownArrow.style.transform = 'rotate(180deg)';
                    } else {
                        dropdownArrow.style.transform = 'rotate(0deg)';
                    }
                }
            });
        }
    });

    // Close dropdown when clicking outside with arrow reset
    document.addEventListener('click', function(e) {
        document.querySelectorAll('[data-dropdown]').forEach(function(dropdown) {
            const toggle = dropdown.closest('.menu-item').querySelector('[data-dropdown-toggle]');
            if (dropdown && !dropdown.contains(e.target) && (!toggle || !toggle.contains(e.target))) {
                dropdown.classList.add('hidden');
                if (toggle) {
                    const arrow = toggle.querySelector('.dropdown-arrow');
                    if (arrow) {
                        arrow.style.transform = 'rotate(0deg)';
                    }
                }
            }
        });
    });

    // Language Switcher - Select Dropdown
    const languageSelect = document.getElementById('language-select');
    
    if (languageSelect) {
        languageSelect.addEventListener('change', function(e) {
            const selectedLang = e.target.value;
            // Add your language switching logic here
            // Example: window.location.href = '/?lang=' + selectedLang;
            console.log('Language changed to:', selectedLang);
        });
    }

    // Flag to prevent infinite reload loop
    let isUpdatingGTranslate = false;
    let gtranslateUpdateTimeout = null;
    let gtSelectHandler = null;
    let googSelectHandler = null;
    let isInitialPageLoad = true;
    let pageLoadComplete = false;
    
    // Mark page load as complete after a short delay
    setTimeout(function() {
        isInitialPageLoad = false;
        pageLoadComplete = true;
    }, 2000);

    // GTranslate Widget - Update selected language display (SYNC ONLY - NO RELOAD)
    function updateGTranslateDisplay() {
        // Prevent recursive calls
        if (isUpdatingGTranslate) {
            return;
        }
        
        isUpdatingGTranslate = true;
        
        // Clear any pending updates
        if (gtranslateUpdateTimeout) {
            clearTimeout(gtranslateUpdateTimeout);
        }
        
        // Wait for GTranslate to initialize
        gtranslateUpdateTimeout = setTimeout(function() {
            // Get current language from URL or cookie
            const urlParams = new URLSearchParams(window.location.search);
            const langParam = urlParams.get('lang');
            const cookieLang = document.cookie.match(/wheelfy_lang=([^;]+)/);
            const currentLang = langParam || (cookieLang ? cookieLang[1] : 'en');
            
            // Find GTranslate select elements
            const gtSelect = document.querySelector('.gt_selector.notranslate');
            const googSelect = document.querySelector('.goog-te-combo');
            
            if (gtSelect) {
                // Map language codes
                const langMap = {
                    'en': 'en|en',
                    'hu': 'en|hu',
                    'de': 'en|de'
                };
                
                const gtValue = langMap[currentLang] || 'en|en';
                
                // Only update if value is different (silent update - no event trigger)
                if (gtSelect.value !== gtValue) {
                    // Temporarily remove event listener to prevent reload
                    if (gtSelectHandler) {
                        gtSelect.removeEventListener('change', gtSelectHandler);
                    }
                    
                    // Set value silently
                    gtSelect.value = gtValue;
                    
                    // Re-attach event listener after a short delay
                    setTimeout(function() {
                        if (gtSelectHandler) {
                            gtSelect.addEventListener('change', gtSelectHandler);
                        }
                    }, 100);
                }
            }
            
            if (googSelect) {
                // Update Google Translate combo
                const googLangMap = {
                    'en': 'en',
                    'hu': 'hu',
                    'de': 'de'
                };
                
                const googValue = googLangMap[currentLang] || 'en';
                
                // Only update if value is different (silent update)
                if (googSelect.value !== googValue) {
                    // Temporarily remove event listener to prevent reload
                    if (googSelectHandler) {
                        googSelect.removeEventListener('change', googSelectHandler);
                    }
                    
                    // Set value silently
                    googSelect.value = googValue;
                    
                    // Re-attach event listener after a short delay
                    setTimeout(function() {
                        if (googSelectHandler) {
                            googSelect.addEventListener('change', googSelectHandler);
                        }
                    }, 100);
                }
            }
            
            isUpdatingGTranslate = false;
        }, 500);
    }
    
    // Run on page load (only once)
    let hasRunInitialUpdate = false;
    let initialUpdateTimeout = null;
    
    function runInitialGTranslateUpdate() {
        if (hasRunInitialUpdate) {
            return;
        }
        hasRunInitialUpdate = true;
        
        // Clear any existing timeout
        if (initialUpdateTimeout) {
            clearTimeout(initialUpdateTimeout);
        }
        
        // Wait for DOM and GTranslate to be ready
        function doUpdate() {
            if (!isUpdatingGTranslate) {
                updateGTranslateDisplay();
            }
        }
        
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', function() {
                // Wait a bit for GTranslate to initialize
                initialUpdateTimeout = setTimeout(doUpdate, 1000);
            });
        } else {
            // Wait a bit for GTranslate to initialize
            initialUpdateTimeout = setTimeout(doUpdate, 1000);
        }
    }
    
    // Only run once on page load
    runInitialGTranslateUpdate();
    
    // Listen for GTranslate language changes (USER INITIATED ONLY)
    document.addEventListener('DOMContentLoaded', function() {
        const gtSelect = document.querySelector('.gt_selector.notranslate');
        const googSelect = document.querySelector('.goog-te-combo');
        
        // Define handler functions
        gtSelectHandler = function(e) {
            // Prevent reload during initial page load
            if (isInitialPageLoad || !pageLoadComplete) {
                return;
            }
            
            // Only reload if this is a user-initiated change (not programmatic)
            if (isUpdatingGTranslate) {
                return; // Skip if we're in the middle of a programmatic update
            }
            
            // Update the display when user changes language
            const selectedValue = e.target.value;
            if (selectedValue) {
                const langCode = selectedValue.split('|')[1] || 'en';
                // Update cookie
                document.cookie = 'wheelfy_lang=' + langCode + '; path=/; max-age=31536000';
                // Reload page to apply language (only for user-initiated changes)
                window.location.reload();
            }
        };
        
        googSelectHandler = function(e) {
            // Prevent reload during initial page load
            if (isInitialPageLoad || !pageLoadComplete) {
                return;
            }
            
            // Only process if this is a user-initiated change
            if (isUpdatingGTranslate) {
                return; // Skip if we're in the middle of a programmatic update
            }
            
            const selectedLang = e.target.value;
            if (selectedLang) {
                // Update cookie
                document.cookie = 'wheelfy_lang=' + selectedLang + '; path=/; max-age=31536000';
                // Update GTranslate selector if it exists
                const gtSelect = document.querySelector('.gt_selector.notranslate');
                if (gtSelect) {
                    const langMap = {
                        'en': 'en|en',
                        'hu': 'en|hu',
                        'de': 'en|de'
                    };
                    const gtValue = langMap[selectedLang] || 'en|en';
                    // Temporarily remove handler to prevent reload
                    if (gtSelectHandler) {
                        gtSelect.removeEventListener('change', gtSelectHandler);
                    }
                    gtSelect.value = gtValue;
                    // Re-attach handler
                    setTimeout(function() {
                        if (gtSelectHandler) {
                            gtSelect.addEventListener('change', gtSelectHandler);
                        }
                    }, 100);
                }
                // Reload page to apply language
                window.location.reload();
            }
        };
        
        if (gtSelect && gtSelectHandler) {
            gtSelect.addEventListener('change', gtSelectHandler);
        }
        
        if (googSelect && googSelectHandler) {
            googSelect.addEventListener('change', googSelectHandler);
        }
    });

    // Header Dashboard Dropdown Toggle
    window.toggleHeaderDropdown = function(menuId) {
        const menu = document.getElementById(menuId);
        const icon = document.getElementById(menuId + '-icon');
        if (menu) {
            const isHidden = menu.classList.contains('hidden');
            // Close all other dropdowns first
            document.querySelectorAll('[id$="-menu"]').forEach(function(m) {
                if (m.id !== menuId) {
                    m.classList.add('hidden');
                }
            });
            // Toggle current menu
            if (isHidden) {
                menu.classList.remove('hidden');
                if (icon) {
                    icon.style.transform = 'rotate(180deg)';
                }
            } else {
                menu.classList.add('hidden');
                if (icon) {
                    icon.style.transform = 'rotate(0deg)';
                }
            }
        }
    };

    // Close header dropdown when clicking outside
    document.addEventListener('click', function(e) {
        const headerMenu = document.getElementById('header-menu');
        const headerButton = e.target.closest('button[onclick*="toggleHeaderDropdown"]');
        if (headerMenu && !headerMenu.contains(e.target) && !headerButton) {
            headerMenu.classList.add('hidden');
            const icon = document.getElementById('header-menu-icon');
            if (icon) {
                icon.style.transform = 'rotate(0deg)';
            }
        }
    });

    // Smooth scroll for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            const href = this.getAttribute('href');
            if (href !== '#' && href.length > 1) {
                const target = document.querySelector(href);
                if (target) {
                    e.preventDefault();
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            }
        });
    });

    // Animate hero section elements immediately on page load
    const heroSection = document.querySelector('.hero-section-sticky, section:first-of-type');
    if (heroSection) {
        const heroElements = heroSection.querySelectorAll('[data-animate]');
        heroElements.forEach((el, index) => {
            setTimeout(() => {
                el.style.opacity = '1';
                el.classList.add('animate-fade-in-up');
            }, index * 200);
        });
    }

    // Add animation classes on scroll (simple intersection observer)
    if ('IntersectionObserver' in window) {
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver(function(entries) {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    // Skip if already animated (hero section)
                    if (!entry.target.classList.contains('animate-fade-in-up')) {
                        entry.target.classList.add('animate-fade-in-up');
                    }
                    observer.unobserve(entry.target);
                }
            });
        }, observerOptions);

        // Observe elements with data-animate attribute (excluding hero)
        document.querySelectorAll('[data-animate]').forEach(el => {
            // Only observe if not in hero section or already visible
            if (!heroSection || !heroSection.contains(el)) {
                observer.observe(el);
            }
        });

        // Auto-animate sections on scroll
        document.querySelectorAll('section').forEach(section => {
            if (section !== heroSection) {
                observer.observe(section);
            }
        });
    }

    // Close mobile menu when clicking on a link
    if (mobileMenu) {
        mobileMenu.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', function() {
                closeMobileMenu();
            });
        });
    }

    // Close menu on escape key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && mobileMenu && !mobileMenu.classList.contains('translate-x-full')) {
            closeMobileMenu();
        }
    });

    // Add smooth scroll behavior for all internal links
    document.querySelectorAll('a[href^="/"], a[href^="#"]').forEach(link => {
        link.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            if (href && href.startsWith('#')) {
                const target = document.querySelector(href);
                if (target) {
                    e.preventDefault();
                    const headerOffset = 80;
                    const elementPosition = target.getBoundingClientRect().top;
                    const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

                    window.scrollTo({
                        top: offsetPosition,
                        behavior: 'smooth'
                    });
                }
            }
        });
    });

    // Add loading state to buttons (exclude form submit buttons)
    document.querySelectorAll('.button').forEach(button => {
        // Skip buttons that are form submit buttons or have specific IDs
        if (button.type === 'submit' || button.id === 'login-submit-btn' || button.id === 'register-submit-btn') {
            return;
        }
        
        button.addEventListener('click', function() {
            if (this.tagName === 'BUTTON' && !this.disabled && this.type !== 'submit') {
                const originalText = this.innerHTML;
                this.disabled = true;
                this.style.opacity = '0.7';
                
                setTimeout(() => {
                    this.disabled = false;
                    this.style.opacity = '1';
                }, 1000);
            }
        });
    });

    // Lazy load images
    if ('IntersectionObserver' in window) {
        const imageObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    if (img.dataset.src) {
                        img.src = img.dataset.src;
                        img.removeAttribute('data-src');
                        observer.unobserve(img);
                    }
                }
            });
        });

        document.querySelectorAll('img[data-src]').forEach(img => {
            imageObserver.observe(img);
        });
    }

    // FAQ Accordion Functionality
    document.querySelectorAll('.faq-question').forEach(function(questionBtn) {
        questionBtn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            const faqItem = this.closest('.faq-item');
            const answer = faqItem.querySelector('.faq-answer');
            const isActive = faqItem.classList.contains('active');
            
            // Close all FAQ items (optional: for accordion behavior where only one is open)
            // Uncomment the next 4 lines if you want accordion behavior (only one open at a time)
            // document.querySelectorAll('.faq-item').forEach(function(item) {
            //     item.classList.remove('active');
            //     item.querySelector('.faq-answer').classList.add('hidden');
            //     item.querySelector('.faq-question').setAttribute('aria-expanded', 'false');
            // });
            
            // Toggle current item
            if (isActive) {
                faqItem.classList.remove('active');
                answer.classList.add('hidden');
                this.setAttribute('aria-expanded', 'false');
            } else {
                faqItem.classList.add('active');
                answer.classList.remove('hidden');
                this.setAttribute('aria-expanded', 'true');
            }
        });
    });

})();

