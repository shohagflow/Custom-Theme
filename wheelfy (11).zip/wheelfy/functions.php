<?php
/**
 * Wheelfy Theme Functions
 *
 * @package Wheelfy
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * Start output buffering early for form submissions to prevent headers already sent errors
 */
function wheelfy_start_output_buffering() {
    // Only buffer if this is a POST request to our forms
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && 
        (isset($_POST['car_accessories_nonce']) || isset($_POST['select_partner_nonce']))) {
        if (ob_get_level() == 0) {
            ob_start();
        }
    }
}
add_action('plugins_loaded', 'wheelfy_start_output_buffering', 1);

/**
 * Load CMB2 Framework
 */
require_once get_template_directory() . '/includes/cmb2-init.php';

/**
 * Load CMB2 Field Definitions
 */
require_once get_template_directory() . '/includes/cmb2-fields.php';

/**
 * Load CMB2 Helper Functions
 */
require_once get_template_directory() . '/includes/cmb2-helpers.php';

/**
 * Load Subscription Management System
 */
require_once get_template_directory() . '/includes/subscription-management.php';

/**
 * Load Chat Security System (Contact Information Blocking)
 */
require_once get_template_directory() . '/includes/chat-security.php';

/**
 * Load Payment Gateway System
 */
require_once get_template_directory() . '/includes/payment-gateway.php';

/**
 * Load TGM Plugin Activation (if available)
 */
$tgm_file = get_template_directory() . '/includes/tgm/class-tgm-plugin-activation.php';
if (file_exists($tgm_file)) {
    require_once $tgm_file;
    
    /**
     * Load TGM Plugin Configuration
     */
    $tgm_config = get_template_directory() . '/includes/tgm-config.php';
    if (file_exists($tgm_config)) {
        require_once $tgm_config;
    }
}

/**
 * Prevent WPForms Lite from being auto-installed or recommended
 * This ensures only WP Mail SMTP is installed, not WPForms Lite
 */
function wheelfy_prevent_wpforms_auto_install() {
    // Load plugin functions if not already loaded
    if (!function_exists('is_plugin_active')) {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
    }
    
    // Deactivate WPForms Lite if it gets installed (it's not required for our theme)
    $wpforms_plugin = 'wpforms-lite/wpforms.php';
    if (is_plugin_active($wpforms_plugin)) {
        deactivate_plugins($wpforms_plugin);
    }
}
add_action('admin_init', 'wheelfy_prevent_wpforms_auto_install');

/**
 * Filter to prevent WPForms Lite from being shown in plugin recommendations
 */
function wheelfy_filter_plugin_suggestions($plugins) {
    // Remove WPForms Lite from any plugin suggestion lists
    if (is_array($plugins)) {
        foreach ($plugins as $key => $plugin) {
            if (isset($plugin['slug']) && $plugin['slug'] === 'wpforms-lite') {
                unset($plugins[$key]);
            }
            if (isset($plugin['slug']) && $plugin['slug'] === 'wpforms') {
                unset($plugins[$key]);
            }
        }
    }
    return $plugins;
}
add_filter('wp_mail_smtp_admin_get_plugins', 'wheelfy_filter_plugin_suggestions', 10, 1);
add_filter('tgmpa_plugins', 'wheelfy_filter_plugin_suggestions', 10, 1);


/**
 * Theme Setup
 */
function wheelfy_setup() {
    // Add theme support
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
        'style',
        'script',
    ));
    add_theme_support('custom-logo');
    add_theme_support('responsive-embeds');
    add_theme_support('align-wide');

    // Register navigation menus
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'wheelfy'),
        'footer' => __('Footer Menu', 'wheelfy'),
    ));
}
add_action('after_setup_theme', 'wheelfy_setup');

/**
 * Create Custom User Roles: Customer and Partner
 * CRITICAL: These roles have NO administrator capabilities
 */
function wheelfy_create_custom_roles() {
    // Customer Role - Frontend only, NO admin capabilities
    if (!get_role('customer')) {
        add_role(
            'customer',
            __('Customer', 'wheelfy'),
            array(
                'read' => true,                    // Can read posts/pages
                'upload_files' => true,            // Can upload media
                // NO admin capabilities
                'administrator' => false,
                'manage_options' => false,
                'manage_network' => false,
                'activate_plugins' => false,
                'delete_users' => false,
                'edit_users' => false,
            )
        );
    }
    
    // Partner Role - Frontend only, NO admin capabilities
    if (!get_role('partner')) {
        add_role(
            'partner',
            __('Partner', 'wheelfy'),
            array(
                'read' => true,                    // Can read posts/pages
                'upload_files' => true,            // Can upload media
                // NO admin capabilities
                'administrator' => false,
                'manage_options' => false,
                'manage_network' => false,
                'activate_plugins' => false,
                'delete_users' => false,
                'edit_users' => false,
            )
        );
    }
}
add_action('after_setup_theme', 'wheelfy_create_custom_roles');
add_action('after_switch_theme', 'wheelfy_create_custom_roles');

/**
 * Auto-create pages on theme activation
 */
function wheelfy_create_pages() {
    $pages = array(
        array(
            'title' => 'Home',
            'slug' => 'home',
            'template' => 'page-home.php',
            'content' => 'Welcome to our automotive services platform. Compare prices and save money on car maintenance and sales.',
        ),
        array(
            'title' => 'How It Works',
            'slug' => 'how-it-works',
            'template' => 'page-how-it-works.php',
            'content' => 'Learn how our platform works to help you save money on car services.',
        ),
        array(
            'title' => 'Car Maintenance',
            'slug' => 'car-maintenance',
            'template' => 'page-car-maintenance.php',
            'content' => 'Compare prices from verified garages and workshops for all your car maintenance needs.',
        ),
        array(
            'title' => 'Car Sales',
            'slug' => 'car-sales',
            'template' => 'page-car-sales.php',
            'content' => 'Sell your car easily and get the best price from multiple dealerships.',
        ),
        array(
            'title' => 'Partners',
            'slug' => 'partners',
            'template' => 'page-partners.php',
            'content' => 'Join our network of trusted service providers and dealerships.',
        ),
        array(
            'title' => 'Pricing',
            'slug' => 'pricing',
            'template' => 'page-pricing.php',
            'content' => 'Simple, transparent pricing. Free for customers, fair for partners.',
        ),
        array(
            'title' => 'Login',
            'slug' => 'login',
            'template' => 'page-login.php',
            'content' => 'Sign in to your account.',
        ),
        array(
            'title' => 'Register',
            'slug' => 'register',
            'template' => 'page-register.php',
            'content' => 'Create your free account to start saving money.',
        ),
        array(
            'title' => 'Request for Proposal',
            'slug' => 'request-proposal',
            'template' => 'page-request-proposal.php',
            'content' => 'Request a proposal for car maintenance or sales services.',
        ),
        array(
            'title' => 'Sell Your Car',
            'slug' => 'sell-your-car',
            'template' => 'page-sell-your-car.php',
            'content' => 'Get the best price for your vehicle.',
        ),
        array(
            'title'   => 'Customer Dashboard',
            'slug'    => 'customer-dashboard',
            'template'=> 'page-dashboard-customer.php',
            'content' => '',
        ),
        array(
            'title'   => 'Partner Dashboard',
            'slug'    => 'partner-dashboard',
            'template'=> 'page-dashboard-partner.php',
            'content' => '',
        ),
        array(
            'title' => 'FAQ',
            'slug' => 'faq',
            'template' => 'page-faq.php',
            'content' => 'Frequently asked questions about our platform.',
        ),
        array(
            'title' => 'Sell Your Car Form',
            'slug' => 'sell-your-car-form',
            'template' => 'page-sell-car-form.php',
            'content' => 'Submit your car details to get the best price.',
        ),
        array(
            'title' => 'Car Accessories Form',
            'slug' => 'car-accessories-form',
            'template' => 'page-car-accessories-form.php',
            'content' => 'Select the accessories and features your car has.',
        ),
        array(
            'title' => 'Service Book Form',
            'slug' => 'service-book-form',
            'template' => 'page-service-book-form.php',
            'content' => 'Enter information about your car\'s service records.',
        ),
        array(
            'title' => 'Previous Service Form',
            'slug' => 'previous-service-form',
            'template' => 'page-previous-service-form.php',
            'content' => 'Enter details about your car\'s previous service records.',
        ),
        array(
            'title' => 'All Services Form',
            'slug' => 'all-services-form',
            'template' => 'page-all-services-form.php',
            'content' => 'Request a comprehensive service for your vehicle.',
        ),
    );

    foreach ($pages as $page) {
        $page_check = get_page_by_path($page['slug']);
        if (!$page_check) {
            $page_data = array(
                'post_title' => $page['title'],
                'post_name' => $page['slug'],
                'post_content' => $page['content'],
                'post_status' => 'publish',
                'post_type' => 'page',
                'post_author' => 1,
            );
            $page_id = wp_insert_post($page_data);
            
            if ($page_id && isset($page['template']) && !empty($page['template'])) {
                update_post_meta($page_id, '_wp_page_template', $page['template']);
            }
        }
    }
    
    // Flush rewrite rules after creating pages to ensure URLs work
    if (function_exists('flush_rewrite_rules')) {
        flush_rewrite_rules(false);
    }
}

/**
 * Ensure dashboard pages exist (customer-dashboard and partner-dashboard)
 * This runs on init to create pages if they don't exist
 */
function wheelfy_ensure_dashboard_pages_exist() {
    $dashboard_pages = array(
        array(
            'title'   => 'Customer Dashboard',
            'slug'    => 'customer-dashboard',
            'template'=> 'page-dashboard-customer.php',
            'content' => '',
        ),
        array(
            'title'   => 'Partner Dashboard',
            'slug'    => 'partner-dashboard',
            'template'=> 'page-dashboard-partner.php',
            'content' => '',
        ),
        array(
            'title'   => 'Partner Profile',
            'slug'    => 'partner-profile',
            'template'=> 'page-partner-profile.php',
            'content' => '',
        ),
    );
    
    foreach ($dashboard_pages as $page) {
        $page_check = get_page_by_path($page['slug']);
        if (!$page_check) {
            $page_data = array(
                'post_title' => $page['title'],
                'post_name' => $page['slug'],
                'post_content' => $page['content'],
                'post_status' => 'publish',
                'post_type' => 'page',
                'post_author' => 1,
            );
            $page_id = wp_insert_post($page_data);
            
            if ($page_id && isset($page['template']) && !empty($page['template'])) {
                update_post_meta($page_id, '_wp_page_template', $page['template']);
                // Flush rewrite rules after creating page
                flush_rewrite_rules(false);
            }
        } else {
            // Page exists, but make sure template is set correctly
            $current_template = get_post_meta($page_check->ID, '_wp_page_template', true);
            if (empty($current_template) && isset($page['template'])) {
                update_post_meta($page_check->ID, '_wp_page_template', $page['template']);
            }
        }
    }
}

/**
 * Check for required plugins on theme activation
 */
function wheelfy_check_required_plugins() {
    // Load plugin functions if not already loaded
    if (!function_exists('is_plugin_active')) {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
    }
    
    $required_plugins = array(
        array(
            'name' => 'CMB2',
            'file' => 'cmb2/init.php',
            'slug' => 'cmb2',
            'required' => true,
            'message' => 'CMB2 is required for theme settings and dynamic content management.',
        ),
        array(
            'name' => 'GTranslate',
            'file' => 'gtranslate/gtranslate.php',
            'slug' => 'gtranslate',
            'required' => true,
            'message' => 'GTranslate is required for multilingual support.',
        ),
        array(
            'name' => 'WP Mail SMTP',
            'file' => 'wp-mail-smtp/wp_mail_smtp.php',
            'slug' => 'wp-mail-smtp',
            'required' => true,
            'message' => 'WP Mail SMTP is required for email functionality.',
        ),
    );
    
    $missing_plugins = array();
    
    foreach ($required_plugins as $plugin) {
        // Check if plugin is active
        if (!is_plugin_active($plugin['file'])) {
            // Check if plugin is installed but not active
            if (file_exists(WP_PLUGIN_DIR . '/' . $plugin['file'])) {
                $missing_plugins[] = array(
                    'name' => $plugin['name'],
                    'file' => $plugin['file'],
                    'slug' => $plugin['slug'],
                    'status' => 'inactive',
                    'message' => $plugin['message'],
                );
            } else {
                // Plugin is not installed
                $missing_plugins[] = array(
                    'name' => $plugin['name'],
                    'file' => $plugin['file'],
                    'slug' => $plugin['slug'],
                    'status' => 'not_installed',
                    'message' => $plugin['message'],
                );
            }
        }
    }
    
    return $missing_plugins;
}

/**
 * Show admin notice for required plugins
 */
function wheelfy_required_plugins_notice() {
    if (!current_user_can('activate_plugins')) {
        return;
    }
    
    $missing_plugins = wheelfy_check_required_plugins();
    
    if (empty($missing_plugins)) {
        return;
    }
    
    $plugin_names = array();
    $plugin_links = array();
    
    foreach ($missing_plugins as $plugin) {
        $plugin_names[] = $plugin['name'];
        
        if ($plugin['status'] === 'inactive') {
            $activate_url = wp_nonce_url(
                admin_url('plugins.php?action=activate&plugin=' . urlencode($plugin['file'])),
                'activate-plugin_' . $plugin['file']
            );
            $plugin_links[] = '<a href="' . esc_url($activate_url) . '">' . esc_html__('Activate', 'wheelfy') . ' ' . esc_html($plugin['name']) . '</a>';
        } else {
            $install_url = admin_url('plugin-install.php?s=' . urlencode($plugin['name']) . '&tab=search&type=term');
            $plugin_links[] = '<a href="' . esc_url($install_url) . '">' . esc_html__('Install', 'wheelfy') . ' ' . esc_html($plugin['name']) . '</a>';
        }
    }
    
    $message = sprintf(
        esc_html__('The Wheelfy theme requires the following plugins to function properly: %s. %s', 'wheelfy'),
        '<strong>' . implode('</strong>, <strong>', $plugin_names) . '</strong>',
        implode(' | ', $plugin_links)
    );
    
    echo '<div class="notice notice-error"><p>' . $message . '</p></div>';
}
add_action('admin_notices', 'wheelfy_required_plugins_notice');

/**
 * Check required plugins on theme activation
 */
function wheelfy_theme_activation_check() {
    $missing_plugins = wheelfy_check_required_plugins();
    
    if (!empty($missing_plugins)) {
        // Store missing plugins in transient for display
        set_transient('wheelfy_missing_plugins', $missing_plugins, 30);
    }
    
    // Still create pages even if plugins are missing
    wheelfy_create_pages();
}
add_action('after_switch_theme', 'wheelfy_theme_activation_check');

// Run on theme activation
add_action('after_switch_theme', 'wheelfy_create_pages');
// Also check and create dashboard pages on init (in case theme was already activated)
add_action('init', 'wheelfy_ensure_dashboard_pages_exist', 20);

// Also run on admin init to ensure pages exist (only once)
if (!get_option('wheelfy_pages_created')) {
    add_action('admin_init', function() {
        wheelfy_create_pages();
        update_option('wheelfy_pages_created', true);
        flush_rewrite_rules();
    }, 1);
}

// Flush rewrite rules on theme activation
add_action('after_switch_theme', function() {
    flush_rewrite_rules();
});

// Create pages on first load if they don't exist
add_action('wp', function() {
    if (!get_option('wheelfy_pages_created')) {
        wheelfy_create_pages();
        update_option('wheelfy_pages_created', true);
        flush_rewrite_rules();
    }
}, 1);

// Ensure Request for Proposal page exists (check on admin pages load)
add_action('admin_init', function() {
    $page_check = get_page_by_path('request-proposal');
    if (!$page_check) {
        $page_data = array(
            'post_title' => 'Request for Proposal',
            'post_name' => 'request-proposal',
            'post_content' => 'Request a proposal for car maintenance or sales services.',
            'post_status' => 'publish',
            'post_type' => 'page',
            'post_author' => 1,
        );
        $page_id = wp_insert_post($page_data);
        
        if ($page_id) {
            update_post_meta($page_id, '_wp_page_template', 'page-request-proposal.php');
            flush_rewrite_rules(false);
        }
    }
    
    // Ensure Sell Your Car page exists (check on admin pages load)
    $sell_page_check = get_page_by_path('sell-your-car');
    if (!$sell_page_check) {
        $sell_page_data = array(
            'post_title' => 'Sell Your Car',
            'post_name' => 'sell-your-car',
            'post_content' => 'Get the best price for your vehicle.',
            'post_status' => 'publish',
            'post_type' => 'page',
            'post_author' => 1,
        );
        $sell_page_id = wp_insert_post($sell_page_data);
        
        if ($sell_page_id) {
            update_post_meta($sell_page_id, '_wp_page_template', 'page-sell-your-car.php');
            flush_rewrite_rules(false);
        }
    }
    
    // Ensure FAQ page exists (check on admin pages load)
    $faq_page_check = get_page_by_path('faq');
    if (!$faq_page_check) {
        $faq_page_data = array(
            'post_title' => 'FAQ',
            'post_name' => 'faq',
            'post_content' => 'Frequently asked questions about our platform.',
            'post_status' => 'publish',
            'post_type' => 'page',
            'post_author' => 1,
        );
        $faq_page_id = wp_insert_post($faq_page_data);
        
        if ($faq_page_id) {
            update_post_meta($faq_page_id, '_wp_page_template', 'page-faq.php');
            flush_rewrite_rules(false);
        }
    }
    
    // Ensure Sell Your Car Form page exists (check on admin pages load)
    $sell_car_form_check = get_page_by_path('sell-your-car-form');
    if (!$sell_car_form_check) {
        $sell_car_form_data = array(
            'post_title' => 'Sell Your Car Form',
            'post_name' => 'sell-your-car-form',
            'post_content' => 'Submit your car details to get the best price.',
            'post_status' => 'publish',
            'post_type' => 'page',
            'post_author' => 1,
        );
        $sell_car_form_id = wp_insert_post($sell_car_form_data);
        
        if ($sell_car_form_id) {
            update_post_meta($sell_car_form_id, '_wp_page_template', 'page-sell-car-form.php');
            flush_rewrite_rules(false);
        }
    }
    
    // Ensure Car Accessories Form page exists (check on admin pages load)
    $car_accessories_form_check = get_page_by_path('car-accessories-form');
    if (!$car_accessories_form_check) {
        $car_accessories_form_data = array(
            'post_title' => 'Car Accessories Form',
            'post_name' => 'car-accessories-form',
            'post_content' => 'Select the accessories and features your car has.',
            'post_status' => 'publish',
            'post_type' => 'page',
            'post_author' => 1,
        );
        $car_accessories_form_id = wp_insert_post($car_accessories_form_data);
        
        if ($car_accessories_form_id) {
            update_post_meta($car_accessories_form_id, '_wp_page_template', 'page-car-accessories-form.php');
            flush_rewrite_rules(false);
        }
    }
    
    // Ensure Service Book Form page exists (check on admin pages load)
    $service_book_form_check = get_page_by_path('service-book-form');
    if (!$service_book_form_check) {
        $service_book_form_data = array(
            'post_title' => 'Service Book Form',
            'post_name' => 'service-book-form',
            'post_content' => 'Enter information about your car\'s service records.',
            'post_status' => 'publish',
            'post_type' => 'page',
            'post_author' => 1,
        );
        $service_book_form_id = wp_insert_post($service_book_form_data);
        
        if ($service_book_form_id) {
            update_post_meta($service_book_form_id, '_wp_page_template', 'page-service-book-form.php');
            flush_rewrite_rules(false);
        }
    }
    
    // Ensure Previous Service Form page exists (check on admin pages load)
    $previous_service_form_check = get_page_by_path('previous-service-form');
    if (!$previous_service_form_check) {
        $previous_service_form_data = array(
            'post_title' => 'Previous Service Form',
            'post_name' => 'previous-service-form',
            'post_content' => 'Enter details about your car\'s previous service records.',
            'post_status' => 'publish',
            'post_type' => 'page',
            'post_author' => 1,
        );
        $previous_service_form_id = wp_insert_post($previous_service_form_data);
        
        if ($previous_service_form_id) {
            update_post_meta($previous_service_form_id, '_wp_page_template', 'page-previous-service-form.php');
            flush_rewrite_rules(false);
        }
    }
    
    // Service form pages array
    $service_forms = array(
        array(
            'slug' => 'all-services-form',
            'title' => 'All Services Form',
            'template' => 'page-all-services-form.php',
            'content' => 'Request a comprehensive service for your vehicle.',
        ),
    );
    
    // Ensure all service form pages exist
    foreach ($service_forms as $form) {
        $form_check = get_page_by_path($form['slug']);
        if (!$form_check) {
            $form_data = array(
                'post_title' => $form['title'],
                'post_name' => $form['slug'],
                'post_content' => $form['content'],
                'post_status' => 'publish',
                'post_type' => 'page',
                'post_author' => 1,
            );
            $form_id = wp_insert_post($form_data);
            
            if ($form_id) {
                update_post_meta($form_id, '_wp_page_template', $form['template']);
                flush_rewrite_rules(false);
            }
        }
    }
}, 1);

/**
 * Enqueue Scripts and Styles
 */
function wheelfy_scripts() {
    $theme_version = wp_get_theme()->get('Version');
    
    // Enqueue Google Fonts
    wp_enqueue_style(
        'wheelfy-fonts',
        'https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap',
        array(),
        null
    );
    
    // Enqueue compiled CSS
    wp_enqueue_style(
        'wheelfy-style',
        get_template_directory_uri() . '/dist/style.css',
        array('wheelfy-fonts'),
        $theme_version
    );

    // Enqueue theme JavaScript
    wp_enqueue_script(
        'wheelfy-script',
        get_template_directory_uri() . '/js/main.js',
        array(),
        $theme_version,
        true
    );

    // Localize script for AJAX
    wp_localize_script('wheelfy-script', 'wheelfy', array(
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('wheelfy_nonce'),
        'themeUrl' => get_template_directory_uri(),
        'userId' => get_current_user_id(),
    ));
    
    // Add dynamic header CSS from CMB2 settings
    $header_css = wheelfy_get_dynamic_header_css();
    if ($header_css) {
        wp_add_inline_style('wheelfy-style', $header_css);
    }
    
    // Add dynamic footer CSS from CMB2 settings
    $footer_css = wheelfy_get_dynamic_footer_css();
    if ($footer_css) {
        wp_add_inline_style('wheelfy-style', $footer_css);
    }
    
    // Add custom CSS for header widgets and navigation
    wp_add_inline_style('wheelfy-style', '
        /* Hero Section Title - Responsive Sizing */
        .hero-title {
            font-weight: 700 !important;
            font-size: 42px !important;
            line-height: 1.2 !important;
        }
        
        @media (min-width: 768px) {
            .hero-title {
                font-size: 50px !important;
                font-weight: 700 !important;
                line-height: 1.2 !important;
            }
        }
        
        @media (min-width: 1024px) {
            .hero-title {
                font-size: 65px !important;
                font-weight: 700 !important;
                line-height: 1.2 !important;
            }
        }
        
        /* Section Title - Responsive Sizing */
        .section-title {
            font-weight: 700 !important;
            font-size: 36px !important;
            line-height: 1.2 !important;
        }
        
        /* H2 Section Title - Phone Device */
        h2.section-title {
            font-size: 32px !important;
            font-weight: 700 !important;
            line-height: 1.2 !important;
        }
        
        @media (min-width: 768px) {
            .section-title {
                font-size: 45px !important;
            }
            
            h2.section-title {
                font-size: 40px !important;
                font-weight: 700 !important;
                line-height: 1.2 !important;
            }
        }
        
        @media (min-width: 1024px) {
            .section-title {
                font-size: 55px !important;
            }
            
            h2.section-title {
                font-size: 45px !important;
                font-weight: 700 !important;
                line-height: 1.2 !important;
            }
        }
        
        /* Ensure h2 on phone is 32px even without section-title class */
        @media (max-width: 767px) {
            h2:not(.hero-title) {
                font-size: 32px !important;
            }
        }
        
        /* Header - Professional Modern Styling */
        header {
            background-color: #1a1d2e !important;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05) !important;
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1) !important;
            z-index: 9999 !important; /* Ensure header is always on top on all pages */
        }
        
        /* Fix: Ensure desktop header shows at 1024px+ and mobile hides */
        /* Override hidden class specifically for desktop header at 1024px+ */
        @media (min-width: 1024px) {
            header .desktop-header-layout.hidden.lg\:grid,
            header .desktop-header-layout.hidden,
            .desktop-header-layout.hidden.lg\:grid,
            .desktop-header-layout {
                display: grid !important;
                visibility: visible !important;
                opacity: 1 !important;
            }
            header .mobile-header-layout.lg\:hidden,
            header .mobile-header-layout,
            .mobile-header-layout.lg\:hidden,
            .mobile-header-layout {
                display: none !important;
                visibility: hidden !important;
            }
            #mobile-menu,
            #mobile-menu-overlay {
                display: none !important;
                visibility: hidden !important;
            }
        }
        
        /* Ensure mobile header shows below 1024px */
        @media (max-width: 1023px) {
            header .desktop-header-layout,
            .desktop-header-layout {
                display: none !important;
                visibility: hidden !important;
            }
            header .mobile-header-layout,
            .mobile-header-layout {
                display: flex !important;
                visibility: visible !important;
            }
            
            /* Ensure mobile menu is hidden off-screen by default */
            #mobile-menu {
                transform: translateX(100%) !important;
                visibility: visible !important; /* Visible for animation, but off-screen */
            }
            
            /* Prevent horizontal scroll on mobile */
            html, body {
                overflow-x: hidden !important;
                max-width: 100vw !important;
                width: 100% !important;
            }
        }
        
        /* Header Dashboard Dropdown Menu */
        header .relative button[onclick*="toggleHeaderDropdown"] {
            position: relative;
            color: #ffffff !important;
            font-size: 0.9375rem !important;
            font-weight: 500 !important;
            padding: 0.5rem 1rem !important;
            border-radius: 0.375rem !important;
            transition: all 0.2s ease !important;
            background: transparent !important;
            border: none !important;
        }
        header .relative button[onclick*="toggleHeaderDropdown"]:hover {
            background: linear-gradient(135deg, #fdfd96, #0a5159) !important;
            -webkit-background-clip: text !important;
            -webkit-text-fill-color: transparent !important;
            background-clip: text !important;
            background-color: rgba(255, 255, 255, 0.05) !important;
        }
        header .relative button[onclick*="toggleHeaderDropdown"]:hover svg {
            color: #fdfd96 !important;
        }
        header #header-menu {
            background: #1a1d2e !important;
            border: 1px solid rgba(255,255,255,0.1) !important;
            box-shadow: 0 10px 30px rgba(0,0,0,0.5) !important;
            z-index: 1000 !important;
        }
        header #header-menu a {
            color: #ffffff !important;
            transition: all 0.2s ease !important;
        }
        header #header-menu a:hover {
            background: rgba(255,255,255,0.1) !important;
            color: #fdfd96 !important;
        }
        header #header-menu-icon {
            transition: transform 0.2s ease;
        }

        /* Header Navigation - White text, brand color for active */
        header nav .button-nav,
        header nav .menu-item a,
        header nav a.button-nav,
        header nav ul li a {
            color: #ffffff !important;
            font-size: 0.9375rem !important;
            font-weight: 500 !important;
            padding: 0.5rem 0.75rem !important;
            border-radius: 0.375rem !important;
            transition: all 0.2s ease !important;
        }
        
        header nav .button-nav:hover,
        header nav .menu-item a:hover,
        header nav a.button-nav:hover {
            background: linear-gradient(135deg, #fdfd96, #0a5159) !important;
            -webkit-background-clip: text !important;
            -webkit-text-fill-color: transparent !important;
            background-clip: text !important;
            /* Removed background-color hover effect */
        }
        
        /* Active/Current Menu Item - Brand Color (Yellow to Green Gradient) */
        header nav .current-menu-item a,
        header nav .current-page-item a,
        header nav .menu-item.current-menu-item > a,
        header nav .menu-item.current-page-item > a,
        header nav .active a,
        header nav a.bg-primary\/10.text-primary,
        header nav .button-nav.bg-primary\/10.text-primary,
        header nav .current-menu-item .button-nav,
        header nav .current-page-item .button-nav {
            color: #fdfd96 !important; /* Fallback for browsers without gradient support */
            background: linear-gradient(135deg, #fdfd96, #0a5159) !important;
            -webkit-background-clip: text !important;
            -webkit-text-fill-color: transparent !important;
            background-clip: text !important;
            background-color: rgba(253, 253, 150, 0.1) !important;
        }
        
        /* Header Buttons - Professional Styling */
        header .button-hero {
            background: linear-gradient(135deg, #fdfd96, #0a5159) !important;
            color: #1a1d2e !important;
            font-weight: 600 !important;
            padding: 0.625rem 1.5rem !important;
            border-radius: 0.5rem !important;
            font-size: 1rem !important;
            transition: all 0.3s ease !important;
            box-shadow: 0 4px 12px rgba(253, 253, 150, 0.2) !important;
        }
        
        header .button-hero:hover {
            transform: translateY(-1px) !important;
            box-shadow: 0 6px 16px rgba(253, 253, 150, 0.3) !important;
        }
        
        header a[href*="login"] {
            color: #ffffff !important;
            font-weight: 500 !important;
            padding-top: 0.4rem !important;
            border-radius: 0.5rem !important;
            transition: all 0.2s ease !important;
        }
        
        header a[href*="login"]:hover {
            color: #fdfd96 !important;
        }
        
        /* Language Select Dropdown Styling */
        header #language-select {
            min-width: 4rem;
            background-color: transparent !important;
            color: #ffffff !important;
        }
        
        header #language-select option {
            background-color: #1a1d2e !important;
            color: #ffffff !important;
        }
        
        header #language-select:focus {
            outline: none !important;
            border-color: #fdfd96 !important;
        }
        
        /* GTranslate Widget Styling */
        header .header-language-switcher .gt_selector,
        header .header-language-switcher .goog-te-combo {
            background-color: transparent !important;
            border: 1px solid rgba(255, 255, 255, 0.2) !important;
            border-radius: 0.5rem !important;
            color: #ffffff !important;
            padding: 0.5rem 0.75rem !important;
            font-size: 0.9375rem !important;
            font-weight: 500 !important;
            cursor: pointer !important;
            min-width: 120px !important;
        }
        
        header .header-language-switcher .gt_selector:focus,
        header .header-language-switcher .goog-te-combo:focus {
            outline: none !important;
            border-color: #fdfd96 !important;
        }
        
        header .header-language-switcher .gt_selector option,
        header .header-language-switcher .goog-te-combo option {
            background-color: #1a1d2e !important;
            color: #ffffff !important;
        }
        
        /* Ensure GTranslate shows selected value */
        header .header-language-switcher .gt_selector[value],
        header .header-language-switcher .goog-te-combo[value] {
            color: #ffffff !important;
        }
        
        /* Hide GTranslate branding if needed */
        header .header-language-switcher .goog-te-gadget-simple {
            background-color: transparent !important;
            border: none !important;
        }
        
        header .header-language-switcher .goog-te-gadget-simple .goog-te-menu-value {
            color: #ffffff !important;
        }
        
        /* Hide hamburger menu on desktop */
        @media (min-width: 1024px) {
            header .lg\\:hidden,
            header .mobile-menu-btn,
            header #mobile-menu-toggle,
            header [id="mobile-menu-toggle"] {
                display: none !important;
                visibility: hidden !important;
                opacity: 0 !important;
            }
        }
        
        /* Brand Color Gradient Utility */
        .brand-gradient {
            background: linear-gradient(135deg, #fdfd96, #0a5159) !important;
            -webkit-background-clip: text !important;
            -webkit-text-fill-color: transparent !important;
            background-clip: text !important;
        }
        
        .brand-gradient-bg {
            background: linear-gradient(135deg, #fdfd96, #0a5159) !important;
        }
        
        /* Learn More Button Styling */
        .button.button-hero {
            padding: 0.875rem 1.75rem !important;
            min-height: 3rem;
            display: inline-flex !important;
            align-items: center !important;
            justify-content: center !important;
            gap: 0.5rem;
            border-radius: 0.5rem;
            font-size: 1rem !important;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        
        .button.button-hero:hover {
            transform: translateY(-2px);
        }
        
        /* Standardize All Button Text Sizes */
        .button,
        .button-hero,
        .button-hero-outline,
        .button-nav,
        .button-sm,
        .button-lg,
        .button-xl,
        a.button,
        button.button {
            font-size: 1rem !important;
        }
        
        /* Override any inline text size classes on buttons */
        .button.text-sm,
        .button-hero.text-sm,
        .button-hero-outline.text-sm,
        .button.text-base,
        .button-hero.text-base,
        .button-hero-outline.text-base,
        .button.text-lg,
        .button-hero.text-lg,
        .button-hero-outline.text-lg {
            font-size: 1rem !important;
        }
        
        /* How It Works - Step Numbers Brand Color */
        .brand-gradient-number {
            background: linear-gradient(135deg, hsl(60 96% 79% / 0.4), hsl(186 80% 19% / 0.4)) !important;
            -webkit-background-clip: text !important;
            background-clip: text !important;
            -webkit-text-fill-color: transparent !important;
            color: hsl(60 96% 79%) !important;
            opacity: 0.8 !important;
        }
        
        /* Desktop Header Layout - 3 columns: Logo | Menu | Buttons - All in One Line */
        header.desktop-header .desktop-header-layout {
            display: grid !important;
            grid-template-columns: 1fr 2fr 1fr !important;
            width: 100% !important;
        }
        
        header.desktop-header {
            height: 80px !important;
            min-height: 80px !important;
        }
        
        /* IMPORTANT: Use min-width: 1024px to include 1024px for desktop layout */
        @media (min-width: 1024px) {
            header.desktop-header {
                height: 80px !important;
                min-height: 80px !important;
            }
            
            /* Equal top and bottom padding - Same spacing */
            header.desktop-header .desktop-header-nav {
                padding-top: 1.25rem !important;
                padding-bottom: 1.25rem !important;
                padding-left: 2rem !important;
                padding-right: 2rem !important;
            }
            
            /* Header Container - Fixed max-width 1400px for all pages */
            header.desktop-header .desktop-header-nav.container,
            header .desktop-header-nav.container {
                max-width: 1400px !important;
                width: 100% !important;
                margin-left: auto !important;
                margin-right: auto !important;
            }
        }
        
        /* Force hide desktop menu on mobile */
        /* IMPORTANT: Use max-width: 1023px to exclude 1024px, so 1024px uses desktop layout */
        @media (max-width: 1023px) {
            header.header-mobile {
                height: 60px !important;
                min-height: 60px !important;
            }
            
            header.header-mobile nav {
                padding: 0.5rem 1rem !important;
            }
            
            /* Hide desktop layout completely on mobile */
            header.header-mobile .desktop-header-layout {
                display: none !important;
                visibility: hidden !important;
                opacity: 0 !important;
                height: 0 !important;
                overflow: hidden !important;
            }
            
            /* Show mobile layout */
            header.header-mobile .mobile-header-layout {
                display: flex !important;
                visibility: visible !important;
                opacity: 1 !important;
            }
            
            /* Logo on Mobile */
            header.header-mobile .h-8,
            header.header-mobile img.h-8 {
                height: 2rem !important;
                max-height: 2rem !important;
            }
            
            /* Hero Title Responsive */
            .hero-section-sticky h1,
            section:first-of-type h1 {
                font-size: 2rem !important;
                line-height: 2.25rem !important;
            }
        }
        
        /* Force hide mobile menu on desktop */
        /* IMPORTANT: Use min-width: 1024px to include 1024px for desktop layout */
        @media (min-width: 1024px) {
            header .mobile-header-layout {
                display: none !important;
                visibility: hidden !important;
                opacity: 0 !important;
                height: 0 !important;
                overflow: hidden !important;
            }
            
            /* Show desktop layout - override hidden class */
            header .desktop-header-layout,
            header .desktop-header-layout.hidden,
            header .desktop-header-layout.hidden.lg\:grid {
                display: grid !important;
                visibility: visible !important;
                opacity: 1 !important;
                height: auto !important;
                overflow: visible !important;
            }
        }
        
        @media (max-width: 640px) {
            .hero-section-sticky h1:not(.hero-title),
            section:first-of-type h1:not(.hero-title) {
                font-size: 1.75rem !important;
                line-height: 2rem !important;
            }
            
            /* Ensure hero-title overrides any other rules */
            .hero-title,
            h1.hero-title,
            .hero-section-sticky h1.hero-title,
            section:first-of-type h1.hero-title {
                font-size: 42px !important;
                line-height: 1.2 !important;
                font-weight: 700 !important;
            }
        }
        
        /* Mobile Menu Offcanvas Styling - Full Screen Black Background */
        #mobile-menu-overlay {
            z-index: 40 !important;
            opacity: 0 !important;
            visibility: hidden !important;
            transition: opacity 0.3s ease-in-out, visibility 0.3s ease-in-out !important;
        }
        
        /* Overlay visible when menu is open */
        #mobile-menu-overlay:not(.hidden) {
            opacity: 1 !important;
            visibility: visible !important;
        }
        
        /* Prevent horizontal scroll globally */
        html, body {
            overflow-x: hidden !important;
            max-width: 100vw !important;
            width: 100% !important;
        }
        
        /* Lock body when menu is open */
        body.menu-open {
            overflow: hidden !important;
            position: fixed !important;
            width: 100% !important;
            max-width: 100vw !important;
        }
        
        #mobile-menu {
            z-index: 50 !important;
            will-change: transform !important;
            background-color: #000000 !important;
            background: #000000 !important;
            /* Menu width - 85vw on mobile, max 400px */
            width: 85vw !important;
            max-width: 400px !important;
            height: 100vh !important;
            min-height: 100vh !important;
            max-height: 100vh !important;
            /* Position from right, off-screen by default */
            position: fixed !important;
            top: 0 !important;
            right: 0 !important;
            bottom: 0 !important;
            left: auto !important;
            overflow-y: auto !important;
            overflow-x: hidden !important;
            /* Start off-screen to the right */
            transform: translateX(100%) !important;
            transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1) !important;
            /* Box shadow for depth */
            box-shadow: -4px 0 20px rgba(0, 0, 0, 0.3) !important;
        }
        
        /* Ensure menu stays off-screen when closed */
        #mobile-menu:not(.translate-x-0) {
            transform: translateX(100%) !important;
        }
        
        /* Menu when open - slide in */
        #mobile-menu.translate-x-0 {
            transform: translateX(0) !important;
        }
        
        /* Ensure main container has black background and full height */
        #mobile-menu > div {
            background-color: #000000 !important;
            background: #000000 !important;
            width: 100% !important;
            max-width: 100% !important;
            height: 100vh !important;
            min-height: 100vh !important;
            max-height: 100vh !important;
            box-sizing: border-box !important;
            overflow-y: auto !important;
            overflow-x: hidden !important;
        }
        
        /* Ensure all child elements have black background */
        #mobile-menu * {
            background-color: #000000 !important;
        }
        
        /* Navigation and borders - transparent on black */
        #mobile-menu nav {
            background-color: transparent !important;
        }
        
        #mobile-menu .border-b,
        #mobile-menu .border-t {
            background-color: transparent !important;
            border-color: rgba(255, 255, 255, 0.1) !important;
        }
        
        /* Text elements should remain visible */
        #mobile-menu span,
        #mobile-menu a,
        #mobile-menu button,
        #mobile-menu li,
        #mobile-menu ul {
            background-color: transparent !important;
        }
        
        /* But keep the main container black */
        #mobile-menu > div {
            background-color: #000000 !important;
        }
        
        /* These are handled above, but keep for specificity */
        #mobile-menu.translate-x-full {
            transform: translateX(100%) !important;
        }
        
        #mobile-menu.translate-x-0 {
            transform: translateX(0) !important;
        }
        
        #mobile-menu .mobile-menu-list {
            display: flex !important;
            flex-direction: column !important;
            gap: 0.25rem !important;
            list-style: none !important;
            margin: 0 !important;
            padding: 0 !important;
        }
        
        #mobile-menu .menu-item {
            width: 100% !important;
        }
        
        #mobile-menu .menu-item > a {
            display: flex !important;
            align-items: center !important;
            width: 100% !important;
            padding: 0.875rem 1rem !important;
            color: #ffffff !important;
            font-size: 1rem !important;
            font-weight: 500 !important;
            border-radius: 0.5rem !important;
            transition: all 0.2s ease !important;
            text-decoration: none !important;
        }
        
        #mobile-menu .menu-item > a:hover {
            background-color: rgba(255, 255, 255, 0.05) !important;
            color: #fdfd96 !important;
        }
        
        /* Active/Current Menu Item - Highlighted */
        #mobile-menu .menu-item.current-menu-item > a,
        #mobile-menu .menu-item.current-page-item > a {
            background-color: rgba(253, 253, 150, 0.15) !important;
            color: #fdfd96 !important;
        }
        
        /* Submenu Items (Services) */
        #mobile-menu .sub-menu {
            display: block !important;
            margin-left: 1.5rem !important;
            margin-top: 0.25rem !important;
            padding-left: 0 !important;
            list-style: none !important;
        }
        
        #mobile-menu .sub-menu .menu-item > a {
            padding-left: 2.5rem !important;
            font-size: 0.9375rem !important;
            color: rgba(255, 255, 255, 0.8) !important;
        }
        
        #mobile-menu .sub-menu .menu-item > a::before {
            content: "" !important;
            position: absolute !important;
            left: 1rem !important;
            width: 0.375rem !important;
            height: 0.375rem !important;
            border-radius: 50% !important;
            background-color: rgba(255, 255, 255, 0.4) !important;
        }
        
        /* Mobile Menu Button - Professional Styling with Brand Colors */
        .mobile-menu-btn {
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
            cursor: pointer !important;
            padding: 0.625rem !important;
            background: linear-gradient(135deg, #fdfd96, #0a5159) !important;
            border-radius: 0.5rem !important;
            border: none !important;
            color: #fdfd96 !important;
            position: relative !important;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1) !important;
            width: 2.5rem !important;
            height: 2.5rem !important;
        }
        
        .mobile-menu-btn:hover {
            box-shadow: 0 0 20px rgba(253, 253, 150, 0.4), 0 0 40px rgba(253, 253, 150, 0.2) !important;
            transform: scale(1.05) !important;
        }
        
        .mobile-menu-btn:active {
            transform: scale(0.95) !important;
        }
        
        .mobile-menu-btn .hamburger-icon {
            width: 1.5rem !important;
            height: 1.5rem !important;
            color: #1a1d2e !important;
            stroke: #1a1d2e !important;
            transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1) !important;
        }
        
        .mobile-menu-btn:hover .hamburger-icon {
            transform: rotate(90deg) !important;
        }
        
        .mobile-menu-btn #close-icon.hamburger-icon {
            transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1) !important;
        }
        
        .mobile-menu-btn:hover #close-icon.hamburger-icon {
            transform: rotate(90deg) !important;
        }
        
        /* Ensure SVG maintains aspect ratio */
        .mobile-menu-btn svg {
            width: 1.5rem !important;
            height: 1.5rem !important;
            flex-shrink: 0 !important;
        }
        
        .mobile-menu-btn svg path {
            transition: stroke-width 0.3s ease !important;
        }
        
        .mobile-menu-btn:hover svg path {
            stroke-width: 3 !important;
        }
        
        .mobile-menu-close {
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
            cursor: pointer !important;
            color: #ffffff !important;
        }
        
        .mobile-menu-close svg {
            color: #ffffff !important;
            stroke: #ffffff !important;
        }
        
        .mobile-menu-close:hover {
            color: #ffffff !important;
        }
        
        /* Mobile Menu Login Link - Match Menu Items Styling */
        #mobile-menu .pb-4 a[href*="login"],
        #mobile-menu a[href*="login"] {
            display: flex !important;
            align-items: center !important;
            width: 100% !important;
            padding: 0.875rem 1rem !important;
            color: #ffffff !important;
            font-size: 1rem !important;
            font-weight: 500 !important;
            border-radius: 0.5rem !important;
            transition: all 0.2s ease !important;
            text-decoration: none !important;
            margin: 0 !important;
        }
        
        #mobile-menu .pb-4 a[href*="login"]:hover,
        #mobile-menu a[href*="login"]:hover {
            background-color: rgba(255, 255, 255, 0.05) !important;
            color: #fdfd96 !important;
        }
        
        .mobile-menu-close:hover svg {
            color: #ffffff !important;
            stroke: #ffffff !important;
        }
        
        /* Prevent body scroll when menu is open */
        body.menu-open {
            overflow: hidden !important;
            position: fixed !important;
            width: 100% !important;
            height: 100% !important;
        }
        
        /* Ensure main content does not interfere with mobile menu */
        body.menu-open #main-content {
            pointer-events: none !important;
        }
        
        /* Header Spacer Adjustment */
        @media (max-width: 1024px) {
            .header-spacer {
                height: 60px !important;
            }
        }
        
        /* Center column - Navigation Menu */
        header nav .grid > div:nth-child(2) {
            display: flex !important;
            justify-content: center !important;
            align-items: center !important;
            width: 100% !important;
        }
        
        /* Right column - Buttons */
        header nav .grid > div:nth-child(3) {
            display: flex !important;
            justify-content: flex-end !important;
            align-items: center !important;
            gap: 0.75rem !important;
        }
        
        /* Logo Container */
        header nav .grid > div:first-child {
            display: flex !important;
            align-items: center !important;
        }
        
        /* Menu Items Spacing */
        header nav ul.menu,
        header nav ul.flex {
            gap: 0.25rem !important;
        }
        
        header nav .menu-item a {
            padding: 0.5rem 0.875rem !important;
            margin: 0 !important;
        }
        
        .header-widget-area {
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }
        
        .header-widget-area .widget {
            margin: 0;
            padding: 0;
        }
        
        .header-widget-area .widget-title {
            display: none;
        }
        
        .header-widget-area .widget ul {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }
        
        /* Modern Home Page Enhancements */
        .home section {
            position: relative;
        }
        
        .home [data-animate] {
            opacity: 0;
        }
        
        .home [data-animate].animate-fade-in-up {
            opacity: 1;
        }
        
        /* Universal Card Hover Effect - Applied to All Cards (Brand Gradient Border on Hover) */
        .card-hover-smooth,
        .service-card,
        .bg-card[class*="border"],
        article[class*="border"] {
            position: relative !important;
            transition: box-shadow 0.5s cubic-bezier(0.4, 0, 0.2, 1) !important;
            will-change: box-shadow;
            border-width: 1px !important;
            border-style: solid !important;
            border-color: rgba(255, 255, 255, 0.1) !important;
        }
        
        .card-hover-smooth::before,
        .service-card::before,
        .bg-card[class*="border"]::before,
        article[class*="border"]::before {
            content: "" !important;
            position: absolute !important;
            inset: -1px !important;
            border-radius: inherit !important;
            background: linear-gradient(135deg, #fdfd96, #0a5159) !important;
            opacity: 0 !important;
            transition: opacity 0.5s cubic-bezier(0.4, 0, 0.2, 1) !important;
            pointer-events: none !important;
            z-index: -1 !important;
        }
        
        .card-hover-smooth::after,
        .service-card::after,
        .bg-card[class*="border"]::after,
        article[class*="border"]::after {
            content: "" !important;
            position: absolute !important;
            inset: 0 !important;
            border-radius: inherit !important;
            background: inherit !important;
            z-index: -1 !important;
        }
        
        .card-hover-smooth:hover::before,
        .service-card:hover::before,
        .bg-card[class*="border"]:hover::before,
        article[class*="border"]:hover::before {
            opacity: 1 !important;
        }
        
        .card-hover-smooth:hover,
        .service-card:hover,
        .bg-card[class*="border"]:hover,
        article[class*="border"]:hover {
            border-color: transparent !important;
            box-shadow: 0 10px 30px -5px rgba(253, 253, 150, 0.3), 
                        0 10px 30px -5px rgba(10, 81, 89, 0.2),
                        0 0 0 1px rgba(253, 253, 150, 0.2) !important;
        }
        
        
        
        /* Smooth Image Zoom */
        .service-card-image {
            transition: transform 0.8s cubic-bezier(0.25, 0.46, 0.45, 0.94) !important;
            will-change: transform !important;
        }
        
        .service-card:hover .service-card-image {
            transform: scale(1.1) !important;
        }
        
        /* Smooth Gradient Overlay */
        .service-card-overlay {
            transition: background 0.6s cubic-bezier(0.4, 0, 0.2, 1) !important;
        }
        
        .service-card:hover .service-card-overlay {
            background: linear-gradient(to top, 
                hsl(var(--background)) 0%, 
                hsl(var(--background) / 0.9) 50%, 
                hsl(var(--background) / 0.4) 100%) !important;
        }
        
        /* Smooth Title Color Change */
        .service-card-title {
            transition: color 0.4s cubic-bezier(0.4, 0, 0.2, 1) !important;
        }
        
        .service-card:hover .service-card-title {
            color: hsl(var(--primary)) !important;
        }
        
        /* Smooth Feature Badge Animations */
        .service-card-feature {
            transition: background-color 0.4s cubic-bezier(0.4, 0, 0.2, 1),
                        border-color 0.4s cubic-bezier(0.4, 0, 0.2, 1) !important;
        }
        
        .service-card:hover .service-card-feature {
            background-color: hsl(var(--primary) / 0.1) !important;
            border-color: hsl(var(--primary) / 0.3) !important;
        }
        
        /* Smooth Icon Animation */
        .service-card:hover .w-16.h-16 {
            transform: scale(1.1) !important;
        }
        
        .service-card .w-16.h-16 {
            transition: transform 0.4s cubic-bezier(0.34, 1.56, 0.64, 1) !important;
        }
        
        /* Consistent Section Spacing */
        .section-spacing {
            padding-top: 6rem !important;
            padding-bottom: 6rem !important;
        }
        
        @media (max-width: 768px) {
            .section-spacing {
                padding-top: 4rem !important;
                padding-bottom: 4rem !important;
            }
        }
        
        /* Smooth Icon Animations */
        .card-hover-smooth .group-hover\:scale-110,
        .services-section .group-hover\:scale-110 {
            transition: transform 0.4s cubic-bezier(0.34, 1.56, 0.64, 1) !important;
        }
        
        /* Smooth Text Color Transitions */
        .card-hover-smooth .group-hover\:text-primary,
        .services-section .group-hover\:text-primary {
            transition: color 0.3s ease-in-out !important;
        }
        
        
        /* Modern Card Shadows */
        .home .bg-card\/80 {
            background-color: hsl(var(--card) / 0.8) !important;
        }
        
        .home .backdrop-blur-sm {
            backdrop-filter: blur(8px) !important;
            -webkit-backdrop-filter: blur(8px) !important;
        }
        
        .home .backdrop-blur-md {
            backdrop-filter: blur(12px) !important;
            -webkit-backdrop-filter: blur(12px) !important;
        }
        
        /* Enhanced Hover Effects */
        .home .hover\:-translate-y-2:hover {
            transform: translateY(-0.5rem) !important;
        }
        
        .home .hover\:scale-110:hover {
            transform: scale(1.1) !important;
        }
        
        .home .hover\:scale-105:hover {
            transform: scale(1.05) !important;
        }
        
        /* Modern Shadow Effects */
        .home .shadow-primary\/10 {
            box-shadow: 0 10px 40px -10px hsl(60 96% 79% / 0.1) !important;
        }
        
        .home .shadow-primary\/20 {
            box-shadow: 0 10px 40px -10px hsl(60 96% 79% / 0.2) !important;
        }
        
        .home .shadow-primary\/30 {
            box-shadow: 0 20px 60px -15px hsl(60 96% 79% / 0.3) !important;
        }
        
        .home .shadow-primary\/40 {
            box-shadow: 0 25px 70px -15px hsl(60 96% 79% / 0.4) !important;
        }
        
        .header-widget-area .widget li {
            list-style: none;
            margin: 0;
            padding: 0;
        }
        
        .header-widget-area-mobile {
            margin-bottom: 0.5rem;
        }
        
        .header-widget-area-mobile .widget {
            margin-bottom: 0.5rem;
        }
        
        .header-widget-area-mobile .widget:last-child {
            margin-bottom: 0;
        }
        
        /* Footer List Styles - Remove all bullets and dots */
        footer ul {
            list-style: none !important;
            padding-left: 0 !important;
            margin-left: 0 !important;
        }
        
        footer li {
            list-style: none !important;
            padding-left: 0 !important;
            margin-left: 0 !important;
        }
        
        footer ul li::before {
            content: none !important;
            display: none !important;
        }
        
        footer ul li::marker {
            display: none !important;
            content: none !important;
        }
        
        /* Footer widget area lists */
        footer .widget ul,
        footer .widget ul li {
            list-style: none !important;
            padding-left: 0 !important;
            margin-left: 0 !important;
        }
        
        /* Footer Navigation Menu Widget - Vertical Display */
        footer .widget_nav_menu .menu,
        footer .widget_nav_menu .menu-container,
        footer .widget_nav_menu ul.menu,
        footer .widget_nav_menu .menu-footer-menu-1-container,
        footer .widget_nav_menu .menu-footer-menu-1-container ul,
        footer .widget_nav_menu .menu-footer-menu-2-container,
        footer .widget_nav_menu .menu-footer-menu-2-container ul {
            display: block !important;
            flex-direction: column !important;
            list-style: none !important;
            padding-left: 0 !important;
            margin-left: 0 !important;
        }
        
        footer .widget_nav_menu .menu li,
        footer .widget_nav_menu .menu-item,
        footer .widget_nav_menu ul.menu li {
            display: block !important;
            width: 100% !important;
            float: none !important;
            margin-bottom: 0.75rem !important;
            list-style: none !important;
            padding-left: 0 !important;
            margin-left: 0 !important;
        }
        
        footer .widget_nav_menu .menu li a,
        footer .widget_nav_menu .menu-item a,
        footer .widget_nav_menu ul.menu li a {
            display: block !important;
            width: 100% !important;
            color: var(--muted-foreground) !important;
            transition: color 0.2s ease !important;
        }
        
        footer .widget_nav_menu .menu li a:hover,
        footer .widget_nav_menu .menu-item a:hover,
        footer .widget_nav_menu ul.menu li a:hover {
            color: var(--primary) !important;
        }
        
        /* Hide widget title if needed (optional) */
        footer .widget_nav_menu .widget-title {
            font-size: 24px !important;
            font-weight: 500 !important;
            margin-bottom: 1rem !important;
        }
        
        /* Footer Menu Two Widget Area Styling */
        footer #footer-menu-two .widget,
        footer #footer-menu-two .widget ul,
        footer #footer-menu-two .menu,
        footer #footer-menu-two .menu-container,
        footer #footer-menu-two .menu-container ul,
        footer #footer-menu-two .menu-footer-menue-2-container,
        footer #footer-menu-two .menu-footer-menue-2-container ul {
            list-style: none !important;
            padding-left: 0 !important;
            margin-left: 0 !important;
            margin-bottom: 0 !important;
            display: block !important;
            flex-direction: column !important;
        }
        
        footer #footer-menu-two .widget ul li,
        footer #footer-menu-two .menu li,
        footer #footer-menu-two .menu-item {
            list-style: none !important;
            padding-left: 0 !important;
            margin-left: 0 !important;
            margin-bottom: 0.75rem !important;
            display: block !important;
            width: 100% !important;
            float: none !important;
        }
        
        footer #footer-menu-two .widget ul li a,
        footer #footer-menu-two .menu li a,
        footer #footer-menu-two .menu-item a {
            display: block !important;
            color: var(--muted-foreground) !important;
            transition: color 0.2s ease !important;
            width: 100% !important;
            font-size: 16px !important;
        }
        
        footer #footer-menu-two .widget ul li a:hover,
        footer #footer-menu-two .menu li a:hover,
        footer #footer-menu-two .menu-item a:hover {
            color: var(--primary) !important;
        }
        
        /* Footer Menu Two Widget Title - Match other column headings */
        footer #footer-menu-two .widget-title,
        footer #footer-menu-two h3.widget-title {
            font-size: 24px !important;
            font-weight: 500 !important;
            line-height: 1.2 !important;
            margin-bottom: 1rem !important;
            color: var(--foreground) !important;
        }
        
        /* Quick Links Widget Area Styling */
        footer #quick-links-widget-area .widget,
        footer #quick-links-widget-area .widget ul,
        footer #quick-links-widget-area .menu,
        footer #quick-links-widget-area .menu-main-menu-container,
        footer #quick-links-widget-area .menu-main-menu-container ul {
            list-style: none !important;
            padding-left: 0 !important;
            margin-left: 0 !important;
            margin-bottom: 0 !important;
            display: block !important;
            flex-direction: column !important;
        }
        
        footer #quick-links-widget-area .widget ul li,
        footer #quick-links-widget-area .menu li,
        footer #quick-links-widget-area .menu-item {
            list-style: none !important;
            padding-left: 0 !important;
            margin-left: 0 !important;
            margin-bottom: 0.75rem !important;
            display: block !important;
            width: 100% !important;
            float: none !important;
        }
        
        footer #quick-links-widget-area .widget ul li a,
        footer #quick-links-widget-area .menu li a,
        footer #quick-links-widget-area .menu-item a {
            display: block !important;
            color: var(--muted-foreground) !important;
            transition: color 0.2s ease !important;
            width: 100% !important;
        }
        
        footer #quick-links-widget-area .widget ul li a:hover,
        footer #quick-links-widget-area .menu li a:hover,
        footer #quick-links-widget-area .menu-item a:hover {
            color: var(--primary) !important;
        }
        
        footer #quick-links-widget-area .widget-title,
        footer #quick-links-widget-area h2.wp-block-heading:empty {
            display: none !important;
        }
        
        /* Hide empty h2 headings in Quick Links widget area */
        footer #quick-links-widget-area h2.wp-block-heading:empty {
            display: none !important;
            height: 0 !important;
            margin: 0 !important;
            padding: 0 !important;
        }
        
        /* Force vertical layout for flex containers in Quick Links */
        footer #quick-links-widget-area .wp-block-group,
        footer #quick-links-widget-area .wp-block-group-is-layout-flex,
        footer #quick-links-widget-area .is-layout-flex {
            flex-direction: column !important;
            display: flex !important;
        }
        
        footer #quick-links-widget-area .wp-block-group > * {
            width: 100% !important;
        }
        
        /* H3 Elements - All 24px - Maximum Specificity - Override Everything - Must be at end */
        * h3,
        html h3,
        body h3,
        h3,
        .h3,
        h3.text-xl,
        h3.text-2xl,
        h3.text-3xl,
        h3.text-lg,
        h3.text-base,
        h3.text-sm,
        h3.font-bold,
        h3.font-semibold,
        h3.font-medium,
        .text-xl h3,
        .text-2xl h3,
        .text-3xl h3,
        article h3,
        section h3,
        div h3,
        .card h3,
        .bg-card h3,
        .service-card-title,
        h3.service-card-title,
        [class*="text-"] h3,
        h3[class*="text-"],
        footer h3,
        footer h3.font-semibold,
        footer h3.text-foreground,
        footer h3.font-semibold.text-foreground,
        footer .widget-title,
        footer h3.widget-title {
            font-size: 24px !important;
            font-weight: 500 !important;
            line-height: 1.2 !important;
        }
        
        /* Ensure all h3 have font-weight 500 */
        * h3,
        html h3,
        body h3,
        h3,
        .h3 {
            font-weight: 500 !important;
        }
        
        /* Footer All UL LI Text Size - 16px */
        footer ul li,
        footer ul li a,
        footer ul li a.text-sm,
        footer ul li span,
        footer ul li *,
        footer .widget ul li,
        footer .widget ul li a,
        footer .widget ul li a.text-sm {
            font-size: 16px !important;
        }
        
        /* Override text-sm class in footer */
        footer .text-sm,
        footer ul .text-sm,
        footer li .text-sm,
        footer a.text-sm {
            font-size: 16px !important;
        }
        
        /* Feature Card Description Text - 18px */
        .card-hover-smooth p.text-sm,
        .card-hover-smooth p.text-muted-foreground,
        section .card-hover-smooth p.text-sm {
            font-size: 18px !important;
        }
        
        /* FAQ Accordion Styles */
        .faq-item {
            transition: all 0.3s ease;
        }
        
        .faq-question {
            cursor: pointer;
            border: none;
            background: transparent;
        }
        
        .faq-question:focus {
            outline: none;
        }
        
        .faq-question:hover {
            background-color: hsl(var(--secondary) / 0.5);
        }
        
        .faq-answer {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.3s ease, padding 0.3s ease, opacity 0.3s ease;
            opacity: 0;
        }
        
        .faq-answer:not(.hidden) {
            max-height: 500px;
            opacity: 1;
            animation: fadeIn 0.3s ease;
        }
        
        .faq-icon {
            transition: transform 0.3s ease;
            color: hsl(var(--primary));
        }
        
        .faq-icon.rotate-180 {
            transform: rotate(180deg);
        }
        
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        /* FAQ Section Spacing */
        .faq-item + .faq-item {
            margin-top: 1rem;
        }
    ');
}
add_action('wp_enqueue_scripts', 'wheelfy_scripts');

/**
 * Register Widget Areas
 */
function wheelfy_widgets_init() {
    // Header Widget Area
    register_sidebar(array(
        'name' => __('Header Widget Area', 'wheelfy'),
        'id' => 'header-widget-area',
        'description' => __('Add widgets here to appear in your header. These will appear in the right side of the header on desktop.', 'wheelfy'),
        'before_widget' => '<div id="%1$s" class="widget %2$s header-widget">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widget-title sr-only">',
        'after_title' => '</h3>',
    ));
    
    // Quick Links Widget Area (for footer Quick Links column)
    register_sidebar(array(
        'name' => __('Quick Links Widget Area', 'wheelfy'),
        'id' => 'quick-links-widget-area',
        'description' => __('Add widgets here to appear in the Quick Links column of the footer.', 'wheelfy'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widget-title" style="display: none;">',
        'after_title' => '</h3>',
    ));
    
    // Footer Widget Area
    register_sidebar(array(
        'name' => __('Footer Menu one', 'wheelfy'),
        'id' => 'footer-widget-area',
        'description' => __('Add widgets here to appear in your footer.', 'wheelfy'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
    ));
    
    // Footer Menu Two Widget Area
    register_sidebar(array(
        'name' => __('Footer Menu two', 'wheelfy'),
        'id' => 'footer-menu-two',
        'description' => __('Add widgets here to appear in the second footer menu area.', 'wheelfy'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
    ));
}
add_action('widgets_init', 'wheelfy_widgets_init');

/**
 * Enable user registration in WordPress
 */
function wheelfy_enable_user_registration() {
    // Enable user registration if not already enabled
    if (!get_option('users_can_register')) {
        update_option('users_can_register', 1);
    }
}
add_action('after_setup_theme', 'wheelfy_enable_user_registration');

/**
 * Handle Registration Form Submission
 */
function wheelfy_handle_registration() {
    // Only process on POST request
    if (!isset($_SERVER['REQUEST_METHOD']) || $_SERVER['REQUEST_METHOD'] !== 'POST') {
        return;
    }

    // Check if this is our registration form
    if (!isset($_POST['wheelfy_register_nonce']) || !isset($_POST['user_login']) || !isset($_POST['user_email']) || !isset($_POST['user_pass'])) {
        return;
    }

    // Verify nonce
    if (!wp_verify_nonce($_POST['wheelfy_register_nonce'], 'wheelfy_register')) {
        wp_die('Security check failed. Please try again.');
    }
    
    // Prevent any output before redirect
    if (ob_get_level()) {
        ob_end_clean();
    }

    $username = sanitize_user($_POST['user_login']);
    $email = sanitize_email($_POST['user_email']);
    $password = $_POST['user_pass'];
    $confirm_pass = isset($_POST['confirm_pass']) ? $_POST['confirm_pass'] : '';
    $user_type = isset($_POST['user_type']) ? sanitize_text_field($_POST['user_type']) : 'customer';
    $business_name = isset($_POST['business_name']) ? sanitize_text_field($_POST['business_name']) : '';
    $phone_number = isset($_POST['phone_number']) ? sanitize_text_field($_POST['phone_number']) : '';
    $partner_type = isset($_POST['partner_type']) ? sanitize_text_field($_POST['partner_type']) : '';

    // Validate required fields
    if (empty($username) || empty($email) || empty($password)) {
        wp_redirect(add_query_arg('error', 'empty_fields', home_url('/register' . ($user_type === 'partner' ? '?type=partner' : ''))));
        exit;
    }

    // Require partner-specific fields
    if ($user_type === 'partner') {
        if (empty($partner_type)) {
            wp_redirect(add_query_arg('error', 'partner_type_required', home_url('/register?type=partner')));
            exit;
        }
        if (empty($business_name)) {
            wp_redirect(add_query_arg('error', 'business_required', home_url('/register?type=partner')));
            exit;
        }
        if (empty($phone_number)) {
            wp_redirect(add_query_arg('error', 'phone_required', home_url('/register?type=partner')));
            exit;
        }
    }

    // Require terms agreement
    if (!isset($_POST['terms_agree']) || $_POST['terms_agree'] != '1') {
        wp_redirect(add_query_arg('error', 'terms_required', home_url('/register' . ($user_type === 'partner' ? '?type=partner' : ''))));
        exit;
    }

    // Validate password confirmation
    if ($password !== $confirm_pass) {
        wp_redirect(add_query_arg('error', 'password_mismatch', home_url('/register' . ($user_type === 'partner' ? '?type=partner' : ''))));
        exit;
    }

    // Validate password strength
    if (strlen($password) < 6) {
        wp_redirect(add_query_arg('error', 'weak_password', home_url('/register' . ($user_type === 'partner' ? '?type=partner' : ''))));
        exit;
    }

    // Register user using WordPress function
    $user_id = wp_create_user($username, $password, $email);

    if (!is_wp_error($user_id)) {
        // Get the user object
        $user = new WP_User($user_id);
        
        // CRITICAL: Ensure user is NEVER set as administrator
        // Remove all admin capabilities first
        $user->remove_cap('administrator');
        $user->remove_cap('manage_options');
        $user->remove_cap('manage_network');
        $user->remove_cap('activate_plugins');
        $user->remove_cap('delete_users');
        $user->remove_cap('edit_users');
        
        // CRITICAL: Ensure custom roles exist before assignment
        wheelfy_create_custom_roles();
        
        // Save custom fields
        if ($user_type === 'partner') {
            if ($partner_type) {
                update_user_meta($user_id, 'partner_type', $partner_type);
            }
            if ($business_name) {
                update_user_meta($user_id, 'business_name', $business_name);
            }
            if ($phone_number) {
                update_user_meta($user_id, 'phone_number', $phone_number);
            }
            // STRICT: Set user role to 'partner' - role must exist
            // NEVER set to administrator or subscriber
            if (get_role('partner')) {
                $user->set_role('partner');
            } else {
                // If partner role doesn't exist, create it and assign
                wheelfy_create_custom_roles();
                $user->set_role('partner');
            }
        } else {
            // STRICT: For customers, set to 'customer' role
            // NEVER set to administrator or subscriber
            if (get_role('customer')) {
                $user->set_role('customer');
            } else {
                // If customer role doesn't exist, create it and assign
                wheelfy_create_custom_roles();
                $user->set_role('customer');
            }
        }
        
        // CRITICAL: Double-check and remove admin role if somehow assigned
        if (in_array('administrator', $user->roles)) {
            $user->remove_role('administrator');
            // Re-assign correct role based on user_type
            if ($user_type === 'partner') {
                $user->set_role('partner');
            } else {
                $user->set_role('customer');
            }
        }
        
        // CRITICAL: Remove subscriber role if somehow assigned
        if (in_array('subscriber', $user->roles) && !in_array('administrator', $user->roles)) {
            $user->remove_role('subscriber');
            // Re-assign correct role based on user_type
            if ($user_type === 'partner') {
                $user->set_role('partner');
            } else {
                $user->set_role('customer');
            }
        }
        
        // Save user type to database
        update_user_meta($user_id, 'user_type', $user_type);
        
        // Set initial status to pending (requires admin approval)
        update_user_meta($user_id, 'user_status', 'pending');
        
        // Log registration for debugging (optional - can be removed in production)
        error_log('Wheelfy Registration: User ID ' . $user_id . ', Type: ' . $user_type . ', Role: ' . implode(', ', $user->roles) . ', Status: pending');
        
        // Send welcome email to new user
        wheelfy_send_welcome_email($user_id, $user_type, $username, $email);
        
        // Auto login user after registration
        wp_clear_auth_cookie();
        wp_set_current_user($user_id);
        wp_set_auth_cookie($user_id, true);

        // CRITICAL: Ensure dashboard pages exist before redirecting
        wheelfy_ensure_dashboard_pages_exist();
        
        // Check for redirect_to parameter (for protected form pages)
        $redirect_to = '';
        if (isset($_POST['redirect_to']) && !empty($_POST['redirect_to'])) {
            $redirect_to = esc_url_raw($_POST['redirect_to']);
        }
        
        // Determine redirect URL
        if (!empty($redirect_to) && strpos($redirect_to, home_url()) === 0) {
            // Redirect to the form page user was trying to access
            $redirect_url = $redirect_to;
        } else {
            // Redirect to appropriate dashboard after successful registration
            $redirect_url = ($user_type === 'partner') ? home_url('/partner-dashboard') : home_url('/customer-dashboard');
        }
        
        // Clear all output buffers to prevent "headers already sent" errors
        while (ob_get_level()) {
            ob_end_clean();
        }
        
        // Use wp_safe_redirect which is the WordPress recommended method
        wp_safe_redirect($redirect_url);
        exit();
    } else {
        // Registration failed
        error_log('User creation failed');
        $error_code = $user_id->get_error_code();
        $error_message = $user_id->get_error_message();
        error_log('Error code: ' . $error_code);
        error_log('Error message: ' . $error_message);
        
        // Map WordPress errors to our error codes
        if (strpos(strtolower($error_message), 'username') !== false || strpos(strtolower($error_message), 'already exists') !== false || $error_code === 'existing_user_login') {
            $error_code = 'username_exists';
        } elseif (strpos(strtolower($error_message), 'email') !== false || strpos(strtolower($error_message), 'already exists') !== false || $error_code === 'existing_user_email') {
            $error_code = 'email_exists';
        } elseif ($error_code === 'empty_username') {
            $error_code = 'empty_fields';
        } elseif ($error_code === 'invalid_email') {
            $error_code = 'invalid_email';
        } elseif ($error_code === 'business_required') {
            $error_code = 'business_required';
        } elseif ($error_code === 'phone_required') {
            $error_code = 'phone_required';
        } elseif ($error_code === 'terms_required') {
            $error_code = 'terms_required';
        }
        
        wp_redirect(add_query_arg('error', $error_code, home_url('/register' . ($user_type === 'partner' ? '?type=partner' : ''))));
        exit;
    }
}
// Run on init with highest priority to process POST submissions before any output
add_action('init', 'wheelfy_handle_registration', 0);

/**
 * Send Welcome Email to New Users
 * 
 * Sends a beautiful HTML welcome email to customers and partners after registration.
 * Compatible with WP Mail SMTP plugin.
 * 
 * @param int $user_id The user ID
 * @param string $user_type The user type ('customer' or 'partner')
 * @param string $username The username
 * @param string $email The user email address
 * @return bool True if email sent successfully, false otherwise
 */
function wheelfy_send_welcome_email($user_id, $user_type, $username, $email) {
    // Sanitize inputs
    $user_id = intval($user_id);
    $user_type = sanitize_text_field($user_type);
    $username = sanitize_text_field($username);
    $email = sanitize_email($email);
    
    // Validate email
    if (!is_email($email)) {
        error_log('Wheelfy Welcome Email: Invalid email address - ' . $email);
        return false;
    }
    
    // Get user data
    $user = get_userdata($user_id);
    if (!$user) {
        error_log('Wheelfy Welcome Email: User not found - ID ' . $user_id);
        return false;
    }
    
    // Get display name
    $display_name = $user->display_name ? $user->display_name : $username;
    
    // Get site information
    $site_name = get_bloginfo('name');
    $site_url = home_url();
    $site_email = get_option('admin_email');
    
    // Get user-specific data
    $business_name = '';
    $dashboard_url = '';
    
    if ($user_type === 'partner') {
        $business_name = get_user_meta($user_id, 'business_name', true);
        $dashboard_url = home_url('/partner-dashboard');
        $dashboard_name = __('Partner Dashboard', 'wheelfy');
    } else {
        $dashboard_url = home_url('/customer-dashboard');
        $dashboard_name = __('Customer Dashboard', 'wheelfy');
    }
    
    // Email subject
    $subject = sprintf(
        __('Welcome to %s! Your Account Has Been Created', 'wheelfy'),
        $site_name
    );
    
    // Email content
    $message = wheelfy_get_welcome_email_template($display_name, $username, $email, $user_type, $business_name, $dashboard_url, $dashboard_name, $site_name, $site_url);
    
    // Email headers for HTML email
    $headers = array(
        'Content-Type: text/html; charset=UTF-8',
        'From: ' . $site_name . ' <' . $site_email . '>',
        'Reply-To: ' . $site_name . ' <' . $site_email . '>'
    );
    
    // Send email using WordPress wp_mail function (compatible with WP Mail SMTP)
    $sent = wp_mail($email, $subject, $message, $headers);
    
    if ($sent) {
        error_log('Wheelfy Welcome Email: Successfully sent to ' . $email . ' (User ID: ' . $user_id . ')');
    } else {
        error_log('Wheelfy Welcome Email: Failed to send to ' . $email . ' (User ID: ' . $user_id . ')');
    }
    
    return $sent;
}

/**
 * Get Welcome Email HTML Template
 * 
 * Creates a beautiful HTML email template for welcome emails.
 * 
 * @param string $display_name User's display name
 * @param string $username Username
 * @param string $email User email
 * @param string $user_type User type ('customer' or 'partner')
 * @param string $business_name Business name (for partners)
 * @param string $dashboard_url Dashboard URL
 * @param string $dashboard_name Dashboard name
 * @param string $site_name Site name
 * @param string $site_url Site URL
 * @return string HTML email content
 */
function wheelfy_get_welcome_email_template($display_name, $username, $email, $user_type, $business_name, $dashboard_url, $dashboard_name, $site_name, $site_url) {
    // Email template with inline CSS for better email client compatibility
    $template = '
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to ' . esc_html($site_name) . '</title>
</head>
<body style="margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, \'Helvetica Neue\', Arial, sans-serif; background-color: #f5f5f5;">
    <table role="presentation" style="width: 100%; border-collapse: collapse; background-color: #f5f5f5; padding: 40px 20px;">
        <tr>
            <td align="center">
                <table role="presentation" style="max-width: 600px; width: 100%; background-color: #ffffff; border-radius: 12px; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1); overflow: hidden;">
                    <!-- Header -->
                    <tr>
                        <td style="background: linear-gradient(135deg, #f9e79f 0%, #1b4d3e 100%); padding: 40px 30px; text-align: center;">
                            <h1 style="margin: 0; color: #ffffff; font-size: 28px; font-weight: 700; text-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);">' . esc_html($site_name) . '</h1>
                        </td>
                    </tr>
                    
                    <!-- Content -->
                    <tr>
                        <td style="padding: 40px 30px;">
                            <h2 style="margin: 0 0 20px 0; color: #1a1a1a; font-size: 24px; font-weight: 600;">Welcome, ' . esc_html($display_name) . '!</h2>
                            
                            <p style="margin: 0 0 20px 0; color: #4a4a4a; font-size: 16px; line-height: 1.6;">
                                Thank you for creating an account with ' . esc_html($site_name) . '! We\'re excited to have you on board.
                            </p>
                            
                            <div style="background-color: #f8f9fa; border-left: 4px solid #1b4d3e; padding: 20px; margin: 25px 0; border-radius: 4px;">
                                <p style="margin: 0 0 10px 0; color: #1a1a1a; font-size: 15px; font-weight: 600;">Your Account Details:</p>
                                <ul style="margin: 0; padding-left: 20px; color: #4a4a4a; font-size: 15px; line-height: 1.8;">
                                    <li><strong>Username:</strong> ' . esc_html($username) . '</li>
                                    <li><strong>Email:</strong> ' . esc_html($email) . '</li>
                                    <li><strong>Account Type:</strong> ' . esc_html(ucfirst($user_type)) . '</li>';
    
    if ($user_type === 'partner' && !empty($business_name)) {
        $template .= '<li><strong>Business Name:</strong> ' . esc_html($business_name) . '</li>';
    }
    
    $template .= '
                                </ul>
                            </div>
                            
                            <p style="margin: 20px 0; color: #4a4a4a; font-size: 16px; line-height: 1.6;">
                                Your account is currently <strong>pending approval</strong>. Once an administrator approves your account, you\'ll be able to access all features.
                            </p>
                            
                            <!-- CTA Button -->
                            <table role="presentation" style="width: 100%; margin: 30px 0;">
                                <tr>
                                    <td align="center">
                                        <a href="' . esc_url($dashboard_url) . '" style="display: inline-block; padding: 14px 32px; background: linear-gradient(135deg, #f9e79f 0%, #1b4d3e 100%); color: #ffffff; text-decoration: none; border-radius: 6px; font-size: 16px; font-weight: 600; box-shadow: 0 4px 12px rgba(27, 77, 62, 0.3);">
                                            Access Your ' . esc_html($dashboard_name) . '
                                        </a>
                                    </td>
                                </tr>
                            </table>
                            
                            <p style="margin: 25px 0 0 0; color: #666666; font-size: 14px; line-height: 1.6;">
                                If you have any questions or need assistance, please don\'t hesitate to contact us.
                            </p>
                            
                            <p style="margin: 20px 0 0 0; color: #666666; font-size: 14px; line-height: 1.6;">
                                Best regards,<br>
                                <strong>The ' . esc_html($site_name) . ' Team</strong>
                            </p>
                        </td>
                    </tr>
                    
                    <!-- Footer -->
                    <tr>
                        <td style="background-color: #f8f9fa; padding: 30px; text-align: center; border-top: 1px solid #e9ecef;">
                            <p style="margin: 0 0 10px 0; color: #666666; font-size: 13px;">
                                <a href="' . esc_url($site_url) . '" style="color: #1b4d3e; text-decoration: none;">' . esc_html($site_name) . '</a>
                            </p>
                            <p style="margin: 0; color: #999999; font-size: 12px;">
                                This email was sent to ' . esc_html($email) . ' because you created an account on our platform.
                            </p>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>';
    
    return $template;
}

/**
 * Protect form pages - require login before accessing forms
 * Redirects non-logged-in users to registration page with redirect_to parameter
 */
function wheelfy_protect_form_pages() {
    // Only run on frontend, not admin
    if (is_admin()) {
        return;
    }
    
    // Skip if user is already logged in
    if (is_user_logged_in()) {
        return;
    }
    
    // List of protected form page slugs
    $protected_form_slugs = array(
        'request-proposal',
        'sell-car-form',
        'sell-your-car-form',
        'service-book-form',
        'all-services-form',
        'car-accessories-form',
        'previous-service-form',
    );
    
    // Get current page slug
    global $post;
    if (!is_object($post)) {
        return;
    }
    
    $current_slug = $post->post_name;
    
    // Check if current page is a protected form page
    if (in_array($current_slug, $protected_form_slugs)) {
        // Build the current URL to redirect back to after login/registration
        $current_url = home_url($_SERVER['REQUEST_URI']);
        
        // Redirect to registration page with redirect_to parameter
        $register_url = add_query_arg('redirect_to', urlencode($current_url), home_url('/register'));
        
        // Redirect to registration page
        wp_safe_redirect($register_url);
        exit;
    }
}
add_action('template_redirect', 'wheelfy_protect_form_pages', 1);

/**
 * Handle Car Accessories Form Submission
 */
function wheelfy_handle_car_accessories_form() {
    // Check if this is a POST request for car accessories form
    if (!isset($_POST['car_accessories_nonce']) || !wp_verify_nonce($_POST['car_accessories_nonce'], 'car_accessories_form')) {
        return;
    }
    
    // Clear any output buffers completely before any output
    if (ob_get_level() > 0) {
        while (ob_get_level()) {
            ob_end_clean();
        }
    }
    
    // Ensure headers haven't been sent before redirecting
    if (headers_sent($file, $line)) {
        // Headers already sent - use wp_die with JS redirect as fallback
        wp_die('<script>window.location.href = "' . esc_js(home_url('/car-accessories-form?error=headers_sent')) . '";</script>');
        exit;
    }
    
    // Get form data
    $make = isset($_POST['make']) ? sanitize_text_field($_POST['make']) : '';
    $model = isset($_POST['model']) ? sanitize_text_field($_POST['model']) : '';
    $year = isset($_POST['year']) ? sanitize_text_field($_POST['year']) : '';
    $mileage = isset($_POST['mileage']) ? sanitize_text_field($_POST['mileage']) : '';
    $services = isset($_POST['services']) ? array_map('sanitize_text_field', $_POST['services']) : array();
    $additional_services = isset($_POST['additional_services']) ? sanitize_textarea_field($_POST['additional_services']) : '';
    // Keep accessories for backward compatibility
    $accessories = isset($_POST['accessories']) ? array_map('sanitize_text_field', $_POST['accessories']) : array();
    $additional_accessories = isset($_POST['additional_accessories']) ? sanitize_textarea_field($_POST['additional_accessories']) : '';
    
    // Validate required fields
    if (empty($make) || empty($model) || empty($year) || empty($mileage)) {
        wp_safe_redirect(add_query_arg('error', 'empty_fields', home_url('/car-accessories-form')));
        exit;
    }
    
    // Save form data to session or transient for next step
    $request_id = uniqid('req_', true);
    $form_data = array(
        'make' => $make,
        'model' => $model,
        'year' => $year,
        'mileage' => $mileage,
        'services' => $services,
        'additional_services' => $additional_services,
        'accessories' => $accessories, // Keep for backward compatibility
        'additional_accessories' => $additional_accessories, // Keep for backward compatibility
        'request_type' => 'car_accessories',
        'timestamp' => current_time('mysql'),
    );
    
    // SECURITY: Add customer_id if user is logged in for data isolation
    if (is_user_logged_in()) {
        $form_data['customer_id'] = get_current_user_id();
        $current_user = wp_get_current_user();
        $form_data['customer_email'] = $current_user->user_email;
    }
    
    // Store in transient for 1 hour
    set_transient('car_accessories_request_' . $request_id, $form_data, HOUR_IN_SECONDS);
    
    // Redirect to select partner page
    wp_safe_redirect(home_url('/select-partner?request_id=' . $request_id));
    exit;
}
// Run form handlers very early on init to catch POST before any output
add_action('init', 'wheelfy_handle_car_accessories_form', 0);

/**
 * Handle Sell Car Form Submission
 */
function wheelfy_handle_sell_car_form() {
    // Check if this is a POST request for sell car form
    if (!isset($_POST['sell_car_form_nonce']) || !wp_verify_nonce($_POST['sell_car_form_nonce'], 'sell_car_form')) {
        return;
    }
    
    // Start output buffering if not already started
    if (ob_get_level() == 0) {
        ob_start();
    }
    
    // Clear any output buffers completely before any output
    if (ob_get_level() > 0) {
        while (ob_get_level()) {
            ob_end_clean();
        }
    }
    
    // Ensure headers haven't been sent before redirecting
    if (headers_sent($file, $line)) {
        // Headers already sent - use wp_die with JS redirect as fallback
        wp_die('<script>window.location.href = "' . esc_js(home_url('/sell-your-car-form?error=headers_sent')) . '";</script>');
        exit;
    }
    
    // Get form data - support both field name formats (car_brand/car_model/car_year OR make/model/year)
    $make = isset($_POST['make']) ? sanitize_text_field($_POST['make']) : (isset($_POST['car_brand']) ? sanitize_text_field($_POST['car_brand']) : '');
    $model = isset($_POST['model']) ? sanitize_text_field($_POST['model']) : (isset($_POST['car_model']) ? sanitize_text_field($_POST['car_model']) : '');
    $year = isset($_POST['year']) ? sanitize_text_field($_POST['year']) : (isset($_POST['car_year']) ? intval($_POST['car_year']) : '');
    $mileage = isset($_POST['mileage']) ? sanitize_text_field($_POST['mileage']) : '';
    $color = isset($_POST['color']) ? sanitize_text_field($_POST['color']) : '';
    $price = isset($_POST['price']) ? sanitize_text_field($_POST['price']) : '';
    $fuel_type = isset($_POST['fuel_type']) ? sanitize_text_field($_POST['fuel_type']) : '';
    $license_plate = isset($_POST['license_plate']) ? sanitize_text_field($_POST['license_plate']) : '';
    $service_book = isset($_POST['service_book']) ? sanitize_text_field($_POST['service_book']) : '';
    $last_service_date = isset($_POST['last_service_date']) ? sanitize_text_field($_POST['last_service_date']) : '';
    $last_service_mileage = isset($_POST['last_service_mileage']) ? sanitize_text_field($_POST['last_service_mileage']) : '';
    $service_description = isset($_POST['service_description']) ? sanitize_textarea_field($_POST['service_description']) : '';
    $location = isset($_POST['location']) ? sanitize_text_field($_POST['location']) : '';
    $full_name = isset($_POST['full_name']) ? sanitize_text_field($_POST['full_name']) : '';
    $email = isset($_POST['email']) ? sanitize_email($_POST['email']) : '';
    $phone = isset($_POST['phone']) ? sanitize_text_field($_POST['phone']) : '';
    $additional_notes = isset($_POST['additional_notes']) ? sanitize_textarea_field($_POST['additional_notes']) : '';
    
    // Use service_description as additional_notes if additional_notes is empty
    if (empty($additional_notes) && !empty($service_description)) {
        $additional_notes = $service_description;
    }
    
    // Validate required fields
    if (empty($make) || empty($model) || empty($year) || empty($mileage)) {
        wp_safe_redirect(add_query_arg('error', 'empty_fields', home_url('/sell-your-car-form')));
        exit;
    }
    
    // Handle car photos upload
    $car_photos = array();
    if (!empty($_FILES['car_photos']['name'][0])) {
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        require_once(ABSPATH . 'wp-admin/includes/media.php');
        
        $files = $_FILES['car_photos'];
        $file_count = count($files['name']);
        
        for ($i = 0; $i < $file_count; $i++) {
            if ($files['error'][$i] === UPLOAD_ERR_OK) {
                $file = array(
                    'name'     => $files['name'][$i],
                    'type'     => $files['type'][$i],
                    'tmp_name' => $files['tmp_name'][$i],
                    'error'    => $files['error'][$i],
                    'size'     => $files['size'][$i]
                );
                
                $allowed_types = array('image/jpeg', 'image/jpg', 'image/png', 'image/webp', 'image/svg+xml');
                $file_type = wp_check_filetype($file['name']);
                
                if (in_array($file['type'], $allowed_types) || in_array($file_type['type'], $allowed_types)) {
                    $max_size = 8 * 1024 * 1024; // 8MB
                    if ($file['size'] <= $max_size) {
                        $upload = wp_handle_upload($file, array('test_form' => false));
                        
                        if (!isset($upload['error'])) {
                            $attachment = array(
                                'post_mime_type' => $upload['type'],
                                'post_title'     => sanitize_file_name(pathinfo($file['name'], PATHINFO_FILENAME)),
                                'post_content'   => '',
                                'post_status'    => 'inherit',
                            );
                            
                            $attach_id = wp_insert_attachment($attachment, $upload['file']);
                            
                            if (!is_wp_error($attach_id)) {
                                $attach_data = wp_generate_attachment_metadata($attach_id, $upload['file']);
                                wp_update_attachment_metadata($attach_id, $attach_data);
                                $car_photos[] = $attach_id;
                            }
                        }
                    }
                }
            }
        }
    }
    
    // Save form data to transient for next step
    $request_id = uniqid('req_', true);
    $form_data = array(
        'make' => $make,
        'model' => $model,
        'year' => $year,
        'mileage' => $mileage,
        'color' => $color,
        'price' => $price,
        'fuel_type' => $fuel_type,
        'license_plate' => $license_plate,
        'service_book' => $service_book,
        'last_service_date' => $last_service_date,
        'last_service_mileage' => $last_service_mileage,
        'service_description' => $service_description,
        'location' => $location,
        'full_name' => $full_name,
        'email' => $email, // IMPORTANT: Save email for partner selection handler
        'phone' => $phone,
        'additional_notes' => $additional_notes,
        'car_photos' => $car_photos, // Array of attachment IDs
        'request_type' => 'sell_car',
        'timestamp' => current_time('mysql'),
    );
    
    // SECURITY: Add customer_id if user is logged in for data isolation
    if (is_user_logged_in()) {
        $form_data['customer_id'] = get_current_user_id();
        $current_user = wp_get_current_user();
        $form_data['customer_email'] = $current_user->user_email;
    }
    
    // Store in transient for 1 hour
    set_transient('car_accessories_request_' . $request_id, $form_data, HOUR_IN_SECONDS);
    
    // Redirect to select partner page
    wp_safe_redirect(home_url('/select-partner?request_id=' . $request_id));
    exit;
}
// Run form handlers very early on init to catch POST before any output
add_action('init', 'wheelfy_handle_sell_car_form', 0);

/**
 * Handle Service Book Form Submission
 */
function wheelfy_handle_service_book_form() {
    // Check if this is a POST request for service book form
    if (!isset($_POST['service_book_form_nonce']) || !wp_verify_nonce($_POST['service_book_form_nonce'], 'service_book_form')) {
        return;
    }
    
    // Start output buffering if not already started
    if (ob_get_level() == 0) {
        ob_start();
    }
    
    // Clear any output buffers completely before any output
    if (ob_get_level() > 0) {
        while (ob_get_level()) {
            ob_end_clean();
        }
    }
    
    // Ensure headers haven't been sent before redirecting
    if (headers_sent($file, $line)) {
        // Headers already sent - use wp_die with JS redirect as fallback
        wp_die('<script>window.location.href = "' . esc_js(home_url('/service-book-form?error=headers_sent')) . '";</script>');
        exit;
    }
    
    // Get form data
    $make = isset($_POST['make']) ? sanitize_text_field($_POST['make']) : '';
    $model = isset($_POST['model']) ? sanitize_text_field($_POST['model']) : '';
    $year = isset($_POST['year']) ? sanitize_text_field($_POST['year']) : '';
    $mileage = isset($_POST['mileage']) ? sanitize_text_field($_POST['mileage']) : '';
    $service_book = isset($_POST['service_book']) ? sanitize_text_field($_POST['service_book']) : '';
    $additional_notes = isset($_POST['additional_notes']) ? sanitize_textarea_field($_POST['additional_notes']) : '';
    
    // Validate required fields
    if (empty($make) || empty($model) || empty($year) || empty($mileage)) {
        wp_safe_redirect(add_query_arg('error', 'empty_fields', home_url('/service-book-form')));
        exit;
    }
    
    // Save form data to transient for next step
    $request_id = uniqid('req_', true);
    $form_data = array(
        'make' => $make,
        'model' => $model,
        'year' => $year,
        'mileage' => $mileage,
        'service_book' => $service_book,
        'additional_notes' => $additional_notes,
        'request_type' => 'service_book',
        'timestamp' => current_time('mysql'),
    );
    
    // SECURITY: Add customer_id if user is logged in for data isolation
    if (is_user_logged_in()) {
        $form_data['customer_id'] = get_current_user_id();
        $current_user = wp_get_current_user();
        $form_data['customer_email'] = $current_user->user_email;
    }
    
    // Store in transient for 1 hour
    set_transient('car_accessories_request_' . $request_id, $form_data, HOUR_IN_SECONDS);
    
    // Redirect to select partner page
    wp_safe_redirect(home_url('/select-partner?request_id=' . $request_id));
    exit;
}
// Run form handlers very early on init to catch POST before any output
add_action('init', 'wheelfy_handle_service_book_form', 0);

/**
 * Handle Previous Service Form Submission
 */
function wheelfy_handle_previous_service_form() {
    // Check if this is a POST request for previous service form
    if (!isset($_POST['previous_service_form_nonce']) || !wp_verify_nonce($_POST['previous_service_form_nonce'], 'previous_service_form')) {
        return;
    }
    
    // Start output buffering if not already started
    if (ob_get_level() == 0) {
        ob_start();
    }
    
    // Clear any output buffers completely before any output
    if (ob_get_level() > 0) {
        while (ob_get_level()) {
            ob_end_clean();
        }
    }
    
    // Ensure headers haven't been sent before redirecting
    if (headers_sent($file, $line)) {
        // Headers already sent - use wp_die with JS redirect as fallback
        wp_die('<script>window.location.href = "' . esc_js(home_url('/previous-service-form?error=headers_sent')) . '";</script>');
        exit;
    }
    
    // Get form data
    $make = isset($_POST['make']) ? sanitize_text_field($_POST['make']) : '';
    $model = isset($_POST['model']) ? sanitize_text_field($_POST['model']) : '';
    $year = isset($_POST['year']) ? sanitize_text_field($_POST['year']) : '';
    $mileage = isset($_POST['mileage']) ? sanitize_text_field($_POST['mileage']) : '';
    $last_service_date = isset($_POST['last_service_date']) ? sanitize_text_field($_POST['last_service_date']) : '';
    $last_service_mileage = isset($_POST['last_service_mileage']) ? sanitize_text_field($_POST['last_service_mileage']) : '';
    $service_type = isset($_POST['service_type']) ? sanitize_text_field($_POST['service_type']) : '';
    $additional_notes = isset($_POST['additional_notes']) ? sanitize_textarea_field($_POST['additional_notes']) : '';
    
    // Validate required fields
    if (empty($make) || empty($model) || empty($year) || empty($mileage) || empty($last_service_date) || empty($last_service_mileage)) {
        wp_safe_redirect(add_query_arg('error', 'empty_fields', home_url('/previous-service-form')));
        exit;
    }
    
    // Save form data to transient for next step
    $request_id = uniqid('req_', true);
    $form_data = array(
        'make' => $make,
        'model' => $model,
        'year' => $year,
        'mileage' => $mileage,
        'last_service_date' => $last_service_date,
        'last_service_mileage' => $last_service_mileage,
        'service_type' => $service_type,
        'additional_notes' => $additional_notes,
        'request_type' => 'previous_service',
        'timestamp' => current_time('mysql'),
    );
    
    // SECURITY: Add customer_id if user is logged in for data isolation
    if (is_user_logged_in()) {
        $form_data['customer_id'] = get_current_user_id();
        $current_user = wp_get_current_user();
        $form_data['customer_email'] = $current_user->user_email;
    }
    
    // Store in transient for 1 hour
    set_transient('car_accessories_request_' . $request_id, $form_data, HOUR_IN_SECONDS);
    
    // Redirect to select partner page
    wp_safe_redirect(home_url('/select-partner?request_id=' . $request_id));
    exit;
}
// Run form handlers very early on init to catch POST before any output
add_action('init', 'wheelfy_handle_previous_service_form', 0);

/**
 * Handle All Services Form Submission
 * Processes the "All Services" form and redirects to partner selection page
 */
function wheelfy_handle_all_services_form() {
    // Check if this is a POST request for all services form
    if (!isset($_POST['all_services_form_nonce']) || !wp_verify_nonce($_POST['all_services_form_nonce'], 'all_services_form')) {
        return;
    }
    
    // Clear any output buffers completely before any output
    if (ob_get_level() > 0) {
        while (ob_get_level()) {
            ob_end_clean();
        }
    }
    
    // Ensure headers haven't been sent before redirecting
    if (headers_sent($file, $line)) {
        wp_die('<script>window.location.href = "' . esc_js(home_url('/all-services-form?error=headers_sent')) . '";</script>');
        exit;
    }
    
    // Get form data
    $make = isset($_POST['make']) ? sanitize_text_field($_POST['make']) : '';
    $model = isset($_POST['model']) ? sanitize_text_field($_POST['model']) : '';
    $year = isset($_POST['year']) ? sanitize_text_field($_POST['year']) : '';
    $mileage = isset($_POST['mileage']) ? sanitize_text_field($_POST['mileage']) : '';
    $additional_notes = isset($_POST['additional_notes']) ? sanitize_textarea_field($_POST['additional_notes']) : '';
    
    // Get selected services (array)
    $services = array();
    if (isset($_POST['services']) && is_array($_POST['services'])) {
        foreach ($_POST['services'] as $service) {
            $services[] = sanitize_text_field($service);
        }
    }
    
    // Validate required fields
    if (empty($make) || empty($model) || empty($year)) {
        wp_safe_redirect(add_query_arg('error', 'empty_fields', home_url('/all-services-form')));
        exit;
    }
    
    // Validate that at least one service is selected
    if (empty($services)) {
        wp_safe_redirect(add_query_arg('error', 'no_services', home_url('/all-services-form')));
        exit;
    }
    
    // Save form data to transient for next step
    $request_id = uniqid('req_', true);
    $form_data = array(
        'make' => $make,
        'model' => $model,
        'year' => $year,
        'mileage' => $mileage,
        'services' => $services,
        'additional_notes' => $additional_notes,
        'timestamp' => current_time('mysql'),
        'form_type' => 'all_services' // Identify the form type
    );
    
    // SECURITY: Add customer_id if user is logged in for data isolation
    if (is_user_logged_in()) {
        $form_data['customer_id'] = get_current_user_id();
        $current_user = wp_get_current_user();
        $form_data['customer_email'] = $current_user->user_email;
    }
    
    // Store in transient for 1 hour
    set_transient('car_accessories_request_' . $request_id, $form_data, HOUR_IN_SECONDS);
    
    // Redirect to select partner page
    wp_safe_redirect(home_url('/select-partner?request_id=' . $request_id));
    exit;
}
add_action('init', 'wheelfy_handle_all_services_form', 0);

/**
 * Handle Partner Selection Submission
 */
function wheelfy_handle_partner_selection() {
    // Check if this is a POST request for partner selection
    if (!isset($_POST['select_partner_nonce']) || !wp_verify_nonce($_POST['select_partner_nonce'], 'select_partner')) {
        return;
    }
    
    // Start output buffering if not already started
    if (ob_get_level() == 0) {
        ob_start();
    }
    
    // Clear any existing output buffers
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    
    // Ensure headers haven't been sent before redirecting
    if (headers_sent($file, $line)) {
        // Headers already sent - use wp_die with JS redirect as fallback
        wp_die('<script>window.location.href = "' . esc_js(home_url('/select-partner?error=headers_sent')) . '";</script>');
        exit;
    }
    
    $request_id = isset($_POST['request_id']) ? sanitize_text_field($_POST['request_id']) : '';
    $action = isset($_POST['action']) ? sanitize_text_field($_POST['action']) : 'all';
    $selected_partners = isset($_POST['selected_partners']) ? array_map('intval', $_POST['selected_partners']) : array();
    
    if (empty($request_id)) {
        wp_safe_redirect(home_url('/select-partner'));
        exit;
    }
    
    // Get form data
    $form_data = get_transient('car_accessories_request_' . $request_id);
    if (!$form_data) {
        // Dynamic fallback: Try to determine which form page to redirect to based on request_type or referer
        $fallback_url = home_url('/car-accessories-form'); // Default fallback
        
        // Check referer to determine which form was submitted
        $referer = wp_get_referer();
        if ($referer) {
            $referer_path = parse_url($referer, PHP_URL_PATH);
            if (strpos($referer_path, '/sell-your-car-form') !== false || strpos($referer_path, '/sell-car-form') !== false) {
                $fallback_url = home_url('/sell-your-car-form');
            } elseif (strpos($referer_path, '/service-book-form') !== false) {
                $fallback_url = home_url('/service-book-form');
            } elseif (strpos($referer_path, '/previous-service-form') !== false) {
                $fallback_url = home_url('/previous-service-form');
            } elseif (strpos($referer_path, '/all-services-form') !== false) {
                $fallback_url = home_url('/all-services-form');
            }
        }
        
        wp_safe_redirect(add_query_arg('error', 'session_expired', $fallback_url));
        exit;
    }
    
    $current_user_id = get_current_user_id();
    $first_partner_id = 0;
    
    // Get customer email from form data for linking requests later
    // Support both 'email' and 'customer_email' field names
    $customer_email = '';
    if (isset($form_data['email'])) {
        $customer_email = sanitize_email($form_data['email']);
    } elseif (isset($form_data['customer_email'])) {
        $customer_email = sanitize_email($form_data['customer_email']);
    }
    
    // Save request to database (create a custom post type entry or save to user meta)
    if ($action === 'selected' && !empty($selected_partners)) {
        // Get first selected partner
        $first_partner_id = $selected_partners[0];
        
        // PRIORITY FLAG: Customer specifically selected these dealers (VIP/Fast Track)
        $is_priority_request = true;
        
        // Save partner_id to transient for each selected partner
        foreach ($selected_partners as $partner_id) {
            // Update transient with partner_id
            $form_data['partner_id'] = $partner_id;
            $form_data['status'] = 'pending';
            $form_data['customer_id'] = $current_user_id;
            $form_data['customer_email'] = $customer_email; // Save email for linking
            $form_data['selected_at'] = current_time('mysql');
            $form_data['is_priority'] = $is_priority_request; // VIP/Fast Track flag
            // Extend transient to 30 days so it persists
            set_transient('car_accessories_request_' . $request_id . '_partner_' . $partner_id, $form_data, 30 * DAY_IN_SECONDS);
        }
        
        // Also save to user meta for permanent storage (if logged in)
        if ($current_user_id > 0) {
            $customer_requests = get_user_meta($current_user_id, 'customer_service_requests', true);
            if (!is_array($customer_requests)) {
                $customer_requests = array();
            }
            
            foreach ($selected_partners as $partner_id) {
                $request_entry = array(
                    'request_id' => $request_id,
                    'partner_id' => $partner_id,
                    'status' => 'pending',
                    'created_at' => current_time('mysql'),
                    'form_data' => $form_data
                );
                $customer_requests[] = $request_entry;
            }
            
            update_user_meta($current_user_id, 'customer_service_requests', $customer_requests);
            
            // Get customer information for notifications
            $customer = get_userdata($current_user_id);
            $customer_name = $customer ? ($customer->display_name ?: $customer->user_login) : 'Customer';
            
            // Create notifications and send emails to selected partners
            foreach ($selected_partners as $partner_id) {
                // Create dashboard notification for partner with PRIORITY/VIP flag
                $vehicle_info = $form_data['make'] . ' ' . $form_data['model'] . ' (' . $form_data['year'] . ')';
                $notification_title = $is_priority_request 
                    ? __('⭐ VIP Service Request', 'wheelfy') 
                    : __('New Service Request', 'wheelfy');
                $notification_message = $is_priority_request
                    ? sprintf(__('🚀 Fast Track! %s specifically chose YOU for %s.', 'wheelfy'), $customer_name, $vehicle_info)
                    : sprintf(__('You received a new service request from %s for %s.', 'wheelfy'), $customer_name, $vehicle_info);
                    
                wheelfy_create_notification(
                    $partner_id,
                    'new_request',
                    $notification_title,
                    $notification_message,
                    array(
                        'request_id' => $request_id,
                        'customer_id' => $current_user_id,
                        'customer_name' => $customer_name,
                        'is_priority' => $is_priority_request,
                        'link' => home_url('/partner-dashboard#requests')
                    )
                );
                
                // Send email notification to partner (with priority info)
                wheelfy_send_new_request_email_to_partner($partner_id, $request_id, $form_data, $current_user_id);
            }
        } else {
            // User not logged in - save to a global option keyed by email for later linking
            if (!empty($customer_email)) {
                $pending_requests = get_option('wheelfy_pending_requests_' . md5($customer_email), array());
                if (!is_array($pending_requests)) {
                    $pending_requests = array();
                }
                
                foreach ($selected_partners as $partner_id) {
                    $request_entry = array(
                        'request_id' => $request_id,
                        'partner_id' => $partner_id,
                        'status' => 'pending',
                        'created_at' => current_time('mysql'),
                        'form_data' => $form_data
                    );
                    $pending_requests[] = $request_entry;
                }
                
                update_option('wheelfy_pending_requests_' . md5($customer_email), $pending_requests);
                
                // Get customer name from email or form data
                $customer_name = !empty($form_data['customer_name']) ? $form_data['customer_name'] : 'Customer';
                if (empty($customer_name) || $customer_name === 'Customer') {
                    // Try to extract name from email
                    $email_parts = explode('@', $customer_email);
                    $customer_name = !empty($email_parts[0]) ? $email_parts[0] : 'Customer';
                }
                
                // Create notifications and send emails to selected partners (for non-logged-in users)
                foreach ($selected_partners as $partner_id) {
                    // Create dashboard notification for partner with PRIORITY/VIP flag
                    $vehicle_info = $form_data['make'] . ' ' . $form_data['model'] . ' (' . $form_data['year'] . ')';
                    $notification_title = $is_priority_request 
                        ? __('⭐ VIP Service Request', 'wheelfy') 
                        : __('New Service Request', 'wheelfy');
                    $notification_message = $is_priority_request
                        ? sprintf(__('🚀 Fast Track! %s specifically chose YOU for %s.', 'wheelfy'), $customer_name, $vehicle_info)
                        : sprintf(__('You received a new service request from %s for %s.', 'wheelfy'), $customer_name, $vehicle_info);
                        
                    wheelfy_create_notification(
                        $partner_id,
                        'new_request',
                        $notification_title,
                        $notification_message,
                        array(
                            'request_id' => $request_id,
                            'customer_email' => $customer_email,
                            'customer_name' => $customer_name,
                            'is_priority' => $is_priority_request,
                            'link' => home_url('/partner-dashboard#requests')
                        )
                    );
                    
                    // Send email notification to partner (with priority info)
                    wheelfy_send_new_request_email_to_partner($partner_id, $request_id, $form_data, 0, $customer_email);
                }
            }
        }
        
        // Redirect to first selected partner's quotation page
        wp_safe_redirect(home_url('/partner-quotation?request_id=' . $request_id . '&partner_id=' . $first_partner_id));
        exit;
    } else {
        // Send to ALL partners
        // Selected partners get VIP/Priority, others get normal request
        
        // Get priority partner IDs from POST (JSON encoded array)
        $priority_partner_ids = array();
        if (isset($_POST['priority_partner_ids'])) {
            $priority_json = stripslashes($_POST['priority_partner_ids']);
            $priority_partner_ids = json_decode($priority_json, true);
            if (!is_array($priority_partner_ids)) {
                $priority_partner_ids = array();
            }
            $priority_partner_ids = array_map('intval', $priority_partner_ids);
        }
        
        // Check if this is a sell_car request - only get car dealership partners
        $request_type = isset($form_data['request_type']) ? $form_data['request_type'] : '';
        $is_sell_car = ($request_type === 'sell_car');
        
        // Get ALL partners (or car dealerships for sell_car)
        if ($is_sell_car) {
            // First try to get car dealership partners
            $all_partners = get_users(array(
                'role' => 'partner',
                'number' => -1,
                'meta_query' => array(
                    array(
                        'key' => 'partner_type',
                        'value' => 'car_dealership',
                        'compare' => '='
                    )
                )
            ));
            // If no car dealerships, get all partners
            if (empty($all_partners)) {
                $all_partners = get_users(array('role' => 'partner', 'number' => -1));
            }
        } else {
            $all_partners = get_users(array('role' => 'partner', 'number' => -1));
        }
        
        if (!empty($all_partners)) {
            $first_partner_id = $all_partners[0]->ID;
            
            // Get customer name for notifications
            $customer_name = 'Customer';
            if ($current_user_id > 0) {
                $customer = get_userdata($current_user_id);
                $customer_name = $customer ? ($customer->display_name ?: $customer->user_login) : 'Customer';
            } elseif (!empty($form_data['full_name'])) {
                $customer_name = $form_data['full_name'];
            } elseif (!empty($customer_email)) {
                $email_parts = explode('@', $customer_email);
                $customer_name = !empty($email_parts[0]) ? $email_parts[0] : 'Customer';
            }
            
            // Create vehicle info for notifications
            $vehicle_info = '';
            if (isset($form_data['make']) && isset($form_data['model']) && isset($form_data['year'])) {
                $vehicle_info = $form_data['make'] . ' ' . $form_data['model'] . ' (' . $form_data['year'] . ')';
            }
            
            // Send to EACH partner
            foreach ($all_partners as $partner) {
                $partner_id = $partner->ID;
                
                // Check if this partner is in the priority list (selected by customer)
                $is_priority_for_this_partner = in_array($partner_id, $priority_partner_ids);
                
                // Save to transient for this partner
                $partner_form_data = $form_data;
                $partner_form_data['partner_id'] = $partner_id;
                $partner_form_data['status'] = 'pending';
                $partner_form_data['customer_id'] = $current_user_id;
                $partner_form_data['customer_email'] = $customer_email;
                $partner_form_data['selected_at'] = current_time('mysql');
                $partner_form_data['is_priority'] = $is_priority_for_this_partner; // VIP only for selected partners
                set_transient('car_accessories_request_' . $request_id . '_partner_' . $partner_id, $partner_form_data, 30 * DAY_IN_SECONDS);
                
                // Create notification for this partner - VIP or Normal based on selection
                if ($is_priority_for_this_partner) {
                    $notification_title = __('⭐ VIP Service Request', 'wheelfy');
                    $notification_message = sprintf(__('🚀 Fast Track! %s specifically chose YOU for %s.', 'wheelfy'), $customer_name, $vehicle_info);
                } else {
                    $notification_title = __('New Service Request', 'wheelfy');
                    $notification_message = sprintf(__('You received a new service request from %s for %s.', 'wheelfy'), $customer_name, $vehicle_info);
                }
                
                wheelfy_create_notification(
                    $partner_id,
                    'new_request',
                    $notification_title,
                    $notification_message,
                    array(
                        'request_id' => $request_id,
                        'customer_id' => $current_user_id,
                        'customer_email' => $customer_email,
                        'customer_name' => $customer_name,
                        'is_priority' => $is_priority_for_this_partner,
                        'link' => home_url('/partner-dashboard#requests')
                    )
                );
                
                // Send email notification to partner
                wheelfy_send_new_request_email_to_partner($partner_id, $request_id, $partner_form_data, $current_user_id, $customer_email);
            }
            
            // Save to user meta (if logged in) - save entry for EACH partner
            if ($current_user_id > 0) {
                $customer_requests = get_user_meta($current_user_id, 'customer_service_requests', true);
                if (!is_array($customer_requests)) {
                    $customer_requests = array();
                }
                
                foreach ($all_partners as $partner) {
                    $partner_id = $partner->ID;
                    $is_priority_for_this_partner = in_array($partner_id, $priority_partner_ids);
                    $partner_form_data = $form_data;
                    $partner_form_data['is_priority'] = $is_priority_for_this_partner;
                    
                    $request_entry = array(
                        'request_id' => $request_id,
                        'partner_id' => $partner_id,
                        'status' => 'pending',
                        'created_at' => current_time('mysql'),
                        'form_data' => $partner_form_data
                    );
                    $customer_requests[] = $request_entry;
                }
                
                update_user_meta($current_user_id, 'customer_service_requests', $customer_requests);
            } else {
                // User not logged in - save to email-based option for EACH partner
                if (!empty($customer_email)) {
                    $pending_requests = get_option('wheelfy_pending_requests_' . md5($customer_email), array());
                    if (!is_array($pending_requests)) {
                        $pending_requests = array();
                    }
                    
                    foreach ($all_partners as $partner) {
                        $partner_id = $partner->ID;
                        $is_priority_for_this_partner = in_array($partner_id, $priority_partner_ids);
                        $partner_form_data = $form_data;
                        $partner_form_data['is_priority'] = $is_priority_for_this_partner;
                        
                        $request_entry = array(
                            'request_id' => $request_id,
                            'partner_id' => $partner_id,
                            'status' => 'pending',
                            'created_at' => current_time('mysql'),
                            'form_data' => $partner_form_data
                        );
                        $pending_requests[] = $request_entry;
                    }
                    
                    update_option('wheelfy_pending_requests_' . md5($customer_email), $pending_requests);
                }
            }
            
            wp_safe_redirect(home_url('/partner-quotation?request_id=' . $request_id . '&partner_id=' . $first_partner_id));
            exit;
        }
    }
    
    wp_safe_redirect(home_url('/select-partner?request_id=' . $request_id));
    exit;
}
// Run form handlers very early on init to catch POST before any output
add_action('init', 'wheelfy_handle_partner_selection', 0);

/**
 * Handle Service Request Submission
 * Creates a request when customer selects a service from partner profile
 */
function wheelfy_handle_service_request() {
    // Check if this is a POST request for service request
    if (!isset($_POST['request_service_nonce']) || !wp_verify_nonce($_POST['request_service_nonce'], 'request_service')) {
        return;
    }
    
    // Start output buffering early to prevent any output
    if (ob_get_level() == 0) {
        ob_start();
    }
    
    // Clear any existing output buffers to prevent "headers already sent" errors
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    
    // Restart output buffering
    ob_start();
    
    // Ensure headers haven't been sent before redirecting
    if (headers_sent($file, $line)) {
        wp_die('<script>window.location.href = "' . esc_js(home_url('/partner/' . (isset($_POST['partner_id']) ? intval($_POST['partner_id']) : 0) . '/?error=headers_sent')) . '";</script>');
        exit;
    }
    
    $service_id = isset($_POST['service_id']) ? sanitize_text_field($_POST['service_id']) : '';
    $partner_id = isset($_POST['partner_id']) ? intval($_POST['partner_id']) : 0;
    
    if (empty($service_id) || $partner_id <= 0) {
        wp_safe_redirect(home_url('/partner/' . $partner_id . '/?error=invalid_request'));
        exit;
    }
    
    // Verify partner exists and is a partner
    $partner = get_userdata($partner_id);
    if (!$partner || !in_array('partner', $partner->roles)) {
        wp_safe_redirect(home_url('/partner/' . $partner_id . '/?error=invalid_partner'));
        exit;
    }
    
    // Get service data
    $partner_services = get_user_meta($partner_id, 'partner_services', true);
    if (!is_array($partner_services)) {
        $partner_services = array();
    }
    
    $service_data = null;
    foreach ($partner_services as $service) {
        if (isset($service['id']) && $service['id'] === $service_id) {
            $service_data = $service;
            break;
        }
    }
    
    if (!$service_data || (isset($service_data['status']) && $service_data['status'] !== 'active')) {
        wp_safe_redirect(home_url('/partner/' . $partner_id . '/?error=service_not_found'));
        exit;
    }
    
    // Get current user
    $current_user_id = get_current_user_id();
    $customer_email = '';
    $customer_name = '';
    
    if ($current_user_id > 0) {
        $customer = get_userdata($current_user_id);
        $customer_email = $customer ? $customer->user_email : '';
        $customer_name = $customer ? ($customer->display_name ?: $customer->user_login) : '';
    } else {
        // User not logged in - redirect to login
        wp_safe_redirect(wp_login_url(home_url('/partner/' . $partner_id . '/')));
        exit;
    }
    
    // Create request_id
    $request_id = uniqid('req_', true);
    
    // Prepare form_data with service information
    $form_data = array(
        'request_type' => 'service',
        'service_id' => $service_id,
        'service_title' => isset($service_data['title']) ? $service_data['title'] : '',
        'service_description' => isset($service_data['description']) ? $service_data['description'] : '',
        'service_price' => isset($service_data['price']) ? floatval($service_data['price']) : 0,
        'service_price_currency' => isset($service_data['price_currency']) ? $service_data['price_currency'] : 'EUR',
        'service_duration' => isset($service_data['duration']) ? $service_data['duration'] : '',
        'service_category' => isset($service_data['category']) ? $service_data['category'] : '',
        'partner_id' => $partner_id,
        'customer_id' => $current_user_id,
        'customer_email' => $customer_email,
        'customer_name' => $customer_name,
        'status' => 'pending',
        'created_at' => current_time('mysql'),
        'selected_at' => current_time('mysql')
    );
    
    // Save to transient (partner-specific)
    set_transient('car_accessories_request_' . $request_id . '_partner_' . $partner_id, $form_data, 30 * DAY_IN_SECONDS);
    
    // Save to user meta for permanent storage
    $customer_requests = get_user_meta($current_user_id, 'customer_service_requests', true);
    if (!is_array($customer_requests)) {
        $customer_requests = array();
    }
    
    $request_entry = array(
        'request_id' => $request_id,
        'partner_id' => $partner_id,
        'status' => 'pending',
        'created_at' => current_time('mysql'),
        'form_data' => $form_data
    );
    $customer_requests[] = $request_entry;
    update_user_meta($current_user_id, 'customer_service_requests', $customer_requests);
    
    // Create notification for partner
    $service_title = isset($service_data['title']) ? $service_data['title'] : 'Service Request';
    wheelfy_create_notification(
        $partner_id,
        'new_request',
        __('New Service Request', 'wheelfy'),
        sprintf(__('You received a new service request from %s for "%s".', 'wheelfy'), $customer_name, $service_title),
        array(
            'request_id' => $request_id,
            'customer_id' => $current_user_id,
            'customer_name' => $customer_name,
            'link' => home_url('/partner-dashboard#requests')
        )
    );
    
    // Send email notification to partner
    wheelfy_send_new_request_email_to_partner($partner_id, $request_id, $form_data, $current_user_id);
    
    // Redirect to customer dashboard (same as form-based requests)
    // Request will appear in customer's dashboard and partner's dashboard
    wp_safe_redirect(home_url('/customer-dashboard#requests'));
    exit;
}
add_action('init', 'wheelfy_handle_service_request', 0);

/**
 * Handle Request Status Update (Accept/Delete) via AJAX
 */
function wheelfy_update_request_status() {
    // Suppress PHP errors/warnings from corrupting JSON response
    @ini_set('display_errors', 0);
    error_reporting(0);
    
    // Clean any previous output to ensure valid JSON response
    while (ob_get_level()) {
        ob_end_clean();
    }
    ob_start();
    
    try {
        // Helper to send error with clean output
        $send_error = function($message) {
            if (ob_get_level()) ob_end_clean();
            wp_send_json_error(array('message' => $message));
        };
        
        // Verify nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_nonce')) {
            $send_error('Security check failed.');
        }
        
        // Check if user is logged in and is a partner
        if (!is_user_logged_in()) {
            $send_error('You must be logged in.');
        }
        
        $current_user = wp_get_current_user();
        if (!in_array('partner', $current_user->roles)) {
            $send_error('Unauthorized.');
        }
        
        $partner_id = $current_user->ID;
        $request_id_full = isset($_POST['request_id']) ? sanitize_text_field($_POST['request_id']) : '';
        $status = isset($_POST['status']) ? sanitize_text_field($_POST['status']) : '';
        
        if (empty($request_id_full) || empty($status)) {
            $send_error('Missing required parameters.');
        }
    
    // Validate status - Added waiting_customer_approval for new workflow
    $valid_statuses = array('pending', 'accepted', 'waiting_customer_approval', 'rejected', 'deleted');
    if (!in_array($status, $valid_statuses)) {
        $send_error('Invalid status.');
    }
    
    // Parse request_id (format: req_xxx_partner_y or req_xxx)
    $parts = explode('_partner_', $request_id_full);
    $request_id = $parts[0];
    $request_partner_id = isset($parts[1]) ? intval($parts[1]) : $partner_id;
    
    // Verify this request belongs to this partner
    if ($request_partner_id != $partner_id) {
        $send_error('Unauthorized. This request does not belong to you.');
    }
    
    // Get price and note for partner acceptance (NEW WORKFLOW)
    $offer_price = isset($_POST['offer_price']) ? floatval($_POST['offer_price']) : 0;
    $offer_note = isset($_POST['offer_note']) ? sanitize_textarea_field($_POST['offer_note']) : '';
    
    $customer_id = 0;
    $customer_email = '';
    $form_data = null;
    
    // Get request data from transient FIRST to check request_type
    $transient_key = 'car_accessories_request_' . $request_id . '_partner_' . $partner_id;
    $form_data = get_transient($transient_key);
    
    // If transient not found with partner suffix, try without it
    if (!$form_data || !is_array($form_data)) {
        $transient_key_base = 'car_accessories_request_' . $request_id;
        $form_data = get_transient($transient_key_base);
    }
    
    // Check request_type - "sell_car" doesn't need price (car price is already set)
    $request_type = '';
    if ($form_data && is_array($form_data) && isset($form_data['request_type'])) {
        $request_type = $form_data['request_type'];
    }
    
    // NEW WORKFLOW: If partner is accepting
    $use_new_workflow = false;
    $is_sell_car = ($request_type === 'sell_car');
    
    if ($status === 'accepted') {
        if ($is_sell_car) {
            // Sell Car requests: Accept directly without price requirement
            // The car price is already included in the listing
            $status = 'accepted';
            $use_new_workflow = false; // Use direct acceptance for sell_car
        } else {
            // Other requests: Price is REQUIRED
            if (!isset($_POST['offer_price']) || $_POST['offer_price'] === '' || $offer_price <= 0) {
                $send_error('Service price is required. Please enter a valid price to accept this request.');
            }
            
            // New workflow: Partner accepts with price - status becomes waiting_customer_approval
            $status = 'waiting_customer_approval';
            $use_new_workflow = true;
        }
    }
    
    if ($form_data && is_array($form_data)) {
        $customer_id = isset($form_data['customer_id']) ? intval($form_data['customer_id']) : 0;
        $customer_email = isset($form_data['customer_email']) ? $form_data['customer_email'] : '';
        
        // If customer_id is 0 but we have email, try to find customer
        if ($customer_id == 0 && !empty($customer_email)) {
            $customer_user = get_user_by('email', $customer_email);
            if ($customer_user) {
                $customer_id = $customer_user->ID;
            }
        }
        
        // Update status
        $form_data['status'] = $status;
        $form_data['updated_at'] = current_time('mysql');
        $form_data['partner_id'] = $partner_id;
        
        // Store offer details for new workflow
        if ($use_new_workflow) {
            $form_data['offer_price'] = $offer_price;
            $form_data['offer_note'] = $offer_note;
            $form_data['offer_date'] = current_time('mysql');
            $form_data['workflow_version'] = 'v2'; // Mark as new workflow
        }
        
        // Update transient
        set_transient($transient_key, $form_data, 30 * DAY_IN_SECONDS);
        
        // Also update customer's user meta if logged in
        if ($customer_id > 0) {
            $customer_requests = get_user_meta($customer_id, 'customer_service_requests', true);
            if (!is_array($customer_requests)) {
                $customer_requests = array();
            }
            
            $found_in_meta = false;
            foreach ($customer_requests as $key => $req) {
                // Use loose comparison for partner_id (could be string or int)
                $req_id = isset($req['request_id']) ? $req['request_id'] : '';
                $req_partner = isset($req['partner_id']) ? intval($req['partner_id']) : 0;
                
                // Match by request_id AND (partner_id matches OR partner_id is 0/not set - meaning first time offer)
                $id_match = ($req_id === $request_id);
                $partner_match = ($req_partner == intval($partner_id)) || ($req_partner == 0);
                
                if ($id_match && $partner_match) {
                    $customer_requests[$key]['status'] = $status;
                    $customer_requests[$key]['updated_at'] = current_time('mysql');
                    $customer_requests[$key]['partner_id'] = $partner_id; // Update partner_id in case it was 0
                    
                    // Store offer details for new workflow
                    if ($use_new_workflow) {
                        $customer_requests[$key]['offer_price'] = $offer_price;
                        $customer_requests[$key]['offer_note'] = $offer_note;
                        $customer_requests[$key]['offer_date'] = current_time('mysql');
                        $customer_requests[$key]['workflow_version'] = 'v2';
                    }
                    
                    $found_in_meta = true;
                    break;
                }
            }
            
            // If not found, create new entry from form_data - but check for duplicates first
            if (!$found_in_meta && is_array($form_data)) {
                // Double-check we don't already have this request (by request_id only)
                $already_exists = false;
                foreach ($customer_requests as $existing_req) {
                    $existing_id = isset($existing_req['request_id']) ? $existing_req['request_id'] : '';
                    if ($existing_id === $request_id) {
                        $already_exists = true;
                        break;
                    }
                }
                
                if (!$already_exists) {
                    $new_entry = $form_data;
                    $new_entry['request_id'] = $request_id;
                    $new_entry['partner_id'] = $partner_id;
                    $new_entry['status'] = $status;
                    $new_entry['updated_at'] = current_time('mysql');
                    
                    if ($use_new_workflow) {
                        $new_entry['offer_price'] = $offer_price;
                        $new_entry['offer_note'] = $offer_note;
                        $new_entry['offer_date'] = current_time('mysql');
                        $new_entry['workflow_version'] = 'v2';
                    }
                    
                    $customer_requests[] = $new_entry;
                }
            }
            
            update_user_meta($customer_id, 'customer_service_requests', $customer_requests);
        }
    } else {
        // Try to get from post meta
        if (strpos($request_id, 'post_') === 0) {
            $post_id = intval(str_replace('post_', '', $request_id));
            if ($post_id > 0) {
                $customer_id = get_post_field('post_author', $post_id);
                $customer_user = get_userdata($customer_id);
                $customer_email = $customer_user ? $customer_user->user_email : '';
                update_post_meta($post_id, '_proposal_status', $status);
                update_post_meta($post_id, 'partner_id', $partner_id);
                update_post_meta($post_id, 'status_updated_at', current_time('mysql'));
                
                // Store offer details for new workflow
                if ($use_new_workflow) {
                    update_post_meta($post_id, '_proposal_offer_price', $offer_price);
                    update_post_meta($post_id, '_proposal_offer_note', $offer_note);
                    update_post_meta($post_id, '_proposal_offer_date', current_time('mysql'));
                    update_post_meta($post_id, '_proposal_workflow_version', 'v2');
                }
            }
        } else {
            // Fallback: Search in all customer_service_requests user meta
            // This handles cases where transient expired but request exists in user meta
            global $wpdb;
            $customer_requests_meta = $wpdb->get_results(
                "SELECT user_id, meta_value FROM {$wpdb->usermeta} 
                 WHERE meta_key = 'customer_service_requests'"
            );
            
            foreach ($customer_requests_meta as $meta) {
                $requests = maybe_unserialize($meta->meta_value);
                if (!is_array($requests)) continue;
                
                foreach ($requests as $key => $req) {
                    if (isset($req['request_id']) && $req['request_id'] === $request_id && 
                        isset($req['partner_id']) && intval($req['partner_id']) == intval($partner_id)) {
                        
                        $customer_id = intval($meta->user_id);
                        $customer_user = get_userdata($customer_id);
                        $customer_email = $customer_user ? $customer_user->user_email : '';
                        
                        // Update the request status
                        $requests[$key]['status'] = $status;
                        $requests[$key]['updated_at'] = current_time('mysql');
                        
                        if ($use_new_workflow) {
                            $requests[$key]['offer_price'] = $offer_price;
                            $requests[$key]['offer_note'] = $offer_note;
                            $requests[$key]['offer_date'] = current_time('mysql');
                            $requests[$key]['workflow_version'] = 'v2';
                        }
                        
                        update_user_meta($customer_id, 'customer_service_requests', $requests);
                        
                        // Get form_data from the request
                        $form_data = isset($req['form_data']) ? $req['form_data'] : $req;
                        
                        // Recreate transient for future use
                        $transient_key = 'car_accessories_request_' . $request_id . '_partner_' . $partner_id;
                        if (is_array($form_data)) {
                            $form_data['status'] = $status;
                            $form_data['customer_id'] = $customer_id;
                            $form_data['customer_email'] = $customer_email;
                            if ($use_new_workflow) {
                                $form_data['offer_price'] = $offer_price;
                                $form_data['offer_note'] = $offer_note;
                                $form_data['offer_date'] = current_time('mysql');
                                $form_data['workflow_version'] = 'v2';
                            }
                            set_transient($transient_key, $form_data, 30 * DAY_IN_SECONDS);
                        }
                        
                        break 2; // Break both loops
                    }
                }
            }
        }
    }
    
    // NEW WORKFLOW: Partner sends offer (waiting_customer_approval)
    // Customer must approve before chat is created
    if ($use_new_workflow && $status === 'waiting_customer_approval') {
        if ($customer_id > 0 && $partner_id > 0) {
            $partner_name = get_user_meta($partner_id, 'business_name', true) ?: $current_user->display_name;
            
            // Create notification for customer about the offer
            wheelfy_create_notification(
                $customer_id,
                'partner_offer',
                __('New Offer Received', 'wheelfy'),
                sprintf(__('%s has sent you an offer of %s for your request. Please review and approve.', 'wheelfy'), $partner_name, wheelfy_format_price($offer_price)),
                array(
                    'request_id' => $request_id, 
                    'partner_id' => $partner_id, 
                    'offer_price' => $offer_price,
                    'offer_note' => $offer_note,
                    'link' => home_url('/customer-dashboard#requests'),
                    'action_text' => 'View Offer'
                )
            );
            
            // Send email notification about offer (wrapped in try-catch)
            try {
                wheelfy_send_partner_offer_email_to_customer($customer_id, $request_id, $partner_id, $partner_name, $offer_price, $offer_note, $form_data);
            } catch (Exception $email_error) {
                error_log('Wheelfy Email Error (Exception): ' . $email_error->getMessage());
                // Don't fail the whole request just because email failed
            } catch (Error $email_error) {
                error_log('Wheelfy Email Error (Fatal): ' . $email_error->getMessage());
                // Don't fail the whole request just because email failed
            }
        } else {
            // Log warning but don't fail - offer was saved, just notification couldn't be sent
            error_log('Wheelfy Warning: Offer saved but customer_id is 0, cannot send notification. Request ID: ' . $request_id);
        }
    }
    
    // LEGACY WORKFLOW: If accepting without new workflow (backward compatibility)
    // Create chat thread automatically for old requests
    if (!$use_new_workflow && $status === 'accepted' && $customer_id > 0 && $partner_id > 0) {
        $thread_id = wheelfy_get_or_create_thread($customer_id, $partner_id, $request_id);
        
        // Create notification for customer
        $partner_name = get_user_meta($partner_id, 'business_name', true) ?: $current_user->display_name;
        wheelfy_create_notification(
            $customer_id,
            'request_accepted',
            __('Request Accepted', 'wheelfy'),
            sprintf(__('Your request has been accepted by %s. You can now chat with them.', 'wheelfy'), $partner_name),
            array('request_id' => $request_id, 'partner_id' => $partner_id, 'thread_id' => $thread_id)
        );
        
        // Send email notification to customer (pass form_data if available)
        if (!$form_data) {
            // Try to get form_data from transient
            $transient_key = 'car_accessories_request_' . $request_id . '_partner_' . $partner_id;
            $form_data = get_transient($transient_key);
        }
        wheelfy_send_request_accepted_email_to_customer($customer_id, $request_id, $partner_id, $partner_name, $form_data);
    } elseif ($status === 'rejected' || $status === 'deleted') {
        // Create notification for customer
        $partner_name = get_user_meta($partner_id, 'business_name', true) ?: $current_user->display_name;
        wheelfy_create_notification(
            $customer_id,
            'request_rejected',
            __('Request Declined', 'wheelfy'),
            sprintf(__('Your request was declined by %s.', 'wheelfy'), $partner_name),
            array('request_id' => $request_id, 'partner_id' => $partner_id)
        );
    }
    
    // Clean output buffer before sending response
    if (ob_get_level()) {
        ob_end_clean();
    }
    
    wp_send_json_success(array(
        'message' => 'Request status updated successfully.',
        'status' => $status,
        'thread_id' => isset($thread_id) ? $thread_id : null
    ));
    
    } catch (Exception $e) {
        // Log the error for debugging
        error_log('Wheelfy Update Request Status Error: ' . $e->getMessage());
        
        // Clean output buffer before sending error response
        if (ob_get_level()) {
            ob_end_clean();
        }
        
        wp_send_json_error(array('message' => 'An error occurred: ' . $e->getMessage()));
    } catch (Error $e) {
        // Catch PHP 7+ fatal errors
        error_log('Wheelfy Update Request Status Fatal Error: ' . $e->getMessage());
        
        if (ob_get_level()) {
            ob_end_clean();
        }
        
        wp_send_json_error(array('message' => 'A system error occurred. Please try again.'));
    }
}
add_action('wp_ajax_update_request_status', 'wheelfy_update_request_status');

/**
 * Get partner requests (AJAX)
 */
function wheelfy_get_partner_requests() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_nonce')) {
        wp_send_json_error(array('message' => 'Security check failed.'));
    }
    
    // Check if user is logged in and is a partner
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'You must be logged in.'));
    }
    
    $current_user = wp_get_current_user();
    if (!in_array('partner', $current_user->roles)) {
        wp_send_json_error(array('message' => 'Unauthorized.'));
    }
    
    $partner_id = $current_user->ID;
    $status_filter = isset($_POST['status_filter']) ? sanitize_text_field($_POST['status_filter']) : 'all';
    
    $requests = wheelfy_get_partner_requests_data($partner_id, $status_filter);
    $pending_count = wheelfy_get_partner_pending_request_count($partner_id);
    
    wp_send_json_success(array(
        'requests' => $requests,
        'pending_count' => $pending_count
    ));
}
add_action('wp_ajax_get_partner_requests', 'wheelfy_get_partner_requests');

/**
 * Get partner requests data
 */
function wheelfy_get_partner_requests_data($partner_id, $status_filter = 'all') {
    $requests = array();
    
    // Query transients for this partner
    global $wpdb;
    $transient_prefix = '_transient_car_accessories_request_';
    $transient_keys = $wpdb->get_col($wpdb->prepare(
        "SELECT option_name FROM {$wpdb->options} 
        WHERE option_name LIKE %s
        AND option_name LIKE %s
        ORDER BY option_id DESC",
        $wpdb->esc_like($transient_prefix) . '%',
        '%_partner_' . $partner_id
    ));
    
    foreach ($transient_keys as $transient_name) {
        $transient_key = str_replace('_transient_', '', $transient_name);
        $transient_key = str_replace('_transient_timeout_', '', $transient_key);
        
        // Extract request_id from transient key
        $key_part = str_replace('car_accessories_request_', '', $transient_key);
        $parts = explode('_partner_', $key_part);
        $request_id = $parts[0];
        
        $form_data = get_transient('car_accessories_request_' . $request_id . '_partner_' . $partner_id);
        
        if ($form_data && isset($form_data['status'])) {
            $status = $form_data['status'];
            
            // Apply status filter
            if ($status_filter !== 'all') {
                if ($status_filter === 'complete') {
                    // For "complete" filter, match both "complete" and "completed"
                    if ($status !== 'complete' && $status !== 'completed') {
                        continue;
                    }
                } else {
                    // For other filters, exact match
                    if ($status !== $status_filter) {
                        continue;
                    }
                }
            }
            
            // Only show pending requests by default, but allow filter to show all
            $customer_id = isset($form_data['customer_id']) ? intval($form_data['customer_id']) : 0;
            $customer_email = isset($form_data['customer_email']) ? $form_data['customer_email'] : '';
            $customer_name = 'Unknown Customer';
            
            if ($customer_id > 0) {
                $customer_user = get_userdata($customer_id);
                if ($customer_user) {
                    $customer_name = $customer_user->display_name ?: $customer_user->user_login;
                }
            } elseif (!empty($customer_email)) {
                $customer_name = $customer_email;
            }
            
            // Build request details
            $request_details = 'Service Request';
            $request_type = isset($form_data['request_type']) ? $form_data['request_type'] : '';
            
            // Check if this is a service-based request
            if ($request_type === 'service' && isset($form_data['service_title'])) {
                $request_details = $form_data['service_title'] . ' - Service Request';
            } elseif ($request_type === 'sell_car' && isset($form_data['make']) && isset($form_data['model']) && isset($form_data['year'])) {
                // Sell Car request
                $request_details = $form_data['year'] . ' ' . $form_data['make'] . ' ' . $form_data['model'] . ' - Sell Car Request';
                if (isset($form_data['price']) && !empty($form_data['price'])) {
                    $request_details .= ' (€' . number_format(floatval($form_data['price']), 0, ',', ' ') . ')';
                }
            } elseif ($request_type === 'service_book' && isset($form_data['make']) && isset($form_data['model']) && isset($form_data['year'])) {
                // Service Book request
                $request_details = $form_data['year'] . ' ' . $form_data['make'] . ' ' . $form_data['model'] . ' - Service Book Request';
            } elseif ($request_type === 'previous_service' && isset($form_data['make']) && isset($form_data['model']) && isset($form_data['year'])) {
                // Previous Service request
                $request_details = $form_data['year'] . ' ' . $form_data['make'] . ' ' . $form_data['model'] . ' - Previous Service Request';
            } elseif ($request_type === 'car_accessories' && isset($form_data['make']) && isset($form_data['model']) && isset($form_data['year'])) {
                // Car Accessories request
                $request_details = $form_data['year'] . ' ' . $form_data['make'] . ' ' . $form_data['model'] . ' - Car Accessories Request';
                if (isset($form_data['services']) && is_array($form_data['services']) && !empty($form_data['services'])) {
                    $request_details .= ' (' . implode(', ', array_slice($form_data['services'], 0, 3)) . ')';
                } elseif (isset($form_data['accessories']) && is_array($form_data['accessories']) && !empty($form_data['accessories'])) {
                    $request_details .= ' (' . implode(', ', array_slice($form_data['accessories'], 0, 3)) . ')';
                }
            } elseif (isset($form_data['make']) && isset($form_data['model']) && isset($form_data['year'])) {
                // Form-based request (car accessories, etc.) - default fallback
                $request_details = $form_data['year'] . ' ' . $form_data['make'] . ' ' . $form_data['model'] . ' - Car Services Request';
                if (isset($form_data['services']) && is_array($form_data['services']) && !empty($form_data['services'])) {
                    $request_details .= ' (' . implode(', ', array_slice($form_data['services'], 0, 3)) . ')';
                }
            }
            
            $request_date = isset($form_data['timestamp']) ? $form_data['timestamp'] : (isset($form_data['created_at']) ? $form_data['created_at'] : current_time('mysql'));
            
            // Calculate time ago for display
            $request_timestamp = strtotime($request_date);
            $current_timestamp = current_time('timestamp');
            $time_diff = $current_timestamp - $request_timestamp;
            
            $time_ago = '';
            if ($time_diff < 60) {
                $time_ago = 'Just now';
            } elseif ($time_diff < 3600) {
                $minutes = floor($time_diff / 60);
                $time_ago = $minutes . ' minute' . ($minutes > 1 ? 's' : '') . ' ago';
            } elseif ($time_diff < 86400) {
                $hours = floor($time_diff / 3600);
                $time_ago = $hours . ' hour' . ($hours > 1 ? 's' : '') . ' ago';
            } elseif ($time_diff < 604800) {
                $days = floor($time_diff / 86400);
                $time_ago = $days . ' day' . ($days > 1 ? 's' : '') . ' ago';
            } elseif ($time_diff < 2592000) {
                $weeks = floor($time_diff / 604800);
                $time_ago = $weeks . ' week' . ($weeks > 1 ? 's' : '') . ' ago';
            } else {
                $months = floor($time_diff / 2592000);
                $time_ago = $months . ' month' . ($months > 1 ? 's' : '') . ' ago';
            }
            
            // Convert car_photos attachment IDs to URLs for sell_car requests
            if (isset($form_data['request_type']) && $form_data['request_type'] === 'sell_car' && isset($form_data['car_photos']) && is_array($form_data['car_photos'])) {
                $car_photos_urls = array();
                foreach ($form_data['car_photos'] as $photo_id) {
                    if (is_numeric($photo_id)) {
                        $image_url = wp_get_attachment_image_url($photo_id, 'medium');
                        if ($image_url) {
                            $car_photos_urls[] = array(
                                'id' => $photo_id,
                                'url' => $image_url,
                                'full_url' => wp_get_attachment_image_url($photo_id, 'full')
                            );
                        }
                    }
                }
                if (!empty($car_photos_urls)) {
                    $form_data['car_photos_urls'] = $car_photos_urls;
                }
            }
            
            $requests[] = array(
                'id' => $request_id . '_partner_' . $partner_id,
                'request_id' => $request_id,
                'partner_id' => $partner_id,
                'customer_id' => $customer_id,
                'customer_name' => $customer_name,
                'customer_email' => $customer_email,
                'request_type' => isset($form_data['request_type']) ? $form_data['request_type'] : 'normal',
                'request_details' => $request_details,
                'request_date' => $request_date,
                'request_timestamp' => $request_timestamp,
                'time_ago' => $time_ago,
                'status' => $status,
                'form_data' => $form_data
            );
        }
    }
    
    // Track request IDs to avoid duplicates
    $seen_request_ids = array();
    foreach ($requests as $req) {
        if (isset($req['request_id'])) {
            $seen_request_ids[$req['request_id']] = true;
        }
        // Also track by customer_email + partner_id combination for better de-duplication
        if (isset($req['customer_email']) && !empty($req['customer_email'])) {
            $seen_request_ids[$req['customer_email'] . '_' . $partner_id] = true;
        }
    }
    
    // Also check posts (proposals) - but avoid duplicates
    $proposal_args = array(
        'post_type' => 'post',
        'posts_per_page' => -1,
        'meta_query' => array(
            array(
                'key' => 'partner_id',
                'value' => $partner_id,
                'compare' => '='
            )
        ),
        'orderby' => 'date',
        'order' => 'DESC'
    );
    
    $proposal_posts = get_posts($proposal_args);
    foreach ($proposal_posts as $post) {
        // Check if this post's request already exists in transients (avoid duplicates)
        $post_request_id = get_post_meta($post->ID, '_proposal_request_id', true);
        $post_email = get_post_meta($post->ID, '_proposal_email', true);
        
        // Skip if we already have this request from transient
        if (!empty($post_request_id) && isset($seen_request_ids[$post_request_id])) {
            continue;
        }
        
        // Also skip if same email+partner combo (different way request could be duplicated)
        if (!empty($post_email) && isset($seen_request_ids[$post_email . '_' . $partner_id])) {
            continue;
        }
        $status = get_post_meta($post->ID, '_proposal_status', true) ?: 'pending';
        
        // Handle status filter
        if ($status_filter !== 'all') {
            if ($status_filter === 'complete') {
                // For "complete" filter, match both "complete" and "completed"
                if ($status !== 'complete' && $status !== 'completed') {
                    continue;
                }
            } else {
                // For other filters, exact match
                if ($status !== $status_filter) {
                    continue;
                }
            }
        }
        
        $customer_id = get_post_field('post_author', $post->ID);
        $customer_user = get_userdata($customer_id);
        $customer_name = $customer_user ? ($customer_user->display_name ?: $customer_user->user_login) : 'Unknown Customer';
        $customer_email = $customer_user ? $customer_user->user_email : '';
        
        // Calculate time ago for display
        $request_timestamp = strtotime($post->post_date);
        $current_timestamp = current_time('timestamp');
        $time_diff = $current_timestamp - $request_timestamp;
        
        $time_ago = '';
        if ($time_diff < 60) {
            $time_ago = 'Just now';
        } elseif ($time_diff < 3600) {
            $minutes = floor($time_diff / 60);
            $time_ago = $minutes . ' minute' . ($minutes > 1 ? 's' : '') . ' ago';
        } elseif ($time_diff < 86400) {
            $hours = floor($time_diff / 3600);
            $time_ago = $hours . ' hour' . ($hours > 1 ? 's' : '') . ' ago';
        } elseif ($time_diff < 604800) {
            $days = floor($time_diff / 86400);
            $time_ago = $days . ' day' . ($days > 1 ? 's' : '') . ' ago';
        } elseif ($time_diff < 2592000) {
            $weeks = floor($time_diff / 604800);
            $time_ago = $weeks . ' week' . ($weeks > 1 ? 's' : '') . ' ago';
        } else {
            $months = floor($time_diff / 2592000);
            $time_ago = $months . ' month' . ($months > 1 ? 's' : '') . ' ago';
        }
        
        $requests[] = array(
            'id' => 'post_' . $post->ID . '_partner_' . $partner_id,
            'request_id' => 'post_' . $post->ID,
            'partner_id' => $partner_id,
            'customer_id' => $customer_id,
            'customer_name' => $customer_name,
            'customer_email' => $customer_email,
            'request_type' => 'normal',
            'request_details' => get_the_title($post->ID) ?: 'Service Request',
            'request_date' => $post->post_date,
            'request_timestamp' => $request_timestamp,
            'time_ago' => $time_ago,
            'status' => $status,
            'form_data' => array()
        );
    }
    
    // Sort by date (newest first)
    usort($requests, function($a, $b) {
        return strtotime($b['request_date']) - strtotime($a['request_date']);
    });
    
    return $requests;
}

/**
 * Get partner pending request count
 */
/**
 * Get partner completed jobs count
 */
function wheelfy_get_partner_completed_jobs_count($partner_id) {
    $completed_statuses = array('complete', 'completed');
    $total_completed = 0;
    $processed_request_keys = array();
    
    // Query 1: Get requests from posts where partner is assigned
    $proposal_args = array(
        'post_type' => 'post',
        'posts_per_page' => -1,
        'meta_query' => array(
            array(
                'key' => 'partner_id',
                'value' => $partner_id,
                'compare' => '='
            ),
            array(
                'key' => '_proposal_status',
                'compare' => 'EXISTS'
            )
        ),
        'orderby' => 'date',
        'order' => 'DESC'
    );
    
    $proposal_posts = get_posts($proposal_args);
    foreach ($proposal_posts as $post) {
        $status = get_post_meta($post->ID, '_proposal_status', true) ?: 'pending';
        if (in_array($status, $completed_statuses)) {
            $request_key = 'post_' . $post->ID . '_partner_' . $partner_id;
            if (!in_array($request_key, $processed_request_keys)) {
                $total_completed++;
                $processed_request_keys[] = $request_key;
            }
        }
    }
    
    // Query 2: Get requests from customer user meta where partner is assigned
    global $wpdb;
    $customer_requests_meta = $wpdb->get_results($wpdb->prepare(
        "SELECT user_id, meta_value FROM {$wpdb->usermeta}
        WHERE meta_key = 'wheelfy_service_requests'
        AND meta_value LIKE %s",
        '%"partner_id";i:' . $partner_id . ';%'
    ));
    
    foreach ($customer_requests_meta as $meta_row) {
        $saved_requests = maybe_unserialize($meta_row->meta_value);
        
        if (is_array($saved_requests)) {
            foreach ($saved_requests as $saved_request) {
                if (!isset($saved_request['partner_id']) || intval($saved_request['partner_id']) != $partner_id) {
                    continue;
                }
                
                $request_id = isset($saved_request['request_id']) ? $saved_request['request_id'] : '';
                $request_key = $request_id . '_partner_' . $partner_id;
                
                if (!in_array($request_key, $processed_request_keys)) {
                    $status = isset($saved_request['status']) ? $saved_request['status'] : 'pending';
                    if (in_array($status, $completed_statuses)) {
                        $total_completed++;
                        $processed_request_keys[] = $request_key;
                    }
                }
            }
        }
    }
    
    // Query 3: Check transients (recent form submissions with partner assigned)
    $transient_prefix = '_transient_car_accessories_request_';
    $transient_timeout_prefix = '_transient_timeout_car_accessories_request_';
    
    $transient_keys = $wpdb->get_col($wpdb->prepare(
        "SELECT option_name FROM {$wpdb->options} 
        WHERE (option_name LIKE %s OR option_name LIKE %s)
        AND option_name NOT LIKE %s
        ORDER BY option_id DESC",
        $transient_prefix . '%',
        $transient_prefix . '%_partner_%',
        $transient_timeout_prefix . '%'
    ));
    
    foreach ($transient_keys as $transient_key) {
        $key_part = str_replace($transient_prefix, '', $transient_key);
        if (strpos($key_part, '_partner_') !== false) {
            $parts = explode('_partner_', $key_part);
            $request_id = $parts[0];
            $transient_partner_id = isset($parts[1]) ? intval($parts[1]) : 0;
            $form_data = get_transient('car_accessories_request_' . $request_id . '_partner_' . $transient_partner_id);
        } else {
            $request_id = $key_part;
            $form_data = get_transient('car_accessories_request_' . $request_id);
            $transient_partner_id = isset($form_data['partner_id']) ? intval($form_data['partner_id']) : 0;
        }
        
        if ($form_data && isset($form_data['timestamp']) && $transient_partner_id == $partner_id) {
            $request_key = $request_id . '_partner_' . $partner_id;
            
            if (!in_array($request_key, $processed_request_keys)) {
                $status = isset($form_data['status']) ? $form_data['status'] : 'pending';
                if (in_array($status, $completed_statuses)) {
                    $total_completed++;
                    $processed_request_keys[] = $request_key;
                }
            }
        }
    }
    
    return $total_completed;
}

/**
 * Get partner cars purchased count (for Car Dealership partners)
 * Counts completed sell_car requests
 */
function wheelfy_get_partner_cars_purchased_count($partner_id) {
    $completed_statuses = array('complete', 'completed');
    $total_cars_purchased = 0;
    $processed_request_keys = array();
    
    // Query 1: Get requests from customer user meta where partner is assigned and request_type is sell_car
    global $wpdb;
    $customer_requests_meta = $wpdb->get_results($wpdb->prepare(
        "SELECT user_id, meta_value FROM {$wpdb->usermeta}
        WHERE meta_key = 'customer_service_requests'
        AND meta_value LIKE %s",
        '%"partner_id";i:' . $partner_id . ';%'
    ));
    
    foreach ($customer_requests_meta as $meta_row) {
        $saved_requests = maybe_unserialize($meta_row->meta_value);
        
        if (is_array($saved_requests)) {
            foreach ($saved_requests as $saved_request) {
                if (!isset($saved_request['partner_id']) || intval($saved_request['partner_id']) != $partner_id) {
                    continue;
                }
                
                // Check if this is a sell_car request
                $form_data = isset($saved_request['form_data']) ? $saved_request['form_data'] : array();
                $request_type = isset($form_data['request_type']) ? $form_data['request_type'] : '';
                
                if ($request_type !== 'sell_car') {
                    continue;
                }
                
                $request_id = isset($saved_request['request_id']) ? $saved_request['request_id'] : '';
                $request_key = $request_id . '_partner_' . $partner_id;
                
                if (!in_array($request_key, $processed_request_keys)) {
                    $status = isset($saved_request['status']) ? $saved_request['status'] : 'pending';
                    if (in_array($status, $completed_statuses)) {
                        $total_cars_purchased++;
                        $processed_request_keys[] = $request_key;
                    }
                }
            }
        }
    }
    
    // Query 2: Check transients for sell_car requests
    $transient_prefix = '_transient_car_accessories_request_';
    $transient_timeout_prefix = '_transient_timeout_car_accessories_request_';
    
    $transient_keys = $wpdb->get_col($wpdb->prepare(
        "SELECT option_name FROM {$wpdb->options} 
        WHERE (option_name LIKE %s OR option_name LIKE %s)
        AND option_name NOT LIKE %s
        ORDER BY option_id DESC",
        $transient_prefix . '%',
        $transient_prefix . '%_partner_%',
        $transient_timeout_prefix . '%'
    ));
    
    foreach ($transient_keys as $transient_key) {
        $key_part = str_replace($transient_prefix, '', $transient_key);
        if (strpos($key_part, '_partner_') !== false) {
            $parts = explode('_partner_', $key_part);
            $request_id = $parts[0];
            $transient_partner_id = isset($parts[1]) ? intval($parts[1]) : 0;
            $form_data = get_transient('car_accessories_request_' . $request_id . '_partner_' . $transient_partner_id);
        } else {
            $request_id = $key_part;
            $form_data = get_transient('car_accessories_request_' . $request_id);
            $transient_partner_id = isset($form_data['partner_id']) ? intval($form_data['partner_id']) : 0;
        }
        
        if ($form_data && isset($form_data['timestamp']) && $transient_partner_id == $partner_id) {
            // Check if this is a sell_car request
            $request_type = isset($form_data['request_type']) ? $form_data['request_type'] : '';
            
            if ($request_type === 'sell_car') {
                $request_key = $request_id . '_partner_' . $partner_id;
                
                if (!in_array($request_key, $processed_request_keys)) {
                    $status = isset($form_data['status']) ? $form_data['status'] : 'pending';
                    if (in_array($status, $completed_statuses)) {
                        $total_cars_purchased++;
                        $processed_request_keys[] = $request_key;
                    }
                }
            }
        }
    }
    
    return $total_cars_purchased;
}

function wheelfy_get_partner_pending_request_count($partner_id) {
    $requests = wheelfy_get_partner_requests_data($partner_id, 'pending');
    return count($requests);
}

/**
 * Handle Customer Request Cancellation via AJAX
 */
function wheelfy_cancel_customer_request() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_nonce')) {
        wp_send_json_error(array('message' => 'Security check failed.'));
    }
    
    // Check if user is logged in and is a customer
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'You must be logged in.'));
    }
    
    $current_user = wp_get_current_user();
    if (!in_array('customer', $current_user->roles)) {
        wp_send_json_error(array('message' => 'Unauthorized. Only customers can cancel requests.'));
    }
    
    $request_id = isset($_POST['request_id']) ? sanitize_text_field($_POST['request_id']) : '';
    
    if (empty($request_id)) {
        wp_send_json_error(array('message' => 'Missing required parameters.'));
    }
    
    $current_user_id = get_current_user_id();
    $customer_requests = get_user_meta($current_user_id, 'customer_service_requests', true);
    
    if (!is_array($customer_requests)) {
        wp_send_json_error(array('message' => 'Request not found.'));
    }
    
    $request_found = false;
    $updated_requests = array();
    
    foreach ($customer_requests as $request) {
        // Check if this is the request to cancel
        // Handle both formats: 'req_xxx' and 'req_xxx_partner_y'
        $request_identifier = isset($request['request_id']) ? $request['request_id'] : '';
        $full_request_id = isset($request['partner_id']) ? $request_identifier . '_partner_' . $request['partner_id'] : $request_identifier;
        
        if ($request_id === $full_request_id || $request_id === $request_identifier) {
            // Only allow cancellation of pending requests
            if (isset($request['status']) && $request['status'] === 'pending') {
                $request['status'] = 'cancelled';
                $request['cancelled_at'] = current_time('mysql');
                $request_found = true;
            } else {
                wp_send_json_error(array('message' => 'Only pending requests can be cancelled.'));
            }
        }
        $updated_requests[] = $request;
    }
    
    if (!$request_found) {
        wp_send_json_error(array('message' => 'Request not found or already processed.'));
    }
    
    // Update user meta
    update_user_meta($current_user_id, 'customer_service_requests', $updated_requests);
    
    // Also update transient if it exists
    if (strpos($request_id, '_partner_') !== false) {
        $parts = explode('_partner_', $request_id);
        $base_request_id = $parts[0];
        $partner_id = isset($parts[1]) ? intval($parts[1]) : 0;
        
        if ($partner_id > 0) {
            $transient_data = get_transient('car_accessories_request_' . $base_request_id . '_partner_' . $partner_id);
            if ($transient_data) {
                $transient_data['status'] = 'cancelled';
                $transient_data['cancelled_at'] = current_time('mysql');
                set_transient('car_accessories_request_' . $base_request_id . '_partner_' . $partner_id, $transient_data, 30 * DAY_IN_SECONDS);
            }
        }
    }
    
    // Create notification for partner
    if ($partner_id > 0) {
        do_action('wheelfy_request_cancelled', $request_id, $current_user_id, $partner_id);
    }
    
    wp_send_json_success(array(
        'message' => 'Request cancelled successfully.',
        'request_id' => $request_id
    ));
}
add_action('wp_ajax_cancel_customer_request', 'wheelfy_cancel_customer_request');

/**
 * AJAX Handler: Get Customer Requests Dynamically
 */
function wheelfy_ajax_get_customer_requests() {
    // Suppress PHP errors from corrupting JSON
    @ini_set('display_errors', 0);
    error_reporting(0);
    while (ob_get_level()) ob_end_clean();
    ob_start();
    
    // Check if user is logged in
    if (!is_user_logged_in()) {
        ob_end_clean();
        wp_send_json_error(array('message' => 'User not logged in'));
        return;
    }
    
    $current_user_id = get_current_user_id();
    $customer_requests = array();
    
    // Query 1: Get requests from posts (proposals) created by current user
    $proposal_args = array(
        'post_type' => 'post',
        'author' => $current_user_id,
        'posts_per_page' => -1,
        'meta_query' => array(
            array(
                'key' => '_proposal_status',
                'compare' => 'EXISTS'
            )
        ),
        'orderby' => 'date',
        'order' => 'DESC'
    );
    
    $proposal_posts = get_posts($proposal_args);
    
    foreach ($proposal_posts as $post) {
        $request_id = 'post_' . $post->ID;
        $status = get_post_meta($post->ID, '_proposal_status', true) ?: 'pending';
        $partner_id = get_post_meta($post->ID, 'partner_id', true) ?: 0;
        
        // Show ALL requests - including those without partners (pending assignment)
        // This allows customers to see their requests in real-time
        
        $request_type = get_post_meta($post->ID, '_proposal_request_type', true) ?: 'Service Request';
        
        // Get car details for request details
        $car_brand = get_post_meta($post->ID, '_proposal_car_brand', true);
        $car_model = get_post_meta($post->ID, '_proposal_car_model', true);
        $car_year = get_post_meta($post->ID, '_proposal_car_year', true);
        $request_details = '';
        if ($car_brand && $car_model && $car_year) {
            $request_details = $car_year . ' ' . $car_brand . ' ' . $car_model . ' - ' . $request_type;
        } else {
            $request_details = $post->post_title;
        }
        
        // Get partner info
        $partner_name = 'Not Assigned';
        $partner_tier = 'premium';
        $partner_rating = 4.5;
        $partner_location = 'Location not set';
        $partner_logo = '';
        $partner_type = '';
        $partner_price = '';
        $partner_price_currency = '';
        
        if ($partner_id > 0) {
            $partner_user = get_userdata($partner_id);
            if ($partner_user) {
                $partner_name = get_user_meta($partner_id, 'business_name', true);
                if (empty($partner_name)) {
                    $partner_name = $partner_user->display_name ?: $partner_user->user_login;
                }
                $partner_tier = get_user_meta($partner_id, 'partner_tier', true) ?: 'premium';
                $partner_type = get_user_meta($partner_id, 'partner_type', true) ?: '';
                // Get dynamic rating from reviews, fallback to stored rating or 0.0
                $partner_rating = wheelfy_get_partner_dynamic_rating($partner_id);
                if ($partner_rating == 0.0) {
                    $partner_rating = get_user_meta($partner_id, 'partner_rating', true);
                    if (empty($partner_rating) || $partner_rating === '0') {
                        $partner_rating = 0.0; // Show 0.0 if no reviews instead of fake 4.5
                    } else {
                        $partner_rating = floatval($partner_rating);
                    }
                }
                $partner_location = get_user_meta($partner_id, 'user_location', true) ?: 'Location not set';
                
                // Get partner price
                $partner_price = get_user_meta($partner_id, 'partner_price', true);
                $partner_price_currency = get_user_meta($partner_id, 'partner_price_currency', true) ?: 'USD';
                
                // Format price
                $price_display = 'Not set';
                if ($partner_price) {
                    $currency_symbols = array('USD' => '$', 'HUF' => 'Ft');
                    $symbol = isset($currency_symbols[$partner_price_currency]) ? $currency_symbols[$partner_price_currency] : '$';
                    $price_display = number_format(floatval($partner_price), 2) . ' ' . $symbol . ' ' . $partner_price_currency;
                }
                
                // Get partner logo
                $logo_id = get_user_meta($partner_id, 'partner_logo_id', true);
                if (empty($logo_id)) {
                    $logo_id = get_user_meta($partner_id, 'profile_image_id', true);
                }
                if ($logo_id && is_numeric($logo_id)) {
                    $partner_logo = wp_get_attachment_image_url($logo_id, 'thumbnail');
                    if (!$partner_logo) {
                        $partner_logo = wp_get_attachment_image_url($logo_id, 'medium');
                    }
                }
                if (empty($partner_logo)) {
                    $partner_logo = get_avatar_url($partner_id, array('size' => 64, 'default' => 'mm'));
                }
            }
        }
        
            // Get partner email and phone
            $partner_email = '';
            $partner_phone = '';
            if ($partner_id > 0) {
                $partner_user = get_userdata($partner_id);
                if ($partner_user) {
                    $partner_email = $partner_user->user_email;
                    $partner_phone = get_user_meta($partner_id, 'phone_number', true) ?: '';
                }
            }
            
            $customer_requests[] = array(
                'id' => $request_id,
                'request_type' => $request_type,
                'request_details' => $request_details,
                'partner_id' => $partner_id,
                'partner_name' => $partner_name,
                'partner_tier' => $partner_tier,
                'partner_rating' => floatval($partner_rating),
                'partner_location' => $partner_location,
                'partner_email' => $partner_email,
                'partner_phone' => $partner_phone,
                'partner_logo' => $partner_logo,
                'partner_type' => $partner_type,
                'partner_price' => isset($price_display) ? $price_display : 'Not set',
                'status' => $status,
                'request_date' => $post->post_date,
                'quotes_received' => 0,
                'last_update' => human_time_diff(strtotime($post->post_modified), current_time('timestamp')) . ' ago'
            );
    }
    
    // Track seen request IDs to prevent duplicates between posts and user meta
    $seen_request_ids = array();
    foreach ($customer_requests as $req) {
        // Track by post ID
        if (isset($req['id']) && strpos($req['id'], 'post_') === 0) {
            $post_id = intval(str_replace('post_', '', $req['id']));
            // Get the _proposal_request_id if it exists
            $prop_request_id = get_post_meta($post_id, '_proposal_request_id', true);
            if (!empty($prop_request_id)) {
                $seen_request_ids[$prop_request_id] = true;
            }
        }
        $seen_request_ids[$req['id']] = true;
    }
    
    // Query 2: Get requests from user meta (permanent storage) - avoid duplicates
    $saved_requests = get_user_meta($current_user_id, 'customer_service_requests', true);
    if (is_array($saved_requests) && !empty($saved_requests)) {
        foreach ($saved_requests as $saved_request) {
            if (!isset($saved_request['request_id']) || !isset($saved_request['partner_id'])) {
                continue;
            }
            
            $request_id = $saved_request['request_id'];
            $partner_id = intval($saved_request['partner_id']);
            
            // Create unique key for this request-partner combination
            $unique_key = $request_id . '_partner_' . $partner_id;
            
            // Skip if we already have this request (de-duplication from posts OR within user meta)
            if (isset($seen_request_ids[$request_id]) || isset($seen_request_ids[$unique_key])) {
                continue;
            }
            
            // Mark this request as seen to prevent duplicates within user meta itself
            $seen_request_ids[$request_id] = true;
            $seen_request_ids[$unique_key] = true;
            
            $status = isset($saved_request['status']) ? $saved_request['status'] : 'pending';
            $created_at = isset($saved_request['created_at']) ? $saved_request['created_at'] : current_time('mysql');
            $form_data = isset($saved_request['form_data']) ? $saved_request['form_data'] : array();
            
            // Show ALL requests - including those without partners (pending assignment)
            // This allows customers to see their requests in real-time
            
            // Get partner info
            $partner_name = 'Not Assigned';
            $partner_tier = 'premium';
            $partner_rating = 4.5;
            $partner_location = 'Location not set';
            $partner_type = '';
            $partner_price = '';
            $partner_price_currency = '';
            
            $partner_logo = '';
            if ($partner_id > 0) {
                $partner_user = get_userdata($partner_id);
                if ($partner_user) {
                    $partner_name = get_user_meta($partner_id, 'business_name', true);
                    if (empty($partner_name)) {
                        $partner_name = $partner_user->display_name ?: $partner_user->user_login;
                    }
                    $partner_tier = get_user_meta($partner_id, 'partner_tier', true) ?: 'premium';
                    $partner_type = get_user_meta($partner_id, 'partner_type', true) ?: '';
                    // Get dynamic rating from reviews, fallback to stored rating or 0.0
                    if (function_exists('wheelfy_get_partner_dynamic_rating')) {
                        $partner_rating = wheelfy_get_partner_dynamic_rating($partner_id);
                        if ($partner_rating == 0.0) {
                            $partner_rating = get_user_meta($partner_id, 'partner_rating', true);
                            if (empty($partner_rating) || $partner_rating === '0') {
                                $partner_rating = 0.0; // Show 0.0 if no reviews instead of fake 4.5
                            } else {
                                $partner_rating = floatval($partner_rating);
                            }
                        }
                    } else {
                        $partner_rating = get_user_meta($partner_id, 'partner_rating', true);
                        if (empty($partner_rating) || $partner_rating === '0') {
                            $partner_rating = 0.0;
                        } else {
                            $partner_rating = floatval($partner_rating);
                        }
                    }
                    $partner_location = get_user_meta($partner_id, 'user_location', true) ?: 'Location not set';
                    
                    // Get partner price
                    $partner_price = get_user_meta($partner_id, 'partner_price', true);
                    $partner_price_currency = get_user_meta($partner_id, 'partner_price_currency', true) ?: 'USD';
                    
                    // Format price
                    $price_display = 'Not set';
                    if ($partner_price) {
                        $currency_symbols = array('USD' => '$', 'HUF' => 'Ft');
                        $symbol = isset($currency_symbols[$partner_price_currency]) ? $currency_symbols[$partner_price_currency] : '$';
                        $price_display = number_format(floatval($partner_price), 2) . ' ' . $symbol . ' ' . $partner_price_currency;
                    }
                    
                    // Get partner logo
                    $logo_id = get_user_meta($partner_id, 'partner_logo_id', true);
                    if (empty($logo_id)) {
                        $logo_id = get_user_meta($partner_id, 'profile_image_id', true);
                    }
                    if ($logo_id && is_numeric($logo_id)) {
                        $partner_logo = wp_get_attachment_image_url($logo_id, 'thumbnail');
                        if (!$partner_logo) {
                            $partner_logo = wp_get_attachment_image_url($logo_id, 'medium');
                        }
                    }
                    if (empty($partner_logo)) {
                        $partner_logo = get_avatar_url($partner_id, array('size' => 64, 'default' => 'mm'));
                    }
                }
            }
            
            // Build request details
            $request_details = 'Service Request';
            $request_type = isset($form_data['request_type']) ? $form_data['request_type'] : '';
            
            // Check if this is a service-based request
            if ($request_type === 'service' && isset($form_data['service_title'])) {
                $request_details = $form_data['service_title'] . ' - Service Request';
            } elseif ($request_type === 'sell_car' && isset($form_data['make']) && isset($form_data['model']) && isset($form_data['year'])) {
                // Sell Car request
                $request_details = $form_data['year'] . ' ' . $form_data['make'] . ' ' . $form_data['model'] . ' - Sell Car Request';
                if (isset($form_data['price']) && !empty($form_data['price'])) {
                    $request_details .= ' (€' . number_format(floatval($form_data['price']), 0, ',', ' ') . ')';
                }
            } elseif ($request_type === 'service_book' && isset($form_data['make']) && isset($form_data['model']) && isset($form_data['year'])) {
                // Service Book request
                $request_details = $form_data['year'] . ' ' . $form_data['make'] . ' ' . $form_data['model'] . ' - Service Book Request';
            } elseif ($request_type === 'previous_service' && isset($form_data['make']) && isset($form_data['model']) && isset($form_data['year'])) {
                // Previous Service request
                $request_details = $form_data['year'] . ' ' . $form_data['make'] . ' ' . $form_data['model'] . ' - Previous Service Request';
            } elseif (isset($form_data['make']) && isset($form_data['model']) && isset($form_data['year'])) {
                // Form-based request (car accessories, etc.) - default
                $request_details = $form_data['year'] . ' ' . $form_data['make'] . ' ' . $form_data['model'] . ' - Car Accessories Request';
                if (isset($form_data['services']) && is_array($form_data['services']) && !empty($form_data['services'])) {
                    $request_details .= ' (' . implode(', ', array_slice($form_data['services'], 0, 3)) . ')';
                } elseif (isset($form_data['accessories']) && is_array($form_data['accessories']) && !empty($form_data['accessories'])) {
                    $request_details .= ' (' . implode(', ', array_slice($form_data['accessories'], 0, 3)) . ')';
                }
            } elseif (isset($form_data['timestamp'])) {
                $request_details = 'Car Services Request';
            }
            
            $request_date = isset($form_data['timestamp']) ? $form_data['timestamp'] : $created_at;
            
            // Get partner email and phone
            $partner_email = '';
            $partner_phone = '';
            if ($partner_id > 0) {
                $partner_user = get_userdata($partner_id);
                if ($partner_user) {
                    $partner_email = $partner_user->user_email;
                    $partner_phone = get_user_meta($partner_id, 'phone_number', true) ?: '';
                }
            }
            
            // Determine request type for display
            $display_request_type = 'Car Services';
            if ($request_type === 'service') {
                $display_request_type = 'Service Request';
            } elseif (!empty($request_type)) {
                $display_request_type = ucfirst(str_replace('_', ' ', $request_type)) . ' Request';
            }
            
            // Get offer details for new workflow
            $offer_price = isset($saved_request['offer_price']) ? floatval($saved_request['offer_price']) : (isset($form_data['offer_price']) ? floatval($form_data['offer_price']) : 0);
            $offer_note = isset($saved_request['offer_note']) ? $saved_request['offer_note'] : (isset($form_data['offer_note']) ? $form_data['offer_note'] : '');
            $workflow_version = isset($saved_request['workflow_version']) ? $saved_request['workflow_version'] : (isset($form_data['workflow_version']) ? $form_data['workflow_version'] : '');
            
            $customer_requests[] = array(
                'id' => $request_id . '_partner_' . $partner_id,
                'request_type' => $display_request_type,
                'request_details' => $request_details,
                'partner_id' => $partner_id,
                'partner_name' => $partner_name,
                'partner_tier' => $partner_tier,
                'partner_rating' => floatval($partner_rating),
                'partner_location' => $partner_location,
                'partner_email' => $partner_email,
                'partner_phone' => $partner_phone,
                'partner_logo' => $partner_logo,
                'partner_type' => $partner_type,
                'partner_price' => isset($price_display) ? $price_display : 'Not set',
                'status' => $status,
                'request_date' => $request_date,
                'quotes_received' => 0,
                'last_update' => human_time_diff(strtotime($request_date), current_time('timestamp')) . ' ago',
                // New workflow fields
                'offer_price' => $offer_price,
                'offer_note' => $offer_note,
                'workflow_version' => $workflow_version
            );
        }
    }
    
    // Query 3: Get requests from transients (recent form submissions with partner assigned)
    global $wpdb;
    $transient_prefix = '_transient_car_accessories_request_';
    $transient_timeout_prefix = '_transient_timeout_car_accessories_request_';
    
    // Get all transients that match our pattern (including partner-specific ones)
    $transient_keys = $wpdb->get_col($wpdb->prepare(
        "SELECT option_name FROM {$wpdb->options} 
        WHERE (option_name LIKE %s OR option_name LIKE %s)
        AND option_name NOT LIKE %s
        ORDER BY option_id DESC",
        $transient_prefix . '%',
        $transient_prefix . '%_partner_%',
        $transient_timeout_prefix . '%'
    ));
    
    // Track which base request IDs we've already processed to avoid duplicates
    $processed_request_ids = array();
    
    // First pass: collect all partner-specific transients (they take priority)
    $partner_transients = array();
    $base_transients = array();
    
    foreach ($transient_keys as $transient_key) {
        $key_part = str_replace($transient_prefix, '', $transient_key);
        if (strpos($key_part, '_partner_') !== false) {
            $parts = explode('_partner_', $key_part);
            $base_id = $parts[0];
            $partner_transients[$base_id] = $transient_key;
        } else {
            $base_transients[$key_part] = $transient_key;
        }
    }
    
    // Process transients - partner-specific ones take priority over base ones
    foreach ($transient_keys as $transient_key) {
        // Extract request_id and partner_id if present
        $key_part = str_replace($transient_prefix, '', $transient_key);
        if (strpos($key_part, '_partner_') !== false) {
            $parts = explode('_partner_', $key_part);
            $request_id = $parts[0];
            $partner_id = isset($parts[1]) ? intval($parts[1]) : 0;
            $form_data = get_transient('car_accessories_request_' . $request_id . '_partner_' . $partner_id);
        } else {
            $request_id = $key_part;
            
            // SKIP base transient if a partner-specific version exists
            // This prevents duplicate entries (one with partner, one without)
            if (isset($partner_transients[$request_id])) {
                continue; // Partner version will be processed instead
            }
            
            $form_data = get_transient('car_accessories_request_' . $request_id);
            $partner_id = isset($form_data['partner_id']) ? intval($form_data['partner_id']) : 0;
        }
        
        // Skip if we've already processed this base request ID
        if (isset($processed_request_ids[$request_id])) {
            continue;
        }
        
        if ($form_data && isset($form_data['timestamp'])) {
            // CRITICAL SECURITY FIX: Only show requests that belong to the current customer
            // Check if this request belongs to the current logged-in user
            if (isset($form_data['customer_id'])) {
                // If customer_id is set, it MUST match current user
                if (intval($form_data['customer_id']) !== $current_user_id) {
                    continue; // Skip - this request belongs to another customer
                }
            } elseif (isset($form_data['customer_email'])) {
                // Fallback: Check by email if customer_id not set
                $current_user = wp_get_current_user();
                if ($form_data['customer_email'] !== $current_user->user_email) {
                    continue; // Skip - this request belongs to another customer
                }
            } else {
                // No customer identifier - skip this transient for security
                // These are orphan requests without ownership
                continue;
            }
            
            // Skip if already added from user meta or posts (check by base request ID)
            $already_added = false;
            foreach ($customer_requests as $existing_request) {
                // Check if the base request ID matches (ignore partner suffix)
                $existing_base_id = $existing_request['id'];
                if (strpos($existing_base_id, '_partner_') !== false) {
                    $existing_base_id = explode('_partner_', $existing_base_id)[0];
                }
                if ($existing_base_id === $request_id) {
                    $already_added = true;
                    break;
                }
            }
            if ($already_added) {
                continue;
            }
            
            // Mark this base request ID as processed
            $processed_request_ids[$request_id] = true;
            
            $status = isset($form_data['status']) ? $form_data['status'] : 'pending';
            
            // Get partner info
            $partner_name = 'Not Assigned';
            $partner_tier = 'premium';
            $partner_rating = 4.5;
            $partner_location = 'Location not set';
            $partner_logo = '';
            $partner_type = '';
            $partner_price = '';
            $partner_price_currency = '';
            
            if ($partner_id > 0) {
                $partner_user = get_userdata($partner_id);
                if ($partner_user) {
                    $partner_name = get_user_meta($partner_id, 'business_name', true);
                    if (empty($partner_name)) {
                        $partner_name = $partner_user->display_name ?: $partner_user->user_login;
                    }
                    $partner_tier = get_user_meta($partner_id, 'partner_tier', true) ?: 'premium';
                    $partner_type = get_user_meta($partner_id, 'partner_type', true) ?: '';
                    // Get dynamic rating from reviews, fallback to stored rating or 0.0
                    if (function_exists('wheelfy_get_partner_dynamic_rating')) {
                        $partner_rating = wheelfy_get_partner_dynamic_rating($partner_id);
                        if ($partner_rating == 0.0) {
                            $partner_rating = get_user_meta($partner_id, 'partner_rating', true);
                            if (empty($partner_rating) || $partner_rating === '0') {
                                $partner_rating = 0.0; // Show 0.0 if no reviews instead of fake 4.5
                            } else {
                                $partner_rating = floatval($partner_rating);
                            }
                        }
                    } else {
                        $partner_rating = get_user_meta($partner_id, 'partner_rating', true);
                        if (empty($partner_rating) || $partner_rating === '0') {
                            $partner_rating = 0.0;
                        } else {
                            $partner_rating = floatval($partner_rating);
                        }
                    }
                    $partner_location = get_user_meta($partner_id, 'user_location', true) ?: 'Location not set';
                    
                    // Get partner price
                    $partner_price = get_user_meta($partner_id, 'partner_price', true);
                    $partner_price_currency = get_user_meta($partner_id, 'partner_price_currency', true) ?: 'USD';
                    
                    // Format price
                    $price_display = 'Not set';
                    if ($partner_price) {
                        $currency_symbols = array('USD' => '$', 'HUF' => 'Ft');
                        $symbol = isset($currency_symbols[$partner_price_currency]) ? $currency_symbols[$partner_price_currency] : '$';
                        $price_display = number_format(floatval($partner_price), 2) . ' ' . $symbol . ' ' . $partner_price_currency;
                    }
                    
                    // Get partner logo
                    $logo_id = get_user_meta($partner_id, 'partner_logo_id', true);
                    if (empty($logo_id)) {
                        $logo_id = get_user_meta($partner_id, 'profile_image_id', true);
                    }
                    if ($logo_id && is_numeric($logo_id)) {
                        $partner_logo = wp_get_attachment_image_url($logo_id, 'thumbnail');
                        if (!$partner_logo) {
                            $partner_logo = wp_get_attachment_image_url($logo_id, 'medium');
                        }
                    }
                    if (empty($partner_logo)) {
                        $partner_logo = get_avatar_url($partner_id, array('size' => 64, 'default' => 'mm'));
                    }
                }
            }
            
            // Build request details
            $request_details = 'Service Request';
            $request_type = isset($form_data['request_type']) ? $form_data['request_type'] : '';
            
            if ($request_type === 'sell_car' && isset($form_data['make']) && isset($form_data['model']) && isset($form_data['year'])) {
                // Sell Car request
                $request_details = $form_data['year'] . ' ' . $form_data['make'] . ' ' . $form_data['model'] . ' - Sell Car Request';
                if (isset($form_data['price']) && !empty($form_data['price'])) {
                    $request_details .= ' (€' . number_format(floatval($form_data['price']), 0, ',', ' ') . ')';
                }
            } elseif ($request_type === 'service_book' && isset($form_data['make']) && isset($form_data['model']) && isset($form_data['year'])) {
                // Service Book request
                $request_details = $form_data['year'] . ' ' . $form_data['make'] . ' ' . $form_data['model'] . ' - Service Book Request';
            } elseif ($request_type === 'previous_service' && isset($form_data['make']) && isset($form_data['model']) && isset($form_data['year'])) {
                // Previous Service request
                $request_details = $form_data['year'] . ' ' . $form_data['make'] . ' ' . $form_data['model'] . ' - Previous Service Request';
            } elseif ($request_type === 'car_accessories' && isset($form_data['make']) && isset($form_data['model']) && isset($form_data['year'])) {
                // Car Accessories request
                $request_details = $form_data['year'] . ' ' . $form_data['make'] . ' ' . $form_data['model'] . ' - Car Accessories Request';
                if (isset($form_data['services']) && is_array($form_data['services']) && !empty($form_data['services'])) {
                    $request_details .= ' (' . implode(', ', array_slice($form_data['services'], 0, 3)) . ')';
                } elseif (isset($form_data['accessories']) && is_array($form_data['accessories']) && !empty($form_data['accessories'])) {
                    $request_details .= ' (' . implode(', ', array_slice($form_data['accessories'], 0, 3)) . ')';
                }
            } elseif (isset($form_data['make']) && isset($form_data['model']) && isset($form_data['year'])) {
                // Form-based request (car accessories, etc.) - default fallback
                $request_details = $form_data['year'] . ' ' . $form_data['make'] . ' ' . $form_data['model'] . ' - Car Services Request';
                if (isset($form_data['services']) && is_array($form_data['services']) && !empty($form_data['services'])) {
                    $request_details .= ' (' . implode(', ', array_slice($form_data['services'], 0, 3)) . ')';
                }
            }
            
            // Get partner email and phone
            $partner_email = '';
            $partner_phone = '';
            if ($partner_id > 0) {
                $partner_user = get_userdata($partner_id);
                if ($partner_user) {
                    $partner_email = $partner_user->user_email;
                    $partner_phone = get_user_meta($partner_id, 'phone_number', true) ?: '';
                }
            }
            
            // Format request_type for display
            $display_request_type = 'Car Services';
            if ($request_type === 'sell_car') {
                $display_request_type = 'Sell Car Request';
            } elseif ($request_type === 'service_book') {
                $display_request_type = 'Service Book Request';
            } elseif ($request_type === 'previous_service') {
                $display_request_type = 'Previous Service Request';
            } elseif ($request_type === 'car_accessories') {
                $display_request_type = 'Car Accessories Request';
            } elseif (!empty($request_type)) {
                $display_request_type = ucfirst(str_replace('_', ' ', $request_type)) . ' Request';
            }
            
            $customer_requests[] = array(
                'id' => $request_id . '_partner_' . $partner_id,
                'request_type' => $display_request_type,
                'request_details' => $request_details,
                'partner_id' => $partner_id,
                'partner_name' => $partner_name,
                'partner_tier' => $partner_tier,
                'partner_rating' => floatval($partner_rating),
                'partner_location' => $partner_location,
                'partner_email' => $partner_email,
                'partner_phone' => $partner_phone,
                'partner_logo' => $partner_logo,
                'partner_type' => $partner_type,
                'partner_price' => isset($price_display) ? $price_display : 'Not set',
                'status' => $status,
                'request_date' => $form_data['timestamp'],
                'quotes_received' => 0,
                'last_update' => human_time_diff(strtotime($form_data['timestamp']), current_time('timestamp')) . ' ago'
            );
        }
    }
    
    // Return ALL requests (not just accepted) - allows real-time viewing of all statuses
    // Sort by date (newest first)
    usort($customer_requests, function($a, $b) {
        return strtotime($b['request_date']) - strtotime($a['request_date']);
    });
    
    if (ob_get_level()) ob_end_clean();
    wp_send_json_success(array(
        'requests' => array_values($customer_requests),
        'count' => count($customer_requests)
    ));
}
add_action('wp_ajax_get_customer_requests', 'wheelfy_ajax_get_customer_requests');

/**
 * Handle Profile Image Upload via AJAX
 */
function wheelfy_upload_profile_image() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_nonce')) {
        wp_send_json_error(array('message' => 'Security check failed. Please refresh the page and try again.'));
    }
    
    // Check if user is logged in
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'You must be logged in to upload images.'));
    }
    
    $current_user_id = get_current_user_id();
    
    // Check if file was uploaded
    if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
        wp_send_json_error(array('message' => 'No file was uploaded or there was an upload error.'));
    }
    
    // Validate file type
    $file = $_FILES['file'];
    $allowed_types = array('image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp');
    $file_type = wp_check_filetype($file['name']);
    
    if (!in_array($file['type'], $allowed_types) && !in_array($file_type['type'], $allowed_types)) {
        wp_send_json_error(array('message' => 'Invalid file type. Please upload a JPEG, PNG, GIF, or WebP image.'));
    }
    
    // Validate file size (max 5MB)
    $max_size = 5 * 1024 * 1024; // 5MB in bytes
    if ($file['size'] > $max_size) {
        wp_send_json_error(array('message' => 'File is too large. Maximum size is 5MB.'));
    }
    
    // Include WordPress file handling functions
    require_once(ABSPATH . 'wp-admin/includes/file.php');
    require_once(ABSPATH . 'wp-admin/includes/image.php');
    require_once(ABSPATH . 'wp-admin/includes/media.php');
    
    // Handle file upload
    $upload = wp_handle_upload($file, array('test_form' => false));
    
    if (isset($upload['error'])) {
        wp_send_json_error(array('message' => $upload['error']));
    }
    
    // Create attachment
    $attachment = array(
        'post_mime_type' => $upload['type'],
        'post_title' => sanitize_file_name(pathinfo($file['name'], PATHINFO_FILENAME)),
        'post_content' => '',
        'post_status' => 'inherit',
        'post_author' => $current_user_id,
    );
    
    $attach_id = wp_insert_attachment($attachment, $upload['file']);
    
    if (is_wp_error($attach_id)) {
        wp_send_json_error(array('message' => 'Failed to create attachment.'));
    }
    
    // Generate attachment metadata
    $attach_data = wp_generate_attachment_metadata($attach_id, $upload['file']);
    wp_update_attachment_metadata($attach_id, $attach_data);
    
    // Delete old profile image if exists
    $old_attachment_id = get_user_meta($current_user_id, 'profile_image_id', true);
    if ($old_attachment_id && is_numeric($old_attachment_id)) {
        wp_delete_attachment($old_attachment_id, true);
    }
    
    // Save attachment ID to user meta
    update_user_meta($current_user_id, 'profile_image_id', $attach_id);
    
    // Get image URL
    $image_url = wp_get_attachment_image_url($attach_id, 'full');
    
    // Return success with image URL
    wp_send_json_success(array(
        'url' => $image_url,
        'attachment_id' => $attach_id,
        'message' => 'Profile image uploaded successfully.'
    ));
}
add_action('wp_ajax_upload_profile_image', 'wheelfy_upload_profile_image');

/**
 * Handle Profile Information Update via AJAX
 */
function wheelfy_update_profile_info() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_nonce')) {
        wp_send_json_error(array('message' => 'Security check failed. Please refresh the page and try again.'));
    }
    
    // Check if user is logged in
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'You must be logged in to update profile.'));
    }
    
    $current_user_id = get_current_user_id();
    $current_user = wp_get_current_user();
    
    // Get and sanitize data
    $name = isset($_POST['name']) ? sanitize_text_field($_POST['name']) : '';
    $business_name = isset($_POST['business_name']) ? sanitize_text_field($_POST['business_name']) : '';
    $full_name = isset($_POST['full_name']) ? sanitize_text_field($_POST['full_name']) : '';
    $email = isset($_POST['email']) ? sanitize_email($_POST['email']) : '';
    $phone = isset($_POST['phone']) ? sanitize_text_field($_POST['phone']) : '';
    $location = isset($_POST['location']) ? sanitize_text_field($_POST['location']) : '';
    
    // Validate email if provided
    if ($email && !is_email($email)) {
        wp_send_json_error(array('message' => 'Invalid email address.'));
    }
    
    // Check if email is already in use by another user
    if ($email && $email !== $current_user->user_email) {
        $email_exists = email_exists($email);
        if ($email_exists && $email_exists !== $current_user_id) {
            wp_send_json_error(array('message' => 'This email is already registered to another account.'));
        }
    }
    
    // Update user email if changed
    if ($email && $email !== $current_user->user_email) {
        $user_data = array(
            'ID' => $current_user_id,
            'user_email' => $email
        );
        wp_update_user($user_data);
    }
    
    // Update display name if name field changed
    if ($name && $name !== $current_user->display_name) {
        $user_data = array(
            'ID' => $current_user_id,
            'display_name' => $name
        );
        wp_update_user($user_data);
        // Also update first_name for consistency
        update_user_meta($current_user_id, 'first_name', $name);
    }
    
    // Update display name if full_name changed (for backward compatibility)
    if ($full_name && $full_name !== $current_user->display_name && !$name) {
        $user_data = array(
            'ID' => $current_user_id,
            'display_name' => $full_name
        );
        wp_update_user($user_data);
    }
    
    // Save to user meta
    if ($business_name) {
        update_user_meta($current_user_id, 'business_name', $business_name);
    }
    if ($phone !== '') {
        update_user_meta($current_user_id, 'user_phone', $phone);
        update_user_meta($current_user_id, 'phone_number', $phone); // Also save as phone_number for customer dashboard compatibility
    }
    if ($location !== '') {
        update_user_meta($current_user_id, 'user_location', $location);
    }
    
    wp_send_json_success(array(
        'message' => 'Profile information updated successfully.',
        'name' => $name,
        'business_name' => $business_name,
        'full_name' => $full_name,
        'email' => $email,
        'phone' => $phone,
        'location' => $location
    ));
}
add_action('wp_ajax_update_profile_info', 'wheelfy_update_profile_info');

/**
 * Handle Biography Update via AJAX
 */
function wheelfy_update_bio() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_nonce')) {
        wp_send_json_error(array('message' => 'Security check failed. Please refresh the page and try again.'));
    }
    
    // Check if user is logged in
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'You must be logged in to update biography.'));
    }
    
    $current_user_id = get_current_user_id();
    
    // Get and sanitize bio
    $bio = isset($_POST['bio']) ? sanitize_textarea_field($_POST['bio']) : '';
    
    // Save to user meta
    update_user_meta($current_user_id, 'user_bio', $bio);
    
    wp_send_json_success(array(
        'message' => 'Biography updated successfully.',
        'bio' => $bio
    ));
}
add_action('wp_ajax_update_bio', 'wheelfy_update_bio');

/**
 * Handle Social Media Links Update via AJAX
 */
function wheelfy_update_social_links() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_nonce')) {
        wp_send_json_error(array('message' => 'Security check failed. Please refresh the page and try again.'));
    }
    
    // Check if user is logged in
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'You must be logged in to update social links.'));
    }
    
    $current_user_id = get_current_user_id();
    
    // Get and sanitize social links
    $facebook = isset($_POST['facebook']) ? esc_url_raw($_POST['facebook']) : '';
    $twitter = isset($_POST['twitter']) ? esc_url_raw($_POST['twitter']) : '';
    $instagram = isset($_POST['instagram']) ? esc_url_raw($_POST['instagram']) : '';
    $linkedin = isset($_POST['linkedin']) ? esc_url_raw($_POST['linkedin']) : '';
    
    // Save to user meta
    update_user_meta($current_user_id, 'user_facebook', $facebook);
    update_user_meta($current_user_id, 'user_twitter', $twitter);
    update_user_meta($current_user_id, 'user_instagram', $instagram);
    update_user_meta($current_user_id, 'user_linkedin', $linkedin);
    
    wp_send_json_success(array(
        'message' => 'Social media links updated successfully.',
        'facebook' => $facebook,
        'twitter' => $twitter,
        'instagram' => $instagram,
        'linkedin' => $linkedin
    ));
}
add_action('wp_ajax_update_social_links', 'wheelfy_update_social_links');

/**
 * Handle Professional Information Update via AJAX
 */
function wheelfy_update_professional_info() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_nonce')) {
        wp_send_json_error(array('message' => 'Security check failed. Please refresh the page and try again.'));
    }
    
    // Check if user is logged in
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'You must be logged in to update professional information.'));
    }
    
    $current_user_id = get_current_user_id();
    $current_user = wp_get_current_user();
    
    // Check if user is a partner
    if (!in_array('partner', $current_user->roles)) {
        wp_send_json_error(array('message' => 'Only partners can update professional information.'));
    }
    
    // Get and sanitize data
    $profession = isset($_POST['profession']) ? sanitize_text_field($_POST['profession']) : '';
    $price = isset($_POST['price']) ? sanitize_text_field($_POST['price']) : '';
    $currency = isset($_POST['currency']) ? sanitize_text_field($_POST['currency']) : 'USD';
    $experience = isset($_POST['experience']) ? sanitize_text_field($_POST['experience']) : '';
    
    // Validate price if provided
    if ($price !== '' && !is_numeric($price)) {
        wp_send_json_error(array('message' => 'Price must be a valid number.'));
    }
    
    // Validate currency
    $allowed_currencies = array('USD', 'HUF');
    if (!in_array($currency, $allowed_currencies)) {
        $currency = 'USD'; // Default to USD if invalid
    }
    
    // Save to user meta
    update_user_meta($current_user_id, 'partner_profession', $profession);
    update_user_meta($current_user_id, 'partner_price', $price);
    update_user_meta($current_user_id, 'partner_price_currency', $currency);
    update_user_meta($current_user_id, 'partner_experience', $experience);
    update_option('wheelfy_currency', $currency);
    
    // Format price display
    $price_display = '';
    if ($price !== '') {
        $currency_symbols = array(
            'USD' => '$',
            'EUR' => '€',
            'GBP' => '£',
            'HUF' => 'Ft'
        );
        $symbol = isset($currency_symbols[$currency]) ? $currency_symbols[$currency] : '$';
        $price_display = number_format(floatval($price), 2) . ' ' . $symbol . ' ' . $currency;
    }
    
    wp_send_json_success(array(
        'message' => 'Professional information updated successfully.',
        'profession' => $profession,
        'price' => $price,
        'price_display' => $price_display,
        'currency' => $currency,
        'experience' => $experience
    ));
}
add_action('wp_ajax_update_professional_info', 'wheelfy_update_professional_info');

/**
 * Handle Login Form Submission
 */
function wheelfy_handle_login() {
    // Only process on POST request
    if (!isset($_SERVER['REQUEST_METHOD']) || $_SERVER['REQUEST_METHOD'] !== 'POST') {
        return;
    }
    
    // Check if this is our login form (check for log and pwd fields)
    if (!isset($_POST['log']) || !isset($_POST['pwd'])) {
        return;
    }
    
    // Verify nonce if present
    if (isset($_POST['wheelfy_login_nonce'])) {
        if (!wp_verify_nonce($_POST['wheelfy_login_nonce'], 'wheelfy_login')) {
            wp_die('Security check failed. Please try again.');
        }
    }
    
    // Don't process if it's WordPress's own login form
    if (isset($_POST['wp-submit']) || (isset($_POST['action']) && $_POST['action'] === 'login' && strpos($_SERVER['REQUEST_URI'], 'wp-login.php') !== false)) {
        return;
    }
    
    // Get login credentials
    $username = sanitize_user($_POST['log']);
    $password = $_POST['pwd'];
    $rememberme = isset($_POST['rememberme']) && $_POST['rememberme'] === 'forever';
    
    // Get login type from POST or GET
    $login_type = 'customer';
    if (isset($_POST['login_type'])) {
        $login_type = sanitize_text_field($_POST['login_type']);
    } elseif (isset($_GET['type']) && $_GET['type'] === 'partner') {
        $login_type = 'partner';
    }
    
    // Validate inputs
    if (empty($username) || empty($password)) {
        $login_url = home_url('/login');
        if ($login_type === 'partner') {
            $login_url = add_query_arg('type', 'partner', $login_url);
        }
        wp_redirect(add_query_arg('login', 'failed', $login_url));
        exit;
    }
    
    // Authenticate user against database
    // This checks if user exists and credentials are correct
    $user = wp_authenticate($username, $password);
    
    // Check if authentication was successful
    if (is_wp_error($user)) {
        // Login failed - user doesn't exist or credentials don't match
        $login_url = home_url('/login');
        if ($login_type === 'partner') {
            $login_url = add_query_arg('type', 'partner', $login_url);
        }
        wp_redirect(add_query_arg('login', 'failed', $login_url));
        exit;
    }
    
    // CRITICAL: Check user's WordPress role FIRST (primary identifier)
    // Get user roles - should be 'administrator', 'customer', or 'partner'
    $user_roles = $user->roles;
    
    // STRICT: Check if user is administrator by role
    if (in_array('administrator', $user_roles)) {
        // User is administrator - allow wp-admin access
        // Login successful - set auth cookie
        wp_clear_auth_cookie();
        wp_set_current_user($user->ID);
        wp_set_auth_cookie($user->ID, $rememberme);
        
        // Clear output buffers before redirect
        while (ob_get_level()) {
            ob_end_clean();
        }
        // Redirect admin to wp-admin
        wp_safe_redirect(admin_url());
        exit;
    }
    
    // User is NOT administrator - must be customer or partner
    // CRITICAL: Ensure custom roles exist
    wheelfy_create_custom_roles();
    
    // Get user_type from database (secondary identifier)
    $user_type = get_user_meta($user->ID, 'user_type', true);
    
    // CRITICAL: Validate and fix user role if incorrect
    // If user has wrong role, fix it based on user_type
    if (in_array('subscriber', $user_roles) || empty($user_roles) || (!in_array('customer', $user_roles) && !in_array('partner', $user_roles))) {
        // User has wrong role - fix it
        if (empty($user_type)) {
            // If user_type not set, use login type
            $user_type = $login_type;
            update_user_meta($user->ID, 'user_type', $user_type);
        }
        
        // Remove all roles
        foreach ($user_roles as $role) {
            $user->remove_role($role);
        }
        
        // Assign correct role
        if ($user_type === 'partner' && get_role('partner')) {
            $user->set_role('partner');
        } else {
            $user->set_role('customer');
            $user_type = 'customer';
            update_user_meta($user->ID, 'user_type', 'customer');
        }
    } else {
        // User has correct role - determine user_type from role
        if (in_array('partner', $user_roles)) {
            $user_type = 'partner';
        } elseif (in_array('customer', $user_roles)) {
            $user_type = 'customer';
        }
        
        // Update user_type meta if not set
        if (empty($user_type)) {
            $user_type = in_array('partner', $user_roles) ? 'partner' : 'customer';
            update_user_meta($user->ID, 'user_type', $user_type);
        }
    }
    
    // CRITICAL: Remove ALL admin capabilities from non-admins
    $user->remove_cap('administrator');
    $user->remove_cap('manage_options');
    $user->remove_cap('manage_network');
    $user->remove_cap('activate_plugins');
    $user->remove_cap('delete_users');
    $user->remove_cap('edit_users');
    
    // Login successful - set auth cookie
    wp_clear_auth_cookie();
    wp_set_current_user($user->ID);
    wp_set_auth_cookie($user->ID, $rememberme);
    
    // Check for redirect_to parameter (for protected form pages)
    $custom_redirect = '';
    if (isset($_POST['redirect_to']) && !empty($_POST['redirect_to'])) {
        $custom_redirect = esc_url_raw($_POST['redirect_to']);
    }
    
    // Determine redirect URL
    if (!empty($custom_redirect) && strpos($custom_redirect, home_url()) === 0) {
        // Redirect to the form page user was trying to access (if it's on the same domain)
        $redirect_to = $custom_redirect;
    } else {
        // Non-admin users (customers/partners) - redirect to their profile dashboard
        // Based on role (primary) and user_type (secondary)
        if ($user_type === 'partner' || in_array('partner', $user->roles)) {
            $redirect_to = home_url('/partner-dashboard');
        } else {
            // Default to customer dashboard
            $redirect_to = home_url('/customer-dashboard');
        }
    }
    
    // Clear output buffers before redirect
    while (ob_get_level()) {
        ob_end_clean();
    }
    
    // Redirect to frontend profile dashboard (NOT wp-admin)
    // This is completely separate from WordPress admin dashboard
    wp_safe_redirect($redirect_to);
    exit;
}
// Run on init with high priority (priority 0) to process login before any output
add_action('init', 'wheelfy_handle_login', 0);

/**
 * Block wp-admin access at the EARLIEST possible point
 * This runs on 'init' hook to catch wp-admin access before anything loads
 */
function wheelfy_block_wp_admin_early() {
    // Only check if trying to access admin area
    if (!is_admin()) {
        return;
    }
    
    // Allow AJAX requests
    if (defined('DOING_AJAX') && DOING_AJAX) {
        return;
    }
    
    // Allow admin-ajax.php
    if (strpos($_SERVER['REQUEST_URI'], 'admin-ajax.php') !== false) {
        return;
    }
    
    // Check if user is logged in
    if (is_user_logged_in()) {
        $current_user = wp_get_current_user();
        
        // STRICT: Check user role directly - must be 'administrator'
        // Block if role is NOT 'administrator'
        if (!in_array('administrator', $current_user->roles)) {
            // Clear output buffers
            while (ob_get_level()) {
                ob_end_clean();
            }
            
            // Get user role to determine redirect
            $user_roles = $current_user->roles;
            $user_type = get_user_meta($current_user->ID, 'user_type', true);
            
            // CRITICAL: Redirect to frontend dashboard - NO EXCEPTIONS
            // Customers and Partners should NEVER see wp-admin
            if (in_array('partner', $user_roles) || $user_type === 'partner') {
                wp_safe_redirect(home_url('/partner-dashboard'));
            } else {
                wp_safe_redirect(home_url('/customer-dashboard'));
            }
            exit;
        }
    }
}
// Run on init with high priority to catch wp-admin access early
add_action('init', 'wheelfy_block_wp_admin_early', 1);

/**
 * Handle Login Redirect Based on User Type
 */
function wheelfy_login_redirect($redirect_to, $requested_redirect_to, $user) {
    // If login failed, return the redirect_to
    if (is_wp_error($user)) {
        return $redirect_to;
    }
    
    // If user is logged in, redirect based on user type
    if (is_a($user, 'WP_User')) {
        // Check if user is administrator
        // STRICT: Check user role directly - must be 'administrator'
        $user_roles = $user->roles;
        
        if (in_array('administrator', $user_roles)) {
            // Administrators can access wp-admin
            // If redirect_to is wp-admin, allow it
            if ($requested_redirect_to && strpos($requested_redirect_to, 'wp-admin') !== false) {
                return $requested_redirect_to;
            }
            // Default admin redirect
            if ($redirect_to && strpos($redirect_to, 'wp-admin') !== false) {
                return $redirect_to;
            }
            // Fallback to admin dashboard
            return admin_url();
        }
        
        // User is NOT administrator - must be customer or partner
        // Get user_type from database (secondary identifier)
        $user_type = get_user_meta($user->ID, 'user_type', true);
        
        // Determine role from WordPress roles (primary) or user_type (secondary)
        $is_partner = in_array('partner', $user_roles) || $user_type === 'partner';
        
        // CRITICAL: Override ANY wp-admin redirect for non-admins
        // Customers and Partners should NEVER access wp-admin
        if ($requested_redirect_to && strpos($requested_redirect_to, 'wp-admin') !== false) {
            // Force redirect to frontend profile dashboard based on role
            if ($is_partner) {
                return home_url('/partner-dashboard');
            } else {
                return home_url('/customer-dashboard');
            }
        }
        
        // Override default wp-admin redirect
        if ($redirect_to && strpos($redirect_to, 'wp-admin') !== false) {
            // Force redirect to frontend profile dashboard based on role
            if ($is_partner) {
                return home_url('/partner-dashboard');
            } else {
                return home_url('/customer-dashboard');
            }
        }
        
        // Default redirect based on role (primary) and user_type (secondary)
        // This ensures customers get customer dashboard, partners get partner dashboard
        // Completely separate from WordPress admin dashboard
        if ($is_partner) {
            return home_url('/partner-dashboard');
        } else {
            return home_url('/customer-dashboard');
        }
    }
    
    return $redirect_to;
}
add_filter('login_redirect', 'wheelfy_login_redirect', 10, 3);

/**
 * Handle Login Errors
 */
function wheelfy_login_failed() {
    $referrer = wp_get_referer();
    if ($referrer && !strpos($referrer, 'wp-login.php') && !strpos($referrer, 'wp-admin')) {
        $login_url = home_url('/login');
        if (strpos($referrer, 'type=partner') !== false) {
            $login_url = add_query_arg('type', 'partner', $login_url);
        }
        wp_redirect(add_query_arg('login', 'failed', $login_url));
        exit;
    }
}
add_action('wp_login_failed', 'wheelfy_login_failed');

/**
 * Prevent non-admin users from accessing WordPress admin dashboard
 * Customers and Partners should NEVER access wp-admin
 */
function wheelfy_restrict_admin_access() {
    // Allow AJAX requests
    if (defined('DOING_AJAX') && DOING_AJAX) {
        return;
    }
    
    // Allow admin-ajax.php requests
    if (strpos($_SERVER['REQUEST_URI'], 'admin-ajax.php') !== false) {
        return;
    }
    
    // Check if user is trying to access admin area
    if (is_admin() && !wp_doing_ajax()) {
        // Get current user
        $current_user = wp_get_current_user();
        
        // STRICT: Check user role directly - must be 'administrator'
        // Block if role is NOT 'administrator'
        if ($current_user->ID > 0 && !in_array('administrator', $current_user->roles)) {
            // Get user role and type
            $user_roles = $current_user->roles;
            $user_type = get_user_meta($current_user->ID, 'user_type', true);
            
            // NO EXCEPTIONS - Customers and Partners cannot access wp-admin
            // Clear output buffers
            while (ob_get_level()) {
                ob_end_clean();
            }
            
            // Redirect to appropriate dashboard based on role
            if (in_array('partner', $user_roles) || $user_type === 'partner') {
                wp_safe_redirect(home_url('/partner-dashboard'));
            } else {
                wp_safe_redirect(home_url('/customer-dashboard'));
            }
            exit;
        }
    }
}
add_action('admin_init', 'wheelfy_restrict_admin_access', 1);

/**
 * Redirect non-admin users away from wp-admin after login
 * Customers and Partners should NEVER access wp-admin
 */
function wheelfy_handle_admin_login_redirect() {
    // Only process if user is logged in and trying to access wp-admin
    if (is_user_logged_in() && is_admin() && !wp_doing_ajax()) {
        $current_user = wp_get_current_user();
        
        // STRICT: Check user role directly - must be 'administrator'
        // Block if role is NOT 'administrator'
        if (!in_array('administrator', $current_user->roles)) {
            // Clear output buffers
            while (ob_get_level()) {
                ob_end_clean();
            }
            
            // Get user role and type
            $user_roles = $current_user->roles;
            $user_type = get_user_meta($current_user->ID, 'user_type', true);
            
            // NO EXCEPTIONS - Redirect immediately based on role
            if (in_array('partner', $user_roles) || $user_type === 'partner') {
                wp_safe_redirect(home_url('/partner-dashboard'));
            } else {
                wp_safe_redirect(home_url('/customer-dashboard'));
            }
            exit;
        }
    }
}
add_action('admin_init', 'wheelfy_handle_admin_login_redirect');

/**
 * Block wp-admin access for non-admins at the EARLIEST possible point
 * This runs before admin_init to catch any early access attempts
 * Runs on 'admin_init' with priority 0 to catch before anything else
 */
function wheelfy_block_wp_admin_for_non_admins() {
    // Only check on admin pages
    if (!is_admin()) {
        return;
    }
    
    // Allow AJAX
    if (defined('DOING_AJAX') && DOING_AJAX) {
        return;
    }
    
    // Allow admin-ajax.php
    if (strpos($_SERVER['REQUEST_URI'], 'admin-ajax.php') !== false) {
        return;
    }
    
    // Check if user is logged in
    if (is_user_logged_in()) {
        $current_user = wp_get_current_user();
        
        // STRICT: Check user role directly - must be 'administrator'
        // Block if role is NOT 'administrator'
        if (!in_array('administrator', $current_user->roles)) {
            // Clear output buffers
            while (ob_get_level()) {
                ob_end_clean();
            }
            
            // Get user role and type
            $user_roles = $current_user->roles;
            $user_type = get_user_meta($current_user->ID, 'user_type', true);
            
            // Redirect to frontend dashboard - NO EXCEPTIONS
            if (in_array('partner', $user_roles) || $user_type === 'partner') {
                wp_safe_redirect(home_url('/partner-dashboard'));
            } else {
                wp_safe_redirect(home_url('/customer-dashboard'));
            }
            exit;
        }
    }
}
// Run very early, before admin_init
add_action('admin_init', 'wheelfy_block_wp_admin_for_non_admins', 0);

/**
 * Block wp-admin access using template_redirect hook
 * This fires even earlier than admin_init to catch wp-admin access
 */
function wheelfy_block_wp_admin_template_redirect() {
    // Only check on admin pages
    if (!is_admin()) {
        return;
    }
    
    // Allow AJAX
    if (defined('DOING_AJAX') && DOING_AJAX) {
        return;
    }
    
    // Allow admin-ajax.php
    if (strpos($_SERVER['REQUEST_URI'], 'admin-ajax.php') !== false) {
        return;
    }
    
    // Check if user is logged in
    if (is_user_logged_in()) {
        $current_user = wp_get_current_user();
        
        // STRICT: Check user role directly - must be 'administrator'
        // Block if role is NOT 'administrator'
        if (!in_array('administrator', $current_user->roles)) {
            // Clear output buffers
            while (ob_get_level()) {
                ob_end_clean();
            }
            
            // Get user role and type
            $user_roles = $current_user->roles;
            $user_type = get_user_meta($current_user->ID, 'user_type', true);
            
            // Redirect to frontend dashboard - NO EXCEPTIONS
            if (in_array('partner', $user_roles) || $user_type === 'partner') {
                wp_safe_redirect(home_url('/partner-dashboard'));
            } else {
                wp_safe_redirect(home_url('/customer-dashboard'));
            }
            exit;
        }
    }
}
// Run on template_redirect which fires before admin_init
add_action('template_redirect', 'wheelfy_block_wp_admin_template_redirect', 1);

/**
 * Add Dashboard Menu Items to WordPress Admin
 * ONLY for administrators - Customers and Partners should NOT access wp-admin
 */
// Removed Customer Dashboard menu from admin sidebar
/*
function wheelfy_add_dashboard_admin_menus() {
    // ONLY add menu items for administrators
    // Customers and Partners should NEVER see wp-admin menu
    if (!current_user_can('administrator')) {
        return;
    }
    
    // Add menu for administrators (they can see both)
    add_menu_page(
        __('Customer Dashboard', 'wheelfy'),
        __('Customer Dashboard', 'wheelfy'),
        'manage_options',
        'wheelfy-customer-dashboard',
        'wheelfy_customer_dashboard_admin_page',
        'dashicons-dashboard',
        2
    );
    
    add_submenu_page(
        'wheelfy-customer-dashboard',
        __('Partner Dashboard', 'wheelfy'),
        __('Partner Dashboard', 'wheelfy'),
        'manage_options',
        'wheelfy-partner-dashboard',
        'wheelfy_partner_dashboard_admin_page'
    );
}
*/
// add_action('admin_menu', 'wheelfy_add_dashboard_admin_menus');

/**
 * Add Wheelfy Admin Dashboard Menu
 */
function wheelfy_add_admin_dashboard_menu() {
    // Only show to administrators
    if (!current_user_can('administrator')) {
        return;
    }
    
    // Main Dashboard
    add_menu_page(
        __('Admin Dashboard', 'wheelfy'),
        __('Admin Dashboard', 'wheelfy'),
        'manage_options',
        'wheelfy-dashboard',
        'wheelfy_admin_dashboard_page',
        'dashicons-admin-settings',
        3
    );
    
    // Overview (same as main dashboard)
    add_submenu_page(
        'wheelfy-dashboard',
        __('Overview', 'wheelfy'),
        __('Overview', 'wheelfy'),
        'manage_options',
        'wheelfy-dashboard',
        'wheelfy_admin_dashboard_page'
    );
    
    // User Management
    add_submenu_page(
        'wheelfy-dashboard',
        __('User Management', 'wheelfy'),
        __('Users', 'wheelfy'),
        'manage_options',
        'wheelfy-users',
        'wheelfy_admin_users_page'
    );
    
    // Request Management
    add_submenu_page(
        'wheelfy-dashboard',
        __('Request Management', 'wheelfy'),
        __('Request', 'wheelfy'),
        'manage_options',
        'wheelfy-request',
        'wheelfy_admin_request_page'
    );
    
    // Subscription Management
    add_submenu_page(
        'wheelfy-dashboard',
        __('Subscription Management', 'wheelfy'),
        __('Subscriptions', 'wheelfy'),
        'manage_options',
        'wheelfy-subscriptions',
        'wheelfy_admin_subscriptions_page'
    );
    
    // Payment Settings
    add_submenu_page(
        'wheelfy-dashboard',
        __('Payment Settings', 'wheelfy'),
        __('Payments', 'wheelfy'),
        'manage_options',
        'wheelfy-payments',
        'wheelfy_admin_payments_page'
    );
    
    // Lead & Offer Management - REMOVED
    // add_submenu_page(
    //     'wheelfy-dashboard',
    //     __('Lead & Offer Management', 'wheelfy'),
    //     __('Leads & Offers', 'wheelfy'),
    //     'manage_options',
    //     'wheelfy-leads',
    //     'wheelfy_admin_leads_page'
    // );
    
    // Review & Rating Control
    add_submenu_page(
        'wheelfy-dashboard',
        __('Review & Rating Control', 'wheelfy'),
        __('Reviews', 'wheelfy'),
        'manage_options',
        'wheelfy-reviews',
        'wheelfy_admin_reviews_page'
    );
    
    // Chat Moderation - REMOVED
    // add_submenu_page(
    //     'wheelfy-dashboard',
    //     __('Chat Moderation', 'wheelfy'),
    //     __('Chat', 'wheelfy'),
    //     'manage_options',
    //     'wheelfy-chat',
    //     'wheelfy_admin_chat_page'
    // );
    
    // Reports & Export
    add_submenu_page(
        'wheelfy-dashboard',
        __('Reports & Export', 'wheelfy'),
        __('Reports', 'wheelfy'),
        'manage_options',
        'wheelfy-reports',
        'wheelfy_admin_reports_page'
    );
}
add_action('admin_menu', 'wheelfy_add_admin_dashboard_menu');

/**
 * Enqueue Admin Dashboard Styles
 */
function wheelfy_enqueue_admin_dashboard_styles($hook) {
    // Only load on our admin pages
    if (strpos($hook, 'wheelfy-') === false) {
        return;
    }
    
    wp_enqueue_style(
        'wheelfy-admin-dashboard',
        get_template_directory_uri() . '/admin/admin-dashboard.css',
        array(),
        '1.0.0'
    );
}
add_action('admin_enqueue_scripts', 'wheelfy_enqueue_admin_dashboard_styles');

/**
 * Enqueue Custom Admin Styles for CMB2 Meta Boxes - Gray Background
 */
function wheelfy_enqueue_cmb2_admin_styles($hook) {
    // Only load on post/page edit screens
    if (!in_array($hook, array('post.php', 'post-new.php', 'page.php', 'page-new.php'))) {
        return;
    }
    
    // Add inline CSS for white-gray background with highlighted text
    $custom_css = "
    /* CMB2 Tabs Container */
    .cmb2-tabs-wrapper {
        margin: 20px 0;
        background: #fff;
        border: 1px solid #c3c4c7;
        box-shadow: 0 1px 1px rgba(0,0,0,.04);
    }
    
    .cmb2-tabs-nav {
        display: flex;
        flex-wrap: wrap;
        background: #f6f7f7;
        border-bottom: 2px solid #D9E38D;
        margin: 0;
        padding: 0;
        list-style: none;
    }
    
    .cmb2-tabs-nav li {
        margin: 0;
        padding: 0;
    }
    
    .cmb2-tabs-nav a {
        display: block;
        padding: 12px 20px;
        color: #646970;
        text-decoration: none;
        font-weight: 600;
        font-size: 13px;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        border-bottom: 3px solid transparent;
        transition: all 0.3s ease;
        cursor: pointer;
    }
    
    .cmb2-tabs-nav a:hover {
        color: #1f2937;
        background: rgba(217, 227, 141, 0.1);
    }
    
    .cmb2-tabs-nav a.active {
        color: #1f2937;
        background: #fff;
        border-bottom-color: #D9E38D;
    }
    
    .cmb2-tabs-content {
        padding: 20px;
    }
    
    .cmb2-tab-pane {
        display: none;
    }
    
    .cmb2-tab-pane.active {
        display: block;
    }
    
    /* Hide default postbox headers when in tabs */
    .cmb2-tabs-wrapper .postbox .postbox-header {
        display: none !important;
    }
    
    .cmb2-tabs-wrapper .postbox {
        border: none;
        box-shadow: none;
        background: transparent;
    }
    
    .cmb2-tabs-wrapper .postbox .inside {
        margin: 0;
        padding: 0;
    }
    
    /* CMB2 Postbox Header - White Gray Background with Highlighted Text */
    .postbox:not(.cmb2-tabs-wrapper .postbox) .postbox-header {
        background: #f3f4f6 !important;
        border-bottom: 2px solid #e5e7eb !important;
        border-left: 4px solid #D9E38D !important;
    }
    
    .postbox:not(.cmb2-tabs-wrapper .postbox) .postbox-header .hndle {
        color: #1f2937 !important;
        font-weight: 700 !important;
        font-size: 15px !important;
        text-transform: uppercase !important;
        letter-spacing: 0.5px !important;
    }
    
    .postbox:not(.cmb2-tabs-wrapper .postbox) .postbox-header .handle-actions button {
        color: #6b7280 !important;
    }
    
    .postbox:not(.cmb2-tabs-wrapper .postbox) .postbox-header .handle-actions button:hover {
        color: #1f2937 !important;
        background: rgba(0, 0, 0, 0.05) !important;
    }
    
    /* Custom Icon Dropdown Styling */
    .custom-icon-select-wrapper {
        position: relative;
        display: inline-block;
        min-width: 250px;
    }
    
    .custom-icon-select-wrapper select[id*='step_icon'] {
        display: none !important;
    }
    
    .custom-icon-select {
        position: relative;
        display: block;
        width: 100%;
        padding: 8px 32px 8px 40px;
        font-size: 14px;
        line-height: 1.5;
        color: #2c3338;
        background-color: #fff;
        border: 1px solid #8c8f94;
        border-radius: 4px;
        cursor: pointer;
        user-select: none;
        min-height: 30px;
        display: flex;
        align-items: center;
        gap: 10px;
    }
    
    .custom-icon-select:hover {
        border-color: #2271b1;
    }
    
    .custom-icon-select:focus {
        border-color: #2271b1;
        box-shadow: 0 0 0 1px #2271b1;
        outline: none;
    }
    
    .custom-icon-select .selected-icon {
        width: 18px;
        height: 18px;
        flex-shrink: 0;
        color: #50575e;
    }
    
    .custom-icon-select .selected-text {
        flex: 1;
    }
    
    .custom-icon-select .dropdown-arrow {
        position: absolute;
        right: 8px;
        top: 50%;
        transform: translateY(-50%);
        width: 0;
        height: 0;
        border-left: 5px solid transparent;
        border-right: 5px solid transparent;
        border-top: 5px solid #50575e;
        pointer-events: none;
    }
    
    .custom-icon-dropdown {
        position: absolute;
        top: 100%;
        left: 0;
        right: 0;
        margin-top: 4px;
        background: #fff;
        border: 1px solid #8c8f94;
        border-radius: 4px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
        z-index: 1000;
        max-height: 300px;
        overflow-y: auto;
        display: none;
    }
    
    .custom-icon-dropdown.open {
        display: block;
    }
    
    .custom-icon-option {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 10px 12px;
        cursor: pointer;
        transition: background-color 0.15s;
    }
    
    .custom-icon-option:hover {
        background-color: #f0f0f1;
    }
    
    .custom-icon-option.selected {
        background-color: #2271b1;
        color: #fff;
    }
    
    .custom-icon-option.selected .option-icon {
        color: #fff;
    }
    
    .custom-icon-option .option-icon {
        width: 18px;
        height: 18px;
        flex-shrink: 0;
        color: #50575e;
    }
    
    .custom-icon-option .option-text {
        flex: 1;
    }
    ";
    
    wp_add_inline_style('wp-admin', $custom_css);
    
    // Add JavaScript to create custom dropdown with icons
    $custom_js = "
    (function($) {
        'use strict';
        
        // Icon SVG paths mapping
        var iconSvgs = {
            'user-plus': '<path stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2\" d=\"M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z\" />',
            'car': '<path stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2\" d=\"M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.4 2.9A3.7 3.7 0 0 0 2 12v4c0 .6.4 1 1 1h2\" /><circle cx=\"7\" cy=\"17\" r=\"2\" /><path stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2\" d=\"M9 17h6\" /><circle cx=\"17\" cy=\"17\" r=\"2\" />',
            'calendar': '<path stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2\" d=\"M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z\" />',
            'send': '<path stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2\" d=\"M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z\" /><path stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2\" d=\"m21.854 2.147-10.94 10.939\" />',
            'bell': '<path stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2\" d=\"M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9\" />',
            'check-circle': '<path stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2\" d=\"M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z\" />',
            'file-text': '<path stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2\" d=\"M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z\" />',
            'message-square': '<path stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2\" d=\"M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z\" />',
            'credit-card': '<path stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2\" d=\"M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z\" />',
            'shield': '<path stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2\" d=\"M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z\" />',
            'star': '<path stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2\" d=\"M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z\" />',
            'clock': '<path stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2\" d=\"M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z\" />',
            'dollar-sign': '<path stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2\" d=\"M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z\" />',
            'wrench': '<path stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2\" d=\"M10.325 4.317c.426-1.756 2.924-1.756 3.25 0a6.73 6.73 0 011.566 4.461c0 1.561-.424 3.145-1.899 4.153L12 14.5l-2.242-1.469a4.73 4.73 0 01-1.899-4.153 6.73 6.73 0 011.566-4.461zM15 10a4.5 4.5 0 11-9 0 4.5 4.5 0 019 0z\" />',
            'search': '<path stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2\" d=\"M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z\" />',
            'heart': '<path stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2\" d=\"M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z\" />'
        };
        
        function createCustomIconDropdown(selectEl) {
            // Skip if already processed
            if (selectEl.data('custom-dropdown')) {
                return;
            }
            
            // Mark as processed
            selectEl.data('custom-dropdown', true);
            
            // Get current value and options
            var currentValue = selectEl.val() || '';
            var options = selectEl.find('option');
            
            // Wrap select in container
            if (!selectEl.parent().hasClass('custom-icon-select-wrapper')) {
                selectEl.wrap('<div class=\"custom-icon-select-wrapper\"></div>');
            }
            
            // Create custom select button
            var getSelectedText = function() {
                var selectedOption = selectEl.find('option:selected');
                return selectedOption.length ? selectedOption.text() : 'Select an icon';
            };
            
            var getSelectedIcon = function(value) {
                if (!value || !iconSvgs[value]) return '';
                return '<svg width=\"18\" height=\"18\" fill=\"none\" stroke=\"currentColor\" viewBox=\"0 0 24 24\">' + iconSvgs[value] + '</svg>';
            };
            
            var customSelect = jQuery('<div class=\"custom-icon-select\"><span class=\"selected-icon\">' + getSelectedIcon(currentValue) + '</span><span class=\"selected-text\">' + getSelectedText() + '</span><span class=\"dropdown-arrow\"></span></div>');
            
            // Create dropdown menu
            var dropdown = jQuery('<div class=\"custom-icon-dropdown\"></div>');
            
            options.each(function() {
                var option = jQuery(this);
                var value = option.val();
                var text = option.text();
                var iconHtml = getSelectedIcon(value);
                var isSelected = value === currentValue;
                
                var customOption = jQuery('<div class=\"custom-icon-option' + (isSelected ? ' selected' : '') + '\" data-value=\"' + value + '\"><span class=\"option-icon\">' + iconHtml + '</span><span class=\"option-text\">' + text + '</span></div>');
                
                customOption.on('click', function(e) {
                    e.stopPropagation();
                    var newValue = jQuery(this).data('value');
                    selectEl.val(newValue).trigger('change');
                    customSelect.find('.selected-icon').html(getSelectedIcon(newValue));
                    customSelect.find('.selected-text').text(text);
                    dropdown.find('.custom-icon-option').removeClass('selected');
                    jQuery(this).addClass('selected');
                    dropdown.removeClass('open');
                });
                
                dropdown.append(customOption);
            });
            
            // Toggle dropdown
            customSelect.on('click', function(e) {
                e.stopPropagation();
                dropdown.toggleClass('open');
            });
            
            // Close dropdown when clicking outside
            jQuery(document).on('click', function(e) {
                if (!jQuery(e.target).closest('.custom-icon-select-wrapper').length) {
                    dropdown.removeClass('open');
                }
            });
            
            // Insert custom elements
            selectEl.after(customSelect);
            customSelect.after(dropdown);
            
            // Update custom select when native select changes
            selectEl.on('change', function() {
                var newValue = jQuery(this).val();
                var selectedOption = selectEl.find('option:selected');
                customSelect.find('.selected-icon').html(getSelectedIcon(newValue));
                customSelect.find('.selected-text').text(selectedOption.length ? selectedOption.text() : 'Select an icon');
                dropdown.find('.custom-icon-option').removeClass('selected');
                dropdown.find('.custom-icon-option[data-value=\"' + newValue + '\"]').addClass('selected');
            });
        }
        
        function initCustomIconDropdowns() {
            jQuery('select[id*=\"step_icon\"]').each(function() {
                createCustomIconDropdown(jQuery(this));
            });
        }
        
        // Run on page load
        jQuery(document).ready(function() {
            initCustomIconDropdowns();
        });
        
        // Run when CMB2 adds new repeatable groups
        jQuery(document).on('cmb2_add_row', function() {
            setTimeout(initCustomIconDropdowns, 100);
        });
        
        // Also run on DOM mutations (for dynamically added selects)
        var observer = new MutationObserver(function(mutations) {
            initCustomIconDropdowns();
        });
        
        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    })(jQuery);
    ";
    
    // Ensure jQuery is loaded
    wp_enqueue_script('jquery');
    wp_add_inline_script('jquery', $custom_js);
    
    // Add JavaScript for CMB2 Tabs
    $cmb2_tabs_js = "
    (function(jQuery) {
        'use strict';
        
        function initCMB2Tabs() {
            // Check if already initialized
            if (jQuery('.cmb2-tabs-wrapper').length > 0) {
                return;
            }
            
            // Check page template - only apply to home page template
            var pageTemplate = jQuery('#page_template');
            if (pageTemplate.length) {
                var template = pageTemplate.val();
                if (template !== 'page-home.php') {
                    return;
                }
            } else {
                // If template selector not found, check URL
                if (window.location.href.indexOf('page-home.php') === -1 && 
                    window.location.href.indexOf('page_template=page-home') === -1) {
                    return;
                }
            }
            
            // Find all CMB2 meta boxes for home page sections
            var sectionBoxes = jQuery('.postbox').filter(function() {
                var id = jQuery(this).attr('id') || '';
                return id.indexOf('wheelfy_') === 0 && 
                       (id.indexOf('hero') !== -1 || 
                        id.indexOf('features') !== -1 || 
                        id.indexOf('benefits') !== -1 || 
                        id.indexOf('how_it_works') !== -1 || 
                        id.indexOf('services') !== -1 || 
                        id.indexOf('testimonials') !== -1 || 
                        id.indexOf('cta_section') !== -1);
            });
            
            if (sectionBoxes.length === 0) {
                return;
            }
            
            // Create tabs wrapper
            var tabsWrapper = jQuery('<div class=\"cmb2-tabs-wrapper\"></div>');
            var tabsNav = jQuery('<ul class=\"cmb2-tabs-nav\"></ul>');
            var tabsContent = jQuery('<div class=\"cmb2-tabs-content\"></div>');
            
            // Section titles mapping
            var sectionTitles = {
                'hero': 'Hero Section',
                'features': 'Features Section',
                'benefits': 'Benefits Section',
                'how_it_works': 'How It Works',
                'services': 'Services Section',
                'testimonials': 'Testimonials Section',
                'cta_section': 'CTA Section'
            };
            
            // Collect boxes and create tabs
            var boxesData = [];
            sectionBoxes.each(function() {
                var box = jQuery(this);
                var boxId = box.attr('id') || '';
                var sectionKey = '';
                
                // Determine section key from box ID
                for (var key in sectionTitles) {
                    if (boxId.indexOf(key) !== -1) {
                        sectionKey = key;
                        break;
                    }
                }
                
                if (sectionKey) {
                    boxesData.push({
                        box: box,
                        sectionKey: sectionKey,
                        tabTitle: sectionTitles[sectionKey],
                        tabId: 'tab-' + sectionKey
                    });
                }
            });
            
            // Sort boxes by order
            var order = ['hero', 'features', 'benefits', 'how_it_works', 'services', 'testimonials', 'cta_section'];
            boxesData.sort(function(a, b) {
                var indexA = order.indexOf(a.sectionKey);
                var indexB = order.indexOf(b.sectionKey);
                return indexA - indexB;
            });
            
            // Create tabs and move boxes
            boxesData.forEach(function(item, index) {
                // Create tab link
                var tabLink = jQuery('<li><a href=\"#\" data-tab=\"' + item.tabId + '\" class=\"' + (index === 0 ? 'active' : '') + '\">' + item.tabTitle + '</a></li>');
                tabsNav.append(tabLink);
                
                // Create tab pane
                var tabPane = jQuery('<div class=\"cmb2-tab-pane\" id=\"' + item.tabId + '\" ' + (index === 0 ? 'style=\"display: block;\"' : '') + '></div>');
                
                // Move box into tab pane
                item.box.appendTo(tabPane);
                tabsContent.append(tabPane);
            });
            
            // Insert tabs before first section box
            if (boxesData.length > 0) {
                boxesData[0].box.before(tabsWrapper);
                tabsWrapper.append(tabsNav);
                tabsWrapper.append(tabsContent);
            }
            
            // Tab click handler
            tabsNav.on('click', 'a', function(e) {
                e.preventDefault();
                var tabId = jQuery(this).data('tab');
                
                // Update active states
                tabsNav.find('a').removeClass('active');
                jQuery(this).addClass('active');
                
                tabsContent.find('.cmb2-tab-pane').removeClass('active').hide();
                tabsContent.find('#' + tabId).addClass('active').show();
            });
        }
        
        // Initialize on page load
        jQuery(document).ready(function() {
            // Wait a bit for CMB2 to initialize
            setTimeout(initCMB2Tabs, 500);
        });
        
        // Re-initialize when CMB2 adds new fields or page template changes
        jQuery(document).on('cmb2_init', function() {
            setTimeout(initCMB2Tabs, 100);
        });
        
        // Watch for page template changes
        jQuery(document).on('change', '#page_template', function() {
            setTimeout(initCMB2Tabs, 100);
        });
    })(jQuery);
    ";
    
    wp_add_inline_script('jquery', $cmb2_tabs_js);
}
add_action('admin_enqueue_scripts', 'wheelfy_enqueue_cmb2_admin_styles');

/**
 * Admin Dashboard Page
 */
function wheelfy_admin_dashboard_page() {
    require_once get_template_directory() . '/admin/admin-dashboard.php';
}

/**
 * Load Admin Functions (for AJAX handlers)
 */
function wheelfy_load_admin_functions() {
    require_once get_template_directory() . '/admin/admin-functions.php';
}
// Load admin functions early so AJAX handlers are available
add_action('init', 'wheelfy_load_admin_functions', 1);

/**
 * Admin Users Page
 */
function wheelfy_admin_users_page() {
    require_once get_template_directory() . '/admin/admin-users.php';
}

/**
 * Admin Request Page
 */
function wheelfy_admin_request_page() {
    require_once get_template_directory() . '/admin/admin-request.php';
}

/**
 * Admin Payment Settings Page
 */
function wheelfy_admin_payments_page() {
    require_once get_template_directory() . '/admin/admin-payments.php';
}

/**
 * Admin Subscriptions Page
 */
function wheelfy_admin_subscriptions_page() {
    require_once get_template_directory() . '/admin/admin-subscriptions.php';
}

/**
 * Admin Leads Page
 */
function wheelfy_admin_leads_page() {
    require_once get_template_directory() . '/admin/admin-leads.php';
}

/**
 * Admin Reviews Page
 */
function wheelfy_admin_reviews_page() {
    // Load reviews functions
    require_once get_template_directory() . '/admin/admin-reviews-functions.php';
    require_once get_template_directory() . '/admin/admin-reviews.php';
}

// Load reviews functions on init so AJAX handlers are registered
function wheelfy_load_reviews_functions() {
    require_once get_template_directory() . '/admin/admin-reviews-functions.php';
}
add_action('init', 'wheelfy_load_reviews_functions', 1);

/**
 * Admin Chat Page
 */
function wheelfy_admin_chat_page() {
    require_once get_template_directory() . '/admin/admin-chat.php';
}

/**
 * Admin Reports Page
 */
function wheelfy_admin_reports_page() {
    // Load reports functions (functions are loaded on init for AJAX handlers)
    require_once get_template_directory() . '/admin/admin-reports.php';
}

// Load reports functions on init so AJAX handlers are registered
function wheelfy_load_reports_functions() {
    require_once get_template_directory() . '/admin/admin-reports-functions.php';
}
add_action('init', 'wheelfy_load_reports_functions', 1);

/**
 * Admin Activities Page
 */
function wheelfy_admin_activities_page() {
    require_once get_template_directory() . '/admin/admin-activities.php';
}

/**
 * Customer Dashboard Admin Page (redirects to frontend dashboard)
 */
function wheelfy_customer_dashboard_admin_page() {
    // Redirect to frontend dashboard
    wp_redirect(home_url('/customer-dashboard'));
    exit;
}

/**
 * Partner Dashboard Admin Page (redirects to frontend dashboard)
 */
function wheelfy_partner_dashboard_admin_page() {
    // Redirect to frontend dashboard
    wp_redirect(home_url('/partner-dashboard'));
    exit;
}

/**
 * Add Dashboard Link to Admin Bar (Works on both frontend and backend)
 */
function wheelfy_add_dashboard_admin_bar_link($wp_admin_bar) {
    if (!is_user_logged_in()) {
        return;
    }
    
    $current_user = wp_get_current_user();
    $user_type = get_user_meta($current_user->ID, 'user_type', true);
    
    // Determine dashboard URL based on user type
    if ($user_type === 'partner') {
        $dashboard_url = home_url('/partner-dashboard');
        $dashboard_title = __('Partner Dashboard', 'wheelfy');
    } else {
        $dashboard_url = home_url('/customer-dashboard');
        $dashboard_title = __('My Dashboard', 'wheelfy');
    }
    
    // Add main dashboard link
    $wp_admin_bar->add_node(array(
        'id'    => 'wheelfy-dashboard',
        'title' => $dashboard_title,
        'href'  => $dashboard_url,
        'meta'  => array(
            'class' => 'wheelfy-dashboard-link',
        ),
    ));
    
    // Add submenu items
    $wp_admin_bar->add_node(array(
        'parent' => 'wheelfy-dashboard',
        'id'     => 'wheelfy-dashboard-view',
        'title'  => __('View Dashboard', 'wheelfy'),
        'href'   => $dashboard_url,
    ));
    
    // If user can access admin, add admin dashboard link
    if (current_user_can('administrator')) {
        $wp_admin_bar->add_node(array(
            'parent' => 'wheelfy-dashboard',
            'id'     => 'wheelfy-dashboard-admin',
            'title'  => __('WP Admin Dashboard', 'wheelfy'),
            'href'   => admin_url(),
        ));
    }
}
add_action('admin_bar_menu', 'wheelfy_add_dashboard_admin_bar_link', 100);

/**
 * Hide WordPress Admin Bar for Non-Admin Users on Frontend
 */
function wheelfy_hide_admin_bar_for_non_admins() {
    // Only hide on frontend, not in admin area
    if (!is_admin()) {
        // Hide admin bar for users who are not administrators
        if (!current_user_can('administrator')) {
            add_filter('show_admin_bar', '__return_false');
        }
    }
}
add_action('init', 'wheelfy_hide_admin_bar_for_non_admins', 9);

/**
 * Custom Post Types and Taxonomies
 */
// Post types removed: Services and Partners
// function wheelfy_register_post_types() {
//     // Register Services Post Type
//     register_post_type('service', array(
//         'labels' => array(
//             'name' => __('Services', 'wheelfy'),
//             'singular_name' => __('Service', 'wheelfy'),
//             'add_new' => __('Add Service', 'wheelfy'),
//             'add_new_item' => __('Add New Service', 'wheelfy'),
//             'edit_item' => __('Edit Service', 'wheelfy'),
//             'new_item' => __('New Service', 'wheelfy'),
//             'view_item' => __('View Service', 'wheelfy'),
//             'view_items' => __('View Services', 'wheelfy'),
//             'search_items' => __('Search Services', 'wheelfy'),
//             'not_found' => __('No services found', 'wheelfy'),
//             'not_found_in_trash' => __('No services found in Trash', 'wheelfy'),
//             'all_items' => __('All Services', 'wheelfy'),
//             'archives' => __('Service Archives', 'wheelfy'),
//             'attributes' => __('Service Attributes', 'wheelfy'),
//             'insert_into_item' => __('Insert into service', 'wheelfy'),
//             'uploaded_to_this_item' => __('Uploaded to this service', 'wheelfy'),
//             'featured_image' => __('Service Featured Image', 'wheelfy'),
//             'set_featured_image' => __('Set featured image', 'wheelfy'),
//             'remove_featured_image' => __('Remove featured image', 'wheelfy'),
//             'use_featured_image' => __('Use as featured image', 'wheelfy'),
//             'menu_name' => __('Services', 'wheelfy'),
//         ),
//         'public' => true,
//         'has_archive' => true,
//         'supports' => array('title', 'editor', 'thumbnail', 'excerpt'),
//         'menu_icon' => 'dashicons-car',
//     ));

//     // Register Partners Post Type
//     register_post_type('partner', array(
//         'labels' => array(
//             'name' => __('Partners', 'wheelfy'),
//             'singular_name' => __('Partner', 'wheelfy'),
//         ),
//         'public' => true,
//         'has_archive' => true,
//         'supports' => array('title', 'editor', 'thumbnail', 'excerpt'),
//         'menu_icon' => 'dashicons-groups',
//     ));
// }
// add_action('init', 'wheelfy_register_post_types');

/**
 * Register custom query vars
 */
// Removed service query var - Services post type removed
// function wheelfy_register_query_vars($vars) {
//     $vars[] = 'service';
//     return $vars;
// }
// add_filter('query_vars', 'wheelfy_register_query_vars');

/**
 * Change admin page title for Services post type
 */
// Removed - Services post type removed
// add_filter('admin_title', 'wheelfy_change_service_admin_title', 10, 2);
// function wheelfy_change_service_admin_title($admin_title, $title) {
//     global $pagenow, $post_type;
//     
//     // Only on edit post screen for service post type
//     if ($pagenow === 'post.php' && isset($_GET['post']) && get_post_type($_GET['post']) === 'service') {
//         return str_replace('Edit Post', 'Edit Service', $admin_title);
//     }
//     
//     // On new post screen for service post type
//     if ($pagenow === 'post-new.php' && isset($_GET['post_type']) && $_GET['post_type'] === 'service') {
//         return str_replace('Add New Post', 'Add New Service', $admin_title);
//     }
//     
//     return $admin_title;
// }

/**
 * Change admin page heading for Services post type
 */
// Removed - Services post type removed
// add_action('admin_head', 'wheelfy_change_service_admin_heading');
// function wheelfy_change_service_admin_heading() {
//     global $pagenow, $post_type;
//     
//     if ($pagenow === 'post.php' && isset($_GET['post'])) {
//         $post = get_post($_GET['post']);
//         if ($post && $post->post_type === 'service') {
//             echo '<script>
//             jQuery(document).ready(function($) {
//                 // Change page heading
//                 var heading = $(".wp-heading-inline");
//                 if (heading.length && heading.text().indexOf("Edit Post") !== -1) {
//                     heading.text(heading.text().replace("Edit Post", "Edit Service"));
//                 }
//                 
//                 // Change button text
//                 var addButton = $("a.page-title-action");
//                 if (addButton.length && addButton.text().indexOf("Add Post") !== -1) {
//                     addButton.text(addButton.text().replace("Add Post", "Add Service"));
//                 }
//             });
//             </script>';
//         }
//     }
//     
//     if ($pagenow === 'post-new.php' && isset($_GET['post_type']) && $_GET['post_type'] === 'service') {
//         echo '<script>
//         jQuery(document).ready(function($) {
//             // Change page heading
//             var heading = $(".wp-heading-inline");
//             if (heading.length && heading.text().indexOf("Add New Post") !== -1) {
//                 heading.text(heading.text().replace("Add New Post", "Add New Service"));
//             }
//         });
//         </script>';
//     }
// }

/**
 * Helper function to get template part
 */
function wheelfy_get_template_part($template_name, $args = array()) {
    extract($args);
    include locate_template("template-parts/{$template_name}.php");
}

/**
 * Add body classes
 */
function wheelfy_body_classes($classes) {
    if (is_front_page()) {
        $classes[] = 'home-page';
    }
    return $classes;
}
add_filter('body_class', 'wheelfy_body_classes');

/**
 * Ensure post_parent is always set to prevent warnings
 */
function wheelfy_ensure_post_parent($post) {
    if (is_object($post) && !isset($post->post_parent)) {
        $post->post_parent = 0;
    }
    return $post;
}
add_filter('the_post', 'wheelfy_ensure_post_parent');
add_filter('get_post', 'wheelfy_ensure_post_parent');

/**
 * Helper function to check if current page matches slug
 */
function wheelfy_is_current_page($slug) {
    if (is_page($slug)) {
        return true;
    }
    
    $pagename = get_query_var('pagename');
    if ($pagename === $slug) {
        return true;
    }
    
    global $wp_query;
    if (isset($wp_query->queried_object) && isset($wp_query->queried_object->post_name)) {
        if ($wp_query->queried_object->post_name === $slug) {
            return true;
        }
    }
    
    // Check by URL
    $current_url = $_SERVER['REQUEST_URI'];
    if (strpos($current_url, '/' . $slug) !== false) {
        return true;
    }
    
    return false;
}

/**
 * Add rewrite rules for custom pages
 */
function wheelfy_add_rewrite_rules() {
    $pages = array('how-it-works', 'car-maintenance', 'car-sales', 'partners', 'pricing', 'login', 'register', 'dashboard', 'request-proposal', 'sell-your-car');
    
    foreach ($pages as $page) {
        add_rewrite_rule('^' . $page . '/?$', 'index.php?pagename=' . $page, 'top');
    }
    
    // Partner profile page rewrite rule
    add_rewrite_rule('^partner/([0-9]+)/?$', 'index.php?pagename=partner-profile&partner_id=$matches[1]', 'top');
}
add_action('init', 'wheelfy_add_rewrite_rules');

/**
 * Register custom query variables for partner profile
 */
function wheelfy_register_query_vars($vars) {
    $vars[] = 'partner_id';
    return $vars;
}
add_filter('query_vars', 'wheelfy_register_query_vars');

/**
 * Get partner profile URL
 * 
 * @param int $partner_id Partner user ID
 * @return string Partner profile URL
 */
function wheelfy_get_partner_profile_url($partner_id) {
    return home_url('/partner/' . intval($partner_id) . '/');
}

/**
 * Filter to ensure get_post_ancestors returns array for virtual pages
 */
function wheelfy_filter_post_ancestors($ancestors, $post_id) {
    global $wp_query;
    
    // If this is a virtual page (ID = 0) created by our template redirect
    if ($post_id == 0 && isset($wp_query->queried_object) && $wp_query->queried_object->ID == 0) {
        return array();
    }
    
    // Ensure we always return an array, not null
    return is_array($ancestors) ? $ancestors : array();
}
add_filter('get_post_ancestors', 'wheelfy_filter_post_ancestors', 10, 2);

/**
 * Template redirect for custom page templates (fallback)
 * Only use this if pages don't exist - pages should be auto-created
 */
function wheelfy_template_redirect() {
    // CRITICAL: Always ensure dashboard pages exist before handling requests
    wheelfy_ensure_dashboard_pages_exist();
    
    // First, try to create pages if they don't exist
    if (!get_option('wheelfy_pages_created')) {
        wheelfy_create_pages();
        update_option('wheelfy_pages_created', true);
        flush_rewrite_rules();
        // Redirect to let WordPress handle it properly
        wp_redirect($_SERVER['REQUEST_URI']);
        exit;
    }
    
    // Only handle 404s for our custom pages
    if (!is_404()) {
        return;
    }
    
    $request_uri = trim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), '/');
    $home_path = trim(parse_url(home_url(), PHP_URL_PATH), '/');
    
    if ($home_path) {
        $request_uri = str_replace('/' . $home_path, '', '/' . $request_uri);
        $request_uri = trim($request_uri, '/');
    }
    
    $template_map = array(
        'how-it-works' => 'page-how-it-works.php',
        'car-maintenance' => 'page-car-maintenance.php',
        'car-sales' => 'page-car-sales.php',
        'partners' => 'page-partners.php',
        'pricing' => 'page-pricing.php',
        'login' => 'page-login.php',
        'register' => 'page-register.php',
        'dashboard' => 'page-dashboard-customer.php',
        'customer-dashboard' => 'page-dashboard-customer.php',
        'partner-dashboard' => 'page-dashboard-partner.php',
        'request-proposal' => 'page-request-proposal.php',
        'sell-your-car' => 'page-sell-your-car.php',
        'select-partner' => 'page-select-partner.php',
        'partner-quotation' => 'page-partner-quotation.php',
    );
    
    // Check if request matches any of our pages
    foreach ($template_map as $slug => $template) {
        if ($request_uri === $slug || strpos($request_uri, $slug . '/') === 0) {
            $template_file = locate_template($template);
            if ($template_file) {
                // Create a proper post object for WordPress with all required properties
                global $wp_query, $post;
                
                $page_title = ucwords(str_replace('-', ' ', $slug));
                
                // Try to get existing page first
                $existing_page = get_page_by_path($slug);
                
                if ($existing_page) {
                    // Use existing page - get full post object
                    $post_obj = get_post($existing_page->ID);
                } else {
                    // Create a complete post object with all required properties
                    $post_obj = new stdClass();
                    $post_obj->ID = 0;
                    $post_obj->post_author = 1;
                    $post_obj->post_date = current_time('mysql');
                    $post_obj->post_date_gmt = current_time('mysql', 1);
                    $post_obj->post_content = '';
                    $post_obj->post_title = $page_title;
                    $post_obj->post_excerpt = '';
                    $post_obj->post_status = 'publish';
                    $post_obj->comment_status = 'closed';
                    $post_obj->ping_status = 'closed';
                    $post_obj->post_password = '';
                    $post_obj->post_name = $slug;
                    $post_obj->to_ping = '';
                    $post_obj->pinged = '';
                    $post_obj->post_modified = current_time('mysql');
                    $post_obj->post_modified_gmt = current_time('mysql', 1);
                    $post_obj->post_content_filtered = '';
                    $post_obj->post_parent = 0; // Required property - must be set
                    $post_obj->guid = home_url('/' . $slug . '/');
                    $post_obj->menu_order = 0;
                    $post_obj->post_type = 'page';
                    $post_obj->post_mime_type = '';
                    $post_obj->comment_count = 0;
                    $post_obj->filter = 'raw';
                    
                    // Ensure post_parent exists before any WordPress functions access it
                    if (!isset($post_obj->post_parent)) {
                        $post_obj->post_parent = 0;
                    }
                }
                
                // Set up query - ensure all properties are set first
                $wp_query->is_page = true;
                $wp_query->is_singular = true;
                $wp_query->is_404 = false;
                $wp_query->is_home = false;
                $wp_query->is_front_page = false;
                
                // Ensure queried_object has post_parent
                if (!isset($post_obj->post_parent)) {
                    $post_obj->post_parent = 0;
                }
                
                // Set ancestors property to empty array to prevent menu system errors
                // WordPress menu system expects this to be an array, not null
                if (!isset($post_obj->ancestors)) {
                    $post_obj->ancestors = array();
                }
                
                $wp_query->queried_object = $post_obj;
                $wp_query->queried_object_id = isset($post_obj->ID) ? $post_obj->ID : 0;
                $wp_query->post = $post_obj;
                $wp_query->posts = array($post_obj);
                $wp_query->post_count = 1;
                $wp_query->found_posts = 1;
                $wp_query->max_num_pages = 1;
                
                // Set global post and ensure post_parent and ancestors are set
                $post = $post_obj;
                if (!isset($post->post_parent)) {
                    $post->post_parent = 0;
                }
                if (!isset($post->ancestors)) {
                    $post->ancestors = array();
                }
                
                setup_postdata($post);
                
                include($template_file);
                exit;
            }
        }
    }
}
add_action('template_redirect', 'wheelfy_template_redirect', 1);

/**
 * Add custom classes to navigation menu items
 */
function wheelfy_nav_menu_css_class($classes, $item, $args) {
    if (isset($args->theme_location) && $args->theme_location === 'primary') {
        // Don't add button classes to submenu items
        if (!in_array('menu-item-has-children', $classes) && !$item->menu_item_parent) {
            // Only top-level items get button classes
        }
        
        // Add active class
        if (in_array('current-menu-item', $classes) || in_array('current-page-item', $classes)) {
            $classes[] = 'active';
        }
        
        // Add dropdown class if has children
        if (in_array('menu-item-has-children', $classes)) {
            $classes[] = 'dropdown';
        }
    }
    return $classes;
}
add_filter('nav_menu_css_class', 'wheelfy_nav_menu_css_class', 10, 3);

/**
 * Add custom classes to navigation menu links
 */
function wheelfy_nav_menu_link_attributes($atts, $item, $args) {
    if (isset($args->theme_location) && $args->theme_location === 'primary') {
        // Don't add button classes to submenu items
        if (!$item->menu_item_parent && !in_array('menu-item-has-children', $item->classes)) {
            $atts['class'] = 'button button-nav';
        } elseif ($item->menu_item_parent) {
            // Submenu items
            $atts['class'] = 'flex items-center gap-2 px-4 py-2 hover:bg-secondary transition-colors';
        } else {
            // Parent items with children (dropdowns)
            $atts['class'] = 'button button-nav flex items-center gap-1';
        }
        
        // Add active class
        if (in_array('current-menu-item', $item->classes) || in_array('current-page-item', $item->classes)) {
            $atts['class'] .= ' bg-primary/10 text-primary';
        }
    }
    return $atts;
}
add_filter('nav_menu_link_attributes', 'wheelfy_nav_menu_link_attributes', 10, 3);

/**
 * Custom Walker for Navigation Menu with Dropdowns
 */
class Wheelfy_Walker_Nav_Menu extends Walker_Nav_Menu {
    
    // Start Level - For submenu UL
    function start_lvl(&$output, $depth = 0, $args = null) {
        $indent = str_repeat("\t", $depth);
        
        if ($depth === 0) {
            // Desktop dropdown
            $output .= "\n$indent<div class=\"dropdown-content hidden absolute top-full left-0 mt-1 w-48 bg-card border border-border rounded-lg shadow-lg z-50\" data-dropdown>\n";
        } else {
            // Nested submenu
            $output .= "\n$indent<ul class=\"sub-menu\">\n";
        }
    }
    
    // End Level - Close submenu UL
    function end_lvl(&$output, $depth = 0, $args = null) {
        $indent = str_repeat("\t", $depth);
        
        if ($depth === 0) {
            $output .= "$indent</div>\n";
        } else {
            $output .= "$indent</ul>\n";
        }
    }
    
    // Start Element - For LI and A tags
    function start_el(&$output, $item, $depth = 0, $args = null, $id = 0) {
        $indent = ($depth) ? str_repeat("\t", $depth) : '';
        
        $classes = empty($item->classes) ? array() : (array) $item->classes;
        $classes[] = 'menu-item-' . $item->ID;
        
        $class_names = join(' ', apply_filters('nav_menu_css_class', array_filter($classes), $item, $args));
        $class_names = $class_names ? ' class="' . esc_attr($class_names) . '"' : '';
        
        $id = apply_filters('nav_menu_item_id', 'menu-item-'. $item->ID, $item, $args);
        $id = $id ? ' id="' . esc_attr($id) . '"' : '';
        
        $has_children = in_array('menu-item-has-children', $classes);
        $is_active = in_array('current-menu-item', $classes) || in_array('current-page-item', $classes);
        
        if ($depth === 0) {
            // Top-level items
            $style = 'list-style: none; margin: 0; padding: 0;' . ($has_children ? ' position: relative;' : '');
            $output .= $indent . '<li' . $id . $class_names . ' style="' . $style . '">';
            
            if ($has_children) {
                // Dropdown parent
                $button_class = 'button button-nav flex items-center gap-1';
                if ($is_active) {
                    $button_class .= ' bg-primary/10 text-primary';
                }
                $output .= '<button class="' . esc_attr($button_class) . '" data-dropdown-toggle="' . $item->ID . '">';
                $output .= apply_filters('the_title', $item->title, $item->ID);
                $output .= '<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                </svg>';
                $output .= '</button>';
            } else {
                // Regular link
                $attributes = ! empty($item->attr_title) ? ' title="'  . esc_attr($item->attr_title) .'"' : '';
                $attributes .= ! empty($item->target)     ? ' target="' . esc_attr($item->target) .'"' : '';
                $attributes .= ! empty($item->xfn)        ? ' rel="'    . esc_attr($item->xfn) .'"' : '';
                $attributes .= ! empty($item->url)        ? ' href="'   . esc_attr($item->url) .'"' : '';
                
                $link_class = 'button button-nav';
                if ($is_active) {
                    $link_class .= ' bg-primary/10 text-primary';
                }
                $attributes .= ' class="' . esc_attr($link_class) . '"';
                
                $item_output = isset($args->before) ? $args->before : '';
                $item_output .= '<a' . $attributes . '>';
                $item_output .= (isset($args->link_before) ? $args->link_before : '') . apply_filters('the_title', $item->title, $item->ID) . (isset($args->link_after) ? $args->link_after : '');
                $item_output .= '</a>';
                $item_output .= isset($args->after) ? $args->after : '';
                
                $output .= apply_filters('walker_nav_menu_start_el', $item_output, $item, $depth, $args);
            }
        } else {
            // Submenu items - these are wrapped in <a> tags directly inside the dropdown div
            $attributes = ! empty($item->attr_title) ? ' title="'  . esc_attr($item->attr_title) .'"' : '';
            $attributes .= ! empty($item->target)     ? ' target="' . esc_attr($item->target) .'"' : '';
            $attributes .= ! empty($item->xfn)        ? ' rel="'    . esc_attr($item->xfn) .'"' : '';
            $attributes .= ! empty($item->url)        ? ' href="'   . esc_attr($item->url) .'"' : '';
            
            $link_class = 'flex items-center gap-2 px-4 py-2 hover:bg-secondary transition-colors';
            if ($is_active) {
                $link_class .= ' bg-primary/10 text-primary';
            }
            
            $output .= $indent . '<a' . $attributes . ' class="' . esc_attr($link_class) . '">';
            $output .= apply_filters('the_title', $item->title, $item->ID);
            $output .= '</a>';
        }
    }
    
    // End Element - Close LI
    function end_el(&$output, $item, $depth = 0, $args = null) {
        if ($depth === 0) {
            $output .= "</li>\n";
        }
    }
}

/**
 * Custom Walker for Mobile Navigation Menu
 */
class Wheelfy_Walker_Nav_Menu_Mobile extends Walker_Nav_Menu {
    
    // Start Level - For submenu UL
    function start_lvl(&$output, $depth = 0, $args = null) {
        // Mobile doesn't need special wrapper for submenu
        $output .= "\n";
    }
    
    // End Level - Close submenu UL
    function end_lvl(&$output, $depth = 0, $args = null) {
        $output .= "\n";
    }
    
    // Start Element - For LI and A tags
    function start_el(&$output, $item, $depth = 0, $args = null, $id = 0) {
        $classes = empty($item->classes) ? array() : (array) $item->classes;
        $classes[] = 'menu-item-' . $item->ID;
        
        $class_names = join(' ', apply_filters('nav_menu_css_class', array_filter($classes), $item, $args));
        $class_names = $class_names ? ' class="' . esc_attr($class_names) . '"' : '';
        
        $has_children = in_array('menu-item-has-children', $classes);
        $is_active = in_array('current-menu-item', $classes) || in_array('current-page-item', $classes);
        
        if ($depth === 0 && $has_children) {
            // Parent item with children
            $output .= '<li' . $class_names . '>';
            $output .= '<p class="px-4 py-2 text-sm text-muted-foreground">' . apply_filters('the_title', $item->title, $item->ID) . '</p>';
        } else {
            // Regular item
            $attributes = ! empty($item->attr_title) ? ' title="'  . esc_attr($item->attr_title) .'"' : '';
            $attributes .= ! empty($item->target)     ? ' target="' . esc_attr($item->target) .'"' : '';
            $attributes .= ! empty($item->xfn)        ? ' rel="'    . esc_attr($item->xfn) .'"' : '';
            $attributes .= ! empty($item->url)        ? ' href="'   . esc_attr($item->url) .'"' : '';
            
            $link_class = $depth > 0 ? 'flex items-center gap-2 px-6 py-2 rounded-lg transition-colors' : 'block px-4 py-2 rounded-lg transition-colors';
            
            if ($is_active) {
                $link_class .= ' bg-primary/10 text-primary';
            } else {
                $link_class .= ' text-foreground hover:bg-secondary';
            }
            
            $output .= '<li' . $class_names . '>';
            $output .= '<a' . $attributes . ' class="' . esc_attr($link_class) . '">';
            $output .= apply_filters('the_title', $item->title, $item->ID);
            $output .= '</a>';
        }
    }
    
    // End Element - Close LI
    function end_el(&$output, $item, $depth = 0, $args = null) {
        $output .= "</li>\n";
    }
}

/**
 * Custom Walker for Header Navigation Menu
 */
class Wheelfy_Walker_Header_Menu extends Walker_Nav_Menu {
    
    // Start Level - For submenu UL
    function start_lvl(&$output, $depth = 0, $args = null) {
        $indent = str_repeat("\t", $depth);
        if ($depth === 0) {
            // Desktop dropdown - Professional styling (left-aligned with menu item)
            $output .= "\n$indent<div class=\"dropdown-content hidden absolute top-full left-0 mt-2 w-56 bg-card border border-border rounded-xl shadow-xl z-50\" data-dropdown>\n";
        } else {
            // Nested submenu
            $output .= "\n$indent<ul class=\"sub-menu\">\n";
        }
    }
    
    // End Level - Close submenu UL
    function end_lvl(&$output, $depth = 0, $args = null) {
        $indent = str_repeat("\t", $depth);
        if ($depth === 0) {
            $output .= "$indent</div>\n";
        } else {
            $output .= "$indent</ul>\n";
        }
    }
    
    // Start Element - For LI and A tags
    function start_el(&$output, $item, $depth = 0, $args = null, $id = 0) {
        $indent = ($depth) ? str_repeat("\t", $depth) : '';
        
        $classes = empty($item->classes) ? array() : (array) $item->classes;
        $classes[] = 'menu-item-' . $item->ID;
        
        $class_names = join(' ', apply_filters('nav_menu_css_class', array_filter($classes), $item, $args));
        $class_names = $class_names ? ' class="' . esc_attr($class_names) . '"' : '';
        
        $id = apply_filters('nav_menu_item_id', 'menu-item-'. $item->ID, $item, $args);
        $id = $id ? ' id="' . esc_attr($id) . '"' : '';
        
        $has_children = in_array('menu-item-has-children', $classes);
        $is_active = in_array('current-menu-item', $classes) || in_array('current-page-item', $classes) || in_array('current-menu-ancestor', $classes);
        
        // Get menu font size from header options
        $menu_font_size = wheelfy_get_header_option('header_menu_font_size', '15');
        $active_class = $is_active ? 'bg-primary/10 text-primary' : '';
        
        if ($depth === 0) {
            // Top-level items
            $li_style = $has_children ? ' position: relative;' : '';
            $output .= $indent . '<li' . $id . $class_names . ($li_style ? ' style="' . esc_attr($li_style) . '"' : '') . '>';
            
            $attributes = ! empty($item->attr_title) ? ' title="'  . esc_attr($item->attr_title) .'"' : '';
            $attributes .= ! empty($item->target)     ? ' target="' . esc_attr($item->target) .'"' : '';
            $attributes .= ! empty($item->xfn)        ? ' rel="'    . esc_attr($item->xfn) .'"' : '';
            $attributes .= ! empty($item->url)        ? ' href="'   . esc_attr($item->url) .'"' : '';
            
            if ($has_children) {
                // Dropdown parent - use button with dropdown toggle and arrow icon
                $output .= '<a' . $attributes . ' class="button button-nav dropdown-toggle ' . esc_attr($active_class) . '" style="font-size: ' . esc_attr($menu_font_size) . 'px;" data-dropdown-toggle="dropdown-' . $item->ID . '">';
                $output .= '<span class="menu-item-text">' . apply_filters('the_title', $item->title, $item->ID) . '</span>';
                $output .= '<svg class="dropdown-arrow" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>';
                $output .= '</a>';
            } else {
                // Regular menu item
                $output .= '<a' . $attributes . ' class="button button-nav ' . esc_attr($active_class) . '" style="font-size: ' . esc_attr($menu_font_size) . 'px;">';
                $output .= apply_filters('the_title', $item->title, $item->ID);
                $output .= '</a>';
            }
        } else {
            // Submenu items
            $attributes = ! empty($item->attr_title) ? ' title="'  . esc_attr($item->attr_title) .'"' : '';
            $attributes .= ! empty($item->target)     ? ' target="' . esc_attr($item->target) .'"' : '';
            $attributes .= ! empty($item->xfn)        ? ' rel="'    . esc_attr($item->xfn) .'"' : '';
            $attributes .= ! empty($item->url)        ? ' href="'   . esc_attr($item->url) .'"' : '';
            
            $submenu_active = in_array('current-menu-item', $classes) || in_array('current-page-item', $classes);
            $submenu_active_class = $submenu_active ? 'bg-primary/10 text-primary' : '';
            
            $output .= $indent . '<a' . $attributes . ' class="dropdown-item flex items-center gap-3 px-4 py-3 text-sm font-medium hover:bg-primary/10 hover:text-primary transition-all duration-200 ' . esc_attr($submenu_active_class) . '">';
            $output .= '<span class="flex-1">' . apply_filters('the_title', $item->title, $item->ID) . '</span>';
            $output .= '</a>';
        }
    }
    
    // End Element - Close LI
    function end_el(&$output, $item, $depth = 0, $args = null) {
        if ($depth === 0) {
            $output .= "</li>\n";
        }
    }
}

/**
 * Fallback menu if no menu is assigned (Desktop)
 */
function wheelfy_fallback_menu_desktop() {
    // Get menu font size from header options
    $menu_font_size = wheelfy_get_header_option('header_menu_font_size', '15');
    
    // Get current language for translations
    $current_lang = isset($_GET['lang']) ? sanitize_text_field($_GET['lang']) : (isset($_COOKIE['wheelfy_lang']) ? sanitize_text_field($_COOKIE['wheelfy_lang']) : 'en');
    
    $menu_translations = array(
        'en' => array(
            'home' => 'Home',
            'how_it_works' => 'How It Works',
            'car_maintenance' => 'Car Maintenance',
            'car_sales' => 'Car Sales',
            'partners' => 'Partners',
            'pricing' => 'Pricing',
        ),
        'hu' => array(
            'home' => 'Otthon',
            'how_it_works' => 'Hogyan működik',
            'car_maintenance' => 'Autókarbantartás',
            'car_sales' => 'Autóeladások',
            'partners' => 'Partnerek',
            'pricing' => 'Árazás',
        ),
        'de' => array(
            'home' => 'Startseite',
            'how_it_works' => 'Wie es funktioniert',
            'car_maintenance' => 'Autowartung',
            'car_sales' => 'Autoverkauf',
            'partners' => 'Partner',
            'pricing' => 'Preise',
        ),
    );
    
    $menu_texts = isset($menu_translations[$current_lang]) ? $menu_translations[$current_lang] : $menu_translations['en'];
    
    $menu_items = array(
        array('name' => $menu_texts['home'], 'url' => home_url('/'), 'slug' => 'home'),
        array('name' => $menu_texts['how_it_works'], 'url' => home_url('/how-it-works'), 'slug' => 'how-it-works'),
        array('name' => $menu_texts['car_maintenance'], 'url' => home_url('/car-maintenance'), 'slug' => 'car-maintenance'),
        array('name' => $menu_texts['car_sales'], 'url' => home_url('/car-sales'), 'slug' => 'car-sales'),
        array('name' => $menu_texts['partners'], 'url' => home_url('/partners'), 'slug' => 'partners'),
        array('name' => $menu_texts['pricing'], 'url' => home_url('/pricing'), 'slug' => 'pricing'),
    );

    echo '<ul class="flex items-center justify-center" style="display: flex !important; list-style: none; margin: 0; padding: 0; justify-content: center !important;">';
    foreach ($menu_items as $item) {
        $current = '';
        if ($item['slug'] === 'home' && (is_home() || is_front_page())) {
            $current = 'bg-primary/10 text-primary';
        } elseif (is_page($item['slug'])) {
            $current = 'bg-primary/10 text-primary';
        }
        echo '<li class="menu-item"><a href="' . esc_url($item['url']) . '" class="button button-nav ' . esc_attr($current) . '" style="font-size: ' . esc_attr($menu_font_size) . 'px;">' . esc_html($item['name']) . '</a></li>';
    }
    echo '</ul>';
}

/**
 * Fallback menu if no menu is assigned (Mobile)
 */
function wheelfy_fallback_menu_mobile() {
    // Get current language for translations
    $current_lang = isset($_GET['lang']) ? sanitize_text_field($_GET['lang']) : (isset($_COOKIE['wheelfy_lang']) ? sanitize_text_field($_COOKIE['wheelfy_lang']) : 'en');
    
    $menu_translations = array(
        'en' => array(
            'home' => 'Home',
            'how_it_works' => 'How It Works',
            'car_maintenance' => 'Car Maintenance',
            'car_sales' => 'Car Sales',
            'partners' => 'Partners',
            'pricing' => 'Pricing',
        ),
        'hu' => array(
            'home' => 'Otthon',
            'how_it_works' => 'Hogyan működik',
            'car_maintenance' => 'Autókarbantartás',
            'car_sales' => 'Autóeladások',
            'partners' => 'Partnerek',
            'pricing' => 'Árazás',
        ),
        'de' => array(
            'home' => 'Startseite',
            'how_it_works' => 'Wie es funktioniert',
            'car_maintenance' => 'Autowartung',
            'car_sales' => 'Autoverkauf',
            'partners' => 'Partner',
            'pricing' => 'Preise',
        ),
    );
    
    $menu_texts = isset($menu_translations[$current_lang]) ? $menu_translations[$current_lang] : $menu_translations['en'];
    
    $menu_items = array(
        array('name' => $menu_texts['home'], 'url' => home_url('/'), 'slug' => 'home'),
        array('name' => $menu_texts['how_it_works'], 'url' => home_url('/how-it-works'), 'slug' => 'how-it-works'),
        array('name' => $menu_texts['car_maintenance'], 'url' => home_url('/car-maintenance'), 'slug' => 'car-maintenance'),
        array('name' => $menu_texts['car_sales'], 'url' => home_url('/car-sales'), 'slug' => 'car-sales'),
        array('name' => $menu_texts['partners'], 'url' => home_url('/partners'), 'slug' => 'partners'),
        array('name' => $menu_texts['pricing'], 'url' => home_url('/pricing'), 'slug' => 'pricing'),
    );

    echo '<ul class="space-y-1 mobile-menu-list">';
    foreach ($menu_items as $item) {
        $current = '';
        if ($item['slug'] === 'home' && (is_home() || is_front_page())) {
            $current = 'current-menu-item';
        } elseif (is_page($item['slug'])) {
            $current = 'current-menu-item';
        }
        echo '<li class="menu-item ' . esc_attr($current) . '"><a href="' . esc_url($item['url']) . '" class="block px-4 py-2 rounded-lg transition-colors text-white hover:bg-white/10">' . esc_html($item['name']) . '</a></li>';
    }
    echo '</ul>';
}

/**
 * Theme Options Page
 * Add theme options menu to WordPress admin dashboard as top-level menu with submenus
 */
function wheelfy_add_theme_options_page() {
    // Main menu page
    add_menu_page(
        __('Theme Settings', 'wheelfy'),                // Page title
        __('Theme Settings', 'wheelfy'),                // Menu title
        'manage_options',                               // Capability
        'wheelfy-theme-options',                       // Menu slug
        'wheelfy_header_options_page',                 // Callback function (Header as default)
        'dashicons-admin-generic',                      // Icon (gear icon)
        30                                              // Position (after Posts)
    );
    
    // Submenu: General Settings - REMOVED
    
    // Submenu: Header Settings
    // Make sure this is registered AFTER the parent menu
    $header_page = add_submenu_page(
        'wheelfy-theme-options',  // Parent slug - must match the main menu slug
        __('Header Settings', 'wheelfy'),
        __('Header', 'wheelfy'),
        'manage_options',
        'wheelfy-header-options',  // Unique menu slug
        'wheelfy_header_options_page'
    );
    
    // Submenu: Footer Settings
    add_submenu_page(
        'wheelfy-theme-options',
        __('Footer Settings', 'wheelfy'),
        __('Footer', 'wheelfy'),
        'manage_options',
        'wheelfy-footer-options',
        'wheelfy_footer_options_page'
    );
    
    // Submenu: Contact & Social
    add_submenu_page(
        'wheelfy-theme-options',
        __('Contact & Social', 'wheelfy'),
        __('Contact & Social', 'wheelfy'),
        'manage_options',
        'wheelfy-contact-options',
        'wheelfy_contact_options_page'
    );
    
    // Submenu: Colors & Branding
    add_submenu_page(
        'wheelfy-theme-options',
        __('Colors & Branding', 'wheelfy'),
        __('Colors & Branding', 'wheelfy'),
        'manage_options',
        'wheelfy-colors-options',
        'wheelfy_colors_options_page'
    );
    
    // Submenu: Business Information
    add_submenu_page(
        'wheelfy-theme-options',
        __('Business Information', 'wheelfy'),
        __('Business Info', 'wheelfy'),
        'manage_options',
        'wheelfy-business-options',
        'wheelfy_business_options_page'
    );
}
add_action('admin_menu', 'wheelfy_add_theme_options_page', 9); // Priority 9 to run before CMB2

/**
 * Remove any duplicate menu items that CMB2 might create
 * and ensure Header Settings appears under Theme Settings
 */
function wheelfy_fix_header_menu_placement() {
    global $submenu;
    
    // Remove Header, Footer, and Contact & Social Settings from Settings menu if they exist there
    if (isset($submenu['options-general.php'])) {
        foreach ($submenu['options-general.php'] as $key => $item) {
            if (isset($item[2]) && ($item[2] === 'wheelfy-header-options' || $item[2] === 'wheelfy-footer-options' || $item[2] === 'wheelfy-contact-options')) {
                unset($submenu['options-general.php'][$key]);
            }
        }
    }
    
    // Ensure Header, Footer, and Contact & Social Settings are under Theme Settings
    if (isset($submenu['wheelfy-theme-options'])) {
        $header_found = false;
        $footer_found = false;
        $contact_found = false;
        
        foreach ($submenu['wheelfy-theme-options'] as $item) {
            if (isset($item[2])) {
                if ($item[2] === 'wheelfy-header-options') {
                    $header_found = true;
                }
                if ($item[2] === 'wheelfy-footer-options') {
                    $footer_found = true;
                }
                if ($item[2] === 'wheelfy-contact-options') {
                    $contact_found = true;
                }
            }
        }
        
        // If Header Settings not found, add it
        if (!$header_found) {
            add_submenu_page(
                'wheelfy-theme-options',
                __('Header Settings', 'wheelfy'),
                __('Header', 'wheelfy'),
                'manage_options',
                'wheelfy-header-options',
                'wheelfy_header_options_page'
            );
        }
        
        // If Footer Settings not found, add it
        if (!$footer_found) {
            add_submenu_page(
                'wheelfy-theme-options',
                __('Footer Settings', 'wheelfy'),
                __('Footer', 'wheelfy'),
                'manage_options',
                'wheelfy-footer-options',
                'wheelfy_footer_options_page'
            );
        }
        
        // If Contact & Social Settings not found, add it
        if (!$contact_found) {
            add_submenu_page(
                'wheelfy-theme-options',
                __('Contact & Social', 'wheelfy'),
                __('Contact & Social', 'wheelfy'),
                'manage_options',
                'wheelfy-contact-options',
                'wheelfy_contact_options_page'
            );
        }
    }
    
    // Also check and remove from any other menus CMB2 might have created
    if (isset($submenu)) {
        foreach ($submenu as $parent => $items) {
            if ($parent !== 'wheelfy-theme-options' && $parent !== 'options-general.php') {
                foreach ($items as $key => $item) {
                    if (isset($item[2]) && ($item[2] === 'wheelfy-header-options' || $item[2] === 'wheelfy-footer-options' || $item[2] === 'wheelfy-contact-options')) {
                        unset($submenu[$parent][$key]);
                    }
                }
            }
        }
    }
}
add_action('admin_menu', 'wheelfy_fix_header_menu_placement', 999);
// Also run on admin_init to catch any late menu additions from CMB2 or other plugins
add_action('admin_init', 'wheelfy_fix_header_menu_placement', 999);
// Run again with even higher priority to ensure it's last
add_action('admin_menu', 'wheelfy_fix_header_menu_placement', 1001);

/**
 * Ensure Theme Settings menu structure is correct
 * This ensures General is the default page and Footer appears as a submenu
 */
add_action('admin_menu', 'wheelfy_fix_theme_settings_menu_structure', 1000);
function wheelfy_fix_theme_settings_menu_structure() {
    global $submenu;
    
    if (!isset($submenu['wheelfy-theme-options'])) {
        return;
    }
    
    // General submenu removed - Header is now the default
    $footer_key = null;
    $other_items = array();
    
    foreach ($submenu['wheelfy-theme-options'] as $key => $item) {
        if (isset($item[2])) {
            if ($item[2] === 'wheelfy-footer-options') {
                $footer_key = $key;
            } else {
                $other_items[$key] = $item;
            }
        }
    }
    
    // Rebuild submenu with other items first, then Footer last
    $new_submenu = array();
    
    // Add other items (Header, Contact, Colors, Business Info)
    foreach ($other_items as $item) {
        $new_submenu[] = $item;
    }
    
    // Add Footer last
    if ($footer_key !== null) {
        $new_submenu[] = $submenu['wheelfy-theme-options'][$footer_key];
    }
    
    // Replace the submenu array
    if (!empty($new_submenu)) {
        $submenu['wheelfy-theme-options'] = $new_submenu;
    }
}

/**
 * Remove menu separator after Theme Settings
 */
function wheelfy_remove_menu_separator() {
    global $menu;
    if (!is_array($menu)) {
        return;
    }
    
    // Remove all menu separators (WordPress adds them automatically)
    foreach ($menu as $key => $item) {
        if (isset($item[4]) && strpos($item[4], 'wp-menu-separator') !== false) {
            unset($menu[$key]);
        }
    }
}
add_action('admin_menu', 'wheelfy_remove_menu_separator', 999);

/**
 * Remove menu separator using CSS and JavaScript (more reliable)
 */
function wheelfy_hide_menu_separator() {
    ?>
    <style type="text/css">
        #adminmenu li.wp-menu-separator,
        #adminmenu li.wp-not-current-submenu.wp-menu-separator {
            display: none !important;
        }
    </style>
    <script type="text/javascript">
        jQuery(document).ready(function($) {
            // Remove separator elements
            $('#adminmenu li.wp-menu-separator, #adminmenu li.wp-not-current-submenu.wp-menu-separator').remove();
        });
    </script>
    <?php
}
add_action('admin_head', 'wheelfy_hide_menu_separator');

/**
 * Register Theme Options Settings
 */
function wheelfy_register_theme_options() {
    // Register settings (all use same option name)
    register_setting('wheelfy_theme_options', 'wheelfy_theme_options', 'wheelfy_sanitize_options');
    
    // ========== GENERAL SETTINGS PAGE ==========
    add_settings_section(
        'wheelfy_general_section',
        __('General Settings', 'wheelfy'),
        'wheelfy_general_section_callback',
        'wheelfy-theme-options'
    );
    
    // Contact Information Section
    add_settings_section(
        'wheelfy_contact_section',
        __('Contact Information', 'wheelfy'),
        'wheelfy_contact_section_callback',
        'wheelfy-theme-options'
    );
    
    // Social Media Section
    add_settings_section(
        'wheelfy_social_section',
        __('Social Media Links', 'wheelfy'),
        'wheelfy_social_section_callback',
        'wheelfy-theme-options'
    );
    
    // Brand Colors Section
    add_settings_section(
        'wheelfy_colors_section',
        __('Brand Colors', 'wheelfy'),
        'wheelfy_colors_section_callback',
        'wheelfy-theme-options'
    );
    
    // Header & Footer Section
    add_settings_section(
        'wheelfy_header_footer_section',
        __('Header & Footer', 'wheelfy'),
        'wheelfy_header_footer_section_callback',
        'wheelfy-theme-options'
    );
    
    // Business Information Section
    add_settings_section(
        'wheelfy_business_section',
        __('Business Information', 'wheelfy'),
        'wheelfy_business_section_callback',
        'wheelfy-theme-options'
    );
    
    // General Settings Fields
    add_settings_field(
        'company_name',
        __('Company Name', 'wheelfy'),
        'wheelfy_company_name_field',
        'wheelfy-theme-options',
        'wheelfy_general_section'
    );
    
    add_settings_field(
        'company_tagline',
        __('Company Tagline', 'wheelfy'),
        'wheelfy_company_tagline_field',
        'wheelfy-theme-options',
        'wheelfy_general_section'
    );
    
    add_settings_field(
        'default_language',
        __('Default Language', 'wheelfy'),
        'wheelfy_default_language_field',
        'wheelfy-theme-options',
        'wheelfy_general_section'
    );
    
    // Contact Information Fields
    add_settings_field(
        'contact_email',
        __('Contact Email', 'wheelfy'),
        'wheelfy_contact_email_field',
        'wheelfy-theme-options',
        'wheelfy_contact_section'
    );
    
    add_settings_field(
        'contact_phone',
        __('Contact Phone', 'wheelfy'),
        'wheelfy_contact_phone_field',
        'wheelfy-theme-options',
        'wheelfy_contact_section'
    );
    
    add_settings_field(
        'contact_address',
        __('Business Address', 'wheelfy'),
        'wheelfy_contact_address_field',
        'wheelfy-theme-options',
        'wheelfy_contact_section'
    );
    
    add_settings_field(
        'contact_city',
        __('City', 'wheelfy'),
        'wheelfy_contact_city_field',
        'wheelfy-theme-options',
        'wheelfy_contact_section'
    );
    
    add_settings_field(
        'contact_country',
        __('Country', 'wheelfy'),
        'wheelfy_contact_country_field',
        'wheelfy-theme-options',
        'wheelfy_contact_section'
    );
    
    // Social Media Fields
    add_settings_field(
        'social_facebook',
        __('Facebook URL', 'wheelfy'),
        'wheelfy_social_facebook_field',
        'wheelfy-theme-options',
        'wheelfy_social_section'
    );
    
    add_settings_field(
        'social_twitter',
        __('Twitter/X URL', 'wheelfy'),
        'wheelfy_social_twitter_field',
        'wheelfy-theme-options',
        'wheelfy_social_section'
    );
    
    add_settings_field(
        'social_instagram',
        __('Instagram URL', 'wheelfy'),
        'wheelfy_social_instagram_field',
        'wheelfy-theme-options',
        'wheelfy_social_section'
    );
    
    add_settings_field(
        'social_linkedin',
        __('LinkedIn URL', 'wheelfy'),
        'wheelfy_social_linkedin_field',
        'wheelfy-theme-options',
        'wheelfy_social_section'
    );
    
    add_settings_field(
        'social_youtube',
        __('YouTube URL', 'wheelfy'),
        'wheelfy_social_youtube_field',
        'wheelfy-theme-options',
        'wheelfy_social_section'
    );
    
    // Brand Colors Fields
    add_settings_field(
        'primary_color',
        __('Primary Color (Yellow)', 'wheelfy'),
        'wheelfy_primary_color_field',
        'wheelfy-theme-options',
        'wheelfy_colors_section'
    );
    
    add_settings_field(
        'secondary_color',
        __('Secondary Color (Teal)', 'wheelfy'),
        'wheelfy_secondary_color_field',
        'wheelfy-theme-options',
        'wheelfy_colors_section'
    );
    
    // Header & Footer Fields
    add_settings_field(
        'header_text',
        __('Header Additional Text', 'wheelfy'),
        'wheelfy_header_text_field',
        'wheelfy-theme-options',
        'wheelfy_header_footer_section'
    );
    
    add_settings_field(
        'footer_copyright',
        __('Footer Copyright Text', 'wheelfy'),
        'wheelfy_footer_copyright_field',
        'wheelfy-theme-options',
        'wheelfy_header_footer_section'
    );
    
    // Business Information Fields
    add_settings_field(
        'business_hours',
        __('Business Hours', 'wheelfy'),
        'wheelfy_business_hours_field',
        'wheelfy-theme-options',
        'wheelfy_business_section'
    );
    
    add_settings_field(
        'business_description',
        __('Business Description', 'wheelfy'),
        'wheelfy_business_description_field',
        'wheelfy-theme-options',
        'wheelfy_business_section'
    );
    
    add_settings_field(
        'google_maps_api_key',
        __('Google Maps API Key', 'wheelfy'),
        'wheelfy_google_maps_api_key_field',
        'wheelfy-theme-options',
        'wheelfy_business_section'
    );
    
    // ========== HEADER SETTINGS PAGE ==========
    add_settings_section(
        'wheelfy_header_section',
        __('Header Settings', 'wheelfy'),
        'wheelfy_header_section_callback',
        'wheelfy-header-options'
    );
    
    add_settings_field(
        'header_text',
        __('Header Additional Text', 'wheelfy'),
        'wheelfy_header_text_field',
        'wheelfy-header-options',
        'wheelfy_header_section'
    );
    
    // ========== FOOTER SETTINGS PAGE ==========
    add_settings_section(
        'wheelfy_footer_section',
        __('Footer Settings', 'wheelfy'),
        'wheelfy_footer_section_callback',
        'wheelfy-footer-options'
    );
    
    add_settings_field(
        'footer_copyright',
        __('Footer Copyright Text', 'wheelfy'),
        'wheelfy_footer_copyright_field',
        'wheelfy-footer-options',
        'wheelfy_footer_section'
    );
    
    // ========== CONTACT & SOCIAL PAGE ==========
    add_settings_section(
        'wheelfy_contact_section_page',
        __('Contact Information', 'wheelfy'),
        'wheelfy_contact_section_callback',
        'wheelfy-contact-options'
    );
    
    add_settings_field(
        'contact_email',
        __('Contact Email', 'wheelfy'),
        'wheelfy_contact_email_field',
        'wheelfy-contact-options',
        'wheelfy_contact_section_page'
    );
    
    add_settings_field(
        'contact_phone',
        __('Contact Phone', 'wheelfy'),
        'wheelfy_contact_phone_field',
        'wheelfy-contact-options',
        'wheelfy_contact_section_page'
    );
    
    add_settings_field(
        'contact_address',
        __('Business Address', 'wheelfy'),
        'wheelfy_contact_address_field',
        'wheelfy-contact-options',
        'wheelfy_contact_section_page'
    );
    
    add_settings_field(
        'contact_city',
        __('City', 'wheelfy'),
        'wheelfy_contact_city_field',
        'wheelfy-contact-options',
        'wheelfy_contact_section_page'
    );
    
    add_settings_field(
        'contact_country',
        __('Country', 'wheelfy'),
        'wheelfy_contact_country_field',
        'wheelfy-contact-options',
        'wheelfy_contact_section_page'
    );
    
    add_settings_section(
        'wheelfy_social_section_page',
        __('Social Media Links', 'wheelfy'),
        'wheelfy_social_section_callback',
        'wheelfy-contact-options'
    );
    
    add_settings_field(
        'social_facebook',
        __('Facebook URL', 'wheelfy'),
        'wheelfy_social_facebook_field',
        'wheelfy-contact-options',
        'wheelfy_social_section_page'
    );
    
    add_settings_field(
        'social_twitter',
        __('Twitter/X URL', 'wheelfy'),
        'wheelfy_social_twitter_field',
        'wheelfy-contact-options',
        'wheelfy_social_section_page'
    );
    
    add_settings_field(
        'social_instagram',
        __('Instagram URL', 'wheelfy'),
        'wheelfy_social_instagram_field',
        'wheelfy-contact-options',
        'wheelfy_social_section_page'
    );
    
    add_settings_field(
        'social_linkedin',
        __('LinkedIn URL', 'wheelfy'),
        'wheelfy_social_linkedin_field',
        'wheelfy-contact-options',
        'wheelfy_social_section_page'
    );
    
    add_settings_field(
        'social_youtube',
        __('YouTube URL', 'wheelfy'),
        'wheelfy_social_youtube_field',
        'wheelfy-contact-options',
        'wheelfy_social_section_page'
    );
    
    // ========== COLORS & BRANDING PAGE ==========
    add_settings_section(
        'wheelfy_colors_section_page',
        __('Brand Colors', 'wheelfy'),
        'wheelfy_colors_section_callback',
        'wheelfy-colors-options'
    );
    
    add_settings_field(
        'primary_color',
        __('Primary Color (Yellow)', 'wheelfy'),
        'wheelfy_primary_color_field',
        'wheelfy-colors-options',
        'wheelfy_colors_section_page'
    );
    
    add_settings_field(
        'secondary_color',
        __('Secondary Color (Teal)', 'wheelfy'),
        'wheelfy_secondary_color_field',
        'wheelfy-colors-options',
        'wheelfy_colors_section_page'
    );
    
    // ========== BUSINESS INFORMATION PAGE ==========
    add_settings_section(
        'wheelfy_business_section_page',
        __('Business Information', 'wheelfy'),
        'wheelfy_business_section_callback',
        'wheelfy-business-options'
    );
    
    add_settings_field(
        'business_hours',
        __('Business Hours', 'wheelfy'),
        'wheelfy_business_hours_field',
        'wheelfy-business-options',
        'wheelfy_business_section_page'
    );
    
    add_settings_field(
        'business_description',
        __('Business Description', 'wheelfy'),
        'wheelfy_business_description_field',
        'wheelfy-business-options',
        'wheelfy_business_section_page'
    );
    
    add_settings_field(
        'google_maps_api_key',
        __('Google Maps API Key', 'wheelfy'),
        'wheelfy_google_maps_api_key_field',
        'wheelfy-business-options',
        'wheelfy_business_section_page'
    );
}
add_action('admin_init', 'wheelfy_register_theme_options');

/**
 * Sanitize Theme Options
 */
function wheelfy_sanitize_options($input) {
    $sanitized = array();
    
    // General
    if (isset($input['company_name'])) {
        $sanitized['company_name'] = sanitize_text_field($input['company_name']);
    }
    if (isset($input['company_tagline'])) {
        $sanitized['company_tagline'] = sanitize_text_field($input['company_tagline']);
    }
    if (isset($input['default_language'])) {
        $sanitized['default_language'] = sanitize_text_field($input['default_language']);
    }
    
    // Contact
    if (isset($input['contact_email'])) {
        $sanitized['contact_email'] = sanitize_email($input['contact_email']);
    }
    if (isset($input['contact_phone'])) {
        $sanitized['contact_phone'] = sanitize_text_field($input['contact_phone']);
    }
    if (isset($input['contact_address'])) {
        $sanitized['contact_address'] = sanitize_text_field($input['contact_address']);
    }
    if (isset($input['contact_city'])) {
        $sanitized['contact_city'] = sanitize_text_field($input['contact_city']);
    }
    if (isset($input['contact_country'])) {
        $sanitized['contact_country'] = sanitize_text_field($input['contact_country']);
    }
    
    // Social Media
    if (isset($input['social_facebook'])) {
        $sanitized['social_facebook'] = esc_url_raw($input['social_facebook']);
    }
    if (isset($input['social_twitter'])) {
        $sanitized['social_twitter'] = esc_url_raw($input['social_twitter']);
    }
    if (isset($input['social_instagram'])) {
        $sanitized['social_instagram'] = esc_url_raw($input['social_instagram']);
    }
    if (isset($input['social_linkedin'])) {
        $sanitized['social_linkedin'] = esc_url_raw($input['social_linkedin']);
    }
    if (isset($input['social_youtube'])) {
        $sanitized['social_youtube'] = esc_url_raw($input['social_youtube']);
    }
    
    // Colors
    if (isset($input['primary_color'])) {
        $sanitized['primary_color'] = sanitize_hex_color($input['primary_color']);
    }
    if (isset($input['secondary_color'])) {
        $sanitized['secondary_color'] = sanitize_hex_color($input['secondary_color']);
    }
    
    // Header & Footer
    if (isset($input['header_text'])) {
        $sanitized['header_text'] = sanitize_text_field($input['header_text']);
    }
    if (isset($input['footer_copyright'])) {
        $sanitized['footer_copyright'] = wp_kses_post($input['footer_copyright']);
    }
    
    // Business
    if (isset($input['business_hours'])) {
        $sanitized['business_hours'] = wp_kses_post($input['business_hours']);
    }
    if (isset($input['business_description'])) {
        $sanitized['business_description'] = wp_kses_post($input['business_description']);
    }
    if (isset($input['google_maps_api_key'])) {
        $sanitized['google_maps_api_key'] = sanitize_text_field($input['google_maps_api_key']);
    }
    
    return $sanitized;
}

/**
 * Section Callbacks
 */
function wheelfy_general_section_callback() {
    echo '<p>' . __('Configure general theme settings.', 'wheelfy') . '</p>';
}

function wheelfy_contact_section_callback() {
    echo '<p>' . __('Enter your business contact information.', 'wheelfy') . '</p>';
}

function wheelfy_social_section_callback() {
    echo '<p>' . __('Add your social media profile URLs.', 'wheelfy') . '</p>';
}

function wheelfy_colors_section_callback() {
    echo '<p>' . __('Customize your brand colors.', 'wheelfy') . '</p>';
}

function wheelfy_header_footer_section_callback() {
    echo '<p>' . __('Configure header and footer settings.', 'wheelfy') . '</p>';
}

function wheelfy_business_section_callback() {
    echo '<p>' . __('Add additional business information.', 'wheelfy') . '</p>';
}

// Additional section callbacks for new pages
function wheelfy_header_section_callback() {
    echo '<p>' . __('Configure header settings and display options.', 'wheelfy') . '</p>';
}

function wheelfy_footer_section_callback() {
    echo '<p>' . __('Configure footer settings and content.', 'wheelfy') . '</p>';
}

/**
 * Field Callbacks - General
 */
function wheelfy_company_name_field() {
    $options = get_option('wheelfy_theme_options');
    $value = isset($options['company_name']) ? $options['company_name'] : '';
    echo '<input type="text" name="wheelfy_theme_options[company_name]" value="' . esc_attr($value) . '" class="regular-text" placeholder="' . esc_attr(get_bloginfo('name')) . '">';
    echo '<p class="description">' . __('Your company or business name.', 'wheelfy') . '</p>';
}

function wheelfy_company_tagline_field() {
    $options = get_option('wheelfy_theme_options');
    $value = isset($options['company_tagline']) ? $options['company_tagline'] : '';
    echo '<input type="text" name="wheelfy_theme_options[company_tagline]" value="' . esc_attr($value) . '" class="regular-text" placeholder="' . esc_attr(get_bloginfo('description')) . '">';
    echo '<p class="description">' . __('A short tagline or description for your business.', 'wheelfy') . '</p>';
}

function wheelfy_default_language_field() {
    $options = get_option('wheelfy_theme_options');
    $value = isset($options['default_language']) ? $options['default_language'] : 'en';
    echo '<select name="wheelfy_theme_options[default_language]">';
    echo '<option value="en"' . selected($value, 'en', false) . '>English (EN)</option>';
    echo '<option value="hu"' . selected($value, 'hu', false) . '>Hungarian (HU)</option>';
    echo '<option value="de"' . selected($value, 'de', false) . '>German (DE)</option>';
    echo '</select>';
    echo '<p class="description">' . __('Default language for the website.', 'wheelfy') . '</p>';
}

/**
 * Field Callbacks - Contact
 */
function wheelfy_contact_email_field() {
    $options = get_option('wheelfy_theme_options');
    $value = isset($options['contact_email']) ? $options['contact_email'] : '';
    echo '<input type="email" name="wheelfy_theme_options[contact_email]" value="' . esc_attr($value) . '" class="regular-text" placeholder="info@wheelfy.com">';
    echo '<p class="description">' . __('Main contact email address.', 'wheelfy') . '</p>';
}

function wheelfy_contact_phone_field() {
    $options = get_option('wheelfy_theme_options');
    $value = isset($options['contact_phone']) ? $options['contact_phone'] : '';
    echo '<input type="text" name="wheelfy_theme_options[contact_phone]" value="' . esc_attr($value) . '" class="regular-text" placeholder="+36 30 123 4567">';
    echo '<p class="description">' . __('Contact phone number.', 'wheelfy') . '</p>';
}

function wheelfy_contact_address_field() {
    $options = get_option('wheelfy_theme_options');
    $value = isset($options['contact_address']) ? $options['contact_address'] : '';
    echo '<input type="text" name="wheelfy_theme_options[contact_address]" value="' . esc_attr($value) . '" class="regular-text" placeholder="Street Address">';
    echo '<p class="description">' . __('Street address.', 'wheelfy') . '</p>';
}

function wheelfy_contact_city_field() {
    $options = get_option('wheelfy_theme_options');
    $value = isset($options['contact_city']) ? $options['contact_city'] : '';
    echo '<input type="text" name="wheelfy_theme_options[contact_city]" value="' . esc_attr($value) . '" class="regular-text" placeholder="Budapest">';
    echo '<p class="description">' . __('City name.', 'wheelfy') . '</p>';
}

function wheelfy_contact_country_field() {
    $options = get_option('wheelfy_theme_options');
    $value = isset($options['contact_country']) ? $options['contact_country'] : '';
    echo '<input type="text" name="wheelfy_theme_options[contact_country]" value="' . esc_attr($value) . '" class="regular-text" placeholder="Hungary">';
    echo '<p class="description">' . __('Country name.', 'wheelfy') . '</p>';
}

/**
 * Field Callbacks - Social Media
 */
function wheelfy_social_facebook_field() {
    $options = get_option('wheelfy_theme_options');
    $value = isset($options['social_facebook']) ? $options['social_facebook'] : '';
    echo '<input type="url" name="wheelfy_theme_options[social_facebook]" value="' . esc_url($value) . '" class="regular-text" placeholder="https://facebook.com/yourpage">';
}

function wheelfy_social_twitter_field() {
    $options = get_option('wheelfy_theme_options');
    $value = isset($options['social_twitter']) ? $options['social_twitter'] : '';
    echo '<input type="url" name="wheelfy_theme_options[social_twitter]" value="' . esc_url($value) . '" class="regular-text" placeholder="https://twitter.com/yourhandle">';
}

function wheelfy_social_instagram_field() {
    $options = get_option('wheelfy_theme_options');
    $value = isset($options['social_instagram']) ? $options['social_instagram'] : '';
    echo '<input type="url" name="wheelfy_theme_options[social_instagram]" value="' . esc_url($value) . '" class="regular-text" placeholder="https://instagram.com/yourprofile">';
}

function wheelfy_social_linkedin_field() {
    $options = get_option('wheelfy_theme_options');
    $value = isset($options['social_linkedin']) ? $options['social_linkedin'] : '';
    echo '<input type="url" name="wheelfy_theme_options[social_linkedin]" value="' . esc_url($value) . '" class="regular-text" placeholder="https://linkedin.com/company/yourcompany">';
}

function wheelfy_social_youtube_field() {
    $options = get_option('wheelfy_theme_options');
    $value = isset($options['social_youtube']) ? $options['social_youtube'] : '';
    echo '<input type="url" name="wheelfy_theme_options[social_youtube]" value="' . esc_url($value) . '" class="regular-text" placeholder="https://youtube.com/yourchannel">';
}

/**
 * Field Callbacks - Colors
 */
function wheelfy_primary_color_field() {
    $options = get_option('wheelfy_theme_options');
    $value = isset($options['primary_color']) ? $options['primary_color'] : '#fdfd96';
    echo '<input type="text" name="wheelfy_theme_options[primary_color]" value="' . esc_attr($value) . '" class="wheelfy-color-picker" data-default-color="#fdfd96">';
    echo '<p class="description">' . __('Primary brand color (yellow).', 'wheelfy') . '</p>';
}

function wheelfy_secondary_color_field() {
    $options = get_option('wheelfy_theme_options');
    $value = isset($options['secondary_color']) ? $options['secondary_color'] : '#0a5159';
    echo '<input type="text" name="wheelfy_theme_options[secondary_color]" value="' . esc_attr($value) . '" class="wheelfy-color-picker" data-default-color="#0a5159">';
    echo '<p class="description">' . __('Secondary brand color (teal).', 'wheelfy') . '</p>';
}

/**
 * Field Callbacks - Header & Footer
 */
function wheelfy_header_text_field() {
    $options = get_option('wheelfy_theme_options');
    $value = isset($options['header_text']) ? $options['header_text'] : '';
    echo '<input type="text" name="wheelfy_theme_options[header_text]" value="' . esc_attr($value) . '" class="regular-text">';
    echo '<p class="description">' . __('Additional text to display in header (optional).', 'wheelfy') . '</p>';
}

function wheelfy_footer_copyright_field() {
    $options = get_option('wheelfy_theme_options');
    $value = isset($options['footer_copyright']) ? $options['footer_copyright'] : '&copy; ' . date('Y') . ' wheelfy &mdash; All rights reserved';
    echo '<textarea name="wheelfy_theme_options[footer_copyright]" rows="3" class="large-text">' . esc_textarea($value) . '</textarea>';
    echo '<p class="description">' . __('Copyright text displayed in footer. HTML allowed.', 'wheelfy') . '</p>';
}

/**
 * Field Callbacks - Business
 */
function wheelfy_business_hours_field() {
    $options = get_option('wheelfy_theme_options');
    $value = isset($options['business_hours']) ? $options['business_hours'] : '';
    echo '<textarea name="wheelfy_theme_options[business_hours]" rows="5" class="large-text" placeholder="Monday - Friday: 9:00 AM - 6:00 PM&#10;Saturday: 10:00 AM - 4:00 PM&#10;Sunday: Closed">' . esc_textarea($value) . '</textarea>';
    echo '<p class="description">' . __('Business operating hours. HTML allowed.', 'wheelfy') . '</p>';
}

function wheelfy_business_description_field() {
    $options = get_option('wheelfy_theme_options');
    $value = isset($options['business_description']) ? $options['business_description'] : '';
    wp_editor($value, 'wheelfy_business_description', array(
        'textarea_name' => 'wheelfy_theme_options[business_description]',
        'textarea_rows' => 10,
        'media_buttons' => false,
        'teeny' => true
    ));
    echo '<p class="description">' . __('Detailed business description.', 'wheelfy') . '</p>';
}

function wheelfy_google_maps_api_key_field() {
    $options = get_option('wheelfy_theme_options');
    $value = isset($options['google_maps_api_key']) ? $options['google_maps_api_key'] : '';
    echo '<input type="text" name="wheelfy_theme_options[google_maps_api_key]" value="' . esc_attr($value) . '" class="regular-text">';
    echo '<p class="description">' . __('Google Maps API key for map functionality (optional).', 'wheelfy') . '</p>';
}

/**
 * General Options Page HTML
 */
function wheelfy_general_options_page() {
    if (!current_user_can('manage_options')) {
        wp_die(__('You do not have sufficient permissions to access this page.', 'wheelfy'));
    }
    
    if (isset($_GET['settings-updated'])) {
        add_settings_error('wheelfy_messages', 'wheelfy_message', __('Settings Saved', 'wheelfy'), 'updated');
    }
    
    settings_errors('wheelfy_messages');
    ?>
    <div class="wrap">
        <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
        
        <form action="options.php" method="post">
            <?php
            settings_fields('wheelfy_theme_options');
            do_settings_sections('wheelfy-theme-options');
            submit_button(__('Save Settings', 'wheelfy'));
            ?>
        </form>
    </div>
    <?php
}

/**
 * Header Options Page HTML
 */
function wheelfy_header_options_page() {
    if (!current_user_can('manage_options')) {
        wp_die(__('You do not have sufficient permissions to access this page.', 'wheelfy'));
    }
    
    // Get the CMB2 options page instance
    $cmb = cmb2_get_metabox('wheelfy_header_settings_metabox', 'wheelfy-header-options');
    
    if (!$cmb) {
        // Fallback if CMB2 is not available
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            <div class="notice notice-error">
                <p><?php esc_html_e('CMB2 framework is required for header settings. Please install CMB2 plugin.', 'wheelfy'); ?></p>
            </div>
        </div>
        <?php
        return;
    }
    
    // Render CMB2 form using the proper method for options pages
    ?>
    <div class="wrap cmb2-options-page option-wheelfy-header-options <?php echo esc_attr($cmb->cmb_id); ?>">
        <h2><?php echo esc_html(get_admin_page_title()); ?></h2>
        <?php 
        // Use CMB2's form rendering function for options pages
        cmb2_metabox_form($cmb, 'wheelfy-header-options', array(
            'save_button' => __('Save Settings', 'wheelfy'),
        )); 
        ?>
    </div>
    <?php
}

/**
 * Footer Options Page HTML
 */
function wheelfy_footer_options_page() {
    if (!current_user_can('manage_options')) {
        wp_die(__('You do not have sufficient permissions to access this page.', 'wheelfy'));
    }
    
    // Ensure CMB2 is available and initialized
    if (!function_exists('cmb2_get_metabox')) {
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            <div class="notice notice-error">
                <p><?php esc_html_e('CMB2 framework is required for footer settings. Please install and activate the CMB2 plugin.', 'wheelfy'); ?></p>
            </div>
        </div>
        <?php
        return;
    }
    
    // Ensure CMB2 metaboxes are registered
    if (!did_action('cmb2_admin_init')) {
        do_action('cmb2_admin_init');
    }
    
    // Get the CMB2 options page instance
    $cmb = cmb2_get_metabox('wheelfy_footer_settings_metabox', 'wheelfy-footer-options');
    
    if (!$cmb) {
        // Fallback if metabox not found
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            <div class="notice notice-error">
                <p><?php esc_html_e('Footer settings metabox not found. Please ensure CMB2 is properly configured.', 'wheelfy'); ?></p>
            </div>
        </div>
        <?php
        return;
    }
    
    // Render CMB2 form using the proper method for options pages
    ?>
    <div class="wrap cmb2-options-page option-wheelfy-footer-options <?php echo esc_attr($cmb->cmb_id); ?>">
        <h2><?php echo esc_html(get_admin_page_title()); ?></h2>
        <?php 
        // Use CMB2's form rendering function for options pages
        cmb2_metabox_form($cmb, 'wheelfy-footer-options', array(
            'save_button' => __('Save Settings', 'wheelfy'),
        )); 
        ?>
    </div>
    <?php
}

/**
 * Contact & Social Options Page HTML
 */
function wheelfy_contact_options_page() {
    if (!current_user_can('manage_options')) {
        wp_die(__('You do not have sufficient permissions to access this page.', 'wheelfy'));
    }
    
    // Get the CMB2 options page instance
    $cmb = cmb2_get_metabox('wheelfy_contact_social_settings_metabox', 'wheelfy-contact-options');
    
    if (!$cmb) {
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            <div class="notice notice-error">
                <p><?php esc_html_e('CMB2 framework is required for contact & social settings. Please install CMB2 plugin.', 'wheelfy'); ?></p>
            </div>
        </div>
        <?php
        return;
    }
    
    ?>
    <div class="wrap cmb2-options-page option-wheelfy-contact-options <?php echo esc_attr($cmb->cmb_id); ?>">
        <h2><?php echo esc_html(get_admin_page_title()); ?></h2>
        
        <!-- Contact & Social Section Title - Before Form -->
        <div class="cmb2-wrap form-table" style="margin-top: 20px;">
            <div class="cmb2-metabox cmb-field-list">
                <div class="cmb-row cmb-type-title">
                    <div class="cmb-td">
                        <h3 class="cmb2-metabox-title"><?php esc_html_e('Contact & Social', 'wheelfy'); ?></h3>
                        <p class="cmb2-metabox-description"><?php esc_html_e('Manage your contact information and social media links', 'wheelfy'); ?></p>
                    </div>
                </div>
            </div>
        </div>
        
        <?php 
        cmb2_metabox_form($cmb, 'wheelfy-contact-options', array(
            'save_button' => __('Save Settings', 'wheelfy'),
        )); 
        ?>
    </div>
    <?php
}

/**
 * Colors & Branding Options Page HTML
 */
function wheelfy_colors_options_page() {
    if (!current_user_can('manage_options')) {
        wp_die(__('You do not have sufficient permissions to access this page.', 'wheelfy'));
    }
    
    if (isset($_GET['settings-updated'])) {
        add_settings_error('wheelfy_messages', 'wheelfy_message', __('Settings Saved', 'wheelfy'), 'updated');
    }
    
    settings_errors('wheelfy_messages');
    ?>
    <div class="wrap">
        <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
        
        <form action="options.php" method="post">
            <?php
            settings_fields('wheelfy_theme_options');
            do_settings_sections('wheelfy-colors-options');
            submit_button(__('Save Settings', 'wheelfy'));
            ?>
        </form>
    </div>
    
    <style>
        .wheelfy-color-picker {
            width: 80px;
            height: 35px;
        }
    </style>
    
    <script>
    jQuery(document).ready(function($) {
        if ($.fn.wpColorPicker) {
            $('.wheelfy-color-picker').wpColorPicker();
        }
    });
    </script>
    <?php
}

/**
 * Business Information Options Page HTML
 */
function wheelfy_business_options_page() {
    if (!current_user_can('manage_options')) {
        wp_die(__('You do not have sufficient permissions to access this page.', 'wheelfy'));
    }
    
    if (isset($_GET['settings-updated'])) {
        add_settings_error('wheelfy_messages', 'wheelfy_message', __('Settings Saved', 'wheelfy'), 'updated');
    }
    
    settings_errors('wheelfy_messages');
    ?>
    <div class="wrap">
        <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
        
        <form action="options.php" method="post">
            <?php
            settings_fields('wheelfy_theme_options');
            do_settings_sections('wheelfy-business-options');
            submit_button(__('Save Settings', 'wheelfy'));
            ?>
        </form>
    </div>
    <?php
}

/**
 * Enqueue Admin Scripts and Styles for Theme Options
 */
function wheelfy_enqueue_admin_assets($hook) {
    // Load on all theme options pages
    $theme_options_pages = array(
        'toplevel_page_wheelfy-theme-options',
        'theme-settings_page_wheelfy-header-options',
        'theme-settings_page_wheelfy-footer-options',
        'theme-settings_page_wheelfy-contact-options',
        'theme-settings_page_wheelfy-colors-options',
        'theme-settings_page_wheelfy-business-options'
    );
    
    // Enqueue modern styles for Header Settings page
    if ($hook === 'theme-settings_page_wheelfy-header-options' || strpos($hook, 'wheelfy-header-options') !== false) {
        wp_enqueue_style(
            'wheelfy-admin-header-settings',
            get_template_directory_uri() . '/assets/admin-header-settings.css',
            array(),
            '1.1.0' // Version bump to force refresh
        );
    }
    
    // Enqueue modern styles for Footer Settings page (reuse header settings CSS for consistent design)
    if ($hook === 'theme-settings_page_wheelfy-footer-options' || strpos($hook, 'wheelfy-footer-options') !== false) {
        wp_enqueue_style(
            'wheelfy-admin-footer-settings',
            get_template_directory_uri() . '/assets/admin-header-settings.css',
            array(),
            '1.1.0' // Reuse header settings CSS for consistent design
        );
    }
    
    // Enqueue modern styles for Contact & Social Settings page (reuse header settings CSS for consistent design)
    if ($hook === 'theme-settings_page_wheelfy-contact-options' || strpos($hook, 'wheelfy-contact-options') !== false) {
        wp_enqueue_style(
            'wheelfy-admin-contact-settings',
            get_template_directory_uri() . '/assets/admin-header-settings.css',
            array(),
            '1.1.0' // Reuse header settings CSS for consistent design
        );
    }
    
    if (!in_array($hook, $theme_options_pages)) {
        return;
    }
    
    // Enqueue WordPress color picker (only needed for colors page, but safe to load on all)
    wp_enqueue_style('wp-color-picker');
    wp_enqueue_script('wp-color-picker');
}
add_action('admin_enqueue_scripts', 'wheelfy_enqueue_admin_assets');

/**
 * Helper Function: Get Theme Option
 * Usage: wheelfy_get_option('contact_email')
 */
function wheelfy_get_option($option_name, $default = '') {
    $options = get_option('wheelfy_theme_options');
    return isset($options[$option_name]) ? $options[$option_name] : $default;
}

/**
 * Get Dynamic Header CSS from CMB2 Settings
 * Generates CSS based on header settings
 */
function wheelfy_get_dynamic_header_css() {
    $header_height_desktop = wheelfy_get_header_option('header_height_desktop', '80');
    $header_height_mobile = wheelfy_get_header_option('header_height_mobile', '60');
    $header_bg_color = wheelfy_get_header_option('header_bg_color', '#1a1d2e');
    $header_bg_opacity = wheelfy_get_header_option('header_bg_opacity', '100');
    $header_sticky = wheelfy_get_header_option('header_sticky', true);
    $header_show_border = wheelfy_get_header_option('header_show_border', true);
    $header_border_color = wheelfy_get_header_option('header_border_color', 'rgba(255, 255, 255, 0.05)');
    $menu_font_size = wheelfy_get_header_option('header_menu_font_size', '15');
    $menu_spacing = wheelfy_get_header_option('header_menu_spacing', '4');
    $mobile_animation_speed = wheelfy_get_header_option('header_mobile_animation_speed', '300');
    $mobile_bg_color = wheelfy_get_header_option('header_mobile_bg_color', '#000000');
    $logo_height_desktop = wheelfy_get_header_option('header_logo_height_desktop', '40');
    $logo_height_mobile = wheelfy_get_header_option('header_logo_height_mobile', '32');
    
    // Calculate background color with opacity
    $bg_color_rgb = '';
    if ($header_bg_color) {
        if (strpos($header_bg_color, '#') === 0) {
            $hex = str_replace('#', '', $header_bg_color);
            $r = hexdec(substr($hex, 0, 2));
            $g = hexdec(substr($hex, 2, 2));
            $b = hexdec(substr($hex, 4, 2));
            $opacity = $header_bg_opacity / 100;
            $bg_color_rgb = "rgba({$r}, {$g}, {$b}, {$opacity})";
        } else {
            $bg_color_rgb = $header_bg_color;
        }
    } else {
        $bg_color_rgb = "rgba(26, 29, 46, " . ($header_bg_opacity / 100) . ")";
    }
    
    $css = "
    /* Dynamic Header Styles from CMB2 Settings */
    .desktop-header {
        height: {$header_height_desktop}px !important;
        background-color: {$bg_color_rgb} !important;
    }
    
    @media (max-width: 1023px) {
        .mobile-header-layout {
            height: {$header_height_mobile}px !important;
        }
    }
    
    /* Navigation Menu Styles */
    .desktop-header-nav ul {
        font-size: {$menu_font_size}px !important;
        gap: {$menu_spacing}px !important;
    }
    
    .desktop-header-nav .button-nav {
        font-size: {$menu_font_size}px !important;
    }
    
    /* Logo Heights */
    .desktop-header .desktop-header-layout img {
        max-height: {$logo_height_desktop}px !important;
    }
    
    @media (max-width: 1023px) {
        .mobile-header-layout img {
            max-height: {$logo_height_mobile}px !important;
        }
    }
    
    /* Mobile Menu Styles */
    #mobile-menu {
        background-color: {$mobile_bg_color} !important;
        transition-duration: {$mobile_animation_speed}ms !important;
    }
    
    #mobile-menu-overlay {
        transition-duration: {$mobile_animation_speed}ms !important;
    }
    
    /* Header Border */
    ";
    
    if ($header_show_border && $header_border_color) {
        $css .= "
    .desktop-header {
        border-bottom: 1px solid {$header_border_color} !important;
    }
        ";
    } else {
        $css .= "
    .desktop-header {
        border-bottom: none !important;
    }
        ";
    }
    
    if ($header_sticky) {
        $css .= "
    .desktop-header {
        position: sticky !important;
        top: 0 !important;
    }
        ";
    } else {
        $css .= "
    .desktop-header {
        position: fixed !important;
        top: 0 !important;
    }
        ";
    }
    
    // Header spacer height
    $css .= "
    .header-spacer {
        height: {$header_height_desktop}px !important;
    }
    
    @media (max-width: 1023px) {
        .header-spacer {
            height: {$header_height_mobile}px !important;
        }
        
        .header-mobile {
            height: {$header_height_mobile}px !important;
        }
    }
    ";
    
    return $css;
}

/**
 * Generate dynamic footer CSS from CMB2 settings
 * 
 * @return string CSS string
 */
function wheelfy_get_dynamic_footer_css() {
    $footer_bg_color = wheelfy_get_footer_option('footer_bg_color', '#1a1d2e');
    $footer_text_color = wheelfy_get_footer_option('footer_text_color', '#ffffff');
    $footer_padding_top = wheelfy_get_footer_option('footer_padding_top', '64');
    $footer_padding_bottom = wheelfy_get_footer_option('footer_padding_bottom', '64');
    $footer_show_border = wheelfy_get_footer_option('footer_show_border', true);
    $footer_border_color = wheelfy_get_footer_option('footer_border_color', 'rgba(255, 255, 255, 0.05)');
    $footer_logo_height = wheelfy_get_footer_option('footer_logo_height', '40');
    
    $css = "
    /* Dynamic Footer Styles from CMB2 Settings */
    footer {
        background-color: {$footer_bg_color} !important;
        color: {$footer_text_color} !important;
        padding-top: {$footer_padding_top}px !important;
    }
    
    footer * {
        color: {$footer_text_color} !important;
    }
    
    footer a {
        color: {$footer_text_color} !important;
    }
    
    footer a:hover {
        color: var(--primary) !important;
    }
    
    footer .footer-logo img {
        height: {$footer_logo_height}px !important;
        max-height: {$footer_logo_height}px !important;
        width: auto !important;
    }
    
    footer .text-center {
        text-align: center;
        padding: 20px 0px;
    }
    
    /* Footer Mobile Responsive Styles */
    @media (max-width: 767px) {
        footer .footer-container {
            padding-top: 2.5rem !important;
            padding-left: 1rem !important;
            padding-right: 1rem !important;
        }
        
        footer .footer-grid {
            gap: 2rem !important;
            margin-bottom: 2rem !important;
        }
        
        footer .space-y-4 > * + * {
            margin-top: 1rem !important;
        }
        
        footer h3 {
            margin-bottom: 1rem !important;
            font-size: 1.125rem !important;
        }
        
        footer ul {
            gap: 0.75rem !important;
        }
        
        footer .footer-copyright-section {
            margin-top: 2rem !important;
            padding-top: 1.5rem !important;
        }
        
        footer .footer-copyright-text {
            padding: 1rem 0 !important;
        }
        
        footer .flex.items-center.gap-4 {
            gap: 0.75rem !important;
            flex-wrap: wrap !important;
            margin-top: 1.5rem !important;
        }
        
        footer .w-10.h-10 {
            width: 2.5rem !important;
            height: 2.5rem !important;
        }
        
        footer .w-10.h-10 svg {
            width: 1.25rem !important;
            height: 1.25rem !important;
        }
        
        footer p.text-sm {
            font-size: 0.875rem !important;
            line-height: 1.5 !important;
        }
        
        footer .footer-logo-description {
            font-size: 1rem !important;
            line-height: 1.625 !important;
            margin-top: 0.75rem !important;
        }
        
        /* Widget areas on mobile */
        footer .widget,
        footer #quick-links-widget-area .widget,
        footer #footer-menu-two .widget {
            margin-bottom: 2rem !important;
        }
        
        footer .widget-title,
        footer h3.widget-title {
            font-size: 1.125rem !important;
            margin-bottom: 1rem !important;
        }
        
        footer .widget ul li,
        footer .menu-item {
            margin-bottom: 0.75rem !important;
        }
        
        footer .widget ul li a,
        footer .menu-item a {
            font-size: 0.875rem !important;
            padding: 0.25rem 0 !important;
        }
        
        /* Social media icons on mobile */
        footer .flex.items-center.gap-4 {
            justify-content: flex-start !important;
            flex-wrap: wrap !important;
        }
        
        /* Ensure grid columns stack on mobile */
        footer .footer-grid {
            grid-template-columns: 1fr !important;
        }
        
        /* Contact information spacing on mobile */
        footer ul.space-y-3 li {
            margin-bottom: 0.75rem !important;
        }
        
        /* Logo sizing on mobile */
        footer img[style*='height'] {
            max-width: 100% !important;
            height: auto !important;
        }
    }
    
    @media (min-width: 768px) and (max-width: 1023px) {
        footer .footer-container {
            padding-top: 3rem !important;
        }
        
        footer .footer-grid {
            gap: 3rem !important;
            margin-bottom: 3rem !important;
        }
        
        footer .footer-copyright-section {
            margin-top: 3rem !important;
        }
    }
    ";
    
    if ($footer_show_border && $footer_border_color) {
        $css .= "
    footer {
        border-top: 1px solid {$footer_border_color} !important;
    }
        ";
    } else {
        $css .= "
    footer {
        border-top: none !important;
    }
        ";
    }
    
    return $css;
}

/**
 * Handle Request for Proposal Form Submission
 */
function wheelfy_handle_proposal_submission() {
    // Verify nonce
    if (!isset($_POST['proposal_nonce']) || !wp_verify_nonce($_POST['proposal_nonce'], 'submit_proposal_nonce')) {
        wp_die('Security check failed', 'Error', array('back_link' => true));
    }

    // Sanitize and validate form data
    $request_type = isset($_POST['request_type']) ? sanitize_text_field($_POST['request_type']) : 'maintenance';
    
    // Car details
    $car_brand = isset($_POST['car_brand']) ? sanitize_text_field($_POST['car_brand']) : '';
    $car_model = isset($_POST['car_model']) ? sanitize_text_field($_POST['car_model']) : '';
    $car_year = isset($_POST['car_year']) ? intval($_POST['car_year']) : 0;
    $fuel_type = isset($_POST['fuel_type']) ? sanitize_text_field($_POST['fuel_type']) : '';
    $mileage = isset($_POST['mileage']) ? intval($_POST['mileage']) : 0;
    $license_plate = isset($_POST['license_plate']) ? sanitize_text_field($_POST['license_plate']) : '';
    
    // Service info
    $service_type = isset($_POST['service_type']) ? sanitize_text_field($_POST['service_type']) : '';
    $service_description = isset($_POST['service_description']) ? sanitize_textarea_field($_POST['service_description']) : '';
    $preferred_date = isset($_POST['preferred_date']) ? sanitize_text_field($_POST['preferred_date']) : '';
    
    // Contact info
    $full_name = isset($_POST['full_name']) ? sanitize_text_field($_POST['full_name']) : '';
    $email = isset($_POST['email']) ? sanitize_email($_POST['email']) : '';
    $phone = isset($_POST['phone']) ? sanitize_text_field($_POST['phone']) : '';
    $location = isset($_POST['location']) ? sanitize_text_field($_POST['location']) : '';
    $terms_agree = isset($_POST['terms_agree']) ? true : false;

    // Determine redirect URL based on request type
    $redirect_url = ($request_type === 'sell') ? home_url('/sell-your-car') : home_url('/request-proposal');

    // Basic validation - service_type is only required for maintenance requests, not for sell requests
    $required_fields_valid = !empty($car_brand) && !empty($car_model) && !empty($car_year) && !empty($fuel_type) && !empty($full_name) && !empty($email) && $terms_agree;
    
    // For maintenance requests, also require service_type
    if ($request_type === 'maintenance' && empty($service_type)) {
        $required_fields_valid = false;
    }
    
    if (!$required_fields_valid) {
        wp_redirect(add_query_arg('error', 'missing_fields', $redirect_url));
        exit;
    }

    // If request type is 'sell', save to transient and redirect to select-partner
    if ($request_type === 'sell') {
        $request_id = uniqid('req_', true);
        $form_data = array(
            'make' => $car_brand,
            'model' => $car_model,
            'year' => $car_year,
            'fuel_type' => $fuel_type,
            'mileage' => $mileage,
            'license_plate' => $license_plate,
            'additional_notes' => $service_description, // Used for additional notes in sell car
            'location' => $location,
            'full_name' => $full_name,
            'email' => $email, // IMPORTANT: Always save email field for partner selection
            'phone' => $phone,
            'request_type' => 'sell_car', // Explicitly set for partner selection
            'timestamp' => current_time('mysql'),
        );

        if (is_user_logged_in()) {
            $form_data['customer_id'] = get_current_user_id();
            $form_data['customer_email'] = $email;
        }

        set_transient('car_accessories_request_' . $request_id, $form_data, HOUR_IN_SECONDS);
        wp_safe_redirect(home_url('/select-partner?request_id=' . $request_id));
        exit;
    }

    // Create proposal post
    $proposal_data = array(
        'post_title'    => sprintf('%s - %s %s (%s)', $full_name, $car_brand, $car_model, $car_year),
        'post_content'  => sprintf(
            "Request Type: %s\n\nCar Details:\nBrand: %s\nModel: %s\nYear: %s\nFuel Type: %s\nMileage: %s km\nLicense Plate: %s\n\n%s\n\nContact:\nName: %s\nEmail: %s\nPhone: %s\nLocation: %s",
            $request_type,
            $car_brand,
            $car_model,
            $car_year,
            $fuel_type,
            $mileage,
            $license_plate,
            ($request_type === 'sell') 
                ? sprintf("Additional Details:\nDescription: %s\nLocation: %s", $service_description, $location)
                : sprintf("Service Info:\nService Type: %s\nDescription: %s\nPreferred Date: %s", $service_type, $service_description, $preferred_date),
            $full_name,
            $email,
            $phone,
            $location
        ),
        'post_status'   => 'publish',
        'post_type'     => 'post',
        'post_author'   => get_current_user_id() ?: 1,
    );

    $proposal_id = wp_insert_post($proposal_data);

    if (is_wp_error($proposal_id)) {
        wp_redirect(add_query_arg('error', 'submission_failed', $redirect_url));
        exit;
    }

    // Save meta data
    update_post_meta($proposal_id, '_proposal_request_type', $request_type);
    update_post_meta($proposal_id, '_proposal_status', 'pending'); // Set initial status as pending
    update_post_meta($proposal_id, '_proposal_car_brand', $car_brand);
    update_post_meta($proposal_id, '_proposal_car_model', $car_model);
    update_post_meta($proposal_id, '_proposal_car_year', $car_year);
    update_post_meta($proposal_id, '_proposal_fuel_type', $fuel_type);
    update_post_meta($proposal_id, '_proposal_mileage', $mileage);
    update_post_meta($proposal_id, '_proposal_license_plate', $license_plate);
    
    // Only save service_type and preferred_date for maintenance requests
    if ($request_type === 'maintenance') {
        update_post_meta($proposal_id, '_proposal_service_type', $service_type);
        update_post_meta($proposal_id, '_proposal_preferred_date', $preferred_date);
    }
    
    update_post_meta($proposal_id, '_proposal_service_description', $service_description);
    update_post_meta($proposal_id, '_proposal_full_name', $full_name);
    update_post_meta($proposal_id, '_proposal_email', $email);
    update_post_meta($proposal_id, '_proposal_phone', $phone);
    update_post_meta($proposal_id, '_proposal_location', $location);

    // Handle car photos upload for sell requests
    if ($request_type === 'sell' && !empty($_FILES['car_photos']['name'][0])) {
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        require_once(ABSPATH . 'wp-admin/includes/media.php');
        
        $uploaded_photos = array();
        $files = $_FILES['car_photos'];
        
        // Handle multiple file uploads
        $file_count = count($files['name']);
        for ($i = 0; $i < $file_count; $i++) {
            if ($files['error'][$i] === UPLOAD_ERR_OK) {
                $file = array(
                    'name'     => $files['name'][$i],
                    'type'     => $files['type'][$i],
                    'tmp_name' => $files['tmp_name'][$i],
                    'error'    => $files['error'][$i],
                    'size'     => $files['size'][$i]
                );
                
                // Validate file type
                $allowed_types = array('image/jpeg', 'image/jpg', 'image/png', 'image/webp', 'image/svg+xml');
                $file_type = wp_check_filetype($file['name']);
                
                if (in_array($file['type'], $allowed_types) || in_array($file_type['type'], $allowed_types)) {
                    // Validate file size (max 8MB)
                    $max_size = 8 * 1024 * 1024; // 8MB
                    if ($file['size'] <= $max_size) {
                        $upload = wp_handle_upload($file, array('test_form' => false));
                        
                        if (!isset($upload['error'])) {
                            $attachment = array(
                                'post_mime_type' => $upload['type'],
                                'post_title'     => sanitize_file_name(pathinfo($file['name'], PATHINFO_FILENAME)),
                                'post_content'   => '',
                                'post_status'    => 'inherit',
                                'post_parent'    => $proposal_id,
                            );
                            
                            $attach_id = wp_insert_attachment($attachment, $upload['file'], $proposal_id);
                            
                            if (!is_wp_error($attach_id)) {
                                $attach_data = wp_generate_attachment_metadata($attach_id, $upload['file']);
                                wp_update_attachment_metadata($attach_id, $attach_data);
                                $uploaded_photos[] = $attach_id;
                            }
                        }
                    }
                }
            }
        }
        
        // Save photo attachment IDs as meta
        if (!empty($uploaded_photos)) {
            update_post_meta($proposal_id, '_proposal_car_photos', $uploaded_photos);
        }
    }

    // Get customer ID if logged in
    $customer_id = is_user_logged_in() ? get_current_user_id() : 0;
    
    // Get all active partners to send email notifications
    $all_partners = get_users(array('role' => 'partner', 'number' => -1));
    
    // Prepare form data for email
    $form_data_for_email = array(
        'make' => $car_brand,
        'model' => $car_model,
        'year' => $car_year,
        'mileage' => $mileage,
        'request_type' => $request_type,
        'service_description' => $service_description,
        'full_name' => $full_name,
        'email' => $email,
        'phone' => $phone,
        'location' => $location
    );
    
    // Send email to all active partners about new request
    if (!empty($all_partners)) {
        foreach ($all_partners as $partner) {
            wheelfy_send_new_request_email_to_partner($partner->ID, 'post_' . $proposal_id, $form_data_for_email, $customer_id, $email);
        }
    }
    
    // Redirect to success page or show success message
    wp_redirect(add_query_arg('success', '1', $redirect_url));
    exit;
}
add_action('admin_post_submit_proposal', 'wheelfy_handle_proposal_submission');
add_action('admin_post_nopriv_submit_proposal', 'wheelfy_handle_proposal_submission');

/**
 * AJAX: Get subscription plan
 */
function wheelfy_ajax_get_subscription_plan() {
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_save_subscription_plan')) {
        wp_send_json_error(array('message' => __('Security check failed.', 'wheelfy')));
    }
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => __('Insufficient permissions.', 'wheelfy')));
    }
    
    $plan_id = isset($_POST['plan_id']) ? sanitize_text_field($_POST['plan_id']) : '';
    if (empty($plan_id)) {
        wp_send_json_error(array('message' => __('Plan ID is required.', 'wheelfy')));
    }
    
    $plans = get_option('wheelfy_subscription_plans', array());
    $plan = null;
    
    foreach ($plans as $p) {
        if (isset($p['id']) && $p['id'] === $plan_id) {
            $plan = $p;
            break;
        }
    }
    
    if ($plan) {
        wp_send_json_success(array('plan' => $plan));
    } else {
        wp_send_json_error(array('message' => __('Plan not found.', 'wheelfy')));
    }
}
add_action('wp_ajax_wheelfy_get_subscription_plan', 'wheelfy_ajax_get_subscription_plan');

/**
 * AJAX: Save subscription plan
 */
function wheelfy_ajax_save_subscription_plan() {
    check_ajax_referer('wheelfy_save_subscription_plan', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => __('Insufficient permissions.', 'wheelfy')));
    }
    
    $plan_id = isset($_POST['plan_id']) ? sanitize_text_field($_POST['plan_id']) : '';
    $plan_name = isset($_POST['plan_name']) ? sanitize_text_field($_POST['plan_name']) : '';
    
    if (empty($plan_name)) {
        wp_send_json_error(array('message' => __('Plan name is required.', 'wheelfy')));
    }
    
    $plans = get_option('wheelfy_subscription_plans', array());
    
    // Generate plan ID if not provided
    $final_plan_id = !empty($plan_id) ? $plan_id : sanitize_title($plan_name);
    
    // Prepare plan data
    $plan_data = array(
        'id' => $final_plan_id,
        'name' => $plan_name,
        'price' => isset($_POST['plan_price']) ? floatval($_POST['plan_price']) : 0,
        'currency' => isset($_POST['plan_currency']) ? sanitize_text_field($_POST['plan_currency']) : 'EUR',
        'price_display' => isset($_POST['plan_price_display']) ? sanitize_text_field($_POST['plan_price_display']) : '',
        'commission_rate' => isset($_POST['plan_commission_rate']) ? floatval($_POST['plan_commission_rate']) : 0,
        'has_commission' => isset($_POST['plan_has_commission']) ? ($_POST['plan_has_commission'] === '1' || $_POST['plan_has_commission'] === true) : true,
        'bidding_restriction' => isset($_POST['plan_bidding_restriction']) ? sanitize_text_field($_POST['plan_bidding_restriction']) : 'none',
        'bidding_restriction_label' => isset($_POST['plan_bidding_restriction_label']) ? sanitize_text_field($_POST['plan_bidding_restriction_label']) : '',
        'features' => isset($_POST['plan_features']) ? sanitize_textarea_field($_POST['plan_features']) : '',
        'features_list' => isset($_POST['plan_features_list']) && is_array($_POST['plan_features_list']) ? array_map('sanitize_text_field', $_POST['plan_features_list']) : array(),
        'popular' => isset($_POST['plan_popular']) && $_POST['plan_popular'] === '1',
        'subscribers' => 0
    );
    
    // Convert features textarea to array if needed
    if (is_string($plan_data['features']) && !empty($plan_data['features'])) {
        $plan_data['features'] = array_filter(array_map('trim', explode("\n", $plan_data['features'])));
    }
    
    // If editing, find and update existing plan
    if (!empty($plan_id)) {
        $found = false;
        foreach ($plans as $key => $plan) {
            if ($plan['id'] === $plan_id) {
                // Preserve subscribers count
                $plan_data['subscribers'] = isset($plan['subscribers']) ? $plan['subscribers'] : 0;
                $plans[$key] = $plan_data;
                $found = true;
                break;
            }
        }
        if (!$found) {
            wp_send_json_error(array('message' => __('Plan not found for updating.', 'wheelfy')));
        }
    } else {
        // New plan
        $plans[] = $plan_data;
    }
    
    update_option('wheelfy_subscription_plans', $plans);
    
    wp_send_json_success(array(
        'message' => __('Plan saved successfully.', 'wheelfy'),
        'plan' => $plan_data
    ));
}
add_action('wp_ajax_wheelfy_save_subscription_plan', 'wheelfy_ajax_save_subscription_plan');

/**
 * AJAX: Delete subscription plan
 */
function wheelfy_ajax_delete_subscription_plan() {
    $plan_id = isset($_POST['plan_id']) ? sanitize_text_field($_POST['plan_id']) : '';
    $nonce = isset($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : '';
    
    if (!wp_verify_nonce($nonce, 'wheelfy_delete_subscription_plan_' . $plan_id)) {
        wp_send_json_error(array('message' => __('Security check failed.', 'wheelfy')));
    }
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => __('Insufficient permissions.', 'wheelfy')));
    }
    
    if (empty($plan_id)) {
        wp_send_json_error(array('message' => __('Plan ID is required.', 'wheelfy')));
    }
    
    $plans = get_option('wheelfy_subscription_plans', array());
    $found = false;
    
    foreach ($plans as $key => $plan) {
        if ($plan['id'] === $plan_id) {
            unset($plans[$key]);
            $found = true;
            break;
        }
    }
    
    if ($found) {
        $plans = array_values($plans); // Re-index array
        update_option('wheelfy_subscription_plans', $plans);
        wp_send_json_success(array('message' => __('Plan deleted successfully.', 'wheelfy')));
    } else {
        wp_send_json_error(array('message' => __('Plan not found.', 'wheelfy')));
    }
}
add_action('wp_ajax_wheelfy_delete_subscription_plan', 'wheelfy_ajax_delete_subscription_plan');

/**
 * AJAX: Accept Request
 */
function wheelfy_ajax_accept_request() {
    // Check nonce
    $nonce = isset($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : '';
    if (!wp_verify_nonce($nonce, 'wheelfy_request_action')) {
        wp_send_json_error(array('message' => __('Security check failed.', 'wheelfy')));
    }
    
    // Check permissions
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => __('Insufficient permissions.', 'wheelfy')));
    }
    
    // Get post ID
    $post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;
    if (empty($post_id)) {
        wp_send_json_error(array('message' => __('Invalid request ID.', 'wheelfy')));
    }
    
    // Verify post exists and is a proposal request
    $post = get_post($post_id);
    if (!$post) {
        wp_send_json_error(array('message' => __('Request not found.', 'wheelfy')));
    }
    
    // Check if it's a proposal request
    $request_type = get_post_meta($post_id, '_proposal_request_type', true);
    if (empty($request_type)) {
        wp_send_json_error(array('message' => __('This is not a valid proposal request.', 'wheelfy')));
    }
    
    // Update status to accepted
    update_post_meta($post_id, '_proposal_status', 'accepted');
    update_post_meta($post_id, '_proposal_accepted_date', current_time('mysql'));
    update_post_meta($post_id, '_proposal_accepted_by', get_current_user_id());
    
    // Get customer and partner info for email
    $customer_id = get_post_field('post_author', $post_id);
    $partner_id = get_current_user_id();
    $partner_user = get_userdata($partner_id);
    $partner_name = '';
    if ($partner_user) {
        $business_name = get_user_meta($partner_id, 'business_name', true);
        $partner_name = !empty($business_name) ? $business_name : ($partner_user->display_name ?: $partner_user->user_login);
    }
    
    // Get form data from post meta
    $form_data = array(
        'make' => get_post_meta($post_id, '_proposal_car_brand', true),
        'model' => get_post_meta($post_id, '_proposal_car_model', true),
        'year' => get_post_meta($post_id, '_proposal_car_year', true)
    );
    
    // Send email to customer
    if ($customer_id > 0) {
        wheelfy_send_request_accepted_email_to_customer($customer_id, 'post_' . $post_id, $partner_id, $partner_name, $form_data);
    }
    
    wp_send_json_success(array('message' => __('Request accepted successfully.', 'wheelfy')));
}
add_action('wp_ajax_wheelfy_accept_request', 'wheelfy_ajax_accept_request');

/**
 * AJAX: Delete Request
 */
function wheelfy_ajax_delete_request() {
    // Check nonce
    $nonce = isset($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : '';
    if (!wp_verify_nonce($nonce, 'wheelfy_request_action')) {
        wp_send_json_error(array('message' => __('Security check failed.', 'wheelfy')));
    }
    
    // Check permissions
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => __('Insufficient permissions.', 'wheelfy')));
    }
    
    // Get post ID
    $post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;
    if (empty($post_id)) {
        wp_send_json_error(array('message' => __('Invalid request ID.', 'wheelfy')));
    }
    
    // Verify post exists and is a proposal request
    $post = get_post($post_id);
    if (!$post) {
        wp_send_json_error(array('message' => __('Request not found.', 'wheelfy')));
    }
    
    // Check if it's a proposal request
    $request_type = get_post_meta($post_id, '_proposal_request_type', true);
    if (empty($request_type)) {
        wp_send_json_error(array('message' => __('This is not a valid proposal request.', 'wheelfy')));
    }
    
    // Delete the post (move to trash)
    $result = wp_delete_post($post_id, false); // false = move to trash, true = permanently delete
    
    if ($result) {
        wp_send_json_success(array('message' => __('Request deleted successfully.', 'wheelfy')));
    } else {
        wp_send_json_error(array('message' => __('Failed to delete request.', 'wheelfy')));
    }
}
add_action('wp_ajax_wheelfy_delete_request', 'wheelfy_ajax_delete_request');

/**
 * ============================================================================
 * NOTIFICATION SYSTEM
 * ============================================================================
 * Real-time notification system for customer and partner dashboards
 */

/**
 * Create a notification for a user
 * 
 * @param int $user_id User ID to notify
 * @param string $type Notification type (message, review, request_accepted, request_rejected, request_deleted, new_request, system)
 * @param string $title Notification title
 * @param string $message Notification message
 * @param array $meta Additional metadata (link, icon, etc.)
 * @return int|false Notification ID or false on failure
 */
function wheelfy_create_notification($user_id, $type, $title, $message, $meta = array()) {
    if (empty($user_id) || empty($type) || empty($title) || empty($message)) {
        return false;
    }
    
    // Check if message notifications are disabled for this user
    if ($type === 'message') {
        $message_notifications_enabled = get_user_meta($user_id, 'message_notifications_enabled', true);
        // If preference is set to '0' (disabled), don't create notification
        if ($message_notifications_enabled === '0') {
            return false;
        }
        // If preference is empty, default to enabled (backward compatibility)
    }
    
    // Check if review notifications are disabled for this user
    if ($type === 'review') {
        $review_notifications_enabled = get_user_meta($user_id, 'review_notifications_enabled', true);
        // If preference is set to '0' (disabled), don't create notification
        if ($review_notifications_enabled === '0') {
            return false;
        }
        // If preference is empty, default to enabled (backward compatibility)
    }
    
    $notifications = get_user_meta($user_id, 'wheelfy_notifications', true);
    if (!is_array($notifications)) {
        $notifications = array();
    }
    
    $notification_id = 'notif_' . time() . '_' . wp_generate_password(8, false);
    
    $notification = array(
        'id' => $notification_id,
        'type' => sanitize_text_field($type),
        'title' => sanitize_text_field($title),
        'message' => sanitize_textarea_field($message),
        'read' => false,
        'created_at' => current_time('mysql'),
        'timestamp' => current_time('timestamp'),
        'meta' => wp_parse_args($meta, array(
            'link' => '',
            'icon' => '',
            'action_text' => '',
            'related_id' => ''
        ))
    );
    
    // Add to beginning of array (newest first)
    array_unshift($notifications, $notification);
    
    // Keep only last 100 notifications per user
    if (count($notifications) > 100) {
        $notifications = array_slice($notifications, 0, 100);
    }
    
    update_user_meta($user_id, 'wheelfy_notifications', $notifications);
    
    return $notification_id;
}

/**
 * Get notifications for a user
 * 
 * @param int $user_id User ID
 * @param array $args Query arguments (limit, unread_only, type)
 * @return array Notifications array
 */
function wheelfy_get_notifications($user_id, $args = array()) {
    $defaults = array(
        'limit' => 50,
        'unread_only' => false,
        'type' => ''
    );
    $args = wp_parse_args($args, $defaults);
    
    $notifications = get_user_meta($user_id, 'wheelfy_notifications', true);
    if (!is_array($notifications)) {
        return array();
    }
    
    // Filter by unread if requested
    if ($args['unread_only']) {
        $notifications = array_filter($notifications, function($notif) {
            return !$notif['read'];
        });
    }
    
    // Filter by type if requested
    if (!empty($args['type'])) {
        $notifications = array_filter($notifications, function($notif) use ($args) {
            return $notif['type'] === $args['type'];
        });
    }
    
    // Apply limit
    if ($args['limit'] > 0) {
        $notifications = array_slice($notifications, 0, $args['limit']);
    }
    
    return array_values($notifications);
}

/**
 * Get unread notification count for a user
 * 
 * @param int $user_id User ID
 * @return int Unread count
 */
function wheelfy_get_unread_notification_count($user_id) {
    $notifications = get_user_meta($user_id, 'wheelfy_notifications', true);
    if (!is_array($notifications)) {
        return 0;
    }
    
    $unread = array_filter($notifications, function($notif) {
        return !$notif['read'];
    });
    
    return count($unread);
}

/**
 * Mark notification as read
 * 
 * @param int $user_id User ID
 * @param string $notification_id Notification ID
 * @return bool Success
 */
function wheelfy_mark_notification_read($user_id, $notification_id) {
    $notifications = get_user_meta($user_id, 'wheelfy_notifications', true);
    if (!is_array($notifications)) {
        return false;
    }
    
    foreach ($notifications as &$notif) {
        if ($notif['id'] === $notification_id) {
            $notif['read'] = true;
            $notif['read_at'] = current_time('mysql');
            update_user_meta($user_id, 'wheelfy_notifications', $notifications);
            return true;
        }
    }
    
    return false;
}

/**
 * Mark all notifications as read for a user
 * 
 * @param int $user_id User ID
 * @return bool Success
 */
function wheelfy_mark_all_notifications_read($user_id) {
    $notifications = get_user_meta($user_id, 'wheelfy_notifications', true);
    if (!is_array($notifications)) {
        return false;
    }
    
    foreach ($notifications as &$notif) {
        if (!$notif['read']) {
            $notif['read'] = true;
            $notif['read_at'] = current_time('mysql');
        }
    }
    
    update_user_meta($user_id, 'wheelfy_notifications', $notifications);
    return true;
}

/**
 * AJAX: Get notifications
 */
function wheelfy_ajax_get_notifications() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_nonce')) {
        wp_send_json_error(array('message' => 'Security check failed.'));
    }
    
    // Check if user is logged in
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'You must be logged in.'));
    }
    
    $user_id = get_current_user_id();
    $unread_only = isset($_POST['unread_only']) && $_POST['unread_only'] === 'true';
    $limit = isset($_POST['limit']) ? intval($_POST['limit']) : 50;
    
    $args = array(
        'limit' => $limit,
        'unread_only' => $unread_only
    );
    
    $notifications = wheelfy_get_notifications($user_id, $args);
    $unread_count = wheelfy_get_unread_notification_count($user_id);
    
    wp_send_json_success(array(
        'notifications' => $notifications,
        'unread_count' => $unread_count
    ));
}
add_action('wp_ajax_get_notifications', 'wheelfy_ajax_get_notifications');

/**
 * AJAX: Get unread notification count only (lightweight)
 */
function wheelfy_ajax_get_notification_count() {
    // Check if user is logged in
    if (!is_user_logged_in()) {
        wp_send_json_success(array('unread_count' => 0));
    }
    
    $user_id = get_current_user_id();
    $unread_count = wheelfy_get_unread_notification_count($user_id);
    
    wp_send_json_success(array('unread_count' => $unread_count));
}
add_action('wp_ajax_get_notification_count', 'wheelfy_ajax_get_notification_count');
add_action('wp_ajax_nopriv_get_notification_count', 'wheelfy_ajax_get_notification_count');

/**
 * AJAX: Mark notification as read
 */
function wheelfy_ajax_mark_notification_read() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_nonce')) {
        wp_send_json_error(array('message' => 'Security check failed.'));
    }
    
    // Check if user is logged in
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'You must be logged in.'));
    }
    
    $user_id = get_current_user_id();
    $notification_id = isset($_POST['notification_id']) ? sanitize_text_field($_POST['notification_id']) : '';
    
    if (empty($notification_id)) {
        wp_send_json_error(array('message' => 'Notification ID is required.'));
    }
    
    $success = wheelfy_mark_notification_read($user_id, $notification_id);
    
    if ($success) {
        $unread_count = wheelfy_get_unread_notification_count($user_id);
        wp_send_json_success(array(
            'message' => 'Notification marked as read.',
            'unread_count' => $unread_count
        ));
    } else {
        wp_send_json_error(array('message' => 'Failed to mark notification as read.'));
    }
}
add_action('wp_ajax_mark_notification_read', 'wheelfy_ajax_mark_notification_read');

/**
 * AJAX: Mark all notifications as read
 */
function wheelfy_ajax_mark_all_notifications_read() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_nonce')) {
        wp_send_json_error(array('message' => 'Security check failed.'));
    }
    
    // Check if user is logged in
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'You must be logged in.'));
    }
    
    $user_id = get_current_user_id();
    $success = wheelfy_mark_all_notifications_read($user_id);
    
    if ($success) {
        wp_send_json_success(array('message' => 'All notifications marked as read.'));
    } else {
        wp_send_json_error(array('message' => 'Failed to mark notifications as read.'));
    }
}
add_action('wp_ajax_mark_all_notifications_read', 'wheelfy_ajax_mark_all_notifications_read');

/**
 * Create notification when request is accepted
 */
function wheelfy_notify_request_accepted($request_id, $partner_id, $customer_id) {
    $partner = get_userdata($partner_id);
    $partner_name = $partner ? ($partner->display_name ?: $partner->user_login) : 'Partner';
    
    $business_name = get_user_meta($partner_id, 'business_name', true);
    if (!empty($business_name)) {
        $partner_name = $business_name;
    }
    
    wheelfy_create_notification(
        $customer_id,
        'request_accepted',
        'Request Accepted',
        sprintf('Your service request has been accepted by %s.', $partner_name),
        array(
            'link' => home_url('/customer-dashboard#requests'),
            'icon' => 'check-circle',
            'action_text' => 'View Request',
            'related_id' => $request_id
        )
    );
}
add_action('wheelfy_request_accepted', 'wheelfy_notify_request_accepted', 10, 3);

/**
 * Create notification when request is rejected/deleted
 */
function wheelfy_notify_request_rejected($request_id, $partner_id, $customer_id) {
    $partner = get_userdata($partner_id);
    $partner_name = $partner ? ($partner->display_name ?: $partner->user_login) : 'Partner';
    
    $business_name = get_user_meta($partner_id, 'business_name', true);
    if (!empty($business_name)) {
        $partner_name = $business_name;
    }
    
    wheelfy_create_notification(
        $customer_id,
        'request_rejected',
        'Request Declined',
        sprintf('Your service request was declined by %s.', $partner_name),
        array(
            'link' => home_url('/customer-dashboard#requests'),
            'icon' => 'x-circle',
            'action_text' => 'View Request',
            'related_id' => $request_id
        )
    );
}
add_action('wheelfy_request_rejected', 'wheelfy_notify_request_rejected', 10, 3);

/**
 * Create notification when new service request is received (for partners)
 */
function wheelfy_notify_new_service_request($request_id, $customer_id, $partner_id) {
    $customer = get_userdata($customer_id);
    $customer_name = $customer ? ($customer->display_name ?: $customer->user_login) : 'Customer';
    
    wheelfy_create_notification(
        $partner_id,
        'new_request',
        'New Service Request',
        sprintf('You have received a new service request from %s.', $customer_name),
        array(
            'link' => home_url('/partner-dashboard#requests'),
            'icon' => 'bell',
            'action_text' => 'View Request',
            'related_id' => $request_id
        )
    );
}
add_action('wheelfy_new_service_request', 'wheelfy_notify_new_service_request', 10, 3);

/**
 * Create notification when request is cancelled
 */
function wheelfy_notify_request_cancelled($request_id, $customer_id, $partner_id) {
    $customer = get_userdata($customer_id);
    $customer_name = $customer ? ($customer->display_name ?: $customer->user_login) : 'Customer';
    
    wheelfy_create_notification(
        $partner_id,
        'request_deleted',
        'Request Cancelled',
        sprintf('Service request from %s has been cancelled.', $customer_name),
        array(
            'link' => home_url('/partner-dashboard#requests'),
            'icon' => 'x-circle',
            'action_text' => 'View Requests',
            'related_id' => $request_id
        )
    );
}
add_action('wheelfy_request_cancelled', 'wheelfy_notify_request_cancelled', 10, 3);

/**
 * Hook into request status updates to create notifications
 */
function wheelfy_handle_request_status_notification($request_id, $status, $partner_id, $customer_id) {
    if ($status === 'accepted') {
        do_action('wheelfy_request_accepted', $request_id, $partner_id, $customer_id);
    } elseif ($status === 'rejected' || $status === 'deleted') {
        do_action('wheelfy_request_rejected', $request_id, $partner_id, $customer_id);
    }
}

// Hook into request cancellation
function wheelfy_handle_cancel_notification($request_id, $customer_id, $partner_id) {
    if ($partner_id > 0) {
        do_action('wheelfy_request_cancelled', $request_id, $customer_id, $partner_id);
    }
}

/**
 * ============================================================================
 * REVIEW SYSTEM
 * ============================================================================
 * Comprehensive review system with eligibility checks and time-based controls
 */

/**
 * Check if a customer is eligible to review a partner
 * 
 * @param int $customer_id Customer user ID
 * @param int $partner_id Partner user ID
 * @return array Eligibility status and details
 */
function wheelfy_check_review_eligibility($customer_id, $partner_id) {
    if (empty($customer_id) || empty($partner_id)) {
        return array(
            'eligible' => false,
            'reason' => 'Invalid user IDs'
        );
    }
    
    // Check if customer has any accepted requests with this partner
    $customer_requests = get_user_meta($customer_id, 'customer_service_requests', true);
    if (!is_array($customer_requests)) {
        $customer_requests = array();
    }
    
    $has_accepted_request = false;
    $request_id = '';
    
    foreach ($customer_requests as $request) {
        if (isset($request['partner_id']) && intval($request['partner_id']) === intval($partner_id)) {
            if (isset($request['status']) && $request['status'] === 'accepted') {
                $has_accepted_request = true;
                $request_id = isset($request['request_id']) ? $request['request_id'] : '';
                break;
            }
        }
    }
    
    if (!$has_accepted_request) {
        // Also check transients
        global $wpdb;
        $transient_prefix = 'car_accessories_request_';
        $transients = $wpdb->get_col($wpdb->prepare(
            "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s",
            $wpdb->esc_like('_transient_' . $transient_prefix) . '%'
        ));
        
        foreach ($transients as $transient_name) {
            $transient_key = str_replace('_transient_', '', $transient_name);
            $form_data = get_transient($transient_key);
            if ($form_data && isset($form_data['customer_id']) && intval($form_data['customer_id']) === intval($customer_id)) {
                if (isset($form_data['partner_id']) && intval($form_data['partner_id']) === intval($partner_id)) {
                    if (isset($form_data['status']) && $form_data['status'] === 'accepted') {
                        $has_accepted_request = true;
                        $request_id = $transient_key;
                        break;
                    }
                }
            }
        }
    }
    
    if (!$has_accepted_request) {
        return array(
            'eligible' => false,
            'reason' => 'No accepted request found'
        );
    }
    
    // Check message count (minimum 1 message exchanged)
    // For now, we'll use a simple check - if request exists and is accepted, assume messages exist
    // In a full implementation, you'd check actual message count from chat system
    $message_count = 1; // Placeholder - replace with actual message count check
    
    // TODO: Implement actual message count check
    // $message_count = wheelfy_get_message_count($customer_id, $partner_id, $request_id);
    
    if ($message_count < 1) {
        return array(
            'eligible' => false,
            'reason' => 'No messages exchanged'
        );
    }
    
    return array(
        'eligible' => true,
        'request_id' => $request_id,
        'message_count' => $message_count
    );
}

/**
 * Get eligible partners for review (for customer)
 * 
 * @param int $customer_id Customer user ID
 * @return array List of eligible partners
 */
function wheelfy_get_eligible_review_partners($customer_id) {
    $eligible_partners = array();
    $processed_partners = array();
    
    // First, get partners from customer requests (any status, not just accepted)
    $customer_requests = get_user_meta($customer_id, 'customer_service_requests', true);
    if (!is_array($customer_requests)) {
        $customer_requests = array();
    }
    
    foreach ($customer_requests as $request) {
        if (isset($request['partner_id']) && intval($request['partner_id']) > 0) {
            $partner_id = intval($request['partner_id']);
            if (!in_array($partner_id, $processed_partners)) {
                $partner = get_userdata($partner_id);
                if ($partner && in_array('partner', $partner->roles)) {
                    $business_name = get_user_meta($partner_id, 'business_name', true);
                    $partner_name = !empty($business_name) ? $business_name : ($partner->display_name ?: $partner->user_login);
                    
                    $eligible_partners[] = array(
                        'partner_id' => $partner_id,
                        'partner_name' => $partner_name,
                        'partner_email' => $partner->user_email,
                        'request_id' => isset($request['request_id']) ? $request['request_id'] : '',
                        'has_review' => wheelfy_customer_has_reviewed($customer_id, $partner_id)
                    );
                    $processed_partners[] = $partner_id;
                }
            }
        }
    }
    
    // Also check transients
    global $wpdb;
    $transient_prefix = 'car_accessories_request_';
    $transients = $wpdb->get_col($wpdb->prepare(
        "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s",
        $wpdb->esc_like('_transient_' . $transient_prefix) . '%'
    ));
    
    foreach ($transients as $transient_name) {
        $transient_key = str_replace('_transient_', '', $transient_name);
        $form_data = get_transient($transient_key);
        if ($form_data && isset($form_data['customer_id']) && intval($form_data['customer_id']) === intval($customer_id)) {
            if (isset($form_data['partner_id']) && intval($form_data['partner_id']) > 0) {
                $partner_id = intval($form_data['partner_id']);
                if (!in_array($partner_id, $processed_partners)) {
                    $partner = get_userdata($partner_id);
                    if ($partner && in_array('partner', $partner->roles)) {
                        $business_name = get_user_meta($partner_id, 'business_name', true);
                        $partner_name = !empty($business_name) ? $business_name : ($partner->display_name ?: $partner->user_login);
                        
                        $eligible_partners[] = array(
                            'partner_id' => $partner_id,
                            'partner_name' => $partner_name,
                            'partner_email' => $partner->user_email,
                            'request_id' => $transient_key,
                            'has_review' => wheelfy_customer_has_reviewed($customer_id, $partner_id)
                        );
                        $processed_partners[] = $partner_id;
                    }
                }
            }
        }
    }
    
    // Also check chat threads (if customer has chatted with partners)
    $chat_threads = get_user_meta($customer_id, 'wheelfy_chat_threads', true);
    if (is_array($chat_threads)) {
        foreach ($chat_threads as $thread_id => $thread_data) {
            if (isset($thread_data['partner_id']) && intval($thread_data['partner_id']) > 0) {
                $partner_id = intval($thread_data['partner_id']);
                if (!in_array($partner_id, $processed_partners)) {
                    $partner = get_userdata($partner_id);
                    if ($partner && in_array('partner', $partner->roles)) {
                        $business_name = get_user_meta($partner_id, 'business_name', true);
                        $partner_name = !empty($business_name) ? $business_name : ($partner->display_name ?: $partner->user_login);
                        
                        $eligible_partners[] = array(
                            'partner_id' => $partner_id,
                            'partner_name' => $partner_name,
                            'partner_email' => $partner->user_email,
                            'request_id' => '',
                            'has_review' => wheelfy_customer_has_reviewed($customer_id, $partner_id)
                        );
                        $processed_partners[] = $partner_id;
                    }
                }
            }
        }
    }
    
    // If still no partners found, show ALL partners (so customer can at least search and select)
    // This allows the review system to work even if there are no existing relationships
    if (empty($eligible_partners)) {
        $all_partners = get_users(array('role' => 'partner', 'number' => 100));
        foreach ($all_partners as $partner) {
            $partner_id = $partner->ID;
            $business_name = get_user_meta($partner_id, 'business_name', true);
            $partner_name = !empty($business_name) ? $business_name : ($partner->display_name ?: $partner->user_login);
            
            $eligible_partners[] = array(
                'partner_id' => $partner_id,
                'partner_name' => $partner_name,
                'partner_email' => $partner->user_email,
                'request_id' => '',
                'has_review' => wheelfy_customer_has_reviewed($customer_id, $partner_id)
            );
        }
    }
    
    return $eligible_partners;
}

/**
 * AJAX handler to get partner's dynamic rating
 */
function wheelfy_get_partner_rating_ajax() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_nonce')) {
        wp_send_json_error(array('message' => 'Security check failed.'));
        return;
    }
    
    // Get partner ID
    $partner_id = isset($_POST['partner_id']) ? intval($_POST['partner_id']) : 0;
    
    if ($partner_id <= 0) {
        wp_send_json_error(array('message' => 'Invalid partner ID.'));
        return;
    }
    
    // Get dynamic rating
    $rating = wheelfy_get_partner_dynamic_rating($partner_id);
    
    // If no reviews, check stored rating
    if ($rating == 0.0) {
        $stored_rating = get_user_meta($partner_id, 'partner_rating', true);
        if (!empty($stored_rating) && $stored_rating !== '0') {
            $rating = floatval($stored_rating);
        }
    }
    
    wp_send_json_success(array('rating' => $rating));
}
add_action('wp_ajax_wheelfy_get_partner_rating', 'wheelfy_get_partner_rating_ajax');
add_action('wp_ajax_nopriv_wheelfy_get_partner_rating', 'wheelfy_get_partner_rating_ajax');

/**
 * Get partner's dynamic rating from reviews
 * Calculates average rating from approved/published reviews
 * 
 * @param int $partner_id Partner user ID
 * @return float Average rating (0.0 to 5.0), or 0.0 if no reviews
 */
function wheelfy_get_partner_dynamic_rating($partner_id) {
    // Get all reviews received by this partner
    $partner_reviews = get_user_meta($partner_id, 'wheelfy_reviews_received', true);
    if (!is_array($partner_reviews)) {
        $partner_reviews = array();
    }
    
    // Filter to only approved/published reviews (same logic as page-partner-profile.php)
    $approved_reviews = array_filter($partner_reviews, function($review) {
        // If no status, treat as approved (backward compatibility for old reviews)
        if (!isset($review['status'])) {
            return true;
        }
        // Only show approved or published reviews
        $allowed_statuses = array('approved', 'published');
        return in_array($review['status'], $allowed_statuses);
    });
    
    // Calculate average rating
    $avg_rating = 0.0;
    if (!empty($approved_reviews)) {
        $total_rating = array_sum(array_column($approved_reviews, 'rating'));
        $avg_rating = round($total_rating / count($approved_reviews), 1);
    }
    
    return floatval($avg_rating);
}

/**
 * Check if customer has already reviewed a partner
 * 
 * @param int $customer_id Customer user ID
 * @param int $partner_id Partner user ID
 * @return bool|array False if no review, or review data if exists
 */
function wheelfy_customer_has_reviewed($customer_id, $partner_id) {
    $reviews = get_user_meta($customer_id, 'wheelfy_reviews_given', true);
    if (!is_array($reviews)) {
        return false;
    }
    
    foreach ($reviews as $review) {
        if (isset($review['partner_id']) && intval($review['partner_id']) === intval($partner_id)) {
            if (!isset($review['status']) || $review['status'] !== 'cancelled') {
                return $review;
            }
        }
    }
    
    return false;
}

/**
 * Create or update a review
 * 
 * @param int $customer_id Customer user ID
 * @param int $partner_id Partner user ID
 * @param int $rating Rating (1-5)
 * @param string $review_text Review text
 * @param string $review_id Optional review ID for updates
 * @return array|false Review data or false on failure
 */
function wheelfy_create_review($customer_id, $partner_id, $rating, $review_text, $review_id = '') {
    // Validate rating
    $rating = intval($rating);
    if ($rating < 1 || $rating > 5) {
        return false;
    }
    
    // Validate partner exists and is a partner
    $partner = get_userdata($partner_id);
    if (!$partner || !in_array('partner', $partner->roles)) {
        return false;
    }
    
    // Sanitize review text
    $review_text = sanitize_textarea_field($review_text);
    if (empty($review_text)) {
        return false;
    }
    
    // Try to find request_id from customer requests (optional - not required)
    $request_id = '';
    $customer_requests = get_user_meta($customer_id, 'customer_service_requests', true);
    if (is_array($customer_requests)) {
        foreach ($customer_requests as $request) {
            if (isset($request['partner_id']) && intval($request['partner_id']) === intval($partner_id)) {
                $request_id = isset($request['request_id']) ? $request['request_id'] : '';
                break;
            }
        }
    }
    
    // Get or create reviews array
    $reviews = get_user_meta($customer_id, 'wheelfy_reviews_given', true);
    if (!is_array($reviews)) {
        $reviews = array();
    }
    
    $is_update = false;
    $existing_review_index = -1;
    
    // Check if updating existing review
    if (!empty($review_id)) {
        foreach ($reviews as $index => $review) {
            if (isset($review['id']) && $review['id'] === $review_id) {
                // Check if within 72 hours
                if (isset($review['created_at'])) {
                    $created_time = strtotime($review['created_at']);
                    $current_time = current_time('timestamp');
                    $hours_diff = ($current_time - $created_time) / 3600;
                    
                    if ($hours_diff > 72) {
                        return false; // Too old to edit
                    }
                }
                
                $is_update = true;
                $existing_review_index = $index;
                break;
            }
        }
    } else {
        // Check if review already exists for this partner
        foreach ($reviews as $index => $review) {
            if (isset($review['partner_id']) && intval($review['partner_id']) === intval($partner_id)) {
                if (!isset($review['status']) || $review['status'] !== 'cancelled') {
                    return false; // Review already exists
                }
            }
        }
    }
    
    if ($is_update) {
        // Update existing review
        $reviews[$existing_review_index]['rating'] = $rating;
        $reviews[$existing_review_index]['review_text'] = $review_text;
        $reviews[$existing_review_index]['updated_at'] = current_time('mysql');
        $reviews[$existing_review_index]['updated_timestamp'] = current_time('timestamp');
        
        $review_data = $reviews[$existing_review_index];
        
        // Create notification for partner
        do_action('wheelfy_review_updated', $review_data['id'], $customer_id, $partner_id);
    } else {
        // Create new review
        $review_id = 'review_' . time() . '_' . wp_generate_password(8, false);
        
        $review_data = array(
            'id' => $review_id,
            'customer_id' => $customer_id,
            'partner_id' => $partner_id,
            'rating' => $rating,
            'review_text' => $review_text,
            'status' => 'approved', // Auto-approve reviews (admin can still manage from Reviews panel)
            'created_at' => current_time('mysql'),
            'created_timestamp' => current_time('timestamp'),
            'request_id' => $request_id
        );
        
        $reviews[] = $review_data;
        
        // Create notification for partner
        do_action('wheelfy_review_created', $review_id, $customer_id, $partner_id);
    }
    
    // Save reviews
    update_user_meta($customer_id, 'wheelfy_reviews_given', $reviews);
    
    // Also save to partner's received reviews
    $partner_reviews = get_user_meta($partner_id, 'wheelfy_reviews_received', true);
    if (!is_array($partner_reviews)) {
        $partner_reviews = array();
    }
    
    if ($is_update) {
        // Update in partner's reviews
        foreach ($partner_reviews as $index => $preview) {
            if (isset($preview['id']) && $preview['id'] === $review_id) {
                $partner_reviews[$index] = $review_data;
                break;
            }
        }
    } else {
        // Add customer info to review data for partner
        $customer = get_userdata($customer_id);
        $review_data['customer_name'] = $customer ? ($customer->display_name ?: $customer->user_login) : 'Customer';
        $partner_reviews[] = $review_data;
    }
    
    update_user_meta($partner_id, 'wheelfy_reviews_received', $partner_reviews);
    
    return $review_data;
}

/**
 * Cancel/delete a review
 * 
 * @param int $customer_id Customer user ID
 * @param string $review_id Review ID
 * @return bool Success
 */
function wheelfy_cancel_review($customer_id, $review_id) {
    $reviews = get_user_meta($customer_id, 'wheelfy_reviews_given', true);
    if (!is_array($reviews)) {
        return false;
    }
    
    foreach ($reviews as $index => $review) {
        if (isset($review['id']) && $review['id'] === $review_id) {
            // Check if within 72 hours
            if (isset($review['created_at'])) {
                $created_time = strtotime($review['created_at']);
                $current_time = current_time('timestamp');
                $hours_diff = ($current_time - $created_time) / 3600;
                
                if ($hours_diff > 72) {
                    return false; // Too old to cancel
                }
            }
            
            $partner_id = isset($review['partner_id']) ? intval($review['partner_id']) : 0;
            
            // Mark as cancelled
            $reviews[$index]['status'] = 'cancelled';
            $reviews[$index]['cancelled_at'] = current_time('mysql');
            
            update_user_meta($customer_id, 'wheelfy_reviews_given', $reviews);
            
            // Remove from partner's received reviews
            if ($partner_id > 0) {
                $partner_reviews = get_user_meta($partner_id, 'wheelfy_reviews_received', true);
                if (is_array($partner_reviews)) {
                    foreach ($partner_reviews as $pindex => $preview) {
                        if (isset($preview['id']) && $preview['id'] === $review_id) {
                            $partner_reviews[$pindex]['status'] = 'cancelled';
                            $partner_reviews[$pindex]['cancelled_at'] = current_time('mysql');
                            update_user_meta($partner_id, 'wheelfy_reviews_received', $partner_reviews);
                            break;
                        }
                    }
                }
                
                // Create notification for partner
                do_action('wheelfy_review_cancelled', $review_id, $customer_id, $partner_id);
            }
            
            return true;
        }
    }
    
    return false;
}

/**
 * Get customer reviews
 * 
 * @param int $customer_id Customer user ID
 * @return array Reviews array
 */
function wheelfy_get_customer_reviews($customer_id) {
    $reviews = get_user_meta($customer_id, 'wheelfy_reviews_given', true);
    if (!is_array($reviews)) {
        return array();
    }
    
    // Filter out cancelled reviews
    $active_reviews = array_filter($reviews, function($review) {
        return !isset($review['status']) || $review['status'] !== 'cancelled';
    });
    
    return array_values($active_reviews);
}

/**
 * Get partner reviews
 * 
 * @param int $partner_id Partner user ID
 * @return array Reviews array
 */
function wheelfy_get_partner_reviews($partner_id) {
    $reviews = get_user_meta($partner_id, 'wheelfy_reviews_received', true);
    if (!is_array($reviews)) {
        return array();
    }
    
    // Filter out cancelled reviews
    $active_reviews = array_filter($reviews, function($review) {
        return !isset($review['status']) || $review['status'] !== 'cancelled';
    });
    
    return array_values($active_reviews);
}

/**
 * Get partner reviews count (approved, published, and pending reviews)
 * 
 * @param int $partner_id Partner user ID
 * @return int Count of visible reviews
 */
function wheelfy_get_partner_reviews_count($partner_id) {
    $reviews = get_user_meta($partner_id, 'wheelfy_reviews_received', true);
    if (!is_array($reviews)) {
        return 0;
    }
    
    // Count reviews that should be displayed (exclude cancelled, rejected only)
    $visible_reviews = array_filter($reviews, function($review) {
        // If no status, treat as approved (backward compatibility)
        if (!isset($review['status'])) {
            return true;
        }
        // Show approved, published, and pending reviews
        $allowed_statuses = array('approved', 'published', 'pending');
        return in_array($review['status'], $allowed_statuses);
    });
    
    return count($visible_reviews);
}

// Note: wheelfy_get_partner_response_rate is defined later in this file (more comprehensive version)

/**
 * Auto-approve all pending reviews (run once to fix existing reviews)
 * Can be triggered via: ?wheelfy_fix_reviews=1 (admin only)
 */
function wheelfy_auto_approve_pending_reviews() {
    if (!isset($_GET['wheelfy_fix_reviews']) || !current_user_can('manage_options')) {
        return;
    }
    
    // Get all users with reviews given
    $customers = get_users(array(
        'role' => 'customer',
        'meta_key' => 'wheelfy_reviews_given',
        'meta_compare' => 'EXISTS'
    ));
    
    $updated_count = 0;
    
    foreach ($customers as $customer) {
        $reviews = get_user_meta($customer->ID, 'wheelfy_reviews_given', true);
        if (!is_array($reviews)) {
            continue;
        }
        
        $updated = false;
        foreach ($reviews as $index => $review) {
            if (isset($review['status']) && $review['status'] === 'pending') {
                $reviews[$index]['status'] = 'approved';
                $updated = true;
                $updated_count++;
                
                // Also update partner's received reviews
                $partner_id = isset($review['partner_id']) ? intval($review['partner_id']) : 0;
                if ($partner_id > 0) {
                    $partner_reviews = get_user_meta($partner_id, 'wheelfy_reviews_received', true);
                    if (is_array($partner_reviews)) {
                        foreach ($partner_reviews as $pindex => $preview) {
                            if (isset($preview['id']) && isset($review['id']) && $preview['id'] === $review['id']) {
                                $partner_reviews[$pindex]['status'] = 'approved';
                                update_user_meta($partner_id, 'wheelfy_reviews_received', $partner_reviews);
                                break;
                            }
                        }
                    }
                }
            }
        }
        
        if ($updated) {
            update_user_meta($customer->ID, 'wheelfy_reviews_given', $reviews);
        }
    }
    
    // Show message and stop
    wp_die('Reviews fixed! ' . $updated_count . ' pending reviews have been approved. <a href="' . home_url() . '">Go back</a>');
}
add_action('init', 'wheelfy_auto_approve_pending_reviews', 1);

/**
 * AJAX: Get eligible partners for review
 */
function wheelfy_ajax_get_eligible_partners() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_nonce')) {
        wp_send_json_error(array('message' => 'Security check failed.'));
    }
    
    // Check if user is logged in
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'You must be logged in.'));
    }
    
    $user_id = get_current_user_id();
    $current_user = wp_get_current_user();
    
    if (!in_array('customer', $current_user->roles)) {
        wp_send_json_error(array('message' => 'Only customers can review partners.'));
    }
    
    $search_term = isset($_POST['search']) ? sanitize_text_field($_POST['search']) : '';
    
    $eligible_partners = wheelfy_get_eligible_review_partners($user_id);
    
    // Filter by search term if provided
    if (!empty($search_term)) {
        $eligible_partners = array_filter($eligible_partners, function($partner) use ($search_term) {
            return stripos($partner['partner_name'], $search_term) !== false;
        });
    }
    
    wp_send_json_success(array('partners' => array_values($eligible_partners)));
}
add_action('wp_ajax_get_eligible_partners', 'wheelfy_ajax_get_eligible_partners');

/**
 * AJAX: Create or update review
 */
function wheelfy_ajax_create_review() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_nonce')) {
        wp_send_json_error(array('message' => 'Security check failed.'));
    }
    
    // Check if user is logged in
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'You must be logged in.'));
    }
    
    $user_id = get_current_user_id();
    $current_user = wp_get_current_user();
    
    if (!in_array('customer', $current_user->roles)) {
        wp_send_json_error(array('message' => 'Only customers can create reviews.'));
    }
    
    $partner_id = isset($_POST['partner_id']) ? intval($_POST['partner_id']) : 0;
    $rating = isset($_POST['rating']) ? intval($_POST['rating']) : 0;
    $review_text = isset($_POST['review_text']) ? sanitize_textarea_field($_POST['review_text']) : '';
    $review_id = isset($_POST['review_id']) ? sanitize_text_field($_POST['review_id']) : '';
    
    if (empty($partner_id) || empty($rating) || empty($review_text)) {
        wp_send_json_error(array('message' => 'Missing required fields.'));
    }
    
    $review_data = wheelfy_create_review($user_id, $partner_id, $rating, $review_text, $review_id);
    
    if ($review_data) {
        wp_send_json_success(array(
            'message' => empty($review_id) ? 'Review created successfully.' : 'Review updated successfully.',
            'review' => $review_data
        ));
    } else {
        wp_send_json_error(array('message' => 'You already gave a review.'));
    }
}
add_action('wp_ajax_create_review', 'wheelfy_ajax_create_review');

/**
 * AJAX: Cancel review
 */
function wheelfy_ajax_cancel_review() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_nonce')) {
        wp_send_json_error(array('message' => 'Security check failed.'));
    }
    
    // Check if user is logged in
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'You must be logged in.'));
    }
    
    $user_id = get_current_user_id();
    $current_user = wp_get_current_user();
    
    if (!in_array('customer', $current_user->roles)) {
        wp_send_json_error(array('message' => 'Only customers can cancel reviews.'));
    }
    
    $review_id = isset($_POST['review_id']) ? sanitize_text_field($_POST['review_id']) : '';
    
    if (empty($review_id)) {
        wp_send_json_error(array('message' => 'Review ID is required.'));
    }
    
    $success = wheelfy_cancel_review($user_id, $review_id);
    
    if ($success) {
        wp_send_json_success(array('message' => 'Review cancelled successfully.'));
    } else {
        wp_send_json_error(array('message' => 'Failed to cancel review. Review may be older than 72 hours.'));
    }
}
add_action('wp_ajax_cancel_review', 'wheelfy_ajax_cancel_review');

/**
 * AJAX: Get customer reviews
 */
function wheelfy_ajax_get_customer_reviews() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_nonce')) {
        wp_send_json_error(array('message' => 'Security check failed.'));
    }
    
    // Check if user is logged in
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'You must be logged in.'));
    }
    
    $user_id = get_current_user_id();
    $reviews = wheelfy_get_customer_reviews($user_id);
    
    // Enrich reviews with partner info
    foreach ($reviews as &$review) {
        if (isset($review['partner_id'])) {
            $partner = get_userdata($review['partner_id']);
            if ($partner) {
                $business_name = get_user_meta($review['partner_id'], 'business_name', true);
                $review['partner_name'] = !empty($business_name) ? $business_name : ($partner->display_name ?: $partner->user_login);
                $review['partner_email'] = $partner->user_email;
            }
        }
        
        // Calculate if review is editable (within 72 hours)
        if (isset($review['created_timestamp'])) {
            $current_time = current_time('timestamp');
            $hours_diff = ($current_time - $review['created_timestamp']) / 3600;
            $review['is_editable'] = $hours_diff <= 72;
            $review['is_locked'] = $hours_diff > 72;
        } else {
            $review['is_editable'] = false;
            $review['is_locked'] = true;
        }
    }
    
    wp_send_json_success(array('reviews' => $reviews));
}
add_action('wp_ajax_get_customer_reviews', 'wheelfy_ajax_get_customer_reviews');

/**
 * Create notification when review is created
 */
function wheelfy_notify_review_created($review_id, $customer_id, $partner_id) {
    $customer = get_userdata($customer_id);
    $customer_name = $customer ? ($customer->display_name ?: $customer->user_login) : 'Customer';
    
    wheelfy_create_notification(
        $partner_id,
        'review',
        'New Review Received',
        sprintf('You received a new review from %s.', $customer_name),
        array(
            'link' => home_url('/partner-dashboard#reviews'),
            'icon' => 'star',
            'action_text' => 'View Review',
            'related_id' => $review_id,
            'customer_name' => $customer_name
        )
    );
}
add_action('wheelfy_review_created', 'wheelfy_notify_review_created', 10, 3);

/**
 * Create notification when review is updated
 */
function wheelfy_notify_review_updated($review_id, $customer_id, $partner_id) {
    $customer = get_userdata($customer_id);
    $customer_name = $customer ? ($customer->display_name ?: $customer->user_login) : 'Customer';
    
    wheelfy_create_notification(
        $partner_id,
        'review',
        'Review Updated',
        sprintf('%s updated their review.', $customer_name),
        array(
            'link' => home_url('/partner-dashboard#reviews'),
            'icon' => 'star',
            'action_text' => 'View Review',
            'related_id' => $review_id
        )
    );
}
add_action('wheelfy_review_updated', 'wheelfy_notify_review_updated', 10, 3);

/**
 * Create notification when review is cancelled
 */
function wheelfy_notify_review_cancelled($review_id, $customer_id, $partner_id) {
    $customer = get_userdata($customer_id);
    $customer_name = $customer ? ($customer->display_name ?: $customer->user_login) : 'Customer';
    
    wheelfy_create_notification(
        $partner_id,
        'review',
        'Review Cancelled',
        sprintf('%s cancelled their review.', $customer_name),
        array(
            'link' => home_url('/partner-dashboard#reviews'),
            'icon' => 'star',
            'action_text' => 'View Reviews',
            'related_id' => $review_id
        )
    );
}
add_action('wheelfy_review_cancelled', 'wheelfy_notify_review_cancelled', 10, 3);

/**
 * ============================================================================
 * MESSAGING SYSTEM
 * ============================================================================
 * Real-time messaging system between customers and partners
 */

/**
 * Check if chat is allowed between customer and partner
 * 
 * @param int $customer_id Customer user ID
 * @param int $partner_id Partner user ID
 * @return array Eligibility status and thread ID
 */
function wheelfy_check_chat_eligibility($customer_id, $partner_id) {
    if (empty($customer_id) || empty($partner_id)) {
        return array(
            'allowed' => false,
            'reason' => 'Invalid user IDs'
        );
    }
    
    // Check if customer has any accepted requests with this partner
    $customer_requests = get_user_meta($customer_id, 'customer_service_requests', true);
    if (!is_array($customer_requests)) {
        $customer_requests = array();
    }
    
    $has_accepted_request = false;
    $request_id = '';
    
    foreach ($customer_requests as $request) {
        if (isset($request['partner_id']) && intval($request['partner_id']) === intval($partner_id)) {
            if (isset($request['status']) && $request['status'] === 'accepted') {
                $has_accepted_request = true;
                $request_id = isset($request['request_id']) ? $request['request_id'] : '';
                break;
            }
        }
    }
    
    if (!$has_accepted_request) {
        // Also check transients
        global $wpdb;
        $transient_prefix = 'car_accessories_request_';
        $transients = $wpdb->get_col($wpdb->prepare(
            "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s",
            $wpdb->esc_like('_transient_' . $transient_prefix) . '%'
        ));
        
        foreach ($transients as $transient_name) {
            $transient_key = str_replace('_transient_', '', $transient_name);
            $form_data = get_transient($transient_key);
            if ($form_data && isset($form_data['customer_id']) && intval($form_data['customer_id']) === intval($customer_id)) {
                if (isset($form_data['partner_id']) && intval($form_data['partner_id']) === intval($partner_id)) {
                    if (isset($form_data['status']) && $form_data['status'] === 'accepted') {
                        $has_accepted_request = true;
                        $request_id = $transient_key;
                        break;
                    }
                }
            }
        }
    }
    
    if (!$has_accepted_request) {
        return array(
            'allowed' => false,
            'reason' => 'No accepted request found'
        );
    }
    
    // Get or create thread ID
    $thread_id = wheelfy_get_or_create_thread($customer_id, $partner_id, $request_id);
    
    return array(
        'allowed' => true,
        'thread_id' => $thread_id,
        'request_id' => $request_id
    );
}

/**
 * Check if chat is read-only (request completed)
 * 
 * @param string $thread_id Thread ID
 * @param array $thread Thread data (optional, will be fetched if not provided)
 * @return bool True if chat is read-only
 */
function wheelfy_is_chat_read_only($thread_id, $thread = null) {
    if (!$thread) {
        $thread = get_option('wheelfy_thread_' . $thread_id, false);
    }
    
    if (!$thread) {
        return false;
    }
    
    $customer_id = isset($thread['customer_id']) ? intval($thread['customer_id']) : 0;
    $partner_id = isset($thread['partner_id']) ? intval($thread['partner_id']) : 0;
    $request_id = isset($thread['request_id']) ? $thread['request_id'] : '';
    
    if (empty($customer_id) || empty($partner_id)) {
        return false;
    }
    
    // Check customer's requests for completed status
    $customer_requests = get_user_meta($customer_id, 'customer_service_requests', true);
    if (is_array($customer_requests)) {
        foreach ($customer_requests as $req) {
            // Match by partner_id
            if (isset($req['partner_id']) && intval($req['partner_id']) === $partner_id) {
                // Check if request is completed
                if (isset($req['status']) && ($req['status'] === 'complete' || $req['status'] === 'completed')) {
                    // Only mark as read-only if it's a v2 workflow request
                    if (isset($req['workflow_version']) && $req['workflow_version'] === 'v2') {
                        return true;
                    }
                }
            }
        }
    }
    
    // Also check transient if request_id is available
    if (!empty($request_id)) {
        $transient_key = 'car_accessories_request_' . $request_id . '_partner_' . $partner_id;
        $form_data = get_transient($transient_key);
        if ($form_data && is_array($form_data)) {
            if (isset($form_data['status']) && ($form_data['status'] === 'complete' || $form_data['status'] === 'completed')) {
                if (isset($form_data['workflow_version']) && $form_data['workflow_version'] === 'v2') {
                    return true;
                }
            }
        }
    }
    
    return false;
}

/**
 * Get or create a chat thread
 * 
 * @param int $customer_id Customer user ID
 * @param int $partner_id Partner user ID
 * @param string $request_id Request ID
 * @return string Thread ID
 */
function wheelfy_get_or_create_thread($customer_id, $partner_id, $request_id = '') {
    // Generate consistent thread ID
    $user_ids = array($customer_id, $partner_id);
    sort($user_ids);
    $thread_id = 'thread_' . $user_ids[0] . '_' . $user_ids[1];
    
    // Check if thread exists
    $thread = get_option('wheelfy_thread_' . $thread_id, false);
    
    if (!$thread) {
        // Create new thread
        $thread_data = array(
            'thread_id' => $thread_id,
            'customer_id' => $customer_id,
            'partner_id' => $partner_id,
            'request_id' => $request_id,
            'created_at' => current_time('mysql'),
            'created_timestamp' => current_time('timestamp'),
            'last_message_at' => current_time('mysql'),
            'last_message_timestamp' => current_time('timestamp')
        );
        
        update_option('wheelfy_thread_' . $thread_id, $thread_data);
        
        // Add to user's thread lists
        $customer_threads = get_user_meta($customer_id, 'wheelfy_chat_threads', true);
        if (!is_array($customer_threads)) {
            $customer_threads = array();
        }
        if (!in_array($thread_id, $customer_threads)) {
            $customer_threads[] = $thread_id;
            update_user_meta($customer_id, 'wheelfy_chat_threads', $customer_threads);
        }
        
        $partner_threads = get_user_meta($partner_id, 'wheelfy_chat_threads', true);
        if (!is_array($partner_threads)) {
            $partner_threads = array();
        }
        if (!in_array($thread_id, $partner_threads)) {
            $partner_threads[] = $thread_id;
            update_user_meta($partner_id, 'wheelfy_chat_threads', $partner_threads);
        }
    }
    
    return $thread_id;
}

/**
 * Send a message
 * 
 * @param string $thread_id Thread ID
 * @param int $sender_id Sender user ID
 * @param string $message_text Message text
 * @param array $attachments Attachment file IDs
 * @return array|false Message data or false on failure
 */
function wheelfy_send_message($thread_id, $sender_id, $message_text, $attachments = array(), $parent_message_id = null) {
    // Verify thread exists and user is part of it
    $thread = get_option('wheelfy_thread_' . $thread_id, false);
    if (!$thread) {
        return false;
    }
    
    if ($thread['customer_id'] != $sender_id && $thread['partner_id'] != $sender_id) {
        return false; // User not part of this thread
    }
    
    // Check if chat is read-only (request completed)
    if (wheelfy_is_chat_read_only($thread_id, $thread)) {
        return array('error' => 'read_only', 'message' => __('This chat is read-only. The request has been completed.', 'wheelfy'));
    }
    
    // Sanitize message text
    $message_text = sanitize_textarea_field($message_text);
    
    // Security: Validate message for contact information (email, phone, etc.)
    // This is a second layer of protection in case AJAX handler validation is bypassed
    if (!empty($message_text) && function_exists('wheelfy_validate_chat_message')) {
        $validation = wheelfy_validate_chat_message($message_text, $sender_id, $thread_id, true);
        if (!$validation['valid']) {
            return false; // Block message with contact information
        }
    }
    
    // Validate parent_message_id if provided (must exist in the same thread)
    if (!empty($parent_message_id)) {
        $messages = get_option('wheelfy_messages_' . $thread_id, array());
        if (!is_array($messages)) {
            $messages = array();
        }
        $parent_exists = false;
        foreach ($messages as $msg) {
            if (isset($msg['id']) && $msg['id'] === $parent_message_id) {
                $parent_exists = true;
                break;
            }
        }
        if (!$parent_exists) {
            $parent_message_id = null; // Invalid parent, treat as normal message
        }
    }
    
    // Get messages for this thread
    $messages = get_option('wheelfy_messages_' . $thread_id, array());
    if (!is_array($messages)) {
        $messages = array();
    }
    
    // Create message
    $message_id = 'msg_' . time() . '_' . wp_generate_password(8, false);
    $message_data = array(
        'id' => $message_id,
        'thread_id' => $thread_id,
        'sender_id' => $sender_id,
        'message_text' => $message_text,
        'attachments' => $attachments,
        'parent_message_id' => $parent_message_id, // NULL for normal messages, message_id for replies
        'status' => 'sent',
        'read' => false,
        'is_deleted' => false,
        'deleted_at' => null,
        'created_at' => current_time('mysql'),
        'created_timestamp' => current_time('timestamp')
    );
    
    $messages[] = $message_data;
    
    // Save messages
    update_option('wheelfy_messages_' . $thread_id, $messages);
    
    // Update thread last message time
    $thread['last_message_at'] = current_time('mysql');
    $thread['last_message_timestamp'] = current_time('timestamp');
    $thread['last_message_id'] = $message_id;
    update_option('wheelfy_thread_' . $thread_id, $thread);
    
    // Determine recipient
    $recipient_id = ($sender_id == $thread['customer_id']) ? $thread['partner_id'] : $thread['customer_id'];
    
    // Create notification for recipient
    do_action('wheelfy_message_sent', $message_id, $thread_id, $sender_id, $recipient_id);
    
    return $message_data;
}

/**
 * Get messages for a thread
 * 
 * @param string $thread_id Thread ID
 * @param int $user_id User ID (for read receipts)
 * @param int $limit Limit number of messages
 * @return array Messages array
 */
function wheelfy_get_thread_messages($thread_id, $user_id, $limit = 100) {
    $messages = get_option('wheelfy_messages_' . $thread_id, array());
    if (!is_array($messages)) {
        return array();
    }
    
    // Mark messages as read for this user
    foreach ($messages as &$msg) {
        if ($msg['sender_id'] != $user_id && !$msg['read']) {
            $msg['read'] = true;
            $msg['read_at'] = current_time('mysql');
        }
    }
    update_option('wheelfy_messages_' . $thread_id, $messages);
    
    // Get last N messages
    if ($limit > 0 && count($messages) > $limit) {
        $messages = array_slice($messages, -$limit);
    }
    
    return $messages;
}

/**
 * Get user's conversation list
 * 
 * @param int $user_id User ID
 * @return array Conversations array
 */
function wheelfy_get_user_conversations($user_id) {
    $thread_ids = get_user_meta($user_id, 'wheelfy_chat_threads', true);
    if (!is_array($thread_ids)) {
        return array();
    }
    
    // Get deleted conversations for this user
    $deleted_conversations = get_user_meta($user_id, 'wheelfy_deleted_conversations', true);
    if (!is_array($deleted_conversations)) {
        $deleted_conversations = array();
    }
    
    $conversations = array();
    
    foreach ($thread_ids as $thread_id) {
        // Skip deleted conversations (unless there's a new message)
        if (in_array($thread_id, $deleted_conversations)) {
            // Check if there's a new message from the other user after deletion
            $thread = get_option('wheelfy_thread_' . $thread_id, false);
            if ($thread && isset($thread['last_message_timestamp'])) {
                $deleted_meta = get_user_meta($user_id, 'wheelfy_deleted_conversations_timestamps', true);
                if (!is_array($deleted_meta)) {
                    $deleted_meta = array();
                }
                $deleted_timestamp = isset($deleted_meta[$thread_id]) ? $deleted_meta[$thread_id] : 0;
                // If last message is newer than deletion, show conversation again
                if ($thread['last_message_timestamp'] <= $deleted_timestamp) {
                    continue; // Still deleted, skip
                }
                // New message received, remove from deleted list
                $deleted_conversations = array_diff($deleted_conversations, array($thread_id));
                update_user_meta($user_id, 'wheelfy_deleted_conversations', $deleted_conversations);
            } else {
                continue; // No thread or no new messages, skip
            }
        }
        
        $thread = get_option('wheelfy_thread_' . $thread_id, false);
        if (!$thread) {
            continue;
        }
        
        // Determine other user
        $other_user_id = ($user_id == $thread['customer_id']) ? $thread['partner_id'] : $thread['customer_id'];
        $other_user = get_userdata($other_user_id);
        
        if (!$other_user) {
            continue;
        }
        
        // Get other user's name
        if ($other_user_id == $thread['partner_id']) {
            $business_name = get_user_meta($other_user_id, 'business_name', true);
            $other_user_name = !empty($business_name) ? $business_name : ($other_user->display_name ?: $other_user->user_login);
        } else {
            $other_user_name = $other_user->display_name ?: $other_user->user_login;
        }
        
        // Get profile image
        $profile_image_id = get_user_meta($other_user_id, 'profile_image_id', true);
        $other_user_avatar = '';
        if ($profile_image_id && is_numeric($profile_image_id)) {
            $other_user_avatar = wp_get_attachment_image_url($profile_image_id, 'thumbnail');
        } else {
            // Fall back to Gravatar
            $other_user_avatar = get_avatar_url($other_user_id, array('size' => 96));
        }
        
        // Get last message (skip deleted messages)
        $messages = get_option('wheelfy_messages_' . $thread_id, array());
        $last_message = null;
        if (!empty($messages)) {
            // Find last non-deleted message
            for ($i = count($messages) - 1; $i >= 0; $i--) {
                $msg = $messages[$i];
                if (!isset($msg['is_deleted']) || !$msg['is_deleted']) {
                    $last_message = $msg;
                    break;
                }
            }
        }
        
        // Count unread messages (excluding deleted)
        $unread_count = 0;
        if ($last_message) {
            foreach ($messages as $msg) {
                if (isset($msg['is_deleted']) && $msg['is_deleted']) {
                    continue; // Skip deleted messages
                }
                if ($msg['sender_id'] != $user_id && !$msg['read']) {
                    $unread_count++;
                }
            }
        }
        
        $conversations[] = array(
            'thread_id' => $thread_id,
            'other_user_id' => $other_user_id,
            'other_user_name' => $other_user_name,
            'other_user_email' => $other_user->user_email,
            'other_user_avatar' => $other_user_avatar,
            'last_message' => $last_message ? array(
                'text' => (isset($last_message['is_deleted']) && $last_message['is_deleted']) ? 'This message was deleted' : wp_trim_words($last_message['message_text'], 20),
                'timestamp' => $last_message['created_timestamp'],
                'sender_id' => $last_message['sender_id']
            ) : null,
            'last_message_time' => isset($thread['last_message_timestamp']) ? $thread['last_message_timestamp'] : 0,
            'unread_count' => $unread_count
        );
    }
    
    // Sort by last message time (newest first)
    usort($conversations, function($a, $b) {
        return $b['last_message_time'] - $a['last_message_time'];
    });
    
    return $conversations;
}

/**
 * Get count of unique users who have sent messages to a user
 * 
 * @param int $user_id User ID
 * @return int Count of unique senders
 */
function wheelfy_get_messages_received_count($user_id) {
    $thread_ids = get_user_meta($user_id, 'wheelfy_chat_threads', true);
    if (!is_array($thread_ids) || empty($thread_ids)) {
        return 0;
    }
    
    // Get deleted conversations for this user
    $deleted_conversations = get_user_meta($user_id, 'wheelfy_deleted_conversations', true);
    if (!is_array($deleted_conversations)) {
        $deleted_conversations = array();
    }
    
    $unique_senders = array();
    
    foreach ($thread_ids as $thread_id) {
        // Skip deleted conversations
        if (in_array($thread_id, $deleted_conversations)) {
            // Check if there's a new message from the other user after deletion
            $thread = get_option('wheelfy_thread_' . $thread_id, false);
            if ($thread && isset($thread['last_message_timestamp'])) {
                $deleted_meta = get_user_meta($user_id, 'wheelfy_deleted_conversations_timestamps', true);
                if (!is_array($deleted_meta)) {
                    $deleted_meta = array();
                }
                $deleted_timestamp = isset($deleted_meta[$thread_id]) ? $deleted_meta[$thread_id] : 0;
                // If last message is newer than deletion, include conversation again
                if ($thread['last_message_timestamp'] <= $deleted_timestamp) {
                    continue; // Still deleted, skip
                }
                // New message received, conversation is active again
            } else {
                continue; // No thread or no new messages, skip
            }
        }
        
        $thread = get_option('wheelfy_thread_' . $thread_id, false);
        if (!$thread) {
            continue;
        }
        
        // Get all messages for this thread
        $messages = get_option('wheelfy_messages_' . $thread_id, array());
        if (!is_array($messages)) {
            continue;
        }
        
        // Collect unique sender IDs (messages received, not sent)
        foreach ($messages as $msg) {
            if (isset($msg['sender_id']) && intval($msg['sender_id']) != intval($user_id)) {
                $sender_id = intval($msg['sender_id']);
                if ($sender_id > 0 && !in_array($sender_id, $unique_senders)) {
                    $unique_senders[] = $sender_id;
                }
            }
        }
    }
    
    return count($unique_senders);
}

/**
 * Get total reviews count given by a customer
 * 
 * @param int $customer_id Customer user ID
 * @return int Total count of reviews given
 */
function wheelfy_get_customer_reviews_count($customer_id) {
    $reviews_given = get_user_meta($customer_id, 'wheelfy_reviews_given', true);
    if (!is_array($reviews_given) || empty($reviews_given)) {
        return 0;
    }
    
    $count = 0;
    foreach ($reviews_given as $review) {
        // Only count reviews that are not cancelled
        if (!isset($review['status']) || $review['status'] !== 'cancelled') {
            $count++;
        }
    }
    
    return $count;
}

/**
 * Get active service requests count for a customer
 * 
 * @param int $customer_id Customer user ID
 * @return int Total count of accepted/approved requests
 */
function wheelfy_get_active_requests_count($customer_id) {
    $active_statuses = array('accepted');
    $total_active = 0;
    $processed_request_ids = array();
    
    // Query 1: Get requests from posts (proposals) created by customer
    $proposal_args = array(
        'post_type' => 'post',
        'author' => $customer_id,
        'posts_per_page' => -1,
        'meta_query' => array(
            array(
                'key' => '_proposal_status',
                'compare' => 'EXISTS'
            )
        ),
        'orderby' => 'date',
        'order' => 'DESC'
    );
    
    $proposal_posts = get_posts($proposal_args);
    foreach ($proposal_posts as $post) {
        $partner_id = get_post_meta($post->ID, 'partner_id', true) ?: 0;
        
        // Only count requests where a partner has been assigned
        if ($partner_id <= 0) {
            continue;
        }
        
        $status = get_post_meta($post->ID, '_proposal_status', true) ?: 'pending';
        if (in_array($status, $active_statuses)) {
            $request_id = 'post_' . $post->ID;
            $processed_request_ids[] = $request_id;
            $total_active++;
        }
    }
    
    // Query 2: Get requests from user meta (permanent storage)
    $saved_requests = get_user_meta($customer_id, 'customer_service_requests', true);
    if (is_array($saved_requests) && !empty($saved_requests)) {
        foreach ($saved_requests as $saved_request) {
            if (!isset($saved_request['request_id']) || !isset($saved_request['partner_id'])) {
                continue;
            }
            
            // Only count requests where a partner has been assigned
            $partner_id = intval($saved_request['partner_id']);
            if ($partner_id <= 0) {
                continue;
            }
            
            $request_id = isset($saved_request['request_id']) ? $saved_request['request_id'] : '';
            $request_key = $request_id . '_partner_' . $partner_id;
            
            // Skip if already counted from posts
            if (in_array($request_id, $processed_request_ids) || in_array($request_key, $processed_request_ids)) {
                continue;
            }
            
            $status = isset($saved_request['status']) ? $saved_request['status'] : 'pending';
            if (in_array($status, $active_statuses)) {
                $total_active++;
                $processed_request_ids[] = $request_key;
            }
        }
    }
    
    // Query 3: Also check transients (recent form submissions with partner assigned)
    // IMPORTANT: Only count transients that belong to this specific customer
    global $wpdb;
    $transient_prefix = '_transient_car_accessories_request_';
    $transient_timeout_prefix = '_transient_timeout_car_accessories_request_';
    
    // Get customer email and ID for matching
    $customer = get_userdata($customer_id);
    $customer_email = $customer ? $customer->user_email : '';
    
    $transient_keys = $wpdb->get_col($wpdb->prepare(
        "SELECT option_name FROM {$wpdb->options} 
        WHERE (option_name LIKE %s OR option_name LIKE %s)
        AND option_name NOT LIKE %s
        ORDER BY option_id DESC",
        $transient_prefix . '%',
        $transient_prefix . '%_partner_%',
        $transient_timeout_prefix . '%'
    ));
    
    foreach ($transient_keys as $transient_key) {
        $key_part = str_replace($transient_prefix, '', $transient_key);
        if (strpos($key_part, '_partner_') !== false) {
            $parts = explode('_partner_', $key_part);
            $request_id = $parts[0];
            $partner_id = isset($parts[1]) ? intval($parts[1]) : 0;
            $form_data = get_transient('car_accessories_request_' . $request_id . '_partner_' . $partner_id);
        } else {
            $request_id = $key_part;
            $form_data = get_transient('car_accessories_request_' . $request_id);
            $partner_id = isset($form_data['partner_id']) ? intval($form_data['partner_id']) : 0;
        }
        
        if ($form_data && isset($form_data['timestamp'])) {
            // CRITICAL: Only count if this request belongs to the current customer
            $form_email = isset($form_data['email']) ? strtolower(trim($form_data['email'])) : '';
            $form_user_id = isset($form_data['user_id']) ? intval($form_data['user_id']) : 0;
            
            // Skip if email doesn't match and user_id doesn't match
            if (!empty($customer_email) && !empty($form_email)) {
                if (strtolower(trim($customer_email)) !== $form_email) {
                    continue; // Not this customer's request
                }
            } elseif ($form_user_id > 0 && $form_user_id !== $customer_id) {
                continue; // Not this customer's request
            } elseif (empty($form_email) && $form_user_id <= 0) {
                continue; // Cannot verify ownership, skip
            }
            
            $request_key = $request_id . '_partner_' . $partner_id;
            
            // Skip if already counted from posts or user meta
            if (in_array($request_id, $processed_request_ids) || in_array($request_key, $processed_request_ids)) {
                continue;
            }
            
            // Only count if partner is assigned
            if ($partner_id > 0) {
                $status = isset($form_data['status']) ? $form_data['status'] : 'pending';
                if (in_array($status, $active_statuses)) {
                    $total_active++;
                    $processed_request_ids[] = $request_key;
                }
            }
        }
    }
    
    return $total_active;
}

/**
 * Get pending service requests count for a customer
 * 
 * @param int $customer_id Customer user ID
 * @return int Total count of pending requests
 */
function wheelfy_get_pending_requests_count($customer_id) {
    $pending_status = 'pending';
    $total_pending = 0;
    $processed_request_keys = array(); // For Query 2/3 duplicate detection
    
    // Query 1: Get requests from posts (proposals) created by customer
    $proposal_args = array(
        'post_type' => 'post',
        'author' => $customer_id,
        'posts_per_page' => -1,
        'meta_query' => array(
            array(
                'key' => '_proposal_status',
                'compare' => 'EXISTS'
            )
        ),
        'orderby' => 'date',
        'order' => 'DESC'
    );
    
    $proposal_posts = get_posts($proposal_args);
    foreach ($proposal_posts as $post) {
        $partner_id = get_post_meta($post->ID, 'partner_id', true) ?: 0;
        
        // Only count requests where a partner has been assigned
        if ($partner_id <= 0) {
            continue;
        }
        
        $status = get_post_meta($post->ID, '_proposal_status', true) ?: 'pending';
        if ($status === $pending_status) {
            $total_pending++;
        }
    }
    
    // Query 2: Get requests from user meta (permanent storage)
    $saved_requests = get_user_meta($customer_id, 'customer_service_requests', true);
    if (is_array($saved_requests) && !empty($saved_requests)) {
        foreach ($saved_requests as $saved_request) {
            if (!isset($saved_request['request_id']) || !isset($saved_request['partner_id'])) {
                continue;
            }
            
            // Only count requests where a partner has been assigned
            $partner_id = intval($saved_request['partner_id']);
            if ($partner_id <= 0) {
                continue;
            }
            
            $request_id = isset($saved_request['request_id']) ? $saved_request['request_id'] : '';
            $request_key = $request_id . '_partner_' . $partner_id;
            $processed_request_keys[] = $request_key;
            
            $status = isset($saved_request['status']) ? $saved_request['status'] : 'pending';
            if ($status === $pending_status) {
                $total_pending++;
            }
        }
    }
    
    // Query 3: Also check transients (recent form submissions with partner assigned)
    // IMPORTANT: Only count transients that belong to this specific customer
    global $wpdb;
    $transient_prefix = '_transient_car_accessories_request_';
    $transient_timeout_prefix = '_transient_timeout_car_accessories_request_';
    
    // Get customer email and ID for matching
    $customer = get_userdata($customer_id);
    $customer_email = $customer ? $customer->user_email : '';
    
    $transient_keys = $wpdb->get_col($wpdb->prepare(
        "SELECT option_name FROM {$wpdb->options} 
        WHERE (option_name LIKE %s OR option_name LIKE %s)
        AND option_name NOT LIKE %s
        ORDER BY option_id DESC",
        $transient_prefix . '%',
        $transient_prefix . '%_partner_%',
        $transient_timeout_prefix . '%'
    ));
    
    foreach ($transient_keys as $transient_key) {
        $key_part = str_replace($transient_prefix, '', $transient_key);
        if (strpos($key_part, '_partner_') !== false) {
            $parts = explode('_partner_', $key_part);
            $request_id = $parts[0];
            $partner_id = isset($parts[1]) ? intval($parts[1]) : 0;
            $form_data = get_transient('car_accessories_request_' . $request_id . '_partner_' . $partner_id);
        } else {
            $request_id = $key_part;
            $form_data = get_transient('car_accessories_request_' . $request_id);
            $partner_id = isset($form_data['partner_id']) ? intval($form_data['partner_id']) : 0;
        }
        
        if ($form_data && isset($form_data['timestamp'])) {
            // CRITICAL: Only count if this request belongs to the current customer
            $form_email = isset($form_data['email']) ? strtolower(trim($form_data['email'])) : '';
            $form_user_id = isset($form_data['user_id']) ? intval($form_data['user_id']) : 0;
            
            // Skip if email doesn't match and user_id doesn't match
            if (!empty($customer_email) && !empty($form_email)) {
                if (strtolower(trim($customer_email)) !== $form_email) {
                    continue; // Not this customer's request
                }
            } elseif ($form_user_id > 0 && $form_user_id !== $customer_id) {
                continue; // Not this customer's request
            } elseif (empty($form_email) && $form_user_id <= 0) {
                continue; // Cannot verify ownership, skip
            }
            
            $request_key = $request_id . '_partner_' . $partner_id;
            
            // Skip if already counted from user meta (Query 2)
            if (in_array($request_key, $processed_request_keys)) {
                continue;
            }
            
            // Only count if partner is assigned
            if ($partner_id > 0) {
                $status = isset($form_data['status']) ? $form_data['status'] : 'pending';
                if ($status === $pending_status) {
                    $total_pending++;
                    $processed_request_keys[] = $request_key;
                }
            }
        }
    }
    
    return $total_pending;
}

/**
 * Get recent activities for a customer
 * 
 * @param int $customer_id Customer user ID
 * @param int $limit Number of activities to return (default 10)
 * @return array Array of activity items sorted by time (newest first)
 */
function wheelfy_get_customer_recent_activities($customer_id, $limit = 10) {
    $activities = array();
    
    // 1. Get recent messages received
    $thread_ids = get_user_meta($customer_id, 'wheelfy_chat_threads', true);
    if (is_array($thread_ids) && !empty($thread_ids)) {
        foreach ($thread_ids as $thread_id) {
            $thread = get_option('wheelfy_thread_' . $thread_id, false);
            if (!$thread) {
                continue;
            }
            
            $messages = get_option('wheelfy_messages_' . $thread_id, array());
            if (!is_array($messages)) {
                continue;
            }
            
            // Get other user info
            $other_user_id = ($customer_id == $thread['customer_id']) ? $thread['partner_id'] : $thread['customer_id'];
            $other_user = get_userdata($other_user_id);
            if (!$other_user) {
                continue;
            }
            
            $other_user_name = '';
            if ($other_user_id == $thread['partner_id']) {
                $business_name = get_user_meta($other_user_id, 'business_name', true);
                $other_user_name = !empty($business_name) ? $business_name : ($other_user->display_name ?: $other_user->user_login);
            } else {
                $other_user_name = $other_user->display_name ?: $other_user->user_login;
            }
            
            // Get messages received (not sent by customer)
            foreach ($messages as $msg) {
                if (isset($msg['sender_id']) && intval($msg['sender_id']) != intval($customer_id)) {
                    $timestamp = isset($msg['created_timestamp']) ? $msg['created_timestamp'] : (isset($msg['created_at']) ? strtotime($msg['created_at']) : 0);
                    if ($timestamp > 0) {
                        $activities[] = array(
                            'type' => 'message',
                            'icon' => 'info',
                            'message' => sprintf(__('New message received from %s', 'wheelfy'), $other_user_name),
                            'timestamp' => $timestamp,
                            'time' => human_time_diff($timestamp, current_time('timestamp')) . ' ago'
                        );
                    }
                }
            }
        }
    }
    
    // 2. Get recent reviews given by customer
    $reviews_given = get_user_meta($customer_id, 'wheelfy_reviews_given', true);
    if (is_array($reviews_given) && !empty($reviews_given)) {
        foreach ($reviews_given as $review) {
            if (!isset($review['status']) || $review['status'] === 'cancelled') {
                continue;
            }
            
            $partner_id = isset($review['partner_id']) ? intval($review['partner_id']) : 0;
            if ($partner_id <= 0) {
                continue;
            }
            
            $partner = get_userdata($partner_id);
            if (!$partner) {
                continue;
            }
            
            $business_name = get_user_meta($partner_id, 'business_name', true);
            $partner_name = !empty($business_name) ? $business_name : ($partner->display_name ?: $partner->user_login);
            
            $rating = isset($review['rating']) ? intval($review['rating']) : 0;
            $timestamp = isset($review['created_at']) ? strtotime($review['created_at']) : 0;
            
            if ($timestamp > 0) {
                $activities[] = array(
                    'type' => 'review',
                    'icon' => 'warning',
                    'message' => sprintf(__('New review: %d stars for %s', 'wheelfy'), $rating, $partner_name),
                    'timestamp' => $timestamp,
                    'time' => human_time_diff($timestamp, current_time('timestamp')) . ' ago'
                );
            }
        }
    }
    
    // 3. Get recent requests (status changes)
    $saved_requests = get_user_meta($customer_id, 'customer_service_requests', true);
    if (is_array($saved_requests) && !empty($saved_requests)) {
        foreach ($saved_requests as $saved_request) {
            if (!isset($saved_request['request_id']) || !isset($saved_request['partner_id'])) {
                continue;
            }
            
            $partner_id = intval($saved_request['partner_id']);
            if ($partner_id <= 0) {
                continue;
            }
            
            $status = isset($saved_request['status']) ? $saved_request['status'] : 'pending';
            $timestamp = isset($saved_request['created_at']) ? strtotime($saved_request['created_at']) : 0;
            
            if ($timestamp > 0) {
                $partner = get_userdata($partner_id);
                $partner_name = 'Partner';
                if ($partner) {
                    $business_name = get_user_meta($partner_id, 'business_name', true);
                    $partner_name = !empty($business_name) ? $business_name : ($partner->display_name ?: $partner->user_login);
                }
                
                $status_text = ucfirst($status);
                if ($status === 'accepted') {
                    $status_text = 'Accepted';
                } elseif ($status === 'in-progress') {
                    $status_text = 'In Progress';
                } elseif ($status === 'completed') {
                    $status_text = 'Completed';
                }
                
                $activities[] = array(
                    'type' => 'request',
                    'icon' => 'info',
                    'message' => sprintf(__('Service request %s with %s', 'wheelfy'), $status_text, $partner_name),
                    'timestamp' => $timestamp,
                    'time' => human_time_diff($timestamp, current_time('timestamp')) . ' ago'
                );
            }
        }
    }
    
    // Sort by timestamp (newest first)
    usort($activities, function($a, $b) {
        return $b['timestamp'] - $a['timestamp'];
    });
    
    // Limit results
    return array_slice($activities, 0, $limit);
}

/**
 * Get recent activities for a partner
 * 
 * @param int $partner_id Partner user ID
 * @param int $limit Number of activities to return (default 10)
 * @return array Array of activity items sorted by time (newest first)
 */
function wheelfy_get_partner_recent_activities($partner_id, $limit = 10) {
    $activities = array();
    
    // 1. Get recent messages received from customers
    $thread_ids = get_user_meta($partner_id, 'wheelfy_chat_threads', true);
    if (is_array($thread_ids) && !empty($thread_ids)) {
        foreach ($thread_ids as $thread_id) {
            $thread = get_option('wheelfy_thread_' . $thread_id, false);
            if (!$thread) {
                continue;
            }
            
            $messages = get_option('wheelfy_messages_' . $thread_id, array());
            if (!is_array($messages)) {
                continue;
            }
            
            // Get customer info
            $customer_id = ($partner_id == $thread['partner_id']) ? $thread['customer_id'] : $thread['partner_id'];
            $customer = get_userdata($customer_id);
            if (!$customer) {
                continue;
            }
            
            $customer_name = $customer->display_name ?: $customer->user_login;
            
            // Get messages received (sent by customer, not by partner)
            foreach ($messages as $msg) {
                if (isset($msg['sender_id']) && intval($msg['sender_id']) != intval($partner_id) && intval($msg['sender_id']) == intval($customer_id)) {
                    $timestamp = isset($msg['created_timestamp']) ? $msg['created_timestamp'] : (isset($msg['created_at']) ? strtotime($msg['created_at']) : 0);
                    if ($timestamp > 0) {
                        $activities[] = array(
                            'type' => 'message',
                            'icon' => 'info',
                            'message' => sprintf(__('New message received from %s', 'wheelfy'), $customer_name),
                            'timestamp' => $timestamp,
                            'time' => human_time_diff($timestamp, current_time('timestamp')) . ' ago'
                        );
                    }
                }
            }
        }
    }
    
    // 2. Get recent reviews received from customers
    $reviews_received = get_user_meta($partner_id, 'wheelfy_reviews_received', true);
    if (is_array($reviews_received) && !empty($reviews_received)) {
        foreach ($reviews_received as $review) {
            if (!isset($review['status']) || $review['status'] === 'cancelled') {
                continue;
            }
            
            $customer_id = isset($review['customer_id']) ? intval($review['customer_id']) : 0;
            if ($customer_id <= 0) {
                continue;
            }
            
            $customer = get_userdata($customer_id);
            if (!$customer) {
                continue;
            }
            
            $customer_name = $customer->display_name ?: $customer->user_login;
            $rating = isset($review['rating']) ? intval($review['rating']) : 0;
            $timestamp = isset($review['created_at']) ? strtotime($review['created_at']) : 0;
            
            if ($timestamp > 0) {
                $activities[] = array(
                    'type' => 'review',
                    'icon' => 'warning',
                    'message' => sprintf(__('New review: %d stars from %s', 'wheelfy'), $rating, $customer_name),
                    'timestamp' => $timestamp,
                    'time' => human_time_diff($timestamp, current_time('timestamp')) . ' ago'
                );
            }
        }
    }
    
    // 3. Get recent service requests (where partner is assigned)
    global $wpdb;
    
    // Query posts where partner is assigned
    $proposal_args = array(
        'post_type' => 'post',
        'posts_per_page' => -1,
        'meta_query' => array(
            array(
                'key' => 'partner_id',
                'value' => $partner_id,
                'compare' => '='
            ),
            array(
                'key' => '_proposal_status',
                'compare' => 'EXISTS'
            )
        ),
        'orderby' => 'date',
        'order' => 'DESC'
    );
    
    $proposal_posts = get_posts($proposal_args);
    foreach ($proposal_posts as $post) {
        $status = get_post_meta($post->ID, '_proposal_status', true) ?: 'pending';
        $timestamp = strtotime($post->post_date);
        
        if ($timestamp > 0) {
            $customer_id = $post->post_author;
            $customer = get_userdata($customer_id);
            $customer_name = $customer ? ($customer->display_name ?: $customer->user_login) : 'Customer';
            
            if ($status === 'pending') {
                $activities[] = array(
                    'type' => 'request',
                    'icon' => 'info',
                    'message' => sprintf(__('New service request received from %s', 'wheelfy'), $customer_name),
                    'timestamp' => $timestamp,
                    'time' => human_time_diff($timestamp, current_time('timestamp')) . ' ago'
                );
            } elseif ($status === 'accepted') {
                $activities[] = array(
                    'type' => 'quote',
                    'icon' => 'success',
                    'message' => sprintf(__('Quote accepted by %s', 'wheelfy'), $customer_name),
                    'timestamp' => $timestamp,
                    'time' => human_time_diff($timestamp, current_time('timestamp')) . ' ago'
                );
            }
        }
    }
    
    // 4. Also check user meta for requests
    $customer_requests_meta = $wpdb->get_results($wpdb->prepare(
        "SELECT user_id, meta_value FROM {$wpdb->usermeta}
        WHERE meta_key = 'customer_service_requests'
        AND meta_value LIKE %s",
        '%"partner_id";i:' . $partner_id . ';%'
    ));
    
    foreach ($customer_requests_meta as $meta_row) {
        $customer_id = $meta_row->user_id;
        $saved_requests = maybe_unserialize($meta_row->meta_value);
        
        if (is_array($saved_requests)) {
            foreach ($saved_requests as $saved_request) {
                if (!isset($saved_request['partner_id']) || intval($saved_request['partner_id']) != $partner_id) {
                    continue;
                }
                
                $status = isset($saved_request['status']) ? $saved_request['status'] : 'pending';
                $timestamp = isset($saved_request['created_at']) ? strtotime($saved_request['created_at']) : 0;
                
                if ($timestamp > 0) {
                    $customer = get_userdata($customer_id);
                    $customer_name = $customer ? ($customer->display_name ?: $customer->user_login) : 'Customer';
                    
                    if ($status === 'pending') {
                        $activities[] = array(
                            'type' => 'request',
                            'icon' => 'info',
                            'message' => sprintf(__('New service request received from %s', 'wheelfy'), $customer_name),
                            'timestamp' => $timestamp,
                            'time' => human_time_diff($timestamp, current_time('timestamp')) . ' ago'
                        );
                    } elseif ($status === 'accepted') {
                        $activities[] = array(
                            'type' => 'quote',
                            'icon' => 'success',
                            'message' => sprintf(__('Quote accepted by %s', 'wheelfy'), $customer_name),
                            'timestamp' => $timestamp,
                            'time' => human_time_diff($timestamp, current_time('timestamp')) . ' ago'
                        );
                    }
                }
            }
        }
    }
    
    // Sort by timestamp (newest first)
    usort($activities, function($a, $b) {
        return $b['timestamp'] - $a['timestamp'];
    });
    
    // Limit results
    return array_slice($activities, 0, $limit);
}

// Note: wheelfy_get_partner_reviews_count is defined earlier in this file

/**
 * Get partner response rate percentage
 * 
 * @param int $partner_id Partner user ID
 * @return float Response rate percentage (0-100)
 */
function wheelfy_get_partner_response_rate($partner_id) {
    $thread_ids = get_user_meta($partner_id, 'wheelfy_chat_threads', true);
    if (!is_array($thread_ids) || empty($thread_ids)) {
        return 0;
    }
    
    $total_customer_messages = 0;
    $total_partner_responses = 0;
    $threads_with_customer_messages = array(); // Track threads that have customer messages
    
    foreach ($thread_ids as $thread_id) {
        $thread = get_option('wheelfy_thread_' . $thread_id, false);
        if (!$thread) {
            continue;
        }
        
        $messages = get_option('wheelfy_messages_' . $thread_id, array());
        if (!is_array($messages) || empty($messages)) {
            continue;
        }
        
        // Get customer ID for this thread
        $customer_id = ($partner_id == $thread['partner_id']) ? $thread['customer_id'] : $thread['partner_id'];
        
        $has_customer_message = false;
        $has_partner_response = false;
        
        foreach ($messages as $msg) {
            $sender_id = isset($msg['sender_id']) ? intval($msg['sender_id']) : 0;
            
            // Count customer messages (messages sent by customer, not partner)
            if ($sender_id == $customer_id && $sender_id != $partner_id) {
                $total_customer_messages++;
                $has_customer_message = true;
            }
            
            // Count partner responses (messages sent by partner after a customer message)
            if ($sender_id == $partner_id && $has_customer_message) {
                $has_partner_response = true;
            }
        }
        
        // If thread has customer messages and partner responded, count as responded
        if ($has_customer_message && $has_partner_response) {
            $total_partner_responses++;
        }
    }
    
    // Calculate response rate: (Threads with responses / Threads with customer messages) * 100
    // Or simpler: (Partner responses / Customer messages) * 100, but cap at 100%
    if ($total_customer_messages > 0) {
        // Count unique threads where partner responded
        $threads_responded = 0;
        foreach ($thread_ids as $thread_id) {
            $thread = get_option('wheelfy_thread_' . $thread_id, false);
            if (!$thread) {
                continue;
            }
            
            $messages = get_option('wheelfy_messages_' . $thread_id, array());
            if (!is_array($messages) || empty($messages)) {
                continue;
            }
            
            $customer_id = ($partner_id == $thread['partner_id']) ? $thread['customer_id'] : $thread['partner_id'];
            $has_customer_message = false;
            $has_partner_response = false;
            
            foreach ($messages as $msg) {
                $sender_id = isset($msg['sender_id']) ? intval($msg['sender_id']) : 0;
                
                if ($sender_id == $customer_id && $sender_id != $partner_id) {
                    $has_customer_message = true;
                }
                
                if ($sender_id == $partner_id && $has_customer_message) {
                    $has_partner_response = true;
                    break; // Found a response, no need to check further
                }
            }
            
            if ($has_customer_message && $has_partner_response) {
                $threads_responded++;
            }
        }
        
        // Count threads with customer messages
        $threads_with_messages = 0;
        foreach ($thread_ids as $thread_id) {
            $thread = get_option('wheelfy_thread_' . $thread_id, false);
            if (!$thread) {
                continue;
            }
            
            $messages = get_option('wheelfy_messages_' . $thread_id, array());
            if (!is_array($messages) || empty($messages)) {
                continue;
            }
            
            $customer_id = ($partner_id == $thread['partner_id']) ? $thread['customer_id'] : $thread['partner_id'];
            
            foreach ($messages as $msg) {
                $sender_id = isset($msg['sender_id']) ? intval($msg['sender_id']) : 0;
                if ($sender_id == $customer_id && $sender_id != $partner_id) {
                    $threads_with_messages++;
                    break; // Found a customer message in this thread
                }
            }
        }
        
        if ($threads_with_messages > 0) {
            $response_rate = ($threads_responded / $threads_with_messages) * 100;
            return round($response_rate, 1);
        }
    }
    
    return 0;
}

/**
 * Get active service requests count for a partner
 * 
 * @param int $partner_id Partner user ID
 * @return int Total count of active requests (accepted or in-progress)
 */
function wheelfy_get_partner_active_requests_count($partner_id) {
    $active_statuses = array('accepted', 'in-progress');
    $total_active = 0;
    $processed_request_keys = array();
    
    // Query 1: Get requests from posts where partner is assigned
    $proposal_args = array(
        'post_type' => 'post',
        'posts_per_page' => -1,
        'meta_query' => array(
            array(
                'key' => 'partner_id',
                'value' => $partner_id,
                'compare' => '='
            ),
            array(
                'key' => '_proposal_status',
                'compare' => 'EXISTS'
            )
        ),
        'orderby' => 'date',
        'order' => 'DESC'
    );
    
    $proposal_posts = get_posts($proposal_args);
    foreach ($proposal_posts as $post) {
        $status = get_post_meta($post->ID, '_proposal_status', true) ?: 'pending';
        if (in_array($status, $active_statuses)) {
            $request_key = 'post_' . $post->ID . '_partner_' . $partner_id;
            if (!in_array($request_key, $processed_request_keys)) {
                $total_active++;
                $processed_request_keys[] = $request_key;
            }
        }
    }
    
    // Query 2: Get requests from customer user meta where partner is assigned
    global $wpdb;
    $customer_requests_meta = $wpdb->get_results($wpdb->prepare(
        "SELECT user_id, meta_value FROM {$wpdb->usermeta}
        WHERE meta_key = 'customer_service_requests'
        AND meta_value LIKE %s",
        '%"partner_id";i:' . $partner_id . ';%'
    ));
    
    foreach ($customer_requests_meta as $meta_row) {
        $saved_requests = maybe_unserialize($meta_row->meta_value);
        
        if (is_array($saved_requests)) {
            foreach ($saved_requests as $saved_request) {
                if (!isset($saved_request['partner_id']) || intval($saved_request['partner_id']) != $partner_id) {
                    continue;
                }
                
                $request_id = isset($saved_request['request_id']) ? $saved_request['request_id'] : '';
                $request_key = $request_id . '_partner_' . $partner_id;
                
                if (!in_array($request_key, $processed_request_keys)) {
                    $status = isset($saved_request['status']) ? $saved_request['status'] : 'pending';
                    if (in_array($status, $active_statuses)) {
                        $total_active++;
                        $processed_request_keys[] = $request_key;
                    }
                }
            }
        }
    }
    
    // Query 3: Check transients (recent form submissions with partner assigned)
    $transient_prefix = '_transient_car_accessories_request_';
    $transient_timeout_prefix = '_transient_timeout_car_accessories_request_';
    
    $transient_keys = $wpdb->get_col($wpdb->prepare(
        "SELECT option_name FROM {$wpdb->options} 
        WHERE (option_name LIKE %s OR option_name LIKE %s)
        AND option_name NOT LIKE %s
        ORDER BY option_id DESC",
        $transient_prefix . '%',
        $transient_prefix . '%_partner_%',
        $transient_timeout_prefix . '%'
    ));
    
    foreach ($transient_keys as $transient_key) {
        $key_part = str_replace($transient_prefix, '', $transient_key);
        if (strpos($key_part, '_partner_') !== false) {
            $parts = explode('_partner_', $key_part);
            $request_id = $parts[0];
            $transient_partner_id = isset($parts[1]) ? intval($parts[1]) : 0;
            $form_data = get_transient('car_accessories_request_' . $request_id . '_partner_' . $transient_partner_id);
        } else {
            $request_id = $key_part;
            $form_data = get_transient('car_accessories_request_' . $request_id);
            $transient_partner_id = isset($form_data['partner_id']) ? intval($form_data['partner_id']) : 0;
        }
        
        if ($form_data && isset($form_data['timestamp']) && $transient_partner_id == $partner_id) {
            $request_key = $request_id . '_partner_' . $partner_id;
            
            if (!in_array($request_key, $processed_request_keys)) {
                $status = isset($form_data['status']) ? $form_data['status'] : 'pending';
                if (in_array($status, $active_statuses)) {
                    $total_active++;
                    $processed_request_keys[] = $request_key;
                }
            }
        }
    }
    
    return $total_active;
}

/**
 * Get unread message count for user
 * 
 * @param int $user_id User ID
 * @return int Unread count
 */
function wheelfy_get_unread_message_count($user_id) {
    $thread_ids = get_user_meta($user_id, 'wheelfy_chat_threads', true);
    if (!is_array($thread_ids)) {
        return 0;
    }
    
    $unread_count = 0;
    
    foreach ($thread_ids as $thread_id) {
        $messages = get_option('wheelfy_messages_' . $thread_id, array());
        foreach ($messages as $msg) {
            if ($msg['sender_id'] != $user_id && !$msg['read']) {
                $unread_count++;
            }
        }
    }
    
    return $unread_count;
}

/**
 * AJAX: Get user conversations
 */
function wheelfy_ajax_get_conversations() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_nonce')) {
        wp_send_json_error(array('message' => 'Security check failed.'));
    }
    
    // Check if user is logged in
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'You must be logged in.'));
    }
    
    $user_id = get_current_user_id();
    $conversations = wheelfy_get_user_conversations($user_id);
    $unread_count = wheelfy_get_unread_message_count($user_id);
    
    wp_send_json_success(array(
        'conversations' => $conversations,
        'unread_count' => $unread_count
    ));
}
add_action('wp_ajax_get_conversations', 'wheelfy_ajax_get_conversations');

/**
 * AJAX: Search conversations
 * Includes partners with non-pending requests OR existing conversations
 */
function wheelfy_ajax_search_conversations() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_nonce')) {
        wp_send_json_error(array('message' => 'Security check failed.'));
    }
    
    // Check if user is logged in
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'You must be logged in.'));
    }
    
    $user_id = get_current_user_id();
    $search_term = isset($_POST['search_term']) ? sanitize_text_field($_POST['search_term']) : '';
    
    // If search term is empty, return all conversations
    if (empty($search_term)) {
        $conversations = wheelfy_get_user_conversations($user_id);
        $unread_count = wheelfy_get_unread_message_count($user_id);
        
        wp_send_json_success(array(
            'conversations' => $conversations,
            'unread_count' => $unread_count
        ));
    }
    
    $search_term_lower = strtolower(trim($search_term));
    
    // Step 1: Get all eligible partner IDs
    // - Partners with non-pending requests
    // - Partners with existing conversations
    $eligible_partner_ids = array();
    
    // Get partners from requests (exclude pending only)
    $saved_requests = get_user_meta($user_id, 'customer_service_requests', true);
    if (is_array($saved_requests) && !empty($saved_requests)) {
        foreach ($saved_requests as $request) {
            if (!isset($request['partner_id']) || !isset($request['status'])) {
                continue;
            }
            
            $partner_id = intval($request['partner_id']);
            $status = sanitize_text_field($request['status']);
            
            // Include if status is NOT pending
            if ($partner_id > 0 && $status !== 'pending') {
                $eligible_partner_ids[$partner_id] = true;
            }
        }
    }
    
    // Get partners from conversations
    $thread_ids = get_user_meta($user_id, 'wheelfy_chat_threads', true);
    if (is_array($thread_ids) && !empty($thread_ids)) {
        foreach ($thread_ids as $thread_id) {
            $thread = get_option('wheelfy_thread_' . $thread_id, false);
            if (!$thread) {
                continue;
            }
            
            // Determine other user (partner)
            $other_user_id = ($user_id == $thread['customer_id']) ? $thread['partner_id'] : $thread['customer_id'];
            if ($other_user_id > 0) {
                $eligible_partner_ids[$other_user_id] = true;
            }
        }
    }
    
    // Also check transients for recent requests
    global $wpdb;
    $transient_prefix = '_transient_car_accessories_request_';
    $transient_keys = $wpdb->get_col($wpdb->prepare(
        "SELECT option_name FROM {$wpdb->options} 
        WHERE option_name LIKE %s
        AND option_name NOT LIKE %s
        ORDER BY option_id DESC
        LIMIT 100",
        $transient_prefix . '%',
        $transient_prefix . '%_timeout%'
    ));
    
    foreach ($transient_keys as $transient_key) {
        $key_part = str_replace($transient_prefix, '', $transient_key);
        if (strpos($key_part, '_partner_') !== false) {
            $parts = explode('_partner_', $key_part);
            $request_id = $parts[0];
            $partner_id = isset($parts[1]) ? intval($parts[1]) : 0;
            $form_data = get_transient('car_accessories_request_' . $request_id . '_partner_' . $partner_id);
        } else {
            $form_data = get_transient('car_accessories_request_' . $key_part);
            $partner_id = isset($form_data['partner_id']) ? intval($form_data['partner_id']) : 0;
        }
        
        if ($form_data && $partner_id > 0) {
            $status = isset($form_data['status']) ? sanitize_text_field($form_data['status']) : 'pending';
            // Include if status is NOT pending
            if ($status !== 'pending') {
                $eligible_partner_ids[$partner_id] = true;
            }
        }
    }
    
    if (empty($eligible_partner_ids)) {
        wp_send_json_success(array(
            'conversations' => array(),
            'unread_count' => 0,
            'search_term' => $search_term
        ));
    }
    
    // Step 2: Search eligible partners by name/email
    $matched_partners = array();
    
    foreach (array_keys($eligible_partner_ids) as $partner_id) {
        $partner_user = get_userdata($partner_id);
        if (!$partner_user) {
            continue;
        }
        
        $match = false;
        
        // Get partner name
        $business_name = get_user_meta($partner_id, 'business_name', true);
        $display_name = !empty($business_name) ? $business_name : ($partner_user->display_name ?: $partner_user->user_login);
        $user_login = $partner_user->user_login;
        $user_email = $partner_user->user_email;
        
        // Match by display name
        if (strpos(strtolower($display_name), $search_term_lower) !== false) {
            $match = true;
        }
        
        // Match by username
        if (!$match && strpos(strtolower($user_login), $search_term_lower) !== false) {
            $match = true;
        }
        
        // Match by email
        if (!$match && strpos(strtolower($user_email), $search_term_lower) !== false) {
            $match = true;
        }
        
        if ($match) {
            // Get conversation info if exists
            $conversation_data = null;
            $thread_ids = get_user_meta($user_id, 'wheelfy_chat_threads', true);
            if (is_array($thread_ids)) {
                foreach ($thread_ids as $thread_id) {
                    $thread = get_option('wheelfy_thread_' . $thread_id, false);
                    if (!$thread) {
                        continue;
                    }
                    
                    $other_user_id = ($user_id == $thread['customer_id']) ? $thread['partner_id'] : $thread['customer_id'];
                    if ($other_user_id == $partner_id) {
                        // Found conversation with this partner
                        $conversation_data = wheelfy_get_conversation_data_for_search($user_id, $thread_id, $thread);
                        break;
                    }
                }
            }
            
            // Get profile image
            $profile_image_id = get_user_meta($partner_id, 'profile_image_id', true);
            $partner_avatar = '';
            if ($profile_image_id && is_numeric($profile_image_id)) {
                $partner_avatar = wp_get_attachment_image_url($profile_image_id, 'thumbnail');
            } else {
                $partner_avatar = get_avatar_url($partner_id, array('size' => 96));
            }
            
            $matched_partners[] = array(
                'thread_id' => $conversation_data ? $conversation_data['thread_id'] : null,
                'other_user_id' => $partner_id,
                'other_user_name' => $display_name,
                'other_user_email' => $user_email,
                'other_user_avatar' => $partner_avatar,
                'last_message' => $conversation_data ? $conversation_data['last_message'] : null,
                'last_message_time' => $conversation_data ? $conversation_data['last_message_time'] : 0,
                'unread_count' => $conversation_data ? $conversation_data['unread_count'] : 0,
                'has_conversation' => $conversation_data !== null
            );
        }
    }
    
    // Sort by last message time (newest first), then by name
    usort($matched_partners, function($a, $b) {
        if ($a['last_message_time'] != $b['last_message_time']) {
            return $b['last_message_time'] - $a['last_message_time'];
        }
        return strcasecmp($a['other_user_name'], $b['other_user_name']);
    });
    
    // Limit results to 20
    $matched_partners = array_slice($matched_partners, 0, 20);
    
    // Calculate unread count
    $unread_count = 0;
    foreach ($matched_partners as $partner) {
        $unread_count += $partner['unread_count'];
    }
    
    wp_send_json_success(array(
        'conversations' => $matched_partners,
        'unread_count' => $unread_count,
        'search_term' => $search_term
    ));
}

/**
 * Helper function to get conversation data for search results
 */
function wheelfy_get_conversation_data_for_search($user_id, $thread_id, $thread) {
    // Get deleted conversations for this user
    $deleted_conversations = get_user_meta($user_id, 'wheelfy_deleted_conversations', true);
    if (!is_array($deleted_conversations)) {
        $deleted_conversations = array();
    }
    
    // Skip if deleted (unless there's a new message)
    if (in_array($thread_id, $deleted_conversations)) {
        if ($thread && isset($thread['last_message_timestamp'])) {
            $deleted_meta = get_user_meta($user_id, 'wheelfy_deleted_conversations_timestamps', true);
            if (!is_array($deleted_meta)) {
                $deleted_meta = array();
            }
            $deleted_timestamp = isset($deleted_meta[$thread_id]) ? $deleted_meta[$thread_id] : 0;
            if ($thread['last_message_timestamp'] <= $deleted_timestamp) {
                return null; // Still deleted
            }
        } else {
            return null; // No thread or no new messages
        }
    }
    
    // Get last message (skip deleted messages)
    $messages = get_option('wheelfy_messages_' . $thread_id, array());
    $last_message = null;
    if (!empty($messages)) {
        // Find last non-deleted message
        for ($i = count($messages) - 1; $i >= 0; $i--) {
            $msg = $messages[$i];
            if (!isset($msg['is_deleted']) || !$msg['is_deleted']) {
                $last_message = $msg;
                break;
            }
        }
    }
    
    // Count unread messages (excluding deleted)
    $unread_count = 0;
    if ($last_message) {
        foreach ($messages as $msg) {
            if (isset($msg['is_deleted']) && $msg['is_deleted']) {
                continue; // Skip deleted messages
            }
            if ($msg['sender_id'] != $user_id && !$msg['read']) {
                $unread_count++;
            }
        }
    }
    
    return array(
        'thread_id' => $thread_id,
        'last_message' => $last_message ? array(
            'text' => (isset($last_message['is_deleted']) && $last_message['is_deleted']) ? 'This message was deleted' : wp_trim_words($last_message['message_text'], 20),
            'timestamp' => $last_message['created_timestamp'],
            'sender_id' => $last_message['sender_id']
        ) : null,
        'last_message_time' => isset($thread['last_message_timestamp']) ? $thread['last_message_timestamp'] : 0,
        'unread_count' => $unread_count
    );
}

add_action('wp_ajax_search_conversations', 'wheelfy_ajax_search_conversations');

/**
 * AJAX: Search conversations (Partner Dashboard - existing conversations only)
 * This endpoint is specifically for partners searching within their existing conversations
 */
function wheelfy_ajax_search_partner_conversations() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_nonce')) {
        wp_send_json_error(array('message' => 'Security check failed.'));
    }
    
    // Check if user is logged in
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'You must be logged in.'));
    }
    
    $partner_id = get_current_user_id();
    $search_term = isset($_POST['search_term']) ? sanitize_text_field($_POST['search_term']) : '';
    
    // If search term is empty, return all conversations
    if (empty($search_term)) {
        $conversations = wheelfy_get_user_conversations($partner_id);
        $unread_count = wheelfy_get_unread_message_count($partner_id);
        
        wp_send_json_success(array(
            'conversations' => $conversations,
            'unread_count' => $unread_count
        ));
    }
    
    // Get all existing conversations for this partner
    $all_conversations = wheelfy_get_user_conversations($partner_id);
    
    // Filter conversations by search term (case-insensitive)
    $search_term_lower = strtolower(trim($search_term));
    $filtered_conversations = array();
    
    foreach ($all_conversations as $conv) {
        $match = false;
        
        // Match by customer display name
        if (!empty($conv['other_user_name'])) {
            if (strpos(strtolower($conv['other_user_name']), $search_term_lower) !== false) {
                $match = true;
            }
        }
        
        // Match by email (if available)
        if (!$match && !empty($conv['other_user_email'])) {
            if (strpos(strtolower($conv['other_user_email']), $search_term_lower) !== false) {
                $match = true;
            }
        }
        
        // Match by last message text
        if (!$match && !empty($conv['last_message']['text'])) {
            if (strpos(strtolower($conv['last_message']['text']), $search_term_lower) !== false) {
                $match = true;
            }
        }
        
        if ($match) {
            $filtered_conversations[] = $conv;
        }
    }
    
    // Get unread count (only for filtered conversations)
    $unread_count = 0;
    foreach ($filtered_conversations as $conv) {
        $unread_count += $conv['unread_count'];
    }
    
    wp_send_json_success(array(
        'conversations' => $filtered_conversations,
        'unread_count' => $unread_count,
        'search_term' => $search_term
    ));
}
add_action('wp_ajax_search_partner_conversations', 'wheelfy_ajax_search_partner_conversations');

/**
 * AJAX: Get or create thread with a partner
 */
function wheelfy_ajax_get_or_create_thread() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_nonce')) {
        wp_send_json_error(array('message' => 'Security check failed.'));
    }
    
    // Check if user is logged in
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'You must be logged in.'));
    }
    
    $current_user_id = get_current_user_id();
    $other_user_id = isset($_POST['other_user_id']) ? intval($_POST['other_user_id']) : 0;
    
    if ($other_user_id <= 0) {
        wp_send_json_error(array('message' => 'Invalid partner ID.'));
    }
    
    if ($current_user_id == $other_user_id) {
        wp_send_json_error(array('message' => 'Cannot create thread with yourself.'));
    }
    
    // Verify other user exists
    $other_user = get_userdata($other_user_id);
    if (!$other_user) {
        wp_send_json_error(array('message' => 'Partner not found.'));
    }
    
    // Get or create thread
    $thread_id = wheelfy_get_or_create_thread($current_user_id, $other_user_id);
    
    // Get thread data
    $thread = get_option('wheelfy_thread_' . $thread_id, false);
    if (!$thread) {
        wp_send_json_error(array('message' => 'Failed to create thread.'));
    }
    
    // Get other user info
    $other_user_name = get_user_meta($other_user_id, 'business_name', true);
    if (empty($other_user_name)) {
        $other_user_name = $other_user->display_name ?: $other_user->user_login;
    }
    
    $other_user_avatar = '';
    $profile_image_id = get_user_meta($other_user_id, 'profile_image', true);
    if ($profile_image_id) {
        $other_user_avatar = wp_get_attachment_image_url($profile_image_id, 'thumbnail');
    }
    if (empty($other_user_avatar)) {
        $other_user_avatar = get_avatar_url($other_user_id, array('size' => 96));
    }
    
    wp_send_json_success(array(
        'thread_id' => $thread_id,
        'other_user_id' => $other_user_id,
        'other_user_name' => $other_user_name,
        'other_user_avatar' => $other_user_avatar
    ));
}
add_action('wp_ajax_get_or_create_thread', 'wheelfy_ajax_get_or_create_thread');

/**
 * AJAX: Update message notifications preference
 */
function wheelfy_ajax_update_message_notifications() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_nonce')) {
        wp_send_json_error(array('message' => 'Security check failed.'));
    }
    
    // Check if user is logged in
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'You must be logged in.'));
    }
    
    $user_id = get_current_user_id();
    $enabled = isset($_POST['enabled']) ? sanitize_text_field($_POST['enabled']) : '1';
    
    // Save preference (1 = enabled, 0 = disabled)
    update_user_meta($user_id, 'message_notifications_enabled', $enabled);
    
    wp_send_json_success(array(
        'message' => 'Message notifications preference updated successfully.',
        'enabled' => $enabled
    ));
}
add_action('wp_ajax_update_message_notifications', 'wheelfy_ajax_update_message_notifications');

/**
 * AJAX: Update review notifications preference
 */
function wheelfy_ajax_update_review_notifications() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_nonce')) {
        wp_send_json_error(array('message' => 'Security check failed.'));
    }
    
    // Check if user is logged in
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'You must be logged in.'));
    }
    
    $user_id = get_current_user_id();
    $enabled = isset($_POST['enabled']) ? sanitize_text_field($_POST['enabled']) : '1';
    
    // Save preference (1 = enabled, 0 = disabled)
    update_user_meta($user_id, 'review_notifications_enabled', $enabled);
    
    wp_send_json_success(array(
        'message' => 'Review notifications preference updated successfully.',
        'enabled' => $enabled
    ));
}
add_action('wp_ajax_update_review_notifications', 'wheelfy_ajax_update_review_notifications');

/**
 * AJAX: Update email notifications preference
 */
function wheelfy_ajax_update_email_notifications() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_nonce')) {
        wp_send_json_error(array('message' => 'Security check failed.'));
    }
    
    // Check if user is logged in
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'You must be logged in.'));
    }
    
    $user_id = get_current_user_id();
    $enabled = isset($_POST['enabled']) ? sanitize_text_field($_POST['enabled']) : '1';
    
    // Save preference (1 = enabled, 0 = disabled)
    update_user_meta($user_id, 'email_notifications_enabled', $enabled);
    
    wp_send_json_success(array(
        'message' => 'Email notifications preference updated successfully.',
        'enabled' => $enabled
    ));
}
add_action('wp_ajax_update_email_notifications', 'wheelfy_ajax_update_email_notifications');

/**
 * AJAX: Get thread messages
 */
function wheelfy_ajax_get_thread_messages() {
    try {
        // Verify nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_nonce')) {
            wp_send_json_error(array('message' => 'Security check failed. Please refresh the page and try again.'));
        }
        
        // Check if user is logged in
        if (!is_user_logged_in()) {
            wp_send_json_error(array('message' => 'You must be logged in to view messages.'));
        }
        
        $user_id = get_current_user_id();
        if (!$user_id || $user_id <= 0) {
            wp_send_json_error(array('message' => 'Invalid user session. Please log in again.'));
        }
        
        $thread_id = isset($_POST['thread_id']) ? sanitize_text_field($_POST['thread_id']) : '';
        $thread_id = trim($thread_id);
        
        if (empty($thread_id)) {
            wp_send_json_error(array('message' => 'Thread ID is required.'));
        }
        
        // Verify user is part of thread
        $thread = get_option('wheelfy_thread_' . $thread_id, false);
        if (!$thread || !is_array($thread)) {
            wp_send_json_error(array('message' => 'Conversation not found. It may have been deleted.'));
        }
        
        // Validate thread structure
        if (!isset($thread['customer_id']) || !isset($thread['partner_id'])) {
            wp_send_json_error(array('message' => 'Invalid conversation data.'));
        }
        
        // Check authorization
        if ($thread['customer_id'] != $user_id && $thread['partner_id'] != $user_id) {
            wp_send_json_error(array('message' => 'You do not have permission to view this conversation.'));
        }
        
        // Get messages
        $messages = wheelfy_get_thread_messages($thread_id, $user_id);
        if (!is_array($messages)) {
            $messages = array();
        }
        
        // Enrich messages with sender info
        foreach ($messages as &$msg) {
            if (!isset($msg['sender_id'])) {
                continue; // Skip invalid messages
            }
            
            // Initialize is_deleted if not set (for backward compatibility)
            if (!isset($msg['is_deleted'])) {
                $msg['is_deleted'] = false;
            }
            
            // Skip message text processing if deleted (but still enrich sender for display)
            if ($msg['is_deleted']) {
                $msg['message_text'] = ''; // Clear text for deleted messages
            }
            
            $sender = get_userdata($msg['sender_id']);
            if ($sender) {
                if ($msg['sender_id'] == $thread['partner_id']) {
                    $business_name = get_user_meta($msg['sender_id'], 'business_name', true);
                    $msg['sender_name'] = !empty($business_name) ? $business_name : ($sender->display_name ?: $sender->user_login);
                } else {
                    $msg['sender_name'] = $sender->display_name ?: $sender->user_login;
                }
            } else {
                $msg['sender_name'] = 'Unknown User';
            }
            
            // Get attachment URLs if any
            if (!empty($msg['attachments']) && is_array($msg['attachments'])) {
                $msg['attachment_urls'] = array();
                foreach ($msg['attachments'] as $attachment_id) {
                    if (!is_numeric($attachment_id)) {
                        continue;
                    }
                    $url = wp_get_attachment_url($attachment_id);
                    if ($url) {
                        $msg['attachment_urls'][] = array(
                            'id' => $attachment_id,
                            'url' => $url,
                            'name' => get_the_title($attachment_id) ?: 'Attachment',
                            'type' => get_post_mime_type($attachment_id) ?: 'application/octet-stream'
                        );
                    }
                }
            }
            
            // Enrich parent message info if this is a reply
            if (!empty($msg['parent_message_id'])) {
                $all_thread_messages = get_option('wheelfy_messages_' . $thread_id, array());
                if (!is_array($all_thread_messages)) {
                    $all_thread_messages = array();
                }
                
                $parent_message = null;
                foreach ($all_thread_messages as $parent_msg) {
                    if (isset($parent_msg['id']) && $parent_msg['id'] === $msg['parent_message_id']) {
                        $parent_message = $parent_msg;
                        break;
                    }
                }
                
                if ($parent_message) {
                    // Check if parent message is deleted
                    $parent_is_deleted = isset($parent_message['is_deleted']) && $parent_message['is_deleted'];
                    
                    if ($parent_is_deleted) {
                        // Parent message was deleted
                        $msg['parent_message'] = array(
                            'id' => $parent_message['id'],
                            'sender_id' => isset($parent_message['sender_id']) ? $parent_message['sender_id'] : null,
                            'sender_name' => null,
                            'message_text' => null,
                            'deleted' => true
                        );
                    } else {
                        // Get parent message sender info
                        $parent_sender = get_userdata($parent_message['sender_id']);
                        $parent_sender_name = 'Unknown User';
                        if ($parent_sender) {
                            if ($parent_message['sender_id'] == $thread['partner_id']) {
                                $business_name = get_user_meta($parent_message['sender_id'], 'business_name', true);
                                $parent_sender_name = !empty($business_name) ? $business_name : ($parent_sender->display_name ?: $parent_sender->user_login);
                            } else {
                                $parent_sender_name = $parent_sender->display_name ?: $parent_sender->user_login;
                            }
                        }
                        
                        $msg['parent_message'] = array(
                            'id' => $parent_message['id'],
                            'sender_id' => $parent_message['sender_id'],
                            'sender_name' => $parent_sender_name,
                            'message_text' => isset($parent_message['message_text']) ? $parent_message['message_text'] : '',
                            'created_timestamp' => isset($parent_message['created_timestamp']) ? $parent_message['created_timestamp'] : 0
                        );
                    }
                } else {
                    // Parent message not found - mark as deleted
                    $msg['parent_message'] = array(
                        'id' => $msg['parent_message_id'],
                        'sender_id' => null,
                        'sender_name' => null,
                        'message_text' => null,
                        'deleted' => true
                    );
                }
            }
        }
        
        // Get other user's avatar and name for thread
        $other_user_id = ($user_id == $thread['customer_id']) ? $thread['partner_id'] : $thread['customer_id'];
        $other_user = get_userdata($other_user_id);
        $other_user_avatar = '';
        $other_user_name = '';
        if ($other_user) {
            // Get other user's name
            if ($other_user_id == $thread['partner_id']) {
                $business_name = get_user_meta($other_user_id, 'business_name', true);
                $other_user_name = !empty($business_name) ? $business_name : ($other_user->display_name ?: $other_user->user_login);
            } else {
                $other_user_name = $other_user->display_name ?: $other_user->user_login;
            }
            
            // Get other user's avatar
            $profile_image_id = get_user_meta($other_user_id, 'profile_image_id', true);
            if ($profile_image_id && is_numeric($profile_image_id)) {
                $other_user_avatar = wp_get_attachment_image_url($profile_image_id, 'thumbnail');
            }
            if (empty($other_user_avatar)) {
                $other_user_avatar = get_avatar_url($other_user_id, array('size' => 96));
            }
        }
        
        $thread['other_user_avatar'] = $other_user_avatar;
        $thread['other_user_name'] = $other_user_name;
        
        wp_send_json_success(array(
            'messages' => $messages,
            'thread' => $thread
        ));
        
    } catch (Exception $e) {
        error_log('Error in wheelfy_ajax_get_thread_messages: ' . $e->getMessage());
        wp_send_json_error(array('message' => 'An unexpected error occurred. Please try again.'));
    }
}
add_action('wp_ajax_get_thread_messages', 'wheelfy_ajax_get_thread_messages');

/**
 * AJAX: Refresh nonce for AJAX requests
 */
function wheelfy_ajax_refresh_nonce() {
    // Check if user is logged in
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'You must be logged in.'));
    }
    
    // Generate fresh nonce
    $new_nonce = wp_create_nonce('wheelfy_nonce');
    
    wp_send_json_success(array(
        'nonce' => $new_nonce
    ));
}
add_action('wp_ajax_wheelfy_refresh_nonce', 'wheelfy_ajax_refresh_nonce');

/**
 * AJAX: Send message
 */
function wheelfy_ajax_send_message() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_nonce')) {
        wp_send_json_error(array('message' => 'Security check failed.'));
    }
    
    // Check if user is logged in
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'You must be logged in.'));
    }
    
    $user_id = get_current_user_id();
    $thread_id = isset($_POST['thread_id']) ? sanitize_text_field($_POST['thread_id']) : '';
    $message_text = isset($_POST['message_text']) ? sanitize_textarea_field($_POST['message_text']) : '';
    $attachment_ids = isset($_POST['attachment_ids']) ? array_map('intval', $_POST['attachment_ids']) : array();
    $parent_message_id = isset($_POST['parent_message_id']) ? sanitize_text_field($_POST['parent_message_id']) : null;
    
    if (empty($thread_id)) {
        wp_send_json_error(array('message' => 'Thread ID is required.'));
    }
    
    if (empty($message_text) && empty($attachment_ids)) {
        wp_send_json_error(array('message' => 'Message text or attachment is required.'));
    }
    
    // Verify user is part of thread
    $thread = get_option('wheelfy_thread_' . $thread_id, false);
    if (!$thread) {
        wp_send_json_error(array('message' => 'Thread not found.'));
    }
    
    if ($thread['customer_id'] != $user_id && $thread['partner_id'] != $user_id) {
        wp_send_json_error(array('message' => 'Unauthorized.'));
    }
    
    // Validate message for contact information (email, phone, etc.)
    if (!empty($message_text) && function_exists('wheelfy_validate_chat_message')) {
        $validation = wheelfy_validate_chat_message($message_text, $user_id, $thread_id, true);
        if (!$validation['valid']) {
            wp_send_json_error(array(
                'message' => $validation['message'],
                'error_type' => 'contact_info_blocked',
                'pattern_type' => $validation['pattern_type']
            ));
        }
    }
    
    // Validate parent_message_id if provided
    if (!empty($parent_message_id)) {
        $parent_message_id = trim($parent_message_id);
        if (empty($parent_message_id)) {
            $parent_message_id = null;
        }
    } else {
        $parent_message_id = null;
    }
    
    $message_data = wheelfy_send_message($thread_id, $user_id, $message_text, $attachment_ids, $parent_message_id);
    
    if ($message_data) {
        wp_send_json_success(array(
            'message' => 'Message sent successfully.',
            'message_data' => $message_data
        ));
    } else {
        wp_send_json_error(array('message' => 'Failed to send message.'));
    }
}
add_action('wp_ajax_send_message', 'wheelfy_ajax_send_message');

/**
 * AJAX: Delete a single message
 */
function wheelfy_ajax_delete_message() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_nonce')) {
        error_log('Delete message: Security check failed - nonce missing or invalid');
        wp_send_json_error(array('message' => 'Security check failed.'));
    }
    
    // Check if user is logged in
    if (!is_user_logged_in()) {
        error_log('Delete message: User not logged in');
        wp_send_json_error(array('message' => 'You must be logged in.'));
    }
    
    $user_id = get_current_user_id();
    $message_id = isset($_POST['message_id']) ? sanitize_text_field($_POST['message_id']) : '';
    $thread_id = isset($_POST['thread_id']) ? sanitize_text_field($_POST['thread_id']) : '';
    
    error_log('Delete message request - User ID: ' . $user_id . ', Message ID: ' . $message_id . ', Thread ID: ' . $thread_id);
    
    if (empty($message_id) || empty($thread_id)) {
        error_log('Delete message: Missing message_id or thread_id');
        wp_send_json_error(array('message' => 'Message ID and Thread ID are required.'));
    }
    
    // Verify user is part of thread
    $thread = get_option('wheelfy_thread_' . $thread_id, false);
    if (!$thread) {
        error_log('Delete message: Thread not found - Thread ID: ' . $thread_id);
        wp_send_json_error(array('message' => 'Thread not found.'));
    }
    
    if ($thread['customer_id'] != $user_id && $thread['partner_id'] != $user_id) {
        error_log('Delete message: Unauthorized - User ID: ' . $user_id . ' not part of thread');
        wp_send_json_error(array('message' => 'Unauthorized.'));
    }
    
    // Get messages for this thread
    $messages = get_option('wheelfy_messages_' . $thread_id, array());
    if (!is_array($messages)) {
        error_log('Delete message: Messages not found or invalid format');
        wp_send_json_error(array('message' => 'Messages not found.'));
    }
    
    // Find and verify message ownership
    $message_found = false;
    foreach ($messages as &$msg) {
        if (isset($msg['id']) && $msg['id'] === $message_id) {
            // Verify user is the sender
            if (!isset($msg['sender_id']) || $msg['sender_id'] != $user_id) {
                error_log('Delete message: User ' . $user_id . ' tried to delete message from sender ' . (isset($msg['sender_id']) ? $msg['sender_id'] : 'unknown'));
                wp_send_json_error(array('message' => 'You can only delete your own messages.'));
            }
            
            // Soft delete: mark as deleted
            $msg['is_deleted'] = true;
            $msg['deleted_at'] = current_time('mysql');
            $msg['deleted_timestamp'] = current_time('timestamp');
            $message_found = true;
            error_log('Delete message: Message marked as deleted - Message ID: ' . $message_id);
            break;
        }
    }
    
    if (!$message_found) {
        error_log('Delete message: Message not found - Message ID: ' . $message_id);
        wp_send_json_error(array('message' => 'Message not found.'));
    }
    
    // Save updated messages
    $update_result = update_option('wheelfy_messages_' . $thread_id, $messages);
    if ($update_result === false) {
        error_log('Delete message: Failed to update messages in database');
        wp_send_json_error(array('message' => 'Failed to save changes.'));
    }
    
    error_log('Delete message: Success - Message ID: ' . $message_id . ' deleted by User ID: ' . $user_id);
    
    // Return comprehensive delete event data for real-time sync
    wp_send_json_success(array(
        'message' => 'Message deleted successfully.',
        'message_id' => $message_id,
        'thread_id' => $thread_id,
        'deleted_by_user_id' => $user_id,
        'deleted_timestamp' => current_time('timestamp'),
        'deleted_at' => current_time('mysql')
    ));
}
add_action('wp_ajax_delete_message', 'wheelfy_ajax_delete_message');

/**
 * AJAX: Delete a conversation (full chat thread)
 */
function wheelfy_ajax_delete_conversation() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_nonce')) {
        error_log('Delete conversation: Security check failed - nonce missing or invalid');
        wp_send_json_error(array('message' => 'Security check failed.'));
    }
    
    // Check if user is logged in
    if (!is_user_logged_in()) {
        error_log('Delete conversation: User not logged in');
        wp_send_json_error(array('message' => 'You must be logged in.'));
    }
    
    $user_id = get_current_user_id();
    $thread_id = isset($_POST['thread_id']) ? sanitize_text_field($_POST['thread_id']) : '';
    
    error_log('Delete conversation request - User ID: ' . $user_id . ', Thread ID: ' . $thread_id);
    
    if (empty($thread_id)) {
        error_log('Delete conversation: Missing thread_id');
        wp_send_json_error(array('message' => 'Thread ID is required.'));
    }
    
    // Verify user is part of thread
    $thread = get_option('wheelfy_thread_' . $thread_id, false);
    if (!$thread) {
        error_log('Delete conversation: Thread not found - Thread ID: ' . $thread_id);
        wp_send_json_error(array('message' => 'Conversation not found.'));
    }
    
    if ($thread['customer_id'] != $user_id && $thread['partner_id'] != $user_id) {
        error_log('Delete conversation: Unauthorized - User ID: ' . $user_id . ' not part of thread');
        wp_send_json_error(array('message' => 'Unauthorized.'));
    }
    
    // Get both participant IDs
    $customer_id = isset($thread['customer_id']) ? intval($thread['customer_id']) : 0;
    $partner_id = isset($thread['partner_id']) ? intval($thread['partner_id']) : 0;
    $affected_user_ids = array();
    if ($customer_id > 0) $affected_user_ids[] = $customer_id;
    if ($partner_id > 0) $affected_user_ids[] = $partner_id;
    
    // Soft delete: Mark conversation as deleted for this user
    // Store deleted conversation in user meta
    $deleted_conversations = get_user_meta($user_id, 'wheelfy_deleted_conversations', true);
    if (!is_array($deleted_conversations)) {
        $deleted_conversations = array();
    }
    
    // Store deletion timestamp
    $deleted_timestamps = get_user_meta($user_id, 'wheelfy_deleted_conversations_timestamps', true);
    if (!is_array($deleted_timestamps)) {
        $deleted_timestamps = array();
    }
    
    // Add thread_id to deleted list if not already there
    if (!in_array($thread_id, $deleted_conversations)) {
        $deleted_conversations[] = $thread_id;
        $deleted_timestamps[$thread_id] = current_time('timestamp');
        update_user_meta($user_id, 'wheelfy_deleted_conversations', $deleted_conversations);
        update_user_meta($user_id, 'wheelfy_deleted_conversations_timestamps', $deleted_timestamps);
        
        error_log('Delete conversation: Success - Thread ID: ' . $thread_id . ' deleted by User ID: ' . $user_id);
        
        // Get updated conversation count after deletion
        $updated_count = wheelfy_get_messages_received_count($user_id);
        
        wp_send_json_success(array(
            'message' => 'Conversation deleted successfully.',
            'thread_id' => $thread_id,
            'deleted_by_user_id' => $user_id,
            'affected_user_ids' => $affected_user_ids,
            'deleted_timestamp' => current_time('timestamp'),
            'deleted_at' => current_time('mysql'),
            'updated_conversation_count' => $updated_count
        ));
    } else {
        // Already deleted, return success anyway
        error_log('Delete conversation: Already deleted - Thread ID: ' . $thread_id);
        
        // Get updated conversation count
        $updated_count = wheelfy_get_messages_received_count($user_id);
        
        wp_send_json_success(array(
            'message' => 'Conversation already deleted.',
            'thread_id' => $thread_id,
            'deleted_by_user_id' => $user_id,
            'affected_user_ids' => $affected_user_ids,
            'deleted_timestamp' => isset($deleted_timestamps[$thread_id]) ? $deleted_timestamps[$thread_id] : current_time('timestamp'),
            'updated_conversation_count' => $updated_count
        ));
    }
}
add_action('wp_ajax_delete_conversation', 'wheelfy_ajax_delete_conversation');

/**
 * AJAX: Upload file attachment
 */
function wheelfy_ajax_upload_attachment() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_nonce')) {
        wp_send_json_error(array('message' => 'Security check failed.'));
    }
    
    // Check if user is logged in
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'You must be logged in.'));
    }
    
    if (empty($_FILES['attachment'])) {
        wp_send_json_error(array('message' => 'No file uploaded.'));
    }
    
    $file = $_FILES['attachment'];
    
    // Validate file type
    $allowed_types = array(
        'image/jpeg',
        'image/jpg',
        'image/png',
        'image/webp',
        'application/pdf',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/zip'
    );
    
    $file_type = wp_check_filetype($file['name']);
    $mime_type = $file['type'];
    
    if (!in_array($mime_type, $allowed_types)) {
        wp_send_json_error(array('message' => 'File type not allowed.'));
    }
    
    // Validate file size (20MB max)
    $max_size = 20 * 1024 * 1024; // 20MB
    if ($file['size'] > $max_size) {
        wp_send_json_error(array('message' => 'File size exceeds 20MB limit.'));
    }
    
    // Upload file
    require_once(ABSPATH . 'wp-admin/includes/file.php');
    require_once(ABSPATH . 'wp-admin/includes/media.php');
    require_once(ABSPATH . 'wp-admin/includes/image.php');
    
    $upload = wp_handle_upload($file, array('test_form' => false));
    
    if (isset($upload['error'])) {
        wp_send_json_error(array('message' => $upload['error']));
    }
    
    // Create attachment
    $attachment_data = array(
        'post_mime_type' => $upload['type'],
        'post_title' => sanitize_file_name($file['name']),
        'post_content' => '',
        'post_status' => 'inherit'
    );
    
    $attachment_id = wp_insert_attachment($attachment_data, $upload['file']);
    
    if (is_wp_error($attachment_id)) {
        wp_send_json_error(array('message' => 'Failed to create attachment.'));
    }
    
    $attach_data = wp_generate_attachment_metadata($attachment_id, $upload['file']);
    wp_update_attachment_metadata($attachment_id, $attach_data);
    
    wp_send_json_success(array(
        'message' => 'File uploaded successfully.',
        'attachment_id' => $attachment_id,
        'attachment_url' => wp_get_attachment_url($attachment_id),
        'attachment_name' => $file['name']
    ));
}
add_action('wp_ajax_upload_attachment', 'wheelfy_ajax_upload_attachment');

/**
 * Get attachment URL by ID (AJAX)
 */
function wheelfy_ajax_get_attachment_url() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_nonce')) {
        wp_send_json_error(array('message' => 'Security check failed.'));
    }
    
    $attachment_id = isset($_POST['attachment_id']) ? intval($_POST['attachment_id']) : 0;
    
    if ($attachment_id <= 0) {
        wp_send_json_error(array('message' => 'Invalid attachment ID.'));
    }
    
    $url = wp_get_attachment_image_url($attachment_id, 'medium');
    if (!$url) {
        $url = wp_get_attachment_image_url($attachment_id, 'full');
    }
    if (!$url) {
        $url = wp_get_attachment_url($attachment_id);
    }
    
    if ($url) {
        wp_send_json_success(array('url' => $url));
    } else {
        wp_send_json_error(array('message' => 'Attachment not found.'));
    }
}
add_action('wp_ajax_wheelfy_get_attachment_url', 'wheelfy_ajax_get_attachment_url');

/**
 * Create notification when message is sent
 */
function wheelfy_notify_message_sent($message_id, $thread_id, $sender_id, $recipient_id) {
    $sender = get_userdata($sender_id);
    $sender_name = $sender ? ($sender->display_name ?: $sender->user_login) : 'User';
    
    // Check if sender is partner
    if (in_array('partner', $sender->roles)) {
        $business_name = get_user_meta($sender_id, 'business_name', true);
        if (!empty($business_name)) {
            $sender_name = $business_name;
        }
    }
    
    wheelfy_create_notification(
        $recipient_id,
        'message',
        'New Message',
        sprintf('You received a new message from %s.', $sender_name),
        array(
            'link' => home_url('/customer-dashboard#messages'),
            'icon' => 'message',
            'action_text' => 'View Message',
            'related_id' => $thread_id
        )
    );
}
add_action('wheelfy_message_sent', 'wheelfy_notify_message_sent', 10, 4);

/**
 * Send email notification to partner when a new request is received
 */
function wheelfy_send_new_request_email_to_partner($partner_id, $request_id, $form_data, $customer_id = 0, $customer_email = '') {
    // Check if email notifications are enabled for this partner
    $email_notifications_enabled = get_user_meta($partner_id, 'email_notifications_enabled', true);
    if ($email_notifications_enabled === '0') {
        return false; // Email notifications disabled
    }
    
    // Get partner email
    $partner = get_userdata($partner_id);
    if (!$partner) {
        return false;
    }
    
    $partner_email = $partner->user_email;
    if (empty($partner_email)) {
        return false;
    }
    
    // Get customer information
    $customer_name = 'Customer';
    $customer_email_address = $customer_email;
    
    if ($customer_id > 0) {
        $customer = get_userdata($customer_id);
        if ($customer) {
            $customer_name = $customer->display_name ?: $customer->user_login;
            $customer_email_address = $customer->user_email;
        }
    }
    
    // Get partner business name
    $partner_business_name = get_user_meta($partner_id, 'business_name', true);
    $partner_display_name = $partner_business_name ?: $partner->display_name;
    
    // Check if this is a service-based request
    $is_service_request = isset($form_data['request_type']) && $form_data['request_type'] === 'service';
    
    // Prepare email content (HTML)
    if ($is_service_request) {
        // Service-based request
        $service_title = isset($form_data['service_title']) ? $form_data['service_title'] : 'Service Request';
        $subject = sprintf(__('New Service Request Received - %s', 'wheelfy'), $service_title);
    } else {
        // Form-based request (car accessories, etc.)
        $make = isset($form_data['make']) ? $form_data['make'] : '';
        $model = isset($form_data['model']) ? $form_data['model'] : '';
        $vehicle_info = trim($make . ' ' . $model);
        if (empty($vehicle_info)) {
            $vehicle_info = 'Vehicle';
        }
        $subject = sprintf(__('New Service Request Received - %s', 'wheelfy'), $vehicle_info);
    }
    
    // Get site info
    $site_name = get_bloginfo('name');
    $site_url = home_url();
    $site_email = get_option('admin_email');
    
    // Build services list
    $services_list = '';
    if (!empty($form_data['services']) && is_array($form_data['services'])) {
        $services_list = '<ul style="margin: 10px 0; padding-left: 20px;">';
        foreach ($form_data['services'] as $service) {
            $services_list .= '<li>' . esc_html($service) . '</li>';
        }
        $services_list .= '</ul>';
    }
    
    $additional_services = !empty($form_data['additional_services']) ? esc_html($form_data['additional_services']) : '';
    
    // Build email details based on request type
    $email_details = array(
        __('Customer Details:', 'wheelfy') => array(
            __('Name:', 'wheelfy') => esc_html($customer_name),
        ),
    );
    
    if ($is_service_request) {
        // Service-based request details
        $service_title = isset($form_data['service_title']) ? esc_html($form_data['service_title']) : 'Service';
        $service_price = isset($form_data['service_price']) ? floatval($form_data['service_price']) : 0;
        $service_currency = isset($form_data['service_price_currency']) ? $form_data['service_price_currency'] : 'EUR';
        $service_duration = isset($form_data['service_duration']) ? esc_html($form_data['service_duration']) : '';
        $service_category = isset($form_data['service_category']) ? esc_html($form_data['service_category']) : '';
        
        $currency_symbol = ($service_currency === 'HUF') ? 'HUF' : '€';
        $price_display = ($service_currency === 'HUF') ? number_format($service_price, 0, ',', ' ') : number_format($service_price, 2);
        
        $email_details[__('Service Details:', 'wheelfy')] = array(
            __('Service:', 'wheelfy') => $service_title,
            __('Price:', 'wheelfy') => $currency_symbol . $price_display,
            __('Duration:', 'wheelfy') => $service_duration,
            __('Category:', 'wheelfy') => $service_category,
        );
    } else {
        // Form-based request - Vehicle details
        $vehicle_details = array();
        if (isset($form_data['make'])) {
            $vehicle_details[__('Make:', 'wheelfy')] = esc_html($form_data['make']);
        }
        if (isset($form_data['model'])) {
            $vehicle_details[__('Model:', 'wheelfy')] = esc_html($form_data['model']);
        }
        if (isset($form_data['year'])) {
            $vehicle_details[__('Year:', 'wheelfy')] = esc_html($form_data['year']);
        }
        if (isset($form_data['mileage'])) {
            $vehicle_details[__('Mileage:', 'wheelfy')] = esc_html($form_data['mileage']);
        }
        
        if (!empty($vehicle_details)) {
            $email_details[__('Vehicle Details:', 'wheelfy')] = $vehicle_details;
        }
    }
    
    // HTML Email Template
    $message = wheelfy_get_email_template_html(
        sprintf(__('Hello %s,', 'wheelfy'), esc_html($partner_display_name)),
        __('You have received a new service request from a customer.', 'wheelfy'),
        $email_details,
        $services_list,
        $additional_services,
        __('Please log in to your partner dashboard to view and respond to this request.', 'wheelfy'),
        home_url('/partner-dashboard'),
        __('View Dashboard', 'wheelfy'),
        $site_name,
        $site_url
    );
    
    // Set email headers (no customer email in Reply-To for privacy)
    $headers = array(
        'Content-Type: text/html; charset=UTF-8',
        'From: ' . $site_name . ' <' . $site_email . '>',
        'Reply-To: ' . $site_name . ' <' . $site_email . '>'
    );
    
    // Send email
    $sent = wp_mail($partner_email, $subject, $message, $headers);
    
    return $sent;
}

/**
 * Send email notification to customer when their request is accepted
 */
function wheelfy_send_request_accepted_email_to_customer($customer_id, $request_id, $partner_id, $partner_name, $form_data = null) {
    // Check if email notifications are enabled for this customer
    $email_notifications_enabled = get_user_meta($customer_id, 'email_notifications_enabled', true);
    if ($email_notifications_enabled === '0') {
        return false; // Email notifications disabled
    }
    
    // Get customer email
    $customer = get_userdata($customer_id);
    if (!$customer) {
        return false;
    }
    
    $customer_email = $customer->user_email;
    if (empty($customer_email)) {
        return false;
    }
    
    // Get partner information
    $partner = get_userdata($partner_id);
    if (!$partner) {
        return false;
    }
    
    $partner_email = $partner->user_email;
    $partner_business_name = get_user_meta($partner_id, 'business_name', true);
    $partner_display_name = $partner_business_name ?: $partner->display_name;
    
    // Get vehicle details from form_data or request
    $vehicle_info = '';
    if ($form_data && isset($form_data['make']) && isset($form_data['model']) && isset($form_data['year'])) {
        $vehicle_info = $form_data['make'] . ' ' . $form_data['model'] . ' (' . $form_data['year'] . ')';
    } else {
        $vehicle_info = __('your vehicle', 'wheelfy');
    }
    
    // Prepare email content (HTML)
    $subject = sprintf(__('Your Service Request Has Been Accepted - %s', 'wheelfy'), $partner_display_name);
    
    // Get site info
    $site_name = get_bloginfo('name');
    $site_url = home_url();
    $site_email = get_option('admin_email');
    
    $customer_display_name = $customer->display_name ?: $customer->user_login;
    
    // HTML Email Template
    $message = wheelfy_get_email_template_html(
        sprintf(__('Hello %s,', 'wheelfy'), esc_html($customer_display_name)),
        sprintf(__('Great news! Your service request for %s has been accepted by %s.', 'wheelfy'), esc_html($vehicle_info), esc_html($partner_display_name)),
        array(
            __('Partner Details:', 'wheelfy') => array(
                __('Business Name:', 'wheelfy') => esc_html($partner_display_name),
            ),
        ),
        '<ul style="margin: 10px 0; padding-left: 20px;">
            <li>' . __('Chat with the partner directly from your dashboard', 'wheelfy') . '</li>
            <li>' . __('View the request status and updates', 'wheelfy') . '</li>
            <li>' . __('Receive quotes and proposals', 'wheelfy') . '</li>
        </ul>',
        '',
        __('Log in to your dashboard to get started:', 'wheelfy'),
        home_url('/customer-dashboard'),
        __('View Dashboard', 'wheelfy'),
        $site_name,
        $site_url
    );
    
    // Set email headers (no partner email in Reply-To for privacy)
    $headers = array(
        'Content-Type: text/html; charset=UTF-8',
        'From: ' . $site_name . ' <' . $site_email . '>',
        'Reply-To: ' . $site_name . ' <' . $site_email . '>'
    );
    
    // Send email
    $sent = wp_mail($customer_email, $subject, $message, $headers);
    
    return $sent;
}

/**
 * Get HTML Email Template
 * 
 * Creates a beautiful HTML email template for notifications.
 */
function wheelfy_get_email_template_html($greeting, $main_message, $details_array = array(), $services_html = '', $additional_info = '', $cta_text = '', $cta_url = '', $cta_button_text = '', $site_name = '', $site_url = '') {
    if (empty($site_name)) {
        $site_name = get_bloginfo('name');
    }
    if (empty($site_url)) {
        $site_url = home_url();
    }
    
    $template = '
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>' . esc_html($site_name) . '</title>
</head>
<body style="margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, \'Helvetica Neue\', Arial, sans-serif; background-color: #f5f5f5;">
    <table role="presentation" style="width: 100%; border-collapse: collapse; background-color: #f5f5f5; padding: 40px 20px;">
        <tr>
            <td align="center">
                <table role="presentation" style="max-width: 600px; width: 100%; background-color: #ffffff; border-radius: 12px; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1); overflow: hidden;">
                    <tr>
                        <td style="background: linear-gradient(135deg, #f9e79f 0%, #1b4d3e 100%); padding: 40px 30px; text-align: center;">
                            <h1 style="margin: 0; color: #ffffff; font-size: 28px; font-weight: 700; text-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);">' . esc_html($site_name) . '</h1>
                        </td>
                    </tr>
                    <tr>
                        <td style="padding: 40px 30px;">
                            <h2 style="margin: 0 0 20px 0; color: #1a1a1a; font-size: 24px; font-weight: 600;">' . $greeting . '</h2>
                            <p style="margin: 0 0 20px 0; color: #4a4a4a; font-size: 16px; line-height: 1.6;">' . $main_message . '</p>';
    
    if (!empty($details_array)) {
        foreach ($details_array as $section_title => $section_items) {
            $template .= '
                            <div style="background-color: #f8f9fa; border-left: 4px solid #1b4d3e; padding: 20px; margin: 25px 0; border-radius: 4px;">
                                <p style="margin: 0 0 10px 0; color: #1a1a1a; font-size: 15px; font-weight: 600;">' . esc_html($section_title) . '</p>
                                <ul style="margin: 0; padding-left: 20px; color: #4a4a4a; font-size: 15px; line-height: 1.8;">';
            foreach ($section_items as $label => $value) {
                $template .= '<li><strong>' . esc_html($label) . '</strong> ' . $value . '</li>';
            }
            $template .= '</ul></div>';
        }
    }
    
    if (!empty($services_html)) {
        $template .= '<div style="background-color: #f8f9fa; padding: 20px; margin: 25px 0; border-radius: 4px;"><p style="margin: 0 0 10px 0; color: #1a1a1a; font-size: 15px; font-weight: 600;">' . __('Requested Services:', 'wheelfy') . '</p>' . $services_html . '</div>';
    }
    
    if (!empty($additional_info)) {
        $template .= '<div style="background-color: #fff3cd; border-left: 4px solid #ffc107; padding: 15px; margin: 20px 0; border-radius: 4px;"><p style="margin: 0; color: #856404; font-size: 14px; line-height: 1.6;">' . $additional_info . '</p></div>';
    }
    
    if (!empty($cta_text) && !empty($cta_url)) {
        $template .= '<table role="presentation" style="width: 100%; margin: 30px 0;"><tr><td align="center"><p style="margin: 0 0 15px 0; color: #4a4a4a; font-size: 15px;">' . $cta_text . '</p><a href="' . esc_url($cta_url) . '" style="display: inline-block; padding: 14px 32px; background: linear-gradient(135deg, #f9e79f 0%, #1b4d3e 100%); color: #ffffff; text-decoration: none; border-radius: 6px; font-size: 16px; font-weight: 600; box-shadow: 0 4px 12px rgba(27, 77, 62, 0.3);">' . (!empty($cta_button_text) ? esc_html($cta_button_text) : __('View Dashboard', 'wheelfy')) . '</a></td></tr></table>';
    }
    
    $template .= '<p style="margin: 25px 0 0 0; color: #666666; font-size: 14px; line-height: 1.6;">' . __('Best regards,', 'wheelfy') . '<br><strong>' . esc_html($site_name) . ' ' . __('Team', 'wheelfy') . '</strong></p></td></tr><tr><td style="background-color: #f8f9fa; padding: 30px; text-align: center; border-top: 1px solid #e9ecef;"><p style="margin: 0 0 10px 0; color: #666666; font-size: 13px;"><a href="' . esc_url($site_url) . '" style="color: #1b4d3e; text-decoration: none;">' . esc_html($site_name) . '</a></p></td></tr></table></td></tr></table></body></html>';
    
    return $template;
}

/**
 * Send email notification to customer when request is completed
 */
function wheelfy_send_request_completed_email_to_customer($customer_id, $request_id, $partner_id, $partner_name, $vehicle_info = '') {
    $email_notifications_enabled = get_user_meta($customer_id, 'email_notifications_enabled', true);
    if ($email_notifications_enabled === '0') {
        return false;
    }
    
    $customer = get_userdata($customer_id);
    if (!$customer || empty($customer->user_email)) {
        return false;
    }
    
    $site_name = get_bloginfo('name');
    $site_email = get_option('admin_email');
    $vehicle_display = !empty($vehicle_info) ? esc_html($vehicle_info) : __('your vehicle', 'wheelfy');
    
    $subject = sprintf(__('Service Request Completed - %s', 'wheelfy'), $site_name);
    
    $message = wheelfy_get_email_template_html(
        sprintf(__('Hello %s,', 'wheelfy'), esc_html($customer->display_name ?: $customer->user_login)),
        sprintf(__('Great news! Your service request for %s has been completed by %s.', 'wheelfy'), $vehicle_display, esc_html($partner_name)),
        array(
            __('Service Details:', 'wheelfy') => array(
                __('Partner:', 'wheelfy') => esc_html($partner_name),
                __('Status:', 'wheelfy') => '<strong style="color: #28a745;">' . __('Completed', 'wheelfy') . '</strong>',
            ),
        ),
        '',
        __('You can now view the completed request in your dashboard and leave a review for the partner.', 'wheelfy'),
        __('View your completed request:', 'wheelfy'),
        home_url('/customer-dashboard#requests'),
        __('View Dashboard', 'wheelfy'),
        $site_name,
        home_url()
    );
    
    $headers = array(
        'Content-Type: text/html; charset=UTF-8',
        'From: ' . $site_name . ' <' . $site_email . '>'
    );
    
    return wp_mail($customer->user_email, $subject, $message, $headers);
}

/**
 * Send email notification to partner when request is completed
 */
function wheelfy_send_request_completed_email_to_partner($partner_id, $request_id, $customer_id, $customer_name, $vehicle_info = '') {
    $email_notifications_enabled = get_user_meta($partner_id, 'email_notifications_enabled', true);
    if ($email_notifications_enabled === '0') {
        return false;
    }
    
    $partner = get_userdata($partner_id);
    if (!$partner || empty($partner->user_email)) {
        return false;
    }
    
    $partner_business_name = get_user_meta($partner_id, 'business_name', true);
    $partner_display_name = $partner_business_name ?: $partner->display_name;
    $site_name = get_bloginfo('name');
    $site_email = get_option('admin_email');
    $vehicle_display = !empty($vehicle_info) ? esc_html($vehicle_info) : __('the vehicle', 'wheelfy');
    
    $subject = sprintf(__('Request Completed - %s', 'wheelfy'), $site_name);
    
    $message = wheelfy_get_email_template_html(
        sprintf(__('Hello %s,', 'wheelfy'), esc_html($partner_display_name)),
        sprintf(__('Congratulations! The service request from %s for %s has been marked as completed.', 'wheelfy'), esc_html($customer_name), $vehicle_display),
        array(
            __('Request Details:', 'wheelfy') => array(
                __('Customer:', 'wheelfy') => esc_html($customer_name),
                __('Vehicle:', 'wheelfy') => $vehicle_display,
                __('Status:', 'wheelfy') => '<strong style="color: #28a745;">' . __('Completed', 'wheelfy') . '</strong>',
            ),
        ),
        '',
        __('The customer has been notified. You can view the completed request in your dashboard.', 'wheelfy'),
        __('View your dashboard:', 'wheelfy'),
        home_url('/partner-dashboard#requests'),
        __('View Dashboard', 'wheelfy'),
        $site_name,
        home_url()
    );
    
    $headers = array(
        'Content-Type: text/html; charset=UTF-8',
        'From: ' . $site_name . ' <' . $site_email . '>'
    );
    
    return wp_mail($partner->user_email, $subject, $message, $headers);
}

/**
 * Admin AJAX: Accept request
 */
function wheelfy_accept_request() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_request_action')) {
        wp_send_json_error(array('message' => 'Security check failed.'));
    }
    
    // Check user permissions
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'You do not have permission to perform this action.'));
    }
    
    $post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;
    
    if ($post_id <= 0) {
        wp_send_json_error(array('message' => 'Invalid request ID.'));
    }
    
    // Check if post exists
    $post = get_post($post_id);
    if (!$post) {
        wp_send_json_error(array('message' => 'Request not found.'));
    }
    
    // Update proposal status to accepted
    update_post_meta($post_id, '_proposal_status', 'accepted');
    
    // Fire action hook for other plugins/themes to hook into
    do_action('wheelfy_admin_request_accepted', $post_id);
    
    wp_send_json_success(array(
        'message' => __('Request accepted successfully.', 'wheelfy')
    ));
}
add_action('wp_ajax_wheelfy_accept_request', 'wheelfy_accept_request');

/**
 * Admin AJAX: Delete request
 */
function wheelfy_delete_request() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_request_action')) {
        wp_send_json_error(array('message' => 'Security check failed.'));
    }
    
    // Check user permissions
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'You do not have permission to perform this action.'));
    }
    
    $post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;
    
    if ($post_id <= 0) {
        wp_send_json_error(array('message' => 'Invalid request ID.'));
    }
    
    // Check if post exists
    $post = get_post($post_id);
    if (!$post) {
        wp_send_json_error(array('message' => 'Request not found.'));
    }
    
    // Trash the post instead of permanently deleting
    wp_trash_post($post_id);
    
    // Fire action hook for other plugins/themes to hook into
    do_action('wheelfy_admin_request_deleted', $post_id);
    
    wp_send_json_success(array(
        'message' => __('Request deleted successfully.', 'wheelfy')
    ));
}
add_action('wp_ajax_wheelfy_delete_request', 'wheelfy_delete_request');

/**
 * Partner AJAX: Mark Request as Complete (Pending Customer/Admin Confirmation)
 */
function wheelfy_ajax_complete_request() {
    // Suppress PHP errors/warnings from corrupting JSON response
    @ini_set('display_errors', 0);
    error_reporting(0);
    
    // Clean any previous output
    while (ob_get_level()) {
        ob_end_clean();
    }
    ob_start();
    
    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_nonce')) {
        ob_end_clean();
        wp_send_json_error(array('message' => 'Security check failed.'));
    }
    
    // Check if user is logged in and is a partner
    if (!is_user_logged_in()) {
        ob_end_clean();
        wp_send_json_error(array('message' => 'You must be logged in.'));
    }
    
    $current_user = wp_get_current_user();
    if (!in_array('partner', $current_user->roles)) {
        ob_end_clean();
        wp_send_json_error(array('message' => 'Unauthorized. Only partners can complete requests.'));
    }
    
    $request_id = isset($_POST['request_id']) ? sanitize_text_field($_POST['request_id']) : '';
    if (empty($request_id)) {
        ob_end_clean();
        wp_send_json_error(array('message' => 'Request ID is required.'));
    }
    
    $partner_id = $current_user->ID;
    
    // Find the request in partner's requests
    $partner_requests = wheelfy_get_partner_requests_data($partner_id, 'all');
    $request_found = false;
    $customer_id = 0;
    $customer_email = '';
    $customer_name = '';
    $request_details = '';
    
    // Extract actual request_id from the format: {request_id}_partner_{partner_id}
    $actual_request_id = $request_id;
    if (strpos($request_id, '_partner_') !== false) {
        $parts = explode('_partner_', $request_id);
        $actual_request_id = $parts[0];
    }
    
    foreach ($partner_requests as $req) {
        if (($req['id'] === $request_id || $req['request_id'] === $actual_request_id) && ($req['status'] === 'accepted' || $req['status'] === 'in_progress' || $req['status'] === 'in-progress')) {
            $request_found = true;
            $customer_id = isset($req['customer_id']) ? intval($req['customer_id']) : 0;
            $customer_email = isset($req['customer_email']) ? $req['customer_email'] : '';
            $customer_name = isset($req['customer_name']) ? $req['customer_name'] : '';
            $request_details = isset($req['request_details']) ? $req['request_details'] : '';
            $actual_request_id = isset($req['request_id']) ? $req['request_id'] : $actual_request_id;
            break;
        }
    }
    
    if (!$request_found) {
        ob_end_clean();
        wp_send_json_error(array('message' => 'Request not found or not in accepted/in progress status.'));
    }
    
    // Update transient status first
    $transient_key = 'car_accessories_request_' . $actual_request_id . '_partner_' . $partner_id;
    $form_data = get_transient($transient_key);
    if ($form_data && is_array($form_data)) {
        $form_data['status'] = 'pending_completion';
        $form_data['completion_requested_date'] = current_time('mysql');
        $form_data['completion_requested_by'] = $partner_id;
        set_transient($transient_key, $form_data, HOUR_IN_SECONDS * 24 * 7); // 7 days
    }
    
    // Update request status to pending_completion in posts
    // Check if request is stored in posts
    $post_id = 0;
    $args = array(
        'post_type' => 'post',
        'posts_per_page' => -1,
        'post_status' => 'publish',
        'meta_query' => array(
            array(
                'key' => '_proposal_request_type',
                'compare' => 'EXISTS',
            ),
        ),
    );
    $posts = get_posts($args);
    foreach ($posts as $post) {
        $post_request_id = get_post_meta($post->ID, '_proposal_request_id', true);
        $post_partner_id = get_post_meta($post->ID, 'partner_id', true);
        
        // Match by request_id or by customer email/name
        $post_status = get_post_meta($post->ID, '_proposal_status', true);
        if ($post_request_id === $actual_request_id || 
            ($post_partner_id == $partner_id && 
             get_post_meta($post->ID, '_proposal_email', true) === $customer_email &&
             ($post_status === 'accepted' || $post_status === 'in_progress' || $post_status === 'in-progress'))) {
            $post_id = $post->ID;
            update_post_meta($post_id, '_proposal_status', 'pending_completion');
            update_post_meta($post_id, '_proposal_completion_requested_date', current_time('mysql'));
            update_post_meta($post_id, '_proposal_completion_requested_by', $partner_id);
            update_post_meta($post_id, '_proposal_request_id', $actual_request_id);
            update_post_meta($post_id, 'partner_id', $partner_id);
            break;
        }
    }
    
    // NOTE: Don't create new posts here - this was causing duplicates
    // Transient and user meta are the source of truth for customer/partner dashboards
    // Posts are only for admin visibility and should be created during initial form submission
    
    // Also update in customer's user meta if exists (check both meta keys)
    if ($customer_id > 0) {
        // Check wheelfy_service_requests first
        $customer_requests = get_user_meta($customer_id, 'wheelfy_service_requests', true);
        if (is_array($customer_requests)) {
            $updated = false;
            foreach ($customer_requests as $index => $req) {
                $req_id = isset($req['request_id']) ? $req['request_id'] : '';
                $req_partner = isset($req['partner_id']) ? intval($req['partner_id']) : 0;
                // Check multiple ID formats
                if (($req_id === $actual_request_id || $req_id === $request_id) && $req_partner == $partner_id) {
                    $customer_requests[$index]['status'] = 'pending_completion';
                    $customer_requests[$index]['completion_requested_date'] = current_time('mysql');
                    $updated = true;
                    break;
                }
            }
            if ($updated) {
                update_user_meta($customer_id, 'wheelfy_service_requests', $customer_requests);
            }
        }
        
        // Also check customer_service_requests
        $customer_requests2 = get_user_meta($customer_id, 'customer_service_requests', true);
        if (is_array($customer_requests2)) {
            $updated = false;
            foreach ($customer_requests2 as $index => $req) {
                $req_id = isset($req['request_id']) ? $req['request_id'] : '';
                $req_partner = isset($req['partner_id']) ? intval($req['partner_id']) : 0;
                // Check multiple ID formats - match by request_id AND (partner matches OR partner was 0)
                $id_match = ($req_id === $actual_request_id || $req_id === $request_id);
                $partner_match = ($req_partner == $partner_id) || ($req_partner == 0);
                
                if ($id_match && $partner_match) {
                    $customer_requests2[$index]['status'] = 'pending_completion';
                    $customer_requests2[$index]['completion_requested_date'] = current_time('mysql');
                    $customer_requests2[$index]['partner_id'] = $partner_id; // Ensure partner_id is set
                    $updated = true;
                    break;
                }
            }
            if ($updated) {
                update_user_meta($customer_id, 'customer_service_requests', $customer_requests2);
            }
        }
    }
    
    // Get partner name for notifications
    $partner_name = get_user_meta($partner_id, 'business_name', true);
    if (empty($partner_name)) {
        $partner_user = get_userdata($partner_id);
        $partner_name = $partner_user ? ($partner_user->display_name ?: $partner_user->user_login) : 'Partner';
    }
    
    // Check if this is a new workflow request (v2)
    // Check multiple sources: transient, customer user meta, and post meta
    $is_new_workflow = false;
    $offer_price_found = 0;
    
    // Check 1: From transient form_data
    if ($form_data && is_array($form_data)) {
        if ((isset($form_data['workflow_version']) && $form_data['workflow_version'] === 'v2') ||
            (isset($form_data['offer_price']) && floatval($form_data['offer_price']) > 0)) {
            $is_new_workflow = true;
            $offer_price_found = isset($form_data['offer_price']) ? floatval($form_data['offer_price']) : 0;
        }
    }
    
    // Check 2: From customer's user meta if not found in transient
    if (!$is_new_workflow && $customer_id > 0) {
        $customer_requests = get_user_meta($customer_id, 'customer_service_requests', true);
        if (is_array($customer_requests)) {
            foreach ($customer_requests as $req) {
                $req_id = isset($req['request_id']) ? $req['request_id'] : '';
                $req_partner = isset($req['partner_id']) ? intval($req['partner_id']) : 0;
                if (($req_id === $actual_request_id || $req_id === $request_id) && $req_partner == $partner_id) {
                    if ((isset($req['workflow_version']) && $req['workflow_version'] === 'v2') ||
                        (isset($req['offer_price']) && floatval($req['offer_price']) > 0)) {
                        $is_new_workflow = true;
                        $offer_price_found = isset($req['offer_price']) ? floatval($req['offer_price']) : 0;
                    }
                    break;
                }
            }
        }
    }
    
    // Check 3: From post meta if still not found
    if (!$is_new_workflow && $post_id > 0) {
        $post_offer_price = get_post_meta($post_id, '_proposal_offer_price', true);
        $post_workflow = get_post_meta($post_id, '_proposal_workflow_version', true);
        if ($post_workflow === 'v2' || (floatval($post_offer_price) > 0)) {
            $is_new_workflow = true;
            $offer_price_found = floatval($post_offer_price);
        }
    }
    
    // FORCE new workflow for ALL new requests (since we now require price)
    // If request was created after the new workflow implementation, it should use new workflow
    // The simplest check: if customer_id > 0, assume new workflow
    if (!$is_new_workflow && $customer_id > 0) {
        // Default to new workflow for requests with valid customer
        $is_new_workflow = true;
    }
    
    // NEW WORKFLOW: Notify customer for confirmation (instead of admin)
    if ($is_new_workflow && $customer_id > 0) {
        // Create notification for customer
        wheelfy_create_notification(
            $customer_id,
            'completion_pending',
            __('Service Completion Confirmation Required', 'wheelfy'),
            sprintf(__('%s has completed your service request. Please confirm the completion.', 'wheelfy'), $partner_name),
            array(
                'link' => home_url('/customer-dashboard#requests'),
                'icon' => 'request_completed',
                'action_text' => 'Confirm Completion',
                'request_id' => $request_id,
                'partner_id' => $partner_id,
                'partner_name' => $partner_name,
            )
        );
        
        // Send email to customer
        wheelfy_send_completion_request_email_to_customer($customer_id, $request_id, $partner_id, $partner_name, $form_data);
        
        ob_end_clean();
        wp_send_json_success(array(
            'message' => __('Request marked as complete. Waiting for customer confirmation.', 'wheelfy')
        ));
        return; // Ensure we stop here
    }
    
    // LEGACY WORKFLOW: Notify admin for confirmation (backward compatibility)
    // Only for old workflow requests (without offer_price)
    if (!$is_new_workflow) {
        $admin_users = get_users(array('role' => 'administrator'));
        if (!empty($admin_users)) {
            $admin = $admin_users[0]; // Get first admin
            
            wheelfy_create_notification(
                $admin->ID,
                'request_completion_pending',
                __('Request Completion Pending', 'wheelfy'),
                sprintf(__('Partner %s has marked a request as complete and is waiting for your confirmation.', 'wheelfy'), $partner_name),
                array(
                    'link' => admin_url('admin.php?page=wheelfy-request&tab=all&status=pending_completion'),
                    'icon' => 'request_completed',
                    'action_text' => 'View Request',
                    'request_id' => $request_id,
                    'partner_id' => $partner_id,
                    'partner_name' => $partner_name,
                    'customer_id' => $customer_id,
                    'customer_name' => $customer_name,
                )
            );
        }
        
        ob_end_clean();
        wp_send_json_success(array(
            'message' => __('Request marked as complete. Waiting for admin confirmation.', 'wheelfy')
        ));
        return;
    }
    
    // Fallback - if customer_id is 0 for new workflow, notify admin
    $admin_users = get_users(array('role' => 'administrator'));
    if (!empty($admin_users)) {
        $admin = $admin_users[0];
        wheelfy_create_notification(
            $admin->ID,
            'request_completion_pending',
            __('Request Completion Pending', 'wheelfy'),
            sprintf(__('Partner %s has marked a request as complete. Customer could not be notified.', 'wheelfy'), $partner_name),
            array(
                'link' => admin_url('admin.php?page=wheelfy-request&tab=all&status=pending_completion'),
                'request_id' => $request_id,
                'partner_id' => $partner_id,
            )
        );
    }
    
    ob_end_clean();
    wp_send_json_success(array(
        'message' => __('Request marked as complete.', 'wheelfy')
    ));
}
add_action('wp_ajax_wheelfy_complete_request', 'wheelfy_ajax_complete_request');

/**
 * Partner AJAX: Mark Request as In Progress
 */
function wheelfy_ajax_mark_in_progress() {
    // Suppress PHP errors from corrupting JSON
    @ini_set('display_errors', 0);
    error_reporting(0);
    while (ob_get_level()) ob_end_clean();
    ob_start();
    
    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_nonce')) {
        ob_end_clean();
        wp_send_json_error(array('message' => 'Security check failed.'));
    }
    
    // Check if user is logged in and is a partner
    if (!is_user_logged_in()) {
        ob_end_clean();
        wp_send_json_error(array('message' => 'You must be logged in.'));
    }
    
    $current_user = wp_get_current_user();
    if (!in_array('partner', $current_user->roles)) {
        ob_end_clean();
        wp_send_json_error(array('message' => 'Unauthorized. Only partners can mark requests as in progress.'));
    }
    
    $request_id = isset($_POST['request_id']) ? sanitize_text_field($_POST['request_id']) : '';
    if (empty($request_id)) {
        ob_end_clean();
        wp_send_json_error(array('message' => 'Request ID is required.'));
    }
    
    $partner_id = $current_user->ID;
    
    // Extract actual request_id from the format: {request_id}_partner_{partner_id}
    $actual_request_id = $request_id;
    if (strpos($request_id, '_partner_') !== false) {
        $parts = explode('_partner_', $request_id);
        $actual_request_id = $parts[0];
    }
    
    // Find the request in partner's requests
    $partner_requests = wheelfy_get_partner_requests_data($partner_id, 'all');
    $request_found = false;
    $customer_id = 0;
    $customer_email = '';
    $customer_name = '';
    $request_details = '';
    
    foreach ($partner_requests as $req) {
        if (($req['id'] === $request_id || $req['request_id'] === $actual_request_id) && $req['status'] === 'accepted') {
            $request_found = true;
            $customer_id = isset($req['customer_id']) ? intval($req['customer_id']) : 0;
            $customer_email = isset($req['customer_email']) ? $req['customer_email'] : '';
            $customer_name = isset($req['customer_name']) ? $req['customer_name'] : '';
            $request_details = isset($req['request_details']) ? $req['request_details'] : '';
            $actual_request_id = isset($req['request_id']) ? $req['request_id'] : $actual_request_id;
            break;
        }
    }
    
    if (!$request_found) {
        wp_send_json_error(array('message' => 'Request not found or not in accepted status.'));
    }
    
    // Update transient status first
    $transient_key = 'car_accessories_request_' . $actual_request_id . '_partner_' . $partner_id;
    $form_data = get_transient($transient_key);
    if ($form_data && is_array($form_data)) {
        $form_data['status'] = 'in_progress';
        $form_data['in_progress_date'] = current_time('mysql');
        $form_data['in_progress_by'] = $partner_id;
        set_transient($transient_key, $form_data, HOUR_IN_SECONDS * 24 * 7); // 7 days
    }
    
    // Update request status to in_progress in posts
    $post_id = 0;
    $args = array(
        'post_type' => 'post',
        'posts_per_page' => -1,
        'post_status' => 'publish',
        'meta_query' => array(
            array(
                'key' => '_proposal_request_type',
                'compare' => 'EXISTS',
            ),
        ),
    );
    $posts = get_posts($args);
    foreach ($posts as $post) {
        $post_request_id = get_post_meta($post->ID, '_proposal_request_id', true);
        $post_partner_id = get_post_meta($post->ID, 'partner_id', true);
        
        if ($post_request_id === $actual_request_id || 
            ($post_partner_id == $partner_id && 
             get_post_meta($post->ID, '_proposal_email', true) === $customer_email &&
             get_post_meta($post->ID, '_proposal_status', true) === 'accepted')) {
            $post_id = $post->ID;
            update_post_meta($post_id, '_proposal_status', 'in_progress');
            update_post_meta($post_id, '_proposal_in_progress_date', current_time('mysql'));
            update_post_meta($post_id, '_proposal_in_progress_by', $partner_id);
            update_post_meta($post_id, '_proposal_request_id', $actual_request_id);
            update_post_meta($post_id, 'partner_id', $partner_id);
            break;
        }
    }
    
    // NOTE: Don't create new posts here - this was causing duplicates
    // Posts are only created during initial form submission or by admin
    // Transient data is the source of truth for partner workflows
    
    // Update in customer's user meta if exists (both meta keys)
    if ($customer_id > 0) {
        // Update wheelfy_service_requests
        $customer_requests = get_user_meta($customer_id, 'wheelfy_service_requests', true);
        if (is_array($customer_requests)) {
            foreach ($customer_requests as $index => $req) {
                if ((isset($req['request_id']) && ($req['request_id'] === $actual_request_id || $req['request_id'] === $request_id)) && 
                    isset($req['partner_id']) && intval($req['partner_id']) == $partner_id) {
                    $customer_requests[$index]['status'] = 'in_progress';
                    $customer_requests[$index]['in_progress_date'] = current_time('mysql');
                    break;
                }
            }
            update_user_meta($customer_id, 'wheelfy_service_requests', $customer_requests);
        }
        
        // Also update customer_service_requests
        $customer_requests2 = get_user_meta($customer_id, 'customer_service_requests', true);
        if (is_array($customer_requests2)) {
            foreach ($customer_requests2 as $index => $req) {
                $req_id = isset($req['request_id']) ? $req['request_id'] : '';
                $req_partner = isset($req['partner_id']) ? intval($req['partner_id']) : 0;
                if (($req_id === $actual_request_id || $req_id === $request_id) && $req_partner == $partner_id) {
                    $customer_requests2[$index]['status'] = 'in_progress';
                    $customer_requests2[$index]['in_progress_date'] = current_time('mysql');
                    break;
                }
            }
            update_user_meta($customer_id, 'customer_service_requests', $customer_requests2);
        }
    }
    
    // Send notification to customer
    if ($customer_id > 0) {
        $partner_name = get_user_meta($partner_id, 'business_name', true);
        if (empty($partner_name)) {
            $partner_user = get_userdata($partner_id);
            $partner_name = $partner_user ? ($partner_user->display_name ?: $partner_user->user_login) : 'Partner';
        }
        
        wheelfy_create_notification(
            $customer_id,
            'request_in_progress',
            __('Request In Progress', 'wheelfy'),
            sprintf(__('Partner %s has started working on your service request.', 'wheelfy'), $partner_name),
            array(
                'link' => home_url('/customer-dashboard#requests'),
                'icon' => 'request_in_progress',
                'action_text' => 'View Request',
                'request_id' => $actual_request_id,
                'partner_id' => $partner_id,
                'partner_name' => $partner_name,
            )
        );
    }
    
    if (ob_get_level()) ob_end_clean();
    wp_send_json_success(array(
        'message' => __('Request marked as in progress. Customer has been notified.', 'wheelfy')
    ));
}
add_action('wp_ajax_wheelfy_mark_in_progress', 'wheelfy_ajax_mark_in_progress');

/**
 * Admin AJAX: Confirm Request Completion
 */
function wheelfy_ajax_confirm_completion() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_request_action')) {
        wp_send_json_error(array('message' => 'Security check failed.'));
    }
    
    // Check user permissions
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'You do not have permission to perform this action.'));
    }
    
    $post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;
    
    if ($post_id <= 0) {
        wp_send_json_error(array('message' => 'Invalid request ID.'));
    }
    
    // Check if post exists
    $post = get_post($post_id);
    if (!$post) {
        wp_send_json_error(array('message' => 'Request not found.'));
    }
    
    // Get request details
    $status = get_post_meta($post_id, '_proposal_status', true);
    if ($status !== 'pending_completion') {
        wp_send_json_error(array('message' => 'Request is not pending completion.'));
    }
    
    // Get customer and partner info
    $customer_email = get_post_meta($post_id, '_proposal_email', true);
    $customer_name = get_post_meta($post_id, '_proposal_full_name', true);
    $partner_id = get_post_meta($post_id, '_proposal_completion_requested_by', true);
    
    // Update status to complete
    update_post_meta($post_id, '_proposal_status', 'complete');
    update_post_meta($post_id, '_proposal_completed_date', current_time('mysql'));
    update_post_meta($post_id, '_proposal_completed_by', get_current_user_id());
    
    // Send notification to customer if logged in
    if (!empty($customer_email)) {
        $customer_user = get_user_by('email', $customer_email);
        if ($customer_user) {
            $partner_name = 'Partner';
            if ($partner_id > 0) {
                $partner_user = get_userdata($partner_id);
                if ($partner_user) {
                    $business_name = get_user_meta($partner_id, 'business_name', true);
                    $partner_name = !empty($business_name) ? $business_name : ($partner_user->display_name ?: $partner_user->user_login);
                }
            }
            
            wheelfy_create_notification(
                $customer_user->ID,
                'request_completed',
                __('Request Completed', 'wheelfy'),
                sprintf(__('Your service request has been completed by %s.', 'wheelfy'), $partner_name),
                array(
                    'link' => home_url('/customer-dashboard#requests'),
                    'icon' => 'request_completed',
                    'action_text' => 'View Request',
                    'request_id' => $post_id,
                    'partner_id' => $partner_id,
                    'partner_name' => $partner_name,
                )
            );
        }
    }
    
    // Send email notifications to customer and partner
    if ($customer_id > 0 || !empty($customer_email)) {
        $customer_user_id = $customer_id;
        if (empty($customer_user_id) && !empty($customer_email)) {
            $customer_user_obj = get_user_by('email', $customer_email);
            $customer_user_id = $customer_user_obj ? $customer_user_obj->ID : 0;
        }
        
        if ($customer_user_id > 0) {
            // Get partner info
            $partner_name = 'Partner';
            if ($partner_id > 0) {
                $partner_user = get_userdata($partner_id);
                if ($partner_user) {
                    $business_name = get_user_meta($partner_id, 'business_name', true);
                    $partner_name = !empty($business_name) ? $business_name : ($partner_user->display_name ?: $partner_user->user_login);
                }
            }
            
            // Get vehicle info from post meta
            $vehicle_info = '';
            $car_brand = get_post_meta($post_id, '_proposal_car_brand', true);
            $car_model = get_post_meta($post_id, '_proposal_car_model', true);
            $car_year = get_post_meta($post_id, '_proposal_car_year', true);
            if ($car_brand && $car_model) {
                $vehicle_info = $car_brand . ' ' . $car_model . ($car_year ? ' (' . $car_year . ')' : '');
            }
            
            // Send email to customer
            wheelfy_send_request_completed_email_to_customer($customer_user_id, $post_id, $partner_id, $partner_name, $vehicle_info);
        }
    }
    
    // Send email to partner
    if ($partner_id > 0) {
        $customer_name = 'Customer';
        if ($customer_id > 0) {
            $customer_user = get_userdata($customer_id);
            if ($customer_user) {
                $customer_name = $customer_user->display_name ?: $customer_user->user_login;
            }
        }
        // Don't use customer email as name for privacy
        
        $vehicle_info = '';
        $car_brand = get_post_meta($post_id, '_proposal_car_brand', true);
        $car_model = get_post_meta($post_id, '_proposal_car_model', true);
        $car_year = get_post_meta($post_id, '_proposal_car_year', true);
        if ($car_brand && $car_model) {
            $vehicle_info = $car_brand . ' ' . $car_model . ($car_year ? ' (' . $car_year . ')' : '');
        }
        
        wheelfy_send_request_completed_email_to_partner($partner_id, $post_id, $customer_id, $customer_name, $vehicle_info);
    }
    
    // Fire action hook
    do_action('wheelfy_request_completed', $post_id, $partner_id);
    
    wp_send_json_success(array(
        'message' => __('Request completion confirmed. Customer and partner have been notified.', 'wheelfy')
    ));
}
add_action('wp_ajax_wheelfy_confirm_completion', 'wheelfy_ajax_confirm_completion');

/**
 * ============================================================================
 * NEW WORKFLOW FUNCTIONS (V2)
 * ============================================================================
 * These functions implement the new request workflow where:
 * 1. Partner accepts with price/note → waiting_customer_approval
 * 2. Customer approves offer → accepted (chat created)
 * 3. Partner starts work → in_progress
 * 4. Partner marks complete → pending_completion (customer pending)
 * 5. Customer confirms completion → complete
 */

/**
 * Helper: Format price with currency
 */
function wheelfy_format_price($price, $currency = '') {
    if (empty($currency)) {
        // Get default currency from theme options or use EUR
        $currency = get_option('wheelfy_default_currency', 'EUR');
    }
    
    $formatted = number_format(floatval($price), 0, '.', ' ');
    
    if ($currency === 'HUF' || $currency === 'Ft') {
        return $formatted . ' Ft';
    }
    
    return '€' . $formatted;
}

/**
 * Send email to customer when partner sends an offer
 */
function wheelfy_send_partner_offer_email_to_customer($customer_id, $request_id, $partner_id, $partner_name, $offer_price, $offer_note, $form_data = null) {
    $email_notifications_enabled = get_user_meta($customer_id, 'email_notifications_enabled', true);
    if ($email_notifications_enabled === '0') {
        return false;
    }
    
    $customer = get_userdata($customer_id);
    if (!$customer || empty($customer->user_email)) {
        return false;
    }
    
    $site_name = get_bloginfo('name');
    $site_email = get_option('admin_email');
    
    // Get vehicle info if available
    $vehicle_info = '';
    if ($form_data && isset($form_data['make']) && isset($form_data['model'])) {
        $vehicle_info = $form_data['make'] . ' ' . $form_data['model'];
        if (isset($form_data['year'])) {
            $vehicle_info .= ' (' . $form_data['year'] . ')';
        }
    }
    
    $subject = sprintf(__('[%s] New Offer from %s', 'wheelfy'), $site_name, $partner_name);
    
    $message = wheelfy_get_email_template_html(
        sprintf(__('New Offer from %s', 'wheelfy'), esc_html($partner_name)),
        sprintf(__('You have received a new offer for your service request%s.', 'wheelfy'), $vehicle_info ? ' for ' . $vehicle_info : ''),
        array(
            __('Offer Details:', 'wheelfy') => array(
                __('Partner:', 'wheelfy') => esc_html($partner_name),
                __('Price:', 'wheelfy') => '<strong style="color: #28a745;">' . wheelfy_format_price($offer_price) . '</strong>',
                __('Note:', 'wheelfy') => !empty($offer_note) ? esc_html($offer_note) : __('No additional notes', 'wheelfy'),
            ),
        ),
        '',
        __('Please review this offer and approve it to proceed with the service.', 'wheelfy'),
        __('View and approve the offer:', 'wheelfy'),
        home_url('/customer-dashboard#requests'),
        __('View Offer', 'wheelfy'),
        $site_name,
        home_url()
    );
    
    $headers = array(
        'Content-Type: text/html; charset=UTF-8',
        'From: ' . $site_name . ' <' . $site_email . '>'
    );
    
    return wp_mail($customer->user_email, $subject, $message, $headers);
}

/**
 * Send email to partner when customer approves their offer
 */
function wheelfy_send_offer_approved_email_to_partner($partner_id, $request_id, $customer_id, $customer_name, $offer_price, $form_data = null) {
    $email_notifications_enabled = get_user_meta($partner_id, 'email_notifications_enabled', true);
    if ($email_notifications_enabled === '0') {
        return false;
    }
    
    $partner = get_userdata($partner_id);
    if (!$partner || empty($partner->user_email)) {
        return false;
    }
    
    $site_name = get_bloginfo('name');
    $site_email = get_option('admin_email');
    
    // Get vehicle info if available
    $vehicle_info = '';
    if ($form_data && isset($form_data['make']) && isset($form_data['model'])) {
        $vehicle_info = $form_data['make'] . ' ' . $form_data['model'];
        if (isset($form_data['year'])) {
            $vehicle_info .= ' (' . $form_data['year'] . ')';
        }
    }
    
    $subject = sprintf(__('[%s] Offer Approved by %s', 'wheelfy'), $site_name, $customer_name);
    
    $message = wheelfy_get_email_template_html(
        __('Your Offer Has Been Approved!', 'wheelfy'),
        sprintf(__('%s has approved your offer%s. You can now start working on this request.', 'wheelfy'), esc_html($customer_name), $vehicle_info ? ' for ' . $vehicle_info : ''),
        array(
            __('Request Details:', 'wheelfy') => array(
                __('Customer:', 'wheelfy') => esc_html($customer_name),
                __('Approved Price:', 'wheelfy') => '<strong style="color: #28a745;">' . wheelfy_format_price($offer_price) . '</strong>',
                __('Status:', 'wheelfy') => '<strong style="color: #007bff;">' . __('Ready to Start', 'wheelfy') . '</strong>',
            ),
        ),
        '',
        __('You can now chat with the customer and start working on this request.', 'wheelfy'),
        __('View the request:', 'wheelfy'),
        home_url('/partner-dashboard#requests'),
        __('View Request', 'wheelfy'),
        $site_name,
        home_url()
    );
    
    $headers = array(
        'Content-Type: text/html; charset=UTF-8',
        'From: ' . $site_name . ' <' . $site_email . '>'
    );
    
    return wp_mail($partner->user_email, $subject, $message, $headers);
}

/**
 * Send email to customer when partner requests completion confirmation
 */
function wheelfy_send_completion_request_email_to_customer($customer_id, $request_id, $partner_id, $partner_name, $form_data = null) {
    $email_notifications_enabled = get_user_meta($customer_id, 'email_notifications_enabled', true);
    if ($email_notifications_enabled === '0') {
        return false;
    }
    
    $customer = get_userdata($customer_id);
    if (!$customer || empty($customer->user_email)) {
        return false;
    }
    
    $site_name = get_bloginfo('name');
    $site_email = get_option('admin_email');
    
    // Get vehicle info if available
    $vehicle_info = '';
    if ($form_data && isset($form_data['make']) && isset($form_data['model'])) {
        $vehicle_info = $form_data['make'] . ' ' . $form_data['model'];
        if (isset($form_data['year'])) {
            $vehicle_info .= ' (' . $form_data['year'] . ')';
        }
    }
    
    $subject = sprintf(__('[%s] Please Confirm Service Completion', 'wheelfy'), $site_name);
    
    $message = wheelfy_get_email_template_html(
        __('Service Completion Confirmation Required', 'wheelfy'),
        sprintf(__('%s has marked your service request%s as completed. Please confirm if the work has been done to your satisfaction.', 'wheelfy'), esc_html($partner_name), $vehicle_info ? ' for ' . $vehicle_info : ''),
        array(
            __('Request Details:', 'wheelfy') => array(
                __('Partner:', 'wheelfy') => esc_html($partner_name),
                __('Status:', 'wheelfy') => '<strong style="color: #ffc107;">' . __('Awaiting Your Confirmation', 'wheelfy') . '</strong>',
            ),
        ),
        '',
        __('Please confirm the completion to finalize this request. If you have any issues, please contact the partner through the chat.', 'wheelfy'),
        __('Confirm completion:', 'wheelfy'),
        home_url('/customer-dashboard#requests'),
        __('Confirm Completion', 'wheelfy'),
        $site_name,
        home_url()
    );
    
    $headers = array(
        'Content-Type: text/html; charset=UTF-8',
        'From: ' . $site_name . ' <' . $site_email . '>'
    );
    
    return wp_mail($customer->user_email, $subject, $message, $headers);
}

/**
 * Customer AJAX: Approve Partner's Offer
 * Changes status from waiting_customer_approval → accepted
 * Creates chat thread at this point
 */
function wheelfy_ajax_customer_approve_offer() {
    // Suppress PHP errors/warnings from corrupting JSON response
    @ini_set('display_errors', 0);
    error_reporting(0);
    
    // Clean any previous output
    while (ob_get_level()) {
        ob_end_clean();
    }
    ob_start();
    
    try {
        // Verify nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_nonce')) {
            ob_end_clean();
            wp_send_json_error(array('message' => 'Security check failed.'));
        }
        
        // Check if user is logged in
        if (!is_user_logged_in()) {
            ob_end_clean();
            wp_send_json_error(array('message' => 'You must be logged in.'));
        }
        
        $current_user = wp_get_current_user();
        $customer_id = $current_user->ID;
        
        $request_id_full = isset($_POST['request_id']) ? sanitize_text_field($_POST['request_id']) : '';
        $partner_id = isset($_POST['partner_id']) ? intval($_POST['partner_id']) : 0;
        
        // Parse partner_id from request_id if not provided
        if (empty($partner_id) && strpos($request_id_full, '_partner_') !== false) {
            $parts = explode('_partner_', $request_id_full);
            $partner_id = isset($parts[1]) ? intval($parts[1]) : 0;
        }
        
        if (empty($request_id_full)) {
            ob_end_clean();
            wp_send_json_error(array('message' => 'Missing request ID.'));
        }
    
    // Parse request_id
    $parts = explode('_partner_', $request_id_full);
    $request_id = $parts[0];
    
    // Find the request in customer's requests
    $customer_requests = get_user_meta($customer_id, 'customer_service_requests', true);
    if (!is_array($customer_requests)) {
        $customer_requests = array();
    }
    
    $request_found = false;
    $request_index = -1;
    $offer_price = 0;
    $form_data = null;
    
    // Try multiple matching strategies
    foreach ($customer_requests as $index => $req) {
        $req_request_id = isset($req['request_id']) ? $req['request_id'] : '';
        $req_partner_id = isset($req['partner_id']) ? intval($req['partner_id']) : 0;
        
        // Match by request_id (try multiple formats)
        $id_match = ($req_request_id === $request_id) || 
                    ($req_request_id === $request_id_full) ||
                    (isset($req['id']) && ($req['id'] === $request_id || $req['id'] === $request_id_full));
        
        // Also try partner match if partner_id provided
        $partner_match = ($partner_id == 0) || ($req_partner_id === $partner_id) || ($partner_id > 0 && $req_partner_id == $partner_id);
        
        if ($id_match && $partner_match) {
            // Check if status is waiting_customer_approval
            $status = isset($req['status']) ? $req['status'] : '';
            if ($status !== 'waiting_customer_approval') {
                ob_end_clean();
                wp_send_json_error(array('message' => 'This request is not awaiting your approval. Status: ' . $status));
            }
            
            $request_found = true;
            $request_index = $index;
            $offer_price = isset($req['offer_price']) ? floatval($req['offer_price']) : 0;
            $partner_id = $req_partner_id > 0 ? $req_partner_id : $partner_id;
            $form_data = $req;
            break;
        }
    }
    
    // Try transient if not found
    if (!$request_found && $partner_id > 0) {
        $transient_key = 'car_accessories_request_' . $request_id . '_partner_' . $partner_id;
        $transient_data = get_transient($transient_key);
        
        if ($transient_data && is_array($transient_data)) {
            $status = isset($transient_data['status']) ? $transient_data['status'] : '';
            if ($status === 'waiting_customer_approval') {
                $request_found = true;
                $form_data = $transient_data;
                $offer_price = isset($transient_data['offer_price']) ? floatval($transient_data['offer_price']) : 0;
                
                // Add to customer_requests for later update
                $customer_requests[] = $transient_data;
                $request_index = count($customer_requests) - 1;
            }
        }
    }
    
    if (!$request_found) {
        ob_end_clean();
        wp_send_json_error(array('message' => 'Request not found. Please refresh and try again.'));
    }
    
    // Update status to accepted
    $customer_requests[$request_index]['status'] = 'accepted';
    $customer_requests[$request_index]['customer_approved_at'] = current_time('mysql');
    $customer_requests[$request_index]['updated_at'] = current_time('mysql');
    update_user_meta($customer_id, 'customer_service_requests', $customer_requests);
    
    // Update transient
    $transient_key = 'car_accessories_request_' . $request_id . '_partner_' . $partner_id;
    $form_data = get_transient($transient_key);
    if ($form_data && is_array($form_data)) {
        $form_data['status'] = 'accepted';
        $form_data['customer_approved_at'] = current_time('mysql');
        $form_data['updated_at'] = current_time('mysql');
        set_transient($transient_key, $form_data, 30 * DAY_IN_SECONDS);
    }
    
    // Update post meta if exists
    $args = array(
        'post_type' => 'post',
        'posts_per_page' => -1,
        'post_status' => 'publish',
        'meta_query' => array(
            array(
                'key' => '_proposal_request_type',
                'compare' => 'EXISTS',
            ),
        ),
    );
    $posts = get_posts($args);
    foreach ($posts as $post) {
        $post_request_id = get_post_meta($post->ID, '_proposal_request_id', true);
        $post_partner_id = get_post_meta($post->ID, 'partner_id', true);
        
        if ($post_request_id === $request_id && intval($post_partner_id) === $partner_id) {
            update_post_meta($post->ID, '_proposal_status', 'accepted');
            update_post_meta($post->ID, '_proposal_customer_approved_at', current_time('mysql'));
            break;
        }
    }
    
    // NOW create chat thread (after customer approval)
    $thread_id = wheelfy_get_or_create_thread($customer_id, $partner_id, $request_id);
    
    // Get partner info
    $partner_user = get_userdata($partner_id);
    $partner_name = '';
    if ($partner_user) {
        $business_name = get_user_meta($partner_id, 'business_name', true);
        $partner_name = !empty($business_name) ? $business_name : ($partner_user->display_name ?: $partner_user->user_login);
    }
    
    // Get customer name
    $customer_name = $current_user->display_name ?: $current_user->user_login;
    
    // Create notification for partner
    wheelfy_create_notification(
        $partner_id,
        'offer_approved',
        __('Offer Approved', 'wheelfy'),
        sprintf(__('%s has approved your offer of %s. You can now start working on this request.', 'wheelfy'), $customer_name, wheelfy_format_price($offer_price)),
        array(
            'request_id' => $request_id, 
            'customer_id' => $customer_id, 
            'thread_id' => $thread_id,
            'link' => home_url('/partner-dashboard#requests'),
            'action_text' => 'View Request'
        )
    );
    
    // Send email to partner
    wheelfy_send_offer_approved_email_to_partner($partner_id, $request_id, $customer_id, $customer_name, $offer_price, $form_data);
    
    ob_end_clean();
    wp_send_json_success(array(
        'message' => __('Offer approved successfully. You can now chat with the partner.', 'wheelfy'),
        'status' => 'accepted',
        'thread_id' => $thread_id
    ));
    
    } catch (Exception $e) {
        error_log('Wheelfy Customer Approve Offer Error: ' . $e->getMessage());
        if (ob_get_level()) ob_end_clean();
        wp_send_json_error(array('message' => 'An error occurred: ' . $e->getMessage()));
    } catch (Error $e) {
        error_log('Wheelfy Customer Approve Offer Fatal Error: ' . $e->getMessage());
        if (ob_get_level()) ob_end_clean();
        wp_send_json_error(array('message' => 'A system error occurred.'));
    }
}
add_action('wp_ajax_wheelfy_customer_approve_offer', 'wheelfy_ajax_customer_approve_offer');

/**
 * Customer AJAX: Confirm Car Sale
 * For Sell Car workflow: accepted → complete (skip in_progress and pending_completion)
 * Also notifies dealer (partner) and admin
 */
function wheelfy_ajax_customer_confirm_sale() {
    // Suppress PHP errors/warnings from corrupting JSON response
    @ini_set('display_errors', 0);
    error_reporting(0);
    
    // Clean any previous output
    while (ob_get_level()) {
        ob_end_clean();
    }
    ob_start();
    
    try {
        // Verify nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_nonce')) {
            ob_end_clean();
            wp_send_json_error(array('message' => 'Security check failed.'));
        }
        
        // Check if user is logged in
        if (!is_user_logged_in()) {
            ob_end_clean();
            wp_send_json_error(array('message' => 'You must be logged in.'));
        }
        
        $current_user = wp_get_current_user();
        $customer_id = $current_user->ID;
        
        $request_id_full = isset($_POST['request_id']) ? sanitize_text_field($_POST['request_id']) : '';
        $partner_id = isset($_POST['partner_id']) ? intval($_POST['partner_id']) : 0;
        
        if (empty($request_id_full)) {
            ob_end_clean();
            wp_send_json_error(array('message' => 'Request ID is required.'));
        }
        
        // Parse request_id
        $parts = explode('_partner_', $request_id_full);
        $request_id = $parts[0];
        if (empty($partner_id) && isset($parts[1])) {
            $partner_id = intval($parts[1]);
        }
        
        // Find the request in customer's requests
        $customer_requests = get_user_meta($customer_id, 'customer_service_requests', true);
        if (!is_array($customer_requests)) {
            $customer_requests = array();
        }
        
        $request_found = false;
        $request_index = -1;
        $form_data = null;
        
        foreach ($customer_requests as $index => $req) {
            $req_request_id = isset($req['request_id']) ? $req['request_id'] : '';
            $req_partner_id = isset($req['partner_id']) ? intval($req['partner_id']) : 0;
            
            // Match by request_id
            $id_match = ($req_request_id === $request_id) || 
                        ($req_request_id === $request_id_full) ||
                        (isset($req['id']) && ($req['id'] === $request_id || $req['id'] === $request_id_full));
            
            if ($id_match) {
                // Check if partner_id matches (or partner_id is 0)
                if ($partner_id > 0 && $req_partner_id > 0 && $req_partner_id !== $partner_id) {
                    continue;
                }
                
                // Check if status is accepted (sell_car should be in accepted status)
                $status = isset($req['status']) ? $req['status'] : '';
                if ($status !== 'accepted') {
                    ob_end_clean();
                    wp_send_json_error(array('message' => 'This request is not awaiting your confirmation. Current status: ' . $status));
                }
                
                $request_found = true;
                $request_index = $index;
                $partner_id = $req_partner_id > 0 ? $req_partner_id : $partner_id;
                $form_data = $req;
                break;
            }
        }
        
        // Try transient if not found
        if (!$request_found && $partner_id > 0) {
            $transient_key = 'car_accessories_request_' . $request_id . '_partner_' . $partner_id;
            $transient_data = get_transient($transient_key);
            
            if ($transient_data && is_array($transient_data)) {
                $status = isset($transient_data['status']) ? $transient_data['status'] : '';
                if ($status === 'accepted') {
                    $request_found = true;
                    $form_data = $transient_data;
                    
                    // Add to customer_requests for later update
                    $customer_requests[] = $transient_data;
                    $request_index = count($customer_requests) - 1;
                }
            }
        }
        
        if (!$request_found) {
            ob_end_clean();
            wp_send_json_error(array('message' => 'Request not found or not in accepted status.'));
        }
        
        // Update status to complete (skip in_progress and pending_completion)
        $customer_requests[$request_index]['status'] = 'complete';
        $customer_requests[$request_index]['sale_confirmed_at'] = current_time('mysql');
        $customer_requests[$request_index]['completed_at'] = current_time('mysql');
        $customer_requests[$request_index]['updated_at'] = current_time('mysql');
        update_user_meta($customer_id, 'customer_service_requests', $customer_requests);
        
        // Update transient
        $transient_key = 'car_accessories_request_' . $request_id . '_partner_' . $partner_id;
        $form_data = get_transient($transient_key);
        if ($form_data && is_array($form_data)) {
            $form_data['status'] = 'complete';
            $form_data['sale_confirmed_at'] = current_time('mysql');
            $form_data['completed_at'] = current_time('mysql');
            $form_data['updated_at'] = current_time('mysql');
            set_transient($transient_key, $form_data, 30 * DAY_IN_SECONDS);
        }
        
        // Update post meta if exists
        $args = array(
            'post_type' => 'post',
            'posts_per_page' => -1,
            'post_status' => 'publish',
            'meta_query' => array(
                array(
                    'key' => '_proposal_request_type',
                    'compare' => 'EXISTS',
                ),
            ),
        );
        $posts = get_posts($args);
        $post_id = 0;
        foreach ($posts as $post) {
            $post_request_id = get_post_meta($post->ID, '_proposal_request_id', true);
            $post_partner_id = get_post_meta($post->ID, 'partner_id', true);
            
            if ($post_request_id === $request_id || 
                (intval($post_partner_id) === $partner_id && get_post_field('post_author', $post->ID) == $customer_id)) {
                $post_id = $post->ID;
                update_post_meta($post_id, '_proposal_status', 'complete');
                update_post_meta($post_id, '_proposal_sale_confirmed_at', current_time('mysql'));
                update_post_meta($post_id, '_proposal_completed_at', current_time('mysql'));
                break;
            }
        }
        
        // Get customer name
        $customer_name = $current_user->display_name ?: $current_user->user_login;
        
        // Get partner info
        $partner_name = 'Dealer';
        if ($partner_id > 0) {
            $partner_user = get_userdata($partner_id);
            if ($partner_user) {
                $business_name = get_user_meta($partner_id, 'business_name', true);
                $partner_name = !empty($business_name) ? $business_name : ($partner_user->display_name ?: $partner_user->user_login);
            }
        }
        
        // Get car details for notification
        $car_info = 'Car';
        if (isset($form_data['make']) && isset($form_data['model'])) {
            $car_info = $form_data['year'] . ' ' . $form_data['make'] . ' ' . $form_data['model'];
        }
        
        // Notify partner (dealer)
        if ($partner_id > 0) {
            wheelfy_create_notification(
                $partner_id,
                'sale_confirmed',
                __('🚗 Sale Confirmed!', 'wheelfy'),
                sprintf(__('%s has confirmed the sale of their %s. The sale is now complete!', 'wheelfy'), $customer_name, $car_info),
                array(
                    'request_id' => $request_id,
                    'customer_id' => $customer_id,
                    'link' => home_url('/partner-dashboard#requests'),
                    'action_text' => 'View Request'
                )
            );
            
            // Send email to partner
            try {
                wheelfy_send_sale_confirmed_email_to_partner($partner_id, $request_id, $customer_id, $customer_name, $form_data);
            } catch (Exception $e) {
                error_log('Wheelfy Sale Email Error (Partner): ' . $e->getMessage());
            } catch (Error $e) {
                error_log('Wheelfy Sale Email Fatal Error (Partner): ' . $e->getMessage());
            }
        }
        
        // Notify admin
        $admin_users = get_users(array('role' => 'administrator'));
        if (!empty($admin_users)) {
            $admin = $admin_users[0];
            
            wheelfy_create_notification(
                $admin->ID,
                'car_sale_complete',
                __('🚗 Car Sale Completed', 'wheelfy'),
                sprintf(__('A car sale has been completed. %s sold their %s to %s.', 'wheelfy'), $customer_name, $car_info, $partner_name),
                array(
                    'request_id' => $request_id,
                    'customer_id' => $customer_id,
                    'partner_id' => $partner_id,
                    'link' => admin_url('admin.php?page=wheelfy-request'),
                    'action_text' => 'View Details'
                )
            );
        }
        
        ob_end_clean();
        wp_send_json_success(array(
            'message' => __('Car sale confirmed successfully!', 'wheelfy'),
            'status' => 'complete'
        ));
        
    } catch (Exception $e) {
        error_log('Wheelfy Customer Confirm Sale Error: ' . $e->getMessage());
        if (ob_get_level()) ob_end_clean();
        wp_send_json_error(array('message' => 'An error occurred: ' . $e->getMessage()));
    } catch (Error $e) {
        error_log('Wheelfy Customer Confirm Sale Fatal Error: ' . $e->getMessage());
        if (ob_get_level()) ob_end_clean();
        wp_send_json_error(array('message' => 'A system error occurred.'));
    }
}
add_action('wp_ajax_wheelfy_customer_confirm_sale', 'wheelfy_ajax_customer_confirm_sale');

/**
 * Send email to partner when car sale is confirmed
 */
function wheelfy_send_sale_confirmed_email_to_partner($partner_id, $request_id, $customer_id, $customer_name, $form_data = null) {
    $email_notifications_enabled = get_user_meta($partner_id, 'email_notifications_enabled', true);
    if ($email_notifications_enabled === '0') {
        return false;
    }
    
    $partner = get_userdata($partner_id);
    if (!$partner || empty($partner->user_email)) {
        return false;
    }
    
    $site_name = get_bloginfo('name');
    $site_email = get_option('admin_email');
    
    // Get car info
    $car_info = 'Car';
    $car_price = '';
    if ($form_data) {
        if (isset($form_data['make']) && isset($form_data['model'])) {
            $car_info = $form_data['year'] . ' ' . $form_data['make'] . ' ' . $form_data['model'];
        }
        if (isset($form_data['price'])) {
            $car_price = '€' . number_format(floatval($form_data['price']), 0, ',', ' ');
        }
    }
    
    $subject = sprintf(__('[%s] 🚗 Car Sale Confirmed - %s', 'wheelfy'), $site_name, $car_info);
    
    $message = wheelfy_get_email_template_html(
        __('Congratulations! Sale Confirmed', 'wheelfy'),
        sprintf(__('%s has confirmed the sale of their car to you.', 'wheelfy'), esc_html($customer_name)),
        array(
            __('Sale Details:', 'wheelfy') => array(
                __('Car:', 'wheelfy') => esc_html($car_info),
                __('Price:', 'wheelfy') => $car_price ?: __('Contact for price', 'wheelfy'),
                __('Seller:', 'wheelfy') => esc_html($customer_name),
                __('Status:', 'wheelfy') => '<strong style="color: #28a745;">✓ COMPLETED</strong>',
            ),
        ),
        '',
        __('You can now coordinate with the customer to complete the transaction. The chat feature is available for communication.', 'wheelfy'),
        __('View request details:', 'wheelfy'),
        home_url('/partner-dashboard#requests'),
        __('View Request', 'wheelfy'),
        $site_name,
        home_url()
    );
    
    $headers = array(
        'Content-Type: text/html; charset=UTF-8',
        'From: ' . $site_name . ' <' . $site_email . '>'
    );
    
    return wp_mail($partner->user_email, $subject, $message, $headers);
}

/**
 * Customer AJAX: Confirm Request Completion
 * Changes status from pending_completion → complete
 * Final step in new workflow
 */
function wheelfy_ajax_customer_confirm_completion() {
    // Suppress PHP errors/warnings from corrupting JSON response
    @ini_set('display_errors', 0);
    error_reporting(0);
    
    // Clean any previous output
    while (ob_get_level()) {
        ob_end_clean();
    }
    ob_start();
    
    try {
        // Verify nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_nonce')) {
            ob_end_clean();
            wp_send_json_error(array('message' => 'Security check failed.'));
        }
        
        // Check if user is logged in
        if (!is_user_logged_in()) {
            ob_end_clean();
            wp_send_json_error(array('message' => 'You must be logged in.'));
        }
        
        $current_user = wp_get_current_user();
        $customer_id = $current_user->ID;
        
        $request_id_full = isset($_POST['request_id']) ? sanitize_text_field($_POST['request_id']) : '';
        $partner_id = isset($_POST['partner_id']) ? intval($_POST['partner_id']) : 0;
        
        if (empty($request_id_full)) {
            ob_end_clean();
            wp_send_json_error(array('message' => 'Request ID is required.'));
        }
        
        // Parse request_id
        $parts = explode('_partner_', $request_id_full);
        $request_id = $parts[0];
        if (empty($partner_id) && isset($parts[1])) {
            $partner_id = intval($parts[1]);
        }
        
        // Find the request in customer's requests
        $customer_requests = get_user_meta($customer_id, 'customer_service_requests', true);
        if (!is_array($customer_requests)) {
            $customer_requests = array();
        }
        
        $request_found = false;
        $request_index = -1;
        $form_data = null;
        
        // First try to find by exact request_id match
        foreach ($customer_requests as $index => $req) {
            $req_partner_id = isset($req['partner_id']) ? intval($req['partner_id']) : 0;
            $req_request_id = isset($req['request_id']) ? $req['request_id'] : '';
            
            // Try multiple matching strategies
            $id_match = ($req_request_id === $request_id) || 
                        ($req_request_id === $request_id_full) ||
                        (isset($req['id']) && ($req['id'] === $request_id || $req['id'] === $request_id_full));
            
            if ($id_match) {
                // Match by partner_id if provided
                if ($partner_id > 0 && $req_partner_id > 0 && $req_partner_id !== $partner_id) {
                    continue;
                }
                
                // Check if status is pending_completion
                $status = isset($req['status']) ? $req['status'] : '';
                if ($status !== 'pending_completion') {
                    ob_end_clean();
                    wp_send_json_error(array('message' => 'This request is not awaiting your confirmation. Current status: ' . $status));
                }
                
                $request_found = true;
                $request_index = $index;
                $partner_id = $req_partner_id > 0 ? $req_partner_id : $partner_id;
                $form_data = $req;
                break;
            }
        }
        
        // If not found in customer_service_requests, try transient
        if (!$request_found && $partner_id > 0) {
            $transient_key = 'car_accessories_request_' . $request_id . '_partner_' . $partner_id;
            $transient_data = get_transient($transient_key);
            
            if ($transient_data && is_array($transient_data)) {
                $status = isset($transient_data['status']) ? $transient_data['status'] : '';
                if ($status === 'pending_completion') {
                    $request_found = true;
                    $form_data = $transient_data;
                    $partner_id = isset($transient_data['partner_id']) ? intval($transient_data['partner_id']) : $partner_id;
                    
                    // Update customer_requests array for later processing
                    $customer_requests[] = $transient_data;
                    $request_index = count($customer_requests) - 1;
                }
            }
        }
        
        // If still not found, check posts with pending_completion status
        if (!$request_found) {
            $args = array(
                'post_type' => 'post',
                'posts_per_page' => -1,
                'post_status' => 'publish',
                'author' => $customer_id,
                'meta_query' => array(
                    'relation' => 'AND',
                    array(
                        'key' => '_proposal_status',
                        'value' => 'pending_completion',
                        'compare' => '='
                    ),
                ),
            );
            $posts = get_posts($args);
            
            foreach ($posts as $post) {
                $post_request_id = get_post_meta($post->ID, '_proposal_request_id', true);
                $post_partner_id = get_post_meta($post->ID, 'partner_id', true);
                
                // Match by request_id
                $id_match = ($post_request_id === $request_id) || 
                            ($post_request_id === $request_id_full) ||
                            (strpos($request_id, 'post_' . $post->ID) !== false);
                
                // Also try matching without partner suffix
                if (!$id_match && $partner_id > 0) {
                    $id_match = (intval($post_partner_id) === $partner_id);
                }
                
                if ($id_match || ($partner_id > 0 && intval($post_partner_id) === $partner_id)) {
                    $request_found = true;
                    $partner_id = intval($post_partner_id);
                    $form_data = array(
                        'request_id' => $post_request_id ?: ('post_' . $post->ID),
                        'partner_id' => $partner_id,
                        'status' => 'pending_completion',
                        'post_id' => $post->ID
                    );
                    
                    // Add to customer_requests for processing
                    $customer_requests[] = $form_data;
                    $request_index = count($customer_requests) - 1;
                    break;
                }
            }
        }
        
        if (!$request_found) {
            ob_end_clean();
            wp_send_json_error(array('message' => 'Request not found or not pending completion. Please refresh and try again.'));
        }
    
    // Update status to complete
    $customer_requests[$request_index]['status'] = 'complete';
    $customer_requests[$request_index]['customer_confirmed_at'] = current_time('mysql');
    $customer_requests[$request_index]['completed_at'] = current_time('mysql');
    $customer_requests[$request_index]['updated_at'] = current_time('mysql');
    update_user_meta($customer_id, 'customer_service_requests', $customer_requests);
    
    // Update transient
    $transient_key = 'car_accessories_request_' . $request_id . '_partner_' . $partner_id;
    $form_data = get_transient($transient_key);
    if ($form_data && is_array($form_data)) {
        $form_data['status'] = 'complete';
        $form_data['customer_confirmed_at'] = current_time('mysql');
        $form_data['completed_at'] = current_time('mysql');
        $form_data['updated_at'] = current_time('mysql');
        set_transient($transient_key, $form_data, 30 * DAY_IN_SECONDS);
    }
    
    // Update post meta
    $post_id = 0;
    $args = array(
        'post_type' => 'post',
        'posts_per_page' => -1,
        'post_status' => 'publish',
        'meta_query' => array(
            array(
                'key' => '_proposal_request_type',
                'compare' => 'EXISTS',
            ),
        ),
    );
    $posts = get_posts($args);
    foreach ($posts as $post) {
        $post_request_id = get_post_meta($post->ID, '_proposal_request_id', true);
        $post_partner_id = get_post_meta($post->ID, 'partner_id', true);
        
        if ($post_request_id === $request_id && intval($post_partner_id) === $partner_id) {
            $post_id = $post->ID;
            update_post_meta($post->ID, '_proposal_status', 'complete');
            update_post_meta($post->ID, '_proposal_customer_confirmed_at', current_time('mysql'));
            update_post_meta($post->ID, '_proposal_completed_date', current_time('mysql'));
            update_post_meta($post->ID, '_proposal_completed_by', $customer_id);
            break;
        }
    }
    
    // Get partner info
    $partner_user = get_userdata($partner_id);
    $partner_name = '';
    if ($partner_user) {
        $business_name = get_user_meta($partner_id, 'business_name', true);
        $partner_name = !empty($business_name) ? $business_name : ($partner_user->display_name ?: $partner_user->user_login);
    }
    
    // Get customer name
    $customer_name = $current_user->display_name ?: $current_user->user_login;
    
    // Create notification for partner
    wheelfy_create_notification(
        $partner_id,
        'request_completed',
        __('Request Completed', 'wheelfy'),
        sprintf(__('%s has confirmed the completion of your service. Great job!', 'wheelfy'), $customer_name),
        array(
            'request_id' => $request_id, 
            'customer_id' => $customer_id,
            'link' => home_url('/partner-dashboard#requests'),
            'action_text' => 'View Request'
        )
    );
    
    // Get vehicle info for emails
    $vehicle_info = '';
    if ($form_data && isset($form_data['make']) && isset($form_data['model'])) {
        $vehicle_info = $form_data['make'] . ' ' . $form_data['model'];
        if (isset($form_data['year'])) {
            $vehicle_info .= ' (' . $form_data['year'] . ')';
        }
    }
    
    // Send completion emails to both parties
    wheelfy_send_request_completed_email_to_customer($customer_id, $request_id, $partner_id, $partner_name, $vehicle_info);
    wheelfy_send_request_completed_email_to_partner($partner_id, $request_id, $customer_id, $customer_name, $vehicle_info);
    
    // Fire action hook
    do_action('wheelfy_request_completed_by_customer', $request_id, $partner_id, $customer_id);
    
    ob_end_clean();
    wp_send_json_success(array(
        'message' => __('Request completed successfully. Thank you for using our service!', 'wheelfy'),
        'status' => 'complete'
    ));
    
    } catch (Exception $e) {
        error_log('Wheelfy Customer Confirm Completion Error: ' . $e->getMessage());
        if (ob_get_level()) ob_end_clean();
        wp_send_json_error(array('message' => 'An error occurred: ' . $e->getMessage()));
    } catch (Error $e) {
        error_log('Wheelfy Customer Confirm Completion Fatal Error: ' . $e->getMessage());
        if (ob_get_level()) ob_end_clean();
        wp_send_json_error(array('message' => 'A system error occurred.'));
    }
}
add_action('wp_ajax_wheelfy_customer_confirm_completion', 'wheelfy_ajax_customer_confirm_completion');

/**
 * AJAX Handler: Submit Review from Partner Profile
 * 
 * IMPORTANT: Only customers who have completed requests with the partner can submit reviews.
 * Each completed request can only be reviewed once.
 */
function wheelfy_ajax_submit_review() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_submit_review')) {
        wp_send_json_error(array('message' => __('Security token missing or invalid. Please refresh the page and try again.', 'wheelfy')));
        return;
    }
    
    // Check if user is logged in
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => __('You must be logged in to submit a review.', 'wheelfy')));
        return;
    }
    
    $current_user_id = get_current_user_id();
    $partner_id = isset($_POST['partner_id']) ? intval($_POST['partner_id']) : 0;
    $request_id = isset($_POST['request_id']) ? intval($_POST['request_id']) : 0;
    $rating = isset($_POST['rating']) ? intval($_POST['rating']) : 0;
    $review_text = isset($_POST['review_text']) ? sanitize_textarea_field($_POST['review_text']) : '';
    
    // Validate inputs
    if ($partner_id <= 0) {
        wp_send_json_error(array('message' => __('Invalid partner ID.', 'wheelfy')));
        return;
    }
    
    if ($request_id <= 0) {
        wp_send_json_error(array('message' => __('Please select a completed service to review.', 'wheelfy')));
        return;
    }
    
    if ($rating < 1 || $rating > 5) {
        wp_send_json_error(array('message' => __('Please select a valid rating (1-5 stars).', 'wheelfy')));
        return;
    }
    
    if (empty($review_text)) {
        wp_send_json_error(array('message' => __('Please write a review.', 'wheelfy')));
        return;
    }
    
    // Verify user is not reviewing themselves
    if ($current_user_id == $partner_id) {
        wp_send_json_error(array('message' => __('You cannot review yourself.', 'wheelfy')));
        return;
    }
    
    // Verify the request exists, belongs to customer, is completed, and partner matches
    $request_post = get_post($request_id);
    if (!$request_post || $request_post->post_author != $current_user_id) {
        wp_send_json_error(array('message' => __('This request does not belong to you.', 'wheelfy')));
        return;
    }
    
    // Check if request status is 'complete'
    $request_status = get_post_meta($request_id, '_proposal_status', true);
    if ($request_status !== 'complete') {
        wp_send_json_error(array('message' => __('You can only review completed requests.', 'wheelfy')));
        return;
    }
    
    // Verify partner_id matches the request
    $request_partner_id = get_post_meta($request_id, 'partner_id', true);
    if (empty($request_partner_id)) {
        $request_partner_id = get_post_meta($request_id, '_proposal_accepted_by', true);
    }
    
    if (intval($request_partner_id) != $partner_id) {
        wp_send_json_error(array('message' => __('This request was not completed by this partner.', 'wheelfy')));
        return;
    }
    
    // Check if customer has already reviewed this specific request
    $customer_reviews = get_user_meta($current_user_id, 'wheelfy_reviews_given', true);
    if (!is_array($customer_reviews)) {
        $customer_reviews = array();
    }
    
    foreach ($customer_reviews as $review) {
        // Check if this request has already been reviewed
        if (isset($review['request_id']) && $review['request_id'] == $request_id && 
            isset($review['partner_id']) && $review['partner_id'] == $partner_id) {
            wp_send_json_error(array('message' => __('You have already reviewed this completed request. You can only review each completed request once.', 'wheelfy')));
            return;
        }
    }
    
    // Get customer info
    $customer_user = get_userdata($current_user_id);
    $customer_name = $customer_user ? ($customer_user->display_name ?: $customer_user->user_login) : 'Anonymous';
    $customer_email = $customer_user ? $customer_user->user_email : '';
    
    // Create review data
    // IMPORTANT: Use both 'id' and 'review_id' for compatibility with admin moderation functions
    $review_id_value = 'review_' . time() . '_' . $current_user_id . '_' . $partner_id;
    $review_data = array(
        'id' => $review_id_value, // Used by admin moderation functions
        'review_id' => $review_id_value, // Also stored for consistency
        'customer_id' => $current_user_id,
        'customer_name' => $customer_name,
        'customer_email' => $customer_email,
        'partner_id' => $partner_id,
        'request_id' => $request_id,
        'rating' => $rating,
        'review_text' => $review_text,
        'date' => current_time('mysql'),
        'created_at' => current_time('mysql'), // Also add created_at for date display
        'status' => 'pending' // Pending admin approval
    );
    
    // Save review to customer's "reviews given" meta
    $customer_reviews[] = $review_data;
    update_user_meta($current_user_id, 'wheelfy_reviews_given', $customer_reviews);
    
    // Save review to partner's "reviews received" meta
    $partner_reviews = get_user_meta($partner_id, 'wheelfy_reviews_received', true);
    if (!is_array($partner_reviews)) {
        $partner_reviews = array();
    }
    $partner_reviews[] = $review_data;
    update_user_meta($partner_id, 'wheelfy_reviews_received', $partner_reviews);
    
    wp_send_json_success(array(
        'message' => __('Review submitted successfully! It will appear after admin approval.', 'wheelfy')
    ));
}
add_action('wp_ajax_wheelfy_submit_review', 'wheelfy_ajax_submit_review');

/**
 * AJAX: Save Partner Service (Add/Edit)
 */
function wheelfy_ajax_save_partner_service() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_nonce')) {
        wp_send_json_error(array('message' => 'Security check failed.'));
    }
    
    // Check if user is logged in and is a partner
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'You must be logged in.'));
    }
    
    $current_user = wp_get_current_user();
    if (!in_array('partner', $current_user->roles)) {
        wp_send_json_error(array('message' => 'Unauthorized. Only partners can manage services.'));
    }
    
    $partner_id = $current_user->ID;
    
    // Get service data
    $service_id = isset($_POST['service_id']) ? sanitize_text_field($_POST['service_id']) : '';
    $title = isset($_POST['title']) ? sanitize_text_field($_POST['title']) : '';
    $description = isset($_POST['description']) ? sanitize_textarea_field($_POST['description']) : '';
    $price = isset($_POST['price']) ? floatval($_POST['price']) : 0;
    $price_currency = isset($_POST['price_currency']) ? sanitize_text_field($_POST['price_currency']) : 'EUR';
    $duration = isset($_POST['duration']) ? sanitize_text_field($_POST['duration']) : '';
    $category = isset($_POST['category']) ? sanitize_text_field($_POST['category']) : '';
    $status = isset($_POST['status']) ? sanitize_text_field($_POST['status']) : 'active';
    
    // Validate required fields
    if (empty($title)) {
        wp_send_json_error(array('message' => 'Service title is required.'));
    }
    
    if (empty($description)) {
        wp_send_json_error(array('message' => 'Service description is required.'));
    }
    
    if ($price <= 0) {
        wp_send_json_error(array('message' => 'Service price must be greater than 0.'));
    }
    
    if (empty($duration)) {
        wp_send_json_error(array('message' => 'Service duration is required.'));
    }
    
    if (empty($category)) {
        wp_send_json_error(array('message' => 'Service category is required.'));
    }
    
    // Validate status
    if (!in_array($status, array('active', 'inactive'))) {
        $status = 'active';
    }
    
    // Get existing services
    $services = get_user_meta($partner_id, 'partner_services', true);
    if (!is_array($services)) {
        $services = array();
    }
    
    // Prepare service data
    $service_data = array(
        'title' => $title,
        'description' => $description,
        'price' => $price,
        'price_currency' => $price_currency,
        'duration' => $duration,
        'category' => $category,
        'status' => $status,
        'updated_at' => current_time('mysql')
    );
    
    // If editing existing service
    if (!empty($service_id)) {
        $service_found = false;
        foreach ($services as $key => $service) {
            if (isset($service['id']) && $service['id'] === $service_id) {
                // Verify this service belongs to this partner
                $service_data['id'] = $service_id;
                $service_data['created_at'] = isset($service['created_at']) ? $service['created_at'] : current_time('mysql');
                $services[$key] = $service_data;
                $service_found = true;
                break;
            }
        }
        
        if (!$service_found) {
            wp_send_json_error(array('message' => 'Service not found.'));
        }
    } else {
        // Creating new service
        $service_data['id'] = uniqid('svc_', true);
        $service_data['created_at'] = current_time('mysql');
        $services[] = $service_data;
    }
    
    // Save services
    update_user_meta($partner_id, 'partner_services', $services);
    
    wp_send_json_success(array(
        'message' => empty($service_id) ? __('Service added successfully!', 'wheelfy') : __('Service updated successfully!', 'wheelfy'),
        'service' => $service_data
    ));
}
add_action('wp_ajax_save_partner_service', 'wheelfy_ajax_save_partner_service');

/**
 * AJAX: Delete Partner Service
 */
function wheelfy_ajax_delete_partner_service() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wheelfy_nonce')) {
        wp_send_json_error(array('message' => 'Security check failed.'));
    }
    
    // Check if user is logged in and is a partner
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'You must be logged in.'));
    }
    
    $current_user = wp_get_current_user();
    if (!in_array('partner', $current_user->roles)) {
        wp_send_json_error(array('message' => 'Unauthorized. Only partners can delete services.'));
    }
    
    $partner_id = $current_user->ID;
    $service_id = isset($_POST['service_id']) ? sanitize_text_field($_POST['service_id']) : '';
    
    if (empty($service_id)) {
        wp_send_json_error(array('message' => 'Service ID is required.'));
    }
    
    // Get existing services
    $services = get_user_meta($partner_id, 'partner_services', true);
    if (!is_array($services)) {
        wp_send_json_error(array('message' => 'Service not found.'));
    }
    
    // Find and remove service
    $service_found = false;
    foreach ($services as $key => $service) {
        if (isset($service['id']) && $service['id'] === $service_id) {
            unset($services[$key]);
            $service_found = true;
            break;
        }
    }
    
    if (!$service_found) {
        wp_send_json_error(array('message' => 'Service not found.'));
    }
    
    // Re-index array
    $services = array_values($services);
    
    // Save updated services
    update_user_meta($partner_id, 'partner_services', $services);
    
    wp_send_json_success(array(
        'message' => __('Service deleted successfully!', 'wheelfy')
    ));
}
add_action('wp_ajax_delete_partner_service', 'wheelfy_ajax_delete_partner_service');

/**
 * Helper: Get Partner Services
 */
function wheelfy_get_partner_services($partner_id, $status_filter = 'all') {
    $services = get_user_meta($partner_id, 'partner_services', true);
    if (!is_array($services)) {
        return array();
    }
    
    // Filter by status if needed
    if ($status_filter !== 'all') {
        $services = array_filter($services, function($service) use ($status_filter) {
            return isset($service['status']) && $service['status'] === $status_filter;
        });
    }
    
    // Sort by created_at (newest first)
    usort($services, function($a, $b) {
        $date_a = isset($a['created_at']) ? strtotime($a['created_at']) : 0;
        $date_b = isset($b['created_at']) ? strtotime($b['created_at']) : 0;
        return $date_b - $date_a;
    });
    
    return $services;
}
