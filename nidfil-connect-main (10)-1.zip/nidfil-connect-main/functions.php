<?php
/**
 * NIDFIL Connect Theme Functions
 *
 * @package NIDFIL_Connect
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

/**
 * Theme Setup
 */
function nidfil_connect_setup() {
    // Add theme support
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
    ));
    
    // Add custom logo support
    add_theme_support('custom-logo', array(
        'height'      => 100,
        'width'       => 400,
        'flex-height' => true,
        'flex-width'  => true,
        'header-text' => array('site-title', 'site-description'),
    ));
    
    // Register navigation menus
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'nidfil-connect'),
        'footer' => __('Footer Menu', 'nidfil-connect'),
    ));
    
    // Set content width
    $GLOBALS['content_width'] = 1200;
}
add_action('after_setup_theme', 'nidfil_connect_setup');

/**
 * Create/ensure Aviso Legal page exists
 */
function nidfil_create_aviso_legal_page() {
    // Check if a page already uses the Aviso Legal template
    $pages = get_pages(array(
        'meta_key'   => '_wp_page_template',
        'meta_value' => 'templates/page-aviso-legal.php',
        'number'     => 1,
        'post_status'=> 'publish',
    ));

    if (!empty($pages)) {
        return $pages[0]->ID;
    }

    // Check if a page with slug 'aviso-legal' exists
    $existing = get_page_by_path('aviso-legal');
    if ($existing) {
        update_post_meta($existing->ID, '_wp_page_template', 'templates/page-aviso-legal.php');
        if ($existing->post_status !== 'publish') {
            wp_update_post(array(
                'ID'          => $existing->ID,
                'post_status' => 'publish',
            ));
        }
        clean_post_cache($existing->ID);
        return $existing->ID;
    }

    // Create the page
    $page_id = wp_insert_post(array(
        'post_title'   => 'Aviso Legal',
        'post_name'    => 'aviso-legal',
        'post_type'    => 'page',
        'post_status'  => 'publish',
        'post_content' => '<!-- Página de Aviso Legal -->',
        'post_author'  => 1,
    ));

    if ($page_id && !is_wp_error($page_id)) {
        update_post_meta($page_id, '_wp_page_template', 'templates/page-aviso-legal.php');
        clean_post_cache($page_id);
        flush_rewrite_rules(false);
        return $page_id;
    }

    return false;
}

/**
 * Create/ensure Política de Privacidad, Cookies y Condiciones de Uso pages exist
 */
function nidfil_create_privacidad_page() {
    $pages = get_pages(array(
        'meta_key'   => '_wp_page_template',
        'meta_value' => 'templates/page-privacidad.php',
        'number'     => 1,
        'post_status'=> 'publish',
    ));
    if (!empty($pages)) {
        return $pages[0]->ID;
    }

    $existing = get_page_by_path('politica-de-privacidad');
    if ($existing) {
        update_post_meta($existing->ID, '_wp_page_template', 'templates/page-privacidad.php');
        if ($existing->post_status !== 'publish') {
            wp_update_post(array('ID' => $existing->ID, 'post_status' => 'publish'));
        }
        clean_post_cache($existing->ID);
        return $existing->ID;
    }

    $page_id = wp_insert_post(array(
        'post_title'   => 'Política de Privacidad (RGPD)',
        'post_name'    => 'politica-de-privacidad',
        'post_type'    => 'page',
        'post_status'  => 'publish',
        'post_content' => '<!-- Página de Política de Privacidad -->',
        'post_author'  => 1,
    ));
    if ($page_id && !is_wp_error($page_id)) {
        update_post_meta($page_id, '_wp_page_template', 'templates/page-privacidad.php');
        clean_post_cache($page_id);
        flush_rewrite_rules(false);
        return $page_id;
    }
    return false;
}

function nidfil_create_cookies_page() {
    $pages = get_pages(array(
        'meta_key'   => '_wp_page_template',
        'meta_value' => 'templates/page-cookies.php',
        'number'     => 1,
        'post_status'=> 'publish',
    ));
    if (!empty($pages)) {
        return $pages[0]->ID;
    }

    $existing = get_page_by_path('politica-de-cookies');
    if ($existing) {
        update_post_meta($existing->ID, '_wp_page_template', 'templates/page-cookies.php');
        if ($existing->post_status !== 'publish') {
            wp_update_post(array('ID' => $existing->ID, 'post_status' => 'publish'));
        }
        clean_post_cache($existing->ID);
        return $existing->ID;
    }

    $page_id = wp_insert_post(array(
        'post_title'   => 'Política de Cookies',
        'post_name'    => 'politica-de-cookies',
        'post_type'    => 'page',
        'post_status'  => 'publish',
        'post_content' => '<!-- Página de Política de Cookies -->',
        'post_author'  => 1,
    ));
    if ($page_id && !is_wp_error($page_id)) {
        update_post_meta($page_id, '_wp_page_template', 'templates/page-cookies.php');
        clean_post_cache($page_id);
        flush_rewrite_rules(false);
        return $page_id;
    }
    return false;
}

function nidfil_create_condiciones_page() {
    $pages = get_pages(array(
        'meta_key'   => '_wp_page_template',
        'meta_value' => 'templates/page-condiciones-uso.php',
        'number'     => 1,
        'post_status'=> 'publish',
    ));
    if (!empty($pages)) {
        return $pages[0]->ID;
    }

    $existing = get_page_by_path('condiciones-de-uso');
    if ($existing) {
        update_post_meta($existing->ID, '_wp_page_template', 'templates/page-condiciones-uso.php');
        if ($existing->post_status !== 'publish') {
            wp_update_post(array('ID' => $existing->ID, 'post_status' => 'publish'));
        }
        clean_post_cache($existing->ID);
        return $existing->ID;
    }

    $page_id = wp_insert_post(array(
        'post_title'   => 'Condiciones de Uso de la Plataforma',
        'post_name'    => 'condiciones-de-uso',
        'post_type'    => 'page',
        'post_status'  => 'publish',
        'post_content' => '<!-- Página de Condiciones de Uso de la Plataforma -->',
        'post_author'  => 1,
    ));
    if ($page_id && !is_wp_error($page_id)) {
        update_post_meta($page_id, '_wp_page_template', 'templates/page-condiciones-uso.php');
        clean_post_cache($page_id);
        flush_rewrite_rules(false);
        return $page_id;
    }
    return false;
}

/**
 * Auto-create Client Profile page if it doesn't exist
 */
function nidfil_create_client_profile_page() {
    // Check if page already exists with correct template
    $client_profile_page = get_pages(array(
        'meta_key' => '_wp_page_template',
        'meta_value' => 'page-client-profile.php',
        'number' => 1,
        'post_status' => 'publish'
    ));
    
    if (!empty($client_profile_page)) {
        $page = $client_profile_page[0];
        // Ensure page is published
        if ($page->post_status !== 'publish') {
            wp_update_post(array(
                'ID' => $page->ID,
                'post_status' => 'publish'
            ));
        }
        return $page->ID;
    }
    
    // Check if a page with slug 'client-profile' exists
    $existing_page = get_page_by_path('client-profile');
    
    if ($existing_page) {
        // Update existing page to use the template and ensure it's published
        update_post_meta($existing_page->ID, '_wp_page_template', 'page-client-profile.php');
        if ($existing_page->post_status !== 'publish') {
            wp_update_post(array(
                'ID' => $existing_page->ID,
                'post_status' => 'publish'
            ));
        }
        clean_post_cache($existing_page->ID);
        return $existing_page->ID;
    }
    
    // Create the page
    $page_data = array(
        'post_title'    => 'Client Profile',
        'post_name'     => 'client-profile',
        'post_content'  => '<!-- This page uses the Client Profile template -->',
        'post_status'   => 'publish',
        'post_type'     => 'page',
        'post_author'   => 1,
    );
    
    $page_id = wp_insert_post($page_data);
    
    if ($page_id && !is_wp_error($page_id)) {
        // Set the page template
        update_post_meta($page_id, '_wp_page_template', 'page-client-profile.php');
        // Clear cache
        clean_post_cache($page_id);
        // Flush rewrite rules
        flush_rewrite_rules(false);
        return $page_id;
    }
    
    return false;
}

/**
 * Create Specialist Profile Page
 */
function nidfil_create_specialist_profile_page() {
    // Check if page already exists with correct template
    $specialist_profile_page = get_pages(array(
        'meta_key' => '_wp_page_template',
        'meta_value' => 'page-specialist-profile.php',
        'number' => 1,
        'post_status' => 'publish'
    ));
    
    if (!empty($specialist_profile_page)) {
        $page = $specialist_profile_page[0];
        // Ensure page is published
        if ($page->post_status !== 'publish') {
            wp_update_post(array(
                'ID' => $page->ID,
                'post_status' => 'publish'
            ));
        }
        return $page->ID;
    }
    
    // Check if a page with slug 'specialist-profile' exists
    $existing_page = get_page_by_path('specialist-profile');
    
    if ($existing_page) {
        // Update existing page to use the template and ensure it's published
        update_post_meta($existing_page->ID, '_wp_page_template', 'page-specialist-profile.php');
        if ($existing_page->post_status !== 'publish') {
            wp_update_post(array(
                'ID' => $existing_page->ID,
                'post_status' => 'publish'
            ));
        }
        clean_post_cache($existing_page->ID);
        return $existing_page->ID;
    }
    
    // Create the page
    $page_data = array(
        'post_title'    => 'Specialist Profile',
        'post_name'     => 'specialist-profile',
        'post_content'  => '<!-- This page uses the Specialist Profile template -->',
        'post_status'   => 'publish',
        'post_type'     => 'page',
        'post_author'   => 1,
    );
    
    $page_id = wp_insert_post($page_data);
    
    if ($page_id && !is_wp_error($page_id)) {
        // Set the page template
        update_post_meta($page_id, '_wp_page_template', 'page-specialist-profile.php');
        // Clear cache
        clean_post_cache($page_id);
        // Flush rewrite rules
        flush_rewrite_rules(false);
        return $page_id;
    }
    
    return false;
}

/**
 * Create Checkout Page
 */
function nidfil_create_checkout_page() {
    // Check if page already exists with correct template
    $checkout_page = get_pages(array(
        'meta_key' => '_wp_page_template',
        'meta_value' => 'page-checkout.php',
        'number' => 1,
        'post_status' => 'publish'
    ));
    
    if (!empty($checkout_page)) {
        $page = $checkout_page[0];
        // Ensure page is published
        if ($page->post_status !== 'publish') {
            wp_update_post(array(
                'ID' => $page->ID,
                'post_status' => 'publish'
            ));
        }
        return $page->ID;
    }
    
    // Check if a page with slug 'checkout' exists
    $existing_page = get_page_by_path('checkout');
    
    if ($existing_page) {
        // Update existing page to use the template and ensure it's published
        update_post_meta($existing_page->ID, '_wp_page_template', 'page-checkout.php');
        if ($existing_page->post_status !== 'publish') {
            wp_update_post(array(
                'ID' => $existing_page->ID,
                'post_status' => 'publish'
            ));
        }
        clean_post_cache($existing_page->ID);
        return $existing_page->ID;
    }
    
    // Create the page
    $page_data = array(
        'post_title'    => 'Checkout',
        'post_name'     => 'checkout',
        'post_content'  => '<!-- This page uses the Checkout template -->',
        'post_status'   => 'publish',
        'post_type'     => 'page',
        'post_author'   => 1,
    );
    
    $page_id = wp_insert_post($page_data);
    
    if ($page_id && !is_wp_error($page_id)) {
        // Set the page template
        update_post_meta($page_id, '_wp_page_template', 'page-checkout.php');
        // Clear cache
        clean_post_cache($page_id);
        // Flush rewrite rules
        flush_rewrite_rules(false);
        return $page_id;
    }
    
    return false;
}

/**
 * Flush rewrite rules on theme activation
 */
function nidfil_theme_activation() {
    nidfil_create_client_profile_page();
    nidfil_create_specialist_profile_page();
    nidfil_create_aviso_legal_page();
    nidfil_create_privacidad_page();
    nidfil_create_cookies_page();
    nidfil_create_condiciones_page();
    nidfil_create_checkout_page();
    nidfil_create_messaging_tables();
    flush_rewrite_rules();
}
add_action('after_switch_theme', 'nidfil_theme_activation');

// Also try to create the page on theme setup
add_action('after_setup_theme', 'nidfil_create_client_profile_page');

/**
 * Ensure Client Profile page exists when template is loaded
 */
function nidfil_ensure_client_profile_page() {
    // Only run on frontend
    if (is_admin() || wp_doing_ajax()) {
        return;
    }
    
    global $wp_query, $post;
    
    // Check if we're on the client-profile page or trying to access it
    $is_client_profile = false;
    $request_uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
    
    // Check various ways the page might be accessed
    if (isset($wp_query->query_vars['pagename']) && $wp_query->query_vars['pagename'] === 'client-profile') {
        $is_client_profile = true;
    } elseif (strpos($request_uri, '/client-profile') !== false || strpos($request_uri, 'client-profile') !== false) {
        $is_client_profile = true;
    } elseif (isset($wp_query->query_vars['name']) && $wp_query->query_vars['name'] === 'client-profile') {
        $is_client_profile = true;
    }
    
    if ($is_client_profile) {
        // Ensure page exists
        $page_id = nidfil_create_client_profile_page();
        
        if ($page_id) {
            // Get the page object
            $page = get_post($page_id);
            
            if ($page && $page->post_status === 'publish') {
                // Ensure template is assigned
                $current_template = get_post_meta($page_id, '_wp_page_template', true);
                if ($current_template !== 'page-client-profile.php') {
                    update_post_meta($page_id, '_wp_page_template', 'page-client-profile.php');
                }
                
                // Set up the global post object
                $post = $page;
                setup_postdata($post);
                
                // Fix the query
                $wp_query->queried_object = $post;
                $wp_query->queried_object_id = $post->ID;
                $wp_query->is_page = true;
                $wp_query->is_singular = true;
                $wp_query->is_404 = false;
                $wp_query->posts = array($post);
                $wp_query->post_count = 1;
                $wp_query->found_posts = 1;
                
                // Set the template
                $wp_query->is_page_template = true;
            }
        }
    }
}
add_action('template_redirect', 'nidfil_ensure_client_profile_page', 1);

/**
 * Prevent 404 on client-profile page
 */
function nidfil_prevent_client_profile_404($query) {
    if (is_admin() || !$query->is_main_query()) {
        return;
    }
    
    $request_uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
    
    if (strpos($request_uri, '/client-profile') !== false || strpos($request_uri, 'client-profile') !== false) {
        $page = get_page_by_path('client-profile');
        
        if ($page && $page->post_status === 'publish') {
            $query->is_404 = false;
            $query->is_page = true;
            $query->is_singular = true;
            $query->queried_object = $page;
            $query->queried_object_id = $page->ID;
            $query->posts = array($page);
            $query->post_count = 1;
            $query->found_posts = 1;
        }
    }
}
add_action('parse_query', 'nidfil_prevent_client_profile_404');

/**
 * Ensure correct template is used for client-profile page
 */
function nidfil_force_client_profile_template($template) {
    global $wp_query, $post;
    
    // Check if we're on the client-profile page
    $is_client_profile = false;
    $request_uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
    
    // Check various ways the page might be accessed
    if (isset($wp_query->query_vars['pagename']) && $wp_query->query_vars['pagename'] === 'client-profile') {
        $is_client_profile = true;
    } elseif (strpos($request_uri, '/client-profile') !== false || strpos($request_uri, 'client-profile') !== false) {
        $is_client_profile = true;
    } elseif (isset($wp_query->query_vars['name']) && $wp_query->query_vars['name'] === 'client-profile') {
        $is_client_profile = true;
    } elseif (is_page() && isset($post) && $post->post_name === 'client-profile') {
        $is_client_profile = true;
    }
    
    if ($is_client_profile) {
        // Ensure page exists first
        $page_id = nidfil_create_client_profile_page();
        
        if (!$page_id) {
            // Try to find the page
            $page = get_page_by_path('client-profile');
            if ($page) {
                $page_id = $page->ID;
            }
        }
        
        if ($page_id) {
            $page = get_post($page_id);
            
            if ($page) {
                // Ensure template is assigned
                $current_template = get_post_meta($page_id, '_wp_page_template', true);
                if ($current_template !== 'page-client-profile.php') {
                    update_post_meta($page_id, '_wp_page_template', 'page-client-profile.php');
                }
                
                // Set up the post object
                $post = $page;
                setup_postdata($post);
                
                // Fix the query
                $wp_query->queried_object = $post;
                $wp_query->queried_object_id = $post->ID;
                $wp_query->is_page = true;
                $wp_query->is_singular = true;
                $wp_query->is_404 = false;
                $wp_query->posts = array($post);
                $wp_query->post_count = 1;
                $wp_query->found_posts = 1;
                
                // Load the template file
                $template_file = get_template_directory() . '/page-client-profile.php';
                if (file_exists($template_file)) {
                    return $template_file;
                }
            }
        }
    }
    
    return $template;
}
add_filter('template_include', 'nidfil_force_client_profile_template', 99);

/**
 * Ensure specialist profile page exists and is set up correctly
 */
function nidfil_ensure_specialist_profile_page() {
    global $wp_query, $post;
    
    $request_uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
    
    // Check if we're accessing the specialist-profile page
    $is_specialist_profile = false;
    if (isset($wp_query->query_vars['pagename']) && $wp_query->query_vars['pagename'] === 'specialist-profile') {
        $is_specialist_profile = true;
    } elseif (strpos($request_uri, '/specialist-profile') !== false || strpos($request_uri, 'specialist-profile') !== false) {
        $is_specialist_profile = true;
    } elseif (isset($wp_query->query_vars['name']) && $wp_query->query_vars['name'] === 'specialist-profile') {
        $is_specialist_profile = true;
    }
    
    if ($is_specialist_profile) {
        // Ensure page exists
        $page_id = nidfil_create_specialist_profile_page();
        
        if ($page_id) {
            // Get the page object
            $page = get_post($page_id);
            
            if ($page && $page->post_status === 'publish') {
                // Ensure template is assigned
                $current_template = get_post_meta($page_id, '_wp_page_template', true);
                if ($current_template !== 'page-specialist-profile.php') {
                    update_post_meta($page_id, '_wp_page_template', 'page-specialist-profile.php');
                }
                
                // Set up the global post object
                $post = $page;
                setup_postdata($post);
                
                // Fix the query
                $wp_query->queried_object = $post;
                $wp_query->queried_object_id = $post->ID;
                $wp_query->is_page = true;
                $wp_query->is_singular = true;
                $wp_query->is_404 = false;
                $wp_query->posts = array($post);
                $wp_query->post_count = 1;
                $wp_query->found_posts = 1;
                
                // Set the template
                $wp_query->is_page_template = true;
            }
        }
    }
}
add_action('template_redirect', 'nidfil_ensure_specialist_profile_page', 1);

/**
 * Prevent 404 on specialist-profile page
 */
function nidfil_prevent_specialist_profile_404($query) {
    if (is_admin() || !$query->is_main_query()) {
        return;
    }
    
    $request_uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
    
    if (strpos($request_uri, '/specialist-profile') !== false || strpos($request_uri, 'specialist-profile') !== false) {
        $page = get_page_by_path('specialist-profile');
        
        if ($page && $page->post_status === 'publish') {
            $query->is_404 = false;
            $query->is_page = true;
            $query->is_singular = true;
            $query->queried_object = $page;
            $query->queried_object_id = $page->ID;
            $query->posts = array($page);
            $query->post_count = 1;
            $query->found_posts = 1;
        }
    }
}
add_action('parse_query', 'nidfil_prevent_specialist_profile_404');

/**
 * Ensure correct template is used for specialist-profile page
 */
function nidfil_force_specialist_profile_template($template) {
    global $wp_query, $post;
    
    // Check if we're on the specialist-profile page
    $is_specialist_profile = false;
    $request_uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
    
    // Check various ways the page might be accessed
    if (isset($wp_query->query_vars['pagename']) && $wp_query->query_vars['pagename'] === 'specialist-profile') {
        $is_specialist_profile = true;
    } elseif (strpos($request_uri, '/specialist-profile') !== false || strpos($request_uri, 'specialist-profile') !== false) {
        $is_specialist_profile = true;
    } elseif (isset($wp_query->query_vars['name']) && $wp_query->query_vars['name'] === 'specialist-profile') {
        $is_specialist_profile = true;
    } elseif (is_page() && isset($post) && $post->post_name === 'specialist-profile') {
        $is_specialist_profile = true;
    }
    
    if ($is_specialist_profile) {
        // Ensure page exists first
        $page_id = nidfil_create_specialist_profile_page();
        
        if (!$page_id) {
            // Try to find the page
            $page = get_page_by_path('specialist-profile');
            if ($page) {
                $page_id = $page->ID;
            }
        }
        
        if ($page_id) {
            $page = get_post($page_id);
            
            if ($page) {
                // Ensure template is assigned
                $current_template = get_post_meta($page_id, '_wp_page_template', true);
                if ($current_template !== 'page-specialist-profile.php') {
                    update_post_meta($page_id, '_wp_page_template', 'page-specialist-profile.php');
                }
                
                // Set up the post object
                $post = $page;
                setup_postdata($post);
                
                // Fix the query
                $wp_query->queried_object = $post;
                $wp_query->queried_object_id = $post->ID;
                $wp_query->is_page = true;
                $wp_query->is_singular = true;
                $wp_query->is_404 = false;
                $wp_query->posts = array($post);
                $wp_query->post_count = 1;
                $wp_query->found_posts = 1;
                
                // Load the template file
                $template_file = get_template_directory() . '/page-specialist-profile.php';
                if (file_exists($template_file)) {
                    return $template_file;
                }
            }
        }
    }
    
    return $template;
}
add_filter('template_include', 'nidfil_force_specialist_profile_template', 99);

/**
 * Ensure checkout page exists and is set up correctly
 */
function nidfil_ensure_checkout_page() {
    global $wp_query, $post;
    
    // Check if we're on the checkout page
    $is_checkout = false;
    $request_uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
    
    // Check various ways the page might be accessed
    if (isset($wp_query->query_vars['pagename']) && $wp_query->query_vars['pagename'] === 'checkout') {
        $is_checkout = true;
    } elseif (strpos($request_uri, '/checkout') !== false || strpos($request_uri, 'checkout') !== false) {
        $is_checkout = true;
    } elseif (isset($wp_query->query_vars['name']) && $wp_query->query_vars['name'] === 'checkout') {
        $is_checkout = true;
    } elseif (is_page() && isset($post) && $post->post_name === 'checkout') {
        $is_checkout = true;
    }
    
    if ($is_checkout) {
        // Ensure page exists first
        $page_id = nidfil_create_checkout_page();
        
        if (!$page_id) {
            // Try to find the page
            $page = get_page_by_path('checkout');
            if ($page) {
                $page_id = $page->ID;
            }
        }
        
        if ($page_id) {
            $page = get_post($page_id);
            
            if ($page) {
                // Ensure template is assigned
                $current_template = get_post_meta($page_id, '_wp_page_template', true);
                if ($current_template !== 'page-checkout.php') {
                    update_post_meta($page_id, '_wp_page_template', 'page-checkout.php');
                }
                
                // Set up the post object
                $post = $page;
                setup_postdata($post);
                
                // Fix the query
                $wp_query->queried_object = $post;
                $wp_query->queried_object_id = $post->ID;
                $wp_query->is_page = true;
                $wp_query->is_singular = true;
                $wp_query->is_404 = false;
                $wp_query->posts = array($post);
                $wp_query->post_count = 1;
                $wp_query->found_posts = 1;
                
                // Set the template
                $wp_query->is_page_template = true;
            }
        }
    }
}
add_action('template_redirect', 'nidfil_ensure_checkout_page', 1);

/**
 * Prevent 404 on checkout page
 */
function nidfil_prevent_checkout_404($query) {
    if (is_admin() || !$query->is_main_query()) {
        return;
    }
    
    $request_uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
    
    if (strpos($request_uri, '/checkout') !== false || strpos($request_uri, 'checkout') !== false) {
        $page = get_page_by_path('checkout');
        
        if ($page && $page->post_status === 'publish') {
            $query->is_404 = false;
            $query->is_page = true;
            $query->is_singular = true;
            $query->queried_object = $page;
            $query->queried_object_id = $page->ID;
            $query->posts = array($page);
            $query->post_count = 1;
            $query->found_posts = 1;
        }
    }
}
add_action('parse_query', 'nidfil_prevent_checkout_404');

/**
 * Ensure correct template is used for checkout page
 */
function nidfil_force_checkout_template($template) {
    global $wp_query, $post;
    
    // Check if we're on the checkout page
    $is_checkout = false;
    $request_uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
    
    // Check various ways the page might be accessed
    if (isset($wp_query->query_vars['pagename']) && $wp_query->query_vars['pagename'] === 'checkout') {
        $is_checkout = true;
    } elseif (strpos($request_uri, '/checkout') !== false || strpos($request_uri, 'checkout') !== false) {
        $is_checkout = true;
    } elseif (isset($wp_query->query_vars['name']) && $wp_query->query_vars['name'] === 'checkout') {
        $is_checkout = true;
    } elseif (is_page() && isset($post) && $post->post_name === 'checkout') {
        $is_checkout = true;
    }
    
    if ($is_checkout) {
        // Ensure page exists first
        $page_id = nidfil_create_checkout_page();
        
        if (!$page_id) {
            // Try to find the page
            $page = get_page_by_path('checkout');
            if ($page) {
                $page_id = $page->ID;
            }
        }
        
        if ($page_id) {
            $page = get_post($page_id);
            
            if ($page) {
                // Ensure template is assigned
                $current_template = get_post_meta($page_id, '_wp_page_template', true);
                if ($current_template !== 'page-checkout.php') {
                    update_post_meta($page_id, '_wp_page_template', 'page-checkout.php');
                }
                
                // Set up the post object
                $post = $page;
                setup_postdata($post);
                
                // Fix the query
                $wp_query->queried_object = $post;
                $wp_query->queried_object_id = $post->ID;
                $wp_query->is_page = true;
                $wp_query->is_singular = true;
                $wp_query->is_404 = false;
                $wp_query->posts = array($post);
                $wp_query->post_count = 1;
                $wp_query->found_posts = 1;
                
                // Load the template file
                $template_file = get_template_directory() . '/page-checkout.php';
                if (file_exists($template_file)) {
                    return $template_file;
                }
            }
        }
    }
    
    return $template;
}
add_filter('template_include', 'nidfil_force_checkout_template', 99);

/**
 * Helper function to get client profile URL (main redirect after login)
 */
function nidfil_get_dashboard_url() {
    // Ensure page exists first
    $page_id = nidfil_create_client_profile_page();
    
    if ($page_id) {
        $url = get_permalink($page_id);
        if ($url) {
            return $url;
        }
    }
    
    // Try to find Client Profile page
    $client_profile_page = get_pages(array(
        'meta_key' => '_wp_page_template',
        'meta_value' => 'page-client-profile.php',
        'number' => 1,
        'post_status' => 'publish'
    ));
    
    if (!empty($client_profile_page)) {
        $url = get_permalink($client_profile_page[0]->ID);
        if ($url) {
            return $url;
        }
    }
    
    // Last resort fallback - create page and return URL
    $page_id = nidfil_create_client_profile_page();
    if ($page_id) {
        $url = get_permalink($page_id);
        if ($url) {
            return $url;
        }
    }
    
    // Final fallback
    return home_url('/client-profile/');
}

/**
 * Enqueue Scripts and Styles
 */
function nidfil_connect_scripts() {
    // Enqueue theme stylesheet
    wp_enqueue_style('nidfil-connect-style', get_stylesheet_uri(), array(), '1.0.0');
    
    // Enqueue Google Fonts
    wp_enqueue_style('google-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Poppins:wght@400;500;600;700&family=Montserrat:wght@400;500;600;700&display=swap', array(), null);
    
    // Enqueue Font Awesome for icons
    wp_enqueue_style(
        'font-awesome',
        'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css',
        array(),
        '6.5.2',
        'all'
    );
    
    // Enqueue theme JavaScript
    wp_enqueue_script('nidfil-connect-script', get_template_directory_uri() . '/js/main.js', array(), '1.0.0', true);
    
    // Get dashboard URL using helper function
    $dashboard_url = nidfil_get_dashboard_url();
    $specialist_dashboard_url = nidfil_get_specialist_dashboard_url();
    
    // Localize script for AJAX
    wp_localize_script('nidfil-connect-script', 'nidfilAjax', array(
        'ajaxurl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('nidfil_nonce'),
        'dashboard_url' => $dashboard_url,
        'specialist_dashboard_url' => $specialist_dashboard_url,
        'current_user_id' => get_current_user_id(),
    ));
}
add_action('wp_enqueue_scripts', 'nidfil_connect_scripts');

/**
 * Register Widget Areas
 */
function nidfil_connect_widgets_init() {
    register_sidebar(array(
        'name' => __('Sidebar', 'nidfil-connect'),
        'id' => 'sidebar-1',
        'description' => __('Add widgets here.', 'nidfil-connect'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget' => '</section>',
        'before_title' => '<h2 class="widget-title">',
        'after_title' => '</h2>',
    ));
}
add_action('widgets_init', 'nidfil_connect_widgets_init');

/**
 * Customizer Settings
 */
function nidfil_connect_customize_register($wp_customize) {
    // Add section for theme options
    $wp_customize->add_section('nidfil_theme_options', array(
        'title' => __('Theme Options', 'nidfil-connect'),
        'priority' => 30,
    ));
    
    // Add setting for hero title
    $wp_customize->add_setting('hero_title', array(
        'default' => 'Un espacio digital para',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('hero_title', array(
        'label' => __('Hero Title', 'nidfil-connect'),
        'section' => 'nidfil_theme_options',
        'type' => 'text',
    ));
    
    // Add setting for hero highlight
    $wp_customize->add_setting('hero_highlight', array(
        'default' => 'YOUR REFORM IS VERY CLOSE',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('hero_highlight', array(
        'label' => __('Hero Highlight Text', 'nidfil-connect'),
        'section' => 'nidfil_theme_options',
        'type' => 'text',
    ));
    
    // Add setting for hero subtitle
    $wp_customize->add_setting('hero_subtitle', array(
        'default' => 'Encuentra a tu especialista de confianza',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('hero_subtitle', array(
        'label' => __('Hero Subtitle', 'nidfil-connect'),
        'section' => 'nidfil_theme_options',
        'type' => 'text',
    ));
}
add_action('customize_register', 'nidfil_connect_customize_register');

/**
 * Get Theme Option Helper
 */
function nidfil_get_option($option_name, $default = '') {
    return get_theme_mod($option_name, $default);
}

/**
 * Include additional files
 */
require_once get_template_directory() . '/inc/template-functions.php';

/**
 * Include access forms only during page rendering (not during AJAX requests)
 */
function nidfil_include_access_forms() {
    // Only include if not an AJAX request
    if (!wp_doing_ajax()) {
        require_once get_template_directory() . '/inc/access-forms.php';
    }
}
add_action('wp_footer', 'nidfil_include_access_forms', 1);

/**
 * Dashboard AJAX Handlers
 */

// Save Profile Image
function nidfil_save_profile_image() {
    check_ajax_referer('nidfil_nonce', 'nonce');
    
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'User not logged in'));
        return;
    }
    
    if (!isset($_FILES['profile_image'])) {
        wp_send_json_error(array('message' => 'No file uploaded'));
        return;
    }
    
    require_once(ABSPATH . 'wp-admin/includes/image.php');
    require_once(ABSPATH . 'wp-admin/includes/file.php');
    require_once(ABSPATH . 'wp-admin/includes/media.php');
    
    $attachment_id = media_handle_upload('profile_image', 0);
    
    if (is_wp_error($attachment_id)) {
        wp_send_json_error(array('message' => $attachment_id->get_error_message()));
        return;
    }
    
    // Update user meta
    $user_id = get_current_user_id();
    update_user_meta($user_id, 'profile_image', $attachment_id);
    
    // Get different image sizes
    $thumbnail_url = wp_get_attachment_image_url($attachment_id, 'thumbnail');
    $medium_url = wp_get_attachment_image_url($attachment_id, 'medium');
    $full_url = wp_get_attachment_image_url($attachment_id, 'full');
    
    wp_send_json_success(array(
        'image_url' => $thumbnail_url,
        'medium_url' => $medium_url,
        'full_url' => $full_url,
        'message' => 'Imagen guardada correctamente'
    ));
}
add_action('wp_ajax_nidfil_save_profile_image', 'nidfil_save_profile_image');

// Save Bio
function nidfil_save_bio() {
    check_ajax_referer('nidfil_nonce', 'nonce');
    
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'User not logged in'));
        return;
    }
    
    $bio = sanitize_textarea_field($_POST['bio']);
    update_user_meta(get_current_user_id(), 'user_bio', $bio);
    
    wp_send_json_success(array('message' => 'Bio saved successfully'));
}
add_action('wp_ajax_nidfil_save_bio', 'nidfil_save_bio');

// Save Personal Info
function nidfil_save_personal_info() {
    check_ajax_referer('nidfil_nonce', 'nonce');
    
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'User not logged in'));
        return;
    }
    
    $user_id = get_current_user_id();
    $data = array();
    
    if (isset($_POST['full_name'])) {
        $data['display_name'] = sanitize_text_field($_POST['full_name']);
    }
    if (isset($_POST['email'])) {
        $data['user_email'] = sanitize_email($_POST['email']);
    }
    if (isset($_POST['phone'])) {
        update_user_meta($user_id, 'user_phone', sanitize_text_field($_POST['phone']));
    }
    if (isset($_POST['location'])) {
        update_user_meta($user_id, 'user_location', sanitize_text_field($_POST['location']));
    }
    
    if (!empty($data)) {
        $data['ID'] = $user_id;
        wp_update_user($data);
    }
    
    wp_send_json_success(array('message' => 'Information saved successfully'));
}
add_action('wp_ajax_nidfil_save_personal_info', 'nidfil_save_personal_info');

// Save Skills
function nidfil_save_skills() {
    check_ajax_referer('nidfil_nonce', 'nonce');
    
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'User not logged in'));
        return;
    }
    
    $skills = sanitize_text_field($_POST['skills']);
    update_user_meta(get_current_user_id(), 'user_skills', $skills);
    
    wp_send_json_success(array('message' => 'Skills saved successfully'));
}
add_action('wp_ajax_nidfil_save_skills', 'nidfil_save_skills');

// Save Social Media Links
function nidfil_save_social_links() {
    check_ajax_referer('nidfil_nonce', 'nonce');
    
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'User not logged in'));
        return;
    }
    
    $user_id = get_current_user_id();
    
    if (isset($_POST['facebook'])) {
        update_user_meta($user_id, 'social_facebook', sanitize_text_field($_POST['facebook']));
    }
    if (isset($_POST['twitter'])) {
        update_user_meta($user_id, 'social_twitter', sanitize_text_field($_POST['twitter']));
    }
    if (isset($_POST['instagram'])) {
        update_user_meta($user_id, 'social_instagram', sanitize_text_field($_POST['instagram']));
    }
    if (isset($_POST['linkedin'])) {
        update_user_meta($user_id, 'social_linkedin', sanitize_text_field($_POST['linkedin']));
    }
    
    wp_send_json_success(array('message' => 'Social links saved successfully'));
}
add_action('wp_ajax_nidfil_save_social_links', 'nidfil_save_social_links');

// Save Review
function nidfil_save_review() {
    check_ajax_referer('nidfil_nonce', 'nonce');
    
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'User not logged in'));
        return;
    }
    
    $rating = intval($_POST['rating']);
    $review = sanitize_textarea_field($_POST['review']);
    $user_id = get_current_user_id();
    
    // You can save this to a custom post type or user meta
    // Example: Save as user meta
    $reviews = get_user_meta($user_id, 'user_reviews', true) ?: array();
    $reviews[] = array(
        'rating' => $rating,
        'review' => $review,
        'date' => current_time('mysql')
    );
    update_user_meta($user_id, 'user_reviews', $reviews);
    
    wp_send_json_success(array('message' => 'Review saved successfully'));
}
add_action('wp_ajax_nidfil_save_review', 'nidfil_save_review');

/**
 * User Registration Handler
 */
function nidfil_register_user() {
    check_ajax_referer('nidfil_nonce', 'nonce');
    
    $name = sanitize_text_field($_POST['name']);
    $email = sanitize_email($_POST['email']);
    $phone = sanitize_text_field($_POST['phone']);
    $password = $_POST['password'];
    
    // Validate required fields
    if (empty($name) || empty($email) || empty($password)) {
        wp_send_json_error(array('message' => 'Por favor, completa todos los campos requeridos.'));
        return;
    }
    
    // Check if email already exists
    if (email_exists($email)) {
        wp_send_json_error(array('message' => 'Este email ya está registrado.'));
        return;
    }
    
    // Check if username already exists
    $username = sanitize_user($email);
    if (username_exists($username)) {
        $username = sanitize_user($name) . '_' . rand(1000, 9999);
    }
    
    // Create user
    $user_id = wp_create_user($username, $password, $email);
    
    if (is_wp_error($user_id)) {
        wp_send_json_error(array('message' => $user_id->get_error_message()));
        return;
    }
    
    
    // Update user display name
    wp_update_user(array(
        'ID' => $user_id,
        'display_name' => $name
    ));
    
    // Save customer-specific meta data
    update_user_meta($user_id, 'user_type', 'customer');
    if (!empty($phone)) {
        update_user_meta($user_id, 'user_phone', $phone);
    }
    
    // Ensure client profile page exists before redirecting
    $page_id = nidfil_create_client_profile_page();
    if ($page_id) {
        // Flush rewrite rules to ensure URL works
        flush_rewrite_rules(false);
        // Clear any caches
        clean_post_cache($page_id);
    }
    
    // Auto login the user using wp_signon for proper authentication
    wp_clear_auth_cookie();
    wp_set_current_user($user_id);
    wp_set_auth_cookie($user_id, true);
    do_action('wp_login', $username, get_userdata($user_id));
    
    // Get dashboard URL using helper function
    $dashboard_url = nidfil_get_dashboard_url();
    
    // Ensure URL is absolute and valid
    if (!filter_var($dashboard_url, FILTER_VALIDATE_URL)) {
        if ($page_id) {
            $dashboard_url = get_permalink($page_id);
        } else {
            $dashboard_url = home_url('/client-profile/');
        }
    }
    
    // Verify the URL exists
    if (empty($dashboard_url)) {
        $dashboard_url = home_url('/client-profile/');
    }
    
    wp_send_json_success(array(
        'message' => 'Registro exitoso. Redirigiendo...',
        'redirect_url' => $dashboard_url,
        'page_id' => $page_id
    ));
}
add_action('wp_ajax_nidfil_register', 'nidfil_register_user');
add_action('wp_ajax_nopriv_nidfil_register', 'nidfil_register_user');

/**
 * User Login Handler
 */
function nidfil_login_user() {
    check_ajax_referer('nidfil_nonce', 'nonce');
    
    $email = sanitize_email($_POST['email']);
    $password = $_POST['password'];
    $remember = isset($_POST['remember']) && $_POST['remember'] === '1' ? true : false;
    
    // Validate required fields
    if (empty($email) || empty($password)) {
        wp_send_json_error(array('message' => 'Por favor, ingresa tu email y contraseña.'));
        return;
    }
    
    // Get user by email
    $user = get_user_by('email', $email);
    
    if (!$user) {
        wp_send_json_error(array('message' => 'Email o contraseña incorrectos.'));
        return;
    }
    
    // Use WordPress signon function for proper authentication
    $credentials = array(
        'user_login'    => $user->user_login,
        'user_password' => $password,
        'remember'      => $remember
    );
    
    $user_signon = wp_signon($credentials, false);
    
    if (is_wp_error($user_signon)) {
        wp_send_json_error(array('message' => 'Email o contraseña incorrectos.'));
        return;
    }
    
    // Ensure client profile page exists before redirecting
    $page_id = nidfil_create_client_profile_page();
    if ($page_id) {
        // Flush rewrite rules to ensure URL works
        flush_rewrite_rules(false);
        // Clear any caches
        clean_post_cache($page_id);
    }
    
    // Get dashboard URL based on user_type (not WordPress role)
    $user_type = get_user_meta($user->ID, 'user_type', true);
    $dashboard_url = '';
    
    if ($user_type === 'specialist') {
        // Redirect to specialist dashboard
        $specialist_page_id = nidfil_create_specialist_profile_page();
        if ($specialist_page_id) {
            flush_rewrite_rules(false);
            clean_post_cache($specialist_page_id);
            $dashboard_url = get_permalink($specialist_page_id);
        }
        if (empty($dashboard_url)) {
            $dashboard_url = home_url('/specialist-profile/');
        }
    } else {
        // Default to client dashboard
        $dashboard_url = nidfil_get_dashboard_url();
    }
    
    // Ensure URL is absolute and valid
    if (empty($dashboard_url) || !filter_var($dashboard_url, FILTER_VALIDATE_URL)) {
        if ($page_id) {
            $dashboard_url = get_permalink($page_id);
        }
        if (empty($dashboard_url) || !filter_var($dashboard_url, FILTER_VALIDATE_URL)) {
            $dashboard_url = home_url('/client-profile/');
        }
    }
    
    wp_send_json_success(array(
        'message' => 'Inicio de sesión exitoso. Redirigiendo...',
        'redirect_url' => $dashboard_url,
        'page_id' => $page_id
    ));
}
add_action('wp_ajax_nidfil_login', 'nidfil_login_user');
add_action('wp_ajax_nopriv_nidfil_login', 'nidfil_login_user');

/**
 * Specialist Registration Handler
 */
function nidfil_register_specialist() {
    check_ajax_referer('nidfil_nonce', 'nonce');
    
    $name = sanitize_text_field($_POST['name']);
    $email = sanitize_email($_POST['email']);
    $phone = sanitize_text_field($_POST['phone']);
    $profession = sanitize_text_field($_POST['profession']);
    $experience = intval($_POST['experience']);
    $password = $_POST['password'];
    
    // Validate required fields
    if (empty($name) || empty($email) || empty($password) || empty($profession) || empty($experience)) {
        wp_send_json_error(array('message' => 'Por favor, completa todos los campos requeridos.'));
        return;
    }
    
    // Check if email already exists
    if (email_exists($email)) {
        wp_send_json_error(array('message' => 'Este email ya está registrado.'));
        return;
    }
    
    // Check if username already exists
    $username = sanitize_user($email);
    if (username_exists($username)) {
        $username = sanitize_user($name) . '_' . rand(1000, 9999);
    }
    
    // Create user
    $user_id = wp_create_user($username, $password, $email);
    
    if (is_wp_error($user_id)) {
        wp_send_json_error(array('message' => $user_id->get_error_message()));
        return;
    }
    
    
    // Update user display name
    wp_update_user(array(
        'ID' => $user_id,
        'display_name' => $name
    ));
    
    // Save specialist-specific meta data
    update_user_meta($user_id, 'user_type', 'specialist');
    update_user_meta($user_id, 'user_phone', $phone);
    update_user_meta($user_id, 'profession', $profession);
    update_user_meta($user_id, 'experience_years', $experience);
    
    // Ensure specialist profile page exists before redirecting
    $page_id = nidfil_create_specialist_profile_page();
    if ($page_id) {
        flush_rewrite_rules(false);
        clean_post_cache($page_id);
    }
    
    // Auto login the user
    wp_clear_auth_cookie();
    wp_set_current_user($user_id);
    wp_set_auth_cookie($user_id, true);
    do_action('wp_login', $username, get_userdata($user_id));
    
    // Get specialist dashboard URL
    $dashboard_url = '';
    if ($page_id) {
        $dashboard_url = get_permalink($page_id);
        // Ensure URL is absolute
        if (!filter_var($dashboard_url, FILTER_VALIDATE_URL)) {
            $dashboard_url = home_url('/specialist-profile/');
        }
    } else {
        $dashboard_url = home_url('/specialist-profile/');
    }
    
    // Ensure URL is absolute
    if (!filter_var($dashboard_url, FILTER_VALIDATE_URL)) {
        $dashboard_url = home_url('/specialist-profile/');
    }
    
    wp_send_json_success(array(
        'message' => 'Registro exitoso. Redirigiendo...',
        'redirect_url' => $dashboard_url,
        'page_id' => $page_id
    ));
}
add_action('wp_ajax_nidfil_register_specialist', 'nidfil_register_specialist');
add_action('wp_ajax_nopriv_nidfil_register_specialist', 'nidfil_register_specialist');

/**
 * Specialist Login Handler
 */
function nidfil_login_specialist() {
    check_ajax_referer('nidfil_nonce', 'nonce');
    
    $email = sanitize_email($_POST['email']);
    $password = $_POST['password'];
    $remember = isset($_POST['remember']) && $_POST['remember'] === '1';
    
    if (empty($email) || empty($password)) {
        wp_send_json_error(array('message' => 'Por favor, completa todos los campos.'));
        return;
    }
    
    // Try to get user by email
    $user = get_user_by('email', $email);
    
    if (!$user) {
        wp_send_json_error(array('message' => 'Email o contraseña incorrectos.'));
        return;
    }
    
    // Check if user is a specialist
    $user_type = get_user_meta($user->ID, 'user_type', true);
    if ($user_type !== 'specialist') {
        wp_send_json_error(array('message' => 'Esta cuenta no es de especialista. Por favor, usa el acceso de cliente.'));
        return;
    }
    
    // Authenticate user
    $creds = array(
        'user_login' => $user->user_login,
        'user_password' => $password,
        'remember' => $remember
    );
    
    $user_signon = wp_signon($creds, false);
    
    if (is_wp_error($user_signon)) {
        wp_send_json_error(array('message' => 'Email o contraseña incorrectos.'));
        return;
    }
    
    // Ensure specialist profile page exists
    $page_id = nidfil_create_specialist_profile_page();
    if ($page_id) {
        flush_rewrite_rules(false);
        clean_post_cache($page_id);
    }
    
    // Get specialist dashboard URL
    $dashboard_url = '';
    if ($page_id) {
        $dashboard_url = get_permalink($page_id);
    } else {
        $dashboard_url = home_url('/specialist-profile/');
    }
    
    wp_send_json_success(array(
        'message' => 'Inicio de sesión exitoso. Redirigiendo...',
        'redirect_url' => $dashboard_url
    ));
}
add_action('wp_ajax_nidfil_login_specialist', 'nidfil_login_specialist');
add_action('wp_ajax_nopriv_nidfil_login_specialist', 'nidfil_login_specialist');

/**
 * Request OTP for Password Reset
 */
function nidfil_request_otp() {
    check_ajax_referer('nidfil_nonce', 'nonce');
    
    $email = sanitize_email($_POST['email']);
    
    // Validate email
    if (empty($email)) {
        wp_send_json_error(array('message' => 'Por favor, ingresa tu dirección de email.'));
        return;
    }
    
    if (!is_email($email)) {
        wp_send_json_error(array('message' => 'Por favor, ingresa una dirección de email válida.'));
        return;
    }
    
    // Get user by email
    $user = get_user_by('email', $email);
    
    // Always return success message for security (don't reveal if email exists)
    if (!$user) {
        wp_send_json_success(array(
            'message' => 'Si el email existe en nuestro sistema, recibirás un código OTP.'
        ));
        return;
    }
    
    // Generate 6-digit OTP
    $otp = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);
    
    // Store OTP with expiration (2 minutes = 120 seconds)
    $otp_data = array(
        'otp' => $otp,
        'expires' => time() + 120, // 2 minutes from now
        'attempts' => 0
    );
    
    // Store in user meta (this invalidates any previous OTP)
    update_user_meta($user->ID, 'password_reset_otp', $otp_data);
    
    // Email subject
    $subject = __('Código OTP para restablecer contraseña - NIDFIL', 'nidfil-connect');
    
    // Email message
    $message = sprintf(
        __('Hola %s,', 'nidfil-connect') . "\n\n" .
        __('Has solicitado restablecer tu contraseña en NIDFIL.', 'nidfil-connect') . "\n\n" .
        __('Tu código OTP es:', 'nidfil-connect') . "\n\n" .
        '%s' . "\n\n" .
        __('Este código es válido por 2 minutos.', 'nidfil-connect') . "\n\n" .
        __('Si no solicitaste este cambio, puedes ignorar este email.', 'nidfil-connect') . "\n\n" .
        __('Saludos,', 'nidfil-connect') . "\n" .
        __('El equipo de NIDFIL', 'nidfil-connect'),
        $user->display_name,
        $otp
    );
    
    // Check if we're in development mode (localhost)
    $is_localhost = (strpos($_SERVER['HTTP_HOST'], 'localhost') !== false || 
                     strpos($_SERVER['HTTP_HOST'], '127.0.0.1') !== false ||
                     strpos($_SERVER['HTTP_HOST'], '.local') !== false);
    
    // Send email
    $sent = wp_mail(
        $user->user_email,
        $subject,
        $message,
        array('Content-Type: text/plain; charset=UTF-8')
    );
    
    // Log for debugging
    error_log('OTP Request - Email: ' . $email . ', OTP: ' . $otp . ', Sent: ' . ($sent ? 'Yes' : 'No'));
    
    if ($sent) {
        $response_data = array(
            'message' => 'Código OTP enviado a tu email. Por favor, revisa tu bandeja de entrada.'
        );
        
        // In development/localhost, also return OTP in response for testing
        if ($is_localhost) {
            $response_data['debug_otp'] = $otp;
            $response_data['debug_message'] = 'Modo desarrollo: El código OTP también se muestra aquí para pruebas.';
        }
        
        wp_send_json_success($response_data);
    } else {
        // Even if email sending fails, return success with OTP for development
        // This allows testing without email configuration
        if ($is_localhost) {
            $response_data = array(
                'message' => 'Código OTP generado (modo desarrollo - email no enviado).',
                'debug_otp' => $otp,
                'debug_message' => 'En desarrollo: El email no se pudo enviar, pero aquí está el código OTP para pruebas.'
            );
            wp_send_json_success($response_data);
        } else {
            // In production, return error if email fails
            wp_send_json_error(array(
                'message' => 'Error al enviar el código OTP. Por favor, intenta de nuevo más tarde.'
            ));
        }
    }
}
add_action('wp_ajax_nidfil_request_otp', 'nidfil_request_otp');
add_action('wp_ajax_nopriv_nidfil_request_otp', 'nidfil_request_otp');

/**
 * Verify OTP for Password Reset
 */
function nidfil_verify_otp() {
    check_ajax_referer('nidfil_nonce', 'nonce');
    
    $email = sanitize_email($_POST['email']);
    $otp = sanitize_text_field($_POST['otp']);
    
    // Validate inputs
    if (empty($email) || empty($otp)) {
        wp_send_json_error(array('message' => 'Por favor, completa todos los campos.'));
        return;
    }
    
    if (!is_email($email)) {
        wp_send_json_error(array('message' => 'Email inválido.'));
        return;
    }
    
    if (strlen($otp) !== 6 || !ctype_digit($otp)) {
        wp_send_json_error(array('message' => 'El código OTP debe tener 6 dígitos.'));
        return;
    }
    
    // Get user by email
    $user = get_user_by('email', $email);
    
    if (!$user) {
        wp_send_json_error(array('message' => 'Email no encontrado.'));
        return;
    }
    
    // Get stored OTP data
    $otp_data = get_user_meta($user->ID, 'password_reset_otp', true);
    
    if (empty($otp_data) || !is_array($otp_data)) {
        wp_send_json_error(array('message' => 'Código OTP no encontrado o expirado. Por favor, solicita uno nuevo.'));
        return;
    }
    
    // Check if OTP is expired
    if (time() > $otp_data['expires']) {
        delete_user_meta($user->ID, 'password_reset_otp');
        wp_send_json_error(array('message' => 'El código OTP ha expirado. Por favor, solicita uno nuevo.'));
        return;
    }
    
    // Verify OTP
    if ($otp_data['otp'] !== $otp) {
        // Increment attempts
        $otp_data['attempts'] = isset($otp_data['attempts']) ? $otp_data['attempts'] + 1 : 1;
        update_user_meta($user->ID, 'password_reset_otp', $otp_data);
        
        wp_send_json_error(array('message' => 'Código OTP incorrecto. Por favor, verifica e intenta de nuevo.'));
        return;
    }
    
    // OTP is valid - mark as verified (don't delete yet, need it for password update)
    $otp_data['verified'] = true;
    update_user_meta($user->ID, 'password_reset_otp', $otp_data);
    
    wp_send_json_success(array(
        'message' => 'Código OTP verificado correctamente.'
    ));
}
add_action('wp_ajax_nidfil_verify_otp', 'nidfil_verify_otp');
add_action('wp_ajax_nopriv_nidfil_verify_otp', 'nidfil_verify_otp');

/**
 * Update Password After OTP Verification
 */
function nidfil_update_password() {
    check_ajax_referer('nidfil_nonce', 'nonce');
    
    $email = sanitize_email($_POST['email']);
    $new_password = $_POST['new_password'];
    
    // Validate inputs
    if (empty($email) || empty($new_password)) {
        wp_send_json_error(array('message' => 'Por favor, completa todos los campos.'));
        return;
    }
    
    if (!is_email($email)) {
        wp_send_json_error(array('message' => 'Email inválido.'));
        return;
    }
    
    // Validate password rules
    if (strlen($new_password) < 6) {
        wp_send_json_error(array('message' => 'La contraseña debe tener al menos 6 caracteres.'));
        return;
    }
    
    // Additional password strength validation (optional)
    // You can add more rules here if needed (e.g., require uppercase, special characters, etc.)
    
    // Get user by email
    $user = get_user_by('email', $email);
    
    if (!$user) {
        wp_send_json_error(array('message' => 'Usuario no encontrado.'));
        return;
    }
    
    // Verify OTP was verified
    $otp_data = get_user_meta($user->ID, 'password_reset_otp', true);
    
    if (empty($otp_data) || !isset($otp_data['verified']) || !$otp_data['verified']) {
        wp_send_json_error(array('message' => 'Por favor, verifica el código OTP primero.'));
        return;
    }
    
    // Check if OTP is still valid (not expired)
    if (time() > $otp_data['expires']) {
        delete_user_meta($user->ID, 'password_reset_otp');
        wp_send_json_error(array('message' => 'La sesión ha expirado. Por favor, inicia el proceso nuevamente.'));
        return;
    }
    
    // Update password
    wp_set_password($new_password, $user->ID);
    
    // Delete OTP data (invalidate after use)
    delete_user_meta($user->ID, 'password_reset_otp');
    
    // Send confirmation email
    $subject = __('Contraseña actualizada - NIDFIL', 'nidfil-connect');
    $message = sprintf(
        __('Hola %s,', 'nidfil-connect') . "\n\n" .
        __('Tu contraseña ha sido actualizada exitosamente.', 'nidfil-connect') . "\n\n" .
        __('Si no realizaste este cambio, por favor contacta con soporte inmediatamente.', 'nidfil-connect') . "\n\n" .
        __('Saludos,', 'nidfil-connect') . "\n" .
        __('El equipo de NIDFIL', 'nidfil-connect'),
        $user->display_name
    );
    
    wp_mail($user->user_email, $subject, $message, array('Content-Type: text/plain; charset=UTF-8'));
    
    wp_send_json_success(array(
        'message' => 'Contraseña actualizada exitosamente. Ahora puedes iniciar sesión con tu nueva contraseña.'
    ));
}
add_action('wp_ajax_nidfil_update_password', 'nidfil_update_password');
add_action('wp_ajax_nopriv_nidfil_update_password', 'nidfil_update_password');

/**
 * Save Professional Information (Specialist)
 */
function nidfil_save_professional_info() {
    check_ajax_referer('nidfil_nonce', 'nonce');
    
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'User not logged in'));
        return;
    }
    
    $user_id = get_current_user_id();
    $profession = sanitize_text_field($_POST['profession'] ?? '');
    $experience = intval($_POST['experience'] ?? 0);
    $service_area = sanitize_text_field($_POST['service_area'] ?? '');
    $languages = sanitize_text_field($_POST['languages'] ?? '');
    
    update_user_meta($user_id, 'profession', $profession);
    update_user_meta($user_id, 'experience_years', $experience);
    update_user_meta($user_id, 'service_area', $service_area);
    update_user_meta($user_id, 'languages', $languages);
    
    wp_send_json_success(array('message' => 'Información profesional guardada correctamente'));
}
add_action('wp_ajax_nidfil_save_professional_info', 'nidfil_save_professional_info');

/**
 * Save Verification Information (Specialist)
 */
function nidfil_save_verification_info() {
    check_ajax_referer('nidfil_nonce', 'nonce');
    
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'User not logged in'));
        return;
    }
    
    $user_id = get_current_user_id();
    $autonomous_worker = sanitize_text_field($_POST['autonomous_worker'] ?? '');
    $cif = sanitize_text_field($_POST['cif'] ?? '');
    $registered_company = sanitize_text_field($_POST['registered_company'] ?? '');
    
    // Validation: At least one field must be filled
    if (empty($autonomous_worker) && empty($cif) && empty($registered_company)) {
        wp_send_json_error(array('message' => 'Debe proporcionar al menos una identificación profesional válida.'));
        return;
    }
    
    update_user_meta($user_id, 'autonomous_worker_number', $autonomous_worker);
    update_user_meta($user_id, 'cif_number', $cif);
    update_user_meta($user_id, 'registered_company', $registered_company);
    
    wp_send_json_success(array('message' => 'Información de verificación guardada correctamente'));
}
add_action('wp_ajax_nidfil_save_verification_info', 'nidfil_save_verification_info');

/**
 * Save Services Offered (Specialist)
 */
function nidfil_save_services() {
    check_ajax_referer('nidfil_nonce', 'nonce');
    
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'User not logged in'));
        return;
    }
    
    $user_id = get_current_user_id();
    $services_text = sanitize_textarea_field($_POST['services'] ?? '');
    
    // Convert textarea lines to array
    $services = array_filter(array_map('trim', explode("\n", $services_text)));
    
    update_user_meta($user_id, 'services_offered', $services);
    
    wp_send_json_success(array('message' => 'Servicios guardados correctamente', 'services' => $services));
}
add_action('wp_ajax_nidfil_save_services', 'nidfil_save_services');

/**
 * Add Service (Specialist)
 */
function nidfil_add_service() {
    check_ajax_referer('nidfil_nonce', 'nonce');
    
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'User not logged in'));
        return;
    }
    
    $user_id = get_current_user_id();
    $service_name = sanitize_text_field($_POST['service_name'] ?? '');
    $service_id = isset($_POST['service_id']) ? intval($_POST['service_id']) : null;
    
    if (empty($service_name)) {
        wp_send_json_error(array('message' => 'El nombre del servicio es requerido'));
        return;
    }
    
    $services = get_user_meta($user_id, 'services_offered', true);
    if (!is_array($services)) {
        $services = array();
    }
    
    // Remove empty values
    $services = array_filter($services);
    
    if ($service_id !== null && isset($services[$service_id])) {
        // Update existing service
        $services[$service_id] = $service_name;
    } else {
        // Add new service
        $services[] = $service_name;
    }
    
    // Re-index array
    $services = array_values($services);
    
    update_user_meta($user_id, 'services_offered', $services);
    
    wp_send_json_success(array('message' => 'Servicio guardado correctamente', 'services' => $services));
}
add_action('wp_ajax_nidfil_add_service', 'nidfil_add_service');

/**
 * Get Services (Specialist)
 */
function nidfil_get_services() {
    check_ajax_referer('nidfil_nonce', 'nonce');
    
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'User not logged in'));
        return;
    }
    
    $user_id = get_current_user_id();
    $services = get_user_meta($user_id, 'services_offered', true);
    
    if (!is_array($services)) {
        $services = array();
    }
    
    // Remove empty values
    $services = array_filter($services);
    $services = array_values($services);
    
    wp_send_json_success(array('services' => $services));
}
add_action('wp_ajax_nidfil_get_services', 'nidfil_get_services');

/**
 * Delete Service (Specialist)
 */
function nidfil_delete_service() {
    check_ajax_referer('nidfil_nonce', 'nonce');
    
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'User not logged in'));
        return;
    }
    
    $user_id = get_current_user_id();
    $service_id = intval($_POST['service_id'] ?? -1);
    
    $services = get_user_meta($user_id, 'services_offered', true);
    if (!is_array($services)) {
        $services = array();
    }
    
    if (isset($services[$service_id])) {
        unset($services[$service_id]);
        // Re-index array
        $services = array_values($services);
        update_user_meta($user_id, 'services_offered', $services);
        wp_send_json_success(array('message' => 'Servicio eliminado correctamente', 'services' => $services));
    } else {
        wp_send_json_error(array('message' => 'Servicio no encontrado'));
    }
}
add_action('wp_ajax_nidfil_delete_service', 'nidfil_delete_service');

/**
 * Save Certifications (Specialist)
 */
function nidfil_save_certifications() {
    check_ajax_referer('nidfil_nonce', 'nonce');
    
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'User not logged in'));
        return;
    }
    
    $user_id = get_current_user_id();
    $certifications_text = sanitize_textarea_field($_POST['certifications'] ?? '');
    
    // Convert textarea lines to array
    $certifications = array_filter(array_map('trim', explode("\n", $certifications_text)));
    
    update_user_meta($user_id, 'certifications', $certifications);
    
    wp_send_json_success(array('message' => 'Certificaciones guardadas correctamente', 'certifications' => $certifications));
}
add_action('wp_ajax_nidfil_save_certifications', 'nidfil_save_certifications');

/**
 * Save Pricing/Rates (Specialist)
 */
function nidfil_save_pricing() {
    check_ajax_referer('nidfil_nonce', 'nonce');
    
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'User not logged in'));
        return;
    }
    
    $user_id = get_current_user_id();
    $hourly_rate = floatval($_POST['hourly_rate'] ?? 0);
    $project_rate = floatval($_POST['project_rate'] ?? 0);
    
    update_user_meta($user_id, 'hourly_rate', $hourly_rate);
    update_user_meta($user_id, 'project_rate', $project_rate);
    
    wp_send_json_success(array('message' => 'Tarifas guardadas correctamente'));
}
add_action('wp_ajax_nidfil_save_pricing', 'nidfil_save_pricing');

/**
 * Save Business Video (Specialist)
 */
function nidfil_save_business_video() {
    check_ajax_referer('nidfil_nonce', 'nonce');
    
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'User not logged in'));
        return;
    }
    
    $user_id = get_current_user_id();
    
    // Check if file was uploaded
    if (!isset($_FILES['business_video']) || $_FILES['business_video']['error'] !== UPLOAD_ERR_OK) {
        wp_send_json_error(array('message' => 'Error al subir el video. Por favor, intenta de nuevo.'));
        return;
    }
    
    // Validate file type
    $allowed_types = array('video/mp4', 'video/webm', 'video/ogg', 'video/quicktime');
    $file_type = wp_check_filetype($_FILES['business_video']['name']);
    $mime_type = $_FILES['business_video']['type'];
    
    if (!in_array($mime_type, $allowed_types) && !in_array($file_type['type'], $allowed_types)) {
        wp_send_json_error(array('message' => 'Formato de video no válido. Usa MP4, WEBM, OGG o MOV.'));
        return;
    }
    
    // Validate file size (max 100MB)
    $max_size = 100 * 1024 * 1024; // 100MB
    if ($_FILES['business_video']['size'] > $max_size) {
        wp_send_json_error(array('message' => 'El video es demasiado grande. Máximo 100MB.'));
        return;
    }
    
    // Delete old video if exists
    $old_video_id = get_user_meta($user_id, 'business_video', true);
    if ($old_video_id) {
        wp_delete_attachment($old_video_id, true);
    }
    
    // Upload the video
    require_once(ABSPATH . 'wp-admin/includes/file.php');
    require_once(ABSPATH . 'wp-admin/includes/media.php');
    require_once(ABSPATH . 'wp-admin/includes/image.php');
    
    $upload = wp_handle_upload($_FILES['business_video'], array('test_form' => false));
    
    if (isset($upload['error'])) {
        wp_send_json_error(array('message' => $upload['error']));
        return;
    }
    
    // Create attachment
    $attachment = array(
        'post_mime_type' => $upload['type'],
        'post_title' => sanitize_file_name(pathinfo($_FILES['business_video']['name'], PATHINFO_FILENAME)),
        'post_content' => '',
        'post_status' => 'inherit'
    );
    
    $attach_id = wp_insert_attachment($attachment, $upload['file']);
    
    if (is_wp_error($attach_id)) {
        wp_send_json_error(array('message' => 'Error al crear el archivo adjunto.'));
        return;
    }
    
    // Generate attachment metadata
    $attach_data = wp_generate_attachment_metadata($attach_id, $upload['file']);
    wp_update_attachment_metadata($attach_id, $attach_data);
    
    // Save video ID to user meta
    update_user_meta($user_id, 'business_video', $attach_id);
    
    wp_send_json_success(array(
        'message' => 'Video guardado correctamente',
        'video_url' => wp_get_attachment_url($attach_id)
    ));
}
add_action('wp_ajax_nidfil_save_business_video', 'nidfil_save_business_video');

/**
 * Remove Business Video (Specialist)
 */
function nidfil_remove_business_video() {
    check_ajax_referer('nidfil_nonce', 'nonce');
    
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'User not logged in'));
        return;
    }
    
    $user_id = get_current_user_id();
    $video_id = get_user_meta($user_id, 'business_video', true);
    
    if ($video_id) {
        wp_delete_attachment($video_id, true);
        delete_user_meta($user_id, 'business_video');
    }
    
    wp_send_json_success(array('message' => 'Video eliminado correctamente'));
}
add_action('wp_ajax_nidfil_remove_business_video', 'nidfil_remove_business_video');

/**
 * Save Business Data (Specialist)
 */
function nidfil_save_business_data() {
    check_ajax_referer('nidfil_nonce', 'nonce');
    
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'User not logged in'));
        return;
    }
    
    $user_id = get_current_user_id();
    
    $business_name = sanitize_text_field($_POST['business_name'] ?? '');
    $office_address = sanitize_text_field($_POST['office_address'] ?? '');
    $business_city = sanitize_text_field($_POST['business_city'] ?? '');
    $business_postal_code = sanitize_text_field($_POST['business_postal_code'] ?? '');
    $business_country = sanitize_text_field($_POST['business_country'] ?? '');
    $business_phone = sanitize_text_field($_POST['business_phone'] ?? '');
    $business_email = sanitize_email($_POST['business_email'] ?? '');
    $business_website = esc_url_raw($_POST['business_website'] ?? '');
    
    update_user_meta($user_id, 'business_name', $business_name);
    update_user_meta($user_id, 'office_address', $office_address);
    update_user_meta($user_id, 'business_city', $business_city);
    update_user_meta($user_id, 'business_postal_code', $business_postal_code);
    update_user_meta($user_id, 'business_country', $business_country);
    update_user_meta($user_id, 'business_phone', $business_phone);
    update_user_meta($user_id, 'business_email', $business_email);
    update_user_meta($user_id, 'business_website', $business_website);
    
    wp_send_json_success(array('message' => 'Datos del negocio guardados correctamente'));
}
add_action('wp_ajax_nidfil_save_business_data', 'nidfil_save_business_data');

/**
 * Helper function to get specialist profile URL
 */
function nidfil_get_specialist_dashboard_url() {
    $page_id = nidfil_create_specialist_profile_page();
    
    if ($page_id) {
        $url = get_permalink($page_id);
        if ($url) {
            return $url;
        }
    }
    
    // Try to find Specialist Profile page
    $specialist_profile_page = get_pages(array(
        'meta_key' => '_wp_page_template',
        'meta_value' => 'page-specialist-profile.php',
        'number' => 1,
        'post_status' => 'publish'
    ));
    
    if (!empty($specialist_profile_page)) {
        $url = get_permalink($specialist_profile_page[0]->ID);
        if ($url) {
            return $url;
        }
    }
    
    // Fallback
    return home_url('/specialist-profile/');
}

/**
 * Helper: get Aviso Legal page URL (ensuring the page exists)
 */
function nidfil_get_aviso_legal_url() {
    $page_id = nidfil_create_aviso_legal_page();

    if ($page_id) {
        $url = get_permalink($page_id);
        if ($url) {
            return $url;
        }
    }

    // Fallback to slug-based URL
    return home_url('/aviso-legal/');
}

function nidfil_get_privacidad_url() {
    $page_id = nidfil_create_privacidad_page();
    if ($page_id) {
        $url = get_permalink($page_id);
        if ($url) {
            return $url;
        }
    }
    return home_url('/politica-de-privacidad/');
}

function nidfil_get_cookies_url() {
    $page_id = nidfil_create_cookies_page();
    if ($page_id) {
        $url = get_permalink($page_id);
        if ($url) {
            return $url;
        }
    }
    return home_url('/politica-de-cookies/');
}

function nidfil_get_condiciones_url() {
    $page_id = nidfil_create_condiciones_page();
    if ($page_id) {
        $url = get_permalink($page_id);
        if ($url) {
            return $url;
        }
    }
    return home_url('/condiciones-de-uso/');
}


function nidfil_login_redirect($redirect_to, $request, $user) {
    if (is_wp_error($user) || !$user) {
        return $redirect_to;
    }
    
    // IMPORTANT: Administrators should go to WordPress admin dashboard
    // Check if user is an administrator
    if (current_user_can('manage_options') || 
        (!empty($user->roles) && in_array('administrator', $user->roles)) ||
        $user->ID == 1) {
        // Redirect administrators to WordPress admin dashboard
        return admin_url();
    }
    
    // Use custom user_type instead of WordPress roles for non-admins
    $user_type = get_user_meta($user->ID, 'user_type', true);
    
    // Check if user is a specialist
    if ($user_type === 'specialist') {
        return nidfil_get_specialist_dashboard_url();
    }
    
    // Default to client profile (for customers or users without user_type)
    return nidfil_get_dashboard_url();
}
add_filter('login_redirect', 'nidfil_login_redirect', 10, 3);

/**
 * Prevent non-admin users from accessing WordPress admin
 * IMPORTANT: Administrators should ALWAYS have access, regardless of user_type
 */
function nidfil_redirect_admin() {
    // Only redirect if we're in admin area and not doing AJAX
    if (!is_admin() || wp_doing_ajax()) {
        return;
    }
    
    // Exclude admin-ajax.php and admin-post.php from redirect
    $request_uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
    if (strpos($request_uri, 'admin-ajax.php') !== false || strpos($request_uri, 'admin-post.php') !== false) {
        return;
    }
    
    $user_id = get_current_user_id();
    if (!$user_id) {
        return;
    }
    
    $user = get_userdata($user_id);
    if (!$user) {
        return;
    }
    
    // CRITICAL: Check if user is an administrator FIRST
    // Administrators should NEVER be redirected, regardless of user_type
    $is_administrator = false;
    
    // Method 1: Check for manage_options capability (most reliable)
    if (current_user_can('manage_options')) {
        $is_administrator = true;
    }
    
    // Method 2: Check if user has administrator role
    if (!empty($user->roles) && in_array('administrator', $user->roles)) {
        $is_administrator = true;
    }
    
    // Method 3: Check if user ID is 1 (first admin user)
    if ($user_id == 1) {
        $is_administrator = true;
        // Ensure user ID 1 has administrator role
        if (empty($user->roles) || !in_array('administrator', $user->roles)) {
            $user->set_role('administrator');
        }
    }
    
    // If user is an administrator, allow access - DO NOT REDIRECT
    if ($is_administrator) {
        return;
    }
    
    // Only redirect NON-ADMINISTRATORS who have user_type set
    // This means they are customers or specialists, not administrators
    $user_type = get_user_meta($user_id, 'user_type', true);
    
    if ($user_type === 'specialist') {
        // Redirect specialists to their dashboard
        wp_redirect(nidfil_get_specialist_dashboard_url());
        exit;
    } elseif ($user_type === 'customer' || !empty($user_type)) {
        // Redirect customers to their dashboard
        wp_redirect(nidfil_get_dashboard_url());
        exit;
    }
    
    // If user has no user_type and is not admin, also redirect to customer dashboard
    // This handles edge cases
    wp_redirect(nidfil_get_dashboard_url());
    exit;
}
add_action('admin_init', 'nidfil_redirect_admin');

/**
 * Hide WordPress admin bar for non-admin users
 */
function nidfil_hide_admin_bar() {
    if (!current_user_can('administrator')) {
        show_admin_bar(false);
    }
}
add_action('init', 'nidfil_hide_admin_bar', 9);

/**
 * Remove admin bar for non-admin users
 */
function nidfil_remove_admin_bar() {
    if (!current_user_can('administrator')) {
        return false;
    }
    return true;
}
add_filter('show_admin_bar', 'nidfil_remove_admin_bar');

/**
 * Create messaging system database tables
 */
function nidfil_create_messaging_tables() {
    global $wpdb;
    
    $charset_collate = $wpdb->get_charset_collate();
    
    // Conversations table
    $table_conversations = $wpdb->prefix . 'nidfil_conversations';
    $sql_conversations = "CREATE TABLE IF NOT EXISTS $table_conversations (
        id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        customer_id bigint(20) UNSIGNED NOT NULL,
        specialist_id bigint(20) UNSIGNED NOT NULL,
        last_message_id bigint(20) UNSIGNED DEFAULT NULL,
        last_message_time datetime DEFAULT NULL,
        customer_unread_count int(11) DEFAULT 0,
        specialist_unread_count int(11) DEFAULT 0,
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY unique_conversation (customer_id, specialist_id),
        KEY customer_id (customer_id),
        KEY specialist_id (specialist_id),
        KEY last_message_time (last_message_time)
    ) $charset_collate;";
    
    // Messages table
    $table_messages = $wpdb->prefix . 'nidfil_messages';
    $sql_messages = "CREATE TABLE IF NOT EXISTS $table_messages (
        id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        conversation_id bigint(20) UNSIGNED NOT NULL,
        sender_id bigint(20) UNSIGNED NOT NULL,
        receiver_id bigint(20) UNSIGNED NOT NULL,
        message_type enum('text', 'image', 'document') DEFAULT 'text',
        message_text text,
        file_url varchar(500) DEFAULT NULL,
        file_name varchar(255) DEFAULT NULL,
        file_size bigint(20) DEFAULT NULL,
        is_read tinyint(1) DEFAULT 0,
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY conversation_id (conversation_id),
        KEY sender_id (sender_id),
        KEY receiver_id (receiver_id),
        KEY created_at (created_at),
        KEY is_read (is_read)
    ) $charset_collate;";
    
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql_conversations);
    dbDelta($sql_messages);
}
add_action('after_setup_theme', 'nidfil_create_messaging_tables');

/**
 * Get or create conversation between customer and specialist
 */
function nidfil_get_or_create_conversation($customer_id, $specialist_id) {
    global $wpdb;
    $table = $wpdb->prefix . 'nidfil_conversations';
    
    // Check if conversation exists
    $conversation = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $table WHERE customer_id = %d AND specialist_id = %d",
        $customer_id,
        $specialist_id
    ));
    
    if ($conversation) {
        return $conversation;
    }
    
    // Create new conversation
    $wpdb->insert(
        $table,
        array(
            'customer_id' => $customer_id,
            'specialist_id' => $specialist_id,
            'created_at' => current_time('mysql')
        ),
        array('%d', '%d', '%s')
    );
    
    return $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $table WHERE customer_id = %d AND specialist_id = %d",
        $customer_id,
        $specialist_id
    ));
}

/**
 * Send message AJAX handler
 */
function nidfil_send_message() {
    check_ajax_referer('nidfil_nonce', 'nonce');
    
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'Debes iniciar sesión para enviar mensajes.'));
        return;
    }
    
    $current_user_id = get_current_user_id();
    $receiver_id = intval($_POST['receiver_id']);
    $message_text = sanitize_textarea_field($_POST['message_text']);
    $message_type = isset($_POST['message_type']) ? sanitize_text_field($_POST['message_type']) : 'text';
    $file_url = isset($_POST['file_url']) ? esc_url_raw($_POST['file_url']) : '';
    $file_name = isset($_POST['file_name']) ? sanitize_text_field($_POST['file_name']) : '';
    $file_size = isset($_POST['file_size']) ? intval($_POST['file_size']) : 0;
    
    if (empty($receiver_id) || empty($message_text) && empty($file_url)) {
        wp_send_json_error(array('message' => 'Por favor, completa todos los campos requeridos.'));
        return;
    }
    
    // Determine if current user is customer or specialist
    $user_type = get_user_meta($current_user_id, 'user_type', true);
    $customer_id = ($user_type === 'client' || empty($user_type)) ? $current_user_id : $receiver_id;
    $specialist_id = ($user_type === 'specialist') ? $current_user_id : $receiver_id;
    
    // Get or create conversation
    $conversation = nidfil_get_or_create_conversation($customer_id, $specialist_id);
    
    if (!$conversation) {
        wp_send_json_error(array('message' => 'Error al crear la conversación.'));
        return;
    }
    
    global $wpdb;
    $messages_table = $wpdb->prefix . 'nidfil_messages';
    
    // Insert message
    $result = $wpdb->insert(
        $messages_table,
        array(
            'conversation_id' => $conversation->id,
            'sender_id' => $current_user_id,
            'receiver_id' => $receiver_id,
            'message_type' => $message_type,
            'message_text' => $message_text,
            'file_url' => $file_url,
            'file_name' => $file_name,
            'file_size' => $file_size,
            'is_read' => 0,
            'created_at' => current_time('mysql')
        ),
        array('%d', '%d', '%d', '%s', '%s', '%s', '%s', '%d', '%d', '%s')
    );
    
    if ($result === false) {
        wp_send_json_error(array('message' => 'Error al enviar el mensaje.'));
        return;
    }
    
    $message_id = $wpdb->insert_id;
    
    // Update conversation
    $conversations_table = $wpdb->prefix . 'nidfil_conversations';
    $unread_field = ($user_type === 'specialist') ? 'customer_unread_count' : 'specialist_unread_count';
    
    $wpdb->update(
        $conversations_table,
        array(
            'last_message_id' => $message_id,
            'last_message_time' => current_time('mysql'),
            $unread_field => $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM $messages_table WHERE conversation_id = %d AND receiver_id = %d AND is_read = 0",
                $conversation->id,
                $receiver_id
            ))
        ),
        array('id' => $conversation->id),
        array('%d', '%s', '%d'),
        array('%d')
    );
    
    // Get the full message data
    $message = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $messages_table WHERE id = %d",
        $message_id
    ));
    
    wp_send_json_success(array(
        'message' => 'Mensaje enviado correctamente.',
        'message_data' => $message
    ));
}
add_action('wp_ajax_nidfil_send_message', 'nidfil_send_message');
add_action('wp_ajax_nopriv_nidfil_send_message', 'nidfil_send_message');

/**
 * Get conversations list AJAX handler
 */
function nidfil_get_conversations() {
    check_ajax_referer('nidfil_nonce', 'nonce');
    
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'Debes iniciar sesión.'));
        return;
    }
    
    $current_user_id = get_current_user_id();
    $user_type = get_user_meta($current_user_id, 'user_type', true);
    
    global $wpdb;
    $conversations_table = $wpdb->prefix . 'nidfil_conversations';
    $messages_table = $wpdb->prefix . 'nidfil_messages';
    
    // Get conversations
    if ($user_type === 'specialist') {
        $conversations = $wpdb->get_results($wpdb->prepare(
            "SELECT c.*, 
                    u.display_name as customer_name, 
                    u.user_email as customer_email,
                    m.message_text as last_message,
                    m.message_type as last_message_type,
                    m.created_at as last_message_time
             FROM $conversations_table c
             LEFT JOIN {$wpdb->users} u ON c.customer_id = u.ID
             LEFT JOIN $messages_table m ON c.last_message_id = m.id
             WHERE c.specialist_id = %d
             ORDER BY c.last_message_time DESC",
            $current_user_id
        ));
    } else {
        $conversations = $wpdb->get_results($wpdb->prepare(
            "SELECT c.*, 
                    u.display_name as specialist_name, 
                    u.user_email as specialist_email,
                    m.message_text as last_message,
                    m.message_type as last_message_type,
                    m.created_at as last_message_time
             FROM $conversations_table c
             LEFT JOIN {$wpdb->users} u ON c.specialist_id = u.ID
             LEFT JOIN $messages_table m ON c.last_message_id = m.id
             WHERE c.customer_id = %d
             ORDER BY c.last_message_time DESC",
            $current_user_id
        ));
    }
    
    // Format conversations
    $formatted_conversations = array();
    foreach ($conversations as $conv) {
        $other_user_id = ($user_type === 'specialist') ? $conv->customer_id : $conv->specialist_id;
        $other_user_name = ($user_type === 'specialist') ? $conv->customer_name : $conv->specialist_name;
        $unread_count = ($user_type === 'specialist') ? $conv->specialist_unread_count : $conv->customer_unread_count;
        
        $formatted_conversations[] = array(
            'conversation_id' => $conv->id,
            'other_user_id' => $other_user_id,
            'other_user_name' => $other_user_name,
            'last_message' => $conv->last_message,
            'last_message_type' => $conv->last_message_type,
            'last_message_time' => $conv->last_message_time,
            'unread_count' => $unread_count
        );
    }
    
    wp_send_json_success(array('conversations' => $formatted_conversations));
}
add_action('wp_ajax_nidfil_get_conversations', 'nidfil_get_conversations');
add_action('wp_ajax_nopriv_nidfil_get_conversations', 'nidfil_get_conversations');

/**
 * Get messages for a conversation AJAX handler
 */
function nidfil_get_messages() {
    check_ajax_referer('nidfil_nonce', 'nonce');
    
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'Debes iniciar sesión.'));
        return;
    }
    
    $conversation_id = intval($_POST['conversation_id']);
    $current_user_id = get_current_user_id();
    
    if (empty($conversation_id)) {
        wp_send_json_error(array('message' => 'ID de conversación inválido.'));
        return;
    }
    
    // Verify user has access to this conversation
    global $wpdb;
    $conversations_table = $wpdb->prefix . 'nidfil_conversations';
    $conversation = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $conversations_table WHERE id = %d AND (customer_id = %d OR specialist_id = %d)",
        $conversation_id,
        $current_user_id,
        $current_user_id
    ));
    
    if (!$conversation) {
        wp_send_json_error(array('message' => 'No tienes acceso a esta conversación.'));
        return;
    }
    
    // Get messages
    $messages_table = $wpdb->prefix . 'nidfil_messages';
    $messages = $wpdb->get_results($wpdb->prepare(
        "SELECT m.*, u.display_name as sender_name
         FROM $messages_table m
         LEFT JOIN {$wpdb->users} u ON m.sender_id = u.ID
         WHERE m.conversation_id = %d
         ORDER BY m.created_at ASC",
        $conversation_id
    ));
    
    // Mark messages as read
    $wpdb->update(
        $messages_table,
        array('is_read' => 1),
        array(
            'conversation_id' => $conversation_id,
            'receiver_id' => $current_user_id,
            'is_read' => 0
        ),
        array('%d'),
        array('%d', '%d', '%d')
    );
    
    // Update unread count
    $user_type = get_user_meta($current_user_id, 'user_type', true);
    $unread_field = ($user_type === 'specialist') ? 'specialist_unread_count' : 'customer_unread_count';
    $wpdb->update(
        $conversations_table,
        array($unread_field => 0),
        array('id' => $conversation_id),
        array('%d'),
        array('%d')
    );
    
    wp_send_json_success(array('messages' => $messages));
}
add_action('wp_ajax_nidfil_get_messages', 'nidfil_get_messages');
add_action('wp_ajax_nopriv_nidfil_get_messages', 'nidfil_get_messages');

/**
 * Upload file for message AJAX handler
 */
function nidfil_upload_message_file() {
    check_ajax_referer('nidfil_nonce', 'nonce');
    
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'Debes iniciar sesión.'));
        return;
    }
    
    if (!isset($_FILES['file'])) {
        wp_send_json_error(array('message' => 'No se encontró ningún archivo.'));
        return;
    }
    
    $file = $_FILES['file'];
    $allowed_types = array('image/jpeg', 'image/png', 'image/gif', 'image/webp', 'application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document');
    $max_size = 10 * 1024 * 1024; // 10MB
    
    if (!in_array($file['type'], $allowed_types)) {
        wp_send_json_error(array('message' => 'Tipo de archivo no permitido.'));
        return;
    }
    
    if ($file['size'] > $max_size) {
        wp_send_json_error(array('message' => 'El archivo es demasiado grande. Máximo 10MB.'));
        return;
    }
    
    require_once(ABSPATH . 'wp-admin/includes/file.php');
    require_once(ABSPATH . 'wp-admin/includes/media.php');
    require_once(ABSPATH . 'wp-admin/includes/image.php');
    
    $upload = wp_handle_upload($file, array('test_form' => false));
    
    if (isset($upload['error'])) {
        wp_send_json_error(array('message' => $upload['error']));
        return;
    }
    
    $file_type = strpos($file['type'], 'image/') !== false ? 'image' : 'document';
    
    wp_send_json_success(array(
        'file_url' => $upload['url'],
        'file_name' => $file['name'],
        'file_size' => $file['size'],
        'file_type' => $file_type
    ));
}
add_action('wp_ajax_nidfil_upload_message_file', 'nidfil_upload_message_file');
add_action('wp_ajax_nopriv_nidfil_upload_message_file', 'nidfil_upload_message_file');

/**
 * Start conversation AJAX handler
 */
function nidfil_start_conversation() {
    check_ajax_referer('nidfil_nonce', 'nonce');
    
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'Debes iniciar sesión para enviar mensajes.'));
        return;
    }
    
    $current_user_id = get_current_user_id();
    $user_type = get_user_meta($current_user_id, 'user_type', true);
    
    // Only customers can start conversations with specialists
    if ($user_type === 'specialist') {
        wp_send_json_error(array('message' => 'Los especialistas no pueden iniciar conversaciones desde aquí.'));
        return;
    }
    
    $specialist_id = intval($_POST['specialist_id']);
    
    if (empty($specialist_id)) {
        wp_send_json_error(array('message' => 'ID de especialista inválido.'));
        return;
    }
    
    // Verify specialist exists and is actually a specialist
    $specialist = get_userdata($specialist_id);
    if (!$specialist) {
        wp_send_json_error(array('message' => 'Especialista no encontrado.'));
        return;
    }
    
    $specialist_type = get_user_meta($specialist_id, 'user_type', true);
    if ($specialist_type !== 'specialist') {
        wp_send_json_error(array('message' => 'El usuario seleccionado no es un especialista.'));
        return;
    }
    
    // Get or create conversation
    $conversation = nidfil_get_or_create_conversation($current_user_id, $specialist_id);
    
    if (!$conversation) {
        wp_send_json_error(array('message' => 'Error al crear la conversación.'));
        return;
    }
    
    // Get dashboard URL
    $dashboard_url = nidfil_get_dashboard_url();
    
    wp_send_json_success(array(
        'message' => 'Conversación iniciada correctamente.',
        'conversation_id' => $conversation->id,
        'redirect_url' => $dashboard_url . '#messagesSection?conversation_id=' . $conversation->id
    ));
}
add_action('wp_ajax_nidfil_start_conversation', 'nidfil_start_conversation');
add_action('wp_ajax_nopriv_nidfil_start_conversation', 'nidfil_start_conversation');

/**
 * Calculate specialist profile completion percentage
 */
function nidfil_calculate_profile_completion($user_id) {
    $fields = array(
        'display_name' => 5,           // Name
        'user_email' => 5,             // Email
        'profession' => 10,            // Profession
        'experience_years' => 5,       // Experience
        'user_bio' => 10,              // Bio/Description
        'user_location' => 10,         // Location
        'user_phone' => 5,             // Phone
        'services_offered' => 15,      // Services
        'certifications' => 10,        // Certifications
        'hourly_rate' => 5,            // Pricing
        'profile_image' => 10,         // Profile Image
        'business_video' => 10,        // Business Video
    );
    
    $total_weight = array_sum($fields);
    $completed_weight = 0;
    
    $user = get_userdata($user_id);
    if (!$user) {
        return 0;
    }
    
    // Check each field
    if (!empty($user->display_name)) $completed_weight += $fields['display_name'];
    if (!empty($user->user_email)) $completed_weight += $fields['user_email'];
    if (!empty(get_user_meta($user_id, 'profession', true))) $completed_weight += $fields['profession'];
    if (!empty(get_user_meta($user_id, 'experience_years', true))) $completed_weight += $fields['experience_years'];
    if (!empty(get_user_meta($user_id, 'user_bio', true))) $completed_weight += $fields['user_bio'];
    if (!empty(get_user_meta($user_id, 'user_location', true))) $completed_weight += $fields['user_location'];
    if (!empty(get_user_meta($user_id, 'user_phone', true))) $completed_weight += $fields['user_phone'];
    
    $services = get_user_meta($user_id, 'services_offered', true);
    if (!empty($services) && (is_array($services) ? count($services) > 0 : strlen($services) > 0)) {
        $completed_weight += $fields['services_offered'];
    }
    
    $certifications = get_user_meta($user_id, 'certifications', true);
    if (!empty($certifications) && (is_array($certifications) ? count($certifications) > 0 : strlen($certifications) > 0)) {
        $completed_weight += $fields['certifications'];
    }
    
    if (!empty(get_user_meta($user_id, 'hourly_rate', true)) || !empty(get_user_meta($user_id, 'project_rate', true))) {
        $completed_weight += $fields['hourly_rate'];
    }
    
    // Check profile image
    $profile_image = get_user_meta($user_id, 'profile_image', true);
    if (!empty($profile_image)) {
        $completed_weight += $fields['profile_image'];
    } else {
        // Check if user has gravatar
        $avatar_url = get_avatar_url($user_id);
        if ($avatar_url && strpos($avatar_url, 'gravatar.com') !== false && strpos($avatar_url, 'd=') === false) {
            $completed_weight += $fields['profile_image'];
        }
    }
    
    // Check business video
    if (!empty(get_user_meta($user_id, 'business_video_url', true))) {
        $completed_weight += $fields['business_video'];
    }
    
    $percentage = ($completed_weight / $total_weight) * 100;
    return round($percentage);
}

/**
 * Get specialists with minimum profile completion
 */
function nidfil_get_specialists($min_completion = 20, $limit = 20) {
    $args = array(
        'role' => '',
        'meta_key' => 'user_type',
        'meta_value' => 'specialist',
        'number' => $limit,
        'orderby' => 'registered',
        'order' => 'DESC'
    );
    
    $users = get_users($args);
    $specialists = array();
    
    foreach ($users as $user) {
        $completion = nidfil_calculate_profile_completion($user->ID);
        
        if ($completion >= $min_completion) {
            $profession = get_user_meta($user->ID, 'profession', true);
            $location = get_user_meta($user->ID, 'user_location', true);
            $office_address = get_user_meta($user->ID, 'office_address', true);
            $phone = get_user_meta($user->ID, 'user_phone', true);
            $whatsapp = get_user_meta($user->ID, 'user_whatsapp', true) ?: $phone;
            $bio = get_user_meta($user->ID, 'user_bio', true);
            $services = get_user_meta($user->ID, 'services_offered', true);
            $verified = get_user_meta($user->ID, 'verified', true) === '1';
            $profile_image = get_user_meta($user->ID, 'profile_image', true);
            
            // Get avatar
            $avatar_url = '';
            if (!empty($profile_image)) {
                // Check if profile_image is an attachment ID (numeric) or a URL
                if (is_numeric($profile_image)) {
                    // It's an attachment ID, get the image URL
                    $avatar_url = wp_get_attachment_image_url($profile_image, 'thumbnail');
                    if (empty($avatar_url)) {
                        // Fallback to medium size if thumbnail doesn't exist
                        $avatar_url = wp_get_attachment_image_url($profile_image, 'medium');
                    }
                    if (empty($avatar_url)) {
                        // Fallback to full size if medium doesn't exist
                        $avatar_url = wp_get_attachment_url($profile_image);
                    }
                } else {
                    // It's already a URL
                    $avatar_url = esc_url($profile_image);
                }
            }
            
            // If still no avatar URL, use default gravatar
            if (empty($avatar_url)) {
                $avatar_url = get_avatar_url($user->ID, array('size' => 56));
            }
            
            // Get initials for avatar placeholder
            $name_parts = explode(' ', $user->display_name);
            $initials = '';
            if (count($name_parts) >= 2) {
                $initials = strtoupper(substr($name_parts[0], 0, 1) . substr($name_parts[1], 0, 1));
            } else {
                $initials = strtoupper(substr($user->display_name, 0, 2));
            }
            
            // Calculate average rating (placeholder - you can implement reviews system)
            $rating = get_user_meta($user->ID, 'average_rating', true);
            if (empty($rating)) {
                $rating = '4.5'; // Default rating
            }
            
            // Get review count (placeholder)
            $reviews_count = get_user_meta($user->ID, 'reviews_count', true);
            if (empty($reviews_count)) {
                $reviews_count = 0;
            }
            
            // Format services
            $services_list = array();
            if (is_array($services)) {
                $services_list = array_slice($services, 0, 3); // Get first 3 services
            } elseif (!empty($services)) {
                $services_array = explode("\n", $services);
                $services_list = array_slice(array_filter($services_array), 0, 3);
            }
            
            $specialists[] = array(
                'id' => $user->ID,
                'name' => $user->display_name,
                'profession' => $profession ?: 'Especialista',
                'location' => $location ?: 'Ubicación no especificada',
                'office_address' => $office_address ?: '',
                'distance' => '0', // Can be calculated based on user location
                'rating' => $rating,
                'reviews' => $reviews_count,
                'verified' => $verified,
                'avatar' => $initials,
                'avatar_url' => $avatar_url,
                'phone' => $phone ?: '',
                'whatsapp' => $whatsapp ?: '',
                'description' => $bio ?: 'Profesional especializado en ' . ($profession ?: 'servicios'),
                'services' => $services_list,
                'completion' => $completion
            );
        }
    }
    
    return $specialists;
}

/**
 * ============================================
 * ADMIN DASHBOARD SYSTEM
 * ============================================
 */

/**
 * Create admin dashboard database tables
 */
function nidfil_create_admin_tables() {
    global $wpdb;
    
    $charset_collate = $wpdb->get_charset_collate();
    
    // Subscriptions table
    $table_subscriptions = $wpdb->prefix . 'nidfil_subscriptions';
    $sql_subscriptions = "CREATE TABLE IF NOT EXISTS $table_subscriptions (
        id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id bigint(20) UNSIGNED NOT NULL,
        plan_type enum('free', 'basic', 'pro') DEFAULT 'free',
        status enum('active', 'expired', 'cancelled', 'pending') DEFAULT 'pending',
        start_date datetime DEFAULT NULL,
        end_date datetime DEFAULT NULL,
        payment_amount decimal(10,2) DEFAULT 0.00,
        payment_status enum('pending', 'completed', 'failed', 'refunded') DEFAULT 'pending',
        payment_date datetime DEFAULT NULL,
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY user_id (user_id),
        KEY status (status),
        KEY plan_type (plan_type)
    ) $charset_collate;";
    
    // Leads table
    $table_leads = $wpdb->prefix . 'nidfil_leads';
    $sql_leads = "CREATE TABLE IF NOT EXISTS $table_leads (
        id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        customer_id bigint(20) UNSIGNED NOT NULL,
        service_type varchar(100) DEFAULT NULL,
        project_type varchar(100) DEFAULT NULL,
        location varchar(255) DEFAULT NULL,
        description text,
        budget decimal(10,2) DEFAULT NULL,
        status enum('open', 'offered', 'accepted', 'closed') DEFAULT 'open',
        accepted_offer_id bigint(20) UNSIGNED DEFAULT NULL,
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY customer_id (customer_id),
        KEY status (status),
        KEY service_type (service_type)
    ) $charset_collate;";
    
    // Offers table
    $table_offers = $wpdb->prefix . 'nidfil_offers';
    $sql_offers = "CREATE TABLE IF NOT EXISTS $table_offers (
        id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        lead_id bigint(20) UNSIGNED NOT NULL,
        specialist_id bigint(20) UNSIGNED NOT NULL,
        offer_amount decimal(10,2) DEFAULT NULL,
        message text,
        status enum('pending', 'accepted', 'rejected', 'withdrawn') DEFAULT 'pending',
        distance decimal(8,2) DEFAULT NULL,
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY lead_id (lead_id),
        KEY specialist_id (specialist_id),
        KEY status (status)
    ) $charset_collate;";
    
    // Reviews table
    $table_reviews = $wpdb->prefix . 'nidfil_reviews';
    $sql_reviews = "CREATE TABLE IF NOT EXISTS $table_reviews (
        id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        customer_id bigint(20) UNSIGNED NOT NULL,
        specialist_id bigint(20) UNSIGNED NOT NULL,
        rating tinyint(1) UNSIGNED NOT NULL DEFAULT 5,
        review_text text,
        status enum('pending', 'approved', 'rejected', 'flagged') DEFAULT 'pending',
        is_verified tinyint(1) DEFAULT 0,
        reported_count int(11) DEFAULT 0,
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY customer_id (customer_id),
        KEY specialist_id (specialist_id),
        KEY status (status),
        KEY rating (rating)
    ) $charset_collate;";
    
    // Platform activities table
    $table_activities = $wpdb->prefix . 'nidfil_activities';
    $sql_activities = "CREATE TABLE IF NOT EXISTS $table_activities (
        id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        activity_type enum('registration', 'lead', 'offer', 'subscription', 'review', 'payment') NOT NULL,
        user_id bigint(20) UNSIGNED DEFAULT NULL,
        related_id bigint(20) UNSIGNED DEFAULT NULL,
        description text,
        metadata text,
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY activity_type (activity_type),
        KEY user_id (user_id),
        KEY created_at (created_at)
    ) $charset_collate;";
    
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql_subscriptions);
    dbDelta($sql_leads);
    dbDelta($sql_offers);
    dbDelta($sql_reviews);
    dbDelta($sql_activities);
}
add_action('after_setup_theme', 'nidfil_create_admin_tables');

/**
 * Register admin menu
 */
function nidfil_admin_menu() {
    // Main dashboard menu
    add_menu_page(
        __('NIDFIL Dashboard', 'nidfil-connect'),
        __('NIDFIL Dashboard', 'nidfil-connect'),
        'manage_options',
        'nidfil-dashboard',
        'nidfil_admin_dashboard_page',
        'dashicons-chart-line',
        3
    );
    
    // Overview Dashboard (submenu of main)
    add_submenu_page(
        'nidfil-dashboard',
        __('Overview Dashboard', 'nidfil-connect'),
        __('Overview', 'nidfil-connect'),
        'manage_options',
        'nidfil-dashboard',
        'nidfil_admin_dashboard_page'
    );
    
    // User Management
    add_submenu_page(
        'nidfil-dashboard',
        __('User Management', 'nidfil-connect'),
        __('Users', 'nidfil-connect'),
        'manage_options',
        'nidfil-users',
        'nidfil_admin_users_page'
    );
    
    // Subscription Management
    add_submenu_page(
        'nidfil-dashboard',
        __('Subscription Management', 'nidfil-connect'),
        __('Subscriptions', 'nidfil-connect'),
        'manage_options',
        'nidfil-subscriptions',
        'nidfil_admin_subscriptions_page'
    );
    
    // Lead & Offer Management
    add_submenu_page(
        'nidfil-dashboard',
        __('Lead & Offer Management', 'nidfil-connect'),
        __('Leads & Offers', 'nidfil-connect'),
        'manage_options',
        'nidfil-leads',
        'nidfil_admin_leads_page'
    );
    
    // Review & Rating Control
    add_submenu_page(
        'nidfil-dashboard',
        __('Review & Rating Control', 'nidfil-connect'),
        __('Reviews', 'nidfil-connect'),
        'manage_options',
        'nidfil-reviews',
        'nidfil_admin_reviews_page'
    );
    
    // Chat Moderation
    add_submenu_page(
        'nidfil-dashboard',
        __('Chat Moderation', 'nidfil-connect'),
        __('Chat Moderation', 'nidfil-connect'),
        'manage_options',
        'nidfil-chat',
        'nidfil_admin_chat_page'
    );
    
    // Reports
    add_submenu_page(
        'nidfil-dashboard',
        __('Reports', 'nidfil-connect'),
        __('Reports', 'nidfil-connect'),
        'manage_options',
        'nidfil-reports',
        'nidfil_admin_reports_page'
    );
    
    // Google Maps Integration
    add_submenu_page(
        'nidfil-dashboard',
        __('Google Maps Integration', 'nidfil-connect'),
        __('Google Maps', 'nidfil-connect'),
        'manage_options',
        'nidfil-google-maps',
        'nidfil_admin_google_maps_page'
    );
    
    // Payment Setup
    add_submenu_page(
        'nidfil-dashboard',
        __('Payment Setup', 'nidfil-connect'),
        __('Payment Setup', 'nidfil-connect'),
        'manage_options',
        'nidfil-payment-setup',
        'nidfil_admin_payment_setup_page'
    );
}
add_action('admin_menu', 'nidfil_admin_menu');

/**
 * Enqueue admin styles and scripts
 */
function nidfil_admin_enqueue_scripts($hook) {
    // Only load on our admin pages
    if (strpos($hook, 'nidfil') === false) {
        return;
    }
    
    // Enqueue Font Awesome for icons
    wp_enqueue_style(
        'font-awesome-admin',
        'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css',
        array(),
        '6.5.2',
        'all'
    );
    
    // Enqueue Chart.js for analytics
    wp_enqueue_script(
        'chart-js',
        'https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js',
        array(),
        '4.4.0',
        true
    );
    
    wp_enqueue_style(
        'nidfil-admin-style',
        get_template_directory_uri() . '/admin/css/admin.css',
        array('font-awesome-admin'),
        '1.0.0'
    );
    
    wp_enqueue_script(
        'nidfil-admin-script',
        get_template_directory_uri() . '/admin/js/admin.js',
        array('jquery', 'chart-js'),
        '1.0.0',
        true
    );
    
    wp_localize_script('nidfil-admin-script', 'nidfilAdmin', array(
        'ajaxurl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('nidfil_admin_nonce'),
        'current_user_id' => get_current_user_id(),
    ));
}
add_action('admin_enqueue_scripts', 'nidfil_admin_enqueue_scripts');

/**
 * Admin page callback functions
 */
function nidfil_admin_dashboard_page() {
    require_once get_template_directory() . '/admin/pages/dashboard.php';
}

function nidfil_admin_users_page() {
    require_once get_template_directory() . '/admin/pages/users.php';
}

function nidfil_admin_subscriptions_page() {
    require_once get_template_directory() . '/admin/pages/subscriptions.php';
}

function nidfil_admin_leads_page() {
    require_once get_template_directory() . '/admin/pages/leads.php';
}

function nidfil_admin_reviews_page() {
    require_once get_template_directory() . '/admin/pages/reviews.php';
}

function nidfil_admin_chat_page() {
    require_once get_template_directory() . '/admin/pages/chat.php';
}

function nidfil_admin_reports_page() {
    require_once get_template_directory() . '/admin/pages/reports.php';
}

function nidfil_admin_google_maps_page() {
    require_once get_template_directory() . '/admin/pages/google-maps.php';
}

function nidfil_admin_payment_setup_page() {
    require_once get_template_directory() . '/admin/pages/payment-setup.php';
}

/**
 * Helper functions for admin dashboard
 */

/**
 * Get dashboard statistics
 */
function nidfil_get_dashboard_stats() {
    global $wpdb;
    
    // Get user counts
    $total_users = count_users();
    $customers_count = 0;
    $specialists_count = 0;
    
    $users = get_users(array('number' => -1));
    foreach ($users as $user) {
        $user_type = get_user_meta($user->ID, 'user_type', true);
        if ($user_type === 'specialist') {
            $specialists_count++;
        } else {
            $customers_count++;
        }
    }
    
    // Get subscription counts
    $subscriptions_table = $wpdb->prefix . 'nidfil_subscriptions';
    $free_count = $wpdb->get_var("SELECT COUNT(*) FROM $subscriptions_table WHERE plan_type = 'free' AND status = 'active'");
    $basic_count = $wpdb->get_var("SELECT COUNT(*) FROM $subscriptions_table WHERE plan_type = 'basic' AND status = 'active'");
    $pro_count = $wpdb->get_var("SELECT COUNT(*) FROM $subscriptions_table WHERE plan_type = 'pro' AND status = 'active'");
    
    // Get leads count
    $leads_table = $wpdb->prefix . 'nidfil_leads';
    $leads_count = $wpdb->get_var("SELECT COUNT(*) FROM $leads_table");
    
    // Get offers count
    $offers_table = $wpdb->prefix . 'nidfil_offers';
    $offers_count = $wpdb->get_var("SELECT COUNT(*) FROM $offers_table WHERE status = 'accepted'");
    
    // Get revenue
    $revenue = $wpdb->get_var("SELECT SUM(payment_amount) FROM $subscriptions_table WHERE payment_status = 'completed'");
    $revenue = $revenue ? floatval($revenue) : 0;
    
    // Get recent activities
    $activities_table = $wpdb->prefix . 'nidfil_activities';
    $recent_activities = $wpdb->get_results(
        "SELECT * FROM $activities_table ORDER BY created_at DESC LIMIT 10"
    );
    
    return array(
        'total_users' => $total_users['total_users'],
        'customers_count' => $customers_count,
        'specialists_count' => $specialists_count,
        'subscriptions' => array(
            'free' => $free_count ? intval($free_count) : 0,
            'basic' => $basic_count ? intval($basic_count) : 0,
            'pro' => $pro_count ? intval($pro_count) : 0,
        ),
        'leads_count' => $leads_count ? intval($leads_count) : 0,
        'offers_count' => $offers_count ? intval($offers_count) : 0,
        'revenue' => $revenue,
        'recent_activities' => $recent_activities
    );
}

/**
 * Log platform activity
 */
function nidfil_log_activity($type, $user_id = null, $related_id = null, $description = '', $metadata = array()) {
    global $wpdb;
    $activities_table = $wpdb->prefix . 'nidfil_activities';
    
    $wpdb->insert(
        $activities_table,
        array(
            'activity_type' => $type,
            'user_id' => $user_id,
            'related_id' => $related_id,
            'description' => $description,
            'metadata' => json_encode($metadata),
            'created_at' => current_time('mysql')
        ),
        array('%s', '%d', '%d', '%s', '%s', '%s')
    );
}

/**
 * ============================================
 * ADMIN AJAX HANDLERS
 * ============================================
 */

/**
 * Verify/Unverify Specialist
 */
function nidfil_admin_verify_user() {
    check_ajax_referer('nidfil_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'Insufficient permissions'));
        return;
    }
    
    $user_id = intval($_POST['user_id']);
    $verified = intval($_POST['verified']);
    
    update_user_meta($user_id, 'verified', $verified);
    
    nidfil_log_activity('registration', $user_id, null, $verified ? 'Specialist verified' : 'Specialist unverified');
    
    wp_send_json_success(array('message' => 'User verification status updated'));
}
add_action('wp_ajax_nidfil_admin_verify_user', 'nidfil_admin_verify_user');

/**
 * Suspend/Activate User
 */
function nidfil_admin_suspend_user() {
    check_ajax_referer('nidfil_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'Insufficient permissions'));
        return;
    }
    
    $user_id = intval($_POST['user_id']);
    $status = sanitize_text_field($_POST['status']);
    
    update_user_meta($user_id, 'account_status', $status);
    
    nidfil_log_activity('registration', $user_id, null, 'User account ' . $status);
    
    wp_send_json_success(array('message' => 'User status updated'));
}
add_action('wp_ajax_nidfil_admin_suspend_user', 'nidfil_admin_suspend_user');

/**
 * Delete User
 */
function nidfil_admin_delete_user() {
    check_ajax_referer('nidfil_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'Insufficient permissions'));
        return;
    }
    
    $user_id = intval($_POST['user_id']);
    
    if ($user_id == get_current_user_id()) {
        wp_send_json_error(array('message' => 'You cannot delete your own account'));
        return;
    }
    
    require_once(ABSPATH . 'wp-admin/includes/user.php');
    wp_delete_user($user_id);
    
    nidfil_log_activity('registration', $user_id, null, 'User account deleted');
    
    wp_send_json_success(array('message' => 'User deleted successfully'));
}
add_action('wp_ajax_nidfil_admin_delete_user', 'nidfil_admin_delete_user');

/**
 * Change Subscription Plan
 */
function nidfil_admin_change_plan() {
    check_ajax_referer('nidfil_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'Insufficient permissions'));
        return;
    }
    
    global $wpdb;
    $subscriptions_table = $wpdb->prefix . 'nidfil_subscriptions';
    
    $subscription_id = intval($_POST['subscription_id']);
    $user_id = intval($_POST['user_id']);
    $plan_type = sanitize_text_field($_POST['plan_type']);
    
    // Update or create subscription
    $existing = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $subscriptions_table WHERE id = %d",
        $subscription_id
    ));
    
    if ($existing) {
        $wpdb->update(
            $subscriptions_table,
            array('plan_type' => $plan_type),
            array('id' => $subscription_id),
            array('%s'),
            array('%d')
        );
    } else {
        $wpdb->insert(
            $subscriptions_table,
            array(
                'user_id' => $user_id,
                'plan_type' => $plan_type,
                'status' => 'active',
                'start_date' => current_time('mysql')
            ),
            array('%d', '%s', '%s', '%s')
        );
    }
    
    nidfil_log_activity('subscription', $user_id, null, 'Subscription plan changed to ' . $plan_type);
    
    wp_send_json_success(array('message' => 'Subscription plan updated'));
}
add_action('wp_ajax_nidfil_admin_change_plan', 'nidfil_admin_change_plan');

/**
 * Toggle Premium Badge
 */
function nidfil_admin_toggle_premium() {
    check_ajax_referer('nidfil_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'Insufficient permissions'));
        return;
    }
    
    global $wpdb;
    $subscriptions_table = $wpdb->prefix . 'nidfil_subscriptions';
    
    $user_id = intval($_POST['user_id']);
    $premium = intval($_POST['premium']);
    
    // Update subscription to pro if premium, or basic if not
    $wpdb->update(
        $subscriptions_table,
        array('plan_type' => $premium ? 'pro' : 'basic'),
        array('user_id' => $user_id),
        array('%s'),
        array('%d')
    );
    
    nidfil_log_activity('subscription', $user_id, null, $premium ? 'Premium badge added' : 'Premium badge removed');
    
    wp_send_json_success(array('message' => 'Premium status updated'));
}
add_action('wp_ajax_nidfil_admin_toggle_premium', 'nidfil_admin_toggle_premium');

/**
 * Save Subscription Plan (Add or Edit)
 */
function nidfil_admin_save_plan() {
    check_ajax_referer('nidfil_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'Insufficient permissions'));
        return;
    }
    
    $plan_id = isset($_POST['plan_id']) ? intval($_POST['plan_id']) : 0;
    $plan_name = sanitize_text_field($_POST['plan_name'] ?? '');
    $plan_price = floatval($_POST['plan_price'] ?? 0);
    $plan_period = sanitize_text_field($_POST['plan_period'] ?? 'month');
    $plan_type = sanitize_text_field($_POST['plan_type'] ?? 'free');
    $plan_status = isset($_POST['plan_status']) && $_POST['plan_status'] == '1' ? 'active' : 'inactive';
    $plan_default = isset($_POST['plan_default']) && $_POST['plan_default'] == '1' ? true : false;
    $plan_items = sanitize_textarea_field($_POST['plan_items'] ?? '');
    
    // Backward compatibility: if plan_type not set, use pro checkbox
    if ($plan_type === 'free' && isset($_POST['plan_pro']) && $_POST['plan_pro'] == '1') {
        $plan_type = 'pro';
    }
    
    // If plan type is FREE, automatically set price to 0
    if ($plan_type === 'free') {
        $plan_price = 0;
    }
    
    // If setting as default, unset other default FREE plans
    if ($plan_default && $plan_type === 'free') {
        $plans = get_option('nidfil_subscription_plans', array());
        if (is_string($plans)) {
            $plans = json_decode($plans, true);
        }
        foreach ($plans as &$p) {
            if (isset($p['id']) && $p['id'] != $plan_id) {
                $p_type = isset($p['plan_type']) ? $p['plan_type'] : (isset($p['pro']) && $p['pro'] ? 'pro' : 'free');
                if ($p_type === 'free') {
                    $p['is_default'] = false;
                }
            }
        }
        update_option('nidfil_subscription_plans', $plans);
    }
    
    if (empty($plan_name)) {
        wp_send_json_error(array('message' => 'Plan name is required.'));
        return;
    }
    
    // Get existing plans
    $plans = get_option('nidfil_subscription_plans', array());
    if (is_string($plans)) {
        $plans = json_decode($plans, true);
    }
    if (!is_array($plans)) {
        $plans = array();
    }
    
    // Convert items string to array
    $items_array = array();
    if (!empty($plan_items)) {
        $items_lines = explode("\n", $plan_items);
        foreach ($items_lines as $line) {
            $line = trim($line);
            if (!empty($line)) {
                $items_array[] = $line;
            }
        }
    }
    
    if ($plan_id > 0) {
        // Edit existing plan
        $found = false;
        foreach ($plans as &$plan) {
            if ($plan['id'] == $plan_id) {
                $plan['name'] = $plan_name;
                $plan['price'] = $plan_price;
                $plan['period'] = $plan_period;
                $plan['plan_type'] = $plan_type;
                $plan['status'] = $plan_status;
                if ($plan_type === 'free') {
                    $plan['is_default'] = $plan_default;
                } else {
                    unset($plan['is_default']);
                }
                // Backward compatibility
                $plan['pro'] = ($plan_type === 'pro');
                $plan['items'] = $items_array;
                $found = true;
                break;
            }
        }
        if (!$found) {
            wp_send_json_error(array('message' => 'Plan not found.'));
            return;
        }
    } else {
        // Add new plan
        $max_id = 0;
        foreach ($plans as $plan) {
            if (isset($plan['id']) && $plan['id'] > $max_id) {
                $max_id = $plan['id'];
            }
        }
        $new_id = $max_id + 1;
        
        $new_plan = array(
            'id' => $new_id,
            'name' => $plan_name,
            'price' => $plan_price,
            'period' => $plan_period,
            'plan_type' => $plan_type,
            'status' => $plan_status,
            'items' => $items_array
        );
        // Backward compatibility
        $new_plan['pro'] = ($plan_type === 'pro');
        if ($plan_type === 'free' && $plan_default) {
            $new_plan['is_default'] = true;
            // Unset other default plans
            foreach ($plans as &$p) {
                $p_type = isset($p['plan_type']) ? $p['plan_type'] : (isset($p['pro']) && $p['pro'] ? 'pro' : 'free');
                if ($p_type === 'free') {
                    $p['is_default'] = false;
                }
            }
        }
        $plans[] = $new_plan;
    }
    
    // Save plans
    update_option('nidfil_subscription_plans', $plans);
    
    wp_send_json_success(array(
        'message' => $plan_id > 0 ? 'Plan updated successfully!' : 'Plan added successfully!',
        'plan_id' => $plan_id > 0 ? $plan_id : $new_id
    ));
}
add_action('wp_ajax_nidfil_admin_save_plan', 'nidfil_admin_save_plan');

/**
 * Get Subscription Plan
 */
function nidfil_admin_get_plan() {
    check_ajax_referer('nidfil_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'Insufficient permissions'));
        return;
    }
    
    $plan_id = intval($_POST['plan_id'] ?? 0);
    
    if ($plan_id <= 0) {
        wp_send_json_error(array('message' => 'Invalid plan ID.'));
        return;
    }
    
    $plans = get_option('nidfil_subscription_plans', array());
    if (is_string($plans)) {
        $plans = json_decode($plans, true);
    }
    
    $plan = null;
    foreach ($plans as $p) {
        if (isset($p['id']) && $p['id'] == $plan_id) {
            $plan = $p;
            // Ensure backward compatibility
            if (!isset($plan['plan_type'])) {
                $plan['plan_type'] = (isset($plan['pro']) && $plan['pro']) ? 'pro' : 'free';
            }
            if (!isset($plan['status'])) {
                $plan['status'] = 'active';
            }
            break;
        }
    }
    
    if (!$plan) {
        wp_send_json_error(array('message' => 'Plan not found.'));
        return;
    }
    
    // Convert items array to string for textarea
    $plan['items_text'] = is_array($plan['items']) ? implode("\n", $plan['items']) : '';
    
    wp_send_json_success(array('plan' => $plan));
}
add_action('wp_ajax_nidfil_admin_get_plan', 'nidfil_admin_get_plan');

/**
 * Get Plan Features (for edit modal)
 */
function nidfil_admin_get_plan_features() {
    check_ajax_referer('nidfil_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'Insufficient permissions'));
        return;
    }
    
    $plan_id = intval($_POST['plan_id'] ?? 0);
    
    if ($plan_id <= 0) {
        wp_send_json_error(array('message' => 'Invalid plan ID.'));
        return;
    }
    
    // Get stored feature states for this plan
    $plan_features = get_option('nidfil_plan_features_' . $plan_id, array());
    
    // Get stored icon types for this plan
    $plan_icon_types = get_option('nidfil_plan_feature_icons_' . $plan_id, array());
    
    // Also get the plan items to generate feature keys and return text-to-key mapping
    $plans = get_option('nidfil_subscription_plans', array());
    if (is_string($plans)) {
        $plans = json_decode($plans, true);
    }
    
    $feature_keys_map = array();
    $feature_text_map = array(); // Map feature text to key for frontend
    $feature_icon_map = array(); // Map feature key to icon type
    
    foreach ($plans as $plan) {
        if ($plan['id'] == $plan_id && isset($plan['items'])) {
            $plan_items = is_array($plan['items']) ? $plan['items'] : (is_string($plan['items']) ? explode("\n", $plan['items']) : array());
            foreach ($plan_items as $item) {
                $item = trim($item);
                if (!empty($item)) {
                    $item_key = md5($item);
                    $feature_keys_map[$item_key] = isset($plan_features[$item_key]) ? $plan_features[$item_key] : true;
                    $feature_text_map[$item] = $item_key; // Map text to key
                    $feature_icon_map[$item_key] = isset($plan_icon_types[$item_key]) ? $plan_icon_types[$item_key] : 'check';
                }
            }
            break;
        }
    }
    
    wp_send_json_success(array(
        'features' => $feature_keys_map,
        'text_to_key' => $feature_text_map, // Send mapping so frontend can match
        'icon_types' => $feature_icon_map // Send icon types
    ));
}
add_action('wp_ajax_nidfil_admin_get_plan_features', 'nidfil_admin_get_plan_features');

/**
 * Delete Subscription Plan
 */
function nidfil_admin_delete_plan() {
    check_ajax_referer('nidfil_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'Insufficient permissions'));
        return;
    }
    
    $plan_id = intval($_POST['plan_id'] ?? 0);
    
    if ($plan_id <= 0) {
        wp_send_json_error(array('message' => 'Invalid plan ID.'));
        return;
    }
    
    $plans = get_option('nidfil_subscription_plans', array());
    if (is_string($plans)) {
        $plans = json_decode($plans, true);
    }
    
    $new_plans = array();
    $found = false;
    foreach ($plans as $plan) {
        if ($plan['id'] != $plan_id) {
            $new_plans[] = $plan;
        } else {
            $found = true;
        }
    }
    
    if (!$found) {
        wp_send_json_error(array('message' => 'Plan not found.'));
        return;
    }
    
    update_option('nidfil_subscription_plans', $new_plans);
    
    wp_send_json_success(array('message' => 'Plan deleted successfully!'));
}
add_action('wp_ajax_nidfil_admin_delete_plan', 'nidfil_admin_delete_plan');

/**
 * Update Plan Payment Status
 */
function nidfil_admin_update_plan_payment() {
    check_ajax_referer('nidfil_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'Insufficient permissions'));
        return;
    }
    
    $plan_id = intval($_POST['plan_id'] ?? 0);
    $payment_enabled = isset($_POST['payment_enabled']) && $_POST['payment_enabled'] == '1' ? true : false;
    
    if ($plan_id <= 0) {
        wp_send_json_error(array('message' => 'Invalid plan ID.'));
        return;
    }
    
    $plans = get_option('nidfil_subscription_plans', array());
    if (is_string($plans)) {
        $plans = json_decode($plans, true);
    }
    
    $found = false;
    foreach ($plans as &$plan) {
        if (isset($plan['id']) && $plan['id'] == $plan_id) {
            $plan['payment_enabled'] = $payment_enabled;
            $found = true;
            break;
        }
    }
    
    if (!$found) {
        wp_send_json_error(array('message' => 'Plan not found.'));
        return;
    }
    
    update_option('nidfil_subscription_plans', $plans);
    
    wp_send_json_success(array(
        'message' => 'Payment status updated successfully!',
        'payment_enabled' => $payment_enabled
    ));
}
add_action('wp_ajax_nidfil_admin_update_plan_payment', 'nidfil_admin_update_plan_payment');

/**
 * Process Checkout - Create Subscription
 */
function nidfil_process_checkout() {
    check_ajax_referer('nidfil_nonce', 'nonce');
    
    global $wpdb;
    $subscriptions_table = $wpdb->prefix . 'nidfil_subscriptions';
    
    // Get form data
    $plan_id = intval($_POST['plan_id'] ?? 0);
    $plan_name = sanitize_text_field($_POST['plan_name'] ?? '');
    $plan_price = floatval($_POST['plan_price'] ?? 0);
    $plan_period = sanitize_text_field($_POST['plan_period'] ?? 'month');
    $payment_enabled = isset($_POST['payment_enabled']) && $_POST['payment_enabled'] == '1';
    
    $first_name = sanitize_text_field($_POST['first_name'] ?? '');
    $last_name = sanitize_text_field($_POST['last_name'] ?? '');
    $email = sanitize_email($_POST['email'] ?? '');
    $phone = sanitize_text_field($_POST['phone'] ?? '');
    
    // Payment fields (only for paid plans)
    $payment_method = sanitize_text_field($_POST['payment_method'] ?? '');
    $card_number = sanitize_text_field($_POST['card_number'] ?? '');
    $expiry = sanitize_text_field($_POST['expiry'] ?? '');
    $cvc = sanitize_text_field($_POST['cvc'] ?? '');
    $card_name = sanitize_text_field($_POST['card_name'] ?? '');
    
    // Validation
    if (empty($first_name) || empty($last_name) || empty($email) || empty($phone)) {
        wp_send_json_error(array('message' => 'Por favor, completa todos los campos requeridos.'));
        return;
    }
    
    if (!is_email($email)) {
        wp_send_json_error(array('message' => 'Por favor, ingresa un email válido.'));
        return;
    }
    
    // Always find or create user by the email entered in the form
    // This ensures the subscription is linked to the correct email address
    $user_id = 0;
    $current_user = is_user_logged_in() ? wp_get_current_user() : null;
    
    // Check if user exists with the email entered in the form
    $user = get_user_by('email', $email);
    
    if ($user) {
        // User exists with this email - use that user
        $user_id = $user->ID;
        // Update user meta with form data
        update_user_meta($user_id, 'first_name', $first_name);
        update_user_meta($user_id, 'last_name', $last_name);
        update_user_meta($user_id, 'phone', $phone);
        
        // User exists - ensure user_type is set if missing
        $existing_user_type = get_user_meta($user_id, 'user_type', true);
        if (empty($existing_user_type)) {
            // Set default to customer if not set
            update_user_meta($user_id, 'user_type', 'customer');
        }
        
    } else {
        // User doesn't exist - create new user account with the email from form
        $username = sanitize_user($email, true);
        $username = str_replace('@', '_', $username);
        
        // Ensure username is unique
        $original_username = $username;
        $counter = 1;
        while (username_exists($username)) {
            $username = $original_username . '_' . $counter;
            $counter++;
        }
        
        $random_password = wp_generate_password(12, false);
        $user_id = wp_create_user($username, $random_password, $email);
        
        if (is_wp_error($user_id)) {
            wp_send_json_error(array('message' => 'Error al crear la cuenta de usuario.'));
            return;
        }
        
        
        // Update user meta
        // Set user_type to customer for checkout registrations
        update_user_meta($user_id, 'user_type', 'customer');
        update_user_meta($user_id, 'first_name', $first_name);
        update_user_meta($user_id, 'last_name', $last_name);
        update_user_meta($user_id, 'phone', $phone);
        
        // Update display name
        $display_name = trim($first_name . ' ' . $last_name);
        if (!empty($display_name)) {
            wp_update_user(array(
                'ID' => $user_id,
                'display_name' => $display_name
            ));
        }
    }
    
    if ($user_id <= 0) {
        wp_send_json_error(array('message' => 'Error al obtener o crear el usuario.'));
        return;
    }
    
    // Determine plan type from stored plans
    $stored_plans = get_option('nidfil_subscription_plans', array());
    if (is_string($stored_plans)) {
        $stored_plans = json_decode($stored_plans, true);
    }
    
    $plan_type = 'free';
    foreach ($stored_plans as $stored_plan) {
        if (isset($stored_plan['id']) && $stored_plan['id'] == $plan_id) {
            $plan_type = isset($stored_plan['plan_type']) ? $stored_plan['plan_type'] : (isset($stored_plan['pro']) && $stored_plan['pro'] ? 'pro' : 'free');
            break;
        }
    }
    
    // Payment validation for paid plans
    if ($payment_enabled && $plan_price > 0) {
        if (empty($card_number) || empty($expiry) || empty($cvc) || empty($card_name)) {
            wp_send_json_error(array('message' => 'Payment not completed. Por favor, completa todos los campos de pago.'));
            return;
        }
        
        // Here you would integrate with actual payment gateway (Stripe, PayPal, etc.)
        // For now, subscriptions are created as pending until admin confirms
        $payment_status = 'pending';
    } else {
        // Free plan - no payment required, but still pending until admin confirms
        $payment_status = 'pending';
        $plan_price = 0;
    }
    
    // Calculate subscription dates (will be set when admin confirms)
    $start_date = null;
    $end_date = null;
    
    // Create new subscription with pending status (admin must confirm)
    $wpdb->insert(
        $subscriptions_table,
        array(
            'user_id' => $user_id,
            'plan_type' => $plan_type,
            'status' => 'pending',
            'start_date' => $start_date,
            'end_date' => $end_date,
            'payment_amount' => $plan_price,
            'payment_status' => $payment_status,
            'payment_date' => null,
            'created_at' => current_time('mysql'),
            'updated_at' => current_time('mysql')
        ),
        array('%d', '%s', '%s', '%s', '%s', '%f', '%s', '%s', '%s', '%s')
    );
    $subscription_id = $wpdb->insert_id;
    
    if (!$subscription_id) {
        wp_send_json_error(array('message' => 'Error al crear la suscripción. Por favor, intenta de nuevo.'));
        return;
    }
    
    // Auto-login user if not logged in
    if (!is_user_logged_in()) {
        wp_set_current_user($user_id);
        wp_set_auth_cookie($user_id);
    }
    
    wp_send_json_success(array(
        'message' => 'Solicitud de suscripción enviada exitosamente. El administrador revisará tu solicitud y la activará pronto.',
        'subscription_id' => $subscription_id,
        'user_id' => $user_id
    ));
}
add_action('wp_ajax_nidfil_process_checkout', 'nidfil_process_checkout');
add_action('wp_ajax_nopriv_nidfil_process_checkout', 'nidfil_process_checkout');

/**
 * Update Plan Type
 */
function nidfil_admin_update_plan_type() {
    check_ajax_referer('nidfil_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'Insufficient permissions'));
        return;
    }
    
    $plan_id = intval($_POST['plan_id'] ?? 0);
    $plan_type = sanitize_text_field($_POST['plan_type'] ?? 'free');
    
    if ($plan_id <= 0) {
        wp_send_json_error(array('message' => 'Invalid plan ID.'));
        return;
    }
    
    if (!in_array($plan_type, array('free', 'pro'))) {
        wp_send_json_error(array('message' => 'Invalid plan type.'));
        return;
    }
    
    $plans = get_option('nidfil_subscription_plans', array());
    if (is_string($plans)) {
        $plans = json_decode($plans, true);
    }
    
    $found = false;
    foreach ($plans as &$plan) {
        if (isset($plan['id']) && $plan['id'] == $plan_id) {
            $plan['plan_type'] = $plan_type;
            // Backward compatibility
            $plan['pro'] = ($plan_type === 'pro');
            // If FREE, set price to 0
            if ($plan_type === 'free') {
                $plan['price'] = 0;
            }
            $found = true;
            break;
        }
    }
    
    if (!$found) {
        wp_send_json_error(array('message' => 'Plan not found.'));
        return;
    }
    
    update_option('nidfil_subscription_plans', $plans);
    
    wp_send_json_success(array(
        'message' => 'Plan type updated successfully!',
        'plan_type' => $plan_type
    ));
}
add_action('wp_ajax_nidfil_admin_update_plan_type', 'nidfil_admin_update_plan_type');

/**
 * Update Plan Status
 */
function nidfil_admin_update_plan_status() {
    check_ajax_referer('nidfil_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'Insufficient permissions'));
        return;
    }
    
    $plan_id = intval($_POST['plan_id'] ?? 0);
    $status = sanitize_text_field($_POST['status'] ?? 'active');
    
    if ($plan_id <= 0) {
        wp_send_json_error(array('message' => 'Invalid plan ID.'));
        return;
    }
    
    if (!in_array($status, array('active', 'inactive'))) {
        wp_send_json_error(array('message' => 'Invalid status.'));
        return;
    }
    
    $plans = get_option('nidfil_subscription_plans', array());
    if (is_string($plans)) {
        $plans = json_decode($plans, true);
    }
    
    $found = false;
    foreach ($plans as &$plan) {
        if (isset($plan['id']) && $plan['id'] == $plan_id) {
            $plan['status'] = $status;
            $found = true;
            break;
        }
    }
    
    if (!$found) {
        wp_send_json_error(array('message' => 'Plan not found.'));
        return;
    }
    
    update_option('nidfil_subscription_plans', $plans);
    
    wp_send_json_success(array(
        'message' => 'Plan status updated successfully!',
        'status' => $status
    ));
}
add_action('wp_ajax_nidfil_admin_update_plan_status', 'nidfil_admin_update_plan_status');

/**
 * Confirm Subscription (Admin Action)
 */
function nidfil_admin_confirm_subscription() {
    check_ajax_referer('nidfil_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'Insufficient permissions'));
        return;
    }
    
    global $wpdb;
    $subscriptions_table = $wpdb->prefix . 'nidfil_subscriptions';
    
    $subscription_id = intval($_POST['subscription_id'] ?? 0);
    
    if ($subscription_id <= 0) {
        wp_send_json_error(array('message' => 'Invalid subscription ID.'));
        return;
    }
    
    // Get subscription details
    $subscription = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $subscriptions_table WHERE id = %d",
        $subscription_id
    ));
    
    if (!$subscription) {
        wp_send_json_error(array('message' => 'Subscription not found.'));
        return;
    }
    
    // Get plan period from stored plans
    $stored_plans = get_option('nidfil_subscription_plans', array());
    if (is_string($stored_plans)) {
        $stored_plans = json_decode($stored_plans, true);
    }
    
    $plan_period = 'month'; // Default
    foreach ($stored_plans as $stored_plan) {
        if (isset($stored_plan['id'])) {
            $stored_plan_type = isset($stored_plan['plan_type']) ? $stored_plan['plan_type'] : (isset($stored_plan['pro']) && $stored_plan['pro'] ? 'pro' : 'free');
            if ($stored_plan_type === $subscription->plan_type) {
                $plan_period = isset($stored_plan['period']) ? $stored_plan['period'] : 'month';
                break;
            }
        }
    }
    
    // Normalize period format (handle month, monthly, year, yearly, etc.)
    $period_normalized = strtolower(trim($plan_period));
    if (strpos($period_normalized, 'year') !== false) {
        $period_normalized = 'year';
    } elseif (strpos($period_normalized, 'month') !== false) {
        $period_normalized = 'month';
    } else {
        // Default to month if unclear
        $period_normalized = 'month';
    }
    
    // Calculate subscription dates based on period
    $start_date = current_time('mysql');
    $start_timestamp = strtotime($start_date);
    
    if ($period_normalized === 'year') {
        // Yearly subscription: add 1 year
        $end_date = date('Y-m-d H:i:s', strtotime('+1 year', $start_timestamp));
    } else {
        // Monthly subscription: add 1 month
        $end_date = date('Y-m-d H:i:s', strtotime('+1 month', $start_timestamp));
    }
    
    // Update subscription: set status to active, payment_status to completed
    $updated = $wpdb->update(
        $subscriptions_table,
        array(
            'status' => 'active',
            'payment_status' => 'completed',
            'start_date' => $start_date,
            'end_date' => $end_date,
            'payment_date' => current_time('mysql'),
            'updated_at' => current_time('mysql')
        ),
        array('id' => $subscription_id),
        array('%s', '%s', '%s', '%s', '%s', '%s'),
        array('%d')
    );
    
    if ($updated === false) {
        wp_send_json_error(array('message' => 'Error updating subscription.'));
        return;
    }
    
    wp_send_json_success(array(
        'message' => 'Subscription confirmed successfully!',
        'subscription_id' => $subscription_id
    ));
}
add_action('wp_ajax_nidfil_admin_confirm_subscription', 'nidfil_admin_confirm_subscription');

/**
 * Delete Subscription (Admin Action)
 */
function nidfil_admin_delete_subscription() {
    check_ajax_referer('nidfil_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'Insufficient permissions'));
        return;
    }
    
    global $wpdb;
    $subscriptions_table = $wpdb->prefix . 'nidfil_subscriptions';
    
    $subscription_id = intval($_POST['subscription_id'] ?? 0);
    
    if ($subscription_id <= 0) {
        wp_send_json_error(array('message' => 'Invalid subscription ID.'));
        return;
    }
    
    // Delete subscription
    $deleted = $wpdb->delete(
        $subscriptions_table,
        array('id' => $subscription_id),
        array('%d')
    );
    
    if ($deleted === false) {
        wp_send_json_error(array('message' => 'Error deleting subscription.'));
        return;
    }
    
    wp_send_json_success(array(
        'message' => 'Subscription deleted successfully!',
        'subscription_id' => $subscription_id
    ));
}
add_action('wp_ajax_nidfil_admin_delete_subscription', 'nidfil_admin_delete_subscription');

/**
 * Toggle Plan Feature (Check/Uncheck)
 */
function nidfil_admin_toggle_plan_feature() {
    check_ajax_referer('nidfil_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'Insufficient permissions'));
        return;
    }
    
    $plan_id = intval($_POST['plan_id'] ?? 0);
    $feature_key = sanitize_text_field($_POST['feature_key'] ?? '');
    $feature_text = sanitize_text_field($_POST['feature_text'] ?? '');
    $is_checked = isset($_POST['is_checked']) && $_POST['is_checked'] == '1' ? true : false;
    $icon_type = sanitize_text_field($_POST['icon_type'] ?? 'check');
    
    if ($plan_id <= 0) {
        wp_send_json_error(array('message' => 'Invalid plan ID.'));
        return;
    }
    
    // If feature_key is not provided but feature_text is, generate the key
    if (empty($feature_key) && !empty($feature_text)) {
        $feature_key = md5($feature_text);
    }
    
    if (empty($feature_key)) {
        wp_send_json_error(array('message' => 'Invalid feature key or text.'));
        return;
    }
    
    // Get existing feature states for this plan
    $plan_features = get_option('nidfil_plan_features_' . $plan_id, array());
    
    // Get existing icon types for this plan
    $plan_icon_types = get_option('nidfil_plan_feature_icons_' . $plan_id, array());
    
    // Update feature state
    $plan_features[$feature_key] = $is_checked;
    
    // Update icon type
    $plan_icon_types[$feature_key] = $icon_type;
    
    // Save feature states and icon types
    update_option('nidfil_plan_features_' . $plan_id, $plan_features);
    update_option('nidfil_plan_feature_icons_' . $plan_id, $plan_icon_types);
    
    wp_send_json_success(array(
        'message' => 'Feature status updated successfully!',
        'is_checked' => $is_checked,
        'feature_key' => $feature_key
    ));
}
add_action('wp_ajax_nidfil_admin_toggle_plan_feature', 'nidfil_admin_toggle_plan_feature');

/**
 * Get Offers for Lead
 */
function nidfil_admin_get_offers() {
    check_ajax_referer('nidfil_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'Insufficient permissions'));
        return;
    }
    
    global $wpdb;
    $offers_table = $wpdb->prefix . 'nidfil_offers';
    
    $lead_id = intval($_POST['lead_id']);
    
    $offers = $wpdb->get_results($wpdb->prepare(
        "SELECT o.*, u.display_name as specialist_name
         FROM $offers_table o
         LEFT JOIN {$wpdb->users} u ON o.specialist_id = u.ID
         WHERE o.lead_id = %d
         ORDER BY o.created_at DESC",
        $lead_id
    ));
    
    wp_send_json_success(array('offers' => $offers));
}
add_action('wp_ajax_nidfil_admin_get_offers', 'nidfil_admin_get_offers');

/**
 * Delete Lead
 */
function nidfil_admin_delete_lead() {
    check_ajax_referer('nidfil_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'Insufficient permissions'));
        return;
    }
    
    global $wpdb;
    $leads_table = $wpdb->prefix . 'nidfil_leads';
    
    $lead_id = intval($_POST['lead_id']);
    
    $wpdb->delete($leads_table, array('id' => $lead_id), array('%d'));
    
    nidfil_log_activity('lead', null, $lead_id, 'Lead deleted');
    
    wp_send_json_success(array('message' => 'Lead deleted successfully'));
}
add_action('wp_ajax_nidfil_admin_delete_lead', 'nidfil_admin_delete_lead');

/**
 * Approve Review
 */
function nidfil_admin_approve_review() {
    check_ajax_referer('nidfil_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'Insufficient permissions'));
        return;
    }
    
    global $wpdb;
    $reviews_table = $wpdb->prefix . 'nidfil_reviews';
    
    $review_id = intval($_POST['review_id']);
    $status = sanitize_text_field($_POST['status']);
    $new_status = $status === 'approved' ? 'pending' : 'approved';
    
    $wpdb->update(
        $reviews_table,
        array('status' => $new_status),
        array('id' => $review_id),
        array('%s'),
        array('%d')
    );
    
    // Recalculate specialist rating
    $review = $wpdb->get_row($wpdb->prepare("SELECT specialist_id FROM $reviews_table WHERE id = %d", $review_id));
    if ($review && $new_status === 'approved') {
        nidfil_recalculate_specialist_rating($review->specialist_id);
    }
    
    nidfil_log_activity('review', null, $review_id, 'Review ' . $new_status);
    
    wp_send_json_success(array('message' => 'Review status updated'));
}
add_action('wp_ajax_nidfil_admin_approve_review', 'nidfil_admin_approve_review');

/**
 * Reject Review
 */
function nidfil_admin_reject_review() {
    check_ajax_referer('nidfil_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'Insufficient permissions'));
        return;
    }
    
    global $wpdb;
    $reviews_table = $wpdb->prefix . 'nidfil_reviews';
    
    $review_id = intval($_POST['review_id']);
    $status = sanitize_text_field($_POST['status']);
    $new_status = $status === 'rejected' ? 'pending' : 'rejected';
    
    $wpdb->update(
        $reviews_table,
        array('status' => $new_status),
        array('id' => $review_id),
        array('%s'),
        array('%d')
    );
    
    nidfil_log_activity('review', null, $review_id, 'Review ' . $new_status);
    
    wp_send_json_success(array('message' => 'Review status updated'));
}
add_action('wp_ajax_nidfil_admin_reject_review', 'nidfil_admin_reject_review');

/**
 * Delete Review
 */
function nidfil_admin_delete_review() {
    check_ajax_referer('nidfil_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'Insufficient permissions'));
        return;
    }
    
    global $wpdb;
    $reviews_table = $wpdb->prefix . 'nidfil_reviews';
    
    $review_id = intval($_POST['review_id']);
    
    $review = $wpdb->get_row($wpdb->prepare("SELECT specialist_id FROM $reviews_table WHERE id = %d", $review_id));
    
    $wpdb->delete($reviews_table, array('id' => $review_id), array('%d'));
    
    // Recalculate specialist rating
    if ($review) {
        nidfil_recalculate_specialist_rating($review->specialist_id);
    }
    
    nidfil_log_activity('review', null, $review_id, 'Review deleted');
    
    wp_send_json_success(array('message' => 'Review deleted successfully'));
}
add_action('wp_ajax_nidfil_admin_delete_review', 'nidfil_admin_delete_review');

/**
 * Get Chat Messages
 */
function nidfil_admin_get_chat() {
    check_ajax_referer('nidfil_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'Insufficient permissions'));
        return;
    }
    
    global $wpdb;
    $messages_table = $wpdb->prefix . 'nidfil_messages';
    
    $conversation_id = intval($_POST['conversation_id']);
    
    $messages = $wpdb->get_results($wpdb->prepare(
        "SELECT m.*, u.display_name as sender_name
         FROM $messages_table m
         LEFT JOIN {$wpdb->users} u ON m.sender_id = u.ID
         WHERE m.conversation_id = %d
         ORDER BY m.created_at ASC",
        $conversation_id
    ));
    
    wp_send_json_success(array('messages' => $messages));
}
add_action('wp_ajax_nidfil_admin_get_chat', 'nidfil_admin_get_chat');

/**
 * Recalculate Specialist Rating
 */
function nidfil_recalculate_specialist_rating($specialist_id) {
    global $wpdb;
    $reviews_table = $wpdb->prefix . 'nidfil_reviews';
    
    $reviews = $wpdb->get_results($wpdb->prepare(
        "SELECT AVG(rating) as avg_rating, COUNT(*) as count
         FROM $reviews_table
         WHERE specialist_id = %d AND status = 'approved'",
        $specialist_id
    ));
    
    if (!empty($reviews)) {
        $avg_rating = round($reviews[0]->avg_rating, 1);
        $review_count = intval($reviews[0]->count);
        
        update_user_meta($specialist_id, 'average_rating', $avg_rating);
        update_user_meta($specialist_id, 'reviews_count', $review_count);
    }
}

/**
 * Get User Profile for Admin View
 */
function nidfil_admin_get_user_profile() {
    check_ajax_referer('nidfil_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'Insufficient permissions'));
        return;
    }
    
    $user_id = intval($_POST['user_id']);
    $user_type = sanitize_text_field($_POST['user_type']);
    
    $user = get_userdata($user_id);
    if (!$user) {
        wp_send_json_error(array('message' => 'User not found'));
        return;
    }
    
    // Get all user meta
    $profile_image = get_user_meta($user_id, 'profile_image', true);
    $user_bio = get_user_meta($user_id, 'user_bio', true);
    $user_phone = get_user_meta($user_id, 'user_phone', true);
    $user_location = get_user_meta($user_id, 'user_location', true);
    $user_skills = get_user_meta($user_id, 'user_skills', true);
    $account_status = get_user_meta($user_id, 'account_status', true) ?: 'active';
    $verified = get_user_meta($user_id, 'verified', true);
    
    // Get profile image URL
    $profile_image_url = '';
    if (!empty($profile_image)) {
        if (is_numeric($profile_image)) {
            $profile_image_url = wp_get_attachment_image_url($profile_image, 'thumbnail');
            if (empty($profile_image_url)) {
                $profile_image_url = wp_get_attachment_image_url($profile_image, 'medium');
            }
        } else {
            $profile_image_url = esc_url($profile_image);
        }
    }
    if (empty($profile_image_url)) {
        $profile_image_url = get_avatar_url($user_id, array('size' => 120));
    }
    
    // Specialist-specific data
    $specialist_data = array();
    if ($user_type === 'specialist') {
        $specialist_data = array(
            'profession' => get_user_meta($user_id, 'profession', true),
            'experience_years' => get_user_meta($user_id, 'experience_years', true),
            'service_area' => get_user_meta($user_id, 'service_area', true),
            'languages' => get_user_meta($user_id, 'languages', true),
            'services_offered' => get_user_meta($user_id, 'services_offered', true),
            'certifications' => get_user_meta($user_id, 'certifications', true),
            'hourly_rate' => get_user_meta($user_id, 'hourly_rate', true),
            'project_rate' => get_user_meta($user_id, 'project_rate', true),
            'business_name' => get_user_meta($user_id, 'business_name', true),
            'office_address' => get_user_meta($user_id, 'office_address', true),
            'business_city' => get_user_meta($user_id, 'business_city', true),
            'business_postal_code' => get_user_meta($user_id, 'business_postal_code', true),
            'business_country' => get_user_meta($user_id, 'business_country', true),
            'business_phone' => get_user_meta($user_id, 'business_phone', true),
            'business_email' => get_user_meta($user_id, 'business_email', true),
            'business_website' => get_user_meta($user_id, 'business_website', true),
            'average_rating' => get_user_meta($user_id, 'average_rating', true),
            'reviews_count' => get_user_meta($user_id, 'reviews_count', true),
            'autonomous_worker_number' => get_user_meta($user_id, 'autonomous_worker_number', true),
            'cif_number' => get_user_meta($user_id, 'cif_number', true),
            'registered_company' => get_user_meta($user_id, 'registered_company', true),
        );
    }
    
    // Social media links
    $social_links = array(
        'facebook' => get_user_meta($user_id, 'social_facebook', true),
        'twitter' => get_user_meta($user_id, 'social_twitter', true),
        'instagram' => get_user_meta($user_id, 'social_instagram', true),
        'linkedin' => get_user_meta($user_id, 'social_linkedin', true),
    );
    
    // Build HTML
    ob_start();
    ?>
    <div class="user-profile-modal-content">
        <div class="profile-header">
            <div class="profile-avatar">
                <img src="<?php echo esc_url($profile_image_url); ?>" alt="<?php echo esc_attr($user->display_name); ?>">
            </div>
            <div class="profile-header-info">
                <h3><?php echo esc_html($user->display_name); ?></h3>
                <p class="profile-email"><?php echo esc_html($user->user_email); ?></p>
                <div class="profile-badges">
                    <span class="user-type-badge user-type-<?php echo $user_type === 'specialist' ? 'specialist' : 'client'; ?>">
                        <?php echo $user_type === 'specialist' ? __('Specialist', 'nidfil-connect') : __('Client', 'nidfil-connect'); ?>
                    </span>
                    <span class="status-badge status-<?php echo esc_attr($account_status); ?>">
                        <?php echo ucfirst($account_status); ?>
                    </span>
                    <?php if ($user_type === 'specialist'): ?>
                        <span class="verified-badge verified-<?php echo $verified ? 'yes' : 'no'; ?>">
                            <?php echo $verified ? __('Verified', 'nidfil-connect') : __('Unverified', 'nidfil-connect'); ?>
                        </span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <div class="profile-sections">
            <div class="profile-section">
                <h4><i class="fas fa-user"></i> <?php _e('Personal Information', 'nidfil-connect'); ?></h4>
                <div class="profile-info-grid">
                    <div class="info-item">
                        <label><?php _e('Full Name', 'nidfil-connect'); ?></label>
                        <p><?php echo esc_html($user->display_name); ?></p>
                    </div>
                    <div class="info-item">
                        <label><?php _e('Email', 'nidfil-connect'); ?></label>
                        <p><?php echo esc_html($user->user_email); ?></p>
                    </div>
                    <?php if ($user_phone): ?>
                    <div class="info-item">
                        <label><?php _e('Phone', 'nidfil-connect'); ?></label>
                        <p><?php echo esc_html($user_phone); ?></p>
                    </div>
                    <?php endif; ?>
                    <?php if ($user_location): ?>
                    <div class="info-item">
                        <label><?php _e('Location', 'nidfil-connect'); ?></label>
                        <p><?php echo esc_html($user_location); ?></p>
                    </div>
                    <?php endif; ?>
                    <div class="info-item">
                        <label><?php _e('Registered', 'nidfil-connect'); ?></label>
                        <p><?php echo date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($user->user_registered)); ?></p>
                    </div>
                    <div class="info-item">
                        <label><?php _e('Account Status', 'nidfil-connect'); ?></label>
                        <p><span class="status-badge status-<?php echo esc_attr($account_status); ?>"><?php echo ucfirst($account_status); ?></span></p>
                    </div>
                </div>
            </div>
            
            <?php if ($user_bio): ?>
            <div class="profile-section">
                <h4><i class="fas fa-file-alt"></i> <?php _e('Bio', 'nidfil-connect'); ?></h4>
                <p class="profile-bio"><?php echo nl2br(esc_html($user_bio)); ?></p>
            </div>
            <?php endif; ?>
            
            <?php if ($user_type === 'specialist'): ?>
                <?php if ($specialist_data['profession']): ?>
                <div class="profile-section">
                    <h4><i class="fas fa-briefcase"></i> <?php _e('Professional Information', 'nidfil-connect'); ?></h4>
                    <div class="profile-info-grid">
                        <div class="info-item">
                            <label><?php _e('Profession', 'nidfil-connect'); ?></label>
                            <p><?php echo esc_html($specialist_data['profession']); ?></p>
                        </div>
                        <?php if ($specialist_data['experience_years']): ?>
                        <div class="info-item">
                            <label><?php _e('Experience', 'nidfil-connect'); ?></label>
                            <p><?php echo esc_html($specialist_data['experience_years']); ?> <?php _e('years', 'nidfil-connect'); ?></p>
                        </div>
                        <?php endif; ?>
                        <?php if ($specialist_data['service_area']): ?>
                        <div class="info-item">
                            <label><?php _e('Service Area', 'nidfil-connect'); ?></label>
                            <p><?php echo esc_html($specialist_data['service_area']); ?></p>
                        </div>
                        <?php endif; ?>
                        <?php if ($specialist_data['languages']): ?>
                        <div class="info-item">
                            <label><?php _e('Languages', 'nidfil-connect'); ?></label>
                            <p><?php echo esc_html($specialist_data['languages']); ?></p>
                        </div>
                        <?php endif; ?>
                        <?php if ($specialist_data['average_rating']): ?>
                        <div class="info-item">
                            <label><?php _e('Rating', 'nidfil-connect'); ?></label>
                            <p>
                                <span class="rating-display">
                                    <?php for ($i = 1; $i <= 5; $i++): ?>
                                        <i class="fas fa-star <?php echo $i <= round($specialist_data['average_rating']) ? 'filled' : ''; ?>"></i>
                                    <?php endfor; ?>
                                    <strong><?php echo esc_html($specialist_data['average_rating']); ?>/5</strong>
                                    (<?php echo esc_html($specialist_data['reviews_count'] ?: 0); ?> <?php _e('reviews', 'nidfil-connect'); ?>)
                                </span>
                            </p>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>
                
                <?php 
                // Verification Requirement Section - Always show for specialists
                if ($user_type === 'specialist'): 
                    $autonomous_worker = $specialist_data['autonomous_worker_number'] ?? '';
                    $cif = $specialist_data['cif_number'] ?? '';
                    $registered_company = $specialist_data['registered_company'] ?? '';
                ?>
                <div class="profile-section">
                    <h4><i class="fas fa-shield-alt"></i> <?php _e('Verification Requirement', 'nidfil-connect'); ?></h4>
                    <div class="profile-info-grid">
                        <div class="info-item">
                            <label><?php _e('Autonomous Worker Number', 'nidfil-connect'); ?></label>
                            <p><?php echo !empty($autonomous_worker) ? esc_html($autonomous_worker) : '<span style="color: #94a3b8; font-style: italic;">' . __('Not uploaded', 'nidfil-connect') . '</span>'; ?></p>
                        </div>
                        <div class="info-item">
                            <label><?php _e('CIF (Company Identification Number)', 'nidfil-connect'); ?></label>
                            <p><?php echo !empty($cif) ? esc_html($cif) : '<span style="color: #94a3b8; font-style: italic;">' . __('Not uploaded', 'nidfil-connect') . '</span>'; ?></p>
                        </div>
                        <div class="info-item">
                            <label><?php _e('Registered Company Name / Number', 'nidfil-connect'); ?></label>
                            <p><?php echo !empty($registered_company) ? esc_html($registered_company) : '<span style="color: #94a3b8; font-style: italic;">' . __('Not uploaded', 'nidfil-connect') . '</span>'; ?></p>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                
                <?php if ($specialist_data['services_offered']): ?>
                <div class="profile-section">
                    <h4><i class="fas fa-list"></i> <?php _e('Services Offered', 'nidfil-connect'); ?></h4>
                    <ul class="services-list">
                        <?php 
                        $services = is_array($specialist_data['services_offered']) ? $specialist_data['services_offered'] : explode("\n", $specialist_data['services_offered']);
                        foreach ($services as $service): 
                            if (!empty(trim($service))):
                        ?>
                            <li><i class="fas fa-check-circle"></i> <?php echo esc_html(trim($service)); ?></li>
                        <?php 
                            endif;
                        endforeach; 
                        ?>
                    </ul>
                </div>
                <?php endif; ?>
                
                <?php if ($specialist_data['certifications']): ?>
                <div class="profile-section">
                    <h4><i class="fas fa-certificate"></i> <?php _e('Certifications', 'nidfil-connect'); ?></h4>
                    <ul class="certifications-list">
                        <?php 
                        $certs = is_array($specialist_data['certifications']) ? $specialist_data['certifications'] : explode("\n", $specialist_data['certifications']);
                        foreach ($certs as $cert): 
                            if (!empty(trim($cert))):
                        ?>
                            <li><i class="fas fa-award"></i> <?php echo esc_html(trim($cert)); ?></li>
                        <?php 
                            endif;
                        endforeach; 
                        ?>
                    </ul>
                </div>
                <?php endif; ?>
                
                <?php if ($specialist_data['hourly_rate'] || $specialist_data['project_rate']): ?>
                <div class="profile-section">
                    <h4><i class="fas fa-euro-sign"></i> <?php _e('Pricing', 'nidfil-connect'); ?></h4>
                    <div class="profile-info-grid">
                        <?php if ($specialist_data['hourly_rate']): ?>
                        <div class="info-item">
                            <label><?php _e('Hourly Rate', 'nidfil-connect'); ?></label>
                            <p>€<?php echo number_format($specialist_data['hourly_rate'], 2); ?></p>
                        </div>
                        <?php endif; ?>
                        <?php if ($specialist_data['project_rate']): ?>
                        <div class="info-item">
                            <label><?php _e('Project Rate', 'nidfil-connect'); ?></label>
                            <p>€<?php echo number_format($specialist_data['project_rate'], 2); ?></p>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>
                
                <?php if ($specialist_data['business_name'] || $specialist_data['office_address']): ?>
                <div class="profile-section">
                    <h4><i class="fas fa-building"></i> <?php _e('Business Information', 'nidfil-connect'); ?></h4>
                    <div class="profile-info-grid">
                        <?php if ($specialist_data['business_name']): ?>
                        <div class="info-item">
                            <label><?php _e('Business Name', 'nidfil-connect'); ?></label>
                            <p><?php echo esc_html($specialist_data['business_name']); ?></p>
                        </div>
                        <?php endif; ?>
                        <?php if ($specialist_data['office_address']): ?>
                        <div class="info-item">
                            <label><?php _e('Address', 'nidfil-connect'); ?></label>
                            <p><?php echo esc_html($specialist_data['office_address']); ?></p>
                        </div>
                        <?php endif; ?>
                        <?php if ($specialist_data['business_city']): ?>
                        <div class="info-item">
                            <label><?php _e('City', 'nidfil-connect'); ?></label>
                            <p><?php echo esc_html($specialist_data['business_city']); ?></p>
                        </div>
                        <?php endif; ?>
                        <?php if ($specialist_data['business_phone']): ?>
                        <div class="info-item">
                            <label><?php _e('Business Phone', 'nidfil-connect'); ?></label>
                            <p><?php echo esc_html($specialist_data['business_phone']); ?></p>
                        </div>
                        <?php endif; ?>
                        <?php if ($specialist_data['business_email']): ?>
                        <div class="info-item">
                            <label><?php _e('Business Email', 'nidfil-connect'); ?></label>
                            <p><?php echo esc_html($specialist_data['business_email']); ?></p>
                        </div>
                        <?php endif; ?>
                        <?php if ($specialist_data['business_website']): ?>
                        <div class="info-item">
                            <label><?php _e('Website', 'nidfil-connect'); ?></label>
                            <p><a href="<?php echo esc_url($specialist_data['business_website']); ?>" target="_blank"><?php echo esc_html($specialist_data['business_website']); ?></a></p>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>
            <?php endif; ?>
            
            <?php if ($user_skills): ?>
            <div class="profile-section">
                <h4><i class="fas fa-tools"></i> <?php _e('Skills', 'nidfil-connect'); ?></h4>
                <p><?php echo nl2br(esc_html($user_skills)); ?></p>
            </div>
            <?php endif; ?>
            
            <?php if (!empty(array_filter($social_links))): ?>
            <div class="profile-section">
                <h4><i class="fas fa-share-alt"></i> <?php _e('Social Media', 'nidfil-connect'); ?></h4>
                <div class="social-links-profile">
                    <?php if ($social_links['facebook']): ?>
                    <a href="<?php echo esc_url($social_links['facebook']); ?>" target="_blank" class="social-link-item">
                        <i class="fab fa-facebook"></i> Facebook
                    </a>
                    <?php endif; ?>
                    <?php if ($social_links['twitter']): ?>
                    <a href="<?php echo esc_url($social_links['twitter']); ?>" target="_blank" class="social-link-item">
                        <i class="fab fa-twitter"></i> Twitter
                    </a>
                    <?php endif; ?>
                    <?php if ($social_links['instagram']): ?>
                    <a href="<?php echo esc_url($social_links['instagram']); ?>" target="_blank" class="social-link-item">
                        <i class="fab fa-instagram"></i> Instagram
                    </a>
                    <?php endif; ?>
                    <?php if ($social_links['linkedin']): ?>
                    <a href="<?php echo esc_url($social_links['linkedin']); ?>" target="_blank" class="social-link-item">
                        <i class="fab fa-linkedin"></i> LinkedIn
                    </a>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <?php
    $html = ob_get_clean();
    
    wp_send_json_success(array(
        'html' => $html,
        'user_name' => $user->display_name
    ));
}
add_action('wp_ajax_nidfil_admin_get_user_profile', 'nidfil_admin_get_user_profile');


