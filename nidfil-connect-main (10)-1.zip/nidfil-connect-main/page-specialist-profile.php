<?php
/**
 * Specialist Profile Template
 * 
 * Template Name: Specialist Profile
 * 
 * This is the main profile dashboard page that specialists see after login
 * 
 * @package NIDFIL_Connect
 */

// Redirect to home if user is not logged in
if (!is_user_logged_in()) {
    wp_redirect(home_url('/'));
    exit;
}

// Check user_type - redirect customers to their dashboard
$current_user_id = get_current_user_id();
$user_type = get_user_meta($current_user_id, 'user_type', true);
if ($user_type !== 'specialist') {
    // Default to customer dashboard if not specialist
    $client_dashboard_url = home_url('/client-profile/');
    wp_redirect($client_dashboard_url);
    exit;
}

// Ensure the page query is set up correctly
global $wp_query, $post;

// Always ensure we have a post object
if (!isset($post) || empty($post) || !is_object($post)) {
    // Try to find the specialist-profile page by template
    $specialist_profile_page = get_pages(array(
        'meta_key' => '_wp_page_template',
        'meta_value' => 'page-specialist-profile.php',
        'number' => 1,
        'post_status' => 'publish'
    ));
    
    if (!empty($specialist_profile_page)) {
        $post = $specialist_profile_page[0];
    } else {
        // Try to find by slug
        $page = get_page_by_path('specialist-profile');
        if ($page) {
            $post = $page;
        } else {
            // Create the page if it doesn't exist
            $page_id = nidfil_create_specialist_profile_page();
            if ($page_id) {
                $post = get_post($page_id);
            }
        }
    }
}

// Set up postdata if we have a post
if (isset($post) && is_object($post)) {
    setup_postdata($post);
    
    // Ensure query is set correctly
    $wp_query->queried_object = $post;
    $wp_query->queried_object_id = $post->ID;
    $wp_query->is_page = true;
    $wp_query->is_singular = true;
    $wp_query->is_404 = false;
    
    if (empty($wp_query->posts)) {
        $wp_query->posts = array($post);
        $wp_query->post_count = 1;
        $wp_query->found_posts = 1;
    }
} else {
    // If still no post, create one
    $page_id = nidfil_create_specialist_profile_page();
    if ($page_id) {
        $post = get_post($page_id);
        setup_postdata($post);
        $wp_query->queried_object = $post;
        $wp_query->queried_object_id = $post->ID;
        $wp_query->is_page = true;
        $wp_query->is_singular = true;
        $wp_query->is_404 = false;
        $wp_query->posts = array($post);
        $wp_query->post_count = 1;
        $wp_query->found_posts = 1;
    }
}

// Ensure 404 is not set
$wp_query->is_404 = false;
$wp_query->is_page = true;
$wp_query->is_singular = true;

get_header();
?>

<main id="main" class="site-main dashboard-main">
    <button class="mobile-menu-toggle" id="mobileMenuToggle" aria-label="Toggle Menu">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M3 12H21M3 6H21M3 18H21" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
    </button>
    <div class="dashboard-sidebar-overlay" id="sidebarOverlay"></div>
    <div class="dashboard-container">
        <!-- Dashboard Sidebar -->
        <aside class="dashboard-sidebar" id="dashboardSidebar">
            <button class="sidebar-close-mobile" id="sidebarCloseMobile" aria-label="Close Menu">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M18 6L6 18M6 6L18 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </button>
            <div class="sidebar-header">
                <div class="profile-image-container" id="profileImageContainer">
                    <?php 
                    $profile_image_id = get_user_meta(get_current_user_id(), 'profile_image', true);
                    $profile_image_url = '';
                    if ($profile_image_id) {
                        $profile_image_url = wp_get_attachment_image_url($profile_image_id, 'thumbnail');
                    }
                    if (empty($profile_image_url)) {
                        $profile_image_url = get_avatar_url(get_current_user_id(), array('size' => 150));
                    }
                    ?>
                    <img src="<?php echo esc_url($profile_image_url); ?>" alt="Profile" class="profile-image" id="profileImage">
                    <button class="edit-image-btn" id="editImageBtn" title="Edit Profile Image">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M14.5 2.5L17.5 5.5M16 1L19 4L11 12H8V9L16 1Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M16 6V16C16 17.1046 15.1046 18 14 18H4C2.89543 18 2 17.1046 2 16V6C2 4.89543 2.89543 4 4 4H14C15.1046 4 16 4.89543 16 6Z" stroke="currentColor" stroke-width="2"/>
                        </svg>
                    </button>
                    <input type="file" id="profileImageInput" accept="image/*" style="display: none;">
                    <div class="image-upload-actions" id="imageUploadActions">
                        <div class="image-upload-buttons">
                            <button class="btn btn-primary btn-sm" id="saveImageBtn">
                                <svg width="16" height="16" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M16.7071 5.29289C17.0976 5.68342 17.0976 6.31658 16.7071 6.70711L8.70711 14.7071C8.31658 15.0976 7.68342 15.0976 7.29289 14.7071L3.29289 10.7071C2.90237 10.3166 2.90237 9.68342 3.29289 9.29289C3.68342 8.90237 4.31658 8.90237 4.70711 9.29289L8 12.5858L15.2929 5.29289C15.6834 4.90237 16.3166 4.90237 16.7071 5.29289Z" fill="currentColor"/>
                                </svg>
                                Guardar
                            </button>
                            <button class="btn btn-outline btn-sm" id="cancelImageBtn">
                                <svg width="16" height="16" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M15 5L5 15M5 5L15 15" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                                Cancelar
                            </button>
                        </div>
                        <div class="image-upload-status" id="imageStatus"></div>
                    </div>
                </div>
                <h2 class="profile-name" id="profileName"><?php echo esc_html(wp_get_current_user()->display_name); ?></h2>
                <p class="profile-email"><?php echo esc_html(wp_get_current_user()->user_email); ?></p>
            </div>
            
            <nav class="dashboard-nav">
                <a href="#dashboard" class="nav-item active" data-section="dashboard">
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M3 3H9V9H3V3Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M11 3H17V9H11V3Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M3 11H9V17H3V11Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M11 11H17V17H11V11Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                    Panel
                </a>
                <a href="#profile" class="nav-item" data-section="profile">
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M10 10C12.7614 10 15 7.76142 15 5C15 2.23858 12.7614 0 10 0C7.23858 0 5 2.23858 5 5C5 7.76142 7.23858 10 10 10Z" fill="currentColor"/>
                        <path d="M10 12C6.68629 12 0 13.7909 0 17V20H20V17C20 13.7909 13.3137 12 10 12Z" fill="currentColor"/>
                    </svg>
                    Perfil
                </a>
                <a href="#services" class="nav-item" data-section="services">
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M3 4C3 2.89543 3.89543 2 5 2H15C16.1046 2 17 2.89543 17 4V16C17 17.1046 16.1046 18 15 18H5C3.89543 18 3 17.1046 3 16V4Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M3 7H17" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M7 7V4C7 3.44772 7.44772 3 8 3H12C12.5523 3 13 3.44772 13 4V7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M8 11H12M10 9V13" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                    Servicios
                </a>
                <a href="#projects" class="nav-item" data-section="projects">
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M3 3H9V9H3V3Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M11 3H17V9H11V3Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M3 11H9V17H3V11Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M11 11H17V17H11V11Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                    Proyectos
                </a>
                <a href="#messages" class="nav-item" data-section="messages">
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M18 2H2C0.895431 2 0 2.89543 0 4V16C0 17.1046 0.895431 18 2 18H18C19.1046 18 20 17.1046 20 16V4C20 2.89543 19.1046 2 18 2Z" stroke="currentColor" stroke-width="2"/>
                        <path d="M2 6L10 11L18 6" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                    </svg>
                    Mensajes
                    <span class="badge" id="messageBadge">0</span>
                </a>
                <a href="#analytics" class="nav-item" data-section="analytics">
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M3 16L9 10L13 14L17 10M17 10V14M17 10H13" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M2 2H18V18H2V2Z" stroke="currentColor" stroke-width="2"/>
                    </svg>
                    Analíticas
                </a>
                <a href="#reviews" class="nav-item" data-section="reviews">
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="currentColor"/>
                    </svg>
                    Reseñas
                </a>
                <a href="#notifications" class="nav-item" data-section="notifications">
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M10 2C8.34315 2 7 3.34315 7 5V8C7 9.10457 6.89543 10 6 10H4C2.89543 10 2 10.8954 2 12V14C2 15.1046 2.89543 16 4 16H16C17.1046 16 18 15.1046 18 14V12C18 10.8954 17.1046 10 16 10H14C13.1046 10 13 9.10457 13 8V5C13 3.34315 11.6569 2 10 2Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M7 16C7 17.1046 7.89543 18 9 18H11C12.1046 18 13 17.1046 13 16" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                    Notificaciones
                    <span class="badge badge-new" id="notificationsBadge">3</span>
                </a>
                <a href="#settings" class="nav-item" data-section="settings">
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M10 12C11.1046 12 12 11.1046 12 10C12 8.89543 11.1046 8 10 8C8.89543 8 8 8.89543 8 10C8 11.1046 8.89543 12 10 12Z" stroke="currentColor" stroke-width="2"/>
                        <path d="M17.6569 10C17.6569 10.4142 17.6569 10.8284 17.6569 11.2426C17.6569 11.6569 17.6569 12.0711 17.6569 12.4853C17.6569 12.8995 17.6569 13.3137 17.6569 13.7279C17.6569 14.1421 17.6569 14.5563 17.6569 14.9706C17.6569 15.3848 17.6569 15.799 17.6569 16.2132C17.6569 16.6274 17.6569 17.0416 17.6569 17.4558C17.6569 17.87 17.6569 18.2842 17.6569 18.6984" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                        <path d="M2.34315 10C2.34315 9.58579 2.34315 9.17157 2.34315 8.75736C2.34315 8.34315 2.34315 7.92893 2.34315 7.51472C2.34315 7.1005 2.34315 6.68629 2.34315 6.27208C2.34315 5.85786 2.34315 5.44365 2.34315 5.02943C2.34315 4.61522 2.34315 4.20101 2.34315 3.78679C2.34315 3.37258 2.34315 2.95837 2.34315 2.54415C2.34315 2.12994 2.34315 1.71573 2.34315 1.30151" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                    </svg>
                    Configuración
                </a>
                <a href="<?php echo esc_url(wp_logout_url(home_url('/'))); ?>" class="nav-item-logout" onclick="return confirm('¿Estás seguro de que deseas cerrar sesión?');">
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M13 7L17 11M17 11L13 15M17 11H7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M7 3H5C3.89543 3 3 3.89543 3 5V15C3 16.1046 3.89543 17 5 17H7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                    <span>Cerrar Sesión</span>
                </a>
            </nav>
        </aside>

        <!-- Dashboard Content -->
        <div class="dashboard-content">
            <!-- Dashboard Overview Section -->
            <section id="dashboardSection" class="dashboard-section active">
                <div class="section-header">
                    <h1>Panel de Control</h1>
                    <span class="welcome-text">Bienvenido, <?php echo esc_html(wp_get_current_user()->display_name); ?></span>
                </div>
                <div class="dashboard-overview">
                    <div class="overview-cards">
                        <div class="overview-card">
                            <div class="overview-icon overview-icon-info">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M21 15C21 15.5304 20.7893 16.0391 20.4142 16.4142C20.0391 16.7893 19.5304 17 19 17H7L3 21V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H19C19.5304 3 20.0391 3.21071 20.4142 3.58579C20.7893 3.96086 21 4.46957 21 5V15Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                            </div>
                            <div class="overview-content">
                                <h3>24</h3>
                                <p>Mensajes Recibidos</p>
                            </div>
                        </div>
                    </div>
                    <div class="recent-activity-summary">
                        <h2>Actividad Reciente</h2>
                        <div class="activity-summary-list">
                            <div class="activity-summary-item">
                                <div class="activity-summary-icon activity-icon-info"></div>
                                <div class="activity-summary-content">
                                    <p><strong>Nuevo mensaje</strong> de María García</p>
                                    <span>Hace 5 días</span>
                                </div>
                            </div>
                            <div class="activity-summary-item">
                                <div class="activity-summary-icon activity-icon-warning"></div>
                                <div class="activity-summary-content">
                                    <p><strong>Nueva reseña:</strong> 5 estrellas</p>
                                    <span>Hace 1 semana</span>
                                </div>
                            </div>
                        </div>
                        <a href="#profile" class="view-all-link nav-link" data-section="profile">Ver todo el perfil →</a>
                    </div>
                </div>
            </section>

            <!-- Profile Section -->
            <section id="profileSection" class="dashboard-section">
                <div class="section-header">
                    <h1>Mi Perfil</h1>
                    <button class="edit-btn" id="editProfileBtn">
                        <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M13.5 2.5L15.5 4.5M14 1L17 4L9 12H6V9L14 1Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M14 6V14C14 15.1046 13.1046 16 12 16H4C2.89543 16 2 15.1046 2 14V6C2 4.89543 2.89543 4 4 4H12C13.1046 4 14 4.89543 14 6Z" stroke="currentColor" stroke-width="2"/>
                        </svg>
                        Editar
                    </button>
                </div>

                <div class="profile-content">
                    <!-- Profile Completion Card -->
                    <div class="profile-card completion-card">
                        <div class="card-header">
                            <h3>Completitud del Perfil</h3>
                            <span class="completion-badge" id="completionPercentage">75%</span>
                        </div>
                        <div class="card-body">
                            <div class="completion-bar">
                                <div class="completion-fill" id="completionFill" style="width: 75%;"></div>
                            </div>
                            <p class="completion-text">Completa tu perfil para mejorar tu experiencia</p>
                        </div>
                    </div>

                    <!-- Statistics Cards -->
                    <div class="stats-grid">
                        <div class="stat-card stat-card-primary">
                            <div class="stat-icon">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z" fill="currentColor"/>
                                </svg>
                            </div>
                            <div class="stat-content">
                                <h4 class="stat-value" id="averageRating">4.8</h4>
                                <p class="stat-label">Calificación Promedio</p>
                            </div>
                        </div>
                        <div class="stat-card stat-card-success">
                            <div class="stat-icon">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M3 3H9V9H3V3Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M11 3H17V9H11V3Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M3 11H9V17H3V11Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M11 11H17V17H11V11Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                            </div>
                            <div class="stat-content">
                                <h4 class="stat-value" id="projectsCompleted">45</h4>
                                <p class="stat-label">Proyectos Completados</p>
                            </div>
                        </div>
                        <div class="stat-card stat-card-info">
                            <div class="stat-icon">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M21 15C21 15.5304 20.7893 16.0391 20.4142 16.4142C20.0391 16.7893 19.5304 17 19 17H7L3 21V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H19C19.5304 3 20.0391 3.21071 20.4142 3.58579C20.7893 3.96086 21 4.46957 21 5V15Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                            </div>
                            <div class="stat-content">
                                <h4 class="stat-value" id="totalMessages">24</h4>
                                <p class="stat-label">Mensajes</p>
                            </div>
                        </div>
                        <div class="stat-card stat-card-warning">
                            <div class="stat-icon">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M1 12C1 12 5 4 12 4C19 4 23 12 23 12C23 12 19 20 12 20C5 20 1 12 1 12Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                    <circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="2"/>
                                </svg>
                            </div>
                            <div class="stat-content">
                                <h4 class="stat-value" id="profileViews">1,234</h4>
                                <p class="stat-label">Vistas del Perfil</p>
                            </div>
                        </div>
                    </div>

                    <!-- Quick Actions -->
                    <div class="profile-card">
                        <div class="card-header">
                            <h3>Acciones Rápidas</h3>
                        </div>
                        <div class="card-body">
                            <div class="quick-actions-grid">
                                <button class="quick-action-btn">
                                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M21 15C21 15.5304 20.7893 16.0391 20.4142 16.4142C20.0391 16.7893 19.5304 17 19 17H7L3 21V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H19C19.5304 3 20.0391 3.21071 20.4142 3.58579C20.7893 3.96086 21 4.46957 21 5V15Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                    <span>Nuevo Mensaje</span>
                                </button>
                                <button class="quick-action-btn">
                                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 20C16.4183 20 20 16.4183 20 12C20 7.58172 16.4183 4 12 4C7.58172 4 4 7.58172 4 12C4 16.4183 7.58172 20 12 20Z" stroke="currentColor" stroke-width="2"/>
                                        <path d="M12 8V12L15 15" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                                    </svg>
                                    <span>Ver Actividad</span>
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Professional Information -->
                    <div class="profile-card">
                        <div class="card-header">
                            <h3>Información Profesional</h3>
                            <button class="icon-btn edit-info-btn" id="editProfessionalBtn">
                                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M13.5 2.5L15.5 4.5M14 1L17 4L9 12H6V9L14 1Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                            </button>
                        </div>
                        <div class="card-body">
                            <div class="info-grid">
                                <div class="info-item">
                                    <label>Profesión/Especialidad</label>
                                    <p class="info-value" id="professionValue"><?php echo esc_html(get_user_meta(get_current_user_id(), 'profession', true) ?: 'No agregado'); ?></p>
                                    <input type="text" class="info-input" id="professionInput" value="<?php echo esc_attr(get_user_meta(get_current_user_id(), 'profession', true)); ?>" placeholder="Ej: Electricista" style="display: none;">
                                </div>
                                <div class="info-item">
                                    <label>Años de Experiencia</label>
                                    <p class="info-value" id="experienceValue"><?php echo esc_html(get_user_meta(get_current_user_id(), 'experience_years', true) ?: 'No agregado'); ?></p>
                                    <input type="number" class="info-input" id="experienceInput" value="<?php echo esc_attr(get_user_meta(get_current_user_id(), 'experience_years', true)); ?>" placeholder="5" min="0" style="display: none;">
                                </div>
                                <div class="info-item">
                                    <label>Zona de Servicio</label>
                                    <p class="info-value" id="serviceAreaValue"><?php echo esc_html(get_user_meta(get_current_user_id(), 'service_area', true) ?: 'No agregado'); ?></p>
                                    <input type="text" class="info-input" id="serviceAreaInput" value="<?php echo esc_attr(get_user_meta(get_current_user_id(), 'service_area', true)); ?>" placeholder="Ej: Madrid, Barcelona" style="display: none;">
                                </div>
                                <div class="info-item">
                                    <label>Idiomas</label>
                                    <p class="info-value" id="languagesValue"><?php echo esc_html(get_user_meta(get_current_user_id(), 'languages', true) ?: 'No agregado'); ?></p>
                                    <input type="text" class="info-input" id="languagesInput" value="<?php echo esc_attr(get_user_meta(get_current_user_id(), 'languages', true)); ?>" placeholder="Ej: Español, Inglés" style="display: none;">
                                </div>
                            </div>
                            <div class="form-actions" id="professionalFormActions" style="display: none;">
                                <button class="btn btn-primary" id="saveProfessionalBtn">Guardar</button>
                                <button class="btn btn-outline" id="cancelProfessionalBtn">Cancelar</button>
                            </div>
                        </div>
                    </div>

                    <!-- Verification Requirement -->
                    <div class="profile-card verification-section">
                        <div class="card-header">
                            <h3>Requisito de Verificación</h3>
                            <button class="icon-btn edit-info-btn" id="editVerificationBtn">
                                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M13.5 2.5L15.5 4.5M14 1L17 4L9 12H6V9L14 1Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                            </button>
                        </div>
                        <div class="card-body">
                            <p class="verification-description">
                                Durante el registro de especialista, el usuario debe proporcionar una identificación profesional válida. Al menos uno de los siguientes campos es obligatorio para proceder con el registro.
                            </p>
                            <div class="info-grid">
                                <div class="info-item">
                                    <label>Número de Trabajador Autónomo</label>
                                    <p class="info-value" id="autonomousWorkerValue"><?php echo esc_html(get_user_meta(get_current_user_id(), 'autonomous_worker_number', true) ?: 'No agregado'); ?></p>
                                    <input type="text" class="info-input" id="autonomousWorkerInput" value="<?php echo esc_attr(get_user_meta(get_current_user_id(), 'autonomous_worker_number', true)); ?>" placeholder="Ej: 12345678A" style="display: none;">
                                </div>
                                <div class="info-item">
                                    <label>CIF (Número de Identificación Fiscal de Empresa)</label>
                                    <p class="info-value" id="cifValue"><?php echo esc_html(get_user_meta(get_current_user_id(), 'cif_number', true) ?: 'No agregado'); ?></p>
                                    <input type="text" class="info-input" id="cifInput" value="<?php echo esc_attr(get_user_meta(get_current_user_id(), 'cif_number', true)); ?>" placeholder="Ej: A12345678" style="display: none;">
                                </div>
                                <div class="info-item">
                                    <label>Nombre/Número de Empresa Registrada</label>
                                    <p class="info-value" id="registeredCompanyValue"><?php echo esc_html(get_user_meta(get_current_user_id(), 'registered_company', true) ?: 'No agregado'); ?></p>
                                    <input type="text" class="info-input" id="registeredCompanyInput" value="<?php echo esc_attr(get_user_meta(get_current_user_id(), 'registered_company', true)); ?>" placeholder="Ej: Empresa S.L. / Número de registro" style="display: none;">
                                </div>
                            </div>
                            <div class="form-actions" id="verificationFormActions" style="display: none;">
                                <button class="btn btn-primary" id="saveVerificationBtn">Guardar</button>
                                <button class="btn btn-outline" id="cancelVerificationBtn">Cancelar</button>
                            </div>
                            <div class="verification-error" id="verificationError" style="display: none; color: #ef4444; margin-top: 10px; font-size: 14px;">
                                <strong>Error:</strong> Debe proporcionar al menos una identificación profesional válida.
                            </div>
                        </div>
                    </div>

                    <!-- Certifications & Qualifications -->
                    <div class="profile-card">
                        <div class="card-header">
                            <h3>Certificaciones y Calificaciones</h3>
                            <button class="icon-btn edit-info-btn" id="editCertificationsBtn">
                                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M13.5 2.5L15.5 4.5M14 1L17 4L9 12H6V9L14 1Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                            </button>
                        </div>
                        <div class="card-body">
                            <div id="certificationsList" class="certifications-list">
                                <?php
                                $certifications = get_user_meta(get_current_user_id(), 'certifications', true);
                                if (empty($certifications)) {
                                    echo '<p class="no-data">No has agregado certificaciones aún. Haz clic en editar para agregar.</p>';
                                } else {
                                    if (is_array($certifications)) {
                                        foreach ($certifications as $cert) {
                                            echo '<div class="certification-item"><span>' . esc_html($cert) . '</span></div>';
                                        }
                                    } else {
                                        echo '<div class="certification-item"><span>' . esc_html($certifications) . '</span></div>';
                                    }
                                }
                                ?>
                            </div>
                            <div class="certifications-edit-form" id="certificationsEditForm" style="display: none;">
                                <textarea id="certificationsTextarea" rows="5" placeholder="Escribe cada certificación en una línea separada..."></textarea>
                                <div class="form-actions">
                                    <button class="btn btn-primary" id="saveCertificationsBtn">Guardar</button>
                                    <button class="btn btn-outline" id="cancelCertificationsBtn">Cancelar</button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Business Video -->
                    <div class="profile-card">
                        <div class="card-header">
                            <h3>Video de Negocio</h3>
                            <button class="icon-btn edit-info-btn" id="editVideoBtn">
                                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M13.5 2.5L15.5 4.5M14 1L17 4L9 12H6V9L14 1Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                            </button>
                        </div>
                        <div class="card-body">
                            <div id="businessVideoContainer" class="business-video-container">
                                <?php 
                                $business_video_id = get_user_meta(get_current_user_id(), 'business_video', true);
                                $business_video_url = '';
                                if ($business_video_id) {
                                    $business_video_url = wp_get_attachment_url($business_video_id);
                                }
                                ?>
                                <?php if (!empty($business_video_url)): ?>
                                    <div class="video-preview-wrapper">
                                        <video id="businessVideoPreview" controls class="business-video-preview" data-original-src="<?php echo esc_url($business_video_url); ?>">
                                            <source src="<?php echo esc_url($business_video_url); ?>" type="video/mp4">
                                            Tu navegador no soporta la reproducción de video.
                                        </video>
                                        <button class="btn btn-outline btn-sm remove-video-btn" id="removeVideoBtn">
                                            <svg width="16" height="16" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M15 5L5 15M5 5L15 15" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                            </svg>
                                            Eliminar Video
                                        </button>
                                    </div>
                                <?php else: ?>
                                    <div class="video-upload-placeholder" id="videoUploadPlaceholder">
                                        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M15 10L19.553 12.276C19.7054 12.3529 19.8317 12.4707 19.9182 12.6169C20.0047 12.7631 20.0484 12.9322 20.0446 13.1036C20.0408 13.275 19.9896 13.4421 19.8965 13.5848C19.8034 13.7275 19.6721 13.8401 19.5168 13.9104L15 16M5 18H13C13.5304 18 14.0391 17.7893 14.4142 17.4142C14.7893 17.0391 15 16.5304 15 16V8C15 7.46957 14.7893 6.96086 14.4142 6.58579C14.0391 6.21071 13.5304 6 13 6H5C4.46957 6 3.96086 6.21071 3.58579 6.58579C3.21071 6.96086 3 7.46957 3 8V16C3 16.5304 3.21071 17.0391 3.58579 17.4142C3.96086 17.7893 4.46957 18 5 18Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                        </svg>
                                        <p class="no-data">No has subido un video de negocio aún.</p>
                                        <button class="btn btn-primary btn-sm" id="uploadVideoBtn">
                                            <svg width="16" height="16" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M10 4V16M4 10H16" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                                            </svg>
                                            Subir Video
                                        </button>
                                    </div>
                                <?php endif; ?>
                                <input type="file" id="businessVideoInput" accept="video/*" style="display: none;">
                                <div class="video-upload-actions" id="videoUploadActions" style="display: none;">
                                    <div class="video-upload-buttons">
                                        <button class="btn btn-primary btn-sm" id="saveVideoBtn">
                                            <svg width="16" height="16" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M16.7071 5.29289C17.0976 5.68342 17.0976 6.31658 16.7071 6.70711L8.70711 14.7071C8.31658 15.0976 7.68342 15.0976 7.29289 14.7071L3.29289 10.7071C2.90237 10.3166 2.90237 9.68342 3.29289 9.29289C3.68342 8.90237 4.31658 8.90237 4.70711 9.29289L8 12.5858L15.2929 5.29289C15.6834 4.90237 16.3166 4.90237 16.7071 5.29289Z" fill="currentColor"/>
                                            </svg>
                                            Guardar
                                        </button>
                                        <button class="btn btn-outline btn-sm" id="cancelVideoBtn">
                                            <svg width="16" height="16" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M15 5L5 15M5 5L15 15" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                            </svg>
                                            Cancelar
                                        </button>
                                    </div>
                                    <div class="video-upload-status" id="videoStatus"></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Business Data / Office Location -->
                    <div class="profile-card">
                        <div class="card-header">
                            <h3>Datos del Negocio / Ubicación de la Oficina</h3>
                            <button class="icon-btn edit-info-btn" id="editBusinessDataBtn">
                                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M13.5 2.5L15.5 4.5M14 1L17 4L9 12H6V9L14 1Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                            </button>
                        </div>
                        <div class="card-body">
                            <div class="info-grid">
                                <div class="info-item">
                                    <label>Nombre del Negocio</label>
                                    <p class="info-value" id="businessNameValue"><?php echo esc_html(get_user_meta(get_current_user_id(), 'business_name', true) ?: 'No agregado'); ?></p>
                                    <input type="text" class="info-input" id="businessNameInput" value="<?php echo esc_attr(get_user_meta(get_current_user_id(), 'business_name', true)); ?>" placeholder="Ej: Servicios Eléctricos García" style="display: none;">
                                </div>
                                <div class="info-item">
                                    <label>Dirección de la Oficina</label>
                                    <p class="info-value" id="officeAddressValue"><?php echo esc_html(get_user_meta(get_current_user_id(), 'office_address', true) ?: 'No agregado'); ?></p>
                                    <input type="text" class="info-input" id="officeAddressInput" value="<?php echo esc_attr(get_user_meta(get_current_user_id(), 'office_address', true)); ?>" placeholder="Ej: Calle Mayor 123, Madrid" style="display: none;">
                                </div>
                                <div class="info-item">
                                    <label>Ciudad</label>
                                    <p class="info-value" id="businessCityValue"><?php echo esc_html(get_user_meta(get_current_user_id(), 'business_city', true) ?: 'No agregado'); ?></p>
                                    <input type="text" class="info-input" id="businessCityInput" value="<?php echo esc_attr(get_user_meta(get_current_user_id(), 'business_city', true)); ?>" placeholder="Ej: Madrid" style="display: none;">
                                </div>
                                <div class="info-item">
                                    <label>Código Postal</label>
                                    <p class="info-value" id="businessPostalCodeValue"><?php echo esc_html(get_user_meta(get_current_user_id(), 'business_postal_code', true) ?: 'No agregado'); ?></p>
                                    <input type="text" class="info-input" id="businessPostalCodeInput" value="<?php echo esc_attr(get_user_meta(get_current_user_id(), 'business_postal_code', true)); ?>" placeholder="Ej: 28001" style="display: none;">
                                </div>
                                <div class="info-item">
                                    <label>País</label>
                                    <p class="info-value" id="businessCountryValue"><?php echo esc_html(get_user_meta(get_current_user_id(), 'business_country', true) ?: 'No agregado'); ?></p>
                                    <input type="text" class="info-input" id="businessCountryInput" value="<?php echo esc_attr(get_user_meta(get_current_user_id(), 'business_country', true)); ?>" placeholder="Ej: España" style="display: none;">
                                </div>
                                <div class="info-item">
                                    <label>Teléfono del Negocio</label>
                                    <p class="info-value" id="businessPhoneValue"><?php echo esc_html(get_user_meta(get_current_user_id(), 'business_phone', true) ?: 'No agregado'); ?></p>
                                    <input type="tel" class="info-input" id="businessPhoneInput" value="<?php echo esc_attr(get_user_meta(get_current_user_id(), 'business_phone', true)); ?>" placeholder="Ej: +34 900 123 456" style="display: none;">
                                </div>
                                <div class="info-item">
                                    <label>Email del Negocio</label>
                                    <p class="info-value" id="businessEmailValue"><?php echo esc_html(get_user_meta(get_current_user_id(), 'business_email', true) ?: 'No agregado'); ?></p>
                                    <input type="email" class="info-input" id="businessEmailInput" value="<?php echo esc_attr(get_user_meta(get_current_user_id(), 'business_email', true)); ?>" placeholder="Ej: contacto@negocio.com" style="display: none;">
                                </div>
                                <div class="info-item">
                                    <label>Sitio Web</label>
                                    <p class="info-value" id="businessWebsiteValue"><?php echo esc_html(get_user_meta(get_current_user_id(), 'business_website', true) ?: 'No agregado'); ?></p>
                                    <input type="url" class="info-input" id="businessWebsiteInput" value="<?php echo esc_attr(get_user_meta(get_current_user_id(), 'business_website', true)); ?>" placeholder="Ej: https://www.mi-negocio.com" style="display: none;">
                                </div>
                            </div>
                            <div class="form-actions" id="businessDataFormActions" style="display: none;">
                                <button class="btn btn-primary" id="saveBusinessDataBtn">Guardar</button>
                                <button class="btn btn-outline" id="cancelBusinessDataBtn">Cancelar</button>
                            </div>
                        </div>
                    </div>

                    <!-- Pricing & Rates -->
                    <div class="profile-card">
                        <div class="card-header">
                            <h3>Tarifas y Precios</h3>
                            <button class="icon-btn edit-info-btn" id="editPricingBtn">
                                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M13.5 2.5L15.5 4.5M14 1L17 4L9 12H6V9L14 1Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                            </button>
                        </div>
                        <div class="card-body">
                            <div class="info-grid">
                                <div class="info-item">
                                    <label>Tarifa por Hora (€)</label>
                                    <p class="info-value" id="hourlyRateValue"><?php echo esc_html(get_user_meta(get_current_user_id(), 'hourly_rate', true) ?: 'No agregado'); ?></p>
                                    <input type="number" class="info-input" id="hourlyRateInput" value="<?php echo esc_attr(get_user_meta(get_current_user_id(), 'hourly_rate', true)); ?>" placeholder="50" min="0" step="0.01" style="display: none;">
                                </div>
                                <div class="info-item">
                                    <label>Tarifa por Proyecto (€)</label>
                                    <p class="info-value" id="projectRateValue"><?php echo esc_html(get_user_meta(get_current_user_id(), 'project_rate', true) ?: 'No agregado'); ?></p>
                                    <input type="number" class="info-input" id="projectRateInput" value="<?php echo esc_attr(get_user_meta(get_current_user_id(), 'project_rate', true)); ?>" placeholder="500" min="0" step="0.01" style="display: none;">
                                </div>
                            </div>
                            <div class="form-actions" id="pricingFormActions" style="display: none;">
                                <button class="btn btn-primary" id="savePricingBtn">Guardar</button>
                                <button class="btn btn-outline" id="cancelPricingBtn">Cancelar</button>
                            </div>
                        </div>
                    </div>

                    <!-- Bio Section -->
                    <div class="profile-card">
                        <div class="card-header">
                            <h3>Biografía</h3>
                            <button class="icon-btn edit-bio-btn" id="editBioBtn">
                                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M13.5 2.5L15.5 4.5M14 1L17 4L9 12H6V9L14 1Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                            </button>
                        </div>
                        <div class="card-body">
                            <?php 
                            $user_bio = get_user_meta(get_current_user_id(), 'user_bio', true);
                            $bio_text = !empty($user_bio) ? esc_html($user_bio) : 'Aún no has agregado una biografía. Haz clic en editar para agregar una.';
                            ?>
                            <p class="bio-text" id="bioText"><?php echo $bio_text; ?></p>
                            <div class="bio-edit-form" id="bioEditForm" style="display: none;">
                                <textarea id="bioTextarea" rows="5" placeholder="Escribe tu biografía aquí..."><?php echo esc_textarea($user_bio); ?></textarea>
                                <div class="form-actions">
                                    <button class="btn btn-primary" id="saveBioBtn">Guardar</button>
                                    <button class="btn btn-outline" id="cancelBioBtn">Cancelar</button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Personal Information -->
                    <div class="profile-card">
                        <div class="card-header">
                            <h3>Información Personal</h3>
                            <button class="icon-btn edit-info-btn" id="editInfoBtn">
                                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M13.5 2.5L15.5 4.5M14 1L17 4L9 12H6V9L14 1Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                            </button>
                        </div>
                        <div class="card-body">
                            <div class="info-grid">
                                <div class="info-item">
                                    <label>Nombre completo</label>
                                    <p class="info-value" id="fullNameValue"><?php echo esc_html(wp_get_current_user()->display_name); ?></p>
                                    <input type="text" class="info-input" id="fullNameInput" value="<?php echo esc_attr(wp_get_current_user()->display_name); ?>" style="display: none;">
                                </div>
                                <div class="info-item">
                                    <label>Email</label>
                                    <p class="info-value" id="emailValue"><?php echo esc_html(wp_get_current_user()->user_email); ?></p>
                                    <input type="email" class="info-input" id="emailInput" value="<?php echo esc_attr(wp_get_current_user()->user_email); ?>" style="display: none;">
                                </div>
                                <div class="info-item">
                                    <label>Teléfono</label>
                                    <?php 
                                    $user_phone = get_user_meta(get_current_user_id(), 'user_phone', true);
                                    $phone_display = !empty($user_phone) ? esc_html($user_phone) : 'No agregado';
                                    ?>
                                    <p class="info-value" id="phoneValue"><?php echo $phone_display; ?></p>
                                    <input type="tel" class="info-input" id="phoneInput" value="<?php echo esc_attr($user_phone); ?>" placeholder="+34 600 000 000" style="display: none;">
                                </div>
                                <div class="info-item">
                                    <label>Ubicación</label>
                                    <?php 
                                    $user_location = get_user_meta(get_current_user_id(), 'user_location', true);
                                    $location_display = !empty($user_location) ? esc_html($user_location) : 'No agregado';
                                    ?>
                                    <p class="info-value" id="locationValue"><?php echo $location_display; ?></p>
                                    <input type="text" class="info-input" id="locationInput" value="<?php echo esc_attr($user_location); ?>" placeholder="Madrid, España" style="display: none;">
                                </div>
                            </div>
                            <div class="form-actions" id="infoFormActions" style="display: none;">
                                <button class="btn btn-primary" id="saveInfoBtn">Guardar</button>
                                <button class="btn btn-outline" id="cancelInfoBtn">Cancelar</button>
                            </div>
                        </div>
                    </div>


                    <!-- Social Media Links -->
                    <div class="profile-card">
                        <div class="card-header">
                            <h3>Redes Sociales</h3>
                            <button class="icon-btn edit-social-btn" id="editSocialBtn">
                                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M13.5 2.5L15.5 4.5M14 1L17 4L9 12H6V9L14 1Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                            </button>
                        </div>
                        <div class="card-body">
                            <div class="social-links-container" id="socialLinksContainer">
                                <?php 
                                $social_facebook = get_user_meta(get_current_user_id(), 'social_facebook', true);
                                $social_twitter = get_user_meta(get_current_user_id(), 'social_twitter', true);
                                $social_instagram = get_user_meta(get_current_user_id(), 'social_instagram', true);
                                $social_linkedin = get_user_meta(get_current_user_id(), 'social_linkedin', true);
                                ?>
                                <div class="social-link-item">
                                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M18 2H15C13.6739 2 12.4021 2.52678 11.4645 3.46447C10.5268 4.40215 10 5.67392 10 7V10H7V14H10V22H14V14H17L18 10H14V7C14 6.73478 14.1054 6.48043 14.2929 6.29289C14.4804 6.10536 14.7348 6 15 6H18V2Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                    <span class="social-link-value" id="facebookValue"><?php echo !empty($social_facebook) ? esc_html($social_facebook) : 'No agregado'; ?></span>
                                    <input type="text" class="social-link-input" id="facebookInput" value="<?php echo esc_attr($social_facebook); ?>" placeholder="facebook.com/tu-perfil" style="display: none;">
                                </div>
                                <div class="social-link-item">
                                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M23 3C22.0424 3.67548 20.9821 4.19211 19.86 4.53C19.2577 3.83751 18.4573 3.34669 17.567 3.12393C16.6767 2.90117 15.7395 2.95724 14.8821 3.28448C14.0247 3.61172 13.2884 4.1944 12.773 4.95372C12.2575 5.71303 11.9877 6.61234 12 7.53V8.53C10.2426 8.57557 8.50127 8.18581 6.93101 7.39545C5.36074 6.60508 4.01032 5.43864 3 4C3 4 -1 13 8 17C5.94053 18.398 3.48716 19.099 1 19C10 24 21 19 21 7.5C20.9991 7.22145 20.9723 6.94359 20.92 6.67C21.9406 5.66349 22.6608 4.39271 23 3V3Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                    <span class="social-link-value" id="twitterValue"><?php echo !empty($social_twitter) ? esc_html($social_twitter) : 'No agregado'; ?></span>
                                    <input type="text" class="social-link-input" id="twitterInput" value="<?php echo esc_attr($social_twitter); ?>" placeholder="twitter.com/tu-perfil" style="display: none;">
                                </div>
                                <div class="social-link-item">
                                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <rect x="2" y="2" width="20" height="20" rx="5" ry="5" stroke="currentColor" stroke-width="2"/>
                                        <path d="M16 11.37C16.1234 12.2022 15.9813 13.0522 15.5938 13.799C15.2063 14.5458 14.5932 15.1514 13.8416 15.5297C13.0901 15.9079 12.2385 16.0396 11.4078 15.9059C10.5771 15.7723 9.80977 15.3801 9.21485 14.7852C8.61993 14.1902 8.22774 13.4229 8.09408 12.5922C7.96042 11.7615 8.09208 10.9099 8.47034 10.1584C8.8486 9.40685 9.45419 8.79374 10.201 8.40624C10.9478 8.01874 11.7978 7.87659 12.63 8C13.4789 8.12588 14.2649 8.52146 14.8717 9.1283C15.4785 9.73514 15.8741 10.5211 16 11.37Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                    <span class="social-link-value" id="instagramValue"><?php echo !empty($social_instagram) ? esc_html($social_instagram) : 'No agregado'; ?></span>
                                    <input type="text" class="social-link-input" id="instagramInput" value="<?php echo esc_attr($social_instagram); ?>" placeholder="instagram.com/tu-perfil" style="display: none;">
                                </div>
                                <div class="social-link-item">
                                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M16 8C17.5913 8 19.1174 8.63214 20.2426 9.75736C21.3679 10.8826 22 12.4087 22 14V21H18V14C18 13.4696 17.7893 12.9609 17.4142 12.5858C17.0391 12.2107 16.5304 12 16 12C15.4696 12 14.9609 12.2107 14.5858 12.5858C14.2107 12.9609 14 13.4696 14 14V21H10V14C10 12.4087 10.6321 10.8826 11.7574 9.75736C12.8826 8.63214 14.4087 8 16 8Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                        <path d="M6 9H2V21H6V9Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                        <circle cx="4" cy="4" r="2" stroke="currentColor" stroke-width="2"/>
                                    </svg>
                                    <span class="social-link-value" id="linkedinValue"><?php echo !empty($social_linkedin) ? esc_html($social_linkedin) : 'No agregado'; ?></span>
                                    <input type="text" class="social-link-input" id="linkedinInput" value="<?php echo esc_attr($social_linkedin); ?>" placeholder="linkedin.com/in/tu-perfil" style="display: none;">
                                </div>
                            </div>
                            <div class="form-actions" id="socialFormActions" style="display: none;">
                                <button class="btn btn-primary" id="saveSocialBtn">Guardar</button>
                                <button class="btn btn-outline" id="cancelSocialBtn">Cancelar</button>
                            </div>
                        </div>
                    </div>

                    <!-- Recent Activity Timeline -->
                    <div class="profile-card">
                        <div class="card-header">
                            <h3>Actividad Reciente</h3>
                        </div>
                        <div class="card-body">
                            <div class="activity-timeline" id="activityTimeline">
                                <div class="activity-item">
                                    <div class="activity-icon activity-icon-success">
                                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M20 6L9 17L4 12" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                        </svg>
                                    </div>
                                    <div class="activity-content">
                                        <p class="activity-text">Proyecto completado: <strong>Reparación eléctrica</strong></p>
                                        <span class="activity-time">Hace 2 días</span>
                                    </div>
                                </div>
                                <div class="activity-item">
                                    <div class="activity-icon activity-icon-info">
                                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M21 15C21 15.5304 20.7893 16.0391 20.4142 16.4142C20.0391 16.7893 19.5304 17 19 17H7L3 21V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H19C19.5304 3 20.0391 3.21071 20.4142 3.58579C20.7893 3.96086 21 4.46957 21 5V15Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                        </svg>
                                    </div>
                                    <div class="activity-content">
                                        <p class="activity-text">Nuevo mensaje de <strong>María García</strong></p>
                                        <span class="activity-time">Hace 5 días</span>
                                    </div>
                                </div>
                                <div class="activity-item">
                                    <div class="activity-icon activity-icon-warning">
                                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                        </svg>
                                    </div>
                                    <div class="activity-content">
                                        <p class="activity-text">Reseña enviada: <strong>5 estrellas</strong></p>
                                        <span class="activity-time">Hace 1 semana</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Services Section -->
            <section id="servicesSection" class="dashboard-section">
                <div class="section-header">
                    <h1>Mis Servicios</h1>
                    <button class="edit-btn btn-sm" id="addServiceBtn">
                        <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M9 3V15M3 9H15" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                        </svg>
                        Agregar Servicio
                    </button>
                </div>
                <div class="services-content">
                    <div class="services-list" id="servicesList">
                        <?php
                        $services = get_user_meta(get_current_user_id(), 'services_offered', true);
                        if (empty($services) || (is_array($services) && count($services) === 0)) {
                            echo '<div class="no-data">';
                            echo '<p>Aún no has agregado servicios. Haz clic en "Agregar Servicio" para comenzar.</p>';
                            echo '</div>';
                        } else {
                            $services_array = is_array($services) ? $services : array($services);
                            foreach ($services_array as $index => $service) {
                                if (!empty($service)) {
                                    echo '<div class="service-card" data-service-id="' . esc_attr($index) . '">';
                                    echo '<div class="service-card-content">';
                                    echo '<h3 class="service-name">' . esc_html($service) . '</h3>';
                                    echo '</div>';
                                    echo '<div class="service-card-actions">';
                                    echo '<button class="icon-btn edit-service-btn" data-service-id="' . esc_attr($index) . '" title="Editar servicio">';
                                    echo '<svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">';
                                    echo '<path d="M13.5 2.5L15.5 4.5M14 1L17 4L9 12H6V9L14 1Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>';
                                    echo '</svg>';
                                    echo '</button>';
                                    echo '<button class="icon-btn delete-service-btn" data-service-id="' . esc_attr($index) . '" title="Eliminar servicio">';
                                    echo '<svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">';
                                    echo '<path d="M4.5 4.5L13.5 13.5M13.5 4.5L4.5 13.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>';
                                    echo '</svg>';
                                    echo '</button>';
                                    echo '</div>';
                                    echo '</div>';
                                }
                            }
                        }
                        ?>
                    </div>
                </div>
            </section>
            
            <!-- Add/Edit Service Modal -->
            <div id="serviceModal" class="service-modal" style="display: none;">
                <div class="modal-overlay" id="serviceModalOverlay"></div>
                <div class="modal-content">
                    <div class="modal-header">
                        <h2 id="serviceModalTitle">Agregar Servicio</h2>
                        <button class="modal-close" id="serviceModalClose">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M18 6L6 18M6 6L18 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form id="serviceForm">
                            <div class="form-group">
                                <label for="serviceNameInput">Nombre del Servicio</label>
                                <input type="text" id="serviceNameInput" class="form-input" placeholder="Ej: Instalación eléctrica, Pintura interior, etc." required>
                            </div>
                            <div class="form-actions">
                                <button type="button" class="btn btn-outline" id="cancelServiceBtn">Cancelar</button>
                                <button type="submit" class="btn btn-primary" id="saveServiceBtn">Guardar Servicio</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Messages Section -->
            <section id="messagesSection" class="dashboard-section">
                <div class="section-header">
                    <h1>Mensajes</h1>
                </div>
                <div class="messages-container">
                    <div class="messages-sidebar">
                        <div class="messages-search">
                            <input type="text" placeholder="Buscar conversaciones..." id="messageSearch">
                        </div>
                        <div class="conversations-list" id="conversationsList">
                            <!-- Conversations will be loaded here -->
                            <div class="conversation-item">
                                <div class="conversation-avatar">JD</div>
                                <div class="conversation-info">
                                    <div class="conversation-header">
                                        <span class="conversation-name">Juan Díaz</span>
                                        <span class="conversation-time">Hace 2h</span>
                                    </div>
                                    <p class="conversation-preview">Hola, estoy interesado en tu servicio...</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="messages-chat">
                        <div class="chat-header">
                            <div class="chat-user-info">
                                <div class="chat-avatar">JD</div>
                                <div>
                                    <h3>Juan Díaz</h3>
                                    <p class="chat-status">En línea</p>
                                </div>
                            </div>
                        </div>
                        <div class="chat-messages" id="chatMessages">
                            <div class="message received">
                                <p>Hola, estoy interesado en tu servicio de electricista. ¿Estás disponible?</p>
                                <span class="message-time">10:30 AM</span>
                            </div>
                        </div>
                        <div class="chat-input-container">
                            <button class="attach-btn" id="attachFileBtn" type="button" title="Adjuntar archivo">
                                <i class="fas fa-paperclip"></i>
                            </button>
                            <input type="file" id="messageFileInput" style="display: none;" accept="image/*,.pdf,.doc,.docx">
                            <input type="text" id="messageInput" placeholder="Escribe un mensaje...">
                            <button class="send-btn" id="sendMessageBtn" type="button">
                                <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M18 2L9 11M18 2L12 18L9 11M18 2L2 8L9 11" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                            </button>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Projects Section -->
            <section id="projectsSection" class="dashboard-section">
                <div class="section-header">
                    <h1>Mis Proyectos</h1>
                    <button class="edit-btn btn-sm" id="addProjectBtn">
                        <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M9 3V15M3 9H15" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                        </svg>
                        Agregar Proyecto
                    </button>
                </div>
                <div class="projects-content">
                    <div class="projects-grid" id="projectsGrid">
                        <!-- Projects will be loaded here -->
                        <div class="project-card">
                            <div class="project-header">
                                <h3>Reparación Eléctrica</h3>
                                <span class="project-status status-completed">Completado</span>
                            </div>
                            <p class="project-description">Instalación eléctrica completa en vivienda nueva</p>
                            <div class="project-meta">
                                <span class="project-date">Completado: Hace 2 días</span>
                                <span class="project-client">Cliente: María García</span>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Analytics Section -->
            <section id="analyticsSection" class="dashboard-section">
                <div class="section-header">
                    <h1>Analíticas</h1>
                </div>
                <div class="analytics-content">
                    <div class="analytics-grid">
                        <div class="analytics-card">
                            <div class="analytics-icon analytics-icon-primary">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M2 17L12 22L22 17" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M2 12L12 17L22 12" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                            </div>
                            <div class="analytics-content-info">
                                <h3 class="analytics-value" id="totalViews">0</h3>
                                <p class="analytics-label">Vistas del Perfil</p>
                            </div>
                        </div>
                        <div class="analytics-card">
                            <div class="analytics-icon analytics-icon-success">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M21 15C21 15.5304 20.7893 16.0391 20.4142 16.4142C20.0391 16.7893 19.5304 17 19 17H7L3 21V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H19C19.5304 3 20.0391 3.21071 20.4142 3.58579C20.7893 3.96086 21 4.46957 21 5V15Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                            </div>
                            <div class="analytics-content-info">
                                <h3 class="analytics-value" id="totalMessagesAnalytics">0</h3>
                                <p class="analytics-label">Mensajes Recibidos</p>
                            </div>
                        </div>
                        <div class="analytics-card">
                            <div class="analytics-icon analytics-icon-warning">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                            </div>
                            <div class="analytics-content-info">
                                <h3 class="analytics-value" id="averageRatingAnalytics">0.0</h3>
                                <p class="analytics-label">Calificación Promedio</p>
                            </div>
                        </div>
                        <div class="analytics-card">
                            <div class="analytics-icon analytics-icon-info">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M12 2C6.48 2 2 6.48 2 12C2 17.52 6.48 22 12 22C17.52 22 22 17.52 22 12C22 6.48 17.52 2 12 2ZM13 17H11V15H13V17ZM13 13H11V7H13V13Z" fill="currentColor"/>
                                </svg>
                            </div>
                            <div class="analytics-content-info">
                                <h3 class="analytics-value" id="totalProjectsAnalytics">0</h3>
                                <p class="analytics-label">Proyectos Completados</p>
                            </div>
                        </div>
                    </div>
                    <div class="analytics-charts">
                        <div class="chart-card">
                            <h3>Vistas del Perfil (Últimos 30 días)</h3>
                            <div class="chart-placeholder">
                                <p class="no-data">Gráfico de vistas próximamente</p>
                            </div>
                        </div>
                        <div class="chart-card">
                            <h3>Mensajes Recibidos (Últimos 30 días)</h3>
                            <div class="chart-placeholder">
                                <p class="no-data">Gráfico de mensajes próximamente</p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Reviews Section -->
            <section id="reviewsSection" class="dashboard-section">
                <div class="section-header">
                    <h1>Reseñas Recibidas</h1>
                </div>
                <div class="reviews-content">
                    <div class="reviews-summary">
                        <div class="rating-display">
                            <div class="rating-stars-large" id="averageRating">
                                <svg width="32" height="32" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="#FFD700"/>
                                </svg>
                                <span class="rating-value-large">4.5</span>
                            </div>
                            <p class="rating-count">Basado en 12 reseñas</p>
                        </div>
                    </div>
                    <div class="reviews-list" id="reviewsList">
                        <!-- Reviews will be loaded here -->
                        <div class="review-card">
                            <div class="review-header">
                                <div class="reviewer-info">
                                    <div class="reviewer-avatar">JD</div>
                                    <div>
                                        <h4>Juan Díaz</h4>
                                        <div class="review-rating editable-rating" data-rating="5">
                                            <svg width="16" height="16" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" class="star filled">
                                                <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="#FFD700"/>
                                            </svg>
                                            <svg width="16" height="16" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" class="star filled">
                                                <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="#FFD700"/>
                                            </svg>
                                            <svg width="16" height="16" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" class="star filled">
                                                <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="#FFD700"/>
                                            </svg>
                                            <svg width="16" height="16" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" class="star filled">
                                                <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="#FFD700"/>
                                            </svg>
                                            <svg width="16" height="16" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" class="star filled">
                                                <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="#FFD700"/>
                                            </svg>
                                        </div>
                                    </div>
                                </div>
                                <button class="icon-btn edit-review-btn">
                                    <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M13.5 2.5L15.5 4.5M14 1L17 4L9 12H6V9L14 1Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                            </div>
                            <p class="review-text">Excelente trabajo, muy profesional y puntual. Recomiendo totalmente.</p>
                            <span class="review-date">Hace 3 días</span>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Notifications Section -->
            <section id="notificationsSection" class="dashboard-section">
                <div class="section-header">
                    <h1>Notificaciones</h1>
                    <button class="edit-btn btn-sm" id="markAllReadBtn">
                        Marcar todas como leídas
                    </button>
                </div>
                <div class="notifications-content">
                    <div class="notifications-list" id="notificationsList">
                        <div class="notification-item unread">
                            <div class="notification-icon notification-icon-info">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M21 15C21 15.5304 20.7893 16.0391 20.4142 16.4142C20.0391 16.7893 19.5304 17 19 17H7L3 21V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H19C19.5304 3 20.0391 3.21071 20.4142 3.58579C20.7893 3.96086 21 4.46957 21 5V15Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                            </div>
                            <div class="notification-content">
                                <h4>Nuevo mensaje recibido</h4>
                                <p>María García te ha enviado un mensaje sobre tu proyecto</p>
                                <span class="notification-time">Hace 2 horas</span>
                            </div>
                            <div class="notification-dot"></div>
                        </div>
                        <div class="notification-item unread">
                            <div class="notification-icon notification-icon-warning">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                            </div>
                            <div class="notification-content">
                                <h4>Nueva reseña recibida</h4>
                                <p>Has recibido una reseña de 5 estrellas de Juan Díaz</p>
                                <span class="notification-time">Hace 1 día</span>
                            </div>
                            <div class="notification-dot"></div>
                        </div>
                        <div class="notification-item unread">
                            <div class="notification-icon notification-icon-success">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M20 6L9 17L4 12" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                            </div>
                            <div class="notification-content">
                                <h4>Proyecto completado</h4>
                                <p>Tu proyecto "Reparación Eléctrica" ha sido marcado como completado</p>
                                <span class="notification-time">Hace 2 días</span>
                            </div>
                            <div class="notification-dot"></div>
                        </div>
                        <div class="notification-item">
                            <div class="notification-icon notification-icon-info">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M12 2V6M12 18V22M6 12H2M22 12H18M19.07 19.07L16.24 16.24M19.07 4.93L16.24 7.76M4.93 19.07L7.76 16.24M4.93 4.93L7.76 7.76" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                            </div>
                            <div class="notification-content">
                                <h4>Perfil actualizado</h4>
                                <p>Tu perfil ha sido visto 10 veces esta semana</p>
                                <span class="notification-time">Hace 3 días</span>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Settings Section -->
            <section id="settingsSection" class="dashboard-section">
                <div class="section-header">
                    <h1>Configuración</h1>
                </div>
                <div class="settings-content">
                    <div class="profile-card">
                        <div class="card-header">
                            <h3>Preferencias de Notificaciones</h3>
                        </div>
                        <div class="card-body">
                            <div class="settings-item">
                                <div class="settings-label">
                                    <label>Notificaciones por Email</label>
                                    <p class="settings-description">Recibe notificaciones importantes por correo electrónico</p>
                                </div>
                                <label class="toggle-switch">
                                    <input type="checkbox" checked>
                                    <span class="toggle-slider"></span>
                                </label>
                            </div>
                            <div class="settings-item">
                                <div class="settings-label">
                                    <label>Notificaciones de Mensajes</label>
                                    <p class="settings-description">Recibe alertas cuando recibas nuevos mensajes</p>
                                </div>
                                <label class="toggle-switch">
                                    <input type="checkbox" checked>
                                    <span class="toggle-slider"></span>
                                </label>
                            </div>
                            <div class="settings-item">
                                <div class="settings-label">
                                    <label>Notificaciones de Reseñas</label>
                                    <p class="settings-description">Recibe notificaciones cuando recibas nuevas reseñas</p>
                                </div>
                                <label class="toggle-switch">
                                    <input type="checkbox" checked>
                                    <span class="toggle-slider"></span>
                                </label>
                            </div>
                        </div>
                    </div>

                    <div class="profile-card">
                        <div class="card-header">
                            <h3>Privacidad</h3>
                        </div>
                        <div class="card-body">
                            <div class="settings-item">
                                <div class="settings-label">
                                    <label>Perfil Público</label>
                                    <p class="settings-description">Permite que otros usuarios vean tu perfil</p>
                                </div>
                                <label class="toggle-switch">
                                    <input type="checkbox" checked>
                                    <span class="toggle-slider"></span>
                                </label>
                            </div>
                            <div class="settings-item">
                                <div class="settings-label">
                                    <label>Mostrar Email</label>
                                    <p class="settings-description">Permite que otros usuarios vean tu correo electrónico</p>
                                </div>
                                <label class="toggle-switch">
                                    <input type="checkbox">
                                    <span class="toggle-slider"></span>
                                </label>
                            </div>
                        </div>
                    </div>

                    <div class="profile-card danger-zone">
                        <div class="card-header">
                            <h3>Zona de Peligro</h3>
                        </div>
                        <div class="card-body">
                            <div class="danger-actions">
                                <button class="btn btn-outline btn-danger">
                                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M3 6H5H21M8 6V4C8 3.46957 8.21071 2.96086 8.58579 2.58579C8.96086 2.21071 9.46957 2 10 2H14C14.5304 2 15.0391 2.21071 15.4142 2.58579C15.7893 2.96086 16 3.46957 16 4V6M19 6V20C19 20.5304 18.7893 21.0391 18.4142 21.4142C18.0391 21.7893 17.5304 22 17 22H7C6.46957 22 5.96086 21.7893 5.58579 21.4142C5.21071 21.0391 5 20.5304 5 20V6H19Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                    Eliminar Cuenta
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</main>

<!-- Add Review Modal -->
<div id="addReviewModal" class="access-modal">
    <div class="modal-overlay" onclick="closeAddReviewModal()"></div>
    <div class="modal-content access-modal-content">
        <button class="modal-close" onclick="closeAddReviewModal()">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M18 6L6 18M6 6L18 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
        </button>
        <div class="modal-body">
            <h2 class="modal-title">Agregar Reseña</h2>
            <form id="addReviewForm" class="access-form">
                <div class="form-group">
                    <label>Calificación</label>
                    <div class="rating-input" id="ratingInput">
                        <svg width="32" height="32" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" class="rating-star" data-rating="1">
                            <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="#E5E5E5"/>
                        </svg>
                        <svg width="32" height="32" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" class="rating-star" data-rating="2">
                            <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="#E5E5E5"/>
                        </svg>
                        <svg width="32" height="32" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" class="rating-star" data-rating="3">
                            <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="#E5E5E5"/>
                        </svg>
                        <svg width="32" height="32" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" class="rating-star" data-rating="4">
                            <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="#E5E5E5"/>
                        </svg>
                        <svg width="32" height="32" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" class="rating-star" data-rating="5">
                            <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="#E5E5E5"/>
                        </svg>
                    </div>
                    <input type="hidden" id="selectedRating" name="rating" value="0">
                </div>
                <div class="form-group">
                    <label for="reviewText">Comentario</label>
                    <textarea id="reviewText" name="review" rows="5" placeholder="Escribe tu reseña aquí..."></textarea>
                </div>
                <button type="submit" class="btn btn-primary form-submit">Publicar Reseña</button>
            </form>
        </div>
    </div>
</div>

<script>
// Simple Navigation System - Direct Implementation
(function() {
    'use strict';
    
    function initNavigation() {
        const navItems = document.querySelectorAll('.nav-item');
        const sections = document.querySelectorAll('.dashboard-section');
        const mobileMenuToggle = document.getElementById('mobileMenuToggle');
        const dashboardSidebar = document.getElementById('dashboardSidebar');
        
        // Mobile menu toggle
        const sidebarOverlay = document.getElementById('sidebarOverlay');
        const sidebarCloseMobile = document.getElementById('sidebarCloseMobile');
        
        function closeMobileMenu() {
            if (dashboardSidebar) {
                dashboardSidebar.classList.remove('mobile-open');
            }
            if (sidebarOverlay) {
                sidebarOverlay.classList.remove('active');
            }
            // Enable body scroll
            document.body.style.overflow = '';
        }
        
        function openMobileMenu() {
            if (dashboardSidebar) {
                dashboardSidebar.classList.add('mobile-open');
            }
            if (sidebarOverlay) {
                sidebarOverlay.classList.add('active');
            }
            // Disable body scroll when sidebar is open
            document.body.style.overflow = 'hidden';
        }
        
        if (mobileMenuToggle && dashboardSidebar) {
            // Ensure sidebar is closed on page load for mobile
            if (window.innerWidth <= 767) {
                closeMobileMenu();
            }
            
            mobileMenuToggle.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                if (dashboardSidebar.classList.contains('mobile-open')) {
                    closeMobileMenu();
                } else {
                    openMobileMenu();
                }
            });
            
            // Close sidebar when clicking overlay
            if (sidebarOverlay) {
                sidebarOverlay.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    closeMobileMenu();
                });
            }
            
            // Close sidebar when clicking close button
            if (sidebarCloseMobile) {
                sidebarCloseMobile.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    closeMobileMenu();
                });
            }
            
            // Close sidebar when clicking nav items on mobile
            navItems.forEach(item => {
                item.addEventListener('click', function() {
                    if (window.innerWidth <= 767) {
                        setTimeout(() => {
                            closeMobileMenu();
                        }, 300);
                    }
                });
            });
            
            // Handle window resize
            let resizeTimer;
            window.addEventListener('resize', function() {
                clearTimeout(resizeTimer);
                resizeTimer = setTimeout(function() {
                    if (window.innerWidth > 767) {
                        // Desktop view - ensure sidebar is visible
                        closeMobileMenu();
                        dashboardSidebar.classList.remove('mobile-open');
                        if (sidebarOverlay) {
                            sidebarOverlay.classList.remove('active');
                        }
                        document.body.style.overflow = '';
                    } else {
                        // Mobile view - ensure sidebar is hidden by default
                        if (!dashboardSidebar.classList.contains('mobile-open')) {
                            closeMobileMenu();
                        }
                    }
                }, 250);
            });
        }
        
        if (navItems.length === 0 || sections.length === 0) {
            console.log('Navigation elements not found, retrying...');
            setTimeout(initNavigation, 500);
            return;
        }
        
        console.log('Navigation initialized:', navItems.length, 'items,', sections.length, 'sections');
        
        function showSection(sectionName) {
            // Hide all sections
            sections.forEach(section => {
                section.classList.remove('active');
                section.style.display = 'none';
            });
            
            // Remove active from all nav items
            navItems.forEach(item => {
                item.classList.remove('active');
            });
            
            // Show target section
            const targetSection = document.getElementById(sectionName + 'Section');
            const targetNav = document.querySelector('[data-section="' + sectionName + '"]');
            
            if (targetSection) {
                targetSection.classList.add('active');
                targetSection.style.display = 'block';
                console.log('Showing section:', sectionName);
            }
            
            if (targetNav) {
                targetNav.classList.add('active');
            }
            
            // Scroll to top
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }
        
        // Add click handlers
        navItems.forEach(item => {
            item.addEventListener('click', function(e) {
                e.preventDefault();
                const section = this.getAttribute('data-section');
                if (section) {
                    showSection(section);
                }
            });
        });

        // Also handle any .nav-link elements (e.g., "Ver todo el perfil →")
        const navLinks = document.querySelectorAll('.nav-link');
        navLinks.forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                const section = this.getAttribute('data-section');
                if (section) {
                    showSection(section);
                }
            });
        });
        
        // Handle hash changes
        window.addEventListener('hashchange', function() {
            const hash = window.location.hash.replace('#', '');
            if (hash) {
                showSection(hash);
            }
        });
        
        // Initial section from hash or default
        const hash = window.location.hash.replace('#', '');
        if (hash) {
            showSection(hash);
        }
    }
    
    // Initialize when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initNavigation);
    } else {
        initNavigation();
    }
    
    // Also try after a short delay as fallback
    setTimeout(initNavigation, 100);
})();

// Profile Editing Functionality - Direct Implementation
(function() {
    'use strict';
    
    function initProfileEditing() {
        // Check if nidfilAjax is available
        if (typeof nidfilAjax === 'undefined') {
            console.log('nidfilAjax not available, retrying...');
            setTimeout(initProfileEditing, 200);
            return;
        }
        
        console.log('Initializing profile editing...');
        
        // Bio Edit Functionality
        const editBioBtn = document.getElementById('editBioBtn');
        const bioText = document.getElementById('bioText');
        const bioEditForm = document.getElementById('bioEditForm');
        const bioTextarea = document.getElementById('bioTextarea');
        const saveBioBtn = document.getElementById('saveBioBtn');
        const cancelBioBtn = document.getElementById('cancelBioBtn');
        
        if (editBioBtn && bioText && bioEditForm && bioTextarea) {
            editBioBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                const currentBio = bioText.textContent.trim();
                const defaultText = 'You haven\'t added a biography yet. Click edit to add one.';
                const defaultTextEs = 'Aún no has agregado una biografía. Haz clic en editar para agregar una.';
                
                bioText.style.display = 'none';
                bioEditForm.style.display = 'block';
                
                if (currentBio !== defaultText && currentBio !== defaultTextEs) {
                    bioTextarea.value = currentBio;
                } else {
                    bioTextarea.value = '';
                }
                bioTextarea.focus();
            });
        }
        
        if (saveBioBtn && bioTextarea) {
            saveBioBtn.addEventListener('click', async function(e) {
                e.preventDefault();
                e.stopPropagation();
                const newBio = bioTextarea.value.trim();
                
                const originalText = saveBioBtn.textContent || 'Save';
                saveBioBtn.disabled = true;
                saveBioBtn.textContent = 'Saving...';

                try {
                    const response = await fetch(nidfilAjax.ajaxurl, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                        body: new URLSearchParams({
                            action: 'nidfil_save_bio',
                            bio: newBio,
                            nonce: nidfilAjax.nonce
                        })
                    });

                    const data = await response.json();

                    if (data && data.success) {
                        bioText.textContent = newBio || 'You haven\'t added a biography yet. Click edit to add one.';
                        bioText.style.display = 'block';
                        bioEditForm.style.display = 'none';
                        updateProfileCompletion();
                    } else {
                        console.error('Error saving biography:', data && data.data && data.data.message ? data.data.message : 'Unknown error');
                    }
                } catch (error) {
                    console.error('Error:', error);
                } finally {
                    saveBioBtn.disabled = false;
                    saveBioBtn.textContent = originalText;
                }
            });
        }
        
        if (cancelBioBtn) {
            cancelBioBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                bioText.style.display = 'block';
                bioEditForm.style.display = 'none';
            });
        }
        
        // Profile Image Upload Functionality
        let editImageBtn = document.getElementById('editImageBtn');
        let profileImageInput = document.getElementById('profileImageInput');
        const profileImage = document.getElementById('profileImage');
        const imageUploadActions = document.getElementById('imageUploadActions');
        const saveImageBtn = document.getElementById('saveImageBtn');
        const cancelImageBtn = document.getElementById('cancelImageBtn');
        const imageStatus = document.getElementById('imageStatus');
        const completionFill = document.getElementById('completionFill');
        const completionBadge = document.getElementById('completionPercentage');
        
        let selectedImageFile = null;
        let originalImageSrc = profileImage ? profileImage.src : '';
        
        const allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
        const maxSize = 5 * 1024 * 1024; // 5MB

        function setImageStatus(message, type = 'info') {
            if (!imageStatus) return;
            
            // Always hide on empty message
            if (!message) {
                imageStatus.classList.remove('info', 'success', 'error');
                imageStatus.textContent = '';
                imageStatus.style.display = 'none';
                return;
            }
            
            // Only show text for errors; otherwise keep hidden
            if (type !== 'error') {
                imageStatus.classList.remove('info', 'success', 'error');
                imageStatus.textContent = '';
                imageStatus.style.display = 'none';
                return;
            }
            
            // Show error message
            imageStatus.classList.remove('info', 'success', 'error');
            imageStatus.classList.add('error');
            imageStatus.textContent = message;
            imageStatus.style.display = 'flex';
        }
        
        function isFilledValue(val) {
            if (!val) return false;
            const trimmed = val.trim();
            if (!trimmed) return false;
            const defaults = ['Not added', 'No agregado'];
            return !defaults.includes(trimmed);
        }
        
        function updateProfileCompletion() {
            let completed = 0;
            const totalSteps = 8; // Increased for specialist fields
            
            // Image completed: consider non-gravatar URL as filled
            let imageComplete = false;
            if (profileImage && profileImage.src) {
                const src = profileImage.src.toLowerCase();
                imageComplete = !(src.includes('gravatar.com') || src.includes('d=mm'));
            }
            if (imageComplete) completed += 1;
            
            // Bio completed: not default/empty
            let bioComplete = false;
            if (bioText) {
                const txt = bioText.textContent.trim();
                const defaults = [
                    "You haven't added a biography yet. Click edit to add one.",
                    'Aún no has agregado una biografía. Haz clic en editar para agregar una.'
                ];
                bioComplete = txt && !defaults.includes(txt);
            }
            if (bioComplete) completed += 1;
            
            // Personal info completed: all fields filled
            const fullNameVal = document.getElementById('fullNameValue')?.textContent || '';
            const emailVal = document.getElementById('emailValue')?.textContent || '';
            const phoneVal = document.getElementById('phoneValue')?.textContent || '';
            const locationVal = document.getElementById('locationValue')?.textContent || '';
            const personalComplete = [fullNameVal, emailVal, phoneVal, locationVal].every(isFilledValue);
            if (personalComplete) completed += 1;
            
            // Professional info completed (specialist-specific)
            const professionVal = document.getElementById('professionValue')?.textContent || '';
            const experienceVal = document.getElementById('experienceValue')?.textContent || '';
            if (isFilledValue(professionVal)) completed += 1;
            if (isFilledValue(experienceVal)) completed += 1;
            
            // Certifications completed (specialist-specific)
            const certificationsList = document.getElementById('certificationsList');
            if (certificationsList && certificationsList.querySelectorAll('.certification-item').length > 0) {
                completed += 1;
            }
            
            // Social complete: at least one link filled
            const socialVals = ['facebookValue', 'twitterValue', 'instagramValue', 'linkedinValue']
                .map(id => document.getElementById(id)?.textContent || '');
            const socialComplete = socialVals.some(isFilledValue);
            if (socialComplete) completed += 1;
            
            const percent = Math.round((completed / totalSteps) * 100);
            if (completionFill) {
                completionFill.style.width = `${percent}%`;
            }
            if (completionBadge) {
                completionBadge.textContent = `${percent}%`;
            }
        }

        // Ensure actions/status are hidden on load
        if (imageUploadActions) {
            imageUploadActions.style.display = 'none';
        }
        setImageStatus('', 'info');
        updateProfileCompletion();

        // Remove any prior listeners (e.g., from main.js) by cloning elements
        if (editImageBtn) {
            const clonedBtn = editImageBtn.cloneNode(true);
            editImageBtn.parentNode.replaceChild(clonedBtn, editImageBtn);
            editImageBtn = clonedBtn;
        }
        if (profileImageInput) {
            const clonedInput = profileImageInput.cloneNode(true);
            profileImageInput.parentNode.replaceChild(clonedInput, profileImageInput);
            profileImageInput = clonedInput;
        }

        if (editImageBtn && profileImageInput) {
            editImageBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                // Reset input so selecting the same file triggers change
                profileImageInput.value = '';
                selectedImageFile = null;
                setImageStatus('', 'info');
                profileImageInput.click();
            });
            
            profileImageInput.addEventListener('change', function(e) {
                const file = e.target.files[0];
                if (file) {
                    // Validate file type
                    if (!allowedTypes.includes(file.type)) {
                        setImageStatus('Formato no válido. Usa JPG, PNG, WEBP o GIF.', 'error');
                        profileImageInput.value = '';
                        return;
                    }
                    
                    // Validate file size (max 5MB)
                    if (file.size > maxSize) {
                        setImageStatus('La imagen es demasiado grande. Máx 5MB.', 'error');
                        profileImageInput.value = '';
                        return;
                    }
                    
                    selectedImageFile = file;
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        if (profileImage) {
                            profileImage.src = e.target.result;
                        }
                        // Show save/cancel buttons with smooth animation
                        if (imageUploadActions) {
                            imageUploadActions.classList.add('show');
                            setImageStatus('', 'info');
                            // Force reflow to trigger animation
                            imageUploadActions.offsetHeight;
                        }
                    };
                    reader.readAsDataURL(file);
                }
            });
        }
        
        // Save image
        if (saveImageBtn) {
            saveImageBtn.addEventListener('click', async function(e) {
                e.preventDefault();
                e.stopPropagation();
                
                if (!selectedImageFile) {
                    setImageStatus('Primero selecciona una imagen.', 'error');
                    return;
                }
                
                const originalText = saveImageBtn.innerHTML;
                saveImageBtn.disabled = true;
                saveImageBtn.innerHTML = '<svg width="16" height="16" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="10" cy="10" r="8" stroke="currentColor" stroke-width="2"/><path d="M10 6V10L13 13" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg> Guardando...';
                
                try {
                    // Create FormData for file upload
                    const formData = new FormData();
                    formData.append('action', 'nidfil_save_profile_image');
                    formData.append('profile_image', selectedImageFile);
                    formData.append('nonce', nidfilAjax.nonce);
                    
                    // Upload image via AJAX
                    const response = await fetch(nidfilAjax.ajaxurl, {
                        method: 'POST',
                        body: formData
                    });
                    
                    const data = await response.json();
                    
                    if (data && data.success) {
                        // Update image source if new URL provided
                        if (data.data && data.data.image_url) {
                            profileImage.src = data.data.image_url + '?t=' + new Date().getTime();
                        }
                        // Hide save/cancel buttons with smooth animation
                        if (imageUploadActions) {
                            imageUploadActions.classList.remove('show');
                            setTimeout(() => {
                                if (imageUploadActions && !imageUploadActions.classList.contains('show')) {
                                    imageUploadActions.style.display = 'none';
                                }
                            }, 300);
                        }
                        // Reset file input
                        profileImageInput.value = '';
                        selectedImageFile = null;
                        originalImageSrc = profileImage.src;
                        
                        // No inline text needed on success; just hide the bar shortly after
                        setTimeout(() => {
                            setImageStatus('', 'info');
                            if (imageUploadActions) {
                                imageUploadActions.classList.remove('show');
                                imageUploadActions.style.display = 'none';
                            }
                            updateProfileCompletion();
                        }, 400);
                    } else {
                        const errorMsg = data && data.data && data.data.message ? data.data.message : 'Error al guardar la imagen.';
                        setImageStatus(errorMsg, 'error');
                        // Restore original image
                        if (profileImage) {
                            profileImage.src = originalImageSrc;
                        }
                    }
                } catch (error) {
                    console.error('Error:', error);
                    setImageStatus('Error al guardar la imagen. Por favor, intenta de nuevo.', 'error');
                    // Restore original image
                    if (profileImage) {
                        profileImage.src = originalImageSrc;
                    }
                } finally {
                    saveImageBtn.disabled = false;
                    saveImageBtn.innerHTML = originalText;
                }
            });
        }
        
        // Cancel image upload
        if (cancelImageBtn) {
            cancelImageBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                // Restore original image
                if (profileImage && originalImageSrc) {
                    profileImage.src = originalImageSrc;
                }
                // Hide save/cancel buttons with smooth animation
                if (imageUploadActions) {
                    imageUploadActions.classList.remove('show');
                    setTimeout(() => {
                        if (imageUploadActions && !imageUploadActions.classList.contains('show')) {
                            imageUploadActions.style.display = 'none';
                        }
                    }, 300);
                }
                // Reset file input
                if (profileImageInput) {
                    profileImageInput.value = '';
                }
                selectedImageFile = null;
                setImageStatus('', 'info');
            });
        }
        
        // Personal Information Edit
        const editInfoBtn = document.getElementById('editInfoBtn');
        const infoFormActions = document.getElementById('infoFormActions');
        const saveInfoBtn = document.getElementById('saveInfoBtn');
        const cancelInfoBtn = document.getElementById('cancelInfoBtn');
        
        const infoFields = {
            fullName: { value: 'fullNameValue', input: 'fullNameInput' },
            email: { value: 'emailValue', input: 'emailInput' },
            phone: { value: 'phoneValue', input: 'phoneInput' },
            location: { value: 'locationValue', input: 'locationInput' }
        };
        
        if (editInfoBtn) {
            editInfoBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                Object.keys(infoFields).forEach(key => {
                    const valueEl = document.getElementById(infoFields[key].value);
                    const inputEl = document.getElementById(infoFields[key].input);
                    if (valueEl && inputEl) {
                        valueEl.style.display = 'none';
                        inputEl.style.display = 'block';
                        const currentValue = valueEl.textContent.trim();
                        if (!inputEl.value && currentValue !== 'Not added' && currentValue !== 'No agregado') {
                            inputEl.value = currentValue;
                        }
                    }
                });
                if (infoFormActions) {
                    infoFormActions.style.display = 'flex';
                }
            });
        }
        
        if (saveInfoBtn) {
            saveInfoBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                const data = {};
                
                Object.keys(infoFields).forEach(key => {
                    const inputEl = document.getElementById(infoFields[key].input);
                    if (inputEl) {
                        data[key] = inputEl.value.trim();
                    }
                });
                
                const originalText = saveInfoBtn.textContent;
                saveInfoBtn.disabled = true;
                saveInfoBtn.textContent = 'Guardando...';
                
                fetch(nidfilAjax.ajaxurl, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: new URLSearchParams({
                        action: 'nidfil_save_personal_info',
                        full_name: data.fullName || '',
                        email: data.email || '',
                        phone: data.phone || '',
                        location: data.location || '',
                        nonce: nidfilAjax.nonce
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        Object.keys(infoFields).forEach(key => {
                            const inputEl = document.getElementById(infoFields[key].input);
                            const valueEl = document.getElementById(infoFields[key].value);
                            if (inputEl && valueEl) {
                                const value = inputEl.value.trim();
                                valueEl.textContent = value || 'Not added';
                                valueEl.style.display = 'block';
                                inputEl.style.display = 'none';
                            }
                        });
                        
                        if (infoFormActions) {
                            infoFormActions.style.display = 'none';
                        }
                        
                        const fullNameInput = document.getElementById('fullNameInput');
                        if (fullNameInput) {
                            const profileName = document.getElementById('profileName');
                            if (profileName) {
                                profileName.textContent = fullNameInput.value.trim();
                            }
                        }
                        
                        updateProfileCompletion();
                    } else {
                        console.error('Error saving information:', data.data && data.data.message ? data.data.message : 'Unknown error');
                    }
                    saveInfoBtn.disabled = false;
                    saveInfoBtn.textContent = originalText;
                })
                .catch(error => {
                    console.error('Error:', error);
                    saveInfoBtn.disabled = false;
                    saveInfoBtn.textContent = originalText;
                });
            });
        }
        
        if (cancelInfoBtn) {
            cancelInfoBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                Object.keys(infoFields).forEach(key => {
                    const valueEl = document.getElementById(infoFields[key].value);
                    const inputEl = document.getElementById(infoFields[key].input);
                    if (valueEl && inputEl) {
                        valueEl.style.display = 'block';
                        inputEl.style.display = 'none';
                    }
                });
                if (infoFormActions) {
                    infoFormActions.style.display = 'none';
                }
            });
        }
        
        // Social Media Edit Functionality
        const editSocialBtn = document.getElementById('editSocialBtn');
        const socialFormActions = document.getElementById('socialFormActions');
        const saveSocialBtn = document.getElementById('saveSocialBtn');
        const cancelSocialBtn = document.getElementById('cancelSocialBtn');
        
        const socialFields = {
            facebook: { value: 'facebookValue', input: 'facebookInput' },
            twitter: { value: 'twitterValue', input: 'twitterInput' },
            instagram: { value: 'instagramValue', input: 'instagramInput' },
            linkedin: { value: 'linkedinValue', input: 'linkedinInput' }
        };
        
        if (editSocialBtn) {
            editSocialBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                Object.keys(socialFields).forEach(key => {
                    const valueEl = document.getElementById(socialFields[key].value);
                    const inputEl = document.getElementById(socialFields[key].input);
                    if (valueEl && inputEl) {
                        valueEl.style.display = 'none';
                        inputEl.style.display = 'block';
                        const currentValue = valueEl.textContent.trim();
                        if (!inputEl.value && currentValue !== 'Not added' && currentValue !== 'No agregado') {
                            inputEl.value = currentValue;
                        }
                    }
                });
                if (socialFormActions) {
                    socialFormActions.style.display = 'flex';
                }
            });
        }
        
        if (saveSocialBtn) {
            saveSocialBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                const data = {};
                
                Object.keys(socialFields).forEach(key => {
                    const inputEl = document.getElementById(socialFields[key].input);
                    if (inputEl) {
                        data[key] = inputEl.value.trim();
                    }
                });
                
                const originalText = saveSocialBtn.textContent;
                saveSocialBtn.disabled = true;
                saveSocialBtn.textContent = 'Guardando...';
                
                fetch(nidfilAjax.ajaxurl, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: new URLSearchParams({
                        action: 'nidfil_save_social_links',
                        facebook: data.facebook || '',
                        twitter: data.twitter || '',
                        instagram: data.instagram || '',
                        linkedin: data.linkedin || '',
                        nonce: nidfilAjax.nonce
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        Object.keys(socialFields).forEach(key => {
                            const inputEl = document.getElementById(socialFields[key].input);
                            const valueEl = document.getElementById(socialFields[key].value);
                            if (inputEl && valueEl) {
                                const value = inputEl.value.trim();
                                valueEl.textContent = value || 'Not added';
                                valueEl.style.display = 'block';
                                inputEl.style.display = 'none';
                            }
                        });
                        if (socialFormActions) {
                            socialFormActions.style.display = 'none';
                        }
                        updateProfileCompletion();
                    } else {
                        console.error('Error saving social links:', data.data && data.data.message ? data.data.message : 'Unknown error');
                    }
                    saveSocialBtn.disabled = false;
                    saveSocialBtn.textContent = originalText;
                })
                .catch(error => {
                    console.error('Error:', error);
                    saveSocialBtn.disabled = false;
                    saveSocialBtn.textContent = originalText;
                });
            });
        }
        
        if (cancelSocialBtn) {
            cancelSocialBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                Object.keys(socialFields).forEach(key => {
                    const valueEl = document.getElementById(socialFields[key].value);
                    const inputEl = document.getElementById(socialFields[key].input);
                    if (valueEl && inputEl) {
                        valueEl.style.display = 'block';
                        inputEl.style.display = 'none';
                    }
                });
                if (socialFormActions) {
                    socialFormActions.style.display = 'none';
                }
            });
        }
        
        // Professional Information Edit (Specialist)
        const editProfessionalBtn = document.getElementById('editProfessionalBtn');
        const professionalFormActions = document.getElementById('professionalFormActions');
        const saveProfessionalBtn = document.getElementById('saveProfessionalBtn');
        const cancelProfessionalBtn = document.getElementById('cancelProfessionalBtn');
        
        const professionalFields = {
            profession: { value: 'professionValue', input: 'professionInput' },
            experience: { value: 'experienceValue', input: 'experienceInput' },
            serviceArea: { value: 'serviceAreaValue', input: 'serviceAreaInput' },
            languages: { value: 'languagesValue', input: 'languagesInput' }
        };
        
        if (editProfessionalBtn) {
            editProfessionalBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                Object.keys(professionalFields).forEach(key => {
                    const valueEl = document.getElementById(professionalFields[key].value);
                    const inputEl = document.getElementById(professionalFields[key].input);
                    if (valueEl && inputEl) {
                        valueEl.style.display = 'none';
                        inputEl.style.display = 'block';
                        const currentValue = valueEl.textContent.trim();
                        if (!inputEl.value && currentValue !== 'Not added' && currentValue !== 'No agregado') {
                            inputEl.value = currentValue;
                        }
                    }
                });
                if (professionalFormActions) {
                    professionalFormActions.style.display = 'flex';
                }
            });
        }
        
        if (saveProfessionalBtn) {
            saveProfessionalBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                const data = {};
                
                Object.keys(professionalFields).forEach(key => {
                    const inputEl = document.getElementById(professionalFields[key].input);
                    if (inputEl) {
                        data[key] = inputEl.value.trim();
                    }
                });
                
                const originalText = saveProfessionalBtn.textContent;
                saveProfessionalBtn.disabled = true;
                saveProfessionalBtn.textContent = 'Guardando...';
                
                fetch(nidfilAjax.ajaxurl, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: new URLSearchParams({
                        action: 'nidfil_save_professional_info',
                        profession: data.profession || '',
                        experience: data.experience || '',
                        service_area: data.serviceArea || '',
                        languages: data.languages || '',
                        nonce: nidfilAjax.nonce
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        Object.keys(professionalFields).forEach(key => {
                            const inputEl = document.getElementById(professionalFields[key].input);
                            const valueEl = document.getElementById(professionalFields[key].value);
                            if (inputEl && valueEl) {
                                const value = inputEl.value.trim();
                                valueEl.textContent = value || 'Not added';
                                valueEl.style.display = 'block';
                                inputEl.style.display = 'none';
                            }
                        });
                        if (professionalFormActions) {
                            professionalFormActions.style.display = 'none';
                        }
                        updateProfileCompletion();
                    }
                    saveProfessionalBtn.disabled = false;
                    saveProfessionalBtn.textContent = originalText;
                })
                .catch(error => {
                    console.error('Error:', error);
                    saveProfessionalBtn.disabled = false;
                    saveProfessionalBtn.textContent = originalText;
                });
            });
        }
        
        if (cancelProfessionalBtn) {
            cancelProfessionalBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                Object.keys(professionalFields).forEach(key => {
                    const valueEl = document.getElementById(professionalFields[key].value);
                    const inputEl = document.getElementById(professionalFields[key].input);
                    if (valueEl && inputEl) {
                        valueEl.style.display = 'block';
                        inputEl.style.display = 'none';
                    }
                });
                if (professionalFormActions) {
                    professionalFormActions.style.display = 'none';
                }
            });
        }
        
        // Verification Requirement Edit
        const editVerificationBtn = document.getElementById('editVerificationBtn');
        const verificationFormActions = document.getElementById('verificationFormActions');
        const saveVerificationBtn = document.getElementById('saveVerificationBtn');
        const cancelVerificationBtn = document.getElementById('cancelVerificationBtn');
        const verificationError = document.getElementById('verificationError');
        
        const verificationFields = {
            autonomousWorker: { value: 'autonomousWorkerValue', input: 'autonomousWorkerInput' },
            cif: { value: 'cifValue', input: 'cifInput' },
            registeredCompany: { value: 'registeredCompanyValue', input: 'registeredCompanyInput' }
        };
        
        if (editVerificationBtn) {
            editVerificationBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                Object.keys(verificationFields).forEach(key => {
                    const valueEl = document.getElementById(verificationFields[key].value);
                    const inputEl = document.getElementById(verificationFields[key].input);
                    if (valueEl && inputEl) {
                        valueEl.style.display = 'none';
                        inputEl.style.display = 'block';
                        const currentValue = valueEl.textContent.trim();
                        if (!inputEl.value && currentValue !== 'Not added' && currentValue !== 'No agregado') {
                            inputEl.value = currentValue;
                        }
                    }
                });
                if (verificationFormActions) {
                    verificationFormActions.style.display = 'flex';
                }
                if (verificationError) {
                    verificationError.style.display = 'none';
                }
            });
        }
        
        if (saveVerificationBtn) {
            saveVerificationBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                const data = {};
                
                Object.keys(verificationFields).forEach(key => {
                    const inputEl = document.getElementById(verificationFields[key].input);
                    if (inputEl) {
                        data[key] = inputEl.value.trim();
                    }
                });
                
                // Validation: At least one field must be filled
                const hasAtLeastOne = data.autonomousWorker || data.cif || data.registeredCompany;
                if (!hasAtLeastOne) {
                    if (verificationError) {
                        verificationError.style.display = 'block';
                    }
                    return;
                }
                
                if (verificationError) {
                    verificationError.style.display = 'none';
                }
                
                const originalText = saveVerificationBtn.textContent;
                saveVerificationBtn.disabled = true;
                saveVerificationBtn.textContent = 'Guardando...';
                
                fetch(nidfilAjax.ajaxurl, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: new URLSearchParams({
                        action: 'nidfil_save_verification_info',
                        autonomous_worker: data.autonomousWorker || '',
                        cif: data.cif || '',
                        registered_company: data.registeredCompany || '',
                        nonce: nidfilAjax.nonce
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        Object.keys(verificationFields).forEach(key => {
                            const inputEl = document.getElementById(verificationFields[key].input);
                            const valueEl = document.getElementById(verificationFields[key].value);
                            if (inputEl && valueEl) {
                                const value = inputEl.value.trim();
                                valueEl.textContent = value || 'No agregado';
                                valueEl.style.display = 'block';
                                inputEl.style.display = 'none';
                            }
                        });
                        if (verificationFormActions) {
                            verificationFormActions.style.display = 'none';
                        }
                        updateProfileCompletion();
                    } else {
                        if (verificationError) {
                            verificationError.textContent = data.data?.message || 'Error al guardar la información de verificación.';
                            verificationError.style.display = 'block';
                        }
                    }
                    saveVerificationBtn.disabled = false;
                    saveVerificationBtn.textContent = originalText;
                })
                .catch(error => {
                    console.error('Error:', error);
                    if (verificationError) {
                        verificationError.textContent = 'Error al guardar la información de verificación.';
                        verificationError.style.display = 'block';
                    }
                    saveVerificationBtn.disabled = false;
                    saveVerificationBtn.textContent = originalText;
                });
            });
        }
        
        if (cancelVerificationBtn) {
            cancelVerificationBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                Object.keys(verificationFields).forEach(key => {
                    const valueEl = document.getElementById(verificationFields[key].value);
                    const inputEl = document.getElementById(verificationFields[key].input);
                    if (valueEl && inputEl) {
                        const currentValue = valueEl.textContent.trim();
                        inputEl.value = (currentValue !== 'Not added' && currentValue !== 'No agregado') ? currentValue : '';
                        valueEl.style.display = 'block';
                        inputEl.style.display = 'none';
                    }
                });
                if (verificationFormActions) {
                    verificationFormActions.style.display = 'none';
                }
                if (verificationError) {
                    verificationError.style.display = 'none';
                }
            });
        }
        
        // Certifications Edit (Specialist)
        const editCertificationsBtn = document.getElementById('editCertificationsBtn');
        const certificationsList = document.getElementById('certificationsList');
        const certificationsEditForm = document.getElementById('certificationsEditForm');
        const certificationsTextarea = document.getElementById('certificationsTextarea');
        const saveCertificationsBtn = document.getElementById('saveCertificationsBtn');
        const cancelCertificationsBtn = document.getElementById('cancelCertificationsBtn');
        
        if (editCertificationsBtn && certificationsList && certificationsEditForm) {
            editCertificationsBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                const currentCerts = Array.from(certificationsList.querySelectorAll('.certification-item span')).map(el => el.textContent).join('\n');
                certificationsList.style.display = 'none';
                certificationsEditForm.style.display = 'block';
                certificationsTextarea.value = currentCerts;
                certificationsTextarea.focus();
            });
        }
        
        if (saveCertificationsBtn) {
            saveCertificationsBtn.addEventListener('click', async function(e) {
                e.preventDefault();
                e.stopPropagation();
                const certificationsText = certificationsTextarea.value.trim();
                
                const originalText = saveCertificationsBtn.textContent;
                saveCertificationsBtn.disabled = true;
                saveCertificationsBtn.textContent = 'Guardando...';
                
                try {
                    const response = await fetch(nidfilAjax.ajaxurl, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                        body: new URLSearchParams({
                            action: 'nidfil_save_certifications',
                            certifications: certificationsText,
                            nonce: nidfilAjax.nonce
                        })
                    });
                    
                    const data = await response.json();
                    
                    if (data && data.success) {
                        certificationsList.innerHTML = '';
                        if (data.data && data.data.certifications && data.data.certifications.length > 0) {
                            data.data.certifications.forEach(cert => {
                                const item = document.createElement('div');
                                item.className = 'certification-item';
                                item.innerHTML = '<span>' + cert + '</span>';
                                certificationsList.appendChild(item);
                            });
                        } else {
                            certificationsList.innerHTML = '<p class="no-data">No has agregado certificaciones aún. Haz clic en editar para agregar.</p>';
                        }
                        certificationsList.style.display = 'block';
                        certificationsEditForm.style.display = 'none';
                        updateProfileCompletion();
                    }
                } catch (error) {
                    console.error('Error:', error);
                } finally {
                    saveCertificationsBtn.disabled = false;
                    saveCertificationsBtn.textContent = originalText;
                }
            });
        }
        
        if (cancelCertificationsBtn) {
            cancelCertificationsBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                certificationsList.style.display = 'block';
                certificationsEditForm.style.display = 'none';
            });
        }
        
        // Pricing Edit (Specialist)
        const editPricingBtn = document.getElementById('editPricingBtn');
        const pricingFormActions = document.getElementById('pricingFormActions');
        const savePricingBtn = document.getElementById('savePricingBtn');
        const cancelPricingBtn = document.getElementById('cancelPricingBtn');
        
        const pricingFields = {
            hourlyRate: { value: 'hourlyRateValue', input: 'hourlyRateInput' },
            projectRate: { value: 'projectRateValue', input: 'projectRateInput' }
        };
        
        if (editPricingBtn) {
            editPricingBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                Object.keys(pricingFields).forEach(key => {
                    const valueEl = document.getElementById(pricingFields[key].value);
                    const inputEl = document.getElementById(pricingFields[key].input);
                    if (valueEl && inputEl) {
                        valueEl.style.display = 'none';
                        inputEl.style.display = 'block';
                        const currentValue = valueEl.textContent.trim();
                        if (!inputEl.value && currentValue !== 'Not added' && currentValue !== 'No agregado') {
                            inputEl.value = currentValue;
                        }
                    }
                });
                if (pricingFormActions) {
                    pricingFormActions.style.display = 'flex';
                }
            });
        }
        
        if (savePricingBtn) {
            savePricingBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                const data = {};
                
                Object.keys(pricingFields).forEach(key => {
                    const inputEl = document.getElementById(pricingFields[key].input);
                    if (inputEl) {
                        data[key] = inputEl.value.trim();
                    }
                });
                
                const originalText = savePricingBtn.textContent;
                savePricingBtn.disabled = true;
                savePricingBtn.textContent = 'Guardando...';
                
                fetch(nidfilAjax.ajaxurl, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: new URLSearchParams({
                        action: 'nidfil_save_pricing',
                        hourly_rate: data.hourlyRate || '',
                        project_rate: data.projectRate || '',
                        nonce: nidfilAjax.nonce
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        Object.keys(pricingFields).forEach(key => {
                            const inputEl = document.getElementById(pricingFields[key].input);
                            const valueEl = document.getElementById(pricingFields[key].value);
                            if (inputEl && valueEl) {
                                const value = inputEl.value.trim();
                                valueEl.textContent = value || 'Not added';
                                valueEl.style.display = 'block';
                                inputEl.style.display = 'none';
                            }
                        });
                        if (pricingFormActions) {
                            pricingFormActions.style.display = 'none';
                        }
                        updateProfileCompletion();
                    }
                    savePricingBtn.disabled = false;
                    savePricingBtn.textContent = originalText;
                })
                .catch(error => {
                    console.error('Error:', error);
                    savePricingBtn.disabled = false;
                    savePricingBtn.textContent = originalText;
                });
            });
        }
        
        if (cancelPricingBtn) {
            cancelPricingBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                Object.keys(pricingFields).forEach(key => {
                    const valueEl = document.getElementById(pricingFields[key].value);
                    const inputEl = document.getElementById(pricingFields[key].input);
                    if (valueEl && inputEl) {
                        valueEl.style.display = 'block';
                        inputEl.style.display = 'none';
                    }
                });
                if (pricingFormActions) {
                    pricingFormActions.style.display = 'none';
                }
            });
        }
        
        // Business Video Upload (Specialist)
        const editVideoBtn = document.getElementById('editVideoBtn');
        const uploadVideoBtn = document.getElementById('uploadVideoBtn');
        const businessVideoInput = document.getElementById('businessVideoInput');
        const businessVideoContainer = document.getElementById('businessVideoContainer');
        const videoUploadPlaceholder = document.getElementById('videoUploadPlaceholder');
        const businessVideoPreview = document.getElementById('businessVideoPreview');
        const videoUploadActions = document.getElementById('videoUploadActions');
        const saveVideoBtn = document.getElementById('saveVideoBtn');
        const cancelVideoBtn = document.getElementById('cancelVideoBtn');
        const removeVideoBtn = document.getElementById('removeVideoBtn');
        const videoStatus = document.getElementById('videoStatus');
        
        let selectedVideoFile = null;
        
        const allowedVideoTypes = ['video/mp4', 'video/webm', 'video/ogg', 'video/quicktime'];
        const maxVideoSize = 100 * 1024 * 1024; // 100MB

        function setVideoStatus(message, type = 'info') {
            if (!videoStatus) return;
            
            if (!message) {
                videoStatus.classList.remove('info', 'success', 'error');
                videoStatus.textContent = '';
                videoStatus.style.display = 'none';
                return;
            }
            
            videoStatus.classList.remove('info', 'success', 'error');
            videoStatus.classList.add(type);
            videoStatus.textContent = message;
            videoStatus.style.display = 'flex';
        }

        // Upload video button
        if (uploadVideoBtn && businessVideoInput) {
            uploadVideoBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                businessVideoInput.value = '';
                selectedVideoFile = null;
                setVideoStatus('', 'info');
                businessVideoInput.click();
            });
        }

        // Edit video button (if video exists)
        if (editVideoBtn && businessVideoInput) {
            editVideoBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                businessVideoInput.value = '';
                selectedVideoFile = null;
                setVideoStatus('', 'info');
                businessVideoInput.click();
            });
        }
        
        // Video file selection
        if (businessVideoInput) {
            businessVideoInput.addEventListener('change', function(e) {
                const file = e.target.files[0];
                if (file) {
                    // Validate file type
                    if (!allowedVideoTypes.includes(file.type)) {
                        setVideoStatus('Formato no válido. Usa MP4, WEBM, OGG o MOV.', 'error');
                        businessVideoInput.value = '';
                        return;
                    }
                    
                    // Validate file size (max 100MB)
                    if (file.size > maxVideoSize) {
                        setVideoStatus('El video es demasiado grande. Máx 100MB.', 'error');
                        businessVideoInput.value = '';
                        return;
                    }
                    
                    selectedVideoFile = file;
                    
                    // Create preview
                    const videoURL = URL.createObjectURL(file);
                    
                    // Hide placeholder if exists
                    if (videoUploadPlaceholder) {
                        videoUploadPlaceholder.style.display = 'none';
                    }
                    
                    // Show preview or create one
                    let preview = businessVideoPreview;
                    if (!preview) {
                        // Create video preview wrapper
                        const wrapper = document.createElement('div');
                        wrapper.className = 'video-preview-wrapper';
                        
                        preview = document.createElement('video');
                        preview.id = 'businessVideoPreview';
                        preview.className = 'business-video-preview';
                        preview.controls = true;
                        preview.src = videoURL;
                        
                        wrapper.appendChild(preview);
                        
                        // Insert before upload actions or at the beginning
                        if (videoUploadActions) {
                            businessVideoContainer.insertBefore(wrapper, videoUploadActions);
                        } else {
                            businessVideoContainer.appendChild(wrapper);
                        }
                    } else {
                        preview.src = videoURL;
                        // Store original URL if not already stored
                        if (!preview.getAttribute('data-original-src')) {
                            const currentSrc = preview.src;
                            preview.setAttribute('data-original-src', currentSrc);
                        }
                    }
                    
                    // Show save/cancel buttons
                    if (videoUploadActions) {
                        videoUploadActions.style.display = 'flex';
                        videoUploadActions.classList.add('show');
                        setVideoStatus('', 'info');
                    }
                }
            });
        }
        
        // Save video
        if (saveVideoBtn) {
            saveVideoBtn.addEventListener('click', async function(e) {
                e.preventDefault();
                e.stopPropagation();
                
                if (!selectedVideoFile) {
                    setVideoStatus('Primero selecciona un video.', 'error');
                    return;
                }
                
                const originalText = saveVideoBtn.innerHTML;
                saveVideoBtn.disabled = true;
                saveVideoBtn.innerHTML = '<svg width="16" height="16" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="10" cy="10" r="8" stroke="currentColor" stroke-width="2"/><path d="M10 6V10L13 13" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg> Guardando...';
                
                try {
                    const formData = new FormData();
                    formData.append('action', 'nidfil_save_business_video');
                    formData.append('business_video', selectedVideoFile);
                    formData.append('nonce', nidfilAjax.nonce);
                    
                    const response = await fetch(nidfilAjax.ajaxurl, {
                        method: 'POST',
                        body: formData
                    });
                    
                    const data = await response.json();
                    
                    if (data && data.success) {
                        // Update video source if new URL provided
                        if (data.data && data.data.video_url) {
                            const preview = document.getElementById('businessVideoPreview');
                            if (preview) {
                                preview.src = data.data.video_url + '?t=' + new Date().getTime();
                            }
                        }
                        
                        // Hide save/cancel buttons
                        if (videoUploadActions) {
                            videoUploadActions.classList.remove('show');
                            setTimeout(() => {
                                if (videoUploadActions && !videoUploadActions.classList.contains('show')) {
                                    videoUploadActions.style.display = 'none';
                                }
                            }, 300);
                        }
                        
                        businessVideoInput.value = '';
                        selectedVideoFile = null;
                        
                        setTimeout(() => {
                            setVideoStatus('', 'info');
                        }, 400);
                        
                        updateProfileCompletion();
                    } else {
                        const errorMsg = data && data.data && data.data.message ? data.data.message : 'Error al guardar el video.';
                        setVideoStatus(errorMsg, 'error');
                    }
                } catch (error) {
                    console.error('Error:', error);
                    setVideoStatus('Error al guardar el video. Por favor, intenta de nuevo.', 'error');
                } finally {
                    saveVideoBtn.disabled = false;
                    saveVideoBtn.innerHTML = originalText;
                }
            });
        }
        
        // Cancel video upload
        if (cancelVideoBtn) {
            cancelVideoBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                
                // Restore original video if exists
                const originalVideoUrl = businessVideoPreview ? businessVideoPreview.getAttribute('data-original-src') : null;
                if (businessVideoPreview && originalVideoUrl) {
                    businessVideoPreview.src = originalVideoUrl;
                } else if (businessVideoPreview && !originalVideoUrl) {
                    // If no original video, remove preview and show placeholder
                    const wrapper = businessVideoPreview.closest('.video-preview-wrapper');
                    if (wrapper) {
                        wrapper.remove();
                    } else {
                        businessVideoPreview.remove();
                    }
                    if (videoUploadPlaceholder) {
                        videoUploadPlaceholder.style.display = 'block';
                    }
                } else if (videoUploadPlaceholder) {
                    videoUploadPlaceholder.style.display = 'block';
                }
                
                // Hide save/cancel buttons
                if (videoUploadActions) {
                    videoUploadActions.classList.remove('show');
                    setTimeout(() => {
                        if (videoUploadActions && !videoUploadActions.classList.contains('show')) {
                            videoUploadActions.style.display = 'none';
                        }
                    }, 300);
                }
                
                businessVideoInput.value = '';
                selectedVideoFile = null;
                setVideoStatus('', 'info');
            });
        }
        
        // Remove video
        if (removeVideoBtn) {
            removeVideoBtn.addEventListener('click', async function(e) {
                e.preventDefault();
                e.stopPropagation();
                
                if (!confirm('¿Estás seguro de que quieres eliminar este video?')) {
                    return;
                }
                
                const originalText = removeVideoBtn.innerHTML;
                removeVideoBtn.disabled = true;
                removeVideoBtn.innerHTML = 'Eliminando...';
                
                try {
                    const response = await fetch(nidfilAjax.ajaxurl, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                        body: new URLSearchParams({
                            action: 'nidfil_remove_business_video',
                            nonce: nidfilAjax.nonce
                        })
                    });
                    
                    const data = await response.json();
                    
                    if (data && data.success) {
                        // Remove preview wrapper
                        const wrapper = businessVideoPreview ? businessVideoPreview.closest('.video-preview-wrapper') : null;
                        if (wrapper) {
                            wrapper.remove();
                        } else if (businessVideoPreview) {
                            businessVideoPreview.remove();
                        }
                        
                        // Show placeholder
                        if (videoUploadPlaceholder) {
                            videoUploadPlaceholder.style.display = 'flex';
                        }
                        
                        updateProfileCompletion();
                    } else {
                        const errorMsg = data && data.data && data.data.message ? data.data.message : 'Error al eliminar el video.';
                        alert(errorMsg);
                    }
                } catch (error) {
                    console.error('Error:', error);
                    alert('Error al eliminar el video. Por favor, intenta de nuevo.');
                } finally {
                    removeVideoBtn.disabled = false;
                    removeVideoBtn.innerHTML = originalText;
                }
            });
        }
        
        // Business Data Edit (Specialist)
        const editBusinessDataBtn = document.getElementById('editBusinessDataBtn');
        const businessDataFormActions = document.getElementById('businessDataFormActions');
        const saveBusinessDataBtn = document.getElementById('saveBusinessDataBtn');
        const cancelBusinessDataBtn = document.getElementById('cancelBusinessDataBtn');
        
        const businessDataFields = {
            businessName: { value: 'businessNameValue', input: 'businessNameInput' },
            officeAddress: { value: 'officeAddressValue', input: 'officeAddressInput' },
            businessCity: { value: 'businessCityValue', input: 'businessCityInput' },
            businessPostalCode: { value: 'businessPostalCodeValue', input: 'businessPostalCodeInput' },
            businessCountry: { value: 'businessCountryValue', input: 'businessCountryInput' },
            businessPhone: { value: 'businessPhoneValue', input: 'businessPhoneInput' },
            businessEmail: { value: 'businessEmailValue', input: 'businessEmailInput' },
            businessWebsite: { value: 'businessWebsiteValue', input: 'businessWebsiteInput' }
        };
        
        if (editBusinessDataBtn) {
            editBusinessDataBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                Object.keys(businessDataFields).forEach(key => {
                    const valueEl = document.getElementById(businessDataFields[key].value);
                    const inputEl = document.getElementById(businessDataFields[key].input);
                    if (valueEl && inputEl) {
                        valueEl.style.display = 'none';
                        inputEl.style.display = 'block';
                        const currentValue = valueEl.textContent.trim();
                        if (!inputEl.value && currentValue !== 'Not added' && currentValue !== 'No agregado') {
                            inputEl.value = currentValue;
                        }
                    }
                });
                if (businessDataFormActions) {
                    businessDataFormActions.style.display = 'flex';
                }
            });
        }
        
        if (saveBusinessDataBtn) {
            saveBusinessDataBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                
                const data = {};
                Object.keys(businessDataFields).forEach(key => {
                    const inputEl = document.getElementById(businessDataFields[key].input);
                    if (inputEl) {
                        data[key] = inputEl.value.trim();
                    }
                });
                
                const originalText = saveBusinessDataBtn.textContent;
                saveBusinessDataBtn.disabled = true;
                saveBusinessDataBtn.textContent = 'Guardando...';
                
                fetch(nidfilAjax.ajaxurl, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: new URLSearchParams({
                        action: 'nidfil_save_business_data',
                        business_name: data.businessName || '',
                        office_address: data.officeAddress || '',
                        business_city: data.businessCity || '',
                        business_postal_code: data.businessPostalCode || '',
                        business_country: data.businessCountry || '',
                        business_phone: data.businessPhone || '',
                        business_email: data.businessEmail || '',
                        business_website: data.businessWebsite || '',
                        nonce: nidfilAjax.nonce
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        Object.keys(businessDataFields).forEach(key => {
                            const inputEl = document.getElementById(businessDataFields[key].input);
                            const valueEl = document.getElementById(businessDataFields[key].value);
                            if (inputEl && valueEl) {
                                const value = inputEl.value.trim();
                                valueEl.textContent = value || 'Not added';
                                valueEl.style.display = 'block';
                                inputEl.style.display = 'none';
                            }
                        });
                        if (businessDataFormActions) {
                            businessDataFormActions.style.display = 'none';
                        }
                        updateProfileCompletion();
                    }
                    saveBusinessDataBtn.disabled = false;
                    saveBusinessDataBtn.textContent = originalText;
                })
                .catch(error => {
                    console.error('Error:', error);
                    saveBusinessDataBtn.disabled = false;
                    saveBusinessDataBtn.textContent = originalText;
                });
            });
        }
        
        if (cancelBusinessDataBtn) {
            cancelBusinessDataBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                Object.keys(businessDataFields).forEach(key => {
                    const valueEl = document.getElementById(businessDataFields[key].value);
                    const inputEl = document.getElementById(businessDataFields[key].input);
                    if (valueEl && inputEl) {
                        valueEl.style.display = 'block';
                        inputEl.style.display = 'none';
                    }
                });
                if (businessDataFormActions) {
                    businessDataFormActions.style.display = 'none';
                }
            });
        }
        
        console.log('Profile editing initialized');
    }
    
    // Initialize when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initProfileEditing);
    } else {
        initProfileEditing();
    }
    
    // Fallback initialization
    setTimeout(initProfileEditing, 300);
})();

// Services Management
(function() {
    function initServicesManagement() {
        const addServiceBtn = document.getElementById('addServiceBtn');
        const serviceModal = document.getElementById('serviceModal');
        const serviceModalOverlay = document.getElementById('serviceModalOverlay');
        const serviceModalClose = document.getElementById('serviceModalClose');
        const serviceModalTitle = document.getElementById('serviceModalTitle');
        const serviceForm = document.getElementById('serviceForm');
        const serviceNameInput = document.getElementById('serviceNameInput');
        const saveServiceBtn = document.getElementById('saveServiceBtn');
        const cancelServiceBtn = document.getElementById('cancelServiceBtn');
        const servicesList = document.getElementById('servicesList');
        let editingServiceId = null;
        
        if (!addServiceBtn || !serviceModal || !servicesList) {
            return;
        }
        
        // Open modal for adding service
        addServiceBtn.addEventListener('click', function(e) {
            e.preventDefault();
            editingServiceId = null;
            serviceModalTitle.textContent = 'Agregar Servicio';
            serviceNameInput.value = '';
            serviceModal.style.display = 'flex';
            setTimeout(() => {
                serviceNameInput.focus();
            }, 100);
        });
        
        // Close modal
        function closeServiceModal() {
            serviceModal.style.display = 'none';
            if (serviceForm) {
                serviceForm.reset();
            }
            editingServiceId = null;
        }
        
        if (serviceModalOverlay) {
            serviceModalOverlay.addEventListener('click', closeServiceModal);
        }
        
        if (serviceModalClose) {
            serviceModalClose.addEventListener('click', closeServiceModal);
        }
        
        if (cancelServiceBtn) {
            cancelServiceBtn.addEventListener('click', closeServiceModal);
        }
        
        // Handle form submission
        if (serviceForm) {
            serviceForm.addEventListener('submit', function(e) {
                e.preventDefault();
                
                const serviceName = serviceNameInput.value.trim();
                if (!serviceName) {
                    alert('Por favor, ingresa el nombre del servicio.');
                    return;
                }
                
                const originalText = saveServiceBtn.textContent;
                saveServiceBtn.disabled = true;
                saveServiceBtn.textContent = 'Guardando...';
                
                const formData = new URLSearchParams();
                formData.append('action', 'nidfil_add_service');
                formData.append('service_name', serviceName);
                if (editingServiceId !== null) {
                    formData.append('service_id', editingServiceId);
                }
                formData.append('nonce', nidfilAjax.nonce);
                
                fetch(nidfilAjax.ajaxurl, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        loadServices();
                        closeServiceModal();
                        if (typeof updateProfileCompletion === 'function') {
                            updateProfileCompletion();
                        }
                    } else {
                        alert(data.data?.message || 'Error al guardar el servicio.');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Error al guardar el servicio. Por favor, intenta de nuevo.');
                })
                .finally(() => {
                    saveServiceBtn.disabled = false;
                    saveServiceBtn.textContent = originalText;
                });
            });
        }
        
        // Load services
        function loadServices() {
            fetch(nidfilAjax.ajaxurl + '?action=nidfil_get_services&nonce=' + nidfilAjax.nonce)
                .then(response => response.json())
                .then(data => {
                    if (data.success && data.data && data.data.services) {
                        renderServices(data.data.services);
                    } else {
                        renderServices([]);
                    }
                })
                .catch(error => {
                    console.error('Error loading services:', error);
                    renderServices([]);
                });
        }
        
        // Render services
        function renderServices(services) {
            if (!servicesList) return;
            
            if (services.length === 0) {
                servicesList.innerHTML = '<div class="no-data"><p>Aún no has agregado servicios. Haz clic en "Agregar Servicio" para comenzar.</p></div>';
                return;
            }
            
            servicesList.innerHTML = '';
            services.forEach((service, index) => {
                const serviceCard = document.createElement('div');
                serviceCard.className = 'service-card';
                serviceCard.setAttribute('data-service-id', index);
                serviceCard.innerHTML = `
                    <div class="service-card-content">
                        <h3 class="service-name">${escapeHtml(service)}</h3>
                    </div>
                    <div class="service-card-actions">
                        <button class="icon-btn edit-service-btn" data-service-id="${index}" title="Editar servicio">
                            <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M13.5 2.5L15.5 4.5M14 1L17 4L9 12H6V9L14 1Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </button>
                        <button class="icon-btn delete-service-btn" data-service-id="${index}" title="Eliminar servicio">
                            <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M4.5 4.5L13.5 13.5M13.5 4.5L4.5 13.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </button>
                    </div>
                `;
                servicesList.appendChild(serviceCard);
            });
            
            // Attach event listeners
            attachServiceEventListeners();
        }
        
        // Attach event listeners to service cards
        function attachServiceEventListeners() {
            // Edit buttons
            document.querySelectorAll('.edit-service-btn').forEach(btn => {
                btn.removeEventListener('click', handleEditClick);
                btn.addEventListener('click', handleEditClick);
            });
            
            // Delete buttons
            document.querySelectorAll('.delete-service-btn').forEach(btn => {
                btn.removeEventListener('click', handleDeleteClick);
                btn.addEventListener('click', handleDeleteClick);
            });
        }
        
        function handleEditClick(e) {
            e.stopPropagation();
            const serviceId = parseInt(this.getAttribute('data-service-id'));
            const serviceCard = this.closest('.service-card');
            const serviceName = serviceCard.querySelector('.service-name').textContent;
            
            editingServiceId = serviceId;
            serviceModalTitle.textContent = 'Editar Servicio';
            serviceNameInput.value = serviceName;
            serviceModal.style.display = 'flex';
            setTimeout(() => {
                serviceNameInput.focus();
            }, 100);
        }
        
        function handleDeleteClick(e) {
            e.stopPropagation();
            const serviceId = parseInt(this.getAttribute('data-service-id'));
            
            if (confirm('¿Estás seguro de que deseas eliminar este servicio?')) {
                const formData = new URLSearchParams();
                formData.append('action', 'nidfil_delete_service');
                formData.append('service_id', serviceId);
                formData.append('nonce', nidfilAjax.nonce);
                
                fetch(nidfilAjax.ajaxurl, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        loadServices();
                        if (typeof updateProfileCompletion === 'function') {
                            updateProfileCompletion();
                        }
                    } else {
                        alert(data.data?.message || 'Error al eliminar el servicio.');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Error al eliminar el servicio. Por favor, intenta de nuevo.');
                });
            }
        }
        
        // Escape HTML to prevent XSS
        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
        
        // Load services on page load
        loadServices();
    }
    
    // Initialize when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initServicesManagement);
    } else {
        initServicesManagement();
    }
    
    // Fallback initialization
    setTimeout(initServicesManagement, 300);
})();
</script>

<?php
get_footer();
?>

