# NIDFIL Connect WordPress Theme

A modern WordPress theme for connecting users with construction and renovation specialists.

## Theme Features

- **Modern Design**: Clean, professional interface with orange accent colors
- **Hero Section**: Prominent call-to-action with search functionality
- **Category Grid**: Display of service categories in an attractive grid layout
- **Responsive**: Fully responsive design that works on all devices
- **Customizable**: Theme options available in WordPress Customizer

## Installation

1. Upload the theme folder to `/wp-content/themes/` directory
2. Activate the theme through the 'Themes' menu in WordPress
3. Go to **Appearance > Customize** to configure theme options

## Theme Structure

```
nidfil-connect-main/
├── style.css              # Main stylesheet (required)
├── functions.php          # Theme functions and setup
├── index.php             # Main template file
├── header.php            # Header template
├── footer.php            # Footer template
├── front-page.php        # Front page template
├── inc/
│   └── template-functions.php  # Template helper functions
└── js/
    └── main.js           # Theme JavaScript
```

## Customization

### Theme Options

Navigate to **Appearance > Customize > Theme Options** to customize:
- Hero Title
- Hero Highlight Text
- Hero Subtitle

### Custom Logo

Go to **Appearance > Customize > Site Identity** to upload a custom logo.

## Technologies Used

- WordPress (PHP)
- HTML5/CSS3
- JavaScript

## Support

For theme support and customization, please contact the theme developer.
