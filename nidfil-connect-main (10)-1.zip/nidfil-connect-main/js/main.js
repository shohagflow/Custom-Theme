/**
 * NIDFIL Connect Theme JavaScript
 */

(function() {
    'use strict';

    // Search form handling
    const searchForm = document.querySelector('.search-form');
    if (searchForm) {
        searchForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const specialist = document.getElementById('specialist').value;
            const location = document.getElementById('location').value;
            
            // You can add AJAX search functionality here
            console.log('Searching for:', specialist, 'in', location);
        });
    }

    // Category card click handling
    const categoryCards = document.querySelectorAll('.category-card');
    categoryCards.forEach(card => {
        card.addEventListener('click', function() {
            const categoryName = this.querySelector('.category-name').textContent;
            // Add navigation logic here
            console.log('Selected category:', categoryName);
        });
    });

    // Hero service switcher
    function initHeroServiceSwitcher() {
        const cards = document.querySelectorAll('.hero-service-card');
        const panels = document.querySelectorAll('.hero-service-panel');

        if (!cards.length || !panels.length) return;

        cards.forEach(card => {
            card.addEventListener('click', function () {
                const target = this.getAttribute('data-target');
                if (!target) return;

                cards.forEach(c => c.classList.remove('is-active'));
                panels.forEach(p => p.classList.remove('is-active'));

                this.classList.add('is-active');
                const panel = document.querySelector('.hero-service-panel--' + target);
                if (panel) {
                    panel.classList.add('is-active');
                    
                    // Initialize nueva flow when nueva panel becomes active
                    if (target === 'nueva') {
                        // Small delay to ensure DOM is ready
                        setTimeout(function() {
                            initNuevaFlow();
                        }, 100);
                    }
                }
                
                // Explicitly hide nueva panel if switching to reforma
                if (target === 'reforma') {
                    const nuevaPanel = document.querySelector('.hero-service-panel--nueva');
                    if (nuevaPanel) {
                        nuevaPanel.classList.remove('is-active');
                    }
                    resetNuevaFlow();
                }
            });
        });
    }

    initHeroServiceSwitcher();

    // New Construction Flow Handler
    function initNuevaFlow() {
        const dropdownBtn = document.getElementById('projectTypeDropdownBtn');
        const dropdown = document.getElementById('projectTypeDropdown');
        const projectTypeOptions = document.querySelectorAll('.project-type-option');
        const locationInput = document.getElementById('nueva-location');
        const searchBtn = document.getElementById('nuevaSearchBtn');

        if (!dropdownBtn || !dropdown) {
            console.log('Nueva flow elements not found');
            return; // Elements don't exist yet
        }

        // Check if already initialized
        if (dropdownBtn.dataset.initialized === 'true') {
            return; // Already initialized
        }
        dropdownBtn.dataset.initialized = 'true';

        let selectedProjectType = null;

        // Dropdown Toggle
        dropdownBtn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            console.log('Dropdown button clicked');
            const isActive = dropdownBtn.classList.contains('active');
            
            if (isActive) {
                dropdownBtn.classList.remove('active');
                dropdown.classList.remove('show');
                console.log('Closing dropdown');
            } else {
                dropdownBtn.classList.add('active');
                dropdown.classList.add('show');
                console.log('Opening dropdown');
            }
        });

        // Close dropdown when clicking outside
        document.addEventListener('click', function(e) {
            if (!dropdownBtn.contains(e.target) && !dropdown.contains(e.target)) {
                dropdownBtn.classList.remove('active');
                dropdown.classList.remove('show');
            }
        });

        // Project Type Selection
        if (projectTypeOptions.length) {
            projectTypeOptions.forEach(option => {
                option.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    
                    // Remove selected class from all options
                    projectTypeOptions.forEach(o => {
                        o.classList.remove('selected');
                        const check = o.querySelector('.project-type-check');
                        if (check) check.style.display = 'none';
                    });
                    
                    // Add selected class to clicked option
                    this.classList.add('selected');
                    const check = this.querySelector('.project-type-check');
                    if (check) check.style.display = 'block';
                    
                    selectedProjectType = this.getAttribute('data-project-type');
                    
                    // Update dropdown header text (optional)
                    const label = this.querySelector('.project-type-option-label').textContent;
                    const titleSpan = dropdownBtn.querySelector('.project-type-title');
                    if (titleSpan) {
                        titleSpan.textContent = label;
                    }
                    
                    // Close dropdown
                    dropdownBtn.classList.remove('active');
                    dropdown.classList.remove('show');
                });
            });
        }

        // Search Button Handler
        if (searchBtn) {
            searchBtn.addEventListener('click', function(e) {
                e.preventDefault();
                
                const projectType = selectedProjectType;
                const location = locationInput ? locationInput.value.trim() : '';

                if (!projectType) {
                    alert('Por favor, selecciona un tipo de proyecto.');
                    return;
                }

                if (!location) {
                    alert('Por favor, introduce una ubicación.');
                    if (locationInput) locationInput.focus();
                    return;
                }

                // Perform search - you can customize this action
                performNuevaSearch(projectType, location);
            });
        }
    }

    // Reset nueva flow when switching away
    function resetNuevaFlow() {
        const dropdownBtn = document.getElementById('projectTypeDropdownBtn');
        const dropdown = document.getElementById('projectTypeDropdown');
        const projectTypeOptions = document.querySelectorAll('.project-type-option');
        const locationInput = document.getElementById('nueva-location');
        const titleSpan = dropdownBtn ? dropdownBtn.querySelector('.project-type-title') : null;

        projectTypeOptions.forEach(option => {
            option.classList.remove('selected');
            const check = option.querySelector('.project-type-check');
            if (check) check.style.display = 'none';
        });
        
        if (dropdownBtn) {
            dropdownBtn.classList.remove('active');
            if (titleSpan) titleSpan.textContent = 'Tipo de proyecto';
        }
        if (dropdown) dropdown.classList.remove('show');
        if (locationInput) locationInput.value = '';
    }

    // Perform search action
    function performNuevaSearch(projectType, location) {
        // Map project type to readable text
        const projectTypeMap = {
            'single-family': 'Vivienda unifamiliar',
            'building': 'Edificio',
            'warehouse': 'Nave / local'
        };

        console.log('Searching for:', {
            projectType: projectTypeMap[projectType] || projectType,
            location: location
        });

        // TODO: Implement actual search functionality
        // This could redirect to a search results page or trigger an AJAX search
        // Example:
        // window.location.href = `<?php echo esc_url(home_url('/')); ?>?project_type=${projectType}&location=${encodeURIComponent(location)}`;
        
        // Or trigger AJAX search:
        // fetch('/wp-admin/admin-ajax.php', {
        //     method: 'POST',
        //     body: new FormData(form)
        // })
    }

    // Initialize nueva flow when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initNuevaFlow);
    } else {
        // DOM is already ready
        initNuevaFlow();
    }

    // Language Switcher functionality
    function initLanguageSwitcher() {
        const languageSwitcher = document.querySelector('.language-switcher');
        const languageSwitcherBtn = document.getElementById('languageSwitcherBtn');
        const languageDropdown = document.getElementById('languageDropdown');
        const currentLanguageSpan = document.getElementById('currentLanguage');
        const languageOptions = document.querySelectorAll('.language-option');

        if (!languageSwitcher || !languageSwitcherBtn) {
            console.log('Language switcher elements not found');
            return;
        }

        console.log('Language switcher initialized');

        // Get saved language from localStorage or default to ES
        let currentLang = localStorage.getItem('selectedLanguage') || 'ES';
        updateCurrentLanguage(currentLang);

        // Toggle dropdown - Multiple event handlers for reliability
        languageSwitcherBtn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            console.log('Language button clicked');
            languageSwitcher.classList.toggle('active');
            console.log('Language switcher active:', languageSwitcher.classList.contains('active'));
        });

        // Also handle clicks on the button container
        languageSwitcher.addEventListener('click', function(e) {
            if (e.target.closest('.language-switcher-button')) {
                e.stopPropagation();
            }
        });

        // Handle language selection
        if (languageOptions.length > 0) {
            languageOptions.forEach(option => {
                option.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    const langCode = this.getAttribute('data-code');
                    const lang = this.getAttribute('data-lang');
                    
                    // Update current language display
                    updateCurrentLanguage(langCode);
                    
                    // Update active state
                    languageOptions.forEach(opt => opt.classList.remove('active'));
                    this.classList.add('active');
                    
                    // Save to localStorage
                    localStorage.setItem('selectedLanguage', langCode);
                    
                    // Close dropdown
                    languageSwitcher.classList.remove('active');
                    
                    console.log('Language changed to:', lang, langCode);
                });
            });
        }

        // Close dropdown when clicking outside
        document.addEventListener('click', function(e) {
            if (languageSwitcher && !languageSwitcher.contains(e.target)) {
                languageSwitcher.classList.remove('active');
            }
        });

        // Function to update current language display
        function updateCurrentLanguage(langCode) {
            if (currentLanguageSpan) {
                currentLanguageSpan.textContent = langCode;
            }
            
            // Update active state in dropdown
            languageOptions.forEach(option => {
                if (option.getAttribute('data-code') === langCode) {
                    option.classList.add('active');
                } else {
                    option.classList.remove('active');
                }
            });
        }
    }

    // Initialize language switcher immediately
    initLanguageSwitcher();
    
    // Also initialize on DOM ready as fallback
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initLanguageSwitcher);
    }
    
    // Additional fallback initialization
    setTimeout(initLanguageSwitcher, 500);

    // Handle language selection
    languageOptions.forEach(option => {
        option.addEventListener('click', function(e) {
            e.preventDefault();
            const langCode = this.getAttribute('data-code');
            const lang = this.getAttribute('data-lang');
            
            // Update current language display
            updateCurrentLanguage(langCode);
            
            // Update active state
            languageOptions.forEach(opt => opt.classList.remove('active'));
            this.classList.add('active');
            
            // Save to localStorage
            localStorage.setItem('selectedLanguage', langCode);
            
            // Close dropdown
            languageSwitcher.classList.remove('active');
            
            // Here you can add actual language switching logic
            // For example, redirect to language-specific URL or reload page with language parameter
            console.log('Language changed to:', lang, langCode);
            
            // Example: Reload page with language parameter
            // window.location.href = window.location.pathname + '?lang=' + lang;
        });
    });

    // Close dropdown when clicking outside
    document.addEventListener('click', function(e) {
        if (languageSwitcher && !languageSwitcher.contains(e.target)) {
            languageSwitcher.classList.remove('active');
        }
    });

    // Function to update current language display
    function updateCurrentLanguage(langCode) {
        if (currentLanguageSpan) {
            currentLanguageSpan.textContent = langCode;
        }
        
        // Update active state in dropdown
        languageOptions.forEach(option => {
            if (option.getAttribute('data-code') === langCode) {
                option.classList.add('active');
            } else {
                option.classList.remove('active');
            }
        });
    }

})();

// Open Specialist Modal - Make globally accessible
window.openSpecialistModal = function(card) {
    const modal = document.getElementById('specialistModal');
    if (!modal) {
        console.error('Specialist modal not found');
        return;
    }
    
    const data = {
        name: card.getAttribute('data-name') || '',
        profession: card.getAttribute('data-profession') || '',
        rating: card.getAttribute('data-rating') || '0',
        reviews: card.getAttribute('data-reviews') || '0',
        location: card.getAttribute('data-location') || '',
        officeAddress: card.getAttribute('data-office-address') || '',
        distance: card.getAttribute('data-distance') || '0',
        verified: card.getAttribute('data-verified') === 'true',
        avatar: card.getAttribute('data-avatar') || '',
        specialistId: card.getAttribute('data-specialist-id') || '',
        whatsapp: card.getAttribute('data-whatsapp') || '',
        phone: card.getAttribute('data-phone') || '',
        description: card.getAttribute('data-description') || ''
    };
    
    // Update modal content
    const modalAvatar = document.getElementById('modalAvatar');
    const modalAvatarImg = document.getElementById('modalAvatarImg');
    const modalName = document.getElementById('modalName');
    const modalProfession = document.getElementById('modalProfession');
    const modalRating = document.getElementById('modalRating');
    const modalLocation = document.getElementById('modalLocation');
    const modalDistance = document.getElementById('modalDistance');
    const modalDescription = document.getElementById('modalDescription');
    const verifiedBadge = document.getElementById('modalVerified');
    const whatsappBtn = document.getElementById('modalWhatsApp');
    const callBtn = document.getElementById('modalCall');
    const messageBtn = document.getElementById('modalMessage');
    
    // Update avatar - check if specialist has avatar URL
    const avatarUrl = card.getAttribute('data-avatar-url') || '';
    const cardAvatarImg = card.querySelector('.specialist-avatar-img');
    const cardAvatarPlaceholder = card.querySelector('.specialist-avatar-placeholder');
    
    // Check if we have a valid avatar URL (not empty and not gravatar)
    if (avatarUrl && avatarUrl.trim() !== '' && avatarUrl.indexOf('gravatar.com') === -1) {
        // Specialist has a custom profile image
        if (modalAvatarImg) {
            modalAvatarImg.src = avatarUrl;
            modalAvatarImg.alt = data.name;
            modalAvatarImg.style.display = 'block';
            modalAvatarImg.onerror = function() {
                // If image fails to load, show placeholder
                this.style.display = 'none';
                if (modalAvatar) {
                    modalAvatar.textContent = data.avatar || data.name.substring(0, 2).toUpperCase();
                    modalAvatar.style.display = 'flex';
                }
            };
        }
        if (modalAvatar) {
            modalAvatar.style.display = 'none';
        }
    } else if (cardAvatarImg && cardAvatarImg.src && cardAvatarImg.src.indexOf('data:') !== 0 && cardAvatarImg.src.indexOf('gravatar.com') === -1) {
        // Fallback: check if card has an image element
        if (modalAvatarImg) {
            modalAvatarImg.src = cardAvatarImg.src;
            modalAvatarImg.style.display = 'block';
            modalAvatarImg.alt = data.name;
            modalAvatarImg.onerror = function() {
                // If image fails to load, show placeholder
                this.style.display = 'none';
                if (modalAvatar) {
                    modalAvatar.textContent = data.avatar || data.name.substring(0, 2).toUpperCase();
                    modalAvatar.style.display = 'flex';
                }
            };
        }
        if (modalAvatar) {
            modalAvatar.style.display = 'none';
        }
    } else {
        // No image available, show placeholder with initials
        if (modalAvatar) {
            modalAvatar.textContent = data.avatar || data.name.substring(0, 2).toUpperCase();
            modalAvatar.style.display = 'flex';
        }
        if (modalAvatarImg) {
            modalAvatarImg.style.display = 'none';
        }
    }
    
    if (modalName) modalName.textContent = data.name;
    if (modalProfession) modalProfession.textContent = data.profession;
    if (modalRating) {
        modalRating.innerHTML = `
            <svg width="18" height="18" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="#FFD700"/>
            </svg>
            <span class="rating-value">${data.rating}</span>
            <span class="reviews-count">(${data.reviews} opiniones)</span>
        `;
    }
    if (modalLocation) {
        let locationText = '';
        if (data.officeAddress && data.officeAddress.trim() !== '') {
            // Show office address if available
            locationText = data.officeAddress;
        } else if (data.location && data.location.trim() !== '' && data.location !== 'Ubicación no especificada') {
            // Fallback to location if office address not available
            locationText = data.location;
        } else {
            // Default message
            locationText = 'Ingresa tu dirección de oficina';
        }
        modalLocation.textContent = locationText;
    }
    if (modalDistance) modalDistance.textContent = data.distance + ' km';
    if (modalDescription) modalDescription.textContent = data.description;
    
    // Show/hide verified badge
    if (verifiedBadge) {
        if (data.verified) {
            verifiedBadge.style.display = 'inline-flex';
        } else {
            verifiedBadge.style.display = 'none';
        }
    }
    
    // Update action buttons
    if (whatsappBtn && data.whatsapp) {
        whatsappBtn.href = `https://wa.me/${data.whatsapp}?text=Hola%20${encodeURIComponent(data.name.split(' ')[0])},%20me%20interesa%20tu%20servicio%20de%20${encodeURIComponent(data.profession.toLowerCase())}`;
    }
    if (callBtn && data.phone) {
        callBtn.href = `tel:${data.phone}`;
    }
    
    // Show/hide message button and set specialist ID
    if (messageBtn) {
        // Show button for all users (logged in or not), but hide if user is the specialist themselves
        const currentUserId = window.nidfilAjax && window.nidfilAjax.current_user_id;
        const isNotSelf = !currentUserId || parseInt(currentUserId) !== parseInt(data.specialistId);
        
        if (data.specialistId && isNotSelf) {
            messageBtn.style.display = 'flex';
            messageBtn.setAttribute('data-specialist-id', data.specialistId);
            messageBtn.disabled = false;
            
            // Remove any existing click handlers and attach a fresh one
            const newBtn = messageBtn.cloneNode(true);
            messageBtn.parentNode.replaceChild(newBtn, messageBtn);
            
            // Attach click handler directly
            newBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                
                if (this.disabled) return;
                
                const specialistId = this.getAttribute('data-specialist-id');
                console.log('Message button clicked, specialist ID:', specialistId);
                
                if (!specialistId) {
                    alert('Error: No se pudo identificar al especialista.');
                    return;
                }
                
                if (!window.nidfilAjax) {
                    alert('Error: Sistema de mensajería no disponible.');
                    return;
                }
                
                // Check if user is logged in
                const isLoggedIn = window.nidfilAjax.is_user_logged_in;
                
                if (!isLoggedIn) {
                    // User is not logged in - open registration form
                    const specialistModal = document.getElementById('specialistModal');
                    if (specialistModal) {
                        specialistModal.classList.remove('modal-active');
                        document.body.style.overflow = '';
                    }
                    
                    if (typeof openClienteModal === 'function') {
                        openClienteModal();
                        setTimeout(function() {
                            if (typeof switchFormTab === 'function') {
                                switchFormTab('register');
                            }
                        }, 100);
                    } else {
                        alert('Por favor, inicia sesión o regístrate para enviar mensajes.');
                    }
                    return;
                }
                
                // User is logged in - proceed with starting conversation
                this.disabled = true;
                const originalHTML = this.innerHTML;
                this.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M21 15C21 15.5304 20.7893 16.0391 20.4142 16.4142C20.0391 16.7893 19.5304 17 19 17H7L3 21V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H19C19.5304 3 20.0391 3.21071 20.4142 3.58579C20.7893 3.96086 21 4.46957 21 5V15Z" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg> Iniciando...';
                
                fetch(nidfilAjax.ajaxurl, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: new URLSearchParams({
                        action: 'nidfil_start_conversation',
                        specialist_id: specialistId,
                        nonce: nidfilAjax.nonce
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        const modal = document.getElementById('specialistModal');
                        if (modal) {
                            modal.classList.remove('modal-active');
                            document.body.style.overflow = '';
                        }
                        
                        let redirectUrl = '';
                        if (data.data && data.data.redirect_url) {
                            redirectUrl = data.data.redirect_url;
                        } else if (nidfilAjax.dashboard_url) {
                            redirectUrl = nidfilAjax.dashboard_url;
                        } else {
                            redirectUrl = '/client-profile/';
                        }
                        
                        if (data.data && data.data.conversation_id) {
                            redirectUrl += '#messagesSection?conversation_id=' + data.data.conversation_id;
                        } else {
                            redirectUrl += '#messagesSection';
                        }
                        
                        window.location.href = redirectUrl;
                    } else {
                        alert(data.data?.message || 'Error al iniciar la conversación.');
                        this.disabled = false;
                        this.innerHTML = originalHTML;
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Error al iniciar la conversación. Por favor, intenta nuevamente.');
                    this.disabled = false;
                    this.innerHTML = originalHTML;
                });
            });
        } else {
            messageBtn.style.display = 'none';
        }
    }
    
    // Show modal
    modal.classList.add('modal-active');
    document.body.style.overflow = 'hidden';
};

// Close Specialist Modal - Make globally accessible
window.closeSpecialistModal = function() {
    const modal = document.getElementById('specialistModal');
    if (modal) {
        modal.classList.remove('modal-active');
        document.body.style.overflow = '';
    }
};

// Add ESC key support to close modal and ensure click handlers work
document.addEventListener('DOMContentLoaded', function() {
    // ESC key to close modal
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            const modal = document.getElementById('specialistModal');
            if (modal && modal.classList.contains('modal-active')) {
                window.closeSpecialistModal();
            }
        }
    });
    
    // Add event listener for specialist cards - PRIMARY METHOD
    function initSpecialistCards() {
        const specialistCards = document.querySelectorAll('.specialist-card');
        console.log('Found specialist cards:', specialistCards.length);
        
        specialistCards.forEach(function(card) {
            // Remove existing onclick and add proper event listener
            card.removeAttribute('onclick');
            
            // Add click event listener
            card.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                
                console.log('Specialist card clicked:', card);
                
                // Call the modal function
                if (typeof window.openSpecialistModal === 'function') {
                    window.openSpecialistModal(card);
                } else {
                    console.error('openSpecialistModal function not available');
                }
            });
        });
    }
    
    // Initialize immediately and also after a delay
    initSpecialistCards();
    setTimeout(initSpecialistCards, 500);
    setTimeout(initSpecialistCards, 1000);
});

// Access Dropdown functionality
(function() {
    'use strict';

    const accessDropdown = document.querySelector('.access-dropdown');
    const accessButton = document.getElementById('accessButton');
    const accessDropdownMenu = document.getElementById('accessDropdown');
    const soyClienteBtn = document.getElementById('soyClienteBtn');
    const soyEspecialistaBtn = document.getElementById('soyEspecialistaBtn');

    // Toggle access dropdown
    if (accessButton) {
        accessButton.addEventListener('click', function(e) {
            e.stopPropagation();
            accessDropdown.classList.toggle('active');
        });
    }

    // Handle "Soy Cliente" click
    if (soyClienteBtn) {
        soyClienteBtn.addEventListener('click', function(e) {
            e.preventDefault();
            accessDropdown.classList.remove('active');
            openClienteModal();
        });
    }

    // Handle "Soy Especialista" click
    if (soyEspecialistaBtn) {
        soyEspecialistaBtn.addEventListener('click', function(e) {
            e.preventDefault();
            accessDropdown.classList.remove('active');
            openEspecialistaModal();
        });
    }

    // Close dropdown when clicking outside
    document.addEventListener('click', function(e) {
        if (accessDropdown && !accessDropdown.contains(e.target)) {
            accessDropdown.classList.remove('active');
        }
    });
})();

// Open Cliente Modal - Make globally accessible
function openClienteModal() {
    const modal = document.getElementById('clienteModal');
    if (modal) {
        modal.classList.add('modal-active');
        document.body.style.overflow = 'hidden';
        // Show login form by default
        if (typeof switchFormTab === 'function') {
            switchFormTab('login');
        } else if (window.switchFormTab) {
            window.switchFormTab('login');
        }
    }
}
window.openClienteModal = openClienteModal;

// Close Cliente Modal - Make it globally accessible (multiple ways)
function closeClienteModal() {
    const modal = document.getElementById('clienteModal');
    if (modal) {
        modal.classList.remove('modal-active');
        document.body.style.overflow = '';
        // Reset forms
        const loginForm = document.getElementById('loginForm');
        const registerForm = document.getElementById('registerForm');
        if (loginForm) loginForm.reset();
        if (registerForm) registerForm.reset();
        // Reset to login tab
        if (typeof switchFormTab === 'function') {
            switchFormTab('login');
        } else if (window.switchFormTab) {
            window.switchFormTab('login');
        }
    }
}
// Make it available on window object as well
window.closeClienteModal = closeClienteModal;

// Form Tab Switching - Make it globally accessible
function switchFormTab(tabName) {
    console.log('Switching to tab:', tabName);
    const tabs = document.querySelectorAll('.form-tab');
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    
    // Update tabs
    tabs.forEach(tab => {
        if (tab.getAttribute('data-tab') === tabName) {
            tab.classList.add('active');
        } else {
            tab.classList.remove('active');
        }
    });
    
    // Show/hide forms based on tab
    if (tabName === 'login') {
        if (loginForm) {
            loginForm.classList.add('active-form');
            loginForm.style.display = 'block';
            console.log('Showing login form');
        }
        if (registerForm) {
            registerForm.classList.remove('active-form');
            registerForm.style.display = 'none';
            console.log('Hiding register form');
        }
    } else if (tabName === 'register') {
        if (registerForm) {
            registerForm.classList.add('active-form');
            registerForm.style.display = 'block';
            console.log('Showing register form');
        }
        if (loginForm) {
            loginForm.classList.remove('active-form');
            loginForm.style.display = 'none';
            console.log('Hiding login form');
        }
    }
}
// Make it globally accessible
window.switchFormTab = switchFormTab;

// Initialize form tabs and close button
(function() {
    'use strict';

    function initModalFeatures() {
        // Initialize form tabs
        const formTabs = document.querySelectorAll('.form-tab');
        
        if (formTabs.length > 0) {
            formTabs.forEach(tab => {
                // Remove existing listeners by cloning
                const newTab = tab.cloneNode(true);
                tab.parentNode.replaceChild(newTab, tab);
                
                newTab.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    const tabName = this.getAttribute('data-tab');
                    console.log('Tab clicked:', tabName);
                    if (window.switchFormTab) {
                        window.switchFormTab(tabName);
                    }
                });
            });
        }
        
        // Initialize close button with event listener (fallback)
        const closeBtn = document.querySelector('.modal-close');
        if (closeBtn) {
            // Remove existing listeners by cloning
            const newCloseBtn = closeBtn.cloneNode(true);
            closeBtn.parentNode.replaceChild(newCloseBtn, closeBtn);
            
            newCloseBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                console.log('Close button clicked via event listener');
                if (window.closeClienteModal) {
                    window.closeClienteModal();
                }
            });
        }
        
        // Initialize overlay click (fallback)
        const overlay = document.querySelector('.modal-overlay');
        if (overlay) {
            overlay.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                console.log('Overlay clicked');
                if (window.closeClienteModal) {
                    window.closeClienteModal();
                }
            });
        }
        
        // ESC key to close
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                const modal = document.getElementById('clienteModal');
                if (modal && modal.classList.contains('modal-active')) {
                    if (window.closeClienteModal) {
                        window.closeClienteModal();
                    }
                }
            }
        });
    }
    
    // Initialize when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initModalFeatures);
    } else {
        initModalFeatures();
    }
    
    // Fallback initialization
    setTimeout(initModalFeatures, 300);

    // Handle login form submission
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const email = document.getElementById('loginEmail').value;
            const password = document.getElementById('loginPassword').value;
            const remember = document.querySelector('#loginForm input[name="remember"]').checked;
            
            if (!email || !password) {
                alert('Por favor, completa todos los campos.');
                return;
            }
            
            // Show loading state
            const submitBtn = loginForm.querySelector('.form-submit');
            const originalText = submitBtn.textContent;
            submitBtn.disabled = true;
            submitBtn.textContent = 'Iniciando sesión...';
            
            // AJAX call to login
            fetch(nidfilAjax.ajaxurl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    action: 'nidfil_login',
                    email: email,
                    password: password,
                    remember: remember ? '1' : '0',
                    nonce: nidfilAjax.nonce
                })
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                if (data.success) {
                    // Show success message briefly
                    submitBtn.textContent = '¡Éxito! Redirigiendo...';
                    
                    // Close modal after a short delay
                    setTimeout(function() {
                        if (typeof closeClienteModal === 'function') {
                            closeClienteModal();
                        } else if (window.closeClienteModal) {
                            window.closeClienteModal();
                        }
                        
                        // Redirect to dashboard
                        let redirectUrl = null;
                        if (data.data && data.data.redirect_url) {
                            redirectUrl = data.data.redirect_url;
                        } else if (nidfilAjax && nidfilAjax.dashboard_url) {
                            redirectUrl = nidfilAjax.dashboard_url;
                        } else {
                            redirectUrl = '/client-profile/';
                        }
                        
                        // Ensure URL is absolute
                        if (redirectUrl && !redirectUrl.startsWith('http')) {
                            redirectUrl = window.location.origin + (redirectUrl.startsWith('/') ? '' : '/') + redirectUrl;
                        }
                        
                        console.log('Login - Redirecting to:', redirectUrl);
                        if (redirectUrl) {
                            window.location.href = redirectUrl;
                        } else {
                            window.location.href = '/client-profile/';
                        }
                    }, 500);
                } else {
                    // Show error message
                    const errorMsg = data.data && data.data.message ? data.data.message : 'Error al iniciar sesión';
                    alert(errorMsg);
                    submitBtn.disabled = false;
                    submitBtn.textContent = originalText;
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Error al iniciar sesión. Por favor, intenta de nuevo.');
                submitBtn.disabled = false;
                submitBtn.textContent = originalText;
            });
        });
    }

    // Handle register form submission
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const name = document.getElementById('registerName').value;
            const email = document.getElementById('registerEmail').value;
            const phone = document.getElementById('registerPhone').value;
            const password = document.getElementById('registerPassword').value;
            const passwordConfirm = document.getElementById('registerPasswordConfirm').value;
            const terms = document.querySelector('#registerForm input[name="terms"]').checked;
            
            // Validate required fields
            if (!name || !email || !password || !passwordConfirm) {
                alert('Por favor, completa todos los campos requeridos.');
                return;
            }
            
            // Validate terms checkbox
            if (!terms) {
                alert('Por favor, acepta los términos y condiciones para continuar.');
                return;
            }
            
            // Validate passwords match
            if (password !== passwordConfirm) {
                alert('Las contraseñas no coinciden');
                return;
            }
            
            // Validate password strength (optional - minimum 6 characters)
            if (password.length < 6) {
                alert('La contraseña debe tener al menos 6 caracteres.');
                return;
            }
            
            // Show loading state
            const submitBtn = registerForm.querySelector('.form-submit');
            const originalText = submitBtn.textContent;
            submitBtn.disabled = true;
            submitBtn.textContent = 'Registrando...';
            
            // AJAX call to register
            fetch(nidfilAjax.ajaxurl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    action: 'nidfil_register',
                    name: name,
                    email: email,
                    phone: phone,
                    password: password,
                    nonce: nidfilAjax.nonce
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Show success message
                    submitBtn.textContent = '¡Éxito! Redirigiendo...';
                    
                    // Close modal after short delay
                    setTimeout(function() {
                        if (typeof closeClienteModal === 'function') {
                            closeClienteModal();
                        } else if (window.closeClienteModal) {
                            window.closeClienteModal();
                        }
                        
                        // Redirect to dashboard
                        let redirectUrl = null;
                        if (data.data && data.data.redirect_url) {
                            redirectUrl = data.data.redirect_url;
                        } else if (nidfilAjax && nidfilAjax.dashboard_url) {
                            redirectUrl = nidfilAjax.dashboard_url;
                        } else {
                            redirectUrl = '/client-profile/';
                        }
                        
                        // Ensure URL is absolute
                        if (redirectUrl && !redirectUrl.startsWith('http')) {
                            redirectUrl = window.location.origin + (redirectUrl.startsWith('/') ? '' : '/') + redirectUrl;
                        }
                        
                        console.log('Redirecting to:', redirectUrl);
                        if (redirectUrl) {
                            window.location.href = redirectUrl;
                        } else {
                            // Fallback: reload page
                            window.location.reload();
                        }
                    }, 500);
                } else {
                    alert(data.data && data.data.message ? data.data.message : 'Error al registrarse');
                    submitBtn.disabled = false;
                    submitBtn.textContent = originalText;
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Error al registrarse. Por favor, intenta de nuevo.');
                submitBtn.disabled = false;
                submitBtn.textContent = originalText;
            });
        });
    }
})();

// Dashboard Functionality
(function() {
    'use strict';

    // Only run on dashboard/client profile pages
    if (!document.querySelector('.dashboard-main') && !document.querySelector('.dashboard-container')) {
        return;
    }
    
    // Wait for DOM to be fully loaded
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function() {
            initDashboardFeatures();
        });
    } else {
        initDashboardFeatures();
    }
})();

function initDashboardFeatures() {
    'use strict';

    console.log('Initializing dashboard features...'); // Debug

    // Navigation between sections
    const navItems = document.querySelectorAll('.nav-item');
    const sections = document.querySelectorAll('.dashboard-section');
    
    console.log('Found nav items:', navItems.length); // Debug
    console.log('Found sections:', sections.length); // Debug

    function switchSection(sectionName) {
        if (!sectionName) {
            console.error('No section name provided');
            return;
        }
        
        const sectionId = sectionName + 'Section';
        console.log('Switching to section ID:', sectionId); // Debug
        
        // Update active nav item
        navItems.forEach(nav => {
            const navSection = nav.getAttribute('data-section');
            if (navSection === sectionName) {
                nav.classList.add('active');
            } else {
                nav.classList.remove('active');
            }
        });
        
        // Hide all sections first
        sections.forEach(section => {
            section.classList.remove('active');
            section.style.display = 'none';
        });
        
        // Show target section
        const targetSection = document.getElementById(sectionId);
        if (targetSection) {
            targetSection.classList.add('active');
            targetSection.style.display = 'block';
            console.log('Section activated:', sectionId); // Debug
            // Smooth scroll to top
            setTimeout(() => {
                window.scrollTo({ top: 0, behavior: 'smooth' });
            }, 100);
        } else {
            console.error('Section not found:', sectionId);
        }
    }

    // Add click handlers to navigation items - Direct approach
    if (navItems.length > 0) {
        navItems.forEach((item, index) => {
            // Remove any existing listeners by cloning
            const newItem = item.cloneNode(true);
            item.parentNode.replaceChild(newItem, item);
            
            // Add fresh event listener
            newItem.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                const sectionName = this.getAttribute('data-section');
                console.log('Nav clicked - Section:', sectionName); // Debug
                if (sectionName) {
                    switchSection(sectionName);
                }
                return false;
            });
        });
    } else {
        console.warn('No navigation items found');
    }
    
    // Alternative: Use event delegation on the nav container
    const navContainer = document.querySelector('.dashboard-nav');
    if (navContainer) {
        navContainer.addEventListener('click', function(e) {
            const clickedItem = e.target.closest('.nav-item');
            if (clickedItem) {
                e.preventDefault();
                e.stopPropagation();
                const sectionName = clickedItem.getAttribute('data-section');
                console.log('Delegation - Section:', sectionName); // Debug
                if (sectionName) {
                    switchSection(sectionName);
                }
                return false;
            }
        }, true);
    }

    // Handle nav-link clicks (like view-all-link) using event delegation
    document.addEventListener('click', function(e) {
        const navLink = e.target.closest('.nav-link');
        if (navLink) {
            e.preventDefault();
            const sectionName = navLink.getAttribute('data-section');
            if (sectionName) {
                switchSection(sectionName);
            }
        }
    });

    // Also use event delegation for nav-items as fallback
    document.addEventListener('click', function(e) {
        const navItem = e.target.closest('.nav-item');
        if (navItem && !navItem.classList.contains('active')) {
            e.preventDefault();
            e.stopPropagation();
            const sectionName = navItem.getAttribute('data-section');
            if (sectionName) {
                console.log('Event delegation triggered for:', sectionName); // Debug
                switchSection(sectionName);
            }
        }
    }, true);

    // Projects Filter Functionality
    const filterBtns = document.querySelectorAll('.filter-btn');
    const projectCards = document.querySelectorAll('.project-card');

    if (filterBtns.length > 0) {
        filterBtns.forEach(btn => {
            btn.addEventListener('click', function() {
                const filter = this.getAttribute('data-filter');
                
                // Update active filter button
                filterBtns.forEach(b => b.classList.remove('active'));
                this.classList.add('active');
                
                // Filter projects
                projectCards.forEach(card => {
                    if (filter === 'all' || card.getAttribute('data-status') === filter) {
                        card.style.display = 'block';
                        setTimeout(() => {
                            card.style.opacity = '1';
                            card.style.transform = 'translateY(0)';
                        }, 10);
                    } else {
                        card.style.opacity = '0';
                        card.style.transform = 'translateY(-10px)';
                        setTimeout(() => {
                            card.style.display = 'none';
                        }, 300);
                    }
                });
            });
        });
    }

    // Mark All Notifications as Read
    const markAllReadBtn = document.getElementById('markAllReadBtn');
    const notificationItems = document.querySelectorAll('.notification-item.unread');

    if (markAllReadBtn) {
        markAllReadBtn.addEventListener('click', function() {
            notificationItems.forEach(item => {
                item.classList.remove('unread');
                const dot = item.querySelector('.notification-dot');
                if (dot) {
                    dot.remove();
                }
            });
            
            // Update badge
            const notificationsBadge = document.getElementById('notificationsBadge');
            if (notificationsBadge) {
                notificationsBadge.textContent = '0';
                notificationsBadge.classList.remove('badge-new');
            }
            
            alert('Todas las notificaciones han sido marcadas como leídas.');
        });
    }

    // Main Edit Profile Button - Opens all edit modes
    const editProfileBtn = document.getElementById('editProfileBtn');
    if (editProfileBtn) {
        editProfileBtn.addEventListener('click', function() {
            // Trigger bio edit
            if (editBioBtn) {
                editBioBtn.click();
            }
            // Trigger personal info edit
            if (editInfoBtn) {
                editInfoBtn.click();
            }
        });
    }

    // Profile Image Upload
    const editImageBtn = document.getElementById('editImageBtn');
    const profileImageInput = document.getElementById('profileImageInput');
    const profileImage = document.getElementById('profileImage');
    const imageUploadActions = document.getElementById('imageUploadActions');
    const saveImageBtn = document.getElementById('saveImageBtn');
    const cancelImageBtn = document.getElementById('cancelImageBtn');
    
    // Debug: Check if elements exist
    console.log('Profile image elements:', {
        editImageBtn: !!editImageBtn,
        profileImageInput: !!profileImageInput,
        profileImage: !!profileImage,
        imageUploadActions: !!imageUploadActions,
        saveImageBtn: !!saveImageBtn,
        cancelImageBtn: !!cancelImageBtn
    });
    
    let selectedImageFile = null;
    let originalImageSrc = profileImage ? profileImage.src : '';

    if (editImageBtn && profileImageInput) {
        editImageBtn.addEventListener('click', function() {
            profileImageInput.click();
        });

        profileImageInput.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                // Validate file type
                if (!file.type.match('image.*')) {
                    alert('Por favor, selecciona una imagen válida.');
                    return;
                }
                
                // Validate file size (max 5MB)
                if (file.size > 5 * 1024 * 1024) {
                    alert('La imagen es demasiado grande. Por favor, selecciona una imagen menor a 5MB.');
                    return;
                }
                
                selectedImageFile = file;
                const reader = new FileReader();
                reader.onload = function(e) {
                    if (profileImage) {
                        profileImage.src = e.target.result;
                    }
                    // Show save/cancel buttons
                    if (imageUploadActions) {
                        imageUploadActions.style.display = 'flex';
                        imageUploadActions.style.visibility = 'visible';
                        imageUploadActions.classList.add('show');
                        console.log('Image selected - showing save/cancel buttons');
                    } else {
                        console.error('imageUploadActions element not found in DOM');
                    }
                };
                reader.readAsDataURL(file);
            }
        });
    } else {
        console.log('Edit image button or input not found');
    }

    // Save image
    if (saveImageBtn) {
        saveImageBtn.addEventListener('click', function() {
            if (!selectedImageFile) {
                alert('Por favor, selecciona una imagen primero.');
                return;
            }

            // Show loading state
            const originalText = saveImageBtn.innerHTML;
            saveImageBtn.disabled = true;
            saveImageBtn.innerHTML = '<svg width="16" height="16" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="10" cy="10" r="8" stroke="currentColor" stroke-width="2"/><path d="M10 6V10L13 13" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg> Guardando...';

            // Create FormData for file upload
            const formData = new FormData();
            formData.append('action', 'nidfil_save_profile_image');
            formData.append('profile_image', selectedImageFile);
            formData.append('nonce', nidfilAjax.nonce);

            // Upload image via AJAX
            fetch(nidfilAjax.ajaxurl, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Update image source if new URL provided
                    if (data.data && data.data.image_url) {
                        profileImage.src = data.data.image_url;
                        // Add cache busting to ensure new image loads
                        profileImage.src = data.data.image_url + '?t=' + new Date().getTime();
                    }
                    // Hide save/cancel buttons
                    if (imageUploadActions) {
                        imageUploadActions.style.display = 'none';
                        imageUploadActions.classList.remove('show');
                    }
                    // Reset file input
                    profileImageInput.value = '';
                    selectedImageFile = null;
                    originalImageSrc = profileImage.src;
                    
                    // Show success message briefly
                    const successMsg = data.data && data.data.message ? data.data.message : 'Imagen de perfil actualizada correctamente.';
                    alert(successMsg);
                } else {
                    const errorMsg = data.data && data.data.message ? data.data.message : 'Error al guardar la imagen.';
                    alert(errorMsg);
                    // Restore original image
                    profileImage.src = originalImageSrc;
                }
                saveImageBtn.disabled = false;
                saveImageBtn.innerHTML = originalText;
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Error al guardar la imagen. Por favor, intenta de nuevo.');
                // Restore original image
                profileImage.src = originalImageSrc;
                saveImageBtn.disabled = false;
                saveImageBtn.innerHTML = originalText;
            });
        });
    }

    // Cancel image upload
    if (cancelImageBtn) {
        cancelImageBtn.addEventListener('click', function() {
            // Restore original image
            profileImage.src = originalImageSrc;
            // Hide save/cancel buttons
            if (imageUploadActions) {
                imageUploadActions.style.display = 'none';
                imageUploadActions.classList.remove('show');
            }
            // Reset file input
            profileImageInput.value = '';
            selectedImageFile = null;
        });
    }

    // Bio Edit Functionality
    const editBioBtn = document.getElementById('editBioBtn');
    const bioText = document.getElementById('bioText');
    const bioEditForm = document.getElementById('bioEditForm');
    const bioTextarea = document.getElementById('bioTextarea');
    const saveBioBtn = document.getElementById('saveBioBtn');
    const cancelBioBtn = document.getElementById('cancelBioBtn');

    if (editBioBtn) {
        editBioBtn.addEventListener('click', function() {
            const currentBio = bioText.textContent.trim();
            const defaultText = 'Aún no has agregado una biografía. Haz clic en editar para agregar una.';
            bioText.style.display = 'none';
            bioEditForm.style.display = 'block';
            // Set the actual bio text, not the default message
            if (currentBio !== defaultText) {
                bioTextarea.value = currentBio;
            } else {
                bioTextarea.value = '';
            }
            bioTextarea.focus();
        });
    }

    if (saveBioBtn) {
        saveBioBtn.addEventListener('click', function(e) {
            e.preventDefault();
            const newBio = bioTextarea.value.trim();
            
            // Show loading state
            const originalText = saveBioBtn.textContent;
            saveBioBtn.disabled = true;
            saveBioBtn.textContent = 'Guardando...';
            
            // Save bio via AJAX
            fetch(nidfilAjax.ajaxurl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    action: 'nidfil_save_bio',
                    bio: newBio,
                    nonce: nidfilAjax.nonce
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    bioText.textContent = newBio || 'Aún no has agregado una biografía. Haz clic en editar para agregar una.';
                    bioText.style.display = 'block';
                    bioEditForm.style.display = 'none';
                    alert('Biografía guardada correctamente.');
                } else {
                    alert(data.data && data.data.message ? data.data.message : 'Error al guardar la biografía.');
                }
                saveBioBtn.disabled = false;
                saveBioBtn.textContent = originalText;
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Error al guardar la biografía. Por favor, intenta de nuevo.');
                saveBioBtn.disabled = false;
                saveBioBtn.textContent = originalText;
            });
        });
    }

    if (cancelBioBtn) {
        cancelBioBtn.addEventListener('click', function(e) {
            e.preventDefault();
            bioText.style.display = 'block';
            bioEditForm.style.display = 'none';
        });
    }

    // Personal Information Edit
    const editInfoBtn = document.getElementById('editInfoBtn');
    const infoFormActions = document.getElementById('infoFormActions');
    const saveInfoBtn = document.getElementById('saveInfoBtn');
    const cancelInfoBtn = document.getElementById('cancelInfoBtn');

    const infoFields = {
        fullName: { value: 'fullNameValue', input: 'fullNameInput' },
        email: { value: 'emailValue', input: 'emailInput' },
        phone: { value: 'phoneValue', input: 'phoneInput' },
        location: { value: 'locationValue', input: 'locationInput' }
    };

    if (editInfoBtn) {
        editInfoBtn.addEventListener('click', function() {
            Object.keys(infoFields).forEach(key => {
                const valueEl = document.getElementById(infoFields[key].value);
                const inputEl = document.getElementById(infoFields[key].input);
                if (valueEl && inputEl) {
                    valueEl.style.display = 'none';
                    inputEl.style.display = 'block';
                    if (!inputEl.value && valueEl.textContent !== 'No agregado') {
                        inputEl.value = valueEl.textContent;
                    }
                }
            });
            infoFormActions.style.display = 'flex';
        });
    }

    if (saveInfoBtn) {
        saveInfoBtn.addEventListener('click', function(e) {
            e.preventDefault();
            const data = {};
            
            Object.keys(infoFields).forEach(key => {
                const inputEl = document.getElementById(infoFields[key].input);
                if (inputEl) {
                    data[key] = inputEl.value.trim();
                }
            });
            
            // Show loading state
            const originalText = saveInfoBtn.textContent;
            saveInfoBtn.disabled = true;
            saveInfoBtn.textContent = 'Guardando...';
            
            // Save personal info via AJAX
            fetch(nidfilAjax.ajaxurl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    action: 'nidfil_save_personal_info',
                    full_name: data.fullName || '',
                    email: data.email || '',
                    phone: data.phone || '',
                    location: data.location || '',
                    nonce: nidfilAjax.nonce
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Update display values
                    Object.keys(infoFields).forEach(key => {
                        const inputEl = document.getElementById(infoFields[key].input);
                        const valueEl = document.getElementById(infoFields[key].value);
                        if (inputEl && valueEl) {
                            const value = inputEl.value.trim();
                            valueEl.textContent = value || 'No agregado';
                            valueEl.style.display = 'block';
                            inputEl.style.display = 'none';
                        }
                    });
                    
                    infoFormActions.style.display = 'none';
                    
                    // Update profile name if full name changed
                    const fullNameInput = document.getElementById('fullNameInput');
                    if (fullNameInput) {
                        const profileName = document.getElementById('profileName');
                        if (profileName) {
                            profileName.textContent = fullNameInput.value.trim();
                        }
                    }
                    
                    alert('Información guardada correctamente.');
                } else {
                    alert(data.data && data.data.message ? data.data.message : 'Error al guardar la información.');
                }
                saveInfoBtn.disabled = false;
                saveInfoBtn.textContent = originalText;
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Error al guardar la información. Por favor, intenta de nuevo.');
                saveInfoBtn.disabled = false;
                saveInfoBtn.textContent = originalText;
            });
        });
    }

    if (cancelInfoBtn) {
        cancelInfoBtn.addEventListener('click', function(e) {
            e.preventDefault();
            Object.keys(infoFields).forEach(key => {
                const valueEl = document.getElementById(infoFields[key].value);
                const inputEl = document.getElementById(infoFields[key].input);
                if (valueEl && inputEl) {
                    valueEl.style.display = 'block';
                    inputEl.style.display = 'none';
                }
            });
            infoFormActions.style.display = 'none';
        });
    }

    // Skills Edit Functionality
    const editSkillsBtn = document.getElementById('editSkillsBtn');
    const skillsContainer = document.getElementById('skillsContainer');
    const skillsEditForm = document.getElementById('skillsEditForm');
    const skillsInput = document.getElementById('skillsInput');
    const saveSkillsBtn = document.getElementById('saveSkillsBtn');
    const cancelSkillsBtn = document.getElementById('cancelSkillsBtn');

    if (editSkillsBtn) {
        editSkillsBtn.addEventListener('click', function() {
            const currentSkills = Array.from(skillsContainer.querySelectorAll('.skill-tag'))
                .map(tag => tag.textContent.trim())
                .join(', ');
            skillsContainer.style.display = 'none';
            skillsEditForm.style.display = 'block';
            if (skillsInput) {
                skillsInput.value = currentSkills;
                skillsInput.focus();
            }
        });
    }

    if (saveSkillsBtn && skillsInput) {
        saveSkillsBtn.addEventListener('click', function(e) {
            e.preventDefault();
            const skills = skillsInput.value.trim();
            
            const originalText = saveSkillsBtn.textContent;
            saveSkillsBtn.disabled = true;
            saveSkillsBtn.textContent = 'Guardando...';
            
            fetch(nidfilAjax.ajaxurl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    action: 'nidfil_save_skills',
                    skills: skills,
                    nonce: nidfilAjax.nonce
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Update skills display
                    skillsContainer.innerHTML = '';
                    if (skills) {
                        const skillsArray = skills.split(',').map(s => s.trim()).filter(s => s);
                        skillsArray.forEach(skill => {
                            const tag = document.createElement('span');
                            tag.className = 'skill-tag';
                            tag.textContent = skill;
                            skillsContainer.appendChild(tag);
                        });
                    } else {
                        skillsContainer.innerHTML = '<p class="empty-state">No has agregado habilidades aún. Haz clic en editar para agregar.</p>';
                    }
                    skillsContainer.style.display = 'flex';
                    skillsEditForm.style.display = 'none';
                    alert('Habilidades guardadas correctamente.');
                } else {
                    alert(data.data && data.data.message ? data.data.message : 'Error al guardar las habilidades.');
                }
                saveSkillsBtn.disabled = false;
                saveSkillsBtn.textContent = originalText;
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Error al guardar las habilidades. Por favor, intenta de nuevo.');
                saveSkillsBtn.disabled = false;
                saveSkillsBtn.textContent = originalText;
            });
        });
    }

    if (cancelSkillsBtn) {
        cancelSkillsBtn.addEventListener('click', function(e) {
            e.preventDefault();
            skillsContainer.style.display = 'flex';
            skillsEditForm.style.display = 'none';
        });
    }

    // Social Media Edit Functionality
    const editSocialBtn = document.getElementById('editSocialBtn');
    const socialFormActions = document.getElementById('socialFormActions');
    const saveSocialBtn = document.getElementById('saveSocialBtn');
    const cancelSocialBtn = document.getElementById('cancelSocialBtn');

    const socialFields = {
        facebook: { value: 'facebookValue', input: 'facebookInput' },
        twitter: { value: 'twitterValue', input: 'twitterInput' },
        instagram: { value: 'instagramValue', input: 'instagramInput' },
        linkedin: { value: 'linkedinValue', input: 'linkedinInput' }
    };

    if (editSocialBtn) {
        editSocialBtn.addEventListener('click', function() {
            Object.keys(socialFields).forEach(key => {
                const valueEl = document.getElementById(socialFields[key].value);
                const inputEl = document.getElementById(socialFields[key].input);
                if (valueEl && inputEl) {
                    valueEl.style.display = 'none';
                    inputEl.style.display = 'block';
                    if (!inputEl.value && valueEl.textContent !== 'No agregado') {
                        inputEl.value = valueEl.textContent;
                    }
                }
            });
            if (socialFormActions) {
                socialFormActions.style.display = 'flex';
            }
        });
    }

    if (saveSocialBtn) {
        saveSocialBtn.addEventListener('click', function(e) {
            e.preventDefault();
            const data = {};
            
            Object.keys(socialFields).forEach(key => {
                const inputEl = document.getElementById(socialFields[key].input);
                if (inputEl) {
                    data[key] = inputEl.value.trim();
                }
            });
            
            const originalText = saveSocialBtn.textContent;
            saveSocialBtn.disabled = true;
            saveSocialBtn.textContent = 'Guardando...';
            
            fetch(nidfilAjax.ajaxurl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    action: 'nidfil_save_social_links',
                    facebook: data.facebook || '',
                    twitter: data.twitter || '',
                    instagram: data.instagram || '',
                    linkedin: data.linkedin || '',
                    nonce: nidfilAjax.nonce
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    Object.keys(socialFields).forEach(key => {
                        const inputEl = document.getElementById(socialFields[key].input);
                        const valueEl = document.getElementById(socialFields[key].value);
                        if (inputEl && valueEl) {
                            const value = inputEl.value.trim();
                            valueEl.textContent = value || 'No agregado';
                            valueEl.style.display = 'block';
                            inputEl.style.display = 'none';
                        }
                    });
                    if (socialFormActions) {
                        socialFormActions.style.display = 'none';
                    }
                    alert('Redes sociales guardadas correctamente.');
                } else {
                    alert(data.data && data.data.message ? data.data.message : 'Error al guardar las redes sociales.');
                }
                saveSocialBtn.disabled = false;
                saveSocialBtn.textContent = originalText;
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Error al guardar las redes sociales. Por favor, intenta de nuevo.');
                saveSocialBtn.disabled = false;
                saveSocialBtn.textContent = originalText;
            });
        });
    }

    if (cancelSocialBtn) {
        cancelSocialBtn.addEventListener('click', function(e) {
            e.preventDefault();
            Object.keys(socialFields).forEach(key => {
                const valueEl = document.getElementById(socialFields[key].value);
                const inputEl = document.getElementById(socialFields[key].input);
                if (valueEl && inputEl) {
                    valueEl.style.display = 'block';
                    inputEl.style.display = 'none';
                }
            });
            if (socialFormActions) {
                socialFormActions.style.display = 'none';
            }
        });
    }

    // Messages Functionality
    const messageInput = document.getElementById('messageInput');
    const sendMessageBtn = document.getElementById('sendMessageBtn');
    const chatMessages = document.getElementById('chatMessages');

    function addMessage(text, isSent = true) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${isSent ? 'sent' : 'received'}`;
        const now = new Date();
        const time = now.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' });
        messageDiv.innerHTML = `
            <p>${text}</p>
            <span class="message-time">${time}</span>
        `;
        chatMessages.appendChild(messageDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    if (sendMessageBtn && messageInput) {
        sendMessageBtn.addEventListener('click', function() {
            const message = messageInput.value.trim();
            if (message) {
                addMessage(message, true);
                messageInput.value = '';
                // Add AJAX call to send message
                // sendMessage(message);
            }
        });

        messageInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                sendMessageBtn.click();
            }
        });
    }

    // Reviews Functionality
    const addReviewBtn = document.getElementById('addReviewBtn');
    const addReviewModal = document.getElementById('addReviewModal');
    const addReviewForm = document.getElementById('addReviewForm');
    const ratingInput = document.getElementById('ratingInput');
    const selectedRating = document.getElementById('selectedRating');
    const ratingStars = ratingInput ? ratingInput.querySelectorAll('.rating-star') : [];

    // Rating star interaction
    ratingStars.forEach(star => {
        star.addEventListener('click', function() {
            const rating = parseInt(this.getAttribute('data-rating'));
            selectedRating.value = rating;
            
            ratingStars.forEach((s, index) => {
                if (index < rating) {
                    s.classList.add('active');
                    s.querySelector('path').setAttribute('fill', '#FFD700');
                } else {
                    s.classList.remove('active');
                    s.querySelector('path').setAttribute('fill', '#E5E5E5');
                }
            });
        });

        star.addEventListener('mouseenter', function() {
            const rating = parseInt(this.getAttribute('data-rating'));
            ratingStars.forEach((s, index) => {
                if (index < rating) {
                    s.querySelector('path').setAttribute('fill', '#FFD700');
                }
            });
        });
    });

    if (ratingInput) {
        ratingInput.addEventListener('mouseleave', function() {
            const currentRating = parseInt(selectedRating.value) || 0;
            ratingStars.forEach((s, index) => {
                if (index < currentRating) {
                    s.querySelector('path').setAttribute('fill', '#FFD700');
                } else {
                    s.querySelector('path').setAttribute('fill', '#E5E5E5');
                }
            });
        });
    }

    if (addReviewBtn) {
        addReviewBtn.addEventListener('click', function() {
            if (addReviewModal) {
                addReviewModal.classList.add('modal-active');
                document.body.style.overflow = 'hidden';
            }
        });
    }

    if (addReviewForm) {
        addReviewForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const rating = selectedRating.value;
            const reviewText = document.getElementById('reviewText').value;
            
            if (!rating || rating === '0') {
                alert('Por favor, selecciona una calificación');
                return;
            }
            
            // Add review to list
            addReviewToList(rating, reviewText);
            
            // Close modal
            closeAddReviewModal();
            
            // Add AJAX call to save review
            // saveReview({ rating, review: reviewText });
        });
    }

    function addReviewToList(rating, text) {
        const reviewsList = document.getElementById('reviewsList');
        if (!reviewsList) return;
        
        const reviewCard = document.createElement('div');
        reviewCard.className = 'review-card';
        const now = new Date();
        const dateStr = 'Hace unos momentos';
        
        let starsHtml = '';
        for (let i = 1; i <= 5; i++) {
            const filled = i <= rating ? 'filled' : 'empty';
            starsHtml += `
                <svg width="16" height="16" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" class="star ${filled}">
                    <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="${i <= rating ? '#FFD700' : '#E5E5E5'}"/>
                </svg>
            `;
        }
        
        reviewCard.innerHTML = `
            <div class="review-header">
                <div class="reviewer-info">
                    <div class="reviewer-avatar">TU</div>
                    <div>
                        <h4>Tú</h4>
                        <div class="review-rating editable-rating" data-rating="${rating}">
                            ${starsHtml}
                        </div>
                    </div>
                </div>
                <button class="icon-btn edit-review-btn">
                    <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M13.5 2.5L15.5 4.5M14 1L17 4L9 12H6V9L14 1Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                </button>
            </div>
            <p class="review-text">${text}</p>
            <span class="review-date">${dateStr}</span>
        `;
        
        reviewsList.insertBefore(reviewCard, reviewsList.firstChild);
    }

    // Editable rating in review cards
    document.addEventListener('click', function(e) {
        if (e.target.closest('.editable-rating .star')) {
            const ratingContainer = e.target.closest('.editable-rating');
            const stars = ratingContainer.querySelectorAll('.star');
            const clickedStar = e.target.closest('.star');
            const newRating = Array.from(stars).indexOf(clickedStar) + 1;
            
            ratingContainer.setAttribute('data-rating', newRating);
            
            stars.forEach((star, index) => {
                if (index < newRating) {
                    star.classList.add('filled');
                    star.classList.remove('empty');
                    star.querySelector('path').setAttribute('fill', '#FFD700');
                } else {
                    star.classList.add('empty');
                    star.classList.remove('filled');
                    star.querySelector('path').setAttribute('fill', '#E5E5E5');
                }
            });
            
            // Add AJAX call to update rating
            // updateReviewRating(ratingContainer.closest('.review-card'), newRating);
        }
    });
}

// Close Add Review Modal
function closeAddReviewModal() {
    const modal = document.getElementById('addReviewModal');
    if (modal) {
        modal.classList.remove('modal-active');
        document.body.style.overflow = '';
        // Reset form
        const form = document.getElementById('addReviewForm');
        if (form) {
            form.reset();
            const ratingStars = document.querySelectorAll('#ratingInput .rating-star');
            ratingStars.forEach(star => {
                star.classList.remove('active');
                star.querySelector('path').setAttribute('fill', '#E5E5E5');
            });
            document.getElementById('selectedRating').value = '0';
        }
    }
}

/**
 * Messaging System
 */
(function() {
    'use strict';
    
    let currentConversationId = null;
    let messagePollInterval = null;
    let currentReceiverId = null;
    
    // Initialize messaging when messages section is active
    function initMessaging() {
        const messagesSection = document.getElementById('messagesSection');
        if (!messagesSection) return;
        
        // Load conversations
        loadConversations();
        
        // Setup event listeners
        setupMessageListeners();
        
        // Start polling for new messages
        startMessagePolling();
    }
    
    // Load conversations list
    function loadConversations() {
        if (!window.nidfilAjax) {
            console.error('nidfilAjax not available');
            return;
        }
        
        fetch(nidfilAjax.ajaxurl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: new URLSearchParams({
                action: 'nidfil_get_conversations',
                nonce: nidfilAjax.nonce
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success && data.data.conversations) {
                renderConversations(data.data.conversations);
            }
        })
        .catch(error => {
            console.error('Error loading conversations:', error);
        });
    }
    
    // Render conversations list
    function renderConversations(conversations) {
        const conversationsList = document.getElementById('conversationsList');
        if (!conversationsList) return;
        
        if (conversations.length === 0) {
            conversationsList.innerHTML = '<div class="no-conversations">No hay conversaciones aún</div>';
            return;
        }
        
        conversationsList.innerHTML = conversations.map(conv => {
            const avatar = conv.other_user_name ? conv.other_user_name.charAt(0).toUpperCase() : '?';
            const timeAgo = formatTimeAgo(conv.last_message_time);
            const preview = conv.last_message_type === 'image' ? '📷 Imagen' : 
                           conv.last_message_type === 'document' ? '📄 Documento' : 
                           (conv.last_message || 'Sin mensajes');
            const unreadBadge = conv.unread_count > 0 ? `<span class="unread-badge">${conv.unread_count}</span>` : '';
            
            return `
                <div class="conversation-item" data-conversation-id="${conv.conversation_id}" data-user-id="${conv.other_user_id}">
                    <div class="conversation-avatar">${avatar}</div>
                    <div class="conversation-info">
                        <div class="conversation-header">
                            <span class="conversation-name">${conv.other_user_name}</span>
                            <span class="conversation-time">${timeAgo}</span>
                        </div>
                        <p class="conversation-preview">${preview}</p>
                    </div>
                    ${unreadBadge}
                </div>
            `;
        }).join('');
        
        // Add click listeners
        conversationsList.querySelectorAll('.conversation-item').forEach(item => {
            item.addEventListener('click', function() {
                const conversationId = this.getAttribute('data-conversation-id');
                const userId = this.getAttribute('data-user-id');
                openConversation(conversationId, userId);
            });
        });
    }
    
    // Open conversation - Make globally accessible
    window.openConversation = function(conversationId, receiverId) {
        currentConversationId = conversationId;
        currentReceiverId = receiverId;
        
        // Update active conversation item
        document.querySelectorAll('.conversation-item').forEach(item => {
            item.classList.remove('active');
            if (item.getAttribute('data-conversation-id') === conversationId) {
                item.classList.add('active');
            }
        });
        
        // Load messages
        loadMessages(conversationId);
        
        // Update chat header
        const conversationItem = document.querySelector(`[data-conversation-id="${conversationId}"]`);
        if (conversationItem) {
            const userName = conversationItem.querySelector('.conversation-name').textContent;
            const avatar = conversationItem.querySelector('.conversation-avatar').textContent;
            
            const chatHeader = document.querySelector('.chat-header');
            if (chatHeader) {
                chatHeader.querySelector('.chat-avatar').textContent = avatar;
                chatHeader.querySelector('h3').textContent = userName;
            }
        }
    };
    
    // Open conversation (local function)
    function openConversation(conversationId, receiverId) {
        window.openConversation(conversationId, receiverId);
    }
    
    // Load messages for a conversation
    function loadMessages(conversationId) {
        if (!window.nidfilAjax) return;
        
        fetch(nidfilAjax.ajaxurl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: new URLSearchParams({
                action: 'nidfil_get_messages',
                conversation_id: conversationId,
                nonce: nidfilAjax.nonce
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success && data.data.messages) {
                renderMessages(data.data.messages);
            }
        })
        .catch(error => {
            console.error('Error loading messages:', error);
        });
    }
    
    // Render messages
    function renderMessages(messages) {
        const chatMessages = document.getElementById('chatMessages');
        if (!chatMessages) return;
        
        const currentUserId = window.nidfilAjax?.current_user_id || 0;
        
        chatMessages.innerHTML = messages.map(msg => {
            const isSent = parseInt(msg.sender_id) === parseInt(currentUserId);
            const messageClass = isSent ? 'sent' : 'received';
            const time = formatMessageTime(msg.created_at);
            
            let messageContent = '';
            if (msg.message_type === 'image') {
                messageContent = `<img src="${msg.file_url}" alt="${msg.file_name || 'Image'}" class="message-image" onclick="window.open('${msg.file_url}', '_blank')">`;
            } else if (msg.message_type === 'document') {
                messageContent = `
                    <div class="message-document">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M14 2H6C5.46957 2 4.96086 2.21071 4.58579 2.58579C4.21071 2.96086 4 3.46957 4 4V20C4 20.5304 4.21071 21.0391 4.58579 21.4142C4.96086 21.7893 5.46957 22 6 22H18C18.5304 22 19.0391 21.7893 19.4142 21.4142C19.7893 21.0391 20 20.5304 20 20V8L14 2Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M14 2V8H20" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                        <div>
                            <p class="document-name">${msg.file_name || 'Documento'}</p>
                            <p class="document-size">${formatFileSize(msg.file_size)}</p>
                        </div>
                        <a href="${msg.file_url}" target="_blank" class="download-btn">Descargar</a>
                    </div>
                `;
            } else {
                messageContent = `<p>${escapeHtml(msg.message_text)}</p>`;
            }
            
            return `
                <div class="message ${messageClass}">
                    ${messageContent}
                    <span class="message-time">${time}</span>
                </div>
            `;
        }).join('');
        
        // Scroll to bottom
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
    
    // Setup message event listeners
    function setupMessageListeners() {
        const sendBtn = document.getElementById('sendMessageBtn');
        const messageInput = document.getElementById('messageInput');
        const fileInput = document.getElementById('messageFileInput');
        const attachBtn = document.getElementById('attachFileBtn');
        
        // Send message on button click
        if (sendBtn) {
            sendBtn.addEventListener('click', sendMessage);
        }
        
        // Send message on Enter key
        if (messageInput) {
            messageInput.addEventListener('keypress', function(e) {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    sendMessage();
                }
            });
        }
        
        // File upload
        if (attachBtn && fileInput) {
            attachBtn.addEventListener('click', function() {
                fileInput.click();
            });
            
            fileInput.addEventListener('change', function(e) {
                if (e.target.files.length > 0) {
                    uploadFile(e.target.files[0]);
                }
            });
        }
    }
    
    // Send message
    function sendMessage() {
        if (!currentConversationId || !currentReceiverId) {
            alert('Por favor, selecciona una conversación primero.');
            return;
        }
        
        const messageInput = document.getElementById('messageInput');
        const messageText = messageInput ? messageInput.value.trim() : '';
        
        if (!messageText && !pendingFile) {
            return;
        }
        
        if (!window.nidfilAjax) {
            console.error('nidfilAjax not available');
            return;
        }
        
        const formData = new FormData();
        formData.append('action', 'nidfil_send_message');
        formData.append('nonce', nidfilAjax.nonce);
        formData.append('receiver_id', currentReceiverId);
        formData.append('message_text', messageText);
        
        if (pendingFile) {
            formData.append('message_type', pendingFile.type);
            formData.append('file_url', pendingFile.url);
            formData.append('file_name', pendingFile.name);
            formData.append('file_size', pendingFile.size);
            pendingFile = null;
        }
        
        fetch(nidfilAjax.ajaxurl, {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                if (messageInput) {
                    messageInput.value = '';
                    messageInput.disabled = false;
                }
                pendingFile = null;
                loadMessages(currentConversationId);
                loadConversations(); // Refresh conversations list
            } else {
                alert(data.data?.message || 'Error al enviar el mensaje');
                if (messageInput) messageInput.disabled = false;
                pendingFile = null;
            }
        })
        .catch(error => {
            console.error('Error sending message:', error);
            alert('Error al enviar el mensaje');
        });
    }
    
    let pendingFile = null;
    
    // Upload file
    function uploadFile(file) {
        if (!window.nidfilAjax) return;
        
        const formData = new FormData();
        formData.append('action', 'nidfil_upload_message_file');
        formData.append('nonce', nidfilAjax.nonce);
        formData.append('file', file);
        
        // Show loading indicator
        const attachBtn = document.getElementById('attachFileBtn');
        if (attachBtn) {
            attachBtn.disabled = true;
            attachBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
        }
        
        fetch(nidfilAjax.ajaxurl, {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (attachBtn) {
                attachBtn.disabled = false;
                attachBtn.innerHTML = '<i class="fas fa-paperclip"></i>';
            }
            
            if (data.success) {
                pendingFile = {
                    type: data.data.file_type,
                    url: data.data.file_url,
                    name: data.data.file_name,
                    size: data.data.file_size
                };
                
                // Add file preview to input
                const messageInput = document.getElementById('messageInput');
                if (messageInput) {
                    messageInput.value = data.data.file_name;
                    messageInput.disabled = true;
                }
                
                // Send message with file
                sendMessage();
            } else {
                alert(data.data?.message || 'Error al subir el archivo');
            }
        })
        .catch(error => {
            console.error('Error uploading file:', error);
            if (attachBtn) {
                attachBtn.disabled = false;
                attachBtn.innerHTML = '<i class="fas fa-paperclip"></i>';
            }
            alert('Error al subir el archivo');
        });
    }
    
    // Start polling for new messages
    function startMessagePolling() {
        if (messagePollInterval) {
            clearInterval(messagePollInterval);
        }
        
        messagePollInterval = setInterval(function() {
            if (currentConversationId) {
                loadMessages(currentConversationId);
            }
            loadConversations();
        }, 5000); // Poll every 5 seconds
    }
    
    // Helper functions
    function formatTimeAgo(dateString) {
        if (!dateString) return '';
        const date = new Date(dateString);
        const now = new Date();
        const diffMs = now - date;
        const diffMins = Math.floor(diffMs / 60000);
        const diffHours = Math.floor(diffMs / 3600000);
        const diffDays = Math.floor(diffMs / 86400000);
        
        if (diffMins < 1) return 'Ahora';
        if (diffMins < 60) return `Hace ${diffMins}m`;
        if (diffHours < 24) return `Hace ${diffHours}h`;
        if (diffDays < 7) return `Hace ${diffDays}d`;
        return date.toLocaleDateString('es-ES');
    }
    
    function formatMessageTime(dateString) {
        if (!dateString) return '';
        const date = new Date(dateString);
        return date.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' });
    }
    
    function formatFileSize(bytes) {
        if (!bytes) return '';
        if (bytes < 1024) return bytes + ' B';
        if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
        return (bytes / 1048576).toFixed(1) + ' MB';
    }
    
    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    
    // Initialize when messages section becomes active
    document.addEventListener('DOMContentLoaded', function() {
        // Check if we're on a dashboard page
        const messagesSection = document.getElementById('messagesSection');
        if (messagesSection) {
            // Watch for section changes
            const observer = new MutationObserver(function(mutations) {
                mutations.forEach(function(mutation) {
                    if (mutation.type === 'attributes' && mutation.attributeName === 'class') {
                        if (messagesSection.classList.contains('active')) {
                            initMessaging();
                        }
                    }
                });
            });
            
            observer.observe(messagesSection, {
                attributes: true,
                attributeFilter: ['class']
            });
            
            // Initialize if already active
            if (messagesSection.classList.contains('active')) {
                initMessaging();
            }
        }
    });
})();

/**
 * Handle Message Button Click in Specialist Modal
 */
(function() {
    'use strict';
    
    // Use event delegation to handle clicks on dynamically created buttons
    document.addEventListener('click', function(e) {
        // Check if the click is on the message button or its child elements
        const messageBtn = e.target.closest('#modalMessage');
        
        if (messageBtn && !messageBtn.disabled) {
            e.preventDefault();
            e.stopPropagation();
                const specialistId = messageBtn.getAttribute('data-specialist-id');
                
                if (!specialistId) {
                    alert('Error: No se pudo identificar al especialista.');
                    return;
                }
                
                if (!window.nidfilAjax) {
                    alert('Error: Sistema de mensajería no disponible.');
                    return;
                }
                
                // Check if user is logged in
                const isLoggedIn = window.nidfilAjax.is_user_logged_in;
                
                if (!isLoggedIn) {
                    // User is not logged in - open registration form
                    const specialistModal = document.getElementById('specialistModal');
                    if (specialistModal) {
                        // Close specialist modal
                        specialistModal.classList.remove('modal-active');
                        document.body.style.overflow = '';
                    }
                    
                    // Open client modal and switch to register tab
                    if (typeof openClienteModal === 'function') {
                        openClienteModal();
                        // Switch to register tab after a short delay to ensure modal is open
                        setTimeout(function() {
                            if (typeof switchFormTab === 'function') {
                                switchFormTab('register');
                            }
                        }, 100);
                    } else {
                        alert('Por favor, inicia sesión o regístrate para enviar mensajes.');
                    }
                    return;
                }
                
                // User is logged in - proceed with starting conversation
                // Disable button during request
                messageBtn.disabled = true;
                const originalHTML = messageBtn.innerHTML;
                messageBtn.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M21 15C21 15.5304 20.7893 16.0391 20.4142 16.4142C20.0391 16.7893 19.5304 17 19 17H7L3 21V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H19C19.5304 3 20.0391 3.21071 20.4142 3.58579C20.7893 3.96086 21 4.46957 21 5V15Z" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg> Iniciando...';
                
                // Start conversation
                fetch(nidfilAjax.ajaxurl, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: new URLSearchParams({
                        action: 'nidfil_start_conversation',
                        specialist_id: specialistId,
                        nonce: nidfilAjax.nonce
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Close modal
                        const modal = document.getElementById('specialistModal');
                        if (modal) {
                            modal.classList.remove('modal-active');
                            document.body.style.overflow = '';
                        }
                        
                        // Redirect to dashboard messages section with conversation open
                        let redirectUrl = '';
                        if (data.data && data.data.redirect_url) {
                            redirectUrl = data.data.redirect_url;
                        } else if (nidfilAjax.dashboard_url) {
                            redirectUrl = nidfilAjax.dashboard_url;
                        } else {
                            redirectUrl = '/client-profile/';
                        }
                        
                        // Add conversation ID to URL hash
                        if (data.data && data.data.conversation_id) {
                            redirectUrl += '#messagesSection?conversation_id=' + data.data.conversation_id;
                        } else {
                            redirectUrl += '#messagesSection';
                        }
                        
                        window.location.href = redirectUrl;
                    } else {
                        alert(data.data?.message || 'Error al iniciar la conversación.');
                        messageBtn.disabled = false;
                        messageBtn.innerHTML = originalHTML;
                    }
                })
                .catch(error => {
                    console.error('Error starting conversation:', error);
                    alert('Error al iniciar la conversación. Por favor, intenta nuevamente.');
                    messageBtn.disabled = false;
                    messageBtn.innerHTML = originalHTML;
                });
        }
    });
    
    // Also attach listener on DOMContentLoaded as fallback
    document.addEventListener('DOMContentLoaded', function() {
        const messageBtn = document.getElementById('modalMessage');
        
        if (messageBtn && !messageBtn.hasAttribute('data-listener-attached')) {
            messageBtn.setAttribute('data-listener-attached', 'true');
            messageBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                
                if (this.disabled) return;
                
                const specialistId = this.getAttribute('data-specialist-id');
                
                if (!specialistId) {
                    alert('Error: No se pudo identificar al especialista.');
                    return;
                }
                
                if (!window.nidfilAjax) {
                    alert('Error: Sistema de mensajería no disponible.');
                    return;
                }
                
                // Check if user is logged in
                const isLoggedIn = window.nidfilAjax.is_user_logged_in;
                
                if (!isLoggedIn) {
                    // User is not logged in - open registration form
                    const specialistModal = document.getElementById('specialistModal');
                    if (specialistModal) {
                        // Close specialist modal
                        specialistModal.classList.remove('modal-active');
                        document.body.style.overflow = '';
                    }
                    
                    // Open client modal and switch to register tab
                    if (typeof openClienteModal === 'function') {
                        openClienteModal();
                        // Switch to register tab after a short delay to ensure modal is open
                        setTimeout(function() {
                            if (typeof switchFormTab === 'function') {
                                switchFormTab('register');
                            }
                        }, 100);
                    } else {
                        alert('Por favor, inicia sesión o regístrate para enviar mensajes.');
                    }
                    return;
                }
                
                // User is logged in - proceed with starting conversation
                // Disable button during request
                this.disabled = true;
                const originalHTML = this.innerHTML;
                this.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M21 15C21 15.5304 20.7893 16.0391 20.4142 16.4142C20.0391 16.7893 19.5304 17 19 17H7L3 21V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H19C19.5304 3 20.0391 3.21071 20.4142 3.58579C20.7893 3.96086 21 4.46957 21 5V15Z" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg> Iniciando...';
                
                // Start conversation
                fetch(nidfilAjax.ajaxurl, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: new URLSearchParams({
                        action: 'nidfil_start_conversation',
                        specialist_id: specialistId,
                        nonce: nidfilAjax.nonce
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Close modal
                        const modal = document.getElementById('specialistModal');
                        if (modal) {
                            modal.classList.remove('modal-active');
                            document.body.style.overflow = '';
                        }
                        
                        // Redirect to dashboard messages section with conversation open
                        let redirectUrl = '';
                        if (data.data && data.data.redirect_url) {
                            redirectUrl = data.data.redirect_url;
                        } else if (nidfilAjax.dashboard_url) {
                            redirectUrl = nidfilAjax.dashboard_url;
                        } else {
                            redirectUrl = '/client-profile/';
                        }
                        
                        // Add conversation ID to URL hash
                        if (data.data && data.data.conversation_id) {
                            redirectUrl += '#messagesSection?conversation_id=' + data.data.conversation_id;
                        } else {
                            redirectUrl += '#messagesSection';
                        }
                        
                        window.location.href = redirectUrl;
                    } else {
                        alert(data.data?.message || 'Error al iniciar la conversación.');
                        messageBtn.disabled = false;
                        messageBtn.innerHTML = originalHTML;
                    }
                })
                .catch(error => {
                    console.error('Error starting conversation:', error);
                    alert('Error al iniciar la conversación. Por favor, intenta nuevamente.');
                    messageBtn.disabled = false;
                    messageBtn.innerHTML = originalHTML;
                });
            });
        }
        
        // Auto-open conversation if URL has conversation ID
        const urlHash = window.location.hash;
        if (urlHash && urlHash.includes('conversation=')) {
            const match = urlHash.match(/conversation=(\d+)/);
            if (match && match[1]) {
                const conversationId = match[1];
                
                // Wait for dashboard to load, then open conversation
                setTimeout(function() {
                    if (typeof window.openConversation === 'function') {
                        // Load conversations first, then open
                        if (typeof loadConversations === 'function') {
                            loadConversations();
                            setTimeout(function() {
                                window.openConversation(conversationId, null);
                            }, 500);
                        }
                    }
                }, 1500);
            }
        }
    });
})();

