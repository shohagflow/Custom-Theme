</div><!-- #page -->

<footer id="colophon" class="site-footer">
    <div class="footer-container">
        <div class="footer-content">
            <div class="footer-column">
                <div class="footer-logo">
                    <a href="<?php echo esc_url( home_url( '/' ) ); ?>">
                        <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/footer-logo.png' ); ?>" alt="NIDFIL" class="footer-logo-image">
                    </a>
                </div>
                <p class="footer-description">El espacio digital donde propietarios y especialistas de la construcción se encuentran.</p>
                <div class="social-links">
                    <a href="#" class="social-link" aria-label="Instagram">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M10 2C7.23858 2 6.875 2.01 5.8125 2.06C4.75 2.11 4.0625 2.27 3.4375 2.5C2.75 2.75 2.1875 3.0625 1.625 3.625C1.0625 4.1875 0.75 4.75 0.5 5.4375C0.27 6.0625 0.11 6.75 0.06 7.8125C0.01 8.875 0 9.23858 0 12C0 14.7614 0.01 15.125 0.06 16.1875C0.11 17.25 0.27 17.9375 0.5 18.5625C0.75 19.25 1.0625 19.8125 1.625 20.375C2.1875 20.9375 2.75 21.25 3.4375 21.5C4.0625 21.73 4.75 21.89 5.8125 21.94C6.875 21.99 7.23858 22 10 22C12.7614 22 13.125 21.99 14.1875 21.94C15.25 21.89 15.9375 21.73 16.5625 21.5C17.25 21.25 17.8125 20.9375 18.375 20.375C18.9375 19.8125 19.25 19.25 19.5 18.5625C19.73 17.9375 19.89 17.25 19.94 16.1875C19.99 15.125 20 14.7614 20 12C20 9.23858 19.99 8.875 19.94 7.8125C19.89 6.75 19.73 6.0625 19.5 5.4375C19.25 4.75 18.9375 4.1875 18.375 3.625C17.8125 3.0625 17.25 2.75 16.5625 2.5C15.9375 2.27 15.25 2.11 14.1875 2.06C13.125 2.01 12.7614 2 10 2ZM10 4.375C12.7614 4.375 13.125 4.375 14.1875 4.4375C15.1875 4.5 15.75 4.625 16.125 4.75C16.625 4.9375 17 5.125 17.375 5.5C17.75 5.875 17.9375 6.25 18.125 6.75C18.25 7.125 18.375 7.6875 18.4375 8.6875C18.5 9.75 18.5 10.1136 18.5 12.875C18.5 15.6364 18.5 16 18.4375 17.0625C18.375 18.0625 18.25 18.625 18.125 19C17.9375 19.5 17.75 19.875 17.375 20.25C17 20.625 16.625 20.8125 16.125 21C15.75 21.125 15.1875 21.25 14.1875 21.3125C13.125 21.375 12.7614 21.375 10 21.375C7.23858 21.375 6.875 21.375 5.8125 21.3125C4.8125 21.25 4.25 21.125 3.875 21C3.375 20.8125 3 20.625 2.625 20.25C2.25 19.875 2.0625 19.5 1.875 19C1.75 18.625 1.625 18.0625 1.5625 17.0625C1.5 16 1.5 15.6364 1.5 12.875C1.5 10.1136 1.5 9.75 1.5625 8.6875C1.625 7.6875 1.75 7.125 1.875 6.75C2.0625 6.25 2.25 5.875 2.625 5.5C3 5.125 3.375 4.9375 3.875 4.75C4.25 4.625 4.8125 4.5 5.8125 4.4375C6.875 4.375 7.23858 4.375 10 4.375ZM10 6.25C7.92893 6.25 6.25 7.92893 6.25 10C6.25 12.0711 7.92893 13.75 10 13.75C12.0711 13.75 13.75 12.0711 13.75 10C13.75 7.92893 12.0711 6.25 10 6.25ZM10 12C8.89543 12 8 11.1046 8 10C8 8.89543 8.89543 8 10 8C11.1046 8 12 8.89543 12 10C12 11.1046 11.1046 12 10 12ZM15.375 6.625C15.375 7.24632 14.8713 7.75 14.25 7.75C13.6287 7.75 13.125 7.24632 13.125 6.625C13.125 6.00368 13.6287 5.5 14.25 5.5C14.8713 5.5 15.375 6.00368 15.375 6.625Z" fill="currentColor"/>
                        </svg>
                    </a>
                    <a href="#" class="social-link" aria-label="LinkedIn">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M18 0H2C0.895431 0 0 0.895431 0 2V18C0 19.1046 0.895431 20 2 20H18C19.1046 20 20 19.1046 20 18V2C20 0.895431 19.1046 0 18 0ZM6 17H3V7H6V17ZM4.5 5.5C3.67157 5.5 3 4.82843 3 4C3 3.17157 3.67157 2.5 4.5 2.5C5.32843 2.5 6 3.17157 6 4C6 4.82843 5.32843 5.5 4.5 5.5ZM17 17H14V12.5C14 11.3954 13.1046 10.5 12 10.5C10.8954 10.5 10 11.3954 10 12.5V17H7V7H10V8.5C10.6046 7.67157 11.6716 7 13 7C15.2091 7 17 8.79086 17 11V17Z" fill="currentColor"/>
                        </svg>
                    </a>
                </div>
            </div>
            
            <div class="footer-column">
                <h3 class="footer-title">Especialistas</h3>
                <ul class="footer-links">
                    <li><a href="#">Arquitectos</a></li>
                    <li><a href="#">Electricistas</a></li>
                    <li><a href="#">Fontaneros</a></li>
                    <li><a href="#">Pintores</a></li>
                    <li><a href="#">Ver todos</a></li>
                </ul>
            </div>
            
            <div class="footer-column">
                <h3 class="footer-title">Empresa</h3>
                <ul class="footer-links">
                    <li><a href="<?php echo esc_url( nidfil_get_aviso_legal_url() ); ?>">Aviso Legal</a></li>
                    <li><a href="<?php echo esc_url( nidfil_get_privacidad_url() ); ?>">Política de Privacidad (RGPD)</a></li>
                    <li><a href="<?php echo esc_url( nidfil_get_cookies_url() ); ?>">Política de Cookies</a></li>
                    <li><a href="<?php echo esc_url( nidfil_get_condiciones_url() ); ?>">Condiciones de Uso de la Plataforma</a></li>
                </ul>
            </div>
            
            <div class="footer-column">
                <h3 class="footer-title">Contacto</h3>
                <ul class="footer-contact">
                    <li>
                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M3.5 2C2.67157 2 2 2.67157 2 3.5V12.5C2 13.3284 2.67157 14 3.5 14H12.5C13.3284 14 14 13.3284 14 12.5V3.5C14 2.67157 13.3284 2 12.5 2H3.5ZM3.5 3H12.5C12.7761 3 13 3.22386 13 3.5V4.5L8 7.5L3 4.5V3.5C3 3.22386 3.22386 3 3.5 3ZM3 5.5L8 8.5L13 5.5V12.5C13 12.7761 12.7761 13 12.5 13H3.5C3.22386 13 3 12.7761 3 12.5V5.5Z" fill="currentColor"/>
                        </svg>
                        <span>info@nidfil.com</span>
                    </li>
                    <li>
                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M3.5 1C2.67157 1 2 1.67157 2 2.5V13.5C2 14.3284 2.67157 15 3.5 15H12.5C13.3284 15 14 14.3284 14 13.5V2.5C14 1.67157 13.3284 1 12.5 1H3.5ZM3.5 2H12.5C12.7761 2 13 2.22386 13 2.5V3.5L8 6.5L3 3.5V2.5C3 2.22386 3.22386 2 3.5 2ZM3 4.5L8 7.5L13 4.5V13.5C13 13.7761 12.7761 14 12.5 14H3.5C3.22386 14 3 13.7761 3 13.5V4.5Z" fill="currentColor"/>
                        </svg>
                        <span>+34 900 123 456</span>
                    </li>
                    <li>
                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M8 0C5.23858 0 3 2.23858 3 5C3 9 8 16 8 16C8 16 13 9 13 5C13 2.23858 10.7614 0 8 0ZM8 6.5C7.17157 6.5 6.5 5.82843 6.5 5C6.5 4.17157 7.17157 3.5 8 3.5C8.82843 3.5 9.5 4.17157 9.5 5C9.5 5.82843 8.82843 6.5 8 6.5Z" fill="currentColor"/>
                        </svg>
                        <span>Madrid, España</span>
                    </li>
                </ul>
            </div>
        </div>
        
        <div class="footer-bottom">
            <p>&copy; <?php echo date('Y'); ?> NIDFIL. Todos los derechos reservados.</p>
        </div>
    </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>

