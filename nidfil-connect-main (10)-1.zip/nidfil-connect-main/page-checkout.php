<?php
/**
 * Template Name: Checkout Page
 * 
 * @package NIDFIL_Connect
 */

if (!defined('ABSPATH')) {
    exit;
}

// Get plan details from URL parameters
$plan_id = isset($_GET['plan_id']) ? intval($_GET['plan_id']) : 0;
$plan_name = isset($_GET['plan_name']) ? sanitize_text_field($_GET['plan_name']) : '';
$plan_price = isset($_GET['plan_price']) ? floatval($_GET['plan_price']) : 0;
$plan_period = isset($_GET['plan_period']) ? sanitize_text_field($_GET['plan_period']) : 'month';

// If no plan selected, redirect to home
if ($plan_id <= 0) {
    wp_redirect(home_url());
    exit;
}

// Get plan details from database to check payment_enabled status
$stored_plans = get_option('nidfil_subscription_plans', array());
if (is_string($stored_plans)) {
    $stored_plans = json_decode($stored_plans, true);
}

$plan_payment_enabled = true; // Default to enabled for backward compatibility
$plan_type = 'pro'; // Default to pro

foreach ($stored_plans as $plan) {
    if (isset($plan['id']) && $plan['id'] == $plan_id) {
        // Check payment_enabled status (default to true if not set for backward compatibility)
        $plan_payment_enabled = !isset($plan['payment_enabled']) || $plan['payment_enabled'] !== false;
        
        // Get plan type
        $plan_type = isset($plan['plan_type']) ? $plan['plan_type'] : (isset($plan['pro']) && $plan['pro'] ? 'pro' : 'free');
        
        // If payment is disabled, ensure price is 0
        if (!$plan_payment_enabled) {
            $plan_price = 0;
        }
        break;
    }
}

get_header();
?>

<main id="main" class="site-main checkout-page-main">
    <div class="checkout-page-container">
        <div class="checkout-page-content">
            <div class="checkout-left-column">
                <div class="checkout-plan-summary-card">
                    <h3 class="checkout-summary-title">Resumen del Plan</h3>
                    <div class="checkout-plan-details">
                        <h4 class="checkout-plan-name-display" id="checkoutPlanNameDisplay"><?php echo esc_html($plan_name); ?></h4>
                        <div class="checkout-plan-price-display">
                            <span class="checkout-price-amount" id="checkoutPlanPriceDisplay">€<?php echo number_format($plan_price, 2); ?></span>
                            <span class="checkout-price-period" id="checkoutPlanPeriodDisplay">/<?php echo esc_html($plan_period); ?></span>
                        </div>
                    </div>
                </div>
                
                <form id="checkoutForm" class="checkout-form">
                    <input type="hidden" id="checkoutPlanId" name="plan_id" value="<?php echo esc_attr($plan_id); ?>">
                    <input type="hidden" id="checkoutPlanPriceValue" name="plan_price" value="<?php echo esc_attr($plan_price); ?>">
                    <input type="hidden" id="checkoutPlanNameValue" name="plan_name" value="<?php echo esc_attr($plan_name); ?>">
                    <input type="hidden" id="checkoutPlanPeriodValue" name="plan_period" value="<?php echo esc_attr($plan_period); ?>">
                    <input type="hidden" id="checkoutPaymentEnabled" name="payment_enabled" value="<?php echo $plan_payment_enabled ? '1' : '0'; ?>">
                    
                    <div class="checkout-form-section">
                        <h4 class="checkout-section-title">
                            <i class="fas fa-user"></i>
                            Información de Contacto
                        </h4>
                        <div class="checkout-form-row">
                            <div class="checkout-form-group">
                                <label for="checkoutFirstName">Nombre <span class="required">*</span></label>
                                <input type="text" id="checkoutFirstName" name="first_name" required>
                            </div>
                            <div class="checkout-form-group">
                                <label for="checkoutLastName">Apellidos <span class="required">*</span></label>
                                <input type="text" id="checkoutLastName" name="last_name" required>
                            </div>
                        </div>
                        <div class="checkout-form-group">
                            <label for="checkoutEmail">Email <span class="required">*</span></label>
                            <?php 
                            $current_user = wp_get_current_user();
                            $user_email = $current_user && $current_user->ID > 0 ? $current_user->user_email : '';
                            $is_logged_in = is_user_logged_in();
                            ?>
                            <input type="email" id="checkoutEmail" name="email" value="<?php echo esc_attr($user_email); ?>" required>
                            <?php if ($is_logged_in && !empty($user_email)): ?>
                                <small style="display: block; margin-top: 4px; color: #64748b; font-size: 12px;">
                                    <i class="fas fa-info-circle"></i> <?php _e('Pre-filled with your registered email. You can edit if needed.', 'nidfil-connect'); ?>
                                </small>
                            <?php endif; ?>
                        </div>
                        <div class="checkout-form-group">
                            <label for="checkoutPhone">Teléfono <span class="required">*</span></label>
                            <input type="tel" id="checkoutPhone" name="phone" required>
                        </div>
                    </div>
                    
                    <div class="checkout-form-section">
                        <h4 class="checkout-section-title">
                            <i class="fas fa-credit-card"></i>
                            Método de Pago
                        </h4>
                        <div class="payment-methods">
                            <label class="payment-method-option">
                                <input type="radio" name="payment_method" value="stripe" checked>
                                <span class="payment-method-label">
                                    <i class="fab fa-cc-stripe"></i>
                                    <span>Tarjeta de Crédito/Débito</span>
                                </span>
                            </label>
                            <label class="payment-method-option">
                                <input type="radio" name="payment_method" value="paypal">
                                <span class="payment-method-label">
                                    <i class="fab fa-paypal"></i>
                                    <span>PayPal</span>
                                </span>
                            </label>
                            <label class="payment-method-option">
                                <input type="radio" name="payment_method" value="bank_transfer">
                                <span class="payment-method-label">
                                    <i class="fas fa-university"></i>
                                    <span>Transferencia Bancaria</span>
                                </span>
                            </label>
                        </div>
                        
                        <div id="cardPaymentFields" class="payment-fields">
                            <div class="checkout-form-group">
                                <label for="checkoutCardNumber">Número de Tarjeta <span class="required payment-required" style="display: <?php echo $plan_payment_enabled ? 'inline' : 'none'; ?>;">*</span></label>
                                <input type="text" id="checkoutCardNumber" name="card_number" placeholder="1234 5678 9012 3456" maxlength="19" <?php echo $plan_payment_enabled ? 'required' : ''; ?>>
                            </div>
                            <div class="checkout-form-row">
                                <div class="checkout-form-group">
                                    <label for="checkoutExpiry">Fecha de Expiración <span class="required payment-required" style="display: <?php echo $plan_payment_enabled ? 'inline' : 'none'; ?>;">*</span></label>
                                    <input type="text" id="checkoutExpiry" name="expiry" placeholder="MM/AA" maxlength="5" <?php echo $plan_payment_enabled ? 'required' : ''; ?>>
                                </div>
                                <div class="checkout-form-group">
                                    <label for="checkoutCVC">CVC <span class="required payment-required" style="display: <?php echo $plan_payment_enabled ? 'inline' : 'none'; ?>;">*</span></label>
                                    <input type="text" id="checkoutCVC" name="cvc" placeholder="123" maxlength="4" <?php echo $plan_payment_enabled ? 'required' : ''; ?>>
                                </div>
                            </div>
                            <div class="checkout-form-group">
                                <label for="checkoutCardName">Nombre en la Tarjeta <span class="required payment-required" style="display: <?php echo $plan_payment_enabled ? 'inline' : 'none'; ?>;">*</span></label>
                                <input type="text" id="checkoutCardName" name="card_name" <?php echo $plan_payment_enabled ? 'required' : ''; ?>>
                            </div>
                        </div>
                    </div>
                    
                    <div class="checkout-form-actions">
                        <a href="<?php echo esc_url(home_url()); ?>" class="checkout-cancel-btn">
                            <i class="fas fa-arrow-left"></i>
                            Volver
                        </a>
                        <button type="submit" class="checkout-submit-btn" id="checkoutSubmitBtn">
                            <?php if ($plan_payment_enabled): ?>
                                <i class="fas fa-lock"></i>
                                Pagar Ahora
                            <?php else: ?>
                                <i class="fas fa-check"></i>
                                Empezar Gratis
                            <?php endif; ?>
                        </button>
                    </div>
                </form>
            </div>
            
            <div class="checkout-right-column">
                <div class="checkout-order-summary">
                    <h3 class="checkout-summary-title">Resumen del Pedido</h3>
                    <div class="checkout-total">
                        <div class="checkout-total-row">
                            <span>Plan:</span>
                            <span id="checkoutSubtotal">€<?php echo number_format($plan_price, 2); ?></span>
                        </div>
                        <div class="checkout-total-row">
                            <span>IVA (21%):</span>
                            <span id="checkoutTax">€<?php echo number_format($plan_price * 0.21, 2); ?></span>
                        </div>
                        <div class="checkout-total-row checkout-total-final">
                            <span>Total:</span>
                            <span id="checkoutTotal">€<?php echo number_format($plan_price * 1.21, 2); ?></span>
                        </div>
                    </div>
                    
                    <div class="checkout-security-info">
                        <i class="fas fa-shield-alt"></i>
                        <p>Tu información está protegida con encriptación SSL</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<script>
(function() {
    'use strict';
    
    // Get payment enabled status
    const paymentEnabledInput = document.getElementById('checkoutPaymentEnabled');
    const paymentEnabled = paymentEnabledInput ? paymentEnabledInput.value === '1' : true;
    
    // Handle payment method change
    const paymentMethods = document.querySelectorAll('input[name="payment_method"]');
    paymentMethods.forEach(method => {
        method.addEventListener('change', function() {
            const cardFields = document.getElementById('cardPaymentFields');
            if (this.value === 'stripe' && cardFields) {
                cardFields.style.display = 'block';
            } else if (cardFields) {
                cardFields.style.display = 'none';
            }
        });
    });
    
    // Handle checkout form submission
    const checkoutForm = document.getElementById('checkoutForm');
    if (checkoutForm) {
        checkoutForm.addEventListener('submit', function(e) {
            e.preventDefault();
            handleCheckoutSubmission(this);
        });
    }
    
    // Format card number input
    const cardNumberInput = document.getElementById('checkoutCardNumber');
    if (cardNumberInput) {
        cardNumberInput.addEventListener('input', function(e) {
            let value = e.target.value.replace(/\s/g, '');
            let formattedValue = value.match(/.{1,4}/g)?.join(' ') || value;
            e.target.value = formattedValue;
        });
    }
    
    // Format expiry date input
    const expiryInput = document.getElementById('checkoutExpiry');
    if (expiryInput) {
        expiryInput.addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            if (value.length >= 2) {
                value = value.substring(0, 2) + '/' + value.substring(2, 4);
            }
            e.target.value = value;
        });
    }
    
    // Format CVC input (numbers only)
    const cvcInput = document.getElementById('checkoutCVC');
    if (cvcInput) {
        cvcInput.addEventListener('input', function(e) {
            e.target.value = e.target.value.replace(/\D/g, '');
        });
    }
    
    // Handle checkout form submission
    function handleCheckoutSubmission(form) {
        const submitBtn = form.querySelector('.checkout-submit-btn');
        const originalText = submitBtn.innerHTML;
        
        // Disable button and show loading
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Procesando...';
        
        // Get form data
        const formData = new FormData(form);
        const paymentMethod = formData.get('payment_method');
        
        // Payment validation - only required if payment is enabled
        if (paymentEnabled && paymentMethod === 'stripe') {
            const cardNumber = formData.get('card_number');
            const expiry = formData.get('expiry');
            const cvc = formData.get('cvc');
            const cardName = formData.get('card_name');
            
            // Validate all payment fields are filled
            if (!cardNumber || !expiry || !cvc || !cardName) {
                alert('Por favor, completa todos los campos de la tarjeta.');
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalText;
                return;
            }
            
            // Validate card number format (basic validation)
            const cardNumberClean = cardNumber.replace(/\s/g, '');
            if (cardNumberClean.length < 13 || cardNumberClean.length > 19) {
                alert('Por favor, ingresa un número de tarjeta válido.');
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalText;
                return;
            }
            
            // Validate expiry format (MM/YY)
            if (!/^\d{2}\/\d{2}$/.test(expiry)) {
                alert('Por favor, ingresa una fecha de expiración válida (MM/AA).');
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalText;
                return;
            }
            
            // Validate CVC
            if (cvc.length < 3 || cvc.length > 4) {
                alert('Por favor, ingresa un CVC válido.');
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalText;
                return;
            }
            
            // Process payment (PRO plan)
            processPayment(form, formData, submitBtn, originalText);
        } else {
            // Skip payment processing (FREE plan)
            processFreeSubscription(form, formData, submitBtn, originalText);
        }
    }
    
    // Process payment for PRO plans
    function processPayment(form, formData, submitBtn, originalText) {
        if (typeof nidfilAjax === 'undefined' || !nidfilAjax.ajaxurl || !nidfilAjax.nonce) {
            showErrorPopup('Error de configuración. Por favor, recarga la página.');
            submitBtn.disabled = false;
            submitBtn.innerHTML = originalText;
            return;
        }
        
        // Prepare payment data
        const paymentData = {
            action: 'nidfil_process_checkout',
            nonce: nidfilAjax.nonce,
            plan_id: formData.get('plan_id'),
            plan_name: formData.get('plan_name'),
            plan_price: formData.get('plan_price'),
            plan_period: formData.get('plan_period'),
            payment_enabled: formData.get('payment_enabled'),
            first_name: formData.get('first_name'),
            last_name: formData.get('last_name'),
            email: formData.get('email'),
            phone: formData.get('phone'),
            payment_method: formData.get('payment_method'),
            card_number: formData.get('card_number'),
            expiry: formData.get('expiry'),
            cvc: formData.get('cvc'),
            card_name: formData.get('card_name')
        };
        
        fetch(nidfilAjax.ajaxurl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: new URLSearchParams(paymentData)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showSuccessPopup('¡Solicitud de suscripción enviada exitosamente! El administrador revisará tu solicitud y la activará pronto.');
                // Redirect after 2 seconds
                setTimeout(() => {
                    window.location.href = '<?php echo esc_url(home_url()); ?>';
                }, 2000);
            } else {
                showErrorPopup(data.data?.message || 'No se pudo procesar el pago. Por favor, intenta de nuevo.');
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalText;
            }
        })
        .catch(error => {
            console.error('Payment error:', error);
            showErrorPopup('Error al procesar el pago. Por favor, intenta de nuevo.');
            submitBtn.disabled = false;
            submitBtn.innerHTML = originalText;
        });
    }
    
    // Process free subscription (no payment required)
    function processFreeSubscription(form, formData, submitBtn, originalText) {
        if (typeof nidfilAjax === 'undefined' || !nidfilAjax.ajaxurl || !nidfilAjax.nonce) {
            showErrorPopup('Error de configuración. Por favor, recarga la página.');
            submitBtn.disabled = false;
            submitBtn.innerHTML = originalText;
            return;
        }
        
        // Prepare subscription data
        const subscriptionData = {
            action: 'nidfil_process_checkout',
            nonce: nidfilAjax.nonce,
            plan_id: formData.get('plan_id'),
            plan_name: formData.get('plan_name'),
            plan_price: formData.get('plan_price'),
            plan_period: formData.get('plan_period'),
            payment_enabled: formData.get('payment_enabled'),
            first_name: formData.get('first_name'),
            last_name: formData.get('last_name'),
            email: formData.get('email'),
            phone: formData.get('phone')
        };
        
        fetch(nidfilAjax.ajaxurl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: new URLSearchParams(subscriptionData)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showSuccessPopup('¡Solicitud de suscripción enviada exitosamente! El administrador revisará tu solicitud y la activará pronto.');
                // Redirect after 2 seconds
                setTimeout(() => {
                    window.location.href = '<?php echo esc_url(home_url()); ?>';
                }, 2000);
            } else {
                showErrorPopup(data.data?.message || 'No se pudo activar la suscripción. Por favor, intenta de nuevo.');
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalText;
            }
        })
        .catch(error => {
            console.error('Subscription error:', error);
            showErrorPopup('Error al activar la suscripción. Por favor, intenta de nuevo.');
            submitBtn.disabled = false;
            submitBtn.innerHTML = originalText;
        });
    }
    
    // Show success popup
    function showSuccessPopup(message) {
        const popup = document.createElement('div');
        popup.className = 'checkout-popup checkout-popup-success';
        popup.innerHTML = `
            <div class="checkout-popup-content">
                <div class="checkout-popup-icon">
                    <i class="fas fa-check-circle"></i>
                </div>
                <h3>¡Éxito!</h3>
                <p>${message}</p>
            </div>
        `;
        document.body.appendChild(popup);
        
        // Remove popup after 3 seconds
        setTimeout(() => {
            popup.remove();
        }, 3000);
    }
    
    // Show error popup
    function showErrorPopup(message) {
        const popup = document.createElement('div');
        popup.className = 'checkout-popup checkout-popup-error';
        popup.innerHTML = `
            <div class="checkout-popup-content">
                <div class="checkout-popup-icon">
                    <i class="fas fa-exclamation-circle"></i>
                </div>
                <h3>Error</h3>
                <p>${message}</p>
                <button class="checkout-popup-close" onclick="this.parentElement.parentElement.remove()">Cerrar</button>
            </div>
        `;
        document.body.appendChild(popup);
    }
})();
</script>

<?php get_footer(); ?>

