<?php
/**
 * Access Forms - Client, Specialist, and Password Reset Modals
 * 
 * This file contains the HTML and JavaScript for:
 * - Client modal (Quiero hacer una reforma)
 * - Specialist modal (Quiero trabajar)
 * - Password Reset modal with OTP verification
 * 
 * @package NIDFIL_Connect
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}
?>

<!-- Soy Cliente Modal -->
<div id="clienteModal" class="access-modal">
    <div class="modal-overlay" onclick="closeClienteModal()"></div>
    <div class="modal-content access-modal-content">
        <button class="modal-close" onclick="closeClienteModal()">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M18 6L6 18M6 6L18 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
        </button>
        
        <div class="modal-body">
            <div class="modal-header">
                <h2 class="modal-title">Soy Cliente</h2>
                <p class="modal-subtitle">Accede a tu cuenta o regístrate</p>
            </div>
            
            <div class="form-tabs">
                <button class="form-tab active" data-tab="login">Iniciar Sesión</button>
                <button class="form-tab" data-tab="register">Registrarse</button>
            </div>
            
            <!-- Login Form -->
            <form id="loginForm" class="access-form active-form" method="post" action="" novalidate>
                <div class="form-group">
                    <label for="loginEmail">Email</label>
                    <input type="email" id="loginEmail" name="email" placeholder="tu@email.com" required>
                </div>
                
                <div class="form-group">
                    <label for="loginPassword">Contraseña</label>
                    <input type="password" id="loginPassword" name="password" placeholder="••••••••" required>
                </div>
                
                <div class="form-options">
                    <label class="checkbox-label">
                        <input type="checkbox" name="remember">
                        <span>Recordarme</span>
                    </label>
                    <a href="#" id="clienteForgotPassword" class="forgot-password" onclick="openResetPasswordModal(); return false;">¿Olvidaste tu contraseña?</a>
                </div>
                
                <button type="submit" class="btn btn-primary form-submit">Iniciar Sesión</button>
                
                <div class="form-divider">
                    <span>o</span>
                </div>
                
                <button type="button" class="btn btn-outline social-login">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                        <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                        <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                        <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
                    </svg>
                    Continuar con Google
                </button>
            </form>
            
            <!-- Register Form -->
            <form id="registerForm" class="access-form" method="post" action="" novalidate>
                <div class="form-group">
                    <label for="registerName">Nombre completo</label>
                    <input type="text" id="registerName" name="name" placeholder="Juan Pérez" required>
                </div>
                
                <div class="form-group">
                    <label for="registerEmail">Email</label>
                    <input type="email" id="registerEmail" name="email" placeholder="tu@email.com" required>
                </div>
                
                <div class="form-group">
                    <label for="registerPhone">Teléfono</label>
                    <input type="tel" id="registerPhone" name="phone" placeholder="+34 600 000 000" required>
                </div>
                
                <div class="form-group">
                    <label for="registerPassword">Contraseña</label>
                    <input type="password" id="registerPassword" name="password" placeholder="••••••••" required>
                </div>
                
                <div class="form-group">
                    <label for="registerPasswordConfirm">Confirmar contraseña</label>
                    <input type="password" id="registerPasswordConfirm" name="password_confirm" placeholder="••••••••" required>
                </div>
                
                <div class="form-group">
                    <label class="checkbox-label">
                        <input type="checkbox" name="terms" required>
                        <span>Acepto los <a href="#">términos y condiciones</a> y la <a href="#">política de privacidad</a></span>
                    </label>
                </div>
                
                <button type="submit" class="btn btn-primary form-submit">Registrarse</button>
                
                <div class="form-divider">
                    <span>o</span>
                </div>
                
                <button type="button" class="btn btn-outline social-login">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                        <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                        <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                        <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
                    </svg>
                    Continuar con Google
                </button>
            </form>
        </div>
    </div>
</div>

<!-- Soy Especialista Modal -->
<div id="especialistaModal" class="access-modal">
    <div class="modal-overlay" onclick="closeEspecialistaModal()"></div>
    <div class="modal-content access-modal-content">
        <button class="modal-close" onclick="closeEspecialistaModal()">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M18 6L6 18M6 6L18 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
        </button>
        
        <div class="modal-body">
            <div class="modal-header">
                <h2 class="modal-title">Soy Especialista</h2>
            </div>
            
            <div class="form-tabs">
                <button class="form-tab active" data-tab="login" onclick="switchEspecialistaTab('login')">Iniciar Sesión</button>
                <button class="form-tab" data-tab="register" onclick="switchEspecialistaTab('register')">Registrarse</button>
            </div>
            
            <!-- Login Form -->
            <form id="especialistaLoginForm" class="access-form active-form" method="post" action="" novalidate>
                <div class="form-group">
                    <label for="especialistaLoginEmail">Email</label>
                    <input type="email" id="especialistaLoginEmail" name="email" placeholder="tu@email.com" required>
                </div>
                
                <div class="form-group">
                    <label for="especialistaLoginPassword">Contraseña</label>
                    <input type="password" id="especialistaLoginPassword" name="password" placeholder="••••••••" required>
                </div>
                
                <div class="form-options">
                    <label class="checkbox-label">
                        <input type="checkbox" name="remember">
                        <span>Recordarme</span>
                    </label>
                    <a href="#" id="especialistaForgotPassword" class="forgot-password" onclick="openResetPasswordModal(); return false;">¿Olvidaste tu contraseña?</a>
                </div>
                
                <button type="submit" class="btn btn-primary form-submit">Iniciar Sesión</button>
                
                <div class="form-divider">
                    <span>o</span>
                </div>
                
                <button type="button" class="btn btn-outline social-login">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                        <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                        <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                        <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
                    </svg>
                    Continuar con Google
                </button>
            </form>
            
            <!-- Register Form -->
            <form id="especialistaRegisterForm" class="access-form" method="post" action="" novalidate>
                <div class="form-group">
                    <label for="especialistaRegisterName">Nombre completo</label>
                    <input type="text" id="especialistaRegisterName" name="name" placeholder="Juan Pérez" required>
                </div>
                
                <div class="form-group">
                    <label for="especialistaRegisterEmail">Email</label>
                    <input type="email" id="especialistaRegisterEmail" name="email" placeholder="tu@email.com" required>
                </div>
                
                <div class="form-group">
                    <label for="especialistaRegisterPhone">Teléfono</label>
                    <input type="tel" id="especialistaRegisterPhone" name="phone" placeholder="+34 600 000 000" required>
                </div>
                
                <div class="form-group">
                    <label for="especialistaRegisterProfession">Profesión/Especialidad</label>
                    <select id="especialistaRegisterProfession" name="profession" required style="width: 100%; padding: 0.75rem 1rem; font-size: 1rem; line-height: 1.5; border: 1px solid #e0e0e0; border-radius: 8px; background-color: #fff; color: #333; cursor: pointer; transition: all 0.3s ease; appearance: none; background-image: url('data:image/svg+xml;charset=UTF-8,<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'12\' height=\'12\' viewBox=\'0 0 12 12\'><path fill=\'%23333\' d=\'M6 9L1 4h10z\'/></svg>'); background-repeat: no-repeat; background-position: right 1rem center; padding-right: 2.5rem; font-family: inherit;">
                        <option value="" disabled selected>Selecciona una especialidad</option>
                        <option value="Electricista">Electricista</option>
                        <option value="Fontanero">Fontanero</option>
                        <option value="Carpintero">Carpintero</option>
                        <option value="Pintor">Pintor</option>
                        <option value="Albañil">Albañil</option>
                        <option value="Techador">Techador</option>
                        <option value="Técnico de Climatización">Técnico de Climatización</option>
                        <option value="Especialista en Suelos">Especialista en Suelos</option>
                        <option value="Instalador de Cocinas">Instalador de Cocinas</option>
                        <option value="Instalador de Baños">Instalador de Baños</option>
                        <option value="Cerrajero">Cerrajero</option>
                        <option value="Cristalero">Cristalero</option>
                        <option value="Yesero">Yesero</option>
                        <option value="Instalador de Vallas">Instalador de Vallas</option>
                        <option value="Jardinero/Paisajista">Jardinero/Paisajista</option>
                        <option value="Contratista General">Contratista General</option>
                        <option value="Otro">Otro</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="especialistaRegisterExperience">Años de Experiencia</label>
                    <input type="number" id="especialistaRegisterExperience" name="experience" placeholder="Ej: 5" min="0" max="50" step="1" required>
                </div>
                
                <div class="form-group">
                    <label for="especialistaRegisterPassword">Contraseña</label>
                    <input type="password" id="especialistaRegisterPassword" name="password" placeholder="••••••••" required>
                </div>
                
                <div class="form-group">
                    <label for="especialistaRegisterPasswordConfirm">Confirmar contraseña</label>
                    <input type="password" id="especialistaRegisterPasswordConfirm" name="password_confirm" placeholder="••••••••" required>
                </div>
                
                <div class="form-group">
                    <label class="checkbox-label">
                        <input type="checkbox" name="terms" required>
                        <span>Acepto los <a href="#">términos y condiciones</a> y la <a href="#">política de privacidad</a></span>
                    </label>
                </div>
                
                <button type="submit" class="btn btn-primary form-submit">Registrarse como Especialista</button>
                
                <div class="form-divider">
                    <span>o</span>
                </div>
                
                <button type="button" class="btn btn-outline social-login">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                        <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                        <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                        <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
                    </svg>
                    Continuar con Google
                </button>
            </form>
        </div>
    </div>
</div>

<style>
/* Professional Select Dropdown Styling - Match other form fields */
#especialistaRegisterProfession:focus {
    outline: none;
    border-color: var(--orange-primary, #f97015);
    box-shadow: 0 0 0 3px rgba(249, 112, 21, 0.1);
}

#especialistaRegisterProfession:hover {
    border-color: #d0d0d0;
}

#especialistaRegisterProfession:focus:hover {
    border-color: var(--orange-primary, #f97015);
}

/* Phone Input Field Active Border Styling - Match other form fields */
#especialistaRegisterPhone:focus {
    outline: none;
    border-color: var(--orange-primary, #f97015);
    box-shadow: 0 0 0 3px rgba(249, 112, 21, 0.1);
}

#especialistaRegisterPhone:hover {
    border-color: #d0d0d0;
}

#especialistaRegisterPhone:focus:hover {
    border-color: var(--orange-primary, #f97015);
}
</style>

<script>
// Client Modal Functions
// Ensure closeClienteModal is available globally
if (typeof closeClienteModal === 'undefined') {
    function closeClienteModal() {
        const modal = document.getElementById('clienteModal');
        if (modal) {
            modal.classList.remove('modal-active');
            document.body.style.overflow = '';
            // Reset forms
            const loginForm = document.getElementById('loginForm');
            const registerForm = document.getElementById('registerForm');
            if (loginForm) loginForm.reset();
            if (registerForm) registerForm.reset();
        }
    }
    window.closeClienteModal = closeClienteModal;
}

// Ensure switchFormTab is available globally
if (typeof switchFormTab === 'undefined') {
    function switchFormTab(tabName) {
        console.log('Footer script - Switching to tab:', tabName);
        const tabs = document.querySelectorAll('.form-tab');
        const loginForm = document.getElementById('loginForm');
        const registerForm = document.getElementById('registerForm');
        
        // Update tabs
        tabs.forEach(tab => {
            if (tab.getAttribute('data-tab') === tabName) {
                tab.classList.add('active');
            } else {
                tab.classList.remove('active');
            }
        });
        
        // Show/hide forms based on tab
        if (tabName === 'login') {
            if (loginForm) {
                loginForm.classList.add('active-form');
                loginForm.style.display = 'block';
                console.log('Footer - Showing login form');
            }
            if (registerForm) {
                registerForm.classList.remove('active-form');
                registerForm.style.display = 'none';
                console.log('Footer - Hiding register form');
            }
        } else if (tabName === 'register') {
            if (registerForm) {
                registerForm.classList.add('active-form');
                registerForm.style.display = 'block';
                console.log('Footer - Showing register form');
            }
            if (loginForm) {
                loginForm.classList.remove('active-form');
                loginForm.style.display = 'none';
                console.log('Footer - Hiding login form');
            }
        }
    }
    window.switchFormTab = switchFormTab;
}

// Client Modal Event Handlers
document.addEventListener('DOMContentLoaded', function() {
    // Close button handler
    const closeBtn = document.querySelector('#clienteModal .modal-close');
    if (closeBtn) {
        closeBtn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            if (typeof closeClienteModal === 'function') {
                closeClienteModal();
            } else if (window.closeClienteModal) {
                window.closeClienteModal();
            }
        });
    }
    
    // Overlay click handler
    const overlay = document.querySelector('#clienteModal .modal-overlay');
    if (overlay) {
        overlay.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            if (typeof closeClienteModal === 'function') {
                closeClienteModal();
            } else if (window.closeClienteModal) {
                window.closeClienteModal();
            }
        });
    }
    
    // Form tab handlers - Direct implementation with fallback
    const formTabs = document.querySelectorAll('#clienteModal .form-tab');
    console.log('Footer script - Found tabs:', formTabs.length);
    
    formTabs.forEach(tab => {
        tab.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            const tabName = this.getAttribute('data-tab');
            console.log('Footer script - Tab clicked:', tabName);
            
            // Try to use the function if available
            if (typeof switchFormTab === 'function') {
                switchFormTab(tabName);
            } else if (window.switchFormTab) {
                window.switchFormTab(tabName);
            } else {
                // Direct fallback implementation
                console.log('Using direct fallback for tab switching');
                const loginForm = document.getElementById('loginForm');
                const registerForm = document.getElementById('registerForm');
                const allTabs = document.querySelectorAll('#clienteModal .form-tab');
                
                // Update tab active states
                allTabs.forEach(t => {
                    if (t.getAttribute('data-tab') === tabName) {
                        t.classList.add('active');
                    } else {
                        t.classList.remove('active');
                    }
                });
                
                // Show/hide forms
                if (tabName === 'login') {
                    if (loginForm) {
                        loginForm.classList.add('active-form');
                        loginForm.style.display = 'block';
                        console.log('Fallback - Showing login form');
                    }
                    if (registerForm) {
                        registerForm.classList.remove('active-form');
                        registerForm.style.display = 'none';
                        console.log('Fallback - Hiding register form');
                    }
                } else if (tabName === 'register') {
                    if (registerForm) {
                        registerForm.classList.add('active-form');
                        registerForm.style.display = 'block';
                        console.log('Fallback - Showing register form');
                    }
                    if (loginForm) {
                        loginForm.classList.remove('active-form');
                        loginForm.style.display = 'none';
                        console.log('Fallback - Hiding login form');
                    }
                }
            }
        });
    });
    
    // Ensure login form uses AJAX - Direct implementation
    const loginFormFooter = document.getElementById('loginForm');
    if (loginFormFooter) {
        // Clone to remove existing listeners
        const newLoginForm = loginFormFooter.cloneNode(true);
        loginFormFooter.parentNode.replaceChild(newLoginForm, loginFormFooter);
        
        newLoginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            e.stopPropagation();
            console.log('Login form submitted via AJAX (access-forms script)');
            
            const email = document.getElementById('loginEmail');
            const password = document.getElementById('loginPassword');
            const remember = document.querySelector('#loginForm input[name="remember"]');
            
            if (!email || !password) {
                alert('Error: Campos no encontrados. Por favor, recarga la página.');
                return false;
            }
            
            const emailVal = email.value.trim();
            const passwordVal = password.value;
            const rememberChecked = remember ? remember.checked : false;
            
            if (!emailVal || !passwordVal) {
                alert('Por favor, completa todos los campos.');
                return false;
            }
            
            const submitBtn = newLoginForm.querySelector('.form-submit');
            const originalText = submitBtn ? submitBtn.textContent : 'Iniciar Sesión';
            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.textContent = 'Iniciando sesión...';
            }
            
            if (typeof nidfilAjax === 'undefined') {
                alert('Error: Sistema no disponible. Por favor, recarga la página.');
                if (submitBtn) {
                    submitBtn.disabled = false;
                    submitBtn.textContent = originalText;
                }
                return false;
            }
            
            fetch(nidfilAjax.ajaxurl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    action: 'nidfil_login',
                    email: emailVal,
                    password: passwordVal,
                    remember: rememberChecked ? '1' : '0',
                    nonce: nidfilAjax.nonce
                })
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                console.log('Login response:', data);
                if (data.success) {
                    if (submitBtn) {
                        submitBtn.textContent = '¡Éxito! Redirigiendo...';
                    }
                    
                    setTimeout(function() {
                        if (typeof closeClienteModal === 'function') {
                            closeClienteModal();
                        } else if (window.closeClienteModal) {
                            window.closeClienteModal();
                        }
                        
                        let redirectUrl = null;
                        if (data.data && data.data.redirect_url) {
                            redirectUrl = data.data.redirect_url;
                        } else if (nidfilAjax && nidfilAjax.dashboard_url) {
                            redirectUrl = nidfilAjax.dashboard_url;
                        } else {
                            redirectUrl = '/client-profile/';
                        }
                        
                        if (redirectUrl && !redirectUrl.startsWith('http')) {
                            redirectUrl = window.location.origin + (redirectUrl.startsWith('/') ? '' : '/') + redirectUrl;
                        }
                        
                        console.log('Login - Redirecting to:', redirectUrl);
                        if (redirectUrl) {
                            window.location.href = redirectUrl;
                        } else {
                            window.location.href = '/client-profile/';
                        }
                    }, 500);
                } else {
                    alert(data.data && data.data.message ? data.data.message : 'Error al iniciar sesión');
                    if (submitBtn) {
                        submitBtn.disabled = false;
                        submitBtn.textContent = originalText;
                    }
                }
            })
            .catch(error => {
                console.error('Login error:', error);
                alert('Error al iniciar sesión. Por favor, intenta de nuevo.');
                if (submitBtn) {
                    submitBtn.disabled = false;
                    submitBtn.textContent = originalText;
                }
            });
            
            return false;
        });
    }
    
    // Ensure registration form uses AJAX - Direct implementation
    const registerFormFooter = document.getElementById('registerForm');
    if (registerFormFooter) {
        // Clone to remove existing listeners
        const newForm = registerFormFooter.cloneNode(true);
        registerFormFooter.parentNode.replaceChild(newForm, registerFormFooter);
        
        newForm.addEventListener('submit', function(e) {
            e.preventDefault();
            e.stopPropagation();
            console.log('Register form submitted via AJAX (access-forms script)');
            
            const name = document.getElementById('registerName');
            const email = document.getElementById('registerEmail');
            const phone = document.getElementById('registerPhone');
            const password = document.getElementById('registerPassword');
            const passwordConfirm = document.getElementById('registerPasswordConfirm');
            const terms = document.querySelector('#registerForm input[name="terms"]');
            
            if (!name || !email || !password || !passwordConfirm) {
                alert('Error: Campos no encontrados. Por favor, recarga la página.');
                return false;
            }
            
            const nameVal = name.value.trim();
            const emailVal = email.value.trim();
            const phoneVal = phone ? phone.value.trim() : '';
            const passwordVal = password.value;
            const passwordConfirmVal = passwordConfirm.value;
            const termsChecked = terms ? terms.checked : false;
            
            if (!nameVal || !emailVal || !passwordVal || !passwordConfirmVal) {
                alert('Por favor, completa todos los campos requeridos.');
                return false;
            }
            
            if (!termsChecked) {
                alert('Por favor, acepta los términos y condiciones para continuar.');
                return false;
            }
            
            if (passwordVal !== passwordConfirmVal) {
                alert('Las contraseñas no coinciden');
                return false;
            }
            
            if (passwordVal.length < 6) {
                alert('La contraseña debe tener al menos 6 caracteres.');
                return false;
            }
            
            const submitBtn = newForm.querySelector('.form-submit');
            const originalText = submitBtn ? submitBtn.textContent : 'Registrarse';
            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.textContent = 'Registrando...';
            }
            
            if (typeof nidfilAjax === 'undefined') {
                alert('Error: Sistema no disponible. Por favor, recarga la página.');
                if (submitBtn) {
                    submitBtn.disabled = false;
                    submitBtn.textContent = originalText;
                }
                return false;
            }
            
            fetch(nidfilAjax.ajaxurl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    action: 'nidfil_register',
                    name: nameVal,
                    email: emailVal,
                    phone: phoneVal,
                    password: passwordVal,
                    nonce: nidfilAjax.nonce
                })
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                console.log('Registration response:', data);
                if (data.success) {
                    if (submitBtn) {
                        submitBtn.textContent = '¡Éxito! Redirigiendo...';
                    }
                    
                    setTimeout(function() {
                        if (typeof closeClienteModal === 'function') {
                            closeClienteModal();
                        } else if (window.closeClienteModal) {
                            window.closeClienteModal();
                        }
                        
                        let redirectUrl = null;
                        if (data.data && data.data.redirect_url) {
                            redirectUrl = data.data.redirect_url;
                        } else if (nidfilAjax && nidfilAjax.dashboard_url) {
                            redirectUrl = nidfilAjax.dashboard_url;
                        } else {
                            redirectUrl = '/client-profile/';
                        }
                        
                        if (redirectUrl && !redirectUrl.startsWith('http')) {
                            redirectUrl = window.location.origin + (redirectUrl.startsWith('/') ? '' : '/') + redirectUrl;
                        }
                        
                        console.log('Redirecting to:', redirectUrl);
                        if (redirectUrl) {
                            window.location.href = redirectUrl;
                        } else {
                            window.location.href = '/client-profile/';
                        }
                    }, 500);
                } else {
                    alert(data.data && data.data.message ? data.data.message : 'Error al registrarse');
                    if (submitBtn) {
                        submitBtn.disabled = false;
                        submitBtn.textContent = originalText;
                    }
                }
            })
            .catch(error => {
                console.error('Registration error:', error);
                alert('Error al registrarse. Por favor, intenta de nuevo.');
                if (submitBtn) {
                    submitBtn.disabled = false;
                    submitBtn.textContent = originalText;
                }
            });
            
            return false;
        });
    }
});

// Specialist Modal Functions
function openEspecialistaModal() {
    const modal = document.getElementById('especialistaModal');
    if (modal) {
        modal.classList.add('modal-active');
        document.body.style.overflow = 'hidden';
        switchEspecialistaTab('login');
    }
}
window.openEspecialistaModal = openEspecialistaModal;

function closeEspecialistaModal() {
    const modal = document.getElementById('especialistaModal');
    if (modal) {
        modal.classList.remove('modal-active');
        document.body.style.overflow = '';
        const loginForm = document.getElementById('especialistaLoginForm');
        const registerForm = document.getElementById('especialistaRegisterForm');
        if (loginForm) loginForm.reset();
        if (registerForm) registerForm.reset();
        switchEspecialistaTab('login');
    }
}
window.closeEspecialistaModal = closeEspecialistaModal;

function switchEspecialistaTab(tabName) {
    const tabs = document.querySelectorAll('#especialistaModal .form-tab');
    const loginForm = document.getElementById('especialistaLoginForm');
    const registerForm = document.getElementById('especialistaRegisterForm');
    
    tabs.forEach(tab => {
        if (tab.getAttribute('data-tab') === tabName) {
            tab.classList.add('active');
        } else {
            tab.classList.remove('active');
        }
    });
    
    if (tabName === 'login') {
        if (loginForm) {
            loginForm.classList.add('active-form');
            loginForm.style.display = 'block';
        }
        if (registerForm) {
            registerForm.classList.remove('active-form');
            registerForm.style.display = 'none';
        }
    } else if (tabName === 'register') {
        if (registerForm) {
            registerForm.classList.add('active-form');
            registerForm.style.display = 'block';
        }
        if (loginForm) {
            loginForm.classList.remove('active-form');
            loginForm.style.display = 'none';
        }
    }
}
window.switchEspecialistaTab = switchEspecialistaTab;

// Specialist Login Form Handler
document.addEventListener('DOMContentLoaded', function() {
    const especialistaLoginForm = document.getElementById('especialistaLoginForm');
    if (especialistaLoginForm) {
        const newForm = especialistaLoginForm.cloneNode(true);
        especialistaLoginForm.parentNode.replaceChild(newForm, especialistaLoginForm);
        
        // Attach forgot password link handler to the cloned form
        const forgotPasswordLink = newForm.querySelector('#especialistaForgotPassword, .forgot-password');
        if (forgotPasswordLink) {
            console.log('Specialist forgot password link found, attaching handler');
            forgotPasswordLink.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                console.log('Specialist forgot password link clicked');
                if (typeof openResetPasswordModal === 'function') {
                    openResetPasswordModal();
                } else if (window.openResetPasswordModal) {
                    window.openResetPasswordModal();
                } else {
                    console.error('openResetPasswordModal function not found');
                }
            });
        } else {
            console.error('Specialist forgot password link not found in cloned form');
        }
    
        newForm.addEventListener('submit', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            const email = document.getElementById('especialistaLoginEmail').value;
            const password = document.getElementById('especialistaLoginPassword').value;
            const remember = document.querySelector('#especialistaLoginForm input[name="remember"]').checked;
            
            if (!email || !password) {
                alert('Por favor, completa todos los campos.');
                return;
            }
            
            const submitBtn = newForm.querySelector('.form-submit');
            const originalText = submitBtn.textContent;
            submitBtn.disabled = true;
            submitBtn.textContent = 'Iniciando sesión...';
            
            fetch(nidfilAjax.ajaxurl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    action: 'nidfil_login_specialist',
                    email: email,
                    password: password,
                    remember: remember ? '1' : '0',
                    nonce: nidfilAjax.nonce
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    submitBtn.textContent = '¡Éxito! Redirigiendo...';
                    setTimeout(function() {
                        closeEspecialistaModal();
                        let redirectUrl = '/specialist-profile/';
                        if (data.data && data.data.redirect_url) {
                            redirectUrl = data.data.redirect_url;
                        }
                        if (!redirectUrl.startsWith('http')) {
                            redirectUrl = window.location.origin + (redirectUrl.startsWith('/') ? '' : '/') + redirectUrl;
                        }
                        window.location.href = redirectUrl;
                    }, 500);
                } else {
                    const errorMsg = data.data && data.data.message ? data.data.message : 'Error al iniciar sesión';
                    alert(errorMsg);
                    submitBtn.disabled = false;
                    submitBtn.textContent = originalText;
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Error al iniciar sesión. Por favor, intenta de nuevo.');
                submitBtn.disabled = false;
                submitBtn.textContent = originalText;
            });
        });
    }
});

// Specialist Registration Form Handler
const especialistaRegisterForm = document.getElementById('especialistaRegisterForm');
if (especialistaRegisterForm) {
    const newForm = especialistaRegisterForm.cloneNode(true);
    especialistaRegisterForm.parentNode.replaceChild(newForm, especialistaRegisterForm);
    
    newForm.addEventListener('submit', function(e) {
        e.preventDefault();
        e.stopPropagation();
        
        const name = document.getElementById('especialistaRegisterName').value.trim();
        const email = document.getElementById('especialistaRegisterEmail').value.trim();
        const phone = document.getElementById('especialistaRegisterPhone').value.trim();
        const profession = document.getElementById('especialistaRegisterProfession').value.trim();
        const experience = document.getElementById('especialistaRegisterExperience').value;
        const password = document.getElementById('especialistaRegisterPassword').value;
        const passwordConfirm = document.getElementById('especialistaRegisterPasswordConfirm').value;
        const terms = document.querySelector('#especialistaRegisterForm input[name="terms"]').checked;
        
        if (!name || !email || !phone || !profession || !experience || !password || !passwordConfirm) {
            alert('Por favor, completa todos los campos.');
            return;
        }
        
        if (password !== passwordConfirm) {
            alert('Las contraseñas no coinciden.');
            return;
        }
        
        if (!terms) {
            alert('Debes aceptar los términos y condiciones.');
            return;
        }
        
        const submitBtn = newForm.querySelector('.form-submit');
        const originalText = submitBtn.textContent;
        submitBtn.disabled = true;
        submitBtn.textContent = 'Registrando...';
        
        if (typeof nidfilAjax === 'undefined' || !nidfilAjax.ajaxurl || !nidfilAjax.nonce) {
            console.error('nidfilAjax is not defined or missing properties.');
            alert('Error de configuración. Por favor, recarga la página.');
            submitBtn.disabled = false;
            submitBtn.textContent = originalText;
            return;
        }
        
        fetch(nidfilAjax.ajaxurl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({
                action: 'nidfil_register_specialist',
                name: name,
                email: email,
                phone: phone,
                profession: profession,
                experience: experience,
                password: password,
                password_confirm: passwordConfirm,
                terms: terms ? '1' : '0',
                nonce: nidfilAjax.nonce
            })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            console.log('Registration response:', data);
            if (data && data.success) {
                submitBtn.textContent = '¡Éxito! Redirigiendo...';
                setTimeout(function() {
                    if (typeof closeEspecialistaModal === 'function') {
                        closeEspecialistaModal();
                    } else if (window.closeEspecialistaModal) {
                        window.closeEspecialistaModal();
                    }
                    
                    let redirectUrl = null;
                    
                    // Priority 1: Use redirect_url from response
                    if (data.data && data.data.redirect_url) {
                        redirectUrl = data.data.redirect_url;
                    }
                    // Priority 2: Use specialist_dashboard_url from localized script
                    else if (nidfilAjax && nidfilAjax.specialist_dashboard_url) {
                        redirectUrl = nidfilAjax.specialist_dashboard_url;
                    }
                    // Priority 3: Fallback to relative URL
                    else {
                        redirectUrl = '/specialist-profile/';
                    }
                    
                    // Ensure URL is absolute
                    if (redirectUrl && !redirectUrl.startsWith('http') && !redirectUrl.startsWith('//')) {
                        redirectUrl = window.location.origin + (redirectUrl.startsWith('/') ? '' : '/') + redirectUrl;
                    }
                    
                    console.log('Registration successful. Redirecting to:', redirectUrl);
                    
                    if (redirectUrl) {
                        window.location.href = redirectUrl;
                    } else {
                        console.error('No redirect URL available');
                        alert('Error: URL de redirección no encontrada. Redirigiendo a la página principal...');
                        window.location.href = window.location.origin;
                    }
                }, 500);
            } else {
                const errorMsg = data && data.data && data.data.message ? data.data.message : 'Error al registrarse';
                console.error('Registration error:', errorMsg);
                alert(errorMsg);
                submitBtn.disabled = false;
                submitBtn.textContent = originalText;
            }
        })
        .catch(error => {
            console.error('Registration fetch error:', error);
            alert('Error al registrarse. Por favor, intenta de nuevo.');
            submitBtn.disabled = false;
            submitBtn.textContent = originalText;
        });
    });
}
</script>

<!-- Password Reset Modal with OTP -->
<div id="resetPasswordModal" class="access-modal" style="display: none;">
    <div class="modal-overlay" onclick="closeResetPasswordModal()"></div>
    <div class="modal-content access-modal-content">
        <button class="modal-close" onclick="closeResetPasswordModal()" aria-label="Cerrar">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M18 6L6 18M6 6L18 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
        </button>
        
        <div class="modal-body">
            <!-- Step 1: Email Input -->
            <div id="resetStep1" class="reset-step">
                <div class="modal-header">
                    <div style="text-align: center; width: 100%;">
                        <svg width="64" height="64" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin: 0 auto 1rem; display: block; color: var(--orange-primary);">
                            <path d="M3 8L10.89 13.26C11.2187 13.4793 11.6049 13.5963 12 13.5963C12.3951 13.5963 12.7813 13.4793 13.11 13.26L21 8M5 19H19C19.5304 19 20.0391 18.7893 20.4142 18.4142C20.7893 18.0391 21 17.5304 21 17V7C21 6.46957 20.7893 5.96086 20.4142 5.58579C20.0391 5.21071 19.5304 5 19 5H5C4.46957 5 3.96086 5.21071 3.58579 5.58579C3.21071 5.96086 3 6.46957 3 7V17C3 17.5304 3.21071 18.0391 3.58579 18.4142C3.96086 18.7893 4.46957 19 5 19Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                        <h2 class="modal-title">Restablecer Contraseña</h2>
                        <p class="modal-subtitle">Ingresa tu dirección de email y te enviaremos un código OTP</p>
                    </div>
                </div>
                
                <form id="resetPasswordForm" class="access-form" method="post" action="" novalidate>
                    <div class="form-group">
                        <label for="resetPasswordEmail">Email</label>
                        <input type="email" id="resetPasswordEmail" name="email" placeholder="tu@email.com" required autocomplete="email">
                    </div>
                    
                    <button type="submit" class="btn btn-primary form-submit" style="width: 100%;">
                        <span class="submit-text">Enviar Código OTP</span>
                    </button>
                    
                    <div style="text-align: center; margin-top: 1.5rem; font-size: 0.875rem; color: var(--text-light);">
                        <p>¿Recordaste tu contraseña? <a href="javascript:void(0);" onclick="closeResetPasswordModal();" style="color: var(--orange-primary); text-decoration: none; font-weight: 600;">Volver al inicio de sesión</a></p>
                    </div>
                </form>
            </div>
            
            <!-- Step 2: OTP Verification -->
            <div id="resetStep2" class="reset-step" style="display: none;">
                <div class="modal-header">
                    <div style="text-align: center; width: 100%;">
                        <svg width="64" height="64" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin: 0 auto 1rem; display: block; color: var(--orange-primary);">
                            <path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M12 8V12" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M12 16H12.01" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                        <h2 class="modal-title">Verificar Código OTP</h2>
                        <p class="modal-subtitle">Ingresa el código de 6 dígitos enviado a <span id="resetEmailDisplay"></span></p>
                        <p id="otpTimer" style="margin-top: 0.5rem; font-size: 0.875rem; color: var(--orange-primary); font-weight: 600;"></p>
                    </div>
                </div>
                
                <form id="verifyOtpForm" class="access-form" method="post" action="" novalidate>
                    <div class="form-group">
                        <label for="resetOtpCode">Código OTP</label>
                        <input type="text" id="resetOtpCode" name="otp" placeholder="000000" maxlength="6" pattern="[0-9]{6}" required autocomplete="one-time-code" style="text-align: center; font-size: 1.5rem; letter-spacing: 0.5rem; font-weight: 600;">
                    </div>
                    
                    <button type="submit" class="btn btn-primary form-submit" style="width: 100%;">
                        <span class="submit-text">Verificar Código</span>
                    </button>
                    
                    <div style="text-align: center; margin-top: 1rem;">
                        <p style="font-size: 0.875rem; color: var(--text-light);">
                            ¿No recibiste el código? 
                            <a href="javascript:void(0);" id="resendOtpLink" onclick="resendOTP();" style="color: var(--orange-primary); text-decoration: none; font-weight: 600; pointer-events: none; opacity: 0.5;">Reenviar</a>
                        </p>
                    </div>
                    
                    <div style="text-align: center; margin-top: 1.5rem; font-size: 0.875rem; color: var(--text-light);">
                        <a href="javascript:void(0);" onclick="goToResetStep(1);" style="color: var(--orange-primary); text-decoration: none; font-weight: 600;">← Cambiar email</a>
                    </div>
                </form>
            </div>
            
            <!-- Step 3: Set New Password -->
            <div id="resetStep3" class="reset-step" style="display: none;">
                <div class="modal-header">
                    <div style="text-align: center; width: 100%;">
                        <svg width="64" height="64" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin: 0 auto 1rem; display: block; color: var(--orange-primary);">
                            <path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M9 12L11 14L15 10" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                        <h2 class="modal-title">Nueva Contraseña</h2>
                        <p class="modal-subtitle">Ingresa tu nueva contraseña segura</p>
                    </div>
                </div>
                
                <form id="setNewPasswordForm" class="access-form" method="post" action="" novalidate>
                    <div class="form-group">
                        <label for="newPassword">Nueva Contraseña</label>
                        <input type="password" id="newPassword" name="new_password" placeholder="••••••••" required minlength="6" autocomplete="new-password">
                        <small style="color: var(--text-light); font-size: 0.75rem;">Mínimo 6 caracteres. Se recomienda usar letras y números.</small>
                    </div>
                    
                    <div class="form-group">
                        <label for="confirmNewPassword">Confirmar Contraseña</label>
                        <input type="password" id="confirmNewPassword" name="confirm_password" placeholder="••••••••" required minlength="6" autocomplete="new-password">
                    </div>
                    
                    <button type="submit" class="btn btn-primary form-submit" style="width: 100%;">
                        <span class="submit-text">Actualizar Contraseña</span>
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
// Password Reset Modal Functions
// Define password reset modal functions FIRST so they're available for inline handlers
// Make function available globally immediately - this ensures it works with onclick handlers
window.openResetPasswordModal = function() {
    console.log('openResetPasswordModal called');
    
    // Get email from login forms BEFORE opening modal
    // Try multiple methods to find email inputs (in case forms are cloned)
    let emailToPreFill = '';
    
    // Method 1: Try querySelector first (works better with cloned elements)
    let loginEmail = document.querySelector('#loginEmail');
    let especialistaLoginEmail = document.querySelector('#especialistaLoginEmail');
    
    // Method 2: If not found, try getElementById
    if (!loginEmail) {
        loginEmail = document.getElementById('loginEmail');
    }
    if (!especialistaLoginEmail) {
        especialistaLoginEmail = document.getElementById('especialistaLoginEmail');
    }
    
    // Method 3: Check ALL email inputs and find the one with the most recent/valid value
    // This handles cloned forms and ensures we get the current value
    const allEmailInputs = document.querySelectorAll('input[type="email"][id="loginEmail"], input[type="email"][id="especialistaLoginEmail"], #loginForm input[type="email"], #especialistaLoginForm input[type="email"]');
    
    console.log('Found email inputs:', allEmailInputs.length);
    
    // Check each email input and prioritize ones with valid email format
    let foundValidEmail = '';
    let foundAnyEmail = '';
    
    allEmailInputs.forEach((input, index) => {
        // Read CURRENT value directly from the input (not cached)
        const emailValue = (input.value || '').trim();
        const inputId = input.id || 'unknown';
        const formId = input.closest('form')?.id || 'unknown';
        const isVisible = input.offsetParent !== null;
        const formVisible = input.closest('.modal-active, [style*="block"]') !== null;
        
        console.log(`Email input ${index + 1} (id: ${inputId}, form: ${formId}, visible: ${isVisible}, formVisible: ${formVisible}):`, emailValue);
        
        if (emailValue) {
            // Check if it's a valid email format
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (emailRegex.test(emailValue)) {
                // Prioritize visible/active inputs
                if (!foundValidEmail || (isVisible || formVisible)) {
                    foundValidEmail = emailValue;
                    console.log(`✓ Found VALID email in input ${index + 1}:`, foundValidEmail);
                }
            } else if (!foundAnyEmail) {
                foundAnyEmail = emailValue;
                console.log(`  Found invalid email in input ${index + 1}:`, foundAnyEmail);
            }
        }
    });
    
    // Prioritize valid email, otherwise use any email found
    emailToPreFill = foundValidEmail || foundAnyEmail;
    
    // Method 4: Also check which modal is currently active/visible
    if (!emailToPreFill) {
        const clienteModal = document.getElementById('clienteModal');
        const especialistaModal = document.getElementById('especialistaModal');
        
        // Check active client modal
        if (clienteModal && (clienteModal.classList.contains('modal-active') || clienteModal.style.display !== 'none')) {
            const activeForm = clienteModal.querySelector('#loginForm.active-form, #loginForm[style*="block"]');
            if (activeForm) {
                const emailInput = activeForm.querySelector('input[type="email"], input[name="email"]');
                if (emailInput && emailInput.value && emailInput.value.trim()) {
                    emailToPreFill = emailInput.value.trim();
                    console.log('✓ Found email in active client modal form:', emailToPreFill);
                }
            }
        }
        
        // Check active specialist modal
        if (!emailToPreFill && especialistaModal && (especialistaModal.classList.contains('modal-active') || especialistaModal.style.display !== 'none')) {
            const activeForm = especialistaModal.querySelector('#especialistaLoginForm.active-form, #especialistaLoginForm[style*="block"]');
            if (activeForm) {
                const emailInput = activeForm.querySelector('input[type="email"], input[name="email"]');
                if (emailInput && emailInput.value && emailInput.value.trim()) {
                    emailToPreFill = emailInput.value.trim();
                    console.log('✓ Found email in active specialist modal form:', emailToPreFill);
                }
            }
        }
    }
    
    // Final check: Use the direct elements if still no email found
    if (!emailToPreFill) {
        if (loginEmail && loginEmail.value && loginEmail.value.trim()) {
            emailToPreFill = loginEmail.value.trim();
            console.log('✓ Found email via loginEmail element:', emailToPreFill);
        } else if (especialistaLoginEmail && especialistaLoginEmail.value && especialistaLoginEmail.value.trim()) {
            emailToPreFill = especialistaLoginEmail.value.trim();
            console.log('✓ Found email via especialistaLoginEmail element:', emailToPreFill);
        }
    }
    
    console.log('Final emailToPreFill:', emailToPreFill || '(empty)');
    
    // Basic email format validation (silent - no alert)
    let shouldAutoSend = false;
    if (emailToPreFill) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        const isValidEmail = emailRegex.test(emailToPreFill);
        console.log('Email validation check:', emailToPreFill, 'is valid:', isValidEmail);
        if (isValidEmail) {
            shouldAutoSend = true; // Valid email - auto-send OTP
            console.log('✓ Email is valid, will auto-send OTP');
        } else {
            console.log('✗ Email format is invalid, will show Step 1 for user to correct');
        }
    } else {
        console.log('✗ No email found to validate');
    }
    
    // Open modal regardless of email (no alerts)
    const modal = document.getElementById('resetPasswordModal');
    if (modal) {
        console.log('Modal found, opening...');
        
        // Get step elements
        const step1 = document.getElementById('resetStep1');
        const step2 = document.getElementById('resetStep2');
        const step3 = document.getElementById('resetStep3');
        
        // Ensure modal is visible
        modal.style.display = 'flex';
        modal.classList.add('modal-active');
        document.body.style.overflow = 'hidden';
        
        // If email is valid, skip Step 1 and go directly to Step 2 (OTP Verification)
        if (shouldAutoSend && emailToPreFill) {
            console.log('Valid email found, opening directly to Step 2 (OTP Verification)');
            
            // Hide Step 1, Show Step 2, Hide Step 3
            if (step1) step1.style.display = 'none';
            if (step2) step2.style.display = 'block';
            if (step3) step3.style.display = 'none';
            
            // Store email globally
            resetEmail = emailToPreFill;
            
            // Update email display in Step 2
            setTimeout(function() {
                const emailDisplay = document.getElementById('resetEmailDisplay');
                if (emailDisplay) {
                    emailDisplay.textContent = emailToPreFill;
                }
                
                // Focus on OTP input
                const otpInput = document.getElementById('resetOtpCode');
                if (otpInput) {
                    otpInput.focus();
                }
            }, 100);
            
            // Automatically send OTP request
            if (typeof nidfilAjax !== 'undefined') {
                console.log('Auto-sending OTP for email:', emailToPreFill);
                
                fetch(nidfilAjax.ajaxurl, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: new URLSearchParams({
                        action: 'nidfil_request_otp',
                        email: emailToPreFill,
                        nonce: nidfilAjax.nonce
                    })
                })
                .then(async response => {
                    // Check if response is actually JSON
                    const contentType = response.headers.get('content-type');
                    if (!contentType || !contentType.includes('application/json')) {
                        // Response is not JSON, get text to see what we got
                        const text = await response.text();
                        console.error('AJAX response is not JSON. Content-Type:', contentType);
                        console.error('Response text (first 500 chars):', text.substring(0, 500));
                        throw new Error('Server returned HTML instead of JSON. This usually means the AJAX endpoint failed or the nonce is invalid.');
                    }
                    
                    if (!response.ok) {
                        throw new Error('Network response was not ok: ' + response.status);
                    }
                    
                    return response.json();
                })
                .then(data => {
                    console.log('Auto OTP request response:', data);
                    if (data.success) {
                        // Check if OTP is in response (development mode)
                        // OTP is sent via email - no alert needed
                        if (data.data && data.data.debug_otp) {
                            // Only log to console for debugging (no alert)
                            console.log('🔐 DEVELOPMENT MODE - OTP Code:', data.data.debug_otp);
                            console.log('📧', data.data.debug_message || 'OTP sent via email');
                        }
                        
                        // Start OTP timer
                        if (typeof startOTPTimer === 'function') {
                            startOTPTimer();
                        }
                        
                        // Show success message (optional - could be a toast notification)
                        console.log('OTP sent successfully to:', emailToPreFill);
                    } else {
                        // Error sending OTP - fallback to Step 1
                        const errorMsg = data.data && data.data.message ? data.data.message : 'Error al enviar el código OTP.';
                        console.error('OTP send error:', errorMsg);
                        
                        // Go back to Step 1 so user can try again
                        if (step1) step1.style.display = 'block';
                        if (step2) step2.style.display = 'none';
                        
                        // Pre-fill email in Step 1
                        const resetEmailInput = document.getElementById('resetPasswordEmail');
                        if (resetEmailInput) {
                            resetEmailInput.value = emailToPreFill;
                            resetEmailInput.focus();
                        }
                    }
                })
                .catch(error => {
                    console.error('Auto OTP request error:', error);
                    // Fallback to Step 1 on error
                    if (step1) step1.style.display = 'block';
                    if (step2) step2.style.display = 'none';
                    
                    const resetEmailInput = document.getElementById('resetPasswordEmail');
                    if (resetEmailInput) {
                        resetEmailInput.value = emailToPreFill;
                        resetEmailInput.focus();
                    }
                });
            } else {
                console.error('nidfilAjax is undefined');
                // Fallback to Step 1
                if (step1) step1.style.display = 'block';
                if (step2) step2.style.display = 'none';
            }
        } else {
            // No valid email - show Step 1 (Email Input)
            console.log('No valid email, showing Step 1 (Email Input)');
            if (step1) step1.style.display = 'block';
            if (step2) step2.style.display = 'none';
            if (step3) step3.style.display = 'none';
            
            // Pre-fill email if it exists (even if invalid format)
            setTimeout(function() {
                const resetEmailInput = document.getElementById('resetPasswordEmail');
                if (resetEmailInput) {
                    if (emailToPreFill) {
                        resetEmailInput.value = emailToPreFill;
                        resetEmailInput.focus();
                        resetEmailInput.select();
                    } else {
                        resetEmailInput.focus();
                    }
                }
            }, 200);
        }
        
        console.log('Modal should now be visible');
    } else {
        console.error('Reset password modal not found');
        // Only show alert for critical errors
        alert('Error: No se pudo abrir el modal de restablecimiento de contraseña.');
    }
};

// Create a named function alias for convenience
function openResetPasswordModal() {
    window.openResetPasswordModal();
}

// Make close function available globally immediately
window.closeResetPasswordModal = function() {
    const modal = document.getElementById('resetPasswordModal');
    if (modal) {
        modal.classList.remove('modal-active');
        // Hide modal after transition
        setTimeout(function() {
            modal.style.display = 'none';
        }, 300);
        document.body.style.overflow = '';
        
        // Reset all forms and steps
        const resetForm = document.getElementById('resetPasswordForm');
        const verifyForm = document.getElementById('verifyOtpForm');
        const passwordForm = document.getElementById('setNewPasswordForm');
        
        if (resetForm) {
            resetForm.reset();
            const submitBtn = resetForm.querySelector('.form-submit');
            if (submitBtn) {
                const submitText = submitBtn.querySelector('.submit-text');
                if (submitText) {
                    submitText.textContent = 'Enviar Código OTP';
                }
                submitBtn.disabled = false;
            }
        }
        
        if (verifyForm) {
            verifyForm.reset();
            const submitBtn = verifyForm.querySelector('.form-submit');
            if (submitBtn) {
                const submitText = submitBtn.querySelector('.submit-text');
                if (submitText) {
                    submitText.textContent = 'Verificar Código';
                }
                submitBtn.disabled = false;
            }
        }
        
        if (passwordForm) {
            passwordForm.reset();
            const submitBtn = passwordForm.querySelector('.form-submit');
            if (submitBtn) {
                const submitText = submitBtn.querySelector('.submit-text');
                if (submitText) {
                    submitText.textContent = 'Actualizar Contraseña';
                }
                submitBtn.disabled = false;
            }
        }
        
        // Reset to step 1
        const step1 = document.getElementById('resetStep1');
        const step2 = document.getElementById('resetStep2');
        const step3 = document.getElementById('resetStep3');
        if (step1) step1.style.display = 'block';
        if (step2) step2.style.display = 'none';
        if (step3) step3.style.display = 'none';
        
        // Clear OTP timer
        if (typeof clearOTPTimer === 'function') {
            clearOTPTimer();
        }
        
        // Clear global variables
        if (typeof resetEmail !== 'undefined') {
            resetEmail = '';
        }
    }
};

// Also create a named function for reference
function closeResetPasswordModal() {
    window.closeResetPasswordModal();
}

// Handle forgot password link clicks - Use event delegation to work with cloned forms
// Use event delegation on document to catch clicks on all forgot password links (works even after cloning)
document.addEventListener('click', function(e) {
    // Check if the clicked element is a forgot-password link by ID or class
    const target = e.target;
    const forgotPasswordLink = target.closest ? target.closest('.forgot-password, #clienteForgotPassword, #especialistaForgotPassword') : null;
    
    if (forgotPasswordLink || 
        (target && target.id && (target.id === 'clienteForgotPassword' || target.id === 'especialistaForgotPassword')) ||
        (target && target.classList && target.classList.contains('forgot-password'))) {
        e.preventDefault();
        e.stopPropagation();
        console.log('Forgot password link clicked via event delegation');
        if (typeof openResetPasswordModal === 'function') {
            openResetPasswordModal();
        } else if (window.openResetPasswordModal) {
            window.openResetPasswordModal();
        } else {
            console.error('openResetPasswordModal function not available');
        }
    }
});

// Password Reset Multi-Step Variables (global scope so they're accessible everywhere)
let resetEmail = '';
let otpTimer = null;

// Handle password reset form submission - Use event delegation (outside DOMContentLoaded so it's always active)
document.addEventListener('submit', function(e) {
    if (e.target && e.target.id === 'resetPasswordForm') {
        e.preventDefault();
        e.stopPropagation();
        console.log('Reset password form submitted via event delegation');
        
        const email = document.getElementById('resetPasswordEmail');
        if (!email) {
            console.error('Email input not found');
            alert('Error: Campo de email no encontrado.');
            return false;
        }
        
        const emailVal = email.value.trim();
        if (!emailVal) {
            alert('Por favor, ingresa tu dirección de email.');
            return false;
        }
        
        // Basic email validation
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(emailVal)) {
            alert('Por favor, ingresa una dirección de email válida.');
            return false;
        }
        
        // Proceed with sending OTP
        const submitBtn = e.target.querySelector('.form-submit');
        const submitText = submitBtn ? submitBtn.querySelector('.submit-text') : null;
        const originalText = submitText ? submitText.textContent : 'Enviar Código OTP';
        
        if (submitBtn) {
            submitBtn.disabled = true;
            if (submitText) {
                submitText.textContent = 'Enviando...';
            } else {
                submitBtn.textContent = 'Enviando...';
            }
        }
        
        if (typeof nidfilAjax === 'undefined') {
            console.error('nidfilAjax is undefined');
            alert('Error: Sistema no disponible. Por favor, recarga la página.');
            if (submitBtn) {
                submitBtn.disabled = false;
                if (submitText) {
                    submitText.textContent = originalText;
                } else {
                    submitBtn.textContent = originalText;
                }
            }
            return false;
        }
        
        resetEmail = emailVal;
        console.log('Sending OTP request for email:', emailVal);
        
        fetch(nidfilAjax.ajaxurl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({
                action: 'nidfil_request_otp',
                email: emailVal,
                nonce: nidfilAjax.nonce
            })
        })
        .then(response => {
            console.log('OTP request response status:', response.status);
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            console.log('OTP request response data:', data);
            if (data.success) {
                // Show OTP input field
                const otpInputGroup = document.getElementById('otpInputGroup');
                const otpInput = document.getElementById('resetOtpCodeStep1');
                const resendContainer = document.getElementById('resendOtpContainerStep1');
                const resendLink = document.getElementById('resendOtpLinkStep1');
                
                if (otpInputGroup) {
                    otpInputGroup.style.display = 'block';
                }
                if (resendContainer) {
                    resendContainer.style.display = 'block';
                }
                
                // Update button text
                if (submitText) submitText.textContent = 'Verificar Código OTP';
                
                // Focus on OTP input
                if (otpInput) {
                    setTimeout(() => {
                        otpInput.focus();
                    }, 100);
                }
                
                // Start OTP timer
                if (typeof startOTPTimerStep1 === 'function') {
                    startOTPTimerStep1();
                } else {
                    // Fallback timer
                    let timeLeft = 120; // 2 minutes
                    const timerElement = document.getElementById('otpTimerStep1');
                    const timerInterval = setInterval(() => {
                        const minutes = Math.floor(timeLeft / 60);
                        const seconds = timeLeft % 60;
                        if (timerElement) {
                            timerElement.textContent = `El código expira en: ${minutes}:${seconds.toString().padStart(2, '0')}`;
                        }
                        timeLeft--;
                        if (timeLeft < 0) {
                            clearInterval(timerInterval);
                            if (timerElement) {
                                timerElement.textContent = 'Código expirado';
                                timerElement.style.color = 'var(--error-color, #dc3545)';
                            }
                            if (resendLink) {
                                resendLink.style.pointerEvents = 'auto';
                                resendLink.style.opacity = '1';
                            }
                        }
                    }, 1000);
                    window.otpTimerStep1 = timerInterval;
                }
                
                // Store that OTP was sent
                e.target.setAttribute('data-otp-sent', 'true');
                
                // Store email for resend functionality
                if (!window.resetEmailStep1) {
                    window.resetEmailStep1 = emailVal;
                }
            } else {
                alert(data.data && data.data.message ? data.data.message : 'Error al enviar el código OTP.');
                if (submitBtn) {
                    submitBtn.disabled = false;
                    if (submitText) {
                        submitText.textContent = originalText;
                    } else {
                        submitBtn.textContent = originalText;
                    }
                }
            }
        })
        .catch(error => {
            console.error('OTP request error:', error);
            alert('Error al enviar el código. Por favor, intenta de nuevo.');
            if (submitBtn) {
                submitBtn.disabled = false;
                if (submitText) {
                    submitText.textContent = originalText;
                } else {
                    submitBtn.textContent = originalText;
                }
            }
        });
        
        return false;
    }
});

// Step 2: Verify OTP
document.addEventListener('DOMContentLoaded', function() {
    const verifyOtpForm = document.getElementById('verifyOtpForm');
    if (verifyOtpForm) {
        verifyOtpForm.addEventListener('submit', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            const otpInput = document.getElementById('resetOtpCode');
            if (!otpInput) {
                alert('Error: Campo OTP no encontrado.');
                return false;
            }
            
            const otpVal = otpInput.value.trim();
            if (!otpVal || otpVal.length !== 6) {
                alert('Por favor, ingresa un código OTP válido de 6 dígitos.');
                return false;
            }
            
            const submitBtn = verifyOtpForm.querySelector('.form-submit');
            const submitText = submitBtn ? submitBtn.querySelector('.submit-text') : null;
            const originalText = submitText ? submitText.textContent : 'Verificar Código';
            
            if (submitBtn) {
                submitBtn.disabled = true;
                if (submitText) submitText.textContent = 'Verificando...';
            }
            
            if (typeof nidfilAjax === 'undefined') {
                alert('Error: Sistema no disponible.');
                if (submitBtn) {
                    submitBtn.disabled = false;
                    if (submitText) submitText.textContent = originalText;
                }
                return false;
            }
            
            fetch(nidfilAjax.ajaxurl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    action: 'nidfil_verify_otp',
                    email: resetEmail,
                    otp: otpVal,
                    nonce: nidfilAjax.nonce
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    if (submitText) submitText.textContent = '✓ Verificado';
                    clearOTPTimer();
                    goToResetStep(3);
                } else {
                    alert(data.data && data.data.message ? data.data.message : 'Código OTP inválido o expirado.');
                    if (submitBtn) {
                        submitBtn.disabled = false;
                        if (submitText) submitText.textContent = originalText;
                    }
                    otpInput.value = '';
                    otpInput.focus();
                }
            })
            .catch(error => {
                console.error('OTP verification error:', error);
                alert('Error al verificar el código. Por favor, intenta de nuevo.');
                if (submitBtn) {
                    submitBtn.disabled = false;
                    if (submitText) submitText.textContent = originalText;
                }
            });
            
            return false;
        });
    }
    
    // Step 3: Set New Password
    const setNewPasswordForm = document.getElementById('setNewPasswordForm');
    if (setNewPasswordForm) {
        setNewPasswordForm.addEventListener('submit', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            const newPassword = document.getElementById('newPassword');
            const confirmPassword = document.getElementById('confirmNewPassword');
            
            if (!newPassword || !confirmPassword) {
                alert('Error: Campos no encontrados.');
                return false;
            }
            
            const newPassVal = newPassword.value;
            const confirmPassVal = confirmPassword.value;
            
            // Validate password rules
            if (!newPassVal) {
                alert('Por favor, ingresa una nueva contraseña.');
                return false;
            }
            
            if (newPassVal.length < 6) {
                alert('La contraseña debe tener al menos 6 caracteres.');
                newPassword.focus();
                return false;
            }
            
            // Password strength validation (optional but recommended)
            // Check for at least one letter and one number for better security
            const hasLetter = /[a-zA-Z]/.test(newPassVal);
            const hasNumber = /[0-9]/.test(newPassVal);
            
            if (!hasLetter || !hasNumber) {
                if (!confirm('La contraseña es débil. Se recomienda usar letras y números. ¿Deseas continuar de todos modos?')) {
                    newPassword.focus();
                    return false;
                }
            }
            
            if (newPassVal !== confirmPassVal) {
                alert('Las contraseñas no coinciden. Por favor, verifica que ambas contraseñas sean iguales.');
                confirmPassword.focus();
                return false;
            }
            
            const submitBtn = setNewPasswordForm.querySelector('.form-submit');
            const submitText = submitBtn ? submitBtn.querySelector('.submit-text') : null;
            const originalText = submitText ? submitText.textContent : 'Actualizar Contraseña';
            
            if (submitBtn) {
                submitBtn.disabled = true;
                if (submitText) submitText.textContent = 'Actualizando...';
            }
            
            if (typeof nidfilAjax === 'undefined') {
                alert('Error: Sistema no disponible.');
                if (submitBtn) {
                    submitBtn.disabled = false;
                    if (submitText) submitText.textContent = originalText;
                }
                return false;
            }
            
            fetch(nidfilAjax.ajaxurl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    action: 'nidfil_update_password',
                    email: resetEmail,
                    new_password: newPassVal,
                    nonce: nidfilAjax.nonce
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    if (submitText) submitText.textContent = '✓ Contraseña Actualizada';
                    alert('¡Contraseña actualizada exitosamente! Ahora puedes iniciar sesión con tu nueva contraseña.');
                    setTimeout(function() {
                        closeResetPasswordModal();
                        window.location.reload();
                    }, 1500);
                } else {
                    alert(data.data && data.data.message ? data.data.message : 'Error al actualizar la contraseña.');
                    if (submitBtn) {
                        submitBtn.disabled = false;
                        if (submitText) submitText.textContent = originalText;
                    }
                }
            })
            .catch(error => {
                console.error('Password update error:', error);
                alert('Error al actualizar la contraseña. Por favor, intenta de nuevo.');
                if (submitBtn) {
                    submitBtn.disabled = false;
                    if (submitText) submitText.textContent = originalText;
                }
            });
            
            return false;
        });
    }
    
    // Helper functions for multi-step process
    function goToResetStep(step) {
        document.getElementById('resetStep1').style.display = step === 1 ? 'block' : 'none';
        document.getElementById('resetStep2').style.display = step === 2 ? 'block' : 'none';
        document.getElementById('resetStep3').style.display = step === 3 ? 'block' : 'none';
    }
    window.goToResetStep = goToResetStep;
    
    function startOTPTimer() {
        clearOTPTimer();
        const timerElement = document.getElementById('otpTimer');
        const resendLink = document.getElementById('resendOtpLink');
        let timeLeft = 120; // 2 minutes
        
        function updateTimer() {
            const minutes = Math.floor(timeLeft / 60);
            const seconds = timeLeft % 60;
            if (timerElement) {
                timerElement.textContent = `El código expira en: ${minutes}:${seconds.toString().padStart(2, '0')}`;
            }
            
            if (timeLeft <= 0) {
                clearOTPTimer();
                if (timerElement) {
                    timerElement.textContent = 'El código ha expirado.';
                    timerElement.style.color = 'var(--text-light)';
                }
                if (resendLink) {
                    resendLink.style.pointerEvents = 'auto';
                    resendLink.style.opacity = '1';
                }
            } else {
                timeLeft--;
                otpTimer = setTimeout(updateTimer, 1000);
            }
        }
        
        updateTimer();
    }
    window.startOTPTimer = startOTPTimer;
    
    function clearOTPTimer() {
        if (otpTimer) {
            clearTimeout(otpTimer);
            otpTimer = null;
        }
    }
    window.clearOTPTimer = clearOTPTimer;
    
    // Resend OTP from Step 1
    window.resendOTPFromStep1 = function() {
        const email = document.getElementById('resetPasswordEmail');
        const emailVal = email ? email.value.trim() : (window.resetEmailStep1 || resetEmail);
        
        if (!emailVal) {
            alert('Error: No se encontró el email.');
            return;
        }
        
        const resendLink = document.getElementById('resendOtpLinkStep1');
        if (resendLink) {
            resendLink.style.pointerEvents = 'none';
            resendLink.style.opacity = '0.5';
            resendLink.textContent = 'Reenviando...';
        }
        
        if (typeof nidfilAjax === 'undefined') {
            alert('Error: Sistema no disponible.');
            if (resendLink) {
                resendLink.style.pointerEvents = 'auto';
                resendLink.style.opacity = '1';
                resendLink.textContent = 'Reenviar';
            }
            return;
        }
        
        fetch(nidfilAjax.ajaxurl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({
                action: 'nidfil_request_otp',
                email: emailVal,
                nonce: nidfilAjax.nonce
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Reset timer
                if (window.otpTimerStep1) {
                    clearInterval(window.otpTimerStep1);
                }
                
                // Restart timer
                let timeLeft = 120;
                const timerElement = document.getElementById('otpTimerStep1');
                const resendLink = document.getElementById('resendOtpLinkStep1');
                
                if (timerElement) {
                    timerElement.style.color = 'var(--orange-primary)';
                }
                
                window.otpTimerStep1 = setInterval(() => {
                    const minutes = Math.floor(timeLeft / 60);
                    const seconds = timeLeft % 60;
                    if (timerElement) {
                        timerElement.textContent = `El código expira en: ${minutes}:${seconds.toString().padStart(2, '0')}`;
                    }
                    timeLeft--;
                    if (timeLeft < 0) {
                        clearInterval(window.otpTimerStep1);
                        if (timerElement) {
                            timerElement.textContent = 'Código expirado';
                            timerElement.style.color = 'var(--error-color, #dc3545)';
                        }
                        if (resendLink) {
                            resendLink.style.pointerEvents = 'auto';
                            resendLink.style.opacity = '1';
                        }
                    }
                }, 1000);
                
                // Reset resend link
                if (resendLink) {
                    resendLink.style.pointerEvents = 'none';
                    resendLink.style.opacity = '0.5';
                    resendLink.textContent = 'Reenviar';
                }
                
                // Clear OTP input
                const otpInput = document.getElementById('resetOtpCodeStep1');
                if (otpInput) {
                    otpInput.value = '';
                    otpInput.focus();
                }
            } else {
                alert(data.data && data.data.message ? data.data.message : 'Error al reenviar el código OTP.');
                if (resendLink) {
                    resendLink.style.pointerEvents = 'auto';
                    resendLink.style.opacity = '1';
                    resendLink.textContent = 'Reenviar';
                }
            }
        })
        .catch(error => {
            console.error('Resend OTP error:', error);
            alert('Error al reenviar el código. Por favor, intenta de nuevo.');
            if (resendLink) {
                resendLink.style.pointerEvents = 'auto';
                resendLink.style.opacity = '1';
                resendLink.textContent = 'Reenviar';
            }
        });
    };
    
    function resendOTP() {
        if (!resetEmail) {
            goToResetStep(1);
            return;
        }
        
        const resendLink = document.getElementById('resendOtpLink');
        if (resendLink) {
            resendLink.style.pointerEvents = 'none';
            resendLink.style.opacity = '0.5';
            resendLink.textContent = 'Reenviando...';
        }
        
        if (typeof nidfilAjax === 'undefined') {
            alert('Error: Sistema no disponible.');
            return;
        }
        
        fetch(nidfilAjax.ajaxurl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({
                action: 'nidfil_request_otp',
                email: resetEmail,
                nonce: nidfilAjax.nonce
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Nuevo código OTP enviado a tu email.');
                document.getElementById('resetOtpCode').value = '';
                startOTPTimer();
            } else {
                alert(data.data && data.data.message ? data.data.message : 'Error al reenviar el código.');
                if (resendLink) {
                    resendLink.style.pointerEvents = 'auto';
                    resendLink.style.opacity = '1';
                    resendLink.textContent = 'Reenviar';
                }
            }
        })
        .catch(error => {
            console.error('Resend OTP error:', error);
            alert('Error al reenviar el código. Por favor, intenta de nuevo.');
            if (resendLink) {
                resendLink.style.pointerEvents = 'auto';
                resendLink.style.opacity = '1';
                resendLink.textContent = 'Reenviar';
            }
        });
    }
    window.resendOTP = resendOTP;
});
</script>

