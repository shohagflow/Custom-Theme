<?php
/**
 * Template Functions
 *
 * @package NIDFIL_Connect
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Display the site logo
 */
function nidfil_the_logo() {
    $logo_url = get_theme_mod('custom_logo');
    if ($logo_url) {
        echo wp_get_attachment_image($logo_url, 'full', false, array('class' => 'site-logo-img'));
    } else {
        ?>
        <a href="<?php echo esc_url(home_url('/')); ?>" class="site-logo" rel="home">
            <div class="logo-square">N</div>
            <span class="logo-text">NIDFIL</span>
        </a>
        <?php
    }
}

