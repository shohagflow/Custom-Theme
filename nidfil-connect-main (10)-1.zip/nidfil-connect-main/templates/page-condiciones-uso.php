<?php
/**
 * Template Name: Condiciones de Uso de la Plataforma
 *
 * @package NIDFIL_Connect
 */

get_header();
?>

<main id="main" class="site-main legal-page">
    <section class="legal-hero">
        <div class="section-container">
            <h1 class="legal-title">Condiciones de Uso de la Plataforma</h1>
            <p class="legal-intro">
                Reglas y condiciones que regulan el uso de la plataforma digital NIDFIL por parte de clientes y profesionales.
            </p>
        </div>
    </section>

    <section class="legal-content-section">
        <div class="section-container legal-content">
            <article class="legal-card">
                <h2>Condiciones de uso de la plataforma</h2>
                <p>
                    NIDFIL es una plataforma digital que pone en contacto a clientes y profesionales del sector de reformas,
                    obra nueva y servicios relacionados.
                </p>

                <h2>Intermediación</h2>
                <p>
                    NIDFIL actúa exclusivamente como intermediario y no ejecuta trabajos ni gestiona pagos entre usuarios
                    en esta fase. Los profesionales son responsables de cumplir la legislación vigente, disponer de licencias
                    y seguros necesarios y responder directamente ante el cliente.
                </p>
                <p>
                    Los clientes aceptan contactar directamente con los profesionales y asumir la responsabilidad de los
                    acuerdos alcanzados. NIDFIL no será responsable de conflictos, incumplimientos, daños o perjuicios
                    derivados de la relación entre usuarios.
                </p>

                <h2>RGPD técnico obligatorio</h2>
                <p>
                    En los formularios de registro se incluirá un <strong>checkbox obligatorio</strong> con el texto:
                    “He leído y acepto el Aviso Legal, la Política de Privacidad y las Condiciones de Uso.” El registro
                    no podrá completarse sin marcarlo y el consentimiento quedará registrado en la base de datos.
                </p>
                <p>
                    La plataforma deberá disponer de un banner de cookies que bloquee las cookies analíticas hasta que
                    el usuario otorgue su aceptación.
                </p>

                <h2>Seguridad</h2>
                <p>
                    La plataforma deberá contar, como mínimo, con las siguientes medidas técnicas de seguridad:
                </p>
                <ul>
                    <li>SSL activo (https) en todo el sitio.</li>
                    <li>Contraseñas encriptadas.</li>
                    <li>Protección antispam y antibots.</li>
                    <li>Limitación de intentos de acceso.</li>
                    <li>Copias de seguridad automáticas.</li>
                    <li>Roles separados: cliente / especialista / administrador.</li>
                </ul>

                <h2>Enfoque de intermediación</h2>
                <p>
                    En ningún texto de la web debe sugerirse que NIDFIL ejecuta obras o presta servicios profesionales.
                    Debe quedar claro que actúa únicamente como plataforma intermediaria.
                </p>

                <h2>Preparación futura</h2>
                <p>
                    Se dejará preparada la estructura técnica para activar en el futuro pagos o cobro por contacto desde
                    el panel de administración, manteniéndose todo desactivado por defecto hasta nueva decisión del titular.
                </p>

                <h2>Propiedad y entrega</h2>
                <p>
                    El dominio y el hosting se mantendrán a nombre del titular de NIDFIL. Este dispondrá de acceso como
                    administrador principal y tendrá derecho a una copia completa de la web (archivos y base de datos)
                    al finalizar el proyecto.
                </p>

                <h2>Modificación de las condiciones</h2>
                <p>
                    NIDFIL se reserva el derecho de modificar estas condiciones en cualquier momento. Las modificaciones
                    serán de aplicación desde su publicación en la plataforma.
                </p>
            </article>
        </div>
    </section>
</main>

<?php
get_footer();


