<?php
/**
 * Template Name: Política de Privacidad (RGPD)
 *
 * @package NIDFIL_Connect
 */

get_header();
?>

<main id="main" class="site-main legal-page">
    <section class="legal-hero">
        <div class="section-container">
            <h1 class="legal-title">Política de Privacidad (RGPD)</h1>
            <p class="legal-intro">
                Cómo tratamos y protegemos tus datos personales cuando utilizas la plataforma digital NIDFIL.
            </p>
        </div>
    </section>

    <section class="legal-content-section">
        <div class="section-container legal-content">
            <article class="legal-card">
                <h2>Responsable del tratamiento</h2>
                <p>
                    <strong>NIDFIL Plataforma Digital</strong> es la responsable del tratamiento de los datos personales
                    de los usuarios de la plataforma.
                </p>
                <p>
                    Correo: <a href="mailto:info@nidfil.com">info@nidfil.com</a><br>
                    País: España
                </p>

                <h2>Datos recogidos</h2>
                <p>
                    Nombre, apellidos, correo electrónico, teléfono (si se facilita), fotografías o archivos subidos
                    voluntariamente, mensajes enviados a través de la plataforma y datos técnicos de navegación.
                </p>

                <h2>Finalidad</h2>
                <p>
                    Gestión del registro de usuarios, contacto entre clientes y profesionales, comunicaciones internas,
                    mejora de la plataforma y atención de consultas.
                </p>

                <h2>Base legal</h2>
                <p>
                    Consentimiento del usuario y ejecución de la relación de uso de la plataforma.
                </p>

                <h2>Conservación</h2>
                <p>
                    Los datos se conservarán mientras la cuenta esté activa o durante el tiempo necesario para cumplir
                    obligaciones legales.
                </p>

                <h2>Derechos</h2>
                <p>
                    Acceso, rectificación, supresión, oposición, limitación y portabilidad mediante solicitud a
                    <a href="mailto:info@nidfil.com">info@nidfil.com</a>.
                </p>

                <h2>Cesión de datos</h2>
                <p>
                    No se cederán datos a terceros salvo obligación legal o proveedores técnicos necesarios.
                </p>

                <h2>Seguridad</h2>
                <p>
                    Se aplican medidas técnicas y organizativas adecuadas para garantizar la seguridad de los datos.
                </p>
            </article>
        </div>
    </section>
</main>

<?php
get_footer();


