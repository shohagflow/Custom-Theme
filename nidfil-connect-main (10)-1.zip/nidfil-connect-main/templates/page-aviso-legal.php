<?php
/**
 * Template Name: Aviso Legal
 *
 * @package NIDFIL_Connect
 */

get_header();
?>

<main id="main" class="site-main legal-page">
    <section class="legal-hero">
        <div class="section-container">
            <h1 class="legal-title">Aviso Legal</h1>
            <p class="legal-intro">
                Información legal y condiciones de uso de la plataforma digital NIDFIL.
            </p>
        </div>
    </section>

    <section class="legal-content-section">
        <div class="section-container legal-content">
            <article class="legal-card">
                <h2>Titular de la web</h2>
                <p><strong>NIDFIL Plataforma Digital</strong></p>

                <h2>Correo electrónico de contacto</h2>
                <p><a href="mailto:info@nidfil.com">info@nidfil.com</a></p>

                <h2>Dominio</h2>
                <p><a href="https://www.nidfil.com" target="_blank" rel="noopener noreferrer">https://www.nidfil.com</a></p>

                <h2>Actividad</h2>
                <p>
                    Plataforma digital de intermediación que conecta a clientes con profesionales y empresas del
                    sector de reformas, obra nueva y servicios asociados.
                </p>

                <h2>Condiciones de uso</h2>
                <p>
                    El acceso y uso del sitio web <strong>www.nidfil.com</strong> atribuye la condición de usuario e implica
                    la aceptación plena y sin reservas del presente Aviso Legal.
                </p>
                <p>
                    El usuario se compromete a hacer un uso adecuado del sitio web y a no emplearlo para actividades
                    ilícitas o contrarias a la buena fe.
                </p>

                <h2>Responsabilidad</h2>
                <p>
                    <strong>NIDFIL</strong> actúa exclusivamente como plataforma intermediaria.
                </p>
                <p>
                    NIDFIL no ejecuta trabajos, no garantiza resultados, no interviene en acuerdos ni pagos entre las
                    partes y no se responsabiliza de la calidad, cumplimiento o legalidad de los servicios prestados
                    por los profesionales.
                </p>
                <p>
                    La responsabilidad de los trabajos realizados recae exclusivamente en el profesional contratado.
                </p>

                <h2>Propiedad intelectual</h2>
                <p>
                    Todos los contenidos del sitio web (textos, diseño, logotipos, imágenes, código fuente y
                    estructura) son titularidad de <strong>NIDFIL Plataforma Digital</strong> o de terceros autorizados.
                </p>

                <h2>Legislación aplicable</h2>
                <p>
                    La relación entre NIDFIL y el usuario se rige por la normativa española vigente.
                </p>
            </article>
        </div>
    </section>
</main>

<?php
get_footer();


