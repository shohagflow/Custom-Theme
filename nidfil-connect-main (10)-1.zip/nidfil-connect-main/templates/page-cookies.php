<?php
/**
 * Template Name: Política de Cookies
 *
 * @package NIDFIL_Connect
 */

get_header();
?>

<main id="main" class="site-main legal-page">
    <section class="legal-hero">
        <div class="section-container">
            <h1 class="legal-title">Política de Cookies</h1>
            <p class="legal-intro">
                Información sobre el uso de cookies y tecnologías similares en la plataforma digital NIDFIL.
            </p>
        </div>
    </section>

    <section class="legal-content-section">
        <div class="section-container legal-content">
            <article class="legal-card">
                <h2>Política de Cookies</h2>
                <p>
                    Este sitio web utiliza cookies técnicas necesarias para su funcionamiento y cookies analíticas básicas.
                </p>
                <p>
                    El usuario puede aceptar, rechazar o configurar las cookies desde el banner habilitado o desde su navegador.
                </p>
                <p>
                    La desactivación de cookies puede afectar al correcto funcionamiento del sitio web.
                </p>
            </article>
        </div>
    </section>
</main>

<?php
get_footer();


