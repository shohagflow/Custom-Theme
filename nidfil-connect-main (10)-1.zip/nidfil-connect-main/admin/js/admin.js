/**
 * NIDFIL Admin Dashboard JavaScript
 */

(function($) {
    'use strict';

    // User Management - View Profile
    $('.view-user-profile').on('click', function(e) {
        e.preventDefault();
        const userId = $(this).data('user-id');
        const userType = $(this).data('user-type') || 'client';
        
        // Show modal
        $('#userProfileModal').fadeIn();
        $('#userProfileContent').html('<div class="profile-loading"><i class="fas fa-spinner fa-spin"></i><p>Loading user profile...</p></div>');
        
        // Fetch user data
        $.ajax({
            url: nidfilAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'nidfil_admin_get_user_profile',
                user_id: userId,
                user_type: userType,
                nonce: nidfilAdmin.nonce
            },
            success: function(response) {
                if (response.success) {
                    $('#userProfileContent').html(response.data.html);
                    $('#modalUserName').text(response.data.user_name + ' - Profile');
                } else {
                    $('#userProfileContent').html('<div class="profile-error"><p>' + (response.data.message || 'Error loading user profile.') + '</p></div>');
                }
            },
            error: function() {
                $('#userProfileContent').html('<div class="profile-error"><p>Error loading user profile. Please try again.</p></div>');
            }
        });
    });

    // User Management
    $('.verify-user').on('click', function() {
        const userId = $(this).data('user-id');
        const verified = $(this).data('verified');
        const action = verified ? 'unverify' : 'verify';
        
        if (!confirm('Are you sure you want to ' + action + ' this user?')) {
            return;
        }
        
        $.ajax({
            url: nidfilAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'nidfil_admin_verify_user',
                user_id: userId,
                verified: verified ? 0 : 1,
                nonce: nidfilAdmin.nonce
            },
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert(response.data.message || 'Error updating user verification status.');
                }
            }
        });
    });

    $('.suspend-user').on('click', function() {
        const userId = $(this).data('user-id');
        const status = $(this).data('status');
        const newStatus = status === 'suspended' ? 'active' : 'suspended';
        const action = newStatus === 'suspended' ? 'suspend' : 'activate';
        
        if (!confirm('Are you sure you want to ' + action + ' this user?')) {
            return;
        }
        
        $.ajax({
            url: nidfilAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'nidfil_admin_suspend_user',
                user_id: userId,
                status: newStatus,
                nonce: nidfilAdmin.nonce
            },
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert(response.data.message || 'Error updating user status.');
                }
            }
        });
    });

    $('.delete-user').on('click', function() {
        const userId = $(this).data('user-id');
        
        if (!confirm('Are you sure you want to permanently delete this user? This action cannot be undone.')) {
            return;
        }
        
        $.ajax({
            url: nidfilAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'nidfil_admin_delete_user',
                user_id: userId,
                nonce: nidfilAdmin.nonce
            },
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert(response.data.message || 'Error deleting user.');
                }
            }
        });
    });

    // Subscription Management
    $('.change-plan').on('change', function() {
        const subscriptionId = $(this).data('subscription-id');
        const userId = $(this).data('user-id');
        const newPlan = $(this).val();
        
        if (!confirm('Are you sure you want to change this subscription plan?')) {
            return;
        }
        
        $.ajax({
            url: nidfilAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'nidfil_admin_change_plan',
                subscription_id: subscriptionId,
                user_id: userId,
                plan_type: newPlan,
                nonce: nidfilAdmin.nonce
            },
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert(response.data.message || 'Error changing subscription plan.');
                }
            }
        });
    });

    $('.toggle-premium').on('click', function() {
        const userId = $(this).data('user-id');
        const isPremium = $(this).data('premium');
        const action = isPremium ? 'remove' : 'add';
        
        if (!confirm('Are you sure you want to ' + action + ' premium badge?')) {
            return;
        }
        
        $.ajax({
            url: nidfilAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'nidfil_admin_toggle_premium',
                user_id: userId,
                premium: isPremium ? 0 : 1,
                nonce: nidfilAdmin.nonce
            },
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert(response.data.message || 'Error updating premium status.');
                }
            }
        });
    });

    // Lead Management
    $('.view-offers').on('click', function() {
        const leadId = $(this).data('lead-id');
        
        $.ajax({
            url: nidfilAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'nidfil_admin_get_offers',
                lead_id: leadId,
                nonce: nidfilAdmin.nonce
            },
            success: function(response) {
                if (response.success) {
                    displayOffersModal(response.data.offers);
                } else {
                    alert(response.data.message || 'Error loading offers.');
                }
            }
        });
    });

    $('.delete-lead').on('click', function() {
        const leadId = $(this).data('lead-id');
        
        if (!confirm('Are you sure you want to delete this lead?')) {
            return;
        }
        
        $.ajax({
            url: nidfilAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'nidfil_admin_delete_lead',
                lead_id: leadId,
                nonce: nidfilAdmin.nonce
            },
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert(response.data.message || 'Error deleting lead.');
                }
            }
        });
    });

    // Review Management
    $('.approve-review').on('click', function() {
        const reviewId = $(this).data('review-id');
        const status = $(this).data('status');
        const newStatus = status === 'approved' ? 'pending' : 'approved';
        
        $.ajax({
            url: nidfilAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'nidfil_admin_approve_review',
                review_id: reviewId,
                status: newStatus,
                nonce: nidfilAdmin.nonce
            },
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert(response.data.message || 'Error updating review status.');
                }
            }
        });
    });

    $('.reject-review').on('click', function() {
        const reviewId = $(this).data('review-id');
        const status = $(this).data('status');
        const newStatus = status === 'rejected' ? 'pending' : 'rejected';
        
        if (!confirm('Are you sure you want to ' + (newStatus === 'rejected' ? 'reject' : 'restore') + ' this review?')) {
            return;
        }
        
        $.ajax({
            url: nidfilAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'nidfil_admin_reject_review',
                review_id: reviewId,
                status: newStatus,
                nonce: nidfilAdmin.nonce
            },
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert(response.data.message || 'Error updating review status.');
                }
            }
        });
    });

    $('.delete-review').on('click', function() {
        const reviewId = $(this).data('review-id');
        
        if (!confirm('Are you sure you want to delete this review?')) {
            return;
        }
        
        $.ajax({
            url: nidfilAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'nidfil_admin_delete_review',
                review_id: reviewId,
                nonce: nidfilAdmin.nonce
            },
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert(response.data.message || 'Error deleting review.');
                }
            }
        });
    });

    // Chat Moderation
    $('.view-chat').on('click', function() {
        const conversationId = $(this).data('conversation-id');
        
        $.ajax({
            url: nidfilAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'nidfil_admin_get_chat',
                conversation_id: conversationId,
                nonce: nidfilAdmin.nonce
            },
            success: function(response) {
                if (response.success) {
                    displayChatModal(response.data.messages);
                } else {
                    alert(response.data.message || 'Error loading chat.');
                }
            }
        });
    });

    // Modal Functions
    function displayOffersModal(offers) {
        let html = '<table class="wp-list-table widefat"><thead><tr><th>Specialist</th><th>Amount</th><th>Status</th><th>Date</th></tr></thead><tbody>';
        
        if (offers.length === 0) {
            html += '<tr><td colspan="4">No offers found.</td></tr>';
        } else {
            offers.forEach(function(offer) {
                html += '<tr>';
                html += '<td>' + offer.specialist_name + '</td>';
                html += '<td>€' + parseFloat(offer.offer_amount).toFixed(2) + '</td>';
                html += '<td><span class="status-badge status-' + offer.status + '">' + offer.status + '</span></td>';
                html += '<td>' + offer.created_at + '</td>';
                html += '</tr>';
            });
        }
        
        html += '</tbody></table>';
        
        $('#offersList').html(html);
        $('#offersModal').fadeIn();
    }

    function displayChatModal(messages) {
        let html = '';
        
        if (messages.length === 0) {
            html = '<p>No messages found.</p>';
        } else {
            messages.forEach(function(message) {
                const isSent = message.sender_id == nidfilAdmin.current_user_id;
                html += '<div class="chat-message ' + (isSent ? 'sent' : 'received') + '">';
                html += '<strong>' + message.sender_name + '</strong><br>';
                html += '<p>' + message.message_text + '</p>';
                html += '<small>' + message.created_at + '</small>';
                html += '</div>';
            });
        }
        
        $('#chatMessages').html(html);
        $('#chatModal').fadeIn();
    }

    // Close modals - Use event delegation for dynamically loaded content
    $(document).on('click', '.close-modal', function(e) {
        e.preventDefault();
        e.stopPropagation();
        $(this).closest('.nidfil-modal').fadeOut();
    });

    $(document).on('click', '.nidfil-modal', function(e) {
        if ($(e.target).hasClass('nidfil-modal')) {
            $(e.target).fadeOut();
        }
    });
    
    // Prevent modal content clicks from closing the modal
    $(document).on('click', '.nidfil-modal .modal-content', function(e) {
        e.stopPropagation();
    });

    // Add New Plan Button
    $('#addNewPlanBtn').on('click', function() {
        $('#planModalTitle').text('Add New Plan');
        $('#planForm')[0].reset();
        $('#plan_id').val('');
        $('#plan_type').val('free');
        $('.plan-type-btn-modal').removeClass('active');
        $('.plan-type-btn-modal[data-type="free"]').addClass('active');
        $('#plan_status').prop('checked', true);
        $('#plan_price').val(0).prop('readonly', true);
        $('#default-plan-group').show();
        $('#planFeaturesList').hide();
        $('#planModal').fadeIn();
    });
    
    // Plan Type Switch on Plan Cards (Inline)
    $(document).on('click', '.plan-type-btn', function() {
        const planId = $(this).data('plan-id');
        const planType = $(this).data('type');
        const card = $(this).closest('.nidfil-plan-card');
        
        $.ajax({
            url: nidfilAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'nidfil_admin_update_plan_type',
                plan_id: planId,
                plan_type: planType,
                nonce: nidfilAdmin.nonce
            },
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert(response.data.message || 'Error updating plan type.');
                }
            },
            error: function() {
                alert('Error updating plan type. Please try again.');
            }
        });
    });
    
    // Payment Status Toggle
    $(document).on('change', '.plan-payment-switch', function() {
        const planId = $(this).data('plan-id');
        const isEnabled = $(this).is(':checked');
        const paymentEnabled = isEnabled ? true : false;
        const label = $(this).siblings('.toggle-label');
        const self = $(this);
        
        $.ajax({
            url: nidfilAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'nidfil_admin_update_plan_payment',
                plan_id: planId,
                payment_enabled: paymentEnabled ? 1 : 0,
                nonce: nidfilAdmin.nonce
            },
            success: function(response) {
                if (response.success) {
                    label.text(isEnabled ? 'ON' : 'OFF');
                } else {
                    alert(response.data.message || 'Error updating payment status.');
                    // Revert checkbox
                    self.prop('checked', !isEnabled);
                }
            },
            error: function() {
                alert('Error updating payment status. Please try again.');
                // Revert checkbox
                self.prop('checked', !isEnabled);
            }
        });
    });
    
    // Plan Status Toggle on Plan Cards (Inline)
    $(document).on('change', '.plan-status-switch', function() {
        const planId = $(this).data('plan-id');
        const isActive = $(this).is(':checked');
        const status = isActive ? 'active' : 'inactive';
        const label = $(this).siblings('.toggle-label');
        
        $.ajax({
            url: nidfilAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'nidfil_admin_update_plan_status',
                plan_id: planId,
                status: status,
                nonce: nidfilAdmin.nonce
            },
            success: function(response) {
                if (response.success) {
                    label.text(isActive ? 'ON' : 'OFF');
                    const card = $('.plan-status-switch[data-plan-id="' + planId + '"]').closest('.nidfil-plan-card');
                    if (isActive) {
                        card.removeClass('plan-inactive');
                    } else {
                        card.addClass('plan-inactive');
                    }
                } else {
                    alert(response.data.message || 'Error updating plan status.');
                    // Revert checkbox
                    $(this).prop('checked', !isActive);
                }
            },
            error: function() {
                alert('Error updating plan status. Please try again.');
                // Revert checkbox
                $(this).prop('checked', !isActive);
            }
        });
    });
    
    // Confirm Subscription
    $(document).on('click', '.confirm-subscription', function() {
        const subscriptionId = $(this).data('subscription-id');
        const button = $(this);
        const originalText = button.html();
        
        if (!confirm('Are you sure you want to confirm this subscription? This will activate it and mark payment as completed.')) {
            return;
        }
        
        button.prop('disabled', true);
        button.html('<i class="fas fa-spinner fa-spin"></i> Processing...');
        
        $.ajax({
            url: nidfilAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'nidfil_admin_confirm_subscription',
                subscription_id: subscriptionId,
                nonce: nidfilAdmin.nonce
            },
            success: function(response) {
                if (response.success) {
                    alert(response.data.message || 'Subscription confirmed successfully!');
                    location.reload();
                } else {
                    alert(response.data.message || 'Error confirming subscription.');
                    button.prop('disabled', false);
                    button.html(originalText);
                }
            },
            error: function() {
                alert('Error confirming subscription. Please try again.');
                button.prop('disabled', false);
                button.html(originalText);
            }
        });
    });
    
    // Delete Subscription
    $(document).on('click', '.delete-subscription', function() {
        const subscriptionId = $(this).data('subscription-id');
        const button = $(this);
        const originalText = button.html();
        
        if (!confirm('Are you sure you want to delete this subscription? This action cannot be undone.')) {
            return;
        }
        
        button.prop('disabled', true);
        button.html('<i class="fas fa-spinner fa-spin"></i> Deleting...');
        
        $.ajax({
            url: nidfilAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'nidfil_admin_delete_subscription',
                subscription_id: subscriptionId,
                nonce: nidfilAdmin.nonce
            },
            success: function(response) {
                if (response.success) {
                    alert(response.data.message || 'Subscription deleted successfully!');
                    location.reload();
                } else {
                    alert(response.data.message || 'Error deleting subscription.');
                    button.prop('disabled', false);
                    button.html(originalText);
                }
            },
            error: function() {
                alert('Error deleting subscription. Please try again.');
                button.prop('disabled', false);
                button.html(originalText);
            }
        });
    });
    
    // Default Plan Toggle on Plan Cards (Inline)
    $(document).on('change', '.plan-default-switch', function() {
        const planId = $(this).data('plan-id');
        const isDefault = $(this).is(':checked');
        
        $.ajax({
            url: nidfilAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'nidfil_admin_update_plan_default',
                plan_id: planId,
                is_default: isDefault ? 1 : 0,
                nonce: nidfilAdmin.nonce
            },
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert(response.data.message || 'Error updating default plan.');
                    // Revert checkbox
                    $(this).prop('checked', !isDefault);
                }
            },
            error: function() {
                alert('Error updating default plan. Please try again.');
                // Revert checkbox
                $(this).prop('checked', !isDefault);
            }
        });
    });

    // Edit Plan Button
    $(document).on('click', '.edit-plan', function() {
        const planId = $(this).data('plan-id');
        
        // Load plan data via AJAX
        $.ajax({
            url: nidfilAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'nidfil_admin_get_plan',
                plan_id: planId,
                nonce: nidfilAdmin.nonce
            },
            success: function(response) {
                if (response.success) {
                    const plan = response.data.plan;
                    $('#planModalTitle').text('Edit Plan');
                    $('#plan_id').val(plan.id);
                    $('#plan_name').val(plan.name);
                    $('#plan_price').val(plan.price);
                    $('#plan_period').val(plan.period || 'month');
                    
                    // Set plan type
                    const planType = plan.plan_type || (plan.pro ? 'pro' : 'free');
                    $('#plan_type').val(planType);
                    $('.plan-type-btn-modal').removeClass('active');
                    $('.plan-type-btn-modal[data-type="' + planType + '"]').addClass('active');
                    
                    // Set status
                    const planStatus = plan.status || 'active';
                    $('#plan_status').prop('checked', planStatus === 'active');
                    
                    // Set default (only for FREE plans)
                    if (planType === 'free') {
                        $('#default-plan-group').show();
                        $('#plan_default').prop('checked', plan.is_default == 1 || plan.is_default === true);
                    } else {
                        $('#default-plan-group').hide();
                        $('#plan_default').prop('checked', false);
                    }
                    
                    // Update price field based on plan type
                    if (planType === 'free') {
                        $('#plan_price').val(0).prop('readonly', true);
                    } else {
                        $('#plan_price').prop('readonly', false);
                    }
                    
                    // Build features list with input fields
                    buildPlanFeaturesList(plan.id, plan.items || []);
                    
                    $('#planModal').fadeIn();
                } else {
                    alert(response.data.message || 'Error loading plan data.');
                }
            },
            error: function() {
                alert('Error loading plan data. Please try again.');
            }
        });
    });

    // Close Modal
    $(document).on('click', '.close-modal', function() {
        $('#planModal').fadeOut();
        $('#planForm')[0].reset();
    });

    // Cancel Plan Form
    $(document).on('click', '.cancel-plan', function() {
        $('#planModal').fadeOut();
        $('#planForm')[0].reset();
    });

    // Plan Type Switch in Modal
    $(document).on('click', '.plan-type-btn-modal', function() {
        const planType = $(this).data('type');
        $('.plan-type-btn-modal').removeClass('active');
        $(this).addClass('active');
        $('#plan_type').val(planType);
        
        // If FREE, set price to 0 and make readonly
        if (planType === 'free') {
            $('#plan_price').val(0).prop('readonly', true);
            $('#default-plan-group').show();
        } else {
            $('#plan_price').prop('readonly', false);
            $('#default-plan-group').hide();
            $('#plan_default').prop('checked', false);
        }
    });
    
    // Submit Plan Form
    $('#planForm').on('submit', function(e) {
        e.preventDefault();
        
        const planId = $('#plan_id').val();
        const planName = $('#plan_name').val();
        const planPrice = $('#plan_price').val();
        const planPeriod = $('#plan_period').val();
        const planType = $('#plan_type').val() || 'free';
        const planStatus = $('#plan_status').is(':checked') ? 1 : 0;
        const planDefault = $('#plan_default').is(':checked') ? 1 : 0;
        
        // Collect all feature values from input fields
        updatePlanItemsHiddenField();
        const planItems = $('#plan_items').val();
        
        if (!planName || !planPeriod) {
            alert('Please fill in all required fields.');
            return;
        }
        
        $.ajax({
            url: nidfilAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'nidfil_admin_save_plan',
                plan_id: planId,
                plan_name: planName,
                plan_price: planPrice,
                plan_period: planPeriod,
                plan_type: planType,
                plan_status: planStatus,
                plan_default: planDefault,
                plan_items: planItems,
                nonce: nidfilAdmin.nonce
            },
            success: function(response) {
                if (response.success) {
                    alert(response.data.message || 'Plan saved successfully!');
                    location.reload();
                } else {
                    alert(response.data.message || 'Error saving plan.');
                }
            },
            error: function() {
                alert('Error saving plan. Please try again.');
            }
        });
    });

    // Delete Plan
    $(document).on('click', '.delete-plan', function() {
        const planId = $(this).data('plan-id');
        
        if (!confirm('Are you sure you want to delete this plan? This action cannot be undone.')) {
            return;
        }
        
        $.ajax({
            url: nidfilAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'nidfil_admin_delete_plan',
                plan_id: planId,
                nonce: nidfilAdmin.nonce
            },
            success: function(response) {
                if (response.success) {
                    alert(response.data.message || 'Plan deleted successfully!');
                    location.reload();
                } else {
                    alert(response.data.message || 'Error deleting plan.');
                }
            },
            error: function() {
                alert('Error deleting plan. Please try again.');
            }
        });
        
        // For now, just show message
        alert('Plan deleted! (Static mode - not removed from database yet)');
        
        // In production, you would do:
        /*
        $.ajax({
            url: nidfilAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'nidfil_admin_delete_plan',
                plan_id: planId,
                nonce: nidfilAdmin.nonce
            },
            success: function(response) {
                if (response.success) {
                    alert('Plan deleted successfully!');
                    location.reload();
                } else {
                    alert(response.data.message || 'Error deleting plan.');
                }
            }
        });
        */
    });

    // Build Plan Features List for Edit Modal with Input Fields
    function buildPlanFeaturesList(planId, items) {
        const featuresList = $('.plan-items-edit');
        featuresList.empty();
        
        // Always show the features list, even if empty
        $('#planFeaturesList').show();
        
        if (!items || items.length === 0) {
            // Add one empty feature field if no items
            addFeatureField(planId, '', '', true, 'check');
            return;
        }
        
        // Get stored feature states for this plan (with proper MD5 keys from backend)
        $.ajax({
            url: nidfilAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'nidfil_admin_get_plan_features',
                plan_id: planId,
                nonce: nidfilAdmin.nonce
            },
            success: function(response) {
                const planFeatures = response.success ? response.data.features : {};
                const textToKeyMap = response.success ? (response.data.text_to_key || {}) : {};
                const iconTypesMap = response.success ? (response.data.icon_types || {}) : {};
                
                items.forEach(function(item) {
                    if (!item || item.trim() === '') return;
                    
                    const itemText = item.trim();
                    // Get the MD5 key from the backend mapping
                    const itemKey = textToKeyMap[itemText] || null;
                    const isChecked = itemKey && planFeatures[itemKey] !== undefined ? planFeatures[itemKey] : true;
                    const iconType = itemKey && iconTypesMap[itemKey] ? iconTypesMap[itemKey] : (isChecked ? 'check' : 'cross');
                    
                    addFeatureField(planId, itemText, itemKey || '', isChecked, iconType);
                });
            },
            error: function() {
                // If AJAX fails, show features with default checked state
                items.forEach(function(item) {
                    if (!item || item.trim() === '') return;
                    addFeatureField(planId, item.trim(), '', true);
                });
            }
        });
    }
    
    // Add a single feature input field
    function addFeatureField(planId, featureText, featureKey, isChecked, iconType) {
        // Default iconType if not provided
        if (!iconType) {
            iconType = isChecked ? 'check' : 'cross';
        }
        const featuresList = $('.plan-items-edit');
        const li = $('<li>').addClass('plan-feature-item-edit').attr({
            'data-feature-key': featureKey,
            'data-plan-id': planId || '',
            'data-icon-type': iconType
        });
        
        const featureRow = $('<div>').addClass('feature-input-row');
        
        // Icon selector dropdown
        const storedIconType = iconType;
        
        const iconSelect = $('<select>').addClass('feature-icon-select').css({
            width: '80px',
            padding: '4px 8px',
            fontSize: '13px'
        });
        
        iconSelect.append($('<option>').attr('value', 'check').text('✓ Check').prop('selected', storedIconType === 'check'));
        iconSelect.append($('<option>').attr('value', 'cross').text('✗ Cross').prop('selected', storedIconType === 'cross'));
        iconSelect.append($('<option>').attr('value', 'star').text('★ Star').prop('selected', storedIconType === 'star'));
        
        // Display icon based on selection
        const iconDisplay = $('<span>').addClass('feature-icon-display').css({
            display: 'inline-block',
            width: '20px',
            height: '20px',
            textAlign: 'center',
            lineHeight: '20px',
            marginRight: '8px'
        });
        
        function updateIconDisplay(iconType) {
            iconDisplay.empty();
            let iconClass = '';
            let iconColor = '';
            let iconText = '';
            
            if (iconType === 'check') {
                iconClass = 'fas fa-check';
                iconColor = '#10b981';
                iconText = '✓';
            } else if (iconType === 'cross') {
                iconClass = 'fas fa-times';
                iconColor = '#ef4444';
                iconText = '✗';
            } else if (iconType === 'star') {
                iconClass = 'fas fa-star';
                iconColor = '#fbc02d';
                iconText = '★';
            }
            
            const icon = $('<i>').addClass(iconClass).css({
                color: iconColor,
                fontSize: '14px'
            });
            iconDisplay.append(icon);
        }
        
        updateIconDisplay(storedIconType);
        
        // Input field
        const inputField = $('<input>').attr({
            type: 'text',
            class: 'feature-input-field regular-text',
            placeholder: 'Enter feature name...',
            value: featureText
        });
        
        // Delete button
        const deleteBtn = $('<button>').attr({
            type: 'button',
            class: 'delete-feature-btn button button-small'
        }).html('<i class="fas fa-trash"></i>');
        
        featureRow.append(iconDisplay).append(iconSelect).append(inputField).append(deleteBtn);
        li.append(featureRow);
        featuresList.append(li);
        
        // Icon select change handler
        iconSelect.on('change', function() {
            const selectedIconType = $(this).val();
            updateIconDisplay(selectedIconType);
            
            // Store icon type in data attribute
            li.attr('data-icon-type', selectedIconType);
            
            // Determine checked state based on icon type (check = checked, cross = unchecked, star = special)
            const newChecked = selectedIconType === 'check' || selectedIconType === 'star';
            
            // Save feature state via AJAX if planId exists
            if (planId) {
                const currentText = inputField.val().trim();
                if (currentText) {
                    const currentKey = li.data('feature-key') || '';
                    $.ajax({
                        url: nidfilAdmin.ajaxurl,
                        type: 'POST',
                        data: {
                            action: 'nidfil_admin_toggle_plan_feature',
                            plan_id: planId,
                            feature_key: currentKey,
                            feature_text: currentText,
                            is_checked: newChecked ? 1 : 0,
                            icon_type: selectedIconType,
                            nonce: nidfilAdmin.nonce
                        },
                        success: function(response) {
                            if (response.success && response.data.feature_key) {
                                li.attr('data-feature-key', response.data.feature_key);
                            }
                        }
                    });
                }
            }
        });
        
        // Delete button handler
        deleteBtn.on('click', function() {
            li.remove();
            updatePlanItemsHiddenField();
        });
        
        // Input field change handler - update feature key when text changes
        inputField.on('blur', function() {
            const newText = $(this).val().trim();
            if (planId && newText) {
                // Update the data attribute
                li.attr('data-feature-text', newText);
                updatePlanItemsHiddenField();
            }
        });
    }
    
    // Update hidden field with all feature values
    function updatePlanItemsHiddenField() {
        const features = [];
        $('.plan-feature-item-edit').each(function() {
            const inputField = $(this).find('.feature-input-field');
            const featureText = inputField.val().trim();
            if (featureText) {
                features.push(featureText);
            }
        });
        $('#plan_items').val(features.join('\n'));
    }
    
    // Add Feature Button
    $(document).on('click', '#addFeatureBtn', function() {
        const planId = $('#plan_id').val();
        addFeatureField(planId, '', '', true);
    });
    
    // Update hidden field when any feature input changes
    $(document).on('input', '.feature-input-field', function() {
        updatePlanItemsHiddenField();
    });
    
    // Feature Toggle in Edit Modal
    $(document).on('change', '.feature-toggle-checkbox-edit', function() {
        const checkbox = $(this);
        const featureItem = checkbox.closest('.plan-feature-item-edit');
        const planId = featureItem.data('plan-id');
        const featureKey = featureItem.data('feature-key');
        const featureText = featureItem.data('feature-text');
        const isChecked = checkbox.is(':checked');
        
        // Update icon display
        const checkIcon = featureItem.find('.feature-check-icon');
        const crossIcon = featureItem.find('.feature-cross-icon');
        
        if (isChecked) {
            checkIcon.show();
            crossIcon.hide();
        } else {
            checkIcon.hide();
            crossIcon.show();
        }
        
        // Save feature state via AJAX
        if (planId) {
            $.ajax({
                url: nidfilAdmin.ajaxurl,
                type: 'POST',
                data: {
                    action: 'nidfil_admin_toggle_plan_feature',
                    plan_id: planId,
                    feature_key: featureKey || '',
                    feature_text: featureText || '',
                    is_checked: isChecked ? 1 : 0,
                    nonce: nidfilAdmin.nonce
                },
                success: function(response) {
                    if (response.success && response.data.feature_key) {
                        // Update the feature key if backend generated one
                        featureItem.attr('data-feature-key', response.data.feature_key);
                    } else if (!response.success) {
                        // Revert on error
                        checkbox.prop('checked', !isChecked);
                        if (isChecked) {
                            checkIcon.hide();
                            crossIcon.show();
                        } else {
                            checkIcon.show();
                            crossIcon.hide();
                        }
                        alert(response.data.message || 'Error updating feature status.');
                    }
                },
                error: function() {
                    // Revert on error
                    checkbox.prop('checked', !isChecked);
                    if (isChecked) {
                        checkIcon.hide();
                        crossIcon.show();
                    } else {
                        checkIcon.show();
                        crossIcon.hide();
                    }
                    alert('Error updating feature status. Please try again.');
                }
            });
        }
    });
    
    // Feature Toggle - Check/Uncheck Plan Features (click on feature item)
    $(document).on('click', '.plan-feature-item', function(e) {
        // Don't trigger if clicking on a link or button inside
        if ($(e.target).is('a, button, input')) {
            return;
        }
        
        const featureItem = $(this);
        const planId = featureItem.data('plan-id');
        const featureKey = featureItem.data('feature-key');
        const currentChecked = featureItem.data('is-checked') == '1';
        const currentIconType = featureItem.data('icon-type') || (currentChecked ? 'check' : 'cross');
        const isChecked = !currentChecked; // Toggle
        
        // Determine new icon type based on toggle
        // If currently check/star, toggle to cross. If cross, toggle to check
        let newIconType = 'check';
        if (currentIconType === 'check' || currentIconType === 'star') {
            newIconType = 'cross';
        } else {
            newIconType = 'check';
        }
        
        // Update icon display immediately
        const iconElement = featureItem.find('.feature-icon i');
        let iconClass = '';
        let iconColor = '';
        
        if (newIconType === 'check') {
            iconClass = 'fas fa-check';
            iconColor = '#10b981';
        } else if (newIconType === 'cross') {
            iconClass = 'fas fa-times';
            iconColor = '#ef4444';
        } else if (newIconType === 'star') {
            iconClass = 'fas fa-star';
            iconColor = '#fbc02d';
        }
        
        iconElement.attr('class', iconClass).css('color', iconColor);
        
        // Update data attributes
        featureItem.attr('data-is-checked', isChecked ? '1' : '0');
        featureItem.attr('data-icon-type', newIconType);
        
        // Save feature state via AJAX
        $.ajax({
            url: nidfilAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'nidfil_admin_toggle_plan_feature',
                plan_id: planId,
                feature_key: featureKey,
                is_checked: isChecked ? 1 : 0,
                icon_type: newIconType,
                nonce: nidfilAdmin.nonce
            },
            success: function(response) {
                if (!response.success) {
                    // Revert on error
                    featureItem.attr('data-is-checked', currentChecked ? '1' : '0');
                    featureItem.attr('data-icon-type', currentIconType);
                    
                    // Revert icon
                    let revertIconClass = '';
                    let revertIconColor = '';
                    if (currentIconType === 'check') {
                        revertIconClass = 'fas fa-check';
                        revertIconColor = '#10b981';
                    } else if (currentIconType === 'cross') {
                        revertIconClass = 'fas fa-times';
                        revertIconColor = '#ef4444';
                    } else if (currentIconType === 'star') {
                        revertIconClass = 'fas fa-star';
                        revertIconColor = '#fbc02d';
                    }
                    iconElement.attr('class', revertIconClass).css('color', revertIconColor);
                    
                    alert(response.data.message || 'Error updating feature status.');
                }
            },
            error: function() {
                // Revert on error
                featureItem.attr('data-is-checked', currentChecked ? '1' : '0');
                featureItem.attr('data-icon-type', currentIconType);
                
                // Revert icon
                let revertIconClass = '';
                let revertIconColor = '';
                if (currentIconType === 'check') {
                    revertIconClass = 'fas fa-check';
                    revertIconColor = '#10b981';
                } else if (currentIconType === 'cross') {
                    revertIconClass = 'fas fa-times';
                    revertIconColor = '#ef4444';
                } else if (currentIconType === 'star') {
                    revertIconClass = 'fas fa-star';
                    revertIconColor = '#fbc02d';
                }
                iconElement.attr('class', revertIconClass).css('color', revertIconColor);
                
                alert('Error updating feature status. Please try again.');
            }
        });
    });

})(jQuery);

