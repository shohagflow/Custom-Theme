<?php
/**
 * Subscription Management Page
 * 
 * @package NIDFIL_Connect
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!current_user_can('manage_options')) {
    wp_die(__('You do not have sufficient permissions to access this page.'));
}

global $wpdb;
$subscriptions_table = $wpdb->prefix . 'nidfil_subscriptions';

// Get active tab
$active_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'plans';

// Check if subscriptions table exists
$table_exists = $wpdb->get_var("SHOW TABLES LIKE '$subscriptions_table'") == $subscriptions_table;

// Get subscriptions from database (including pending)
$subscriptions = array();
if ($table_exists) {
    $subscriptions = $wpdb->get_results("SELECT * FROM $subscriptions_table ORDER BY 
        CASE status 
            WHEN 'pending' THEN 1 
            WHEN 'active' THEN 2 
            ELSE 3 
        END, 
        created_at DESC");
    if ($subscriptions === null) {
        $subscriptions = array();
    }
}

// Get subscription counts dynamically
$free_count = 0;
$pro_count = 0;
$total_active_count = 0;
$total_pending_count = 0;
$total_users_count = 0;

if ($table_exists) {
    // Count by plan_type (free or pro)
    $free_count = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $subscriptions_table WHERE plan_type = %s AND status = %s",
        'free',
        'active'
    ));
    $free_count = $free_count ? intval($free_count) : 0;
    
    $pro_count = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $subscriptions_table WHERE plan_type = %s AND status = %s",
        'pro',
        'active'
    ));
    $pro_count = $pro_count ? intval($pro_count) : 0;
    
    // Total active subscriptions
    $total_active_count = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $subscriptions_table WHERE status = %s",
        'active'
    ));
    $total_active_count = $total_active_count ? intval($total_active_count) : 0;
    
    // Total pending subscriptions
    $total_pending_count = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $subscriptions_table WHERE status = %s",
        'pending'
    ));
    $total_pending_count = $total_pending_count ? intval($total_pending_count) : 0;
    
    // Count total users with subscriptions (free + pro)
    $total_users_count = $free_count + $pro_count;
} else {
    // Table doesn't exist, all counts are 0
    $free_count = 0;
    $pro_count = 0;
    $total_active_count = 0;
    $total_pending_count = 0;
    $total_users_count = 0;
}

// Get subscription plans from options (stored as JSON)
$stored_plans = get_option('nidfil_subscription_plans', array());

// Initialize default plans if none exist
if (empty($stored_plans)) {
    $default_plans = array(
        array(
            'id' => 1,
            'name' => 'Free Plan',
            'price' => 0.00,
            'period' => 'month',
            'pro' => false,
            'items' => array('Basic profile', 'Limited leads', 'Standard support')
        ),
        array(
            'id' => 2,
            'name' => 'Basic Plan',
            'price' => 29.99,
            'period' => 'month',
            'pro' => false,
            'items' => array('Enhanced profile', 'More leads', 'Priority support', 'Analytics dashboard')
        ),
        array(
            'id' => 3,
            'name' => 'Pro Plan',
            'price' => 99.99,
            'period' => 'month',
            'pro' => true,
            'items' => array('Premium profile', 'Unlimited leads', '24/7 support', 'Advanced analytics', 'Premium badge', 'Featured listing')
        )
    );
    update_option('nidfil_subscription_plans', $default_plans);
    $stored_plans = $default_plans;
}

// Ensure plans are arrays (handle JSON stored as string)
if (is_string($stored_plans)) {
    $stored_plans = json_decode($stored_plans, true);
}

// Sort plans by ID
usort($stored_plans, function($a, $b) {
    return $a['id'] - $b['id'];
});
?>

<div class="wrap nidfil-admin-wrap nidfil-subscriptions-page">
    <div class="nidfil-page-header">
        <div class="header-content">
            <h1 class="wp-heading-inline"><?php _e('Subscription Management', 'nidfil-connect'); ?></h1>
            <p class="page-description"><?php _e('Manage subscription plans and user subscriptions', 'nidfil-connect'); ?></p>
        </div>
        <div class="header-actions">
            <?php if ($active_tab === 'plans'): ?>
            <button class="button button-primary" id="addNewPlanBtn">
                <i class="fas fa-plus"></i> <?php _e('Add New Plan', 'nidfil-connect'); ?>
            </button>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Tab Navigation -->
    <div class="nidfil-tab-navigation">
        <a href="?page=nidfil-subscriptions&tab=plans" class="nidfil-tab <?php echo $active_tab === 'plans' ? 'active' : ''; ?>">
            <span class="tab-label"><?php _e('Subscription Plans', 'nidfil-connect'); ?></span>
            <span class="tab-count"><?php echo count($stored_plans); ?></span>
        </a>
        <a href="?page=nidfil-subscriptions&tab=manage" class="nidfil-tab <?php echo $active_tab === 'manage' ? 'active' : ''; ?>">
            <span class="tab-label"><?php _e('Manage Plan', 'nidfil-connect'); ?></span>
            <span class="tab-count"><?php echo count($stored_plans); ?></span>
        </a>
        <a href="?page=nidfil-subscriptions&tab=subscriptions" class="nidfil-tab <?php echo $active_tab === 'subscriptions' ? 'active' : ''; ?>">
            <span class="tab-label"><?php _e('Active Subscriptions', 'nidfil-connect'); ?></span>
            <span class="tab-count"><?php echo $total_active_count; ?></span>
        </a>
        <a href="?page=nidfil-subscriptions&tab=pending" class="nidfil-tab <?php echo $active_tab === 'pending' ? 'active' : ''; ?>">
            <span class="tab-label"><?php _e('Pending Subscriptions', 'nidfil-connect'); ?></span>
            <span class="tab-count"><?php echo $total_pending_count; ?></span>
        </a>
    </div>
    
    <!-- Subscription Plans Section -->
    <div class="nidfil-plans-section" id="plansTab" style="display: <?php echo $active_tab === 'plans' ? 'block' : 'none'; ?>;">
        <h2><?php _e('Subscription Plans', 'nidfil-connect'); ?></h2>
        <div class="nidfil-plans-grid">
            <?php
            // Load plans from database/options
            foreach ($stored_plans as $plan):
                // Ensure items is an array
                $plan_items = is_array($plan['items']) ? $plan['items'] : (is_string($plan['items']) ? explode("\n", $plan['items']) : array());
            ?>
            <div class="nidfil-plan-card <?php echo (isset($plan['status']) && $plan['status'] === 'inactive') ? 'plan-inactive' : ''; ?>">
                <div class="plan-header">
                    <h3><?php echo esc_html($plan['name']); ?></h3>
                    <div class="plan-badges">
                        <?php 
                        $plan_type = isset($plan['plan_type']) ? $plan['plan_type'] : ($plan['pro'] ? 'pro' : 'free');
                        if ($plan_type === 'pro'): ?>
                            <span class="pro-badge">PRO</span>
                        <?php elseif ($plan_type === 'free'): ?>
                            <span class="free-badge">FREE</span>
                        <?php endif; ?>
                        <?php if (isset($plan['is_default']) && $plan['is_default'] && $plan_type === 'free'): ?>
                            <span class="default-badge">DEFAULT</span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="plan-price">
                    <span class="price-amount">€<?php echo number_format($plan['price'], 2); ?></span>
                    <span class="price-period"><?php echo esc_html(isset($plan['period']) ? $plan['period'] : 'month'); ?></span>
                </div>
                <ul class="plan-items" data-plan-id="<?php echo $plan['id']; ?>">
                    <?php 
                    // Get stored feature states for this plan
                    $plan_features = get_option('nidfil_plan_features_' . $plan['id'], array());
                    // Get stored icon types for this plan
                    $plan_icon_types = get_option('nidfil_plan_feature_icons_' . $plan['id'], array());
                    
                    foreach ($plan_items as $index => $item): 
                        $item = trim($item);
                        if (!empty($item)):
                            $item_key = md5($item); // Create unique key for each feature
                            $is_checked = isset($plan_features[$item_key]) ? $plan_features[$item_key] : true; // Default to checked
                            // Get icon type (check, cross, or star) - default based on checked state
                            $icon_type = isset($plan_icon_types[$item_key]) ? $plan_icon_types[$item_key] : ($is_checked ? 'check' : 'cross');
                            
                            // Determine icon class and color based on icon type
                            $icon_class = '';
                            $icon_color = '';
                            if ($icon_type === 'check') {
                                $icon_class = 'fas fa-check';
                                $icon_color = '#10b981';
                            } elseif ($icon_type === 'cross') {
                                $icon_class = 'fas fa-times';
                                $icon_color = '#ef4444';
                            } elseif ($icon_type === 'star') {
                                $icon_class = 'fas fa-star';
                                $icon_color = '#fbc02d';
                            } else {
                                // Fallback to check/cross based on checked state
                                $icon_class = $is_checked ? 'fas fa-check' : 'fas fa-times';
                                $icon_color = $is_checked ? '#10b981' : '#ef4444';
                            }
                    ?>
                        <li class="plan-feature-item" data-feature-key="<?php echo esc_attr($item_key); ?>" data-plan-id="<?php echo $plan['id']; ?>" data-is-checked="<?php echo $is_checked ? '1' : '0'; ?>" data-icon-type="<?php echo esc_attr($icon_type); ?>">
                            <div class="feature-toggle-label" style="cursor: pointer;">
                                <span class="feature-icon">
                                    <i class="<?php echo esc_attr($icon_class); ?>" style="display: inline; color: <?php echo esc_attr($icon_color); ?>;"></i>
                                </span>
                                <span class="feature-text"><?php echo esc_html($item); ?></span>
                            </div>
                        </li>
                    <?php 
                        endif;
                    endforeach; ?>
                </ul>
                <div class="plan-actions">
                    <button class="button button-small edit-plan" data-plan-id="<?php echo $plan['id']; ?>">
                        <i class="fas fa-edit"></i> <?php _e('Edit', 'nidfil-connect'); ?>
                    </button>
                    <button class="button button-small button-link-delete delete-plan" data-plan-id="<?php echo $plan['id']; ?>">
                        <i class="fas fa-trash"></i> <?php _e('Delete', 'nidfil-connect'); ?>
                    </button>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    
    <!-- Manage Plan Section -->
    <div class="nidfil-manage-plans-section" id="manageTab" style="display: <?php echo $active_tab === 'manage' ? 'block' : 'none'; ?>;">
        <h2><?php _e('Manage Plans', 'nidfil-connect'); ?></h2>
        <p class="section-description"><?php _e('Configure plan types and status for all subscription plans', 'nidfil-connect'); ?></p>
        
        <div class="manage-plans-list">
            <?php
            foreach ($stored_plans as $plan):
                $plan_type = isset($plan['plan_type']) ? $plan['plan_type'] : ($plan['pro'] ? 'pro' : 'free');
            ?>
            <div class="manage-plan-item <?php echo (isset($plan['status']) && $plan['status'] === 'inactive') ? 'plan-inactive' : ''; ?>">
                <div class="manage-plan-header">
                    <h3><?php echo esc_html($plan['name']); ?></h3>
                    <div class="manage-plan-badges">
                        <?php if ($plan_type === 'pro'): ?>
                            <span class="pro-badge">PRO</span>
                        <?php elseif ($plan_type === 'free'): ?>
                            <span class="free-badge">FREE</span>
                        <?php endif; ?>
                        <?php if (isset($plan['is_default']) && $plan['is_default'] && $plan_type === 'free'): ?>
                            <span class="default-badge">DEFAULT</span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="plan-controls">
                    <div class="plan-control-row">
                        <label class="plan-control-label"><?php _e('Payment Status:', 'nidfil-connect'); ?></label>
                        <label class="plan-payment-toggle">
                            <input type="checkbox" class="plan-payment-switch" data-plan-id="<?php echo $plan['id']; ?>" <?php echo (!isset($plan['payment_enabled']) || $plan['payment_enabled'] !== false) ? 'checked' : ''; ?>>
                            <span class="toggle-slider"></span>
                            <span class="toggle-label"><?php echo (isset($plan['payment_enabled']) && $plan['payment_enabled'] === false) ? 'OFF' : 'ON'; ?></span>
                        </label>
                    </div>
                    <div class="plan-control-row">
                        <label class="plan-control-label"><?php _e('Plan Type:', 'nidfil-connect'); ?></label>
                        <div class="plan-type-switch">
                            <button type="button" class="plan-type-btn <?php echo $plan_type === 'free' ? 'active' : ''; ?>" data-plan-id="<?php echo $plan['id']; ?>" data-type="free">
                                FREE
                            </button>
                            <button type="button" class="plan-type-btn <?php echo $plan_type === 'pro' ? 'active' : ''; ?>" data-plan-id="<?php echo $plan['id']; ?>" data-type="pro">
                                PRO
                            </button>
                        </div>
                    </div>
                    <div class="plan-control-row">
                        <label class="plan-control-label"><?php _e('Status:', 'nidfil-connect'); ?></label>
                        <label class="plan-status-toggle">
                            <input type="checkbox" class="plan-status-switch" data-plan-id="<?php echo $plan['id']; ?>" <?php echo (!isset($plan['status']) || $plan['status'] === 'active') ? 'checked' : ''; ?>>
                            <span class="toggle-slider"></span>
                            <span class="toggle-label"><?php echo (isset($plan['status']) && $plan['status'] === 'inactive') ? 'OFF' : 'ON'; ?></span>
                        </label>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    
    <!-- Active Subscriptions Section -->
    <div class="nidfil-subscriptions-section" id="subscriptionsTab" style="display: <?php echo $active_tab === 'subscriptions' ? 'block' : 'none'; ?>;">
        <h2><?php _e('Active Subscriptions', 'nidfil-connect'); ?></h2>
        <div class="nidfil-subscription-stats">
        <div class="stat-card">
            <h3><?php echo number_format($total_users_count); ?></h3>
            <p><?php _e('All Users', 'nidfil-connect'); ?></p>
        </div>
        <div class="stat-card">
            <h3><?php echo number_format($free_count); ?></h3>
            <p><?php _e('Free Plans', 'nidfil-connect'); ?></p>
        </div>
        <div class="stat-card">
            <h3><?php echo number_format($pro_count); ?></h3>
            <p><?php _e('Pro Plans', 'nidfil-connect'); ?></p>
        </div>
    </div>
    
    <table class="wp-list-table widefat fixed striped nidfil-subscriptions-table">
        <thead>
            <tr>
                <th class="column-user"><?php _e('Email', 'nidfil-connect'); ?></th>
                <th class="column-plan"><?php _e('Plan', 'nidfil-connect'); ?></th>
                <th class="column-status"><?php _e('Status', 'nidfil-connect'); ?></th>
                <th class="column-amount"><?php _e('Amount', 'nidfil-connect'); ?></th>
                <th class="column-payment-status"><?php _e('Payment Status', 'nidfil-connect'); ?></th>
                <th class="column-dates"><?php _e('Start / End Date', 'nidfil-connect'); ?></th>
                <th class="column-actions"><?php _e('Actions', 'nidfil-connect'); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($subscriptions)): ?>
                <tr>
                    <td colspan="7"><?php _e('No subscriptions found.', 'nidfil-connect'); ?></td>
                </tr>
            <?php else: ?>
                <?php foreach ($subscriptions as $subscription): 
                    $user = get_userdata($subscription->user_id);
                    $user_name = $user ? $user->display_name : __('User #' . $subscription->user_id, 'nidfil-connect');
                ?>
                    <tr>
                        <td class="column-user">
                            <span class="user-email"><?php echo $user ? esc_html($user->user_email) : esc_html($user_name); ?></span>
                        </td>
                        <td class="column-plan">
                            <?php 
                            // Get plan name from stored plans if available
                            $plan_name_display = strtoupper($subscription->plan_type);
                            foreach ($stored_plans as $stored_plan) {
                                if (isset($stored_plan['id'])) {
                                    // Match by plan_type
                                    $stored_plan_type = isset($stored_plan['plan_type']) ? $stored_plan['plan_type'] : (isset($stored_plan['pro']) && $stored_plan['pro'] ? 'pro' : 'free');
                                    if ($stored_plan_type === $subscription->plan_type) {
                                        $plan_name_display = esc_html($stored_plan['name']);
                                        break;
                                    }
                                }
                            }
                            ?>
                            <span class="plan-badge plan-<?php echo esc_attr($subscription->plan_type); ?>">
                                <?php echo $plan_name_display; ?>
                            </span>
                        </td>
                        <td class="column-status">
                            <span class="status-badge status-<?php echo esc_attr($subscription->status); ?>">
                                <?php echo ucfirst($subscription->status); ?>
                            </span>
                        </td>
                        <td class="column-amount">€<?php echo number_format($subscription->payment_amount, 2); ?></td>
                        <td class="column-payment-status">
                            <span class="payment-badge payment-<?php echo esc_attr($subscription->payment_status); ?>">
                                <?php echo ucfirst($subscription->payment_status); ?>
                            </span>
                        </td>
                        <td class="column-dates">
                            <div class="subscription-dates">
                                <?php 
                                // Get plan period for this subscription
                                $subscription_plan_period = 'month'; // Default
                                foreach ($stored_plans as $stored_plan) {
                                    if (isset($stored_plan['id'])) {
                                        $stored_plan_type = isset($stored_plan['plan_type']) ? $stored_plan['plan_type'] : (isset($stored_plan['pro']) && $stored_plan['pro'] ? 'pro' : 'free');
                                        if ($stored_plan_type === $subscription->plan_type) {
                                            $subscription_plan_period = isset($stored_plan['period']) ? $stored_plan['period'] : 'month';
                                            break;
                                        }
                                    }
                                }
                                
                                // Normalize period format
                                $period_normalized = strtolower(trim($subscription_plan_period));
                                if (strpos($period_normalized, 'year') !== false) {
                                    $period_normalized = 'year';
                                    $period_display = __('Yearly', 'nidfil-connect');
                                } else {
                                    $period_normalized = 'month';
                                    $period_display = __('Monthly', 'nidfil-connect');
                                }
                                
                                // Format start date
                                $start_date_display = 'N/A';
                                if (!empty($subscription->start_date) && $subscription->start_date !== '0000-00-00 00:00:00' && $subscription->start_date !== '1970-01-01 00:00:00') {
                                    $start_timestamp = strtotime($subscription->start_date);
                                    if ($start_timestamp !== false && $start_timestamp > 0) {
                                        $start_date_display = date_i18n(get_option('date_format'), $start_timestamp);
                                    }
                                }
                                
                                // Format end date
                                $end_date_display = 'N/A';
                                if (!empty($subscription->end_date) && $subscription->end_date !== '0000-00-00 00:00:00' && $subscription->end_date !== '1970-01-01 00:00:00') {
                                    $end_timestamp = strtotime($subscription->end_date);
                                    if ($end_timestamp !== false && $end_timestamp > 0) {
                                        $end_date_display = date_i18n(get_option('date_format'), $end_timestamp);
                                    }
                                } elseif ($subscription->status === 'pending') {
                                    // Calculate expected end date for pending subscriptions
                                    $expected_start = current_time('mysql');
                                    $expected_start_timestamp = strtotime($expected_start);
                                    
                                    if ($period_normalized === 'year') {
                                        $expected_end_timestamp = strtotime('+1 year', $expected_start_timestamp);
                                    } else {
                                        $expected_end_timestamp = strtotime('+1 month', $expected_start_timestamp);
                                    }
                                    
                                    $end_date_display = date_i18n(get_option('date_format'), $expected_end_timestamp) . ' <span class="date-note">(' . __('Expected', 'nidfil-connect') . ')</span>';
                                }
                                ?>
                                <div class="date-item">
                                    <span class="date-label"><?php _e('Period:', 'nidfil-connect'); ?></span>
                                    <span class="date-value period-badge"><?php echo esc_html($period_display); ?></span>
                                </div>
                                <div class="date-item">
                                    <span class="date-label"><?php _e('Start:', 'nidfil-connect'); ?></span>
                                    <span class="date-value"><?php echo $start_date_display; ?></span>
                                </div>
                                <div class="date-item">
                                    <span class="date-label"><?php _e('End:', 'nidfil-connect'); ?></span>
                                    <span class="date-value"><?php echo $end_date_display; ?></span>
                                </div>
                            </div>
                        </td>
                        <td class="column-actions">
                            <?php if ($subscription->status === 'pending'): ?>
                                <button class="button button-primary button-small confirm-subscription" data-subscription-id="<?php echo $subscription->id; ?>" title="<?php _e('Activate Subscription', 'nidfil-connect'); ?>">
                                    <i class="fas fa-check-circle"></i> <?php _e('Active', 'nidfil-connect'); ?>
                                </button>
                            <?php else: ?>
                                <button class="button button-secondary button-small subscription-active-btn" data-subscription-id="<?php echo $subscription->id; ?>" disabled title="<?php _e('Subscription is Active', 'nidfil-connect'); ?>">
                                    <i class="fas fa-check-circle"></i> <?php _e('Active', 'nidfil-connect'); ?>
                                </button>
                            <?php endif; ?>
                            <button class="button button-link-delete button-small delete-subscription" data-subscription-id="<?php echo $subscription->id; ?>" title="<?php _e('Delete Subscription', 'nidfil-connect'); ?>">
                                <i class="fas fa-trash"></i> <?php _e('Delete', 'nidfil-connect'); ?>
                            </button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
    </div>
    
    <!-- Pending Subscriptions Section -->
    <div class="nidfil-pending-subscriptions-section" id="pendingTab" style="display: <?php echo $active_tab === 'pending' ? 'block' : 'none'; ?>;">
        <h2><?php _e('Pending Subscriptions', 'nidfil-connect'); ?></h2>
        <p class="section-description"><?php _e('Subscriptions waiting for admin confirmation', 'nidfil-connect'); ?></p>
        
        <?php
        // Get only pending subscriptions
        $pending_subscriptions = array();
        if ($table_exists) {
            $pending_subscriptions = $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM $subscriptions_table WHERE status = %s ORDER BY created_at DESC",
                'pending'
            ));
            if ($pending_subscriptions === null) {
                $pending_subscriptions = array();
            }
        }
        ?>
        
        <?php if (empty($pending_subscriptions)): ?>
            <div class="no-pending-subscriptions">
                <p><?php _e('No pending subscriptions found.', 'nidfil-connect'); ?></p>
            </div>
        <?php else: ?>
            <table class="wp-list-table widefat fixed striped nidfil-subscriptions-table">
                <thead>
                    <tr>
                        <th class="column-user"><?php _e('Email', 'nidfil-connect'); ?></th>
                        <th class="column-plan"><?php _e('Plan', 'nidfil-connect'); ?></th>
                        <th class="column-status"><?php _e('Status', 'nidfil-connect'); ?></th>
                        <th class="column-amount"><?php _e('Amount', 'nidfil-connect'); ?></th>
                        <th class="column-payment-status"><?php _e('Payment Status', 'nidfil-connect'); ?></th>
                        <th class="column-dates"><?php _e('Start / End Date', 'nidfil-connect'); ?></th>
                        <th class="column-actions"><?php _e('Actions', 'nidfil-connect'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($pending_subscriptions as $subscription): 
                        $user = get_userdata($subscription->user_id);
                        $user_name = $user ? $user->display_name : __('User #' . $subscription->user_id, 'nidfil-connect');
                    ?>
                        <tr>
                            <td class="column-user">
                                <span class="user-email"><?php echo $user ? esc_html($user->user_email) : esc_html($user_name); ?></span>
                            </td>
                            <td class="column-plan">
                                <?php 
                                // Get plan name from stored plans if available
                                $plan_name_display = strtoupper($subscription->plan_type);
                                foreach ($stored_plans as $stored_plan) {
                                    if (isset($stored_plan['id'])) {
                                        // Match by plan_type
                                        $stored_plan_type = isset($stored_plan['plan_type']) ? $stored_plan['plan_type'] : (isset($stored_plan['pro']) && $stored_plan['pro'] ? 'pro' : 'free');
                                        if ($stored_plan_type === $subscription->plan_type) {
                                            $plan_name_display = esc_html($stored_plan['name']);
                                            break;
                                        }
                                    }
                                }
                                ?>
                                <span class="plan-badge plan-<?php echo esc_attr($subscription->plan_type); ?>">
                                    <?php echo $plan_name_display; ?>
                                </span>
                            </td>
                            <td class="column-status">
                                <span class="status-badge status-<?php echo esc_attr($subscription->status); ?>">
                                    <?php echo ucfirst($subscription->status); ?>
                                </span>
                            </td>
                            <td class="column-amount">€<?php echo number_format($subscription->payment_amount, 2); ?></td>
                            <td class="column-payment-status">
                                <span class="payment-badge payment-<?php echo esc_attr($subscription->payment_status); ?>">
                                    <?php echo ucfirst($subscription->payment_status); ?>
                                </span>
                            </td>
                            <td class="column-dates">
                                <div class="subscription-dates">
                                    <?php 
                                    // Get plan period for this subscription
                                    $subscription_plan_period = 'month'; // Default
                                    foreach ($stored_plans as $stored_plan) {
                                        if (isset($stored_plan['id'])) {
                                            $stored_plan_type = isset($stored_plan['plan_type']) ? $stored_plan['plan_type'] : (isset($stored_plan['pro']) && $stored_plan['pro'] ? 'pro' : 'free');
                                            if ($stored_plan_type === $subscription->plan_type) {
                                                $subscription_plan_period = isset($stored_plan['period']) ? $stored_plan['period'] : 'month';
                                                break;
                                            }
                                        }
                                    }
                                    
                                    // Normalize period format
                                    $period_normalized = strtolower(trim($subscription_plan_period));
                                    if (strpos($period_normalized, 'year') !== false) {
                                        $period_normalized = 'year';
                                        $period_display = __('Yearly', 'nidfil-connect');
                                    } else {
                                        $period_normalized = 'month';
                                        $period_display = __('Monthly', 'nidfil-connect');
                                    }
                                    
                                    // Format start date
                                    $start_date_display = 'N/A';
                                    if (!empty($subscription->start_date) && $subscription->start_date !== '0000-00-00 00:00:00' && $subscription->start_date !== '1970-01-01 00:00:00') {
                                        $start_timestamp = strtotime($subscription->start_date);
                                        if ($start_timestamp !== false && $start_timestamp > 0) {
                                            $start_date_display = date_i18n(get_option('date_format'), $start_timestamp);
                                        }
                                    }
                                    
                                    // Format end date
                                    $end_date_display = 'N/A';
                                    if (!empty($subscription->end_date) && $subscription->end_date !== '0000-00-00 00:00:00' && $subscription->end_date !== '1970-01-01 00:00:00') {
                                        $end_timestamp = strtotime($subscription->end_date);
                                        if ($end_timestamp !== false && $end_timestamp > 0) {
                                            $end_date_display = date_i18n(get_option('date_format'), $end_timestamp);
                                        }
                                    } else {
                                        // Calculate expected end date for pending subscriptions
                                        $expected_start = current_time('mysql');
                                        $expected_start_timestamp = strtotime($expected_start);
                                        
                                        if ($period_normalized === 'year') {
                                            $expected_end_timestamp = strtotime('+1 year', $expected_start_timestamp);
                                        } else {
                                            $expected_end_timestamp = strtotime('+1 month', $expected_start_timestamp);
                                        }
                                        
                                        $end_date_display = date_i18n(get_option('date_format'), $expected_end_timestamp) . ' <span class="date-note">(' . __('Expected', 'nidfil-connect') . ')</span>';
                                    }
                                    ?>
                                    <div class="date-item">
                                        <span class="date-label"><?php _e('Period:', 'nidfil-connect'); ?></span>
                                        <span class="date-value period-badge"><?php echo esc_html($period_display); ?></span>
                                    </div>
                                    <div class="date-item">
                                        <span class="date-label"><?php _e('Start:', 'nidfil-connect'); ?></span>
                                        <span class="date-value"><?php echo $start_date_display; ?></span>
                                    </div>
                                    <div class="date-item">
                                        <span class="date-label"><?php _e('End:', 'nidfil-connect'); ?></span>
                                        <span class="date-value"><?php echo $end_date_display; ?></span>
                                    </div>
                                </div>
                            </td>
                            <td class="column-actions">
                                <button class="button button-primary button-small confirm-subscription" data-subscription-id="<?php echo $subscription->id; ?>" title="<?php _e('Activate Subscription', 'nidfil-connect'); ?>">
                                    <i class="fas fa-check-circle"></i> <?php _e('Active', 'nidfil-connect'); ?>
                                </button>
                                <button class="button button-link-delete button-small delete-subscription" data-subscription-id="<?php echo $subscription->id; ?>" title="<?php _e('Delete Subscription', 'nidfil-connect'); ?>">
                                    <i class="fas fa-trash"></i> <?php _e('Delete', 'nidfil-connect'); ?>
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>

<!-- Add/Edit Plan Modal -->
<div id="planModal" class="nidfil-modal" style="display:none;">
    <div class="modal-content">
        <span class="close-modal">&times;</span>
        <div class="modal-header-section">
            <h2 id="planModalTitle"><?php _e('Add New Plan', 'nidfil-connect'); ?></h2>
        </div>
        <form id="planForm" class="nidfil-plan-form">
            <input type="hidden" id="plan_id" name="plan_id" value="">
            <div class="form-group">
                <label for="plan_name"><?php _e('Plan Name', 'nidfil-connect'); ?> <span class="required">*</span></label>
                <input type="text" id="plan_name" name="plan_name" class="regular-text" required>
            </div>
            
            <div class="form-group">
                <label for="plan_price"><?php _e('Price (€)', 'nidfil-connect'); ?> <span class="required">*</span></label>
                <input type="number" id="plan_price" name="plan_price" step="0.01" min="0" class="regular-text" required>
            </div>
            
            <div class="form-group">
                <label for="plan_period"><?php _e('Billing Period', 'nidfil-connect'); ?> <span class="required">*</span></label>
                <input type="text" id="plan_period" name="plan_period" class="regular-text" placeholder="<?php _e('e.g., month, year, week, day, one-time', 'nidfil-connect'); ?>" value="" required>
                <p class="description"><?php _e('Enter the billing period (e.g., month, year, week, day, one-time)', 'nidfil-connect'); ?></p>
            </div>
            
            <div class="form-group">
                <label><?php _e('Plan Type', 'nidfil-connect'); ?> <span class="required">*</span></label>
                <div class="plan-type-switch-modal">
                    <button type="button" class="plan-type-btn-modal" data-type="free">
                        FREE
                    </button>
                    <button type="button" class="plan-type-btn-modal" data-type="pro">
                        PRO
                    </button>
                </div>
                <input type="hidden" id="plan_type" name="plan_type" value="free">
                <p class="description"><?php _e('Select whether this is a FREE or PRO plan', 'nidfil-connect'); ?></p>
            </div>
            
            <div class="form-group">
                <label for="plan_status">
                    <input type="checkbox" id="plan_status" name="plan_status" value="1" checked>
                    <?php _e('Active Plan', 'nidfil-connect'); ?>
                </label>
                <p class="description"><?php _e('Uncheck to deactivate this plan', 'nidfil-connect'); ?></p>
            </div>
            
            <div class="form-group" id="default-plan-group" style="display: none;">
                <label for="plan_default">
                    <input type="checkbox" id="plan_default" name="plan_default" value="1">
                    <?php _e('Set as Default FREE Plan', 'nidfil-connect'); ?>
                </label>
                <p class="description"><?php _e('Only one FREE plan can be set as default', 'nidfil-connect'); ?></p>
            </div>
            
            <div class="form-group">
                <label><?php _e('Plan Features/Items', 'nidfil-connect'); ?></label>
                <p class="description"><?php _e('Add and manage plan features. Each feature can be toggled on/off.', 'nidfil-connect'); ?></p>
                <div id="planFeaturesList" class="plan-features-edit-list">
                    <ul class="plan-items-edit" style="list-style: none; margin: 0 0 12px 0; padding: 0;">
                        <!-- Features will be dynamically added here -->
                    </ul>
                    <button type="button" id="addFeatureBtn" class="button button-secondary" style="margin-top: 8px;">
                        <i class="fas fa-plus"></i> <?php _e('Add Feature', 'nidfil-connect'); ?>
                    </button>
                </div>
                <input type="hidden" id="plan_items" name="plan_items" value="">
            </div>
            
            <div class="form-actions">
                <button type="submit" class="button button-primary">
                    <i class="fas fa-save"></i> <?php _e('Save Plan', 'nidfil-connect'); ?>
                </button>
                <button type="button" class="button cancel-plan"><?php _e('Cancel', 'nidfil-connect'); ?></button>
            </div>
        </form>
    </div>
</div>

