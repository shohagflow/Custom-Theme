<?php
/**
 * Google Maps Integration Page
 * 
 * @package NIDFIL_Connect
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!current_user_can('manage_options')) {
    wp_die(__('You do not have sufficient permissions to access this page.'));
}

// Handle API key save
if (isset($_POST['save_google_maps_api']) && check_admin_referer('nidfil_google_maps_save', 'nidfil_google_maps_nonce')) {
    $api_key = sanitize_text_field($_POST['google_maps_api_key']);
    update_option('nidfil_google_maps_api_key', $api_key);
    
    // Test API key if provided
    if (!empty($api_key)) {
        $test_url = 'https://maps.googleapis.com/maps/api/geocode/json?address=test&key=' . $api_key;
        $response = wp_remote_get($test_url);
        
        if (!is_wp_error($response)) {
            $body = json_decode(wp_remote_retrieve_body($response), true);
            if (isset($body['status']) && $body['status'] === 'OK') {
                update_option('nidfil_google_maps_api_status', 'connected');
                add_settings_error('nidfil_google_maps', 'api_success', __('Google Maps API key saved and verified successfully!', 'nidfil-connect'), 'success');
            } else {
                update_option('nidfil_google_maps_api_status', 'error');
                add_settings_error('nidfil_google_maps', 'api_error', __('API key is invalid. Please check your key and try again.', 'nidfil-connect'), 'error');
            }
        } else {
            update_option('nidfil_google_maps_api_status', 'error');
            add_settings_error('nidfil_google_maps', 'api_error', __('Could not verify API key. Please check your connection.', 'nidfil-connect'), 'error');
        }
    } else {
        update_option('nidfil_google_maps_api_status', 'disconnected');
        add_settings_error('nidfil_google_maps', 'api_disconnected', __('Google Maps API key removed.', 'nidfil-connect'), 'info');
    }
    
    settings_errors('nidfil_google_maps');
}

// Get current settings
$api_key = get_option('nidfil_google_maps_api_key', '');
$api_status = get_option('nidfil_google_maps_api_status', 'disconnected');
$is_connected = ($api_status === 'connected' && !empty($api_key));
?>

<div class="wrap nidfil-admin-wrap nidfil-google-maps-page">
    <div class="nidfil-page-header">
        <div class="header-content">
            <h1 class="wp-heading-inline"><?php _e('Google Maps Integration', 'nidfil-connect'); ?></h1>
            <p class="page-description"><?php _e('Connect your Google Maps API to enable location-based features for specialists and clients.', 'nidfil-connect'); ?></p>
        </div>
    </div>

    <?php settings_errors('nidfil_google_maps'); ?>

    <!-- API Status Cards -->
    <div class="nidfil-reports-stats">
        <div class="report-stat-card">
            <div class="stat-icon">
                <i class="fas fa-key"></i>
            </div>
            <div class="stat-content">
                <h3><?php echo $is_connected ? __('Connected', 'nidfil-connect') : __('Not Connected', 'nidfil-connect'); ?></h3>
                <p><?php _e('API Status', 'nidfil-connect'); ?></p>
            </div>
        </div>
        <div class="report-stat-card">
            <div class="stat-icon">
                <i class="fas fa-map-marked-alt"></i>
            </div>
            <div class="stat-content">
                <h3><?php echo $is_connected ? '4' : '0'; ?></h3>
                <p><?php _e('Enabled Features', 'nidfil-connect'); ?></p>
            </div>
        </div>
        <div class="report-stat-card">
            <div class="stat-icon">
                <i class="fas fa-check-circle"></i>
            </div>
            <div class="stat-content">
                <h3><?php echo $is_connected ? __('Active', 'nidfil-connect') : __('Inactive', 'nidfil-connect'); ?></h3>
                <p><?php _e('Integration Status', 'nidfil-connect'); ?></p>
            </div>
        </div>
    </div>
    
    <!-- Main Content Grid -->
    <div class="nidfil-reports-grid">
        <!-- API Configuration Card -->
        <div class="report-category-card">
            <div class="category-header">
                <i class="fas fa-key"></i>
                <h2><?php _e('API Configuration', 'nidfil-connect'); ?></h2>
            </div>
            <div class="report-list">
                <form method="post" action="" style="margin-bottom: 0;">
                    <?php wp_nonce_field('nidfil_google_maps_save', 'nidfil_google_maps_nonce'); ?>
                    
                    <div class="report-item" style="flex-direction: column; align-items: flex-start; gap: 12px;">
                        <div style="width: 100%;">
                            <label for="google_maps_api_key" style="display: block; margin-bottom: 8px; font-weight: 600; color: #1a202c; font-size: 13px;">
                                <?php _e('Google Maps API Key', 'nidfil-connect'); ?>
                            </label>
                            <input 
                                type="text" 
                                id="google_maps_api_key" 
                                name="google_maps_api_key" 
                                value="<?php echo esc_attr($api_key); ?>" 
                                placeholder="AIzaSy..." 
                                style="width: 100%; padding: 10px 12px; border: 1px solid #e5e9f2; border-radius: 6px; font-size: 13px; font-family: 'Courier New', monospace;"
                                autocomplete="off"
                            >
                            <p style="margin: 8px 0 0 0; font-size: 12px; color: #64748b; line-height: 1.4;">
                                <?php _e('Enter your Google Maps API key. Get one from', 'nidfil-connect'); ?>
                                <a href="https://console.cloud.google.com/google/maps-apis" target="_blank" rel="noopener" style="color: #f97015; text-decoration: none;">
                                    <?php _e('Google Cloud Console', 'nidfil-connect'); ?>
                                    <i class="fas fa-external-link-alt" style="font-size: 10px; margin-left: 4px;"></i>
                                </a>
                            </p>
                        </div>
                        
                        <?php if ($is_connected): ?>
                            <div style="width: 100%; padding: 12px; background: #d1fae5; border: 1px solid #a7f3d0; border-radius: 6px; display: flex; align-items: center; gap: 10px;">
                                <i class="fas fa-check-circle" style="color: #065f46; font-size: 18px;"></i>
                                <div>
                                    <strong style="display: block; color: #065f46; font-size: 13px; margin-bottom: 2px;"><?php _e('API Key Verified', 'nidfil-connect'); ?></strong>
                                    <p style="margin: 0; color: #065f46; font-size: 12px; opacity: 0.8;"><?php _e('Your Google Maps API is active and ready to use.', 'nidfil-connect'); ?></p>
                                </div>
                            </div>
                        <?php else: ?>
                            <div style="width: 100%; padding: 12px; background: #fef3c7; border: 1px solid #fde68a; border-radius: 6px; display: flex; align-items: center; gap: 10px;">
                                <i class="fas fa-exclamation-triangle" style="color: #92400e; font-size: 18px;"></i>
                                <div>
                                    <strong style="display: block; color: #92400e; font-size: 13px; margin-bottom: 2px;"><?php _e('API Key Required', 'nidfil-connect'); ?></strong>
                                    <p style="margin: 0; color: #92400e; font-size: 12px; opacity: 0.8;"><?php _e('Please enter a valid Google Maps API key to enable location features.', 'nidfil-connect'); ?></p>
                                </div>
                            </div>
                        <?php endif; ?>
                        
                        <div style="width: 100%; display: flex; gap: 10px; margin-top: 8px;">
                            <button type="submit" name="save_google_maps_api" class="button button-primary" style="flex: 1;">
                                <i class="fas fa-save" style="margin-right: 6px;"></i>
                                <?php _e('Save API Key', 'nidfil-connect'); ?>
                            </button>
                            <?php if ($is_connected): ?>
                                <button type="button" id="test-api-btn" class="button button-secondary">
                                    <i class="fas fa-vial" style="margin-right: 6px;"></i>
                                    <?php _e('Test', 'nidfil-connect'); ?>
                                </button>
                            <?php endif; ?>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Enabled Features Card -->
        <div class="report-category-card">
            <div class="category-header">
                <i class="fas fa-list-check"></i>
                <h2><?php _e('Enabled Features', 'nidfil-connect'); ?></h2>
            </div>
            <div class="report-list">
                <div class="report-item">
                    <div class="report-info">
                        <h4>
                            <i class="fas fa-map-marker-alt" style="color: <?php echo $is_connected ? '#f97015' : '#94a3b8'; ?>; margin-right: 6px;"></i>
                            <?php _e('Location Search', 'nidfil-connect'); ?>
                        </h4>
                        <p><?php _e('Users can search for specialists by location', 'nidfil-connect'); ?></p>
                    </div>
                    <div class="report-actions">
                        <?php if ($is_connected): ?>
                            <span style="color: #10b981; font-size: 18px;"><i class="fas fa-check-circle"></i></span>
                        <?php else: ?>
                            <span style="color: #94a3b8; font-size: 18px;"><i class="fas fa-times-circle"></i></span>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="report-item">
                    <div class="report-info">
                        <h4>
                            <i class="fas fa-route" style="color: <?php echo $is_connected ? '#f97015' : '#94a3b8'; ?>; margin-right: 6px;"></i>
                            <?php _e('Distance Calculation', 'nidfil-connect'); ?>
                        </h4>
                        <p><?php _e('Calculate distance between clients and specialists', 'nidfil-connect'); ?></p>
                    </div>
                    <div class="report-actions">
                        <?php if ($is_connected): ?>
                            <span style="color: #10b981; font-size: 18px;"><i class="fas fa-check-circle"></i></span>
                        <?php else: ?>
                            <span style="color: #94a3b8; font-size: 18px;"><i class="fas fa-times-circle"></i></span>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="report-item">
                    <div class="report-info">
                        <h4>
                            <i class="fas fa-map" style="color: <?php echo $is_connected ? '#f97015' : '#94a3b8'; ?>; margin-right: 6px;"></i>
                            <?php _e('Interactive Maps', 'nidfil-connect'); ?>
                        </h4>
                        <p><?php _e('Display specialist locations on interactive maps', 'nidfil-connect'); ?></p>
                    </div>
                    <div class="report-actions">
                        <?php if ($is_connected): ?>
                            <span style="color: #10b981; font-size: 18px;"><i class="fas fa-check-circle"></i></span>
                        <?php else: ?>
                            <span style="color: #94a3b8; font-size: 18px;"><i class="fas fa-times-circle"></i></span>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="report-item">
                    <div class="report-info">
                        <h4>
                            <i class="fas fa-directions" style="color: <?php echo $is_connected ? '#f97015' : '#94a3b8'; ?>; margin-right: 6px;"></i>
                            <?php _e('Directions & Navigation', 'nidfil-connect'); ?>
                        </h4>
                        <p><?php _e('Provide directions to specialist locations', 'nidfil-connect'); ?></p>
                    </div>
                    <div class="report-actions">
                        <?php if ($is_connected): ?>
                            <span style="color: #10b981; font-size: 18px;"><i class="fas fa-check-circle"></i></span>
                        <?php else: ?>
                            <span style="color: #94a3b8; font-size: 18px;"><i class="fas fa-times-circle"></i></span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Setup Guide Card -->
        <div class="report-category-card">
            <div class="category-header">
                <i class="fas fa-book"></i>
                <h2><?php _e('Setup Guide', 'nidfil-connect'); ?></h2>
            </div>
            <div class="report-list">
                <div class="report-item" style="flex-direction: column; align-items: flex-start; gap: 12px; padding: 20px;">
                    <div style="display: flex; gap: 12px; width: 100%;">
                        <div style="width: 32px; height: 32px; border-radius: 50%; background: linear-gradient(135deg, #f97015 0%, #ff8c42 100%); color: white; display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 14px; flex-shrink: 0;">1</div>
                        <div style="flex: 1;">
                            <h4 style="margin: 0 0 6px 0; font-size: 14px; font-weight: 600; color: #1a202c;"><?php _e('Create a Google Cloud Project', 'nidfil-connect'); ?></h4>
                            <p style="margin: 0 0 10px 0; font-size: 12px; color: #64748b; line-height: 1.5;"><?php _e('Go to Google Cloud Console and create a new project or select an existing one.', 'nidfil-connect'); ?></p>
                            <a href="https://console.cloud.google.com/projectcreate" target="_blank" rel="noopener" class="button button-small" style="display: inline-flex; align-items: center; gap: 6px;">
                                <?php _e('Create Project', 'nidfil-connect'); ?>
                                <i class="fas fa-external-link-alt" style="font-size: 10px;"></i>
                            </a>
                        </div>
                    </div>
                </div>
                
                <div class="report-item" style="flex-direction: column; align-items: flex-start; gap: 12px; padding: 20px;">
                    <div style="display: flex; gap: 12px; width: 100%;">
                        <div style="width: 32px; height: 32px; border-radius: 50%; background: linear-gradient(135deg, #f97015 0%, #ff8c42 100%); color: white; display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 14px; flex-shrink: 0;">2</div>
                        <div style="flex: 1;">
                            <h4 style="margin: 0 0 6px 0; font-size: 14px; font-weight: 600; color: #1a202c;"><?php _e('Enable Required APIs', 'nidfil-connect'); ?></h4>
                            <p style="margin: 0 0 8px 0; font-size: 12px; color: #64748b; line-height: 1.5;"><?php _e('Enable the following APIs in your project:', 'nidfil-connect'); ?></p>
                            <ul style="margin: 0 0 10px 20px; padding: 0; font-size: 12px; color: #64748b; line-height: 1.8;">
                                <li><strong>Maps JavaScript API</strong></li>
                                <li><strong>Geocoding API</strong></li>
                                <li><strong>Places API</strong></li>
                                <li><strong>Directions API</strong></li>
                            </ul>
                            <a href="https://console.cloud.google.com/apis/library" target="_blank" rel="noopener" class="button button-small" style="display: inline-flex; align-items: center; gap: 6px;">
                                <?php _e('Enable APIs', 'nidfil-connect'); ?>
                                <i class="fas fa-external-link-alt" style="font-size: 10px;"></i>
                            </a>
                        </div>
                    </div>
                </div>
                
                <div class="report-item" style="flex-direction: column; align-items: flex-start; gap: 12px; padding: 20px;">
                    <div style="display: flex; gap: 12px; width: 100%;">
                        <div style="width: 32px; height: 32px; border-radius: 50%; background: linear-gradient(135deg, #f97015 0%, #ff8c42 100%); color: white; display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 14px; flex-shrink: 0;">3</div>
                        <div style="flex: 1;">
                            <h4 style="margin: 0 0 6px 0; font-size: 14px; font-weight: 600; color: #1a202c;"><?php _e('Create API Key', 'nidfil-connect'); ?></h4>
                            <p style="margin: 0 0 10px 0; font-size: 12px; color: #64748b; line-height: 1.5;"><?php _e('Create a new API key in the Credentials section. Restrict it to your domain for security.', 'nidfil-connect'); ?></p>
                            <a href="https://console.cloud.google.com/apis/credentials" target="_blank" rel="noopener" class="button button-small" style="display: inline-flex; align-items: center; gap: 6px;">
                                <?php _e('Create API Key', 'nidfil-connect'); ?>
                                <i class="fas fa-external-link-alt" style="font-size: 10px;"></i>
                            </a>
                        </div>
                    </div>
                </div>
                
                <div class="report-item" style="flex-direction: column; align-items: flex-start; gap: 12px; padding: 20px;">
                    <div style="display: flex; gap: 12px; width: 100%;">
                        <div style="width: 32px; height: 32px; border-radius: 50%; background: linear-gradient(135deg, #f97015 0%, #ff8c42 100%); color: white; display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 14px; flex-shrink: 0;">4</div>
                        <div style="flex: 1;">
                            <h4 style="margin: 0 0 6px 0; font-size: 14px; font-weight: 600; color: #1a202c;"><?php _e('Enter API Key', 'nidfil-connect'); ?></h4>
                            <p style="margin: 0; font-size: 12px; color: #64748b; line-height: 1.5;"><?php _e('Copy your API key and paste it in the field above, then click "Save API Key".', 'nidfil-connect'); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Map Preview Card -->
        <?php if ($is_connected): ?>
        <div class="report-category-card" style="grid-column: 1 / -1;">
            <div class="category-header">
                <i class="fas fa-map"></i>
                <h2><?php _e('Map Preview', 'nidfil-connect'); ?></h2>
            </div>
            <div style="padding: 20px;">
                <div id="google-maps-preview" style="width: 100%; height: 400px; border-radius: 8px; overflow: hidden; border: 1px solid #e5e9f2;"></div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php if ($is_connected): ?>
<script>
(function() {
    // Load Google Maps API
    function loadGoogleMaps() {
        const script = document.createElement('script');
        script.src = 'https://maps.googleapis.com/maps/api/js?key=<?php echo esc_js($api_key); ?>&callback=initMap';
        script.async = true;
        script.defer = true;
        document.head.appendChild(script);
    }
    
    // Initialize map
    window.initMap = function() {
        const map = new google.maps.Map(document.getElementById('google-maps-preview'), {
            center: { lat: 40.4168, lng: -3.7038 }, // Madrid, Spain
            zoom: 10,
            mapTypeControl: true,
            streetViewControl: true,
            fullscreenControl: true
        });
        
        // Add a sample marker
        new google.maps.Marker({
            position: { lat: 40.4168, lng: -3.7038 },
            map: map,
            title: '<?php _e('Sample Location', 'nidfil-connect'); ?>'
        });
    };
    
    // Load maps when page is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', loadGoogleMaps);
    } else {
        loadGoogleMaps();
    }
})();
</script>
<?php endif; ?>
