<?php
/**
 * Lead & Offer Management Page
 * 
 * @package NIDFIL_Connect
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!current_user_can('manage_options')) {
    wp_die(__('You do not have sufficient permissions to access this page.'));
}

global $wpdb;
$leads_table = $wpdb->prefix . 'nidfil_leads';
$offers_table = $wpdb->prefix . 'nidfil_offers';

// Get leads with offers count
$leads = $wpdb->get_results("
    SELECT l.*, 
           COUNT(o.id) as offers_count,
           (SELECT COUNT(*) FROM $offers_table WHERE lead_id = l.id AND status = 'accepted') as accepted_offers
    FROM $leads_table l
    LEFT JOIN $offers_table o ON l.id = o.lead_id
    GROUP BY l.id
    ORDER BY l.created_at DESC
");

// Generate dummy data if needed
if (empty($leads)) {
    $leads = array(
        (object)array(
            'id' => 1,
            'customer_id' => 1,
            'service_type' => 'Electricidad',
            'project_type' => 'Reforma',
            'location' => 'Madrid, España',
            'description' => 'Necesito instalación eléctrica completa para reforma de cocina',
            'budget' => 2500.00,
            'status' => 'accepted',
            'offers_count' => 3,
            'accepted_offers' => 1,
            'created_at' => date('Y-m-d H:i:s', strtotime('-5 days'))
        ),
        (object)array(
            'id' => 2,
            'customer_id' => 2,
            'service_type' => 'Fontanería',
            'project_type' => 'Reparación',
            'location' => 'Barcelona, España',
            'description' => 'Fuga de agua en baño, necesita reparación urgente',
            'budget' => 500.00,
            'status' => 'offered',
            'offers_count' => 2,
            'accepted_offers' => 0,
            'created_at' => date('Y-m-d H:i:s', strtotime('-2 days'))
        ),
    );
}

$status_filter = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : 'all';

// Count leads by status
$all_leads = $leads;
$open_count = count(array_filter($all_leads, function($lead) { return $lead->status === 'open'; }));
$offered_count = count(array_filter($all_leads, function($lead) { return $lead->status === 'offered'; }));
$accepted_count = count(array_filter($all_leads, function($lead) { return $lead->status === 'accepted'; }));
$closed_count = count(array_filter($all_leads, function($lead) { return $lead->status === 'closed'; }));

if ($status_filter !== 'all') {
    $leads = array_filter($leads, function($lead) use ($status_filter) {
        return $lead->status === $status_filter;
    });
}
?>

<div class="wrap nidfil-admin-wrap nidfil-leads-page">
    <div class="nidfil-page-header">
        <div class="header-content">
            <h1 class="wp-heading-inline"><?php _e('Lead & Offer Management', 'nidfil-connect'); ?></h1>
            <p class="page-description"><?php _e('Manage customer leads and specialist offers', 'nidfil-connect'); ?></p>
        </div>
    </div>
    
    <!-- Modern Tab Navigation -->
    <div class="nidfil-tab-navigation">
        <a href="?page=nidfil-leads&status=all" class="nidfil-tab <?php echo $status_filter === 'all' ? 'active' : ''; ?>">
            <span class="tab-label"><?php _e('All', 'nidfil-connect'); ?></span>
            <span class="tab-count"><?php echo count($all_leads); ?></span>
        </a>
        <a href="?page=nidfil-leads&status=open" class="nidfil-tab <?php echo $status_filter === 'open' ? 'active' : ''; ?>">
            <span class="tab-label"><?php _e('Open', 'nidfil-connect'); ?></span>
            <span class="tab-count"><?php echo $open_count; ?></span>
        </a>
        <a href="?page=nidfil-leads&status=offered" class="nidfil-tab <?php echo $status_filter === 'offered' ? 'active' : ''; ?>">
            <span class="tab-label"><?php _e('Offered', 'nidfil-connect'); ?></span>
            <span class="tab-count"><?php echo $offered_count; ?></span>
        </a>
        <a href="?page=nidfil-leads&status=accepted" class="nidfil-tab <?php echo $status_filter === 'accepted' ? 'active' : ''; ?>">
            <span class="tab-label"><?php _e('Accepted', 'nidfil-connect'); ?></span>
            <span class="tab-count"><?php echo $accepted_count; ?></span>
        </a>
        <a href="?page=nidfil-leads&status=closed" class="nidfil-tab <?php echo $status_filter === 'closed' ? 'active' : ''; ?>">
            <span class="tab-label"><?php _e('Closed', 'nidfil-connect'); ?></span>
            <span class="tab-count"><?php echo $closed_count; ?></span>
        </a>
    </div>
    
    <table class="wp-list-table widefat fixed striped nidfil-leads-table">
        <thead>
            <tr>
                <th class="column-name"><?php _e('Name', 'nidfil-connect'); ?></th>
                <th class="column-service"><?php _e('Service Type', 'nidfil-connect'); ?></th>
                <th class="column-location"><?php _e('Location', 'nidfil-connect'); ?></th>
                <th class="column-budget"><?php _e('Budget', 'nidfil-connect'); ?></th>
                <th class="column-status"><?php _e('Status', 'nidfil-connect'); ?></th>
                <th class="column-offers"><?php _e('Offers', 'nidfil-connect'); ?></th>
                <th class="column-actions"><?php _e('Actions', 'nidfil-connect'); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($leads)): ?>
                <tr>
                    <td colspan="7"><?php _e('No leads found.', 'nidfil-connect'); ?></td>
                </tr>
            <?php else: ?>
                <?php foreach ($leads as $lead): 
                    $customer = get_userdata($lead->customer_id);
                    $customer_name = $customer ? $customer->display_name : __('Customer #' . $lead->customer_id, 'nidfil-connect');
                    
                    // Get offers for this lead
                    $offers = $wpdb->get_results($wpdb->prepare(
                        "SELECT * FROM $offers_table WHERE lead_id = %d ORDER BY created_at DESC",
                        $lead->id
                    ));
                ?>
                    <tr>
                        <td class="column-name">
                            <strong><?php echo esc_html($customer_name); ?></strong>
                        </td>
                        <td class="column-service"><?php echo esc_html($lead->service_type); ?></td>
                        <td class="column-location"><?php echo esc_html($lead->location); ?></td>
                        <td class="column-budget">€<?php echo number_format($lead->budget, 2); ?></td>
                        <td class="column-status">
                            <span class="status-badge status-<?php echo esc_attr($lead->status); ?>">
                                <?php echo ucfirst($lead->status); ?>
                            </span>
                        </td>
                        <td class="column-offers">
                            <strong><?php echo $lead->offers_count; ?></strong> <?php _e('offers', 'nidfil-connect'); ?>
                            <?php if ($lead->accepted_offers > 0): ?>
                                <br><small class="accepted"><?php echo $lead->accepted_offers; ?> <?php _e('accepted', 'nidfil-connect'); ?></small>
                            <?php endif; ?>
                        </td>
                        <td class="column-actions">
                            <button class="button button-small view-lead" data-lead-id="<?php echo $lead->id; ?>"><?php _e('View Details', 'nidfil-connect'); ?></button>
                            <button class="button button-small view-offers" data-lead-id="<?php echo $lead->id; ?>"><?php _e('View Offers', 'nidfil-connect'); ?></button>
                            <button class="button button-small button-link-delete delete-lead" data-lead-id="<?php echo $lead->id; ?>"><?php _e('Delete', 'nidfil-connect'); ?></button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<!-- Offers Modal -->
<div id="offersModal" class="nidfil-modal" style="display:none;">
    <div class="modal-content">
        <span class="close-modal">&times;</span>
        <h2><?php _e('Offers for Lead', 'nidfil-connect'); ?></h2>
        <div id="offersList"></div>
    </div>
</div>

