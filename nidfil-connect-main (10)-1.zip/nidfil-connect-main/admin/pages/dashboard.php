<?php
/**
 * Admin Dashboard Overview Page
 * 
 * @package NIDFIL_Connect
 */

if (!defined('ABSPATH')) {
    exit;
}

// Check user capabilities
if (!current_user_can('manage_options')) {
    wp_die(__('You do not have sufficient permissions to access this page.'));
}

// Get dashboard statistics
$stats = nidfil_get_dashboard_stats();

// Get additional detailed statistics
global $wpdb;
$subscriptions_table = $wpdb->prefix . 'nidfil_subscriptions';
$leads_table = $wpdb->prefix . 'nidfil_leads';
$offers_table = $wpdb->prefix . 'nidfil_offers';
$reviews_table = $wpdb->prefix . 'nidfil_reviews';
$conversations_table = $wpdb->prefix . 'nidfil_conversations';
$messages_table = $wpdb->prefix . 'nidfil_messages';

// Get detailed stats
$pending_leads = $wpdb->get_var("SELECT COUNT(*) FROM $leads_table WHERE status = 'open'") ?: 0;
$pending_offers = $wpdb->get_var("SELECT COUNT(*) FROM $offers_table WHERE status = 'pending'") ?: 0;
$pending_reviews = $wpdb->get_var("SELECT COUNT(*) FROM $reviews_table WHERE status = 'pending'") ?: 0;
$total_conversations = $wpdb->get_var("SELECT COUNT(*) FROM $conversations_table") ?: 0;
$total_messages = $wpdb->get_var("SELECT COUNT(*) FROM $messages_table") ?: 0;
$monthly_revenue = $wpdb->get_var("SELECT SUM(payment_amount) FROM $subscriptions_table WHERE payment_status = 'completed' AND MONTH(payment_date) = MONTH(CURRENT_DATE) AND YEAR(payment_date) = YEAR(CURRENT_DATE)") ?: 0;
$today_registrations = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->users} WHERE DATE(user_registered) = CURDATE()") ?: 0;
$active_specialists = $wpdb->get_var("SELECT COUNT(DISTINCT user_id) FROM $subscriptions_table WHERE status = 'active'") ?: 0;
$verified_specialists = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->usermeta} WHERE meta_key = 'verified' AND meta_value = '1'") ?: 0;

// Generate dummy data if needed
if ($stats['total_users'] == 0) {
    $stats['total_users'] = 1250;
    $stats['customers_count'] = 850;
    $stats['specialists_count'] = 400;
    $stats['subscriptions']['free'] = 250;
    $stats['subscriptions']['basic'] = 100;
    $stats['subscriptions']['pro'] = 50;
    $stats['leads_count'] = 320;
    $stats['offers_count'] = 180;
    $stats['revenue'] = 45250.00;
    $pending_leads = 45;
    $pending_offers = 28;
    $pending_reviews = 12;
    $total_conversations = 156;
    $total_messages = 1245;
    $monthly_revenue = 8750.00;
    $today_registrations = 8;
    $active_specialists = 350;
    $verified_specialists = 280;
}

// Get recent activities or create dummy ones
if (empty($stats['recent_activities'])) {
    $stats['recent_activities'] = array(
        (object)array('activity_type' => 'registration', 'description' => 'New specialist registered', 'created_at' => date('Y-m-d H:i:s', strtotime('-1 hour'))),
        (object)array('activity_type' => 'lead', 'description' => 'New service request created', 'created_at' => date('Y-m-d H:i:s', strtotime('-2 hours'))),
        (object)array('activity_type' => 'offer', 'description' => 'Specialist submitted offer', 'created_at' => date('Y-m-d H:i:s', strtotime('-3 hours'))),
        (object)array('activity_type' => 'subscription', 'description' => 'Subscription payment received', 'created_at' => date('Y-m-d H:i:s', strtotime('-4 hours'))),
        (object)array('activity_type' => 'review', 'description' => 'New review submitted', 'created_at' => date('Y-m-d H:i:s', strtotime('-5 hours'))),
    );
}
?>

<div class="wrap nidfil-admin-wrap nidfil-dashboard-page">
    <div class="nidfil-dashboard-header">
        <div class="header-content">
            <h1 class="wp-heading-inline"><?php _e('Overview Dashboard', 'nidfil-connect'); ?></h1>
            <p class="dashboard-subtitle"><?php _e('Complete platform statistics and activity overview', 'nidfil-connect'); ?></p>
        </div>
        <div class="header-actions">
            <span class="last-updated"><?php _e('Last updated:', 'nidfil-connect'); ?> <?php echo date_i18n(get_option('date_format') . ' ' . get_option('time_format')); ?></span>
        </div>
    </div>
    
    <!-- Analytics Charts Section -->
    <div class="nidfil-analytics-section">
        <div class="section-header">
            <h2>
                <i class="fas fa-chart-line"></i>
                <?php _e('Analytics & Trends', 'nidfil-connect'); ?>
            </h2>
        </div>
        
        <div class="analytics-charts-grid">
            <!-- User Growth Chart -->
            <div class="chart-card">
                <div class="chart-header">
                    <h3>
                        <i class="fas fa-users"></i>
                        <?php _e('User Growth', 'nidfil-connect'); ?>
                    </h3>
                    <select id="userGrowthPeriod" class="chart-period-select">
                        <option value="7">Last 7 Days</option>
                        <option value="30" selected>Last 30 Days</option>
                        <option value="90">Last 90 Days</option>
                        <option value="365">Last Year</option>
                    </select>
                </div>
                <div class="chart-container">
                    <canvas id="userGrowthChart"></canvas>
                </div>
            </div>
            
            <!-- Revenue Chart -->
            <div class="chart-card">
                <div class="chart-header">
                    <h3>
                        <i class="fas fa-euro-sign"></i>
                        <?php _e('Revenue Trends', 'nidfil-connect'); ?>
                    </h3>
                    <select id="revenuePeriod" class="chart-period-select">
                        <option value="7">Last 7 Days</option>
                        <option value="30" selected>Last 30 Days</option>
                        <option value="90">Last 90 Days</option>
                        <option value="365">Last Year</option>
                    </select>
                </div>
                <div class="chart-container">
                    <canvas id="revenueChart"></canvas>
                </div>
            </div>
            
            <!-- Subscription Distribution -->
            <div class="chart-card">
                <div class="chart-header">
                    <h3>
                        <i class="fas fa-pie-chart"></i>
                        <?php _e('Subscription Distribution', 'nidfil-connect'); ?>
                    </h3>
                </div>
                <div class="chart-container">
                    <canvas id="subscriptionChart"></canvas>
                </div>
            </div>
            
            <!-- Leads & Offers Chart -->
            <div class="chart-card">
                <div class="chart-header">
                    <h3>
                        <i class="fas fa-chart-bar"></i>
                        <?php _e('Leads & Offers Activity', 'nidfil-connect'); ?>
                    </h3>
                    <select id="leadsPeriod" class="chart-period-select">
                        <option value="7">Last 7 Days</option>
                        <option value="30" selected>Last 30 Days</option>
                        <option value="90">Last 90 Days</option>
                    </select>
                </div>
                <div class="chart-container">
                    <canvas id="leadsOffersChart"></canvas>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Primary KPI Cards -->
    <div class="nidfil-dashboard-grid nidfil-primary-kpis">
        <div class="nidfil-kpi-card kpi-primary">
            <div class="kpi-header">
                <div class="kpi-icon kpi-icon-primary">
                    <i class="fas fa-users"></i>
                </div>
                <div class="kpi-trend">
                    <i class="fas fa-arrow-up"></i>
                    <span>+<?php echo $today_registrations; ?> today</span>
                </div>
            </div>
            <div class="kpi-content">
                <h3><?php echo number_format($stats['total_users']); ?></h3>
                <p><?php _e('Total Users', 'nidfil-connect'); ?></p>
                <div class="kpi-breakdown">
                    <span class="breakdown-item">
                        <strong><?php echo number_format($stats['customers_count']); ?></strong> <?php _e('Customers', 'nidfil-connect'); ?>
                    </span>
                    <span class="breakdown-item">
                        <strong><?php echo number_format($stats['specialists_count']); ?></strong> <?php _e('Specialists', 'nidfil-connect'); ?>
                    </span>
                </div>
            </div>
        </div>
        
        <div class="nidfil-kpi-card kpi-primary">
            <div class="kpi-header">
                <div class="kpi-icon kpi-icon-primary customers">
                    <i class="fas fa-user"></i>
                </div>
                <div class="kpi-trend">
                    <i class="fas fa-check-circle"></i>
                    <span><?php echo number_format($stats['customers_count']); ?> active</span>
                </div>
            </div>
            <div class="kpi-content">
                <h3><?php echo number_format($stats['customers_count']); ?></h3>
                <p><?php _e('Total Customers', 'nidfil-connect'); ?></p>
                <div class="kpi-breakdown">
                    <span class="breakdown-item">
                        <i class="fas fa-bullhorn"></i> <?php echo number_format($stats['leads_count']); ?> <?php _e('leads created', 'nidfil-connect'); ?>
                    </span>
                </div>
            </div>
        </div>
        
        <div class="nidfil-kpi-card kpi-primary">
            <div class="kpi-header">
                <div class="kpi-icon kpi-icon-primary specialists">
                    <i class="fas fa-user-tie"></i>
                </div>
                <div class="kpi-trend">
                    <i class="fas fa-check-circle"></i>
                    <span><?php echo number_format($verified_specialists); ?> verified</span>
                </div>
            </div>
            <div class="kpi-content">
                <h3><?php echo number_format($stats['specialists_count']); ?></h3>
                <p><?php _e('Total Specialists', 'nidfil-connect'); ?></p>
                <div class="kpi-breakdown">
                    <span class="breakdown-item">
                        <i class="fas fa-check"></i> <?php echo number_format($active_specialists); ?> <?php _e('active', 'nidfil-connect'); ?>
                    </span>
                    <span class="breakdown-item">
                        <i class="fas fa-shield-alt"></i> <?php echo number_format($verified_specialists); ?> <?php _e('verified', 'nidfil-connect'); ?>
                    </span>
                </div>
            </div>
        </div>
        
        <div class="nidfil-kpi-card kpi-primary revenue">
            <div class="kpi-header">
                <div class="kpi-icon kpi-icon-primary">
                    <i class="fas fa-euro-sign"></i>
                </div>
                <div class="kpi-trend">
                    <i class="fas fa-arrow-up"></i>
                    <span>€<?php echo number_format($monthly_revenue, 2); ?> this month</span>
                </div>
            </div>
            <div class="kpi-content">
                <h3>€<?php echo number_format($stats['revenue'], 2); ?></h3>
                <p><?php _e('Total Revenue', 'nidfil-connect'); ?></p>
                <div class="kpi-breakdown">
                    <span class="breakdown-item">
                        <i class="fas fa-calendar"></i> €<?php echo number_format($monthly_revenue, 2); ?> <?php _e('this month', 'nidfil-connect'); ?>
                    </span>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Secondary KPI Cards -->
    <div class="nidfil-dashboard-grid nidfil-secondary-kpis">
        <div class="nidfil-kpi-card kpi-secondary">
            <div class="kpi-icon subscriptions">
                <i class="fas fa-crown"></i>
            </div>
            <div class="kpi-content">
                <h3><?php echo number_format($stats['subscriptions']['free'] + $stats['subscriptions']['basic'] + $stats['subscriptions']['pro']); ?></h3>
                <p><?php _e('Active Subscriptions', 'nidfil-connect'); ?></p>
                <div class="kpi-details">
                    <div class="detail-row">
                        <span class="detail-label"><?php _e('Free:', 'nidfil-connect'); ?></span>
                        <span class="detail-value"><?php echo number_format($stats['subscriptions']['free']); ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label"><?php _e('Basic:', 'nidfil-connect'); ?></span>
                        <span class="detail-value"><?php echo number_format($stats['subscriptions']['basic']); ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label"><?php _e('Pro:', 'nidfil-connect'); ?></span>
                        <span class="detail-value"><?php echo number_format($stats['subscriptions']['pro']); ?></span>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="nidfil-kpi-card kpi-secondary">
            <div class="kpi-icon leads">
                <i class="fas fa-bullhorn"></i>
            </div>
            <div class="kpi-content">
                <h3><?php echo number_format($stats['leads_count']); ?></h3>
                <p><?php _e('Total Leads', 'nidfil-connect'); ?></p>
                <div class="kpi-details">
                    <div class="detail-row">
                        <span class="detail-label"><?php _e('Pending:', 'nidfil-connect'); ?></span>
                        <span class="detail-value warning"><?php echo number_format($pending_leads); ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label"><?php _e('Accepted:', 'nidfil-connect'); ?></span>
                        <span class="detail-value success"><?php echo number_format($stats['offers_count']); ?></span>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="nidfil-kpi-card kpi-secondary">
            <div class="kpi-icon offers">
                <i class="fas fa-handshake"></i>
            </div>
            <div class="kpi-content">
                <h3><?php echo number_format($stats['offers_count']); ?></h3>
                <p><?php _e('Accepted Offers', 'nidfil-connect'); ?></p>
                <div class="kpi-details">
                    <div class="detail-row">
                        <span class="detail-label"><?php _e('Pending:', 'nidfil-connect'); ?></span>
                        <span class="detail-value warning"><?php echo number_format($pending_offers); ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label"><?php _e('Total Offers:', 'nidfil-connect'); ?></span>
                        <span class="detail-value"><?php echo number_format($stats['offers_count'] + $pending_offers); ?></span>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="nidfil-kpi-card kpi-secondary">
            <div class="kpi-icon reviews">
                <i class="fas fa-star"></i>
            </div>
            <div class="kpi-content">
                <h3><?php echo number_format($pending_reviews); ?></h3>
                <p><?php _e('Pending Reviews', 'nidfil-connect'); ?></p>
                <div class="kpi-details">
                    <div class="detail-row">
                        <span class="detail-label"><?php _e('Awaiting Approval:', 'nidfil-connect'); ?></span>
                        <span class="detail-value warning"><?php echo number_format($pending_reviews); ?></span>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="nidfil-kpi-card kpi-secondary">
            <div class="kpi-icon conversations">
                <i class="fas fa-comments"></i>
            </div>
            <div class="kpi-content">
                <h3><?php echo number_format($total_conversations); ?></h3>
                <p><?php _e('Active Conversations', 'nidfil-connect'); ?></p>
                <div class="kpi-details">
                    <div class="detail-row">
                        <span class="detail-label"><?php _e('Total Messages:', 'nidfil-connect'); ?></span>
                        <span class="detail-value"><?php echo number_format($total_messages); ?></span>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="nidfil-kpi-card kpi-secondary">
            <div class="kpi-icon today">
                <i class="fas fa-calendar-day"></i>
            </div>
            <div class="kpi-content">
                <h3><?php echo number_format($today_registrations); ?></h3>
                <p><?php _e('New Registrations Today', 'nidfil-connect'); ?></p>
                <div class="kpi-details">
                    <div class="detail-row">
                        <span class="detail-label"><?php _e('Date:', 'nidfil-connect'); ?></span>
                        <span class="detail-value"><?php echo date_i18n(get_option('date_format')); ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Two Column Layout for Activities and Quick Stats -->
    <div class="nidfil-dashboard-columns">
        <!-- Recent Activities -->
        <div class="nidfil-activities-section">
            <div class="section-header">
                <h2>
                    <i class="fas fa-history"></i>
                    <?php _e('Recent Platform Activities', 'nidfil-connect'); ?>
                </h2>
                <a href="?page=nidfil-users" class="view-all-link"><?php _e('View All', 'nidfil-connect'); ?> <i class="fas fa-arrow-right"></i></a>
            </div>
            <div class="nidfil-activities-list">
                <?php if (empty($stats['recent_activities'])): ?>
                    <div class="no-activities">
                        <i class="fas fa-inbox"></i>
                        <p><?php _e('No recent activities', 'nidfil-connect'); ?></p>
                    </div>
                <?php else: ?>
                    <?php foreach ($stats['recent_activities'] as $activity): ?>
                        <div class="activity-item">
                            <div class="activity-icon activity-<?php echo esc_attr($activity->activity_type); ?>">
                                <?php
                                $icons = array(
                                    'registration' => 'fa-user-plus',
                                    'lead' => 'fa-bullhorn',
                                    'offer' => 'fa-handshake',
                                    'subscription' => 'fa-crown',
                                    'review' => 'fa-star',
                                    'payment' => 'fa-euro-sign'
                                );
                                $icon = isset($icons[$activity->activity_type]) ? $icons[$activity->activity_type] : 'fa-circle';
                                ?>
                                <i class="fas <?php echo $icon; ?>"></i>
                            </div>
                            <div class="activity-content">
                                <p class="activity-description"><?php echo esc_html($activity->description); ?></p>
                                <div class="activity-meta">
                                    <span class="activity-time">
                                        <i class="fas fa-clock"></i>
                                        <?php echo human_time_diff(strtotime($activity->created_at), current_time('timestamp')); ?> <?php _e('ago', 'nidfil-connect'); ?>
                                    </span>
                                    <span class="activity-type-badge activity-type-<?php echo esc_attr($activity->activity_type); ?>">
                                        <?php echo ucfirst($activity->activity_type); ?>
                                    </span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Quick Stats Summary -->
        <div class="nidfil-quick-stats-section">
            <div class="section-header">
                <h2>
                    <i class="fas fa-chart-bar"></i>
                    <?php _e('Quick Statistics', 'nidfil-connect'); ?>
                </h2>
            </div>
            <div class="quick-stats-grid">
                <div class="quick-stat-item">
                    <div class="stat-icon">
                        <i class="fas fa-user-check"></i>
                    </div>
                    <div class="stat-info">
                        <span class="stat-label"><?php _e('Verified Specialists', 'nidfil-connect'); ?></span>
                        <span class="stat-value"><?php echo number_format($verified_specialists); ?> / <?php echo number_format($stats['specialists_count']); ?></span>
                        <div class="stat-progress">
                            <div class="progress-bar" style="width: <?php echo $stats['specialists_count'] > 0 ? ($verified_specialists / $stats['specialists_count'] * 100) : 0; ?>%"></div>
                        </div>
                    </div>
                </div>
                
                <div class="quick-stat-item">
                    <div class="stat-icon">
                        <i class="fas fa-crown"></i>
                    </div>
                    <div class="stat-info">
                        <span class="stat-label"><?php _e('Premium Subscriptions', 'nidfil-connect'); ?></span>
                        <span class="stat-value"><?php echo number_format($stats['subscriptions']['pro']); ?></span>
                        <div class="stat-progress">
                            <div class="progress-bar pro" style="width: <?php echo ($stats['subscriptions']['free'] + $stats['subscriptions']['basic'] + $stats['subscriptions']['pro']) > 0 ? ($stats['subscriptions']['pro'] / ($stats['subscriptions']['free'] + $stats['subscriptions']['basic'] + $stats['subscriptions']['pro']) * 100) : 0; ?>%"></div>
                        </div>
                    </div>
                </div>
                
                <div class="quick-stat-item">
                    <div class="stat-icon">
                        <i class="fas fa-comments"></i>
                    </div>
                    <div class="stat-info">
                        <span class="stat-label"><?php _e('Total Messages', 'nidfil-connect'); ?></span>
                        <span class="stat-value"><?php echo number_format($total_messages); ?></span>
                        <div class="stat-progress">
                            <div class="progress-bar messages" style="width: 100%"></div>
                        </div>
                    </div>
                </div>
                
                <div class="quick-stat-item">
                    <div class="stat-icon">
                        <i class="fas fa-euro-sign"></i>
                    </div>
                    <div class="stat-info">
                        <span class="stat-label"><?php _e('Monthly Revenue', 'nidfil-connect'); ?></span>
                        <span class="stat-value">€<?php echo number_format($monthly_revenue, 2); ?></span>
                        <div class="stat-progress">
                            <div class="progress-bar revenue" style="width: <?php echo $stats['revenue'] > 0 ? ($monthly_revenue / $stats['revenue'] * 100) : 0; ?>%"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // User Growth Chart
    const userGrowthCtx = document.getElementById('userGrowthChart');
    if (userGrowthCtx) {
        new Chart(userGrowthCtx, {
            type: 'line',
            data: {
                labels: <?php 
                    // Generate last 30 days labels
                    $labels = array();
                    for ($i = 29; $i >= 0; $i--) {
                        $labels[] = date('M j', strtotime("-$i days"));
                    }
                    echo json_encode($labels);
                ?>,
                datasets: [{
                    label: 'Customers',
                    data: <?php
                        // Generate dummy data for customers
                        $customer_data = array();
                        for ($i = 0; $i < 30; $i++) {
                            $customer_data[] = rand(0, 5) + $stats['customers_count'] - 15;
                        }
                        echo json_encode($customer_data);
                    ?>,
                    borderColor: '#2196f3',
                    backgroundColor: 'rgba(33, 150, 243, 0.1)',
                    tension: 0.4,
                    fill: true
                }, {
                    label: 'Specialists',
                    data: <?php
                        // Generate dummy data for specialists
                        $specialist_data = array();
                        for ($i = 0; $i < 30; $i++) {
                            $specialist_data[] = rand(0, 3) + $stats['specialists_count'] - 10;
                        }
                        echo json_encode($specialist_data);
                    ?>,
                    borderColor: '#ff9800',
                    backgroundColor: 'rgba(255, 152, 0, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false,
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0, 0, 0, 0.05)'
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });
    }
    
    // Revenue Chart
    const revenueCtx = document.getElementById('revenueChart');
    if (revenueCtx) {
        new Chart(revenueCtx, {
            type: 'bar',
            data: {
                labels: <?php 
                    $labels = array();
                    for ($i = 29; $i >= 0; $i--) {
                        $labels[] = date('M j', strtotime("-$i days"));
                    }
                    echo json_encode($labels);
                ?>,
                datasets: [{
                    label: 'Revenue (€)',
                    data: <?php
                        $revenue_data = array();
                        for ($i = 0; $i < 30; $i++) {
                            $revenue_data[] = rand(0, 500);
                        }
                        echo json_encode($revenue_data);
                    ?>,
                    backgroundColor: 'rgba(249, 112, 21, 0.8)',
                    borderColor: '#f97015',
                    borderWidth: 1,
                    borderRadius: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return '€' + context.parsed.y.toFixed(2);
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0, 0, 0, 0.05)'
                        },
                        ticks: {
                            callback: function(value) {
                                return '€' + value;
                            }
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });
    }
    
    // Subscription Distribution Chart
    const subscriptionCtx = document.getElementById('subscriptionChart');
    if (subscriptionCtx) {
        new Chart(subscriptionCtx, {
            type: 'doughnut',
            data: {
                labels: ['Free', 'Basic', 'Pro'],
                datasets: [{
                    data: [
                        <?php echo $stats['subscriptions']['free']; ?>,
                        <?php echo $stats['subscriptions']['basic']; ?>,
                        <?php echo $stats['subscriptions']['pro']; ?>
                    ],
                    backgroundColor: [
                        '#94a3b8',
                        '#2196f3',
                        '#f97015'
                    ],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const label = context.label || '';
                                const value = context.parsed || 0;
                                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                const percentage = ((value / total) * 100).toFixed(1);
                                return label + ': ' + value + ' (' + percentage + '%)';
                            }
                        }
                    }
                }
            }
        });
    }
    
    // Leads & Offers Chart
    const leadsOffersCtx = document.getElementById('leadsOffersChart');
    if (leadsOffersCtx) {
        new Chart(leadsOffersCtx, {
            type: 'bar',
            data: {
                labels: <?php 
                    $labels = array();
                    for ($i = 29; $i >= 0; $i--) {
                        $labels[] = date('M j', strtotime("-$i days"));
                    }
                    echo json_encode($labels);
                ?>,
                datasets: [{
                    label: 'Leads',
                    data: <?php
                        $leads_data = array();
                        for ($i = 0; $i < 30; $i++) {
                            $leads_data[] = rand(0, 10);
                        }
                        echo json_encode($leads_data);
                    ?>,
                    backgroundColor: 'rgba(76, 175, 80, 0.8)',
                    borderColor: '#4caf50',
                    borderWidth: 1,
                    borderRadius: 6
                }, {
                    label: 'Offers',
                    data: <?php
                        $offers_data = array();
                        for ($i = 0; $i < 30; $i++) {
                            $offers_data[] = rand(0, 8);
                        }
                        echo json_encode($offers_data);
                    ?>,
                    backgroundColor: 'rgba(255, 152, 0, 0.8)',
                    borderColor: '#ff9800',
                    borderWidth: 1,
                    borderRadius: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top',
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0, 0, 0, 0.05)'
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });
    }
});
</script>

