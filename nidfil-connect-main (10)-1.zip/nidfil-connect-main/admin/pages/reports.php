<?php
/**
 * Reports Page
 * 
 * @package NIDFIL_Connect
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!current_user_can('manage_options')) {
    wp_die(__('You do not have sufficient permissions to access this page.'));
}

global $wpdb;
$users_table = $wpdb->prefix . 'users';
$subscriptions_table = $wpdb->prefix . 'nidfil_subscriptions';
$leads_table = $wpdb->prefix . 'nidfil_leads';
$offers_table = $wpdb->prefix . 'nidfil_offers';
$reviews_table = $wpdb->prefix . 'nidfil_reviews';
$conversations_table = $wpdb->prefix . 'nidfil_conversations';
$messages_table = $wpdb->prefix . 'nidfil_messages';

// Handle report download
if (isset($_GET['download']) && isset($_GET['report_type']) && isset($_GET['nonce'])) {
    if (!wp_verify_nonce($_GET['nonce'], 'nidfil_download_report')) {
        wp_die(__('Security check failed.', 'nidfil-connect'));
    }
    
    $report_type = sanitize_text_field($_GET['report_type']);
    $format = isset($_GET['format']) ? sanitize_text_field($_GET['format']) : 'csv';
    
    // Generate and download report
    nidfil_generate_report($report_type, $format);
    exit;
}

// Get statistics
$total_users = $wpdb->get_var("SELECT COUNT(*) FROM $users_table");
$total_clients = $wpdb->get_var("SELECT COUNT(*) FROM $users_table u INNER JOIN {$wpdb->prefix}usermeta um ON u.ID = um.user_id WHERE um.meta_key = 'user_type' AND um.meta_value = 'client'");
$total_specialists = $wpdb->get_var("SELECT COUNT(*) FROM $users_table u INNER JOIN {$wpdb->prefix}usermeta um ON u.ID = um.user_id WHERE um.meta_key = 'user_type' AND um.meta_value = 'specialist'");
$total_subscriptions = $wpdb->get_var("SELECT COUNT(*) FROM $subscriptions_table");
$total_leads = $wpdb->get_var("SELECT COUNT(*) FROM $leads_table");
$total_offers = $wpdb->get_var("SELECT COUNT(*) FROM $offers_table");
$total_reviews = $wpdb->get_var("SELECT COUNT(*) FROM $reviews_table");
$total_conversations = $wpdb->get_var("SELECT COUNT(*) FROM $conversations_table");
$total_messages = $wpdb->get_var("SELECT COUNT(*) FROM $messages_table");
?>

<div class="wrap nidfil-admin-wrap nidfil-reports-page">
    <div class="nidfil-page-header">
        <div class="header-content">
            <h1 class="wp-heading-inline"><?php _e('Reports', 'nidfil-connect'); ?></h1>
            <p class="page-description"><?php _e('Download comprehensive reports and analytics data', 'nidfil-connect'); ?></p>
        </div>
    </div>
    
    <!-- Statistics Cards -->
    <div class="nidfil-reports-stats">
        <div class="report-stat-card">
            <div class="stat-icon">
                <i class="fas fa-users"></i>
            </div>
            <div class="stat-content">
                <h3><?php echo number_format($total_users); ?></h3>
                <p><?php _e('Total Users', 'nidfil-connect'); ?></p>
            </div>
        </div>
        <div class="report-stat-card">
            <div class="stat-icon">
                <i class="fas fa-user-tie"></i>
            </div>
            <div class="stat-content">
                <h3><?php echo number_format($total_clients); ?></h3>
                <p><?php _e('Clients', 'nidfil-connect'); ?></p>
            </div>
        </div>
        <div class="report-stat-card">
            <div class="stat-icon">
                <i class="fas fa-user-cog"></i>
            </div>
            <div class="stat-content">
                <h3><?php echo number_format($total_specialists); ?></h3>
                <p><?php _e('Specialists', 'nidfil-connect'); ?></p>
            </div>
        </div>
        <div class="report-stat-card">
            <div class="stat-icon">
                <i class="fas fa-credit-card"></i>
            </div>
            <div class="stat-content">
                <h3><?php echo number_format($total_subscriptions); ?></h3>
                <p><?php _e('Subscriptions', 'nidfil-connect'); ?></p>
            </div>
        </div>
        <div class="report-stat-card">
            <div class="stat-icon">
                <i class="fas fa-bullhorn"></i>
            </div>
            <div class="stat-content">
                <h3><?php echo number_format($total_leads); ?></h3>
                <p><?php _e('Leads', 'nidfil-connect'); ?></p>
            </div>
        </div>
        <div class="report-stat-card">
            <div class="stat-icon">
                <i class="fas fa-handshake"></i>
            </div>
            <div class="stat-content">
                <h3><?php echo number_format($total_offers); ?></h3>
                <p><?php _e('Offers', 'nidfil-connect'); ?></p>
            </div>
        </div>
        <div class="report-stat-card">
            <div class="stat-icon">
                <i class="fas fa-star"></i>
            </div>
            <div class="stat-content">
                <h3><?php echo number_format($total_reviews); ?></h3>
                <p><?php _e('Reviews', 'nidfil-connect'); ?></p>
            </div>
        </div>
        <div class="report-stat-card">
            <div class="stat-icon">
                <i class="fas fa-comments"></i>
            </div>
            <div class="stat-content">
                <h3><?php echo number_format($total_conversations); ?></h3>
                <p><?php _e('Conversations', 'nidfil-connect'); ?></p>
            </div>
        </div>
    </div>
    
    <!-- Report Categories -->
    <div class="nidfil-reports-grid">
        <!-- User Reports -->
        <div class="report-category-card">
            <div class="category-header">
                <i class="fas fa-users"></i>
                <h2><?php _e('User Reports', 'nidfil-connect'); ?></h2>
            </div>
            <div class="report-list">
                <div class="report-item">
                    <div class="report-info">
                        <h4><?php _e('All Users', 'nidfil-connect'); ?></h4>
                        <p><?php _e('Complete list of all registered users', 'nidfil-connect'); ?></p>
                    </div>
                    <div class="report-actions">
                        <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=nidfil-reports&download=1&report_type=all_users&format=csv'), 'nidfil_download_report'); ?>" class="button button-primary">
                            <i class="fas fa-download"></i> <?php _e('CSV', 'nidfil-connect'); ?>
                        </a>
                    </div>
                </div>
                <div class="report-item">
                    <div class="report-info">
                        <h4><?php _e('Clients Report', 'nidfil-connect'); ?></h4>
                        <p><?php _e('All client users with details', 'nidfil-connect'); ?></p>
                    </div>
                    <div class="report-actions">
                        <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=nidfil-reports&download=1&report_type=clients&format=csv'), 'nidfil_download_report'); ?>" class="button button-primary">
                            <i class="fas fa-download"></i> <?php _e('CSV', 'nidfil-connect'); ?>
                        </a>
                    </div>
                </div>
                <div class="report-item">
                    <div class="report-info">
                        <h4><?php _e('Specialists Report', 'nidfil-connect'); ?></h4>
                        <p><?php _e('All specialist users with details', 'nidfil-connect'); ?></p>
                    </div>
                    <div class="report-actions">
                        <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=nidfil-reports&download=1&report_type=specialists&format=csv'), 'nidfil_download_report'); ?>" class="button button-primary">
                            <i class="fas fa-download"></i> <?php _e('CSV', 'nidfil-connect'); ?>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Subscription Reports -->
        <div class="report-category-card">
            <div class="category-header">
                <i class="fas fa-credit-card"></i>
                <h2><?php _e('Subscription Reports', 'nidfil-connect'); ?></h2>
            </div>
            <div class="report-list">
                <div class="report-item">
                    <div class="report-info">
                        <h4><?php _e('All Subscriptions', 'nidfil-connect'); ?></h4>
                        <p><?php _e('Complete subscription history', 'nidfil-connect'); ?></p>
                    </div>
                    <div class="report-actions">
                        <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=nidfil-reports&download=1&report_type=subscriptions&format=csv'), 'nidfil_download_report'); ?>" class="button button-primary">
                            <i class="fas fa-download"></i> <?php _e('CSV', 'nidfil-connect'); ?>
                        </a>
                    </div>
                </div>
                <div class="report-item">
                    <div class="report-info">
                        <h4><?php _e('Payment History', 'nidfil-connect'); ?></h4>
                        <p><?php _e('All payment transactions', 'nidfil-connect'); ?></p>
                    </div>
                    <div class="report-actions">
                        <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=nidfil-reports&download=1&report_type=payments&format=csv'), 'nidfil_download_report'); ?>" class="button button-primary">
                            <i class="fas fa-download"></i> <?php _e('CSV', 'nidfil-connect'); ?>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Lead & Offer Reports -->
        <div class="report-category-card">
            <div class="category-header">
                <i class="fas fa-bullhorn"></i>
                <h2><?php _e('Lead & Offer Reports', 'nidfil-connect'); ?></h2>
            </div>
            <div class="report-list">
                <div class="report-item">
                    <div class="report-info">
                        <h4><?php _e('All Leads', 'nidfil-connect'); ?></h4>
                        <p><?php _e('Complete leads database', 'nidfil-connect'); ?></p>
                    </div>
                    <div class="report-actions">
                        <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=nidfil-reports&download=1&report_type=leads&format=csv'), 'nidfil_download_report'); ?>" class="button button-primary">
                            <i class="fas fa-download"></i> <?php _e('CSV', 'nidfil-connect'); ?>
                        </a>
                    </div>
                </div>
                <div class="report-item">
                    <div class="report-info">
                        <h4><?php _e('All Offers', 'nidfil-connect'); ?></h4>
                        <p><?php _e('Complete offers database', 'nidfil-connect'); ?></p>
                    </div>
                    <div class="report-actions">
                        <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=nidfil-reports&download=1&report_type=offers&format=csv'), 'nidfil_download_report'); ?>" class="button button-primary">
                            <i class="fas fa-download"></i> <?php _e('CSV', 'nidfil-connect'); ?>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Review Reports -->
        <div class="report-category-card">
            <div class="category-header">
                <i class="fas fa-star"></i>
                <h2><?php _e('Review Reports', 'nidfil-connect'); ?></h2>
            </div>
            <div class="report-list">
                <div class="report-item">
                    <div class="report-info">
                        <h4><?php _e('All Reviews', 'nidfil-connect'); ?></h4>
                        <p><?php _e('Complete reviews and ratings', 'nidfil-connect'); ?></p>
                    </div>
                    <div class="report-actions">
                        <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=nidfil-reports&download=1&report_type=reviews&format=csv'), 'nidfil_download_report'); ?>" class="button button-primary">
                            <i class="fas fa-download"></i> <?php _e('CSV', 'nidfil-connect'); ?>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Chat Reports -->
        <div class="report-category-card">
            <div class="category-header">
                <i class="fas fa-comments"></i>
                <h2><?php _e('Chat Reports', 'nidfil-connect'); ?></h2>
            </div>
            <div class="report-list">
                <div class="report-item">
                    <div class="report-info">
                        <h4><?php _e('Conversations', 'nidfil-connect'); ?></h4>
                        <p><?php _e('All chat conversations', 'nidfil-connect'); ?></p>
                    </div>
                    <div class="report-actions">
                        <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=nidfil-reports&download=1&report_type=conversations&format=csv'), 'nidfil_download_report'); ?>" class="button button-primary">
                            <i class="fas fa-download"></i> <?php _e('CSV', 'nidfil-connect'); ?>
                        </a>
                    </div>
                </div>
                <div class="report-item">
                    <div class="report-info">
                        <h4><?php _e('Messages', 'nidfil-connect'); ?></h4>
                        <p><?php _e('All chat messages', 'nidfil-connect'); ?></p>
                    </div>
                    <div class="report-actions">
                        <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=nidfil-reports&download=1&report_type=messages&format=csv'), 'nidfil_download_report'); ?>" class="button button-primary">
                            <i class="fas fa-download"></i> <?php _e('CSV', 'nidfil-connect'); ?>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Analytics Reports -->
        <div class="report-category-card">
            <div class="category-header">
                <i class="fas fa-chart-bar"></i>
                <h2><?php _e('Analytics Reports', 'nidfil-connect'); ?></h2>
            </div>
            <div class="report-list">
                <div class="report-item">
                    <div class="report-info">
                        <h4><?php _e('Platform Summary', 'nidfil-connect'); ?></h4>
                        <p><?php _e('Complete platform statistics', 'nidfil-connect'); ?></p>
                    </div>
                    <div class="report-actions">
                        <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=nidfil-reports&download=1&report_type=summary&format=csv'), 'nidfil_download_report'); ?>" class="button button-primary">
                            <i class="fas fa-download"></i> <?php _e('CSV', 'nidfil-connect'); ?>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
/**
 * Generate and download report
 */
function nidfil_generate_report($report_type, $format = 'csv') {
    global $wpdb;
    
    $filename = 'nidfil_' . $report_type . '_' . date('Y-m-d_His') . '.' . $format;
    
    header('Content-Type: text/' . $format);
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Pragma: no-cache');
    header('Expires: 0');
    
    $output = fopen('php://output', 'w');
    
    switch ($report_type) {
        case 'all_users':
            $users = $wpdb->get_results("SELECT u.ID, u.user_login, u.user_email, u.user_registered, um.meta_value as user_type FROM {$wpdb->prefix}users u LEFT JOIN {$wpdb->prefix}usermeta um ON u.ID = um.user_id AND um.meta_key = 'user_type'");
            fputcsv($output, array('ID', 'Username', 'Email', 'User Type', 'Registered Date'));
            foreach ($users as $user) {
                fputcsv($output, array($user->ID, $user->user_login, $user->user_email, $user->user_type ?: 'N/A', $user->user_registered));
            }
            break;
            
        case 'clients':
            $clients = $wpdb->get_results("SELECT u.ID, u.user_login, u.user_email, u.user_registered FROM {$wpdb->prefix}users u INNER JOIN {$wpdb->prefix}usermeta um ON u.ID = um.user_id WHERE um.meta_key = 'user_type' AND um.meta_value = 'client'");
            fputcsv($output, array('ID', 'Username', 'Email', 'Registered Date'));
            foreach ($clients as $client) {
                fputcsv($output, array($client->ID, $client->user_login, $client->user_email, $client->user_registered));
            }
            break;
            
        case 'specialists':
            $specialists = $wpdb->get_results("SELECT u.ID, u.user_login, u.user_email, u.user_registered FROM {$wpdb->prefix}users u INNER JOIN {$wpdb->prefix}usermeta um ON u.ID = um.user_id WHERE um.meta_key = 'user_type' AND um.meta_value = 'specialist'");
            fputcsv($output, array('ID', 'Username', 'Email', 'Registered Date'));
            foreach ($specialists as $specialist) {
                fputcsv($output, array($specialist->ID, $specialist->user_login, $specialist->user_email, $specialist->user_registered));
            }
            break;
            
        case 'subscriptions':
            $subscriptions = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}nidfil_subscriptions ORDER BY created_at DESC");
            fputcsv($output, array('ID', 'User ID', 'Plan Type', 'Status', 'Payment Amount', 'Payment Status', 'Start Date', 'End Date', 'Created At'));
            foreach ($subscriptions as $sub) {
                fputcsv($output, array($sub->id, $sub->user_id, $sub->plan_type, $sub->status, $sub->payment_amount, $sub->payment_status, $sub->start_date, $sub->end_date, $sub->created_at));
            }
            break;
            
        case 'payments':
            $payments = $wpdb->get_results("SELECT id, user_id, payment_amount, payment_status, payment_date, created_at FROM {$wpdb->prefix}nidfil_subscriptions WHERE payment_amount > 0 ORDER BY payment_date DESC");
            fputcsv($output, array('ID', 'User ID', 'Amount', 'Status', 'Payment Date', 'Created At'));
            foreach ($payments as $payment) {
                fputcsv($output, array($payment->id, $payment->user_id, $payment->payment_amount, $payment->payment_status, $payment->payment_date, $payment->created_at));
            }
            break;
            
        case 'leads':
            $leads = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}nidfil_leads ORDER BY created_at DESC");
            fputcsv($output, array('ID', 'Customer ID', 'Service Type', 'Location', 'Budget', 'Status', 'Created At'));
            foreach ($leads as $lead) {
                fputcsv($output, array($lead->id, $lead->customer_id, $lead->service_type, $lead->location, $lead->budget, $lead->status, $lead->created_at));
            }
            break;
            
        case 'offers':
            $offers = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}nidfil_offers ORDER BY created_at DESC");
            fputcsv($output, array('ID', 'Lead ID', 'Specialist ID', 'Offer Amount', 'Status', 'Created At'));
            foreach ($offers as $offer) {
                fputcsv($output, array($offer->id, $offer->lead_id, $offer->specialist_id, $offer->offer_amount, $offer->status, $offer->created_at));
            }
            break;
            
        case 'reviews':
            $reviews = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}nidfil_reviews ORDER BY created_at DESC");
            fputcsv($output, array('ID', 'Customer ID', 'Specialist ID', 'Rating', 'Review Text', 'Status', 'Created At'));
            foreach ($reviews as $review) {
                fputcsv($output, array($review->id, $review->customer_id, $review->specialist_id, $review->rating, $review->review_text, $review->status, $review->created_at));
            }
            break;
            
        case 'conversations':
            $conversations = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}nidfil_conversations ORDER BY created_at DESC");
            fputcsv($output, array('ID', 'Customer ID', 'Specialist ID', 'Created At'));
            foreach ($conversations as $conv) {
                fputcsv($output, array($conv->id, $conv->customer_id, $conv->specialist_id, $conv->created_at));
            }
            break;
            
        case 'messages':
            $messages = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}nidfil_messages ORDER BY created_at DESC");
            fputcsv($output, array('ID', 'Conversation ID', 'Sender ID', 'Message', 'Created At'));
            foreach ($messages as $msg) {
                fputcsv($output, array($msg->id, $msg->conversation_id, $msg->sender_id, $msg->message, $msg->created_at));
            }
            break;
            
        case 'summary':
            fputcsv($output, array('Report Type', 'Count', 'Date'));
            fputcsv($output, array('Total Users', $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}users"), date('Y-m-d H:i:s')));
            fputcsv($output, array('Total Subscriptions', $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}nidfil_subscriptions"), date('Y-m-d H:i:s')));
            fputcsv($output, array('Total Leads', $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}nidfil_leads"), date('Y-m-d H:i:s')));
            fputcsv($output, array('Total Offers', $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}nidfil_offers"), date('Y-m-d H:i:s')));
            fputcsv($output, array('Total Reviews', $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}nidfil_reviews"), date('Y-m-d H:i:s')));
            break;
    }
    
    fclose($output);
    exit;
}
?>

