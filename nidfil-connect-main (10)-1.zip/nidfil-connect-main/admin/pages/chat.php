<?php
/**
 * Chat Moderation Page
 * 
 * @package NIDFIL_Connect
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!current_user_can('manage_options')) {
    wp_die(__('You do not have sufficient permissions to access this page.'));
}

global $wpdb;
$conversations_table = $wpdb->prefix . 'nidfil_conversations';
$messages_table = $wpdb->prefix . 'nidfil_messages';

// Get conversations with message counts
$conversations = $wpdb->get_results("
    SELECT c.*,
           COUNT(m.id) as message_count,
           MAX(m.created_at) as last_message_time
    FROM $conversations_table c
    LEFT JOIN $messages_table m ON c.id = m.conversation_id
    GROUP BY c.id
    ORDER BY c.last_message_time DESC
    LIMIT 50
");

// Generate dummy data if needed
if (empty($conversations)) {
    $conversations = array(
        (object)array(
            'id' => 1,
            'customer_id' => 1,
            'specialist_id' => 3,
            'message_count' => 12,
            'last_message_time' => date('Y-m-d H:i:s', strtotime('-1 hour')),
            'created_at' => date('Y-m-d H:i:s', strtotime('-5 days'))
        ),
        (object)array(
            'id' => 2,
            'customer_id' => 2,
            'specialist_id' => 4,
            'message_count' => 8,
            'last_message_time' => date('Y-m-d H:i:s', strtotime('-3 hours')),
            'created_at' => date('Y-m-d H:i:s', strtotime('-3 days'))
        ),
    );
}
?>

<div class="wrap nidfil-admin-wrap nidfil-chat-page">
    <div class="nidfil-page-header">
        <div class="header-content">
            <h1 class="wp-heading-inline"><?php _e('Chat Moderation', 'nidfil-connect'); ?></h1>
            <p class="page-description"><?php _e('Monitor chat activity between customers and specialists. Default access is read-only to protect privacy.', 'nidfil-connect'); ?></p>
        </div>
    </div>
    
    <table class="wp-list-table widefat fixed striped nidfil-chat-table">
        <thead>
            <tr>
                <th class="column-name"><?php _e('Name', 'nidfil-connect'); ?></th>
                <th class="column-specialist"><?php _e('Specialist', 'nidfil-connect'); ?></th>
                <th class="column-messages"><?php _e('Messages', 'nidfil-connect'); ?></th>
                <th class="column-created"><?php _e('Created', 'nidfil-connect'); ?></th>
                <th class="column-actions"><?php _e('Actions', 'nidfil-connect'); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($conversations)): ?>
                <tr>
                    <td colspan="5"><?php _e('No conversations found.', 'nidfil-connect'); ?></td>
                </tr>
            <?php else: ?>
                <?php foreach ($conversations as $conversation): 
                    $customer = get_userdata($conversation->customer_id);
                    $specialist = get_userdata($conversation->specialist_id);
                    $customer_name = $customer ? $customer->display_name : __('Customer #' . $conversation->customer_id, 'nidfil-connect');
                    $specialist_name = $specialist ? $specialist->display_name : __('Specialist #' . $conversation->specialist_id, 'nidfil-connect');
                ?>
                    <tr>
                        <td class="column-name">
                            <div class="user-info">
                                <strong><?php echo esc_html($customer_name); ?></strong>
                                <br><small><?php echo $customer ? esc_html($customer->user_email) : ''; ?></small>
                            </div>
                        </td>
                        <td class="column-specialist">
                            <div class="user-info">
                                <strong><?php echo esc_html($specialist_name); ?></strong>
                                <br><small><?php echo $specialist ? esc_html($specialist->user_email) : ''; ?></small>
                            </div>
                        </td>
                        <td class="column-messages">
                            <span class="message-count-badge">
                                <i class="fas fa-comments"></i>
                                <strong><?php echo $conversation->message_count; ?></strong>
                            </span>
                        </td>
                        <td class="column-created">
                            <div class="date-info">
                                <i class="fas fa-calendar-alt"></i>
                                <?php echo date_i18n(get_option('date_format'), strtotime($conversation->created_at)); ?>
                            </div>
                        </td>
                        <td class="column-actions">
                            <button class="button button-small view-chat" data-conversation-id="<?php echo $conversation->id; ?>">
                                <i class="fas fa-eye"></i> <?php _e('View Chat', 'nidfil-connect'); ?>
                            </button>
                            <button class="button button-small warn-user" data-user-id="<?php echo $conversation->customer_id; ?>">
                                <i class="fas fa-exclamation-triangle"></i> <?php _e('Warn', 'nidfil-connect'); ?>
                            </button>
                            <button class="button button-small restrict-chat" data-conversation-id="<?php echo $conversation->id; ?>">
                                <i class="fas fa-ban"></i> <?php _e('Restrict', 'nidfil-connect'); ?>
                            </button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<!-- Chat View Modal -->
<div id="chatModal" class="nidfil-modal" style="display:none;">
    <div class="modal-content modal-large">
        <span class="close-modal">&times;</span>
        <div class="modal-header-section">
            <h2><?php _e('Chat Conversation', 'nidfil-connect'); ?></h2>
            <p class="modal-subtitle"><?php _e('Read-only view for moderation purposes', 'nidfil-connect'); ?></p>
        </div>
        <div id="chatMessages" class="chat-messages-readonly">
            <div class="chat-loading">
                <i class="fas fa-spinner fa-spin"></i>
                <p><?php _e('Loading messages...', 'nidfil-connect'); ?></p>
            </div>
        </div>
    </div>
</div>

