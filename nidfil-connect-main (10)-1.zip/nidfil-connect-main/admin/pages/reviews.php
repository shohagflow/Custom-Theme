<?php
/**
 * Review & Rating Control Page
 * 
 * @package NIDFIL_Connect
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!current_user_can('manage_options')) {
    wp_die(__('You do not have sufficient permissions to access this page.'));
}

global $wpdb;
$reviews_table = $wpdb->prefix . 'nidfil_reviews';

// Get reviews
$status_filter = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : 'all';

// Get all reviews for counting
$all_reviews = $wpdb->get_results("SELECT * FROM $reviews_table ORDER BY created_at DESC");

// Count reviews by status
$pending_count = count(array_filter($all_reviews, function($r) { return $r->status === 'pending'; }));
$approved_count = count(array_filter($all_reviews, function($r) { return $r->status === 'approved'; }));
$flagged_count = count(array_filter($all_reviews, function($r) { return $r->status === 'flagged'; }));
$rejected_count = count(array_filter($all_reviews, function($r) { return $r->status === 'rejected'; }));

// Filter reviews by status
$query = "SELECT * FROM $reviews_table";
if ($status_filter !== 'all') {
    $query .= $wpdb->prepare(" WHERE status = %s", $status_filter);
}
$query .= " ORDER BY created_at DESC";

$reviews = $wpdb->get_results($query);

// Generate dummy data if needed
if (empty($reviews)) {
    $reviews = array(
        (object)array(
            'id' => 1,
            'customer_id' => 1,
            'specialist_id' => 3,
            'rating' => 5,
            'review_text' => 'Excelente trabajo, muy profesional y puntual. Recomiendo totalmente.',
            'status' => 'approved',
            'is_verified' => 1,
            'reported_count' => 0,
            'created_at' => date('Y-m-d H:i:s', strtotime('-10 days'))
        ),
        (object)array(
            'id' => 2,
            'customer_id' => 2,
            'specialist_id' => 4,
            'rating' => 4,
            'review_text' => 'Buen servicio, aunque tardó un poco más de lo esperado.',
            'status' => 'pending',
            'is_verified' => 0,
            'reported_count' => 0,
            'created_at' => date('Y-m-d H:i:s', strtotime('-5 days'))
        ),
        (object)array(
            'id' => 3,
            'customer_id' => 1,
            'specialist_id' => 3,
            'rating' => 1,
            'review_text' => 'Muy mal servicio, no cumplió con lo acordado.',
            'status' => 'flagged',
            'is_verified' => 0,
            'reported_count' => 2,
            'created_at' => date('Y-m-d H:i:s', strtotime('-3 days'))
        ),
    );
}
?>

<div class="wrap nidfil-admin-wrap nidfil-reviews-page">
    <div class="nidfil-page-header">
        <div class="header-content">
            <h1 class="wp-heading-inline"><?php _e('Review & Rating Control', 'nidfil-connect'); ?></h1>
            <p class="page-description"><?php _e('Manage and moderate customer reviews and ratings', 'nidfil-connect'); ?></p>
        </div>
    </div>
    
    <!-- Modern Tab Navigation -->
    <div class="nidfil-tab-navigation">
        <a href="?page=nidfil-reviews&status=all" class="nidfil-tab <?php echo $status_filter === 'all' ? 'active' : ''; ?>">
            <span class="tab-label"><?php _e('All', 'nidfil-connect'); ?></span>
            <span class="tab-count"><?php echo count($all_reviews); ?></span>
        </a>
        <a href="?page=nidfil-reviews&status=pending" class="nidfil-tab <?php echo $status_filter === 'pending' ? 'active' : ''; ?>">
            <span class="tab-label"><?php _e('Pending', 'nidfil-connect'); ?></span>
            <span class="tab-count"><?php echo $pending_count; ?></span>
        </a>
        <a href="?page=nidfil-reviews&status=approved" class="nidfil-tab <?php echo $status_filter === 'approved' ? 'active' : ''; ?>">
            <span class="tab-label"><?php _e('Approved', 'nidfil-connect'); ?></span>
            <span class="tab-count"><?php echo $approved_count; ?></span>
        </a>
        <a href="?page=nidfil-reviews&status=flagged" class="nidfil-tab <?php echo $status_filter === 'flagged' ? 'active' : ''; ?>">
            <span class="tab-label"><?php _e('Flagged', 'nidfil-connect'); ?></span>
            <span class="tab-count"><?php echo $flagged_count; ?></span>
        </a>
        <a href="?page=nidfil-reviews&status=rejected" class="nidfil-tab <?php echo $status_filter === 'rejected' ? 'active' : ''; ?>">
            <span class="tab-label"><?php _e('Rejected', 'nidfil-connect'); ?></span>
            <span class="tab-count"><?php echo $rejected_count; ?></span>
        </a>
    </div>
    
    <table class="wp-list-table widefat fixed striped nidfil-reviews-table">
        <thead>
            <tr>
                <th class="column-name"><?php _e('Name', 'nidfil-connect'); ?></th>
                <th class="column-specialist"><?php _e('Specialist', 'nidfil-connect'); ?></th>
                <th class="column-rating"><?php _e('Rating', 'nidfil-connect'); ?></th>
                <th class="column-review"><?php _e('Review', 'nidfil-connect'); ?></th>
                <th class="column-status"><?php _e('Status', 'nidfil-connect'); ?></th>
                <th class="column-actions"><?php _e('Actions', 'nidfil-connect'); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($reviews)): ?>
                <tr>
                    <td colspan="6"><?php _e('No reviews found.', 'nidfil-connect'); ?></td>
                </tr>
            <?php else: ?>
                <?php foreach ($reviews as $review): 
                    $customer = get_userdata($review->customer_id);
                    $specialist = get_userdata($review->specialist_id);
                    $customer_name = $customer ? $customer->display_name : __('Customer #' . $review->customer_id, 'nidfil-connect');
                    $specialist_name = $specialist ? $specialist->display_name : __('Specialist #' . $review->specialist_id, 'nidfil-connect');
                ?>
                    <tr>
                        <td class="column-name"><?php echo esc_html($customer_name); ?></td>
                        <td class="column-specialist"><?php echo esc_html($specialist_name); ?></td>
                        <td class="column-rating">
                            <div class="rating-stars">
                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                    <span class="star <?php echo $i <= $review->rating ? 'filled' : ''; ?>">★</span>
                                <?php endfor; ?>
                                <strong><?php echo $review->rating; ?>/5</strong>
                            </div>
                        </td>
                        <td class="column-review">
                            <div class="review-text"><?php echo esc_html($review->review_text); ?></div>
                            <?php if ($review->reported_count > 0): ?>
                                <small class="reported-badge" style="color: #c62828; font-weight: 600;"><?php echo $review->reported_count; ?> <?php _e('reports', 'nidfil-connect'); ?></small>
                            <?php endif; ?>
                        </td>
                        <td class="column-status">
                            <span class="status-badge status-<?php echo esc_attr($review->status); ?>">
                                <?php echo ucfirst($review->status); ?>
                            </span>
                        </td>
                        <td class="column-actions">
                            <button class="button button-small approve-review" data-review-id="<?php echo $review->id; ?>" data-status="<?php echo esc_attr($review->status); ?>">
                                <?php echo $review->status === 'approved' ? __('Unapprove', 'nidfil-connect') : __('Approve', 'nidfil-connect'); ?>
                            </button>
                            <button class="button button-small reject-review" data-review-id="<?php echo $review->id; ?>" data-status="<?php echo esc_attr($review->status); ?>">
                                <?php echo $review->status === 'rejected' ? __('Restore', 'nidfil-connect') : __('Reject', 'nidfil-connect'); ?>
                            </button>
                            <button class="button button-small edit-review" data-review-id="<?php echo $review->id; ?>"><?php _e('Edit', 'nidfil-connect'); ?></button>
                            <button class="button button-small button-link-delete delete-review" data-review-id="<?php echo $review->id; ?>"><?php _e('Delete', 'nidfil-connect'); ?></button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>

