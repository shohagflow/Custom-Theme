<?php
/**
 * Payment Setup Page
 * 
 * @package NIDFIL_Connect
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!current_user_can('manage_options')) {
    wp_die(__('You do not have sufficient permissions to access this page.'));
}

// Handle payment settings save
if (isset($_POST['save_payment_settings']) && check_admin_referer('nidfil_payment_setup_save', 'nidfil_payment_setup_nonce')) {
    // Stripe Settings
    $stripe_enabled = isset($_POST['stripe_enabled']) ? 1 : 0;
    $stripe_test_mode = isset($_POST['stripe_test_mode']) ? 1 : 0;
    $stripe_test_publishable_key = sanitize_text_field($_POST['stripe_test_publishable_key'] ?? '');
    $stripe_test_secret_key = sanitize_text_field($_POST['stripe_test_secret_key'] ?? '');
    $stripe_live_publishable_key = sanitize_text_field($_POST['stripe_live_publishable_key'] ?? '');
    $stripe_live_secret_key = sanitize_text_field($_POST['stripe_live_secret_key'] ?? '');
    
    update_option('nidfil_stripe_enabled', $stripe_enabled);
    update_option('nidfil_stripe_test_mode', $stripe_test_mode);
    update_option('nidfil_stripe_test_publishable_key', $stripe_test_publishable_key);
    update_option('nidfil_stripe_test_secret_key', $stripe_test_secret_key);
    update_option('nidfil_stripe_live_publishable_key', $stripe_live_publishable_key);
    update_option('nidfil_stripe_live_secret_key', $stripe_live_secret_key);
    
    // PayPal Settings
    $paypal_enabled = isset($_POST['paypal_enabled']) ? 1 : 0;
    $paypal_test_mode = isset($_POST['paypal_test_mode']) ? 1 : 0;
    $paypal_client_id = sanitize_text_field($_POST['paypal_client_id'] ?? '');
    $paypal_secret = sanitize_text_field($_POST['paypal_secret'] ?? '');
    
    update_option('nidfil_paypal_enabled', $paypal_enabled);
    update_option('nidfil_paypal_test_mode', $paypal_test_mode);
    update_option('nidfil_paypal_client_id', $paypal_client_id);
    update_option('nidfil_paypal_secret', $paypal_secret);
    
    // Bank Transfer Settings
    $bank_transfer_enabled = isset($_POST['bank_transfer_enabled']) ? 1 : 0;
    $bank_name = sanitize_text_field($_POST['bank_name'] ?? '');
    $bank_account_number = sanitize_text_field($_POST['bank_account_number'] ?? '');
    $bank_routing_number = sanitize_text_field($_POST['bank_routing_number'] ?? '');
    $bank_iban = sanitize_text_field($_POST['bank_iban'] ?? '');
    $bank_swift = sanitize_text_field($_POST['bank_swift'] ?? '');
    $bank_instructions = wp_kses_post($_POST['bank_instructions'] ?? '');
    
    update_option('nidfil_bank_transfer_enabled', $bank_transfer_enabled);
    update_option('nidfil_bank_name', $bank_name);
    update_option('nidfil_bank_account_number', $bank_account_number);
    update_option('nidfil_bank_routing_number', $bank_routing_number);
    update_option('nidfil_bank_iban', $bank_iban);
    update_option('nidfil_bank_swift', $bank_swift);
    update_option('nidfil_bank_instructions', $bank_instructions);
    
    add_settings_error('nidfil_payment_setup', 'settings_saved', __('Payment settings saved successfully!', 'nidfil-connect'), 'success');
    settings_errors('nidfil_payment_setup');
}

// Get current settings
$stripe_enabled = get_option('nidfil_stripe_enabled', 0);
$stripe_test_mode = get_option('nidfil_stripe_test_mode', 1);
$stripe_test_publishable_key = get_option('nidfil_stripe_test_publishable_key', '');
$stripe_test_secret_key = get_option('nidfil_stripe_test_secret_key', '');
$stripe_live_publishable_key = get_option('nidfil_stripe_live_publishable_key', '');
$stripe_live_secret_key = get_option('nidfil_stripe_live_secret_key', '');

$paypal_enabled = get_option('nidfil_paypal_enabled', 0);
$paypal_test_mode = get_option('nidfil_paypal_test_mode', 1);
$paypal_client_id = get_option('nidfil_paypal_client_id', '');
$paypal_secret = get_option('nidfil_paypal_secret', '');

$bank_transfer_enabled = get_option('nidfil_bank_transfer_enabled', 0);
$bank_name = get_option('nidfil_bank_name', '');
$bank_account_number = get_option('nidfil_bank_account_number', '');
$bank_routing_number = get_option('nidfil_bank_routing_number', '');
$bank_iban = get_option('nidfil_bank_iban', '');
$bank_swift = get_option('nidfil_bank_swift', '');
$bank_instructions = get_option('nidfil_bank_instructions', '');

$enabled_gateways = 0;
if ($stripe_enabled) $enabled_gateways++;
if ($paypal_enabled) $enabled_gateways++;
if ($bank_transfer_enabled) $enabled_gateways++;
?>

<div class="wrap nidfil-admin-wrap nidfil-reports-page nidfil-payment-setup-page">
    <div class="nidfil-page-header">
        <div class="header-content">
            <h1 class="wp-heading-inline"><?php _e('Payment Setup', 'nidfil-connect'); ?></h1>
            <p class="page-description"><?php _e('Configure payment gateways and manage payment settings for subscriptions and transactions', 'nidfil-connect'); ?></p>
        </div>
    </div>

    <?php settings_errors('nidfil_payment_setup'); ?>

    <!-- Payment Status Cards -->
    <div class="nidfil-reports-stats">
        <div class="report-stat-card">
            <div class="stat-icon">
                <i class="fas fa-credit-card"></i>
            </div>
            <div class="stat-content">
                <h3><?php echo $enabled_gateways; ?></h3>
                <p><?php _e('Active Gateways', 'nidfil-connect'); ?></p>
            </div>
        </div>
        <div class="report-stat-card">
            <div class="stat-icon">
                <i class="fas fa-toggle-<?php echo ($stripe_enabled || $paypal_enabled || $bank_transfer_enabled) ? 'on' : 'off'; ?>"></i>
            </div>
            <div class="stat-content">
                <h3><?php echo ($stripe_enabled || $paypal_enabled || $bank_transfer_enabled) ? __('Active', 'nidfil-connect') : __('Inactive', 'nidfil-connect'); ?></h3>
                <p><?php _e('Payment Status', 'nidfil-connect'); ?></p>
            </div>
        </div>
    </div>

    <form method="post" action="" id="payment-setup-form">
        <?php wp_nonce_field('nidfil_payment_setup_save', 'nidfil_payment_setup_nonce'); ?>
        
        <div class="nidfil-reports-grid">
            <!-- Stripe Payment Gateway -->
            <div class="report-category-card">
                <div class="category-header">
                    <i class="fab fa-stripe"></i>
                    <h2><?php _e('Stripe', 'nidfil-connect'); ?></h2>
                    <label class="payment-gateway-toggle">
                        <input type="checkbox" name="stripe_enabled" value="1" <?php checked($stripe_enabled, 1); ?>>
                        <span class="toggle-slider"></span>
                    </label>
                </div>
                <div class="report-list">
                    <div class="report-item" style="flex-direction: column; align-items: flex-start; gap: 16px; padding: 20px;">
                        <div style="width: 100%;">
                            <label style="display: flex; align-items: center; gap: 8px; margin-bottom: 12px; font-weight: 600; color: #1a202c; font-size: 13px;">
                                <input type="checkbox" name="stripe_test_mode" value="1" <?php checked($stripe_test_mode, 1); ?> style="margin: 0;">
                                <?php _e('Enable Test Mode', 'nidfil-connect'); ?>
                            </label>
                            <p style="margin: 0 0 16px 0; font-size: 12px; color: #64748b; line-height: 1.4;">
                                <?php _e('Use test API keys to process test payments. Disable this when ready to accept real payments.', 'nidfil-connect'); ?>
                            </p>
                        </div>
                        
                        <div style="width: 100%;">
                            <label style="display: block; margin-bottom: 8px; font-weight: 600; color: #1a202c; font-size: 13px;">
                                <?php _e('Test Publishable Key', 'nidfil-connect'); ?>
                            </label>
                            <input 
                                type="text" 
                                name="stripe_test_publishable_key" 
                                value="<?php echo esc_attr($stripe_test_publishable_key); ?>" 
                                placeholder="pk_test_..." 
                                style="width: 100%; padding: 10px 12px; border: 1px solid #e5e9f2; border-radius: 6px; font-size: 13px; font-family: 'Courier New', monospace;"
                            >
                        </div>
                        
                        <div style="width: 100%;">
                            <label style="display: block; margin-bottom: 8px; font-weight: 600; color: #1a202c; font-size: 13px;">
                                <?php _e('Test Secret Key', 'nidfil-connect'); ?>
                            </label>
                            <input 
                                type="password" 
                                name="stripe_test_secret_key" 
                                value="<?php echo esc_attr($stripe_test_secret_key); ?>" 
                                placeholder="sk_test_..." 
                                style="width: 100%; padding: 10px 12px; border: 1px solid #e5e9f2; border-radius: 6px; font-size: 13px; font-family: 'Courier New', monospace;"
                            >
                        </div>
                        
                        <div style="width: 100%; margin-top: 8px; padding-top: 16px; border-top: 1px solid #e5e9f2;">
                            <label style="display: block; margin-bottom: 8px; font-weight: 600; color: #1a202c; font-size: 13px;">
                                <?php _e('Live Publishable Key', 'nidfil-connect'); ?>
                            </label>
                            <input 
                                type="text" 
                                name="stripe_live_publishable_key" 
                                value="<?php echo esc_attr($stripe_live_publishable_key); ?>" 
                                placeholder="pk_live_..." 
                                style="width: 100%; padding: 10px 12px; border: 1px solid #e5e9f2; border-radius: 6px; font-size: 13px; font-family: 'Courier New', monospace;"
                            >
                        </div>
                        
                        <div style="width: 100%;">
                            <label style="display: block; margin-bottom: 8px; font-weight: 600; color: #1a202c; font-size: 13px;">
                                <?php _e('Live Secret Key', 'nidfil-connect'); ?>
                            </label>
                            <input 
                                type="password" 
                                name="stripe_live_secret_key" 
                                value="<?php echo esc_attr($stripe_live_secret_key); ?>" 
                                placeholder="sk_live_..." 
                                style="width: 100%; padding: 10px 12px; border: 1px solid #e5e9f2; border-radius: 6px; font-size: 13px; font-family: 'Courier New', monospace;"
                            >
                        </div>
                        
                        <div style="width: 100%; margin-top: 12px; padding: 12px; background: #f8fafc; border-radius: 6px;">
                            <p style="margin: 0; font-size: 12px; color: #64748b; line-height: 1.5;">
                                <i class="fas fa-info-circle" style="color: #f97015; margin-right: 6px;"></i>
                                <?php _e('Get your API keys from', 'nidfil-connect'); ?>
                                <a href="https://dashboard.stripe.com/apikeys" target="_blank" rel="noopener" style="color: #f97015; text-decoration: none;">
                                    <?php _e('Stripe Dashboard', 'nidfil-connect'); ?>
                                    <i class="fas fa-external-link-alt" style="font-size: 10px; margin-left: 4px;"></i>
                                </a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- PayPal Payment Gateway -->
            <div class="report-category-card">
                <div class="category-header">
                    <i class="fab fa-paypal"></i>
                    <h2><?php _e('PayPal', 'nidfil-connect'); ?></h2>
                    <label class="payment-gateway-toggle">
                        <input type="checkbox" name="paypal_enabled" value="1" <?php checked($paypal_enabled, 1); ?>>
                        <span class="toggle-slider"></span>
                    </label>
                </div>
                <div class="report-list">
                    <div class="report-item" style="flex-direction: column; align-items: flex-start; gap: 16px; padding: 20px;">
                        <div style="width: 100%;">
                            <label style="display: flex; align-items: center; gap: 8px; margin-bottom: 12px; font-weight: 600; color: #1a202c; font-size: 13px;">
                                <input type="checkbox" name="paypal_test_mode" value="1" <?php checked($paypal_test_mode, 1); ?> style="margin: 0;">
                                <?php _e('Enable Sandbox Mode', 'nidfil-connect'); ?>
                            </label>
                            <p style="margin: 0 0 16px 0; font-size: 12px; color: #64748b; line-height: 1.4;">
                                <?php _e('Use PayPal sandbox for testing. Disable this when ready to accept real payments.', 'nidfil-connect'); ?>
                            </p>
                        </div>
                        
                        <div style="width: 100%;">
                            <label style="display: block; margin-bottom: 8px; font-weight: 600; color: #1a202c; font-size: 13px;">
                                <?php _e('Client ID', 'nidfil-connect'); ?>
                            </label>
                            <input 
                                type="text" 
                                name="paypal_client_id" 
                                value="<?php echo esc_attr($paypal_client_id); ?>" 
                                placeholder="Client ID" 
                                style="width: 100%; padding: 10px 12px; border: 1px solid #e5e9f2; border-radius: 6px; font-size: 13px; font-family: 'Courier New', monospace;"
                            >
                        </div>
                        
                        <div style="width: 100%;">
                            <label style="display: block; margin-bottom: 8px; font-weight: 600; color: #1a202c; font-size: 13px;">
                                <?php _e('Secret Key', 'nidfil-connect'); ?>
                            </label>
                            <input 
                                type="password" 
                                name="paypal_secret" 
                                value="<?php echo esc_attr($paypal_secret); ?>" 
                                placeholder="Secret Key" 
                                style="width: 100%; padding: 10px 12px; border: 1px solid #e5e9f2; border-radius: 6px; font-size: 13px; font-family: 'Courier New', monospace;"
                            >
                        </div>
                        
                        <div style="width: 100%; margin-top: 12px; padding: 12px; background: #f8fafc; border-radius: 6px;">
                            <p style="margin: 0; font-size: 12px; color: #64748b; line-height: 1.5;">
                                <i class="fas fa-info-circle" style="color: #f97015; margin-right: 6px;"></i>
                                <?php _e('Get your credentials from', 'nidfil-connect'); ?>
                                <a href="https://developer.paypal.com/dashboard/applications" target="_blank" rel="noopener" style="color: #f97015; text-decoration: none;">
                                    <?php _e('PayPal Developer', 'nidfil-connect'); ?>
                                    <i class="fas fa-external-link-alt" style="font-size: 10px; margin-left: 4px;"></i>
                                </a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Bank Transfer -->
            <div class="report-category-card">
                <div class="category-header">
                    <i class="fas fa-university"></i>
                    <h2><?php _e('Bank Transfer', 'nidfil-connect'); ?></h2>
                    <label class="payment-gateway-toggle">
                        <input type="checkbox" name="bank_transfer_enabled" value="1" <?php checked($bank_transfer_enabled, 1); ?>>
                        <span class="toggle-slider"></span>
                    </label>
                </div>
                <div class="report-list">
                    <div class="report-item" style="flex-direction: column; align-items: flex-start; gap: 16px; padding: 20px;">
                        <div style="width: 100%;">
                            <label style="display: block; margin-bottom: 8px; font-weight: 600; color: #1a202c; font-size: 13px;">
                                <?php _e('Bank Name', 'nidfil-connect'); ?>
                            </label>
                            <input 
                                type="text" 
                                name="bank_name" 
                                value="<?php echo esc_attr($bank_name); ?>" 
                                placeholder="<?php _e('Bank Name', 'nidfil-connect'); ?>" 
                                style="width: 100%; padding: 10px 12px; border: 1px solid #e5e9f2; border-radius: 6px; font-size: 13px;"
                            >
                        </div>
                        
                        <div style="width: 100%;">
                            <label style="display: block; margin-bottom: 8px; font-weight: 600; color: #1a202c; font-size: 13px;">
                                <?php _e('Account Number', 'nidfil-connect'); ?>
                            </label>
                            <input 
                                type="text" 
                                name="bank_account_number" 
                                value="<?php echo esc_attr($bank_account_number); ?>" 
                                placeholder="<?php _e('Account Number', 'nidfil-connect'); ?>" 
                                style="width: 100%; padding: 10px 12px; border: 1px solid #e5e9f2; border-radius: 6px; font-size: 13px; font-family: 'Courier New', monospace;"
                            >
                        </div>
                        
                        <div style="width: 100%;">
                            <label style="display: block; margin-bottom: 8px; font-weight: 600; color: #1a202c; font-size: 13px;">
                                <?php _e('Routing Number / Sort Code', 'nidfil-connect'); ?>
                            </label>
                            <input 
                                type="text" 
                                name="bank_routing_number" 
                                value="<?php echo esc_attr($bank_routing_number); ?>" 
                                placeholder="<?php _e('Routing Number', 'nidfil-connect'); ?>" 
                                style="width: 100%; padding: 10px 12px; border: 1px solid #e5e9f2; border-radius: 6px; font-size: 13px; font-family: 'Courier New', monospace;"
                            >
                        </div>
                        
                        <div style="width: 100%;">
                            <label style="display: block; margin-bottom: 8px; font-weight: 600; color: #1a202c; font-size: 13px;">
                                <?php _e('IBAN', 'nidfil-connect'); ?>
                            </label>
                            <input 
                                type="text" 
                                name="bank_iban" 
                                value="<?php echo esc_attr($bank_iban); ?>" 
                                placeholder="ES91 2100 0418 4502 0005 1332" 
                                style="width: 100%; padding: 10px 12px; border: 1px solid #e5e9f2; border-radius: 6px; font-size: 13px; font-family: 'Courier New', monospace;"
                            >
                        </div>
                        
                        <div style="width: 100%;">
                            <label style="display: block; margin-bottom: 8px; font-weight: 600; color: #1a202c; font-size: 13px;">
                                <?php _e('SWIFT / BIC Code', 'nidfil-connect'); ?>
                            </label>
                            <input 
                                type="text" 
                                name="bank_swift" 
                                value="<?php echo esc_attr($bank_swift); ?>" 
                                placeholder="SWIFT Code" 
                                style="width: 100%; padding: 10px 12px; border: 1px solid #e5e9f2; border-radius: 6px; font-size: 13px; font-family: 'Courier New', monospace;"
                            >
                        </div>
                        
                        <div style="width: 100%;">
                            <label style="display: block; margin-bottom: 8px; font-weight: 600; color: #1a202c; font-size: 13px;">
                                <?php _e('Payment Instructions', 'nidfil-connect'); ?>
                            </label>
                            <textarea 
                                name="bank_instructions" 
                                rows="4" 
                                placeholder="<?php _e('Enter payment instructions for customers...', 'nidfil-connect'); ?>"
                                style="width: 100%; padding: 10px 12px; border: 1px solid #e5e9f2; border-radius: 6px; font-size: 13px; resize: vertical;"
                            ><?php echo esc_textarea($bank_instructions); ?></textarea>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        
        <div style="margin-top: 24px; padding: 20px; background: #ffffff; border: 1px solid #e5e9f2; border-radius: 12px; box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);">
            <button type="submit" name="save_payment_settings" class="button button-primary button-large" style="padding: 12px 24px; font-size: 14px; font-weight: 600;">
                <i class="fas fa-save" style="margin-right: 8px;"></i>
                <?php _e('Save Payment Settings', 'nidfil-connect'); ?>
            </button>
        </div>
    </form>
</div>

<style>
.payment-gateway-toggle {
    position: relative;
    display: inline-block;
    width: 50px;
    height: 26px;
    margin-left: auto;
}

.payment-gateway-toggle input {
    opacity: 0;
    width: 0;
    height: 0;
}

.toggle-slider {
    position: absolute;
    cursor: pointer;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: #cbd5e1;
    transition: 0.3s;
    border-radius: 26px;
}

.toggle-slider:before {
    position: absolute;
    content: "";
    height: 20px;
    width: 20px;
    left: 3px;
    bottom: 3px;
    background-color: white;
    transition: 0.3s;
    border-radius: 50%;
}

.payment-gateway-toggle input:checked + .toggle-slider {
    background-color: #f97015;
}

.payment-gateway-toggle input:checked + .toggle-slider:before {
    transform: translateX(24px);
}

.payment-gateway-toggle:hover .toggle-slider {
    box-shadow: 0 0 0 3px rgba(249, 112, 21, 0.1);
}

.category-header {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 20px;
    padding-bottom: 16px;
    border-bottom: 2px solid #f1f5f9;
}

.category-header .payment-gateway-toggle {
    margin-left: auto;
}

.nidfil-payment-setup-page .report-category-card {
    position: relative;
}

.nidfil-payment-setup-page .report-category-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 3px;
    background: linear-gradient(90deg, #f97015 0%, #ff8c42 100%);
    border-radius: 12px 12px 0 0;
}
</style>

