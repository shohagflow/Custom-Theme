<?php
/**
 * User Management Page
 * 
 * @package NIDFIL_Connect
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!current_user_can('manage_options')) {
    wp_die(__('You do not have sufficient permissions to access this page.'));
}

// Handle actions
$action = isset($_GET['action']) ? sanitize_text_field($_GET['action']) : '';
$user_id = isset($_GET['user_id']) ? intval($_GET['user_id']) : 0;
$user_type_filter = isset($_GET['user_type']) ? sanitize_text_field($_GET['user_type']) : 'all';

// Get users
$args = array('number' => -1);
$all_users = get_users($args);

$clients = array();
$specialists = array();

foreach ($all_users as $user) {
    $type = get_user_meta($user->ID, 'user_type', true);
    if ($type === 'specialist') {
        $specialists[] = $user;
    } else {
        $clients[] = $user;
    }
}

// Generate dummy users if needed
if (empty($clients) && empty($specialists)) {
    // Create sample data for demo
    $clients = array(
        (object)array('ID' => 1, 'display_name' => 'Juan Pérez', 'user_email' => 'juan@example.com', 'user_registered' => date('Y-m-d H:i:s', strtotime('-30 days'))),
        (object)array('ID' => 2, 'display_name' => 'María García', 'user_email' => 'maria@example.com', 'user_registered' => date('Y-m-d H:i:s', strtotime('-15 days'))),
    );
    $specialists = array(
        (object)array('ID' => 3, 'display_name' => 'Carlos López', 'user_email' => 'carlos@example.com', 'user_registered' => date('Y-m-d H:i:s', strtotime('-20 days'))),
        (object)array('ID' => 4, 'display_name' => 'Ana Martínez', 'user_email' => 'ana@example.com', 'user_registered' => date('Y-m-d H:i:s', strtotime('-10 days'))),
    );
}

$display_users = ($user_type_filter === 'specialists') ? $specialists : (($user_type_filter === 'clients') ? $clients : array_merge($clients, $specialists));
?>

<div class="wrap nidfil-admin-wrap nidfil-users-page">
    <div class="nidfil-page-header">
        <div class="header-content">
            <h1 class="wp-heading-inline"><?php _e('User Management', 'nidfil-connect'); ?></h1>
            <p class="page-description"><?php _e('Manage and monitor all platform users', 'nidfil-connect'); ?></p>
        </div>
    </div>
    
    <!-- Modern Tab Navigation -->
    <div class="nidfil-tab-navigation">
        <a href="?page=nidfil-users&user_type=all" class="nidfil-tab <?php echo $user_type_filter === 'all' ? 'active' : ''; ?>">
            <span class="tab-label"><?php _e('All Users', 'nidfil-connect'); ?></span>
            <span class="tab-count"><?php echo count($display_users); ?></span>
        </a>
        <a href="?page=nidfil-users&user_type=clients" class="nidfil-tab <?php echo $user_type_filter === 'clients' ? 'active' : ''; ?>">
            <span class="tab-label"><?php _e('Clients', 'nidfil-connect'); ?></span>
            <span class="tab-count"><?php echo count($clients); ?></span>
        </a>
        <a href="?page=nidfil-users&user_type=specialists" class="nidfil-tab <?php echo $user_type_filter === 'specialists' ? 'active' : ''; ?>">
            <span class="tab-label"><?php _e('Specialists', 'nidfil-connect'); ?></span>
            <span class="tab-count"><?php echo count($specialists); ?></span>
        </a>
    </div>
    
    <table class="wp-list-table widefat fixed striped nidfil-users-table">
        <thead>
            <tr>
                <th class="column-name"><?php _e('Name', 'nidfil-connect'); ?></th>
                <th class="column-email"><?php _e('Email', 'nidfil-connect'); ?></th>
                <th class="column-status"><?php _e('Status', 'nidfil-connect'); ?></th>
                <th class="column-verified"><?php _e('Verified', 'nidfil-connect'); ?></th>
                <th class="column-registered"><?php _e('Registered', 'nidfil-connect'); ?></th>
                <th class="column-actions"><?php _e('Actions', 'nidfil-connect'); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($display_users)): ?>
                <tr>
                    <td colspan="6"><?php _e('No users found.', 'nidfil-connect'); ?></td>
                </tr>
            <?php else: ?>
                <?php foreach ($display_users as $user): 
                    $type = get_user_meta($user->ID, 'user_type', true);
                    $verified = get_user_meta($user->ID, 'verified', true);
                    $account_status = get_user_meta($user->ID, 'account_status', true) ?: 'active';
                ?>
                    <tr>
                        <td class="column-name">
                            <?php
                            // Get profile image
                            $profile_image = get_user_meta($user->ID, 'profile_image', true);
                            $profile_image_url = '';
                            if (!empty($profile_image)) {
                                if (is_numeric($profile_image)) {
                                    $profile_image_url = wp_get_attachment_image_url($profile_image, 'thumbnail');
                                    if (empty($profile_image_url)) {
                                        $profile_image_url = wp_get_attachment_image_url($profile_image, 'medium');
                                    }
                                } else {
                                    $profile_image_url = esc_url($profile_image);
                                }
                            }
                            if (empty($profile_image_url)) {
                                $profile_image_url = get_avatar_url($user->ID, array('size' => 40));
                            }
                            ?>
                            <div class="user-name-with-avatar">
                                <img src="<?php echo esc_url($profile_image_url); ?>" alt="<?php echo esc_attr($user->display_name); ?>" class="user-avatar-small">
                                <strong><?php echo esc_html($user->display_name); ?></strong>
                            </div>
                        </td>
                        <td class="column-email"><?php echo esc_html($user->user_email); ?></td>
                        <td class="column-status">
                            <span class="status-badge status-<?php echo esc_attr($account_status); ?>">
                                <?php echo ucfirst($account_status); ?>
                            </span>
                        </td>
                        <td class="column-verified">
                            <?php if ($type === 'specialist'): ?>
                                <span class="verified-badge verified-<?php echo $verified ? 'yes' : 'no'; ?>">
                                    <?php echo $verified ? __('Verified', 'nidfil-connect') : __('Unverified', 'nidfil-connect'); ?>
                                </span>
                            <?php else: ?>
                                <span class="verified-badge verified-na"><?php _e('N/A', 'nidfil-connect'); ?></span>
                            <?php endif; ?>
                        </td>
                        <td class="column-registered"><?php echo date_i18n(get_option('date_format'), strtotime($user->user_registered)); ?></td>
                        <td class="column-actions">
                            <button class="button button-small view-user-profile" data-user-id="<?php echo $user->ID; ?>" data-user-type="<?php echo esc_attr($type); ?>"><?php _e('View', 'nidfil-connect'); ?></button>
                            <?php if ($type === 'specialist'): ?>
                                <button class="button button-small verify-user" data-user-id="<?php echo $user->ID; ?>" data-verified="<?php echo $verified ? '1' : '0'; ?>">
                                    <?php echo $verified ? __('Unverify', 'nidfil-connect') : __('Verify', 'nidfil-connect'); ?>
                                </button>
                            <?php endif; ?>
                            <button class="button button-small suspend-user" data-user-id="<?php echo $user->ID; ?>" data-status="<?php echo esc_attr($account_status); ?>">
                                <?php echo $account_status === 'suspended' ? __('Activate', 'nidfil-connect') : __('Suspend', 'nidfil-connect'); ?>
                            </button>
                            <button class="button button-small button-link-delete delete-user" data-user-id="<?php echo $user->ID; ?>"><?php _e('Delete', 'nidfil-connect'); ?></button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<!-- User Profile Modal -->
<div id="userProfileModal" class="nidfil-modal" style="display:none;">
    <div class="modal-content modal-large">
        <span class="close-modal">&times;</span>
        <div class="modal-header-section">
            <h2 id="modalUserName"><?php _e('User Profile', 'nidfil-connect'); ?></h2>
        </div>
        <div id="userProfileContent" class="user-profile-content">
            <div class="profile-loading">
                <i class="fas fa-spinner fa-spin"></i>
                <p><?php _e('Loading user profile...', 'nidfil-connect'); ?></p>
            </div>
        </div>
    </div>
</div>

