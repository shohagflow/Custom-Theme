<?php
/**
 * Front Page Template
 *
 * @package NIDFIL_Connect
 */

get_header();
?>

<main id="main" class="site-main">
    <!-- Hero Section -->
    <section class="hero-section">
        <?php
        // Rotate hero headline every 2 days across 10 predefined titles
        $hero_titles = array(
            'Tu reforma está muy cerca.',
            'Tu reforma empieza con el especialista adecuado.',
            'Encuentra especialistas de confianza cerca de ti.',
            'Profesionales verificados para reformas sin sorpresas.',
            'El especialista adecuado, justo donde lo necesitas.',
            'Tu hogar en manos de especialistas de confianza.',
            'La reforma que imaginas empieza aquí.',
            'Conecta con especialistas cerca de ti.',
            'Reformar tu casa nunca fue tan sencillo.',
            'Más cerca, más fácil, más profesional.',
        );
        
        $days_since_epoch      = floor( time() / DAY_IN_SECONDS );
        $hero_cycle_index      = floor( $days_since_epoch / 2 ); // change every 2 days
        $hero_title_index      = $hero_cycle_index % count( $hero_titles );
        $current_hero_headline = $hero_titles[ $hero_title_index ];
        
        // Split headline into first 3 words (orange) and rest (black)
        $words = explode(' ', $current_hero_headline);
        $first_three_words = array_slice($words, 0, 3);
        $remaining_words = array_slice($words, 3);
        $first_part = implode(' ', $first_three_words);
        $second_part = implode(' ', $remaining_words);
        ?>
        <h1 class="hero-title">
            <span class="hero-title-highlight"><?php echo esc_html( $first_part ); ?></span><?php if ( !empty( $second_part ) ): ?><span class="hero-title-rest"> <?php echo esc_html( $second_part ); ?></span><?php endif; ?>
        </h1>
        <p class="hero-subtitle">
            <?php echo esc_html(nidfil_get_option('hero_subtitle', 'Encuentra a tu especialista de confianza')); ?>
        </p>

        <script>
        (function() {
            // Fallback hero service switcher bound directly on this page
            document.addEventListener('DOMContentLoaded', function () {
                var cards = document.querySelectorAll('.hero-service-card');
                var panels = document.querySelectorAll('.hero-service-panel');

                if (!cards.length || !panels.length) {
                    return;
                }

                // Hide all panels by default - they will only show when button is clicked
                panels.forEach(function(p) { p.classList.remove('is-active'); });
                
                // Hide all hero-service-details containers by default
                var detailsContainers = document.querySelectorAll('.hero-service-details');
                detailsContainers.forEach(function(container) {
                    container.classList.remove('has-active-panel');
                });

                // Reset nueva flow function
                function resetNuevaFlow() {
                    var dropdownBtn = document.getElementById('projectTypeDropdownBtn');
                    var dropdown = document.getElementById('projectTypeDropdown');
                    var projectTypeOptions = document.querySelectorAll('.project-type-option');
                    var locationInput = document.getElementById('nueva-location');
                    var titleSpan = dropdownBtn ? dropdownBtn.querySelector('.project-type-title') : null;

                    if (projectTypeOptions.length) {
                        projectTypeOptions.forEach(function(option) {
                            option.classList.remove('selected');
                            var check = option.querySelector('.project-type-check');
                            if (check) check.style.display = 'none';
                        });
                    }
                    if (dropdownBtn) {
                        dropdownBtn.classList.remove('active');
                        if (titleSpan) titleSpan.textContent = 'Tipo de proyecto';
                    }
                    if (dropdown) dropdown.classList.remove('show');
                    if (locationInput) locationInput.value = '';
                }

                cards.forEach(function(card) {
                    card.addEventListener('click', function (e) {
                        e.preventDefault();
                        e.stopPropagation();
                        
                        var target = this.getAttribute('data-target');
                        if (!target) {
                            console.error('No data-target attribute found on button');
                            return;
                        }

                        cards.forEach(function(c) { c.classList.remove('is-active'); });
                        panels.forEach(function(p) { p.classList.remove('is-active'); });
                        
                        // Hide all hero-service-details containers
                        var detailsContainers = document.querySelectorAll('.hero-service-details');
                        detailsContainers.forEach(function(container) {
                            container.classList.remove('has-active-panel');
                        });

                        this.classList.add('is-active');
                        // Activate both desktop and mobile panels
                        var targetPanels = document.querySelectorAll('.hero-service-panel--' + target);
                        if (targetPanels.length === 0) {
                            console.error('No panels found for target:', target);
                            return;
                        }
                        targetPanels.forEach(function(panel) {
                            panel.classList.add('is-active');
                        });
                        
                        // Show hero-service-details containers when panels are active
                        detailsContainers.forEach(function(container) {
                            var hasActivePanel = container.querySelector('.hero-service-panel.is-active');
                            if (hasActivePanel) {
                                container.classList.add('has-active-panel');
                            }
                        });
                        
                        var panel = document.querySelector('.hero-service-panel--' + target);
                        if (panel) {
                            
                            // Initialize dropdown flow when panel becomes active
                            if (target === 'nueva' || target === 'reforma') {
                                // Helper function to initialize dropdown
                                function initDropdown(dropdownBtnId, dropdownId, locationId, searchBtnId) {
                                    var dropdownBtn = document.getElementById(dropdownBtnId);
                                    var dropdown = document.getElementById(dropdownId);
                                    
                                    if (!dropdownBtn || !dropdown) return;
                                    
                                    // Remove existing listeners by cloning
                                    var newBtn = dropdownBtn.cloneNode(true);
                                    dropdownBtn.parentNode.replaceChild(newBtn, dropdownBtn);
                                    dropdownBtn = newBtn;
                                    
                                            dropdownBtn.addEventListener('click', function(e) {
                                                e.preventDefault();
                                                e.stopPropagation();
                                                
                                                var isActive = dropdownBtn.classList.contains('active');
                                                
                                                if (isActive) {
                                                    dropdownBtn.classList.remove('active');
                                                    dropdown.classList.remove('show');
                                                } else {
                                                    dropdownBtn.classList.add('active');
                                                    dropdown.classList.add('show');
                                                }
                                            });
                                            
                                            // Close dropdown when clicking outside
                                            document.addEventListener('click', function(e) {
                                                if (!dropdownBtn.contains(e.target) && !dropdown.contains(e.target)) {
                                                    dropdownBtn.classList.remove('active');
                                                    dropdown.classList.remove('show');
                                                }
                                            });
                                    
                                    // Project type selection
                                    var projectTypeOptions = dropdown.querySelectorAll('.project-type-option');
                                    projectTypeOptions.forEach(function(option) {
                                        option.addEventListener('click', function(e) {
                                            e.preventDefault();
                                            e.stopPropagation();
                                            
                                            projectTypeOptions.forEach(function(o) {
                                                o.classList.remove('selected');
                                                var check = o.querySelector('.project-type-check');
                                                if (check) check.style.display = 'none';
                                            });
                                            
                                            this.classList.add('selected');
                                            var check = this.querySelector('.project-type-check');
                                            if (check) check.style.display = 'block';
                                            
                                            var label = this.querySelector('.project-type-option-label').textContent;
                                            var titleSpan = dropdownBtn.querySelector('.project-type-title');
                                            if (titleSpan) {
                                                titleSpan.textContent = label;
                                            }
                                            
                                            dropdownBtn.classList.remove('active');
                                            dropdown.classList.remove('show');
                                        });
                                    });
                                    
                                    // Search button handler
                                    var searchBtn = document.getElementById(searchBtnId);
                                    var locationInput = document.getElementById(locationId);
                                    if (searchBtn && locationInput) {
                                        searchBtn.addEventListener('click', function(e) {
                                            e.preventDefault();
                                            var selectedOption = dropdown.querySelector('.project-type-option.selected');
                                            var projectType = selectedOption ? selectedOption.getAttribute('data-project-type') : null;
                                            var location = locationInput.value.trim();
                                            
                                            if (!projectType) {
                                                alert('Por favor, selecciona un tipo de proyecto.');
                                                return;
                                            }
                                            
                                            if (!location) {
                                                alert('Por favor, introduce una ubicación.');
                                                locationInput.focus();
                                                return;
                                            }
                                            
                                            // Perform search
                                            console.log('Searching for:', { projectType: projectType, location: location });
                                            // TODO: Implement actual search functionality
                                        });
                                    }
                                }
                                
                                // Small delay to ensure DOM is ready
                                setTimeout(function() {
                                    // Initialize desktop version
                        if (target === 'reforma') {
                                        initDropdown('reformaProjectTypeDropdownBtn', 'reformaProjectTypeDropdown', 'reforma-location', 'reformaSearchBtn');
                                        initDropdown('reformaProjectTypeDropdownBtnMobile', 'reformaProjectTypeDropdownMobile', 'reforma-location-mobile', 'reformaSearchBtnMobile');
                                    } else {
                                        initDropdown('projectTypeDropdownBtn', 'projectTypeDropdown', 'nueva-location', 'nuevaSearchBtn');
                                        initDropdown('projectTypeDropdownBtnMobile', 'projectTypeDropdownMobile', 'nueva-location-mobile', 'nuevaSearchBtnMobile');
                                    }
                                }, 100);
                            }
                        }
                        
                        // Reset flow when switching panels
                        if (target === 'reforma') {
                            var nuevaPanels = document.querySelectorAll('.hero-service-panel--nueva');
                            nuevaPanels.forEach(function(panel) {
                                panel.classList.remove('is-active');
                            });
                            resetNuevaFlow();
                        } else if (target === 'nueva') {
                            var reformaPanels = document.querySelectorAll('.hero-service-panel--reforma');
                            reformaPanels.forEach(function(panel) {
                                panel.classList.remove('is-active');
                            });
                            // Reset reforma flow (both desktop and mobile)
                            var reformaDropdownBtns = ['reformaProjectTypeDropdownBtn', 'reformaProjectTypeDropdownBtnMobile'];
                            var reformaDropdowns = ['reformaProjectTypeDropdown', 'reformaProjectTypeDropdownMobile'];
                            var reformaLocationInputs = ['reforma-location', 'reforma-location-mobile'];
                            
                            reformaDropdownBtns.forEach(function(btnId) {
                                var btn = document.getElementById(btnId);
                                if (btn) {
                                    btn.classList.remove('active');
                                    var titleSpan = btn.querySelector('.project-type-title');
                                    if (titleSpan) titleSpan.textContent = 'Selecciona un especialista';
                                }
                            });
                            
                            reformaDropdowns.forEach(function(dropdownId) {
                                var dropdown = document.getElementById(dropdownId);
                                if (dropdown) dropdown.classList.remove('show');
                            });
                            
                            reformaLocationInputs.forEach(function(inputId) {
                                var input = document.getElementById(inputId);
                                if (input) input.value = '';
                            });
                            
                            reformaPanels.forEach(function(panel) {
                                var options = panel.querySelectorAll('.project-type-option');
                                options.forEach(function(option) {
                                    option.classList.remove('selected');
                                    var check = option.querySelector('.project-type-check');
                                    if (check) check.style.display = 'none';
                                });
                            });
                        }
                    });
                });
            });
        })();
        </script>

        <?php
        // Rotate hero image automatically every 2 days between hero1.jpg ... hero10.jpg
        $cycle_index    = $hero_cycle_index ?? floor( $days_since_epoch / 2 );
        $hero_number    = ( $cycle_index % 10 ) + 1; // 1–10
        $hero_image_url = get_template_directory_uri() . '/assets/images/hero' . $hero_number . '.jpg';
        ?>
        
        <!-- Hero Service Switch Section -->
        <!-- Hero Service Details Section (Search Bars) - Desktop -->
        <div class="hero-service-details hero-service-details--desktop">
            <div class="hero-service-panel hero-service-panel--reforma">
                <div class="hero-search-bar-inline">
                    <!-- Project Type Dropdown -->
                    <div class="project-type-section">
                        <button class="project-type-dropdown-header" type="button" id="reformaProjectTypeDropdownBtn">
                            <span class="project-type-title">Selecciona un especialista</span>
                            <i class="fas fa-chevron-down project-type-arrow" aria-hidden="true"></i>
                        </button>
                        <div class="project-type-dropdown" id="reformaProjectTypeDropdown">
                            <button class="project-type-option" type="button" data-project-type="arquitecto">
                                <span class="project-type-option-label">Arquitecto / Topógrafo</span>
                                <i class="fas fa-check project-type-check" aria-hidden="true" style="display: none;"></i>
                            </button>
                            <button class="project-type-option" type="button" data-project-type="excavaciones">
                                <span class="project-type-option-label">Excavaciones y Cimentaciones</span>
                                <i class="fas fa-check project-type-check" aria-hidden="true" style="display: none;"></i>
                            </button>
                            <button class="project-type-option" type="button" data-project-type="estructuras">
                                <span class="project-type-option-label">Estructuras y Hormigón</span>
                                <i class="fas fa-check project-type-check" aria-hidden="true" style="display: none;"></i>
                            </button>
                            <button class="project-type-option" type="button" data-project-type="albanil">
                                <span class="project-type-option-label">Albañil</span>
                                <i class="fas fa-check project-type-check" aria-hidden="true" style="display: none;"></i>
                            </button>
                            <button class="project-type-option" type="button" data-project-type="pladur">
                                <span class="project-type-option-label">Pladur</span>
                                <i class="fas fa-check project-type-check" aria-hidden="true" style="display: none;"></i>
                            </button>
                            <button class="project-type-option" type="button" data-project-type="azulejos">
                                <span class="project-type-option-label">Azulejos y Solados</span>
                                <i class="fas fa-check project-type-check" aria-hidden="true" style="display: none;"></i>
                            </button>
                            <button class="project-type-option" type="button" data-project-type="pintor">
                                <span class="project-type-option-label">Pintor</span>
                                <i class="fas fa-check project-type-check" aria-hidden="true" style="display: none;"></i>
                            </button>
                            <button class="project-type-option" type="button" data-project-type="carpintero">
                                <span class="project-type-option-label">Carpintero</span>
                                <i class="fas fa-check project-type-check" aria-hidden="true" style="display: none;"></i>
                            </button>
                            <button class="project-type-option" type="button" data-project-type="fontanero">
                                <span class="project-type-option-label">Fontanero</span>
                                <i class="fas fa-check project-type-check" aria-hidden="true" style="display: none;"></i>
                            </button>
                            <button class="project-type-option" type="button" data-project-type="electricista">
                                <span class="project-type-option-label">Electricista</span>
                                <i class="fas fa-check project-type-check" aria-hidden="true" style="display: none;"></i>
                            </button>
                            <button class="project-type-option" type="button" data-project-type="aire-acondicionado">
                                <span class="project-type-option-label">Aire Acondicionado</span>
                                <i class="fas fa-check project-type-check" aria-hidden="true" style="display: none;"></i>
                            </button>
                            <button class="project-type-option" type="button" data-project-type="energia-solar">
                                <span class="project-type-option-label">Energía Solar</span>
                                <i class="fas fa-check project-type-check" aria-hidden="true" style="display: none;"></i>
                            </button>
                            <button class="project-type-option" type="button" data-project-type="carpinteria-aluminio">
                                <span class="project-type-option-label">Carpintería Aluminio/PVC</span>
                                <i class="fas fa-check project-type-check" aria-hidden="true" style="display: none;"></i>
                            </button>
                            <button class="project-type-option" type="button" data-project-type="jardineria">
                                <span class="project-type-option-label">Jardinería</span>
                                <i class="fas fa-check project-type-check" aria-hidden="true" style="display: none;"></i>
                            </button>
                            <button class="project-type-option" type="button" data-project-type="piscinas">
                                <span class="project-type-option-label">Piscinas</span>
                                <i class="fas fa-check project-type-check" aria-hidden="true" style="display: none;"></i>
                            </button>
                            <button class="project-type-option" type="button" data-project-type="interiorista">
                                <span class="project-type-option-label">Interiorista / Decorador</span>
                                <i class="fas fa-check project-type-check" aria-hidden="true" style="display: none;"></i>
                            </button>
                            <button class="project-type-option" type="button" data-project-type="limpieza">
                                <span class="project-type-option-label">Limpieza del Hogar y Post-obra</span>
                                <i class="fas fa-check project-type-check" aria-hidden="true" style="display: none;"></i>
                            </button>
                        </div>
                    </div>

                    <!-- Location Selection -->
                    <div class="nueva-location-section">
                        <div class="nueva-location-field">
                            <input type="text" name="reforma-location" id="reforma-location" placeholder="Introduce la ubicación" autocomplete="off">
                            <svg class="location-icon location-icon-right" width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M10 10C11.3807 10 12.5 8.88071 12.5 7.5C12.5 6.11929 11.3807 5 10 5C8.61929 5 7.5 6.11929 7.5 7.5C7.5 8.88071 8.61929 10 10 10Z" fill="#666666"></path>
                                <path d="M10 2C6.68629 2 4 4.68629 4 8C4 12.5 10 18 10 18C10 18 16 12.5 16 8C16 4.68629 13.3137 2 10 2ZM10 10.5C8.61929 10.5 7.5 9.38071 7.5 8C7.5 6.61929 8.61929 5.5 10 5.5C11.3807 5.5 12.5 6.61929 12.5 8C12.5 9.38071 11.3807 10.5 10 10.5Z" fill="#666666"></path>
                            </svg>
                        </div>
                    </div>

                    <!-- Search Companies Button -->
                    <div class="nueva-search-section">
                        <button type="button" class="nueva-search-btn" id="reformaSearchBtn">
                            <span>Buscar empresas</span>
                        </button>
                    </div>
                </div>
            </div>

            <div class="hero-service-panel hero-service-panel--nueva">
                <div class="hero-search-bar-inline">
                    <!-- Project Type Dropdown -->
                    <div class="project-type-section">
                        <button class="project-type-dropdown-header" type="button" id="projectTypeDropdownBtn">
                            <span class="project-type-title">Tipo de proyecto</span>
                            <i class="fas fa-chevron-down project-type-arrow" aria-hidden="true"></i>
                        </button>
                        <div class="project-type-dropdown" id="projectTypeDropdown">
                            <button class="project-type-option" type="button" data-project-type="single-family">
                                <div class="project-type-option-icon">
                                    <i class="fas fa-home" aria-hidden="true"></i>
                                </div>
                                <span class="project-type-option-label">Vivienda unifamiliar</span>
                                <i class="fas fa-check project-type-check" aria-hidden="true" style="display: none;"></i>
                            </button>
                            <button class="project-type-option" type="button" data-project-type="building">
                                <div class="project-type-option-icon">
                                    <i class="fas fa-building" aria-hidden="true"></i>
                                </div>
                                <span class="project-type-option-label">Edificio</span>
                                <i class="fas fa-check project-type-check" aria-hidden="true" style="display: none;"></i>
                            </button>
                            <button class="project-type-option" type="button" data-project-type="warehouse">
                                <div class="project-type-option-icon">
                                    <i class="fas fa-warehouse" aria-hidden="true"></i>
                                </div>
                                <span class="project-type-option-label">Nave / local</span>
                                <i class="fas fa-check project-type-check" aria-hidden="true" style="display: none;"></i>
                            </button>
                        </div>
                    </div>

                    <!-- Location Selection -->
                    <div class="nueva-location-section">
                        <div class="nueva-location-field">
                            <input type="text" name="nueva-location" id="nueva-location" placeholder="Introduce la ubicación" autocomplete="off">
                            <svg class="location-icon location-icon-right" width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M10 10C11.3807 10 12.5 8.88071 12.5 7.5C12.5 6.11929 11.3807 5 10 5C8.61929 5 7.5 6.11929 7.5 7.5C7.5 8.88071 8.61929 10 10 10Z" fill="#666666"></path>
                                <path d="M10 2C6.68629 2 4 4.68629 4 8C4 12.5 10 18 10 18C10 18 16 12.5 16 8C16 4.68629 13.3137 2 10 2ZM10 10.5C8.61929 10.5 7.5 9.38071 7.5 8C7.5 6.61929 8.61929 5.5 10 5.5C11.3807 5.5 12.5 6.61929 12.5 8C12.5 9.38071 11.3807 10.5 10 10.5Z" fill="#666666"></path>
                            </svg>
                        </div>
                    </div>

                    <!-- Search Companies Button -->
                    <div class="nueva-search-section">
                        <button type="button" class="nueva-search-btn" id="nuevaSearchBtn">
                            <span>Buscar empresas</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="hero-image-container">
            <img src="<?php echo esc_url( $hero_image_url ); ?>" alt="Profesional de la construcción trabajando en pared de ladrillo" class="hero-image">
        </div>
        
        <!-- Hero Service Details Section (Search Bars) - Mobile -->
        <div class="hero-service-details hero-service-details--mobile">
            <div class="hero-service-panel hero-service-panel--reforma">
                <div class="hero-search-bar-inline">
                    <!-- Project Type Dropdown -->
                    <div class="project-type-section">
                        <button class="project-type-dropdown-header" type="button" id="reformaProjectTypeDropdownBtnMobile">
                            <span class="project-type-title">Selecciona un especialista</span>
                            <i class="fas fa-chevron-down project-type-arrow" aria-hidden="true"></i>
                        </button>
                        <div class="project-type-dropdown" id="reformaProjectTypeDropdownMobile">
                            <button class="project-type-option" type="button" data-project-type="arquitecto">
                                <span class="project-type-option-label">Arquitecto / Topógrafo</span>
                                <i class="fas fa-check project-type-check" aria-hidden="true" style="display: none;"></i>
                            </button>
                            <button class="project-type-option" type="button" data-project-type="excavaciones">
                                <span class="project-type-option-label">Excavaciones y Cimentaciones</span>
                                <i class="fas fa-check project-type-check" aria-hidden="true" style="display: none;"></i>
                            </button>
                            <button class="project-type-option" type="button" data-project-type="estructuras">
                                <span class="project-type-option-label">Estructuras y Hormigón</span>
                                <i class="fas fa-check project-type-check" aria-hidden="true" style="display: none;"></i>
                            </button>
                            <button class="project-type-option" type="button" data-project-type="albanil">
                                <span class="project-type-option-label">Albañil</span>
                                <i class="fas fa-check project-type-check" aria-hidden="true" style="display: none;"></i>
                            </button>
                            <button class="project-type-option" type="button" data-project-type="pladur">
                                <span class="project-type-option-label">Pladur</span>
                                <i class="fas fa-check project-type-check" aria-hidden="true" style="display: none;"></i>
                            </button>
                            <button class="project-type-option" type="button" data-project-type="azulejos">
                                <span class="project-type-option-label">Azulejos y Solados</span>
                                <i class="fas fa-check project-type-check" aria-hidden="true" style="display: none;"></i>
                            </button>
                            <button class="project-type-option" type="button" data-project-type="pintor">
                                <span class="project-type-option-label">Pintor</span>
                                <i class="fas fa-check project-type-check" aria-hidden="true" style="display: none;"></i>
                            </button>
                            <button class="project-type-option" type="button" data-project-type="carpintero">
                                <span class="project-type-option-label">Carpintero</span>
                                <i class="fas fa-check project-type-check" aria-hidden="true" style="display: none;"></i>
                            </button>
                            <button class="project-type-option" type="button" data-project-type="fontanero">
                                <span class="project-type-option-label">Fontanero</span>
                                <i class="fas fa-check project-type-check" aria-hidden="true" style="display: none;"></i>
                            </button>
                            <button class="project-type-option" type="button" data-project-type="electricista">
                                <span class="project-type-option-label">Electricista</span>
                                <i class="fas fa-check project-type-check" aria-hidden="true" style="display: none;"></i>
                            </button>
                            <button class="project-type-option" type="button" data-project-type="aire-acondicionado">
                                <span class="project-type-option-label">Aire Acondicionado</span>
                                <i class="fas fa-check project-type-check" aria-hidden="true" style="display: none;"></i>
                            </button>
                            <button class="project-type-option" type="button" data-project-type="energia-solar">
                                <span class="project-type-option-label">Energía Solar</span>
                                <i class="fas fa-check project-type-check" aria-hidden="true" style="display: none;"></i>
                            </button>
                            <button class="project-type-option" type="button" data-project-type="carpinteria-aluminio">
                                <span class="project-type-option-label">Carpintería Aluminio/PVC</span>
                                <i class="fas fa-check project-type-check" aria-hidden="true" style="display: none;"></i>
                            </button>
                            <button class="project-type-option" type="button" data-project-type="jardineria">
                                <span class="project-type-option-label">Jardinería</span>
                                <i class="fas fa-check project-type-check" aria-hidden="true" style="display: none;"></i>
                            </button>
                            <button class="project-type-option" type="button" data-project-type="piscinas">
                                <span class="project-type-option-label">Piscinas</span>
                                <i class="fas fa-check project-type-check" aria-hidden="true" style="display: none;"></i>
                            </button>
                            <button class="project-type-option" type="button" data-project-type="interiorista">
                                <span class="project-type-option-label">Interiorista / Decorador</span>
                                <i class="fas fa-check project-type-check" aria-hidden="true" style="display: none;"></i>
                            </button>
                            <button class="project-type-option" type="button" data-project-type="limpieza">
                                <span class="project-type-option-label">Limpieza del Hogar y Post-obra</span>
                                <i class="fas fa-check project-type-check" aria-hidden="true" style="display: none;"></i>
                            </button>
                        </div>
                    </div>

                    <!-- Location Selection -->
                    <div class="nueva-location-section">
                        <div class="nueva-location-field">
                            <input type="text" name="reforma-location-mobile" id="reforma-location-mobile" placeholder="Introduce la ubicación" autocomplete="off">
                            <svg class="location-icon location-icon-right" width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M10 10C11.3807 10 12.5 8.88071 12.5 7.5C12.5 6.11929 11.3807 5 10 5C8.61929 5 7.5 6.11929 7.5 7.5C7.5 8.88071 8.61929 10 10 10Z" fill="#666666"></path>
                                <path d="M10 2C6.68629 2 4 4.68629 4 8C4 12.5 10 18 10 18C10 18 16 12.5 16 8C16 4.68629 13.3137 2 10 2ZM10 10.5C8.61929 10.5 7.5 9.38071 7.5 8C7.5 6.61929 8.61929 5.5 10 5.5C11.3807 5.5 12.5 6.61929 12.5 8C12.5 9.38071 11.3807 10.5 10 10.5Z" fill="#666666"></path>
                            </svg>
                        </div>
                    </div>

                    <!-- Search Companies Button -->
                    <div class="nueva-search-section">
                        <button type="button" class="nueva-search-btn" id="reformaSearchBtnMobile">
                            <span>Buscar empresas</span>
                        </button>
                    </div>
                </div>
            </div>

            <div class="hero-service-panel hero-service-panel--nueva">
                <div class="hero-search-bar-inline">
                    <!-- Project Type Dropdown -->
                    <div class="project-type-section">
                        <button class="project-type-dropdown-header" type="button" id="projectTypeDropdownBtnMobile">
                            <span class="project-type-title">Tipo de proyecto</span>
                            <i class="fas fa-chevron-down project-type-arrow" aria-hidden="true"></i>
                        </button>
                        <div class="project-type-dropdown" id="projectTypeDropdownMobile">
                            <button class="project-type-option" type="button" data-project-type="single-family">
                                <div class="project-type-option-icon">
                                    <i class="fas fa-home" aria-hidden="true"></i>
                                </div>
                                <span class="project-type-option-label">Vivienda unifamiliar</span>
                                <i class="fas fa-check project-type-check" aria-hidden="true" style="display: none;"></i>
                            </button>
                            <button class="project-type-option" type="button" data-project-type="building">
                                <div class="project-type-option-icon">
                                    <i class="fas fa-building" aria-hidden="true"></i>
                                </div>
                                <span class="project-type-option-label">Edificio</span>
                                <i class="fas fa-check project-type-check" aria-hidden="true" style="display: none;"></i>
                            </button>
                            <button class="project-type-option" type="button" data-project-type="warehouse">
                                <div class="project-type-option-icon">
                                    <i class="fas fa-warehouse" aria-hidden="true"></i>
                                </div>
                                <span class="project-type-option-label">Nave / local</span>
                                <i class="fas fa-check project-type-check" aria-hidden="true" style="display: none;"></i>
                            </button>
                        </div>
                    </div>

                    <!-- Location Selection -->
                    <div class="nueva-location-section">
                        <div class="nueva-location-field">
                            <input type="text" name="nueva-location-mobile" id="nueva-location-mobile" placeholder="Introduce la ubicación" autocomplete="off">
                            <svg class="location-icon location-icon-right" width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M10 10C11.3807 10 12.5 8.88071 12.5 7.5C12.5 6.11929 11.3807 5 10 5C8.61929 5 7.5 6.11929 7.5 7.5C7.5 8.88071 8.61929 10 10 10Z" fill="#666666"></path>
                                <path d="M10 2C6.68629 2 4 4.68629 4 8C4 12.5 10 18 10 18C10 18 16 12.5 16 8C16 4.68629 13.3137 2 10 2ZM10 10.5C8.61929 10.5 7.5 9.38071 7.5 8C7.5 6.61929 8.61929 5.5 10 5.5C11.3807 5.5 12.5 6.61929 12.5 8C12.5 9.38071 11.3807 10.5 10 10.5Z" fill="#666666"></path>
                            </svg>
                        </div>
                    </div>

                    <!-- Search Companies Button -->
                    <div class="nueva-search-section">
                        <button type="button" class="nueva-search-btn" id="nuevaSearchBtnMobile">
                            <span>Buscar empresas</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Search Section -->
        <div class="search-container">
            <form class="search-form" method="get" action="<?php echo esc_url(home_url('/')); ?>">
                <div class="search-field">
                    <select name="specialist" id="specialist">
                        <option value="">Selecciona un especialista</option>
                        <option value="arquitecto">Arquitecto / Topógrafo</option>
                        <option value="excavaciones">Excavaciones y Cimentaciones</option>
                        <option value="estructuras">Estructuras y Hormigón</option>
                        <option value="albanil">Albañil</option>
                        <option value="pladur">Pladur</option>
                        <option value="azulejos">Azulejos y Solados</option>
                        <option value="pintor">Pintor</option>
                        <option value="carpintero">Carpintero</option>
                        <option value="fontanero">Fontanero</option>
                        <option value="electricista">Electricista</option>
                        <option value="aire-acondicionado">Aire Acondicionado</option>
                        <option value="energia-solar">Energía Solar</option>
                        <option value="carpinteria-aluminio">Carpintería Aluminio/PVC</option>
                        <option value="jardineria">Jardinería</option>
                        <option value="piscinas">Piscinas</option>
                        <option value="interiorista">Interiorista / Decorador</option>
                        <option value="limpieza">Limpieza del Hogar y Post-obra</option>
                    </select>
                </div>
                
                <div class="search-field location-field">
                    <input type="text" name="location" id="location" placeholder="Introduce tu ubicación">
                    <svg class="location-icon" width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M10 10C11.3807 10 12.5 8.88071 12.5 7.5C12.5 6.11929 11.3807 5 10 5C8.61929 5 7.5 6.11929 7.5 7.5C7.5 8.88071 8.61929 10 10 10Z" fill="#666666"/>
                        <path d="M10 2C6.68629 2 4 4.68629 4 8C4 12.5 10 18 10 18C10 18 16 12.5 16 8C16 4.68629 13.3137 2 10 2ZM10 10.5C8.61929 10.5 7.5 9.38071 7.5 8C7.5 6.61929 8.61929 5.5 10 5.5C11.3807 5.5 12.5 6.61929 12.5 8C12.5 9.38071 11.3807 10.5 10 10.5Z" fill="#666666"/>
                    </svg>
                </div>
                
                <button type="submit" class="search-button">
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M9 2C5.68629 2 3 4.68629 3 8C3 11.3137 5.68629 14 9 14C10.2958 14 11.4957 13.5892 12.4765 12.8906L16.293 16.7071C16.6835 17.0976 17.3165 17.0976 17.707 16.7071C18.0976 16.3165 18.0976 15.6835 17.707 15.293L13.8906 11.4765C14.5892 10.4957 15 9.29584 15 8C15 4.68629 12.3137 2 9 2ZM9 4C11.2091 4 13 5.79086 13 8C13 10.2091 11.2091 12 9 12C6.79086 12 5 10.2091 5 8C5 5.79086 6.79086 4 9 4Z" fill="currentColor"/>
                    </svg>
                    Buscar
                </button>
            </form>
        </div>
        
        <!-- Specialists Content Section -->
            <div class="specialists-content">
                <!-- Map Container (Left Side) -->
                <div class="map-container">
                    <div class="map-placeholder">
                        <div class="map-pins">
                            <div class="map-pin-large">
                                <svg width="32" height="40" viewBox="0 0 24 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M12 0C5.37258 0 0 5.37258 0 12C0 18 12 32 12 32C12 32 24 18 24 12C24 5.37258 18.6274 0 12 0Z" fill="#f97015"/>
                                    <circle cx="12" cy="12" r="4" fill="white"/>
                                </svg>
                            </div>
                            <div class="map-pin-small" style="top: 25%; left: 35%;">
                                <svg width="24" height="30" viewBox="0 0 24 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M12 0C5.37258 0 0 5.37258 0 12C0 18 12 30 12 30C12 30 24 18 24 12C24 5.37258 18.6274 0 12 0Z" fill="#f97015"/>
                                </svg>
                            </div>
                            <div class="map-pin-small" style="top: 60%; left: 65%;">
                                <svg width="24" height="30" viewBox="0 0 24 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M12 0C5.37258 0 0 5.37258 0 12C0 18 12 30 12 30C12 30 24 18 24 12C24 5.37258 18.6274 0 12 0Z" fill="#f97015"/>
                                </svg>
                            </div>
                        </div>
                        <div class="map-text-content">
                            <p class="map-label">Mapa interactivo</p>
                            <p class="map-coming-soon">Próximamente con integración Mapbox</p>
                        </div>
                    </div>
                </div>
                
                <!-- Specialists List (Right Side) -->
                <div class="specialists-list">
                    <?php
                    // Get specialists with at least 20% profile completion
                    $specialists = nidfil_get_specialists(20, 20);
                    
                    if (empty($specialists)) {
                        echo '<div class="no-specialists">';
                        echo '<p>No hay especialistas disponibles en este momento.</p>';
                        echo '</div>';
                    } else {
                        foreach ($specialists as $specialist) {
                            $verified_badge = $specialist['verified'] ? '<span class="verified-badge">
                                        <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M10 3L4.5 8.5L2 6" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                        </svg>
                                        Verificado
                            </span>' : '';
                            
                            $avatar_html = '';
                            if (!empty($specialist['avatar_url']) && strpos($specialist['avatar_url'], 'gravatar.com') === false) {
                                $avatar_html = '<img src="' . esc_url($specialist['avatar_url']) . '" alt="' . esc_attr($specialist['name']) . '" class="specialist-avatar-img">';
                            } else {
                                $avatar_html = '<div class="specialist-avatar-placeholder">' . esc_html($specialist['avatar']) . '</div>';
                            }
                            
                            $services_html = '';
                            if (!empty($specialist['services']) && is_array($specialist['services'])) {
                                foreach (array_slice($specialist['services'], 0, 3) as $service) {
                                    $services_html .= '<div class="service-icon" title="' . esc_attr($service) . '">
                                <svg width="16" height="16" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M10 2L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 2Z" fill="#f97015"/>
                                </svg>
                                    </div>';
                                }
                            }
                            
                            $reviews_text = $specialist['reviews'] > 0 ? '(' . $specialist['reviews'] . ' opiniones)' : '(Sin opiniones aún)';
                            ?>
                            <div class="specialist-card" onclick="openSpecialistModal(this)" 
                                 data-name="<?php echo esc_attr($specialist['name']); ?>" 
                                 data-profession="<?php echo esc_attr($specialist['profession']); ?>" 
                                 data-rating="<?php echo esc_attr($specialist['rating']); ?>" 
                                 data-reviews="<?php echo esc_attr($specialist['reviews']); ?>" 
                                 data-location="<?php echo esc_attr($specialist['location']); ?>" 
                                 data-office-address="<?php echo esc_attr($specialist['office_address'] ?? ''); ?>" 
                                 data-distance="<?php echo esc_attr($specialist['distance']); ?>" 
                                 data-verified="<?php echo $specialist['verified'] ? 'true' : 'false'; ?>" 
                                 data-avatar="<?php echo esc_attr($specialist['avatar']); ?>" 
                                 data-avatar-url="<?php echo !empty($specialist['avatar_url']) && strpos($specialist['avatar_url'], 'gravatar.com') === false ? esc_url($specialist['avatar_url']) : ''; ?>" 
                                 data-specialist-id="<?php echo esc_attr($specialist['id']); ?>" 
                                 data-whatsapp="<?php echo esc_attr($specialist['whatsapp']); ?>" 
                                 data-phone="<?php echo esc_attr($specialist['phone']); ?>" 
                                 data-description="<?php echo esc_attr($specialist['description']); ?>">
                        <div class="specialist-avatar">
                                    <?php echo $avatar_html; ?>
                        </div>
                        <div class="specialist-details">
                            <div class="specialist-header">
                                <div class="specialist-name-row">
                                            <h3 class="specialist-name"><?php echo esc_html($specialist['name']); ?></h3>
                                            <?php echo $verified_badge; ?>
                                </div>
                                        <p class="specialist-category"><?php echo esc_html($specialist['profession']); ?></p>
                            </div>
                            <div class="specialist-rating">
                                <svg width="16" height="16" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="#FFD700"/>
                                </svg>
                                        <span class="rating-value"><?php echo esc_html($specialist['rating']); ?></span>
                                        <span class="reviews-count"><?php echo esc_html($reviews_text); ?></span>
                            </div>
                            <div class="specialist-location-row">
                                <div class="specialist-location">
                                    <svg width="14" height="14" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M8 8C9.10457 8 10 7.10457 10 6C10 4.89543 9.10457 4 8 4C6.89543 4 6 4.89543 6 6C6 7.10457 6.89543 8 8 8Z" fill="#666666"/>
                                        <path d="M8 0C3.58172 0 0 3.58172 0 8C0 12 8 16 8 16C8 16 16 12 16 8C16 3.58172 12.4183 0 8 0ZM8 9C6.34315 9 5 7.65685 5 6C5 4.34315 6.34315 3 8 3C9.65685 3 11 4.34315 11 6C11 7.65685 9.65685 9 8 9Z" fill="#666666"/>
                                    </svg>
                                    <span><?php 
                                        $display_location = '';
                                        if (!empty($specialist['office_address'])) {
                                            $display_location = esc_html($specialist['office_address']);
                                        } else {
                                            $display_location = 'Ingresa tu dirección de oficina';
                                        }
                                        echo $display_location;
                                    ?></span>
                                </div>
                                        <?php if ($specialist['distance'] > 0): ?>
                                        <span class="distance"><?php echo esc_html($specialist['distance']); ?> km</span>
                                        <?php endif; ?>
                            </div>
                                    <?php if (!empty($services_html)): ?>
                                    <div class="specialist-services" data-services='<?php echo esc_attr(json_encode($specialist['services'])); ?>'>
                                        <?php echo $services_html; ?>
                            </div>
                                    <?php endif; ?>
                            </div>
                            </div>
                            <?php
                        }
                    }
                    ?>
                    
                    <a href="#" class="view-more-link">
                        Ver más especialistas
                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M6 4L10 8L6 12" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </a>
            </div>
        </div>
    </section>
    
    <!-- Specialist Details Modal -->
    <div id="specialistModal" class="specialist-modal">
        <div class="modal-overlay" id="specialistModalOverlay"></div>
        <div class="modal-content">
            <button class="modal-close" id="specialistModalClose">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M18 6L6 18M6 6L18 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </button>
            
            <div class="modal-body">
                <div class="modal-header">
                    <div class="modal-avatar">
                        <img id="modalAvatarImg" src="https://i.pravatar.cc/120?img=1" alt="Specialist" class="modal-avatar-img">
                        <div class="avatar-placeholder-large" id="modalAvatar" style="display: none;">AG</div>
                    </div>
                    <div class="modal-header-info">
                        <div class="modal-name-row">
                            <h2 class="modal-name" id="modalName">Antonio García</h2>
                            <span class="verified-badge" id="modalVerified" style="display: none;">
                                <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M10 3L4.5 8.5L2 6" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                                Verificado
                            </span>
                        </div>
                        <p class="modal-profession" id="modalProfession">Electricista</p>
                        <div class="modal-rating" id="modalRating">
                            <svg width="18" height="18" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="#FFD700"/>
                            </svg>
                            <span class="rating-value">4.9</span>
                            <span class="reviews-count">(127 opiniones)</span>
                        </div>
                    </div>
                </div>
                
                <div class="modal-details">
                    <div class="detail-item">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M10 10C11.3807 10 12.5 8.88071 12.5 7.5C12.5 6.11929 11.3807 5 10 5C8.61929 5 7.5 6.11929 7.5 7.5C7.5 8.88071 8.61929 10 10 10Z" fill="#666666"/>
                            <path d="M10 2C6.68629 2 4 4.68629 4 8C4 12.5 10 18 10 18C10 18 16 12.5 16 8C16 4.68629 13.3137 2 10 2ZM10 10.5C8.61929 10.5 7.5 9.38071 7.5 8C7.5 6.61929 8.61929 5.5 10 5.5C11.3807 5.5 12.5 6.61929 12.5 8C12.5 9.38071 11.3807 10.5 10 10.5Z" fill="#666666"/>
                        </svg>
                        <div>
                            <span class="detail-label">Ubicación</span>
                            <span class="detail-value" id="modalLocation">Ubicación no especificada</span>
                        </div>
                    </div>
                    
                    <div class="detail-item">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M10 2C6.68629 2 4 4.68629 4 8C4 12.5 10 18 10 18C10 18 16 12.5 16 8C16 4.68629 13.3137 2 10 2Z" fill="#f97015"/>
                            <circle cx="10" cy="8" r="2" fill="white"/>
                        </svg>
                        <div>
                            <span class="detail-label">Distancia</span>
                            <span class="detail-value" id="modalDistance">1.2 km</span>
                        </div>
                    </div>
                    
                    <div class="detail-item">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M10 2C5.58172 2 2 5.58172 2 10C2 14.4183 5.58172 18 10 18C14.4183 18 18 14.4183 18 10C18 5.58172 14.4183 2 10 2ZM10 16C6.68629 16 4 13.3137 4 10C4 6.68629 6.68629 4 10 4C13.3137 4 16 6.68629 16 10C16 13.3137 13.3137 16 10 16Z" fill="#666666"/>
                            <path d="M10 5V10L14 12" stroke="#666666" stroke-width="2" stroke-linecap="round"/>
                        </svg>
                        <div>
                            <span class="detail-label">Tiempo de respuesta</span>
                            <span class="detail-value">24 horas</span>
                        </div>
                    </div>
                </div>
                
                <div class="modal-description">
                    <h3>Acerca de</h3>
                    <p id="modalDescription">Profesional con más de 10 años de experiencia en instalaciones eléctricas. Especializado en reformas y nuevas instalaciones. Trabajo garantizado y presupuestos sin compromiso.</p>
                </div>
                
                <div class="modal-services">
                    <h3>Servicios</h3>
                    <div class="modal-services-icons" id="modalServicesIcons">
                        <div class="service-icon-large" title="Instalaciones eléctricas">
                            <svg width="24" height="24" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M13 2L7 8H10L7 18L13 12H10L13 2Z" fill="#f97015"/>
                            </svg>
                            <span>Instalaciones eléctricas</span>
                        </div>
                        <div class="service-icon-large" title="Reparaciones">
                            <svg width="24" height="24" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M10 2L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 2Z" fill="#f97015"/>
                            </svg>
                            <span>Reparaciones</span>
                        </div>
                        <div class="service-icon-large" title="Iluminación">
                            <svg width="24" height="24" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <circle cx="10" cy="10" r="4" fill="#f97015"/>
                                <path d="M10 2V4M10 16V18M18 10H16M4 10H2M16.364 3.636L15.364 4.636M4.636 15.364L3.636 16.364M16.364 16.364L15.364 15.364M4.636 4.636L3.636 3.636" stroke="#f97015" stroke-width="1.5" stroke-linecap="round"/>
                            </svg>
                            <span>Iluminación</span>
                        </div>
                    </div>
                </div>
                
                <div class="modal-actions">
                    <button type="button" id="modalMessage" class="action-btn message-btn">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M21 15C21 15.5304 20.7893 16.0391 20.4142 16.4142C20.0391 16.7893 19.5304 17 19 17H7L3 21V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H19C19.5304 3 20.0391 3.21071 20.4142 3.58579C20.7893 3.96086 21 4.46957 21 5V15Z" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                        Enviar Mensaje
                    </button>
                    <a href="#" id="modalWhatsApp" target="_blank" class="action-btn whatsapp-btn">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z" fill="white"/>
                        </svg>
                        WhatsApp
                    </a>
                    <a href="#" id="modalCall" class="action-btn call-btn">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M20.01 15.38c-1.23 0-2.42-.2-3.53-.56-.35-.12-.74-.03-1.01.24l-1.57 1.97c-2.83-1.35-5.48-3.9-6.89-6.83l1.95-1.66c.27-.28.35-.67.24-1.02-.37-1.11-.56-2.3-.56-3.53 0-.54-.45-.99-.99-.99H4.19C3.65 3 3 3.24 3 3.99 3 13.28 10.73 21 20.01 21c.71 0 .99-.63.99-1.18v-3.45c0-.54-.45-.99-.99-.99z" fill="white"/>
                        </svg>
                        Llamar
                    </a>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Subscription Plans Section -->
    <?php
    // Get subscription plans from options
    $all_plans = get_option('nidfil_subscription_plans', array());
    if (is_string($all_plans)) {
        $all_plans = json_decode($all_plans, true);
    }
    if (!is_array($all_plans)) {
        $all_plans = array();
    }
    
    // Filter only active plans for frontend
    $frontend_plans = array();
    foreach ($all_plans as $plan) {
        $status = isset($plan['status']) ? $plan['status'] : 'active';
        if ($status === 'active') {
            $frontend_plans[] = $plan;
        }
    }
    
    // Initialize default plans if none exist
    if (empty($all_plans)) {
        $frontend_plans = array(
            array(
                'id' => 1,
                'name' => 'Free Plan',
                'price' => 0.00,
                'period' => 'month',
                'pro' => false,
                'items' => array('Basic profile', 'Limited leads', 'Standard support')
            ),
            array(
                'id' => 2,
                'name' => 'Basic Plan',
                'price' => 29.99,
                'period' => 'month',
                'pro' => false,
                'items' => array('Enhanced profile', 'More leads', 'Priority support', 'Analytics dashboard')
            ),
            array(
                'id' => 3,
                'name' => 'Pro Plan',
                'price' => 99.99,
                'period' => 'month',
                'pro' => true,
                'items' => array('Premium profile', 'Unlimited leads', '24/7 support', 'Advanced analytics', 'Premium badge', 'Featured listing')
            )
        );
        update_option('nidfil_subscription_plans', $frontend_plans);
        $frontend_plans = $frontend_plans; // Already set above
    }
    ?>
    <section class="subscription-plans-section">
        <div class="section-container">
            <h2 class="section-title">Planes de Suscripción</h2>
            <p class="section-subtitle">Elige el plan que mejor se adapte a tus necesidades</p>
            
            <div class="subscription-plans-grid">
                <?php foreach ($frontend_plans as $plan): 
                    $plan_items = is_array($plan['items']) ? $plan['items'] : (is_string($plan['items']) ? explode("\n", $plan['items']) : array());
                    $plan_period = isset($plan['period']) ? $plan['period'] : 'month';
                ?>
                <div class="subscription-plan-card <?php echo $plan['pro'] ? 'plan-pro' : ''; ?>">
                    <div class="plan-card-header">
                        <h3 class="plan-card-title"><?php echo esc_html($plan['name']); ?></h3>
                        <?php if ($plan['pro']): ?>
                            <span class="plan-pro-badge">PRO</span>
                        <?php endif; ?>
                    </div>
                    <div class="plan-card-price">
                        <span class="plan-price-amount">€<?php echo number_format($plan['price'], 2); ?></span>
                        <span class="plan-price-period"><?php echo esc_html($plan_period); ?></span>
                    </div>
                    <ul class="plan-card-features">
                        <?php 
                        // Get stored icon types for this plan
                        $plan_icon_types = get_option('nidfil_plan_feature_icons_' . $plan['id'], array());
                        
                        foreach ($plan_items as $item): 
                            $item = trim($item);
                            if (!empty($item)):
                                $item_key = md5($item); // Create unique key for each feature
                                // Get icon type (check, cross, or star) - default to check
                                $icon_type = isset($plan_icon_types[$item_key]) ? $plan_icon_types[$item_key] : 'check';
                                
                                // Determine icon class and color based on icon type
                                $icon_class = '';
                                $icon_color = '';
                                if ($icon_type === 'check') {
                                    $icon_class = 'fas fa-check';
                                    $icon_color = '#10b981';
                                } elseif ($icon_type === 'cross') {
                                    $icon_class = 'fas fa-times';
                                    $icon_color = '#ef4444';
                                } elseif ($icon_type === 'star') {
                                    $icon_class = 'fas fa-star';
                                    $icon_color = '#fbc02d';
                                } else {
                                    // Fallback to check
                                    $icon_class = 'fas fa-check';
                                    $icon_color = '#10b981';
                                }
                        ?>
                            <li class="plan-feature-item">
                                <i class="<?php echo esc_attr($icon_class); ?>" style="color: <?php echo esc_attr($icon_color); ?>;"></i>
                                <span><?php echo esc_html($item); ?></span>
                            </li>
                        <?php 
                            endif;
                        endforeach; ?>
                    </ul>
                    <div class="plan-card-actions">
                        <?php
                        // Ensure checkout page exists
                        $checkout_page_id = nidfil_create_checkout_page();
                        if (!$checkout_page_id) {
                            $checkout_page = get_page_by_path('checkout');
                            $checkout_page_id = $checkout_page ? $checkout_page->ID : 0;
                        }
                        
                        // Get checkout page URL
                        if ($checkout_page_id) {
                            $checkout_base_url = get_permalink($checkout_page_id);
                        } else {
                            $checkout_base_url = home_url('/checkout');
                        }
                        
                        // Get payment_enabled status from stored plans
                        $stored_plans = get_option('nidfil_subscription_plans', array());
                        if (is_string($stored_plans)) {
                            $stored_plans = json_decode($stored_plans, true);
                        }
                        
                        $plan_payment_enabled = true; // Default to enabled
                        foreach ($stored_plans as $stored_plan) {
                            if (isset($stored_plan['id']) && $stored_plan['id'] == $plan['id']) {
                                $plan_payment_enabled = !isset($stored_plan['payment_enabled']) || $stored_plan['payment_enabled'] !== false;
                                break;
                            }
                        }
                        
                        $checkout_url = add_query_arg(array(
                            'plan_id' => $plan['id'],
                            'plan_name' => urlencode($plan['name']),
                            'plan_price' => $plan['price'],
                            'plan_period' => urlencode($plan_period)
                        ), $checkout_base_url);
                        
                        // Determine button text based on payment status
                        $button_text = 'Seleccionar Plan';
                        if (!$plan_payment_enabled || $plan['price'] == 0) {
                            $button_text = 'Empezar Gratis';
                        }
                        ?>
                        <a href="<?php echo esc_url($checkout_url); ?>" class="plan-cta-button">
                            <?php echo esc_html($button_text); ?>
                        </a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    
    <!-- How It Works Section -->
    <section class="how-it-works-section">
        <div class="section-container">
            <h2 class="section-title">¿Cómo Funciona?</h2>
            <p class="section-subtitle">Encuentra y contrata especialistas en solo 3 pasos</p>
            
            <div class="steps-grid">
                <div class="step-card">
                    <div class="step-number">1</div>
                    <div class="step-icon">
                        <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M21 21L15 15M17 10C17 13.866 13.866 17 10 17C6.13401 17 3 13.866 3 10C3 6.13401 6.13401 3 10 3C13.866 3 17 6.13401 17 10Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </div>
                    <h3 class="step-title">Busca</h3>
                    <p class="step-description">Encuentra el especialista que necesitas según tu proyecto y ubicación</p>
                </div>
                
                <div class="step-card">
                    <div class="step-number">2</div>
                    <div class="step-icon">
                        <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M9 12L11 14L15 10M21 12C21 16.9706 16.9706 21 12 21C7.02944 21 3 16.9706 3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </div>
                    <h3 class="step-title">Compara</h3>
                    <p class="step-description">Revisa perfiles, valoraciones y presupuestos de diferentes especialistas</p>
                </div>
                
                <div class="step-card">
                    <div class="step-number">3</div>
                    <div class="step-icon">
                        <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M9 12L11 14L15 10M21 12C21 16.9706 16.9706 21 12 21C7.02944 21 3 16.9706 3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </div>
                    <h3 class="step-title">Contrata</h3>
                    <p class="step-description">Contacta directamente con el especialista y comienza tu proyecto</p>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Why Choose NIDFIL Section -->
    <section class="why-choose-section">
        <div class="section-container">
            <h2 class="section-title">¿Por qué elegir NIDFIL?</h2>
            <p class="section-subtitle">Conectamos propietarios con los mejores profesionales de la construcción y reforma</p>
            
            <div class="why-choose-grid">
                <div class="why-choose-card">
                    <div class="why-choose-image">
                        <img src="https://img.freepik.com/free-photo/tiler-working-renovation-apartment_23-2149278557.jpg?semt=ais_hybrid&w=740&q=80" alt="Profesionales verificados" class="why-choose-img">
                        <div class="why-choose-overlay">
                            <h3 class="why-choose-card-title">Profesionales verificados</h3>
                            <p class="why-choose-card-text">Todos nuestros especialistas pasan por un proceso de verificación para garantizar su experiencia.</p>
                        </div>
                    </div>
                </div>
                
                <div class="why-choose-card">
                    <div class="why-choose-image">
                        <img src="https://img.freepik.com/premium-photo/renovation-progress-construction-workers-transforming-apartment-hallway-with-natural-light_937679-66466.jpg?semt=ais_hybrid&w=740&q=80" alt="Presupuestos sin compromiso" class="why-choose-img">
                        <div class="why-choose-overlay">
                            <h3 class="why-choose-card-title">Presupuestos sin compromiso</h3>
                            <p class="why-choose-card-text">Recibe presupuestos claros y detallados antes de comenzar cualquier proyecto.</p>
                        </div>
                    </div>
                </div>
                
                <div class="why-choose-card">
                    <div class="why-choose-image">
                        <img src="https://img.freepik.com/free-photo/civil-engineer-construction-worker-architects-wearing-hardhats-safety-vests-are-working-together-construction-site-building-home-cooperation-teamwork-concept_640221-172.jpg?semt=ais_hybrid&w=740&q=80" alt="Resultados garantizados" class="why-choose-img">
                        <div class="why-choose-overlay">
                            <h3 class="why-choose-card-title">Resultados garantizados</h3>
                            <p class="why-choose-card-text">Transforma tu hogar con la tranquilidad de trabajar con los mejores del sector.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Testimonials Section -->
    <section class="testimonials-section">
        <div class="section-container">
            <h2 class="section-title">Lo Que Dicen Nuestros Clientes</h2>
            <p class="section-subtitle">Experiencias reales de quienes han confiado en nosotros</p>
            
            <div class="testimonials-grid">
                <div class="testimonial-card">
                    <div class="testimonial-rating">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="#f97015"/>
                        </svg>
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="#f97015"/>
                        </svg>
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="#f97015"/>
                        </svg>
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="#f97015"/>
                        </svg>
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="#f97015"/>
                        </svg>
                    </div>
                    <p class="testimonial-text">"Encontré al arquitecto perfecto para mi proyecto. El proceso fue muy sencillo y el resultado superó mis expectativas."</p>
                    <div class="testimonial-author">
                        <div class="author-avatar">M</div>
                        <div class="author-info">
                            <div class="author-name">María González</div>
                            <div class="author-location">Madrid</div>
                        </div>
                    </div>
                </div>
                
                <div class="testimonial-card">
                    <div class="testimonial-rating">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="#f97015"/>
                        </svg>
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="#f97015"/>
                        </svg>
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="#f97015"/>
                        </svg>
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="#f97015"/>
                        </svg>
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="#f97015"/>
                        </svg>
                    </div>
                    <p class="testimonial-text">"Excelente plataforma. Pude comparar varios presupuestos y elegir el que mejor se adaptaba a mi presupuesto."</p>
                    <div class="testimonial-author">
                        <div class="author-avatar">J</div>
                        <div class="author-info">
                            <div class="author-name">Juan Martínez</div>
                            <div class="author-location">Barcelona</div>
                        </div>
                    </div>
                </div>
                
                <div class="testimonial-card">
                    <div class="testimonial-rating">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="#f97015"/>
                        </svg>
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="#f97015"/>
                        </svg>
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="#f97015"/>
                        </svg>
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="#f97015"/>
                        </svg>
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="#f97015"/>
                        </svg>
                    </div>
                    <p class="testimonial-text">"Muy profesional y fácil de usar. Encontré un albañil excelente que terminó mi reforma a tiempo y con calidad."</p>
                    <div class="testimonial-author">
                        <div class="author-avatar">A</div>
                        <div class="author-info">
                            <div class="author-name">Ana Rodríguez</div>
                            <div class="author-location">Valencia</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- CTA for Professionals Section -->
    <section class="cta-professionals-section">
        <div class="section-container">
            <div class="cta-professionals-content">
                <h2 class="cta-professionals-title">¿Eres un profesional del sector?</h2>
                <p class="cta-professionals-subtitle">Únete a NIDFIL y conecta con clientes que buscan exactamente tus servicios. Aumenta tu visibilidad y haz crecer tu negocio.</p>
                <a href="#" class="btn btn-white btn-large">
                    Registrarme como Especialista
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M4 10H16M16 10L11 5M16 10L11 15" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                </a>
                
                <div class="cta-statistics">
                    <div class="stat-item">
                        <div class="stat-number">500+</div>
                        <div class="stat-label">Especialistas activos</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-number">10K+</div>
                        <div class="stat-label">Proyectos completados</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-number">4.8★</div>
                        <div class="stat-label">Valoración media</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-number">24h</div>
                        <div class="stat-label">Tiempo de respuesta</div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<script>
// Ensure specialist card clicks work - Direct implementation
(function() {
    function initSpecialistCardClicks() {
        const cards = document.querySelectorAll('.specialist-card');
        console.log('Initializing specialist cards:', cards.length);
        
        cards.forEach(function(card) {
            // Remove onclick attribute to prevent conflicts
            if (card.hasAttribute('onclick')) {
                card.removeAttribute('onclick');
            }
            
            // Remove any existing listeners by cloning
            const newCard = card.cloneNode(true);
            card.parentNode.replaceChild(newCard, card);
            
            // Add fresh click listener
            newCard.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                
                console.log('Card clicked, opening modal...');
                
                // Get data attributes
                const data = {
                    name: newCard.getAttribute('data-name') || '',
                    profession: newCard.getAttribute('data-profession') || '',
                    rating: newCard.getAttribute('data-rating') || '0',
                    reviews: newCard.getAttribute('data-reviews') || '0',
                    location: newCard.getAttribute('data-location') || '',
                    officeAddress: newCard.getAttribute('data-office-address') || '',
                    distance: newCard.getAttribute('data-distance') || '0',
                    verified: newCard.getAttribute('data-verified') === 'true',
                    avatar: newCard.getAttribute('data-avatar') || '',
                    whatsapp: newCard.getAttribute('data-whatsapp') || '',
                    phone: newCard.getAttribute('data-phone') || '',
                    description: newCard.getAttribute('data-description') || ''
                };
                
                // Get modal
                const modal = document.getElementById('specialistModal');
                if (!modal) {
                    console.error('Modal not found!');
                    return;
                }
                
                // Update modal content
                const modalAvatar = document.getElementById('modalAvatar');
                const modalAvatarImg = document.getElementById('modalAvatarImg');
                const modalName = document.getElementById('modalName');
                const modalProfession = document.getElementById('modalProfession');
                const modalRating = document.getElementById('modalRating');
                const modalLocation = document.getElementById('modalLocation');
                const modalDistance = document.getElementById('modalDistance');
                const modalDescription = document.getElementById('modalDescription');
                const verifiedBadge = document.getElementById('modalVerified');
                const whatsappBtn = document.getElementById('modalWhatsApp');
                const callBtn = document.getElementById('modalCall');
                
                // Update avatar - check if specialist has avatar URL
                const avatarUrl = newCard.getAttribute('data-avatar-url') || '';
                
                // Check if we have a valid avatar URL (not empty and not gravatar)
                if (avatarUrl && avatarUrl.trim() !== '' && avatarUrl.indexOf('gravatar.com') === -1) {
                    // Specialist has a custom profile image
                if (modalAvatarImg) {
                        modalAvatarImg.src = avatarUrl;
                    modalAvatarImg.alt = data.name;
                        modalAvatarImg.style.display = 'block';
                        modalAvatarImg.onerror = function() {
                            // If image fails to load, show placeholder
                            this.style.display = 'none';
                            if (modalAvatar) {
                                modalAvatar.textContent = data.avatar || data.name.substring(0, 2).toUpperCase();
                                modalAvatar.style.display = 'flex';
                            }
                        };
                    }
                    if (modalAvatar) {
                        modalAvatar.style.display = 'none';
                    }
                } else {
                    // No image available, show placeholder with initials
                    if (modalAvatar) {
                        modalAvatar.textContent = data.avatar || data.name.substring(0, 2).toUpperCase();
                        modalAvatar.style.display = 'flex';
                    }
                    if (modalAvatarImg) {
                        modalAvatarImg.style.display = 'none';
                    }
                }
                if (modalName) modalName.textContent = data.name;
                if (modalProfession) modalProfession.textContent = data.profession;
                if (modalRating) {
                    modalRating.innerHTML = `
                        <svg width="18" height="18" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M10 1L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 1Z" fill="#FFD700"/>
                        </svg>
                        <span class="rating-value">${data.rating}</span>
                        <span class="reviews-count">(${data.reviews} opiniones)</span>
                    `;
                }
                if (modalLocation) {
                    let locationText = '';
                    if (data.officeAddress && data.officeAddress.trim() !== '') {
                        // Show office address if available
                        locationText = data.officeAddress;
                    } else if (data.location && data.location.trim() !== '' && data.location !== 'Ubicación no especificada') {
                        // Fallback to location if office address not available
                        locationText = data.location;
                    } else {
                        // Default message
                        locationText = 'Ingresa tu dirección de oficina';
                    }
                    modalLocation.textContent = locationText;
                }
                if (modalDistance) modalDistance.textContent = data.distance + ' km';
                if (modalDescription) modalDescription.textContent = data.description;
                
                // Update service icons based on specialist data
                const modalServicesIcons = document.getElementById('modalServicesIcons');
                
                // Get services from card data attribute
                const servicesContainer = card.querySelector('.specialist-services');
                let services = [];
                
                if (servicesContainer && servicesContainer.hasAttribute('data-services')) {
                    try {
                        services = JSON.parse(servicesContainer.getAttribute('data-services'));
                    } catch (e) {
                        console.error('Error parsing services:', e);
                    }
                }
                
                if (modalServicesIcons) {
                    // Generate services HTML for icons
                    let servicesHTML = '';
                    if (services && services.length > 0) {
                        services.slice(0, 3).forEach(function(service) {
                            servicesHTML += `
                                <div class="service-icon-large" title="${service}">
                                    <svg width="24" height="24" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M10 2L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 2Z" fill="#f97015"/>
                                    </svg>
                                    <span>${service}</span>
                                </div>
                            `;
                        });
                    } else {
                        // Fallback: show profession-based services
                    const serviceIconsMap = {
                        'Electricista': `
                            <div class="service-icon-large" title="Instalaciones eléctricas">
                                <svg width="24" height="24" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M13 2L7 8H10L7 18L13 12H10L13 2Z" fill="#f97015"/>
                                </svg>
                                <span>Instalaciones eléctricas</span>
                            </div>
                            <div class="service-icon-large" title="Reparaciones">
                                <svg width="24" height="24" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M10 2L12.5 7H19L14 11L16.5 17L10 13L3.5 17L6 11L1 7H7.5L10 2Z" fill="#f97015"/>
                                </svg>
                                <span>Reparaciones</span>
                            </div>
                            <div class="service-icon-large" title="Iluminación">
                                <svg width="24" height="24" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <circle cx="10" cy="10" r="4" fill="#f97015"/>
                                    <path d="M10 2V4M10 16V18M18 10H16M4 10H2M16.364 3.636L15.364 4.636M4.636 15.364L3.636 16.364M16.364 16.364L15.364 15.364M4.636 4.636L3.636 3.636" stroke="#f97015" stroke-width="1.5" stroke-linecap="round"/>
                                </svg>
                                <span>Iluminación</span>
                            </div>
                        `,
                        'Pintora': `
                            <div class="service-icon-large" title="Pintura interior">
                                <svg width="24" height="24" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M10 2L12 6L10 10L8 6L10 2Z" fill="#f97015"/>
                                    <path d="M4 12L6 16L4 20L2 16L4 12Z" fill="#f97015"/>
                                    <path d="M16 12L18 16L16 20L14 16L16 12Z" fill="#f97015"/>
                                </svg>
                                <span>Pintura interior</span>
                            </div>
                            <div class="service-icon-large" title="Pintura exterior">
                                <svg width="24" height="24" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <rect x="4" y="6" width="12" height="10" rx="1" fill="#f97015"/>
                                    <path d="M6 6V4C6 3.44772 6.44772 3 7 3H13C13.5523 3 14 3.44772 14 4V6" stroke="#f97015" stroke-width="1.5"/>
                                </svg>
                                <span>Pintura exterior</span>
                            </div>
                            <div class="service-icon-large" title="Acabados">
                                <svg width="24" height="24" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M10 4L12 8L10 12L8 8L10 4Z" fill="#f97015"/>
                                    <circle cx="10" cy="14" r="2" fill="#f97015"/>
                                </svg>
                                <span>Acabados</span>
                            </div>
                        `,
                        'Fontanero': `
                            <div class="service-icon-large" title="Reparaciones urgentes">
                                <svg width="24" height="24" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M10 2C5.58172 2 2 5.58172 2 10C2 14.4183 5.58172 18 10 18C14.4183 18 18 14.4183 18 10C18 5.58172 14.4183 2 10 2Z" stroke="#f97015" stroke-width="1.5"/>
                                    <path d="M10 5V10L14 12" stroke="#f97015" stroke-width="1.5" stroke-linecap="round"/>
                                </svg>
                                <span>Reparaciones urgentes</span>
                            </div>
                            <div class="service-icon-large" title="Instalaciones">
                                <svg width="24" height="24" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M8 8H12V10H8V8Z" fill="#f97015"/>
                                    <path d="M10 4V6M10 14V16M16 10H14M6 10H4" stroke="#f97015" stroke-width="1.5" stroke-linecap="round"/>
                                    <circle cx="10" cy="10" r="3" stroke="#f97015" stroke-width="1.5"/>
                                </svg>
                                <span>Instalaciones</span>
                            </div>
                            <div class="service-icon-large" title="Mantenimiento">
                                <svg width="24" height="24" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M10 2L12 6L10 10L8 6L10 2Z" fill="#f97015"/>
                                    <path d="M4 12L6 16L4 20L2 16L4 12Z" fill="#f97015"/>
                                    <path d="M16 12L18 16L16 20L14 16L16 12Z" fill="#f97015"/>
                                </svg>
                                <span>Mantenimiento</span>
                            </div>
                        `,
                        'Interiorista': `
                            <div class="service-icon-large" title="Diseño de espacios">
                                <svg width="24" height="24" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <rect x="4" y="4" width="12" height="12" rx="1" stroke="#f97015" stroke-width="1.5"/>
                                    <path d="M4 8H16M8 4V16" stroke="#f97015" stroke-width="1.5"/>
                                </svg>
                                <span>Diseño de espacios</span>
                            </div>
                            <div class="service-icon-large" title="Decoración">
                                <svg width="24" height="24" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M10 2L12 6L10 10L8 6L10 2Z" fill="#f97015"/>
                                    <circle cx="10" cy="14" r="2" fill="#f97015"/>
                                </svg>
                                <span>Decoración</span>
                            </div>
                            <div class="service-icon-large" title="Consultoría">
                                <svg width="24" height="24" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <circle cx="10" cy="10" r="7" stroke="#f97015" stroke-width="1.5"/>
                                    <path d="M10 6V10L13 13" stroke="#f97015" stroke-width="1.5" stroke-linecap="round"/>
                                </svg>
                                <span>Consultoría</span>
                            </div>
                        `
                    };
                        servicesHTML = serviceIconsMap[data.profession] || serviceIconsMap['Electricista'] || '<p>No hay servicios especificados</p>';
                }
                    
                    modalServicesIcons.innerHTML = servicesHTML;
                }
                
                
                if (verifiedBadge) {
                    verifiedBadge.style.display = data.verified ? 'inline-flex' : 'none';
                }
                
                if (whatsappBtn && data.whatsapp) {
                    whatsappBtn.href = `https://wa.me/${data.whatsapp}?text=Hola%20${encodeURIComponent(data.name.split(' ')[0])},%20me%20interesa%20tu%20servicio%20de%20${encodeURIComponent(data.profession.toLowerCase())}`;
                }
                if (callBtn && data.phone) {
                    callBtn.href = `tel:${data.phone}`;
                }
                
                // Handle message button
                const messageBtn = document.getElementById('modalMessage');
                if (messageBtn && data.specialistId) {
                    const currentUserId = window.nidfilAjax && window.nidfilAjax.current_user_id;
                    const isNotSelf = !currentUserId || parseInt(currentUserId) !== parseInt(data.specialistId);
                    
                    if (isNotSelf) {
                        messageBtn.style.display = 'flex';
                        messageBtn.setAttribute('data-specialist-id', data.specialistId);
                        messageBtn.disabled = false;
                        
                        // Remove existing handlers and attach fresh one
                        const newMessageBtn = messageBtn.cloneNode(true);
                        messageBtn.parentNode.replaceChild(newMessageBtn, messageBtn);
                        
                        newMessageBtn.addEventListener('click', function(e) {
                            e.preventDefault();
                            e.stopPropagation();
                            
                            if (this.disabled) return;
                            
                            const specialistId = this.getAttribute('data-specialist-id');
                            
                            if (!specialistId) {
                                alert('Error: No se pudo identificar al especialista.');
                                return;
                            }
                            
                            if (!window.nidfilAjax) {
                                alert('Error: Sistema de mensajería no disponible.');
                                return;
                            }
                            
                            const isLoggedIn = window.nidfilAjax.is_user_logged_in;
                            
                            if (!isLoggedIn) {
                                const specialistModal = document.getElementById('specialistModal');
                                if (specialistModal) {
                                    specialistModal.classList.remove('modal-active');
                                    document.body.style.overflow = '';
                                }
                                
                                if (typeof openClienteModal === 'function') {
                                    openClienteModal();
                                    setTimeout(function() {
                                        if (typeof switchFormTab === 'function') {
                                            switchFormTab('register');
                                        }
                                    }, 100);
                                } else {
                                    alert('Por favor, inicia sesión o regístrate para enviar mensajes.');
                                }
                                return;
                            }
                            
                            this.disabled = true;
                            const originalHTML = this.innerHTML;
                            this.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M21 15C21 15.5304 20.7893 16.0391 20.4142 16.4142C20.0391 16.7893 19.5304 17 19 17H7L3 21V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H19C19.5304 3 20.0391 3.21071 20.4142 3.58579C20.7893 3.96086 21 4.46957 21 5V15Z" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg> Iniciando...';
                            
                            fetch(nidfilAjax.ajaxurl, {
                                method: 'POST',
                                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                                body: new URLSearchParams({
                                    action: 'nidfil_start_conversation',
                                    specialist_id: specialistId,
                                    nonce: nidfilAjax.nonce
                                })
                            })
                            .then(response => response.json())
                            .then(data => {
                                if (data.success) {
                                    const modal = document.getElementById('specialistModal');
                                    if (modal) {
                                        modal.classList.remove('modal-active');
                                        document.body.style.overflow = '';
                                    }
                                    
                                    let redirectUrl = '';
                                    if (data.data && data.data.redirect_url) {
                                        redirectUrl = data.data.redirect_url;
                                    } else if (nidfilAjax.dashboard_url) {
                                        redirectUrl = nidfilAjax.dashboard_url;
                                    } else {
                                        redirectUrl = '/client-profile/';
                                    }
                                    
                                    if (data.data && data.data.conversation_id) {
                                        redirectUrl += '#messagesSection?conversation_id=' + data.data.conversation_id;
                                    } else {
                                        redirectUrl += '#messagesSection';
                                    }
                                    
                                    window.location.href = redirectUrl;
                                } else {
                                    alert(data.data?.message || 'Error al iniciar la conversación.');
                                    newMessageBtn.disabled = false;
                                    newMessageBtn.innerHTML = originalHTML;
                                }
                            })
                            .catch(error => {
                                console.error('Error:', error);
                                alert('Error al iniciar la conversación. Por favor, intenta nuevamente.');
                                newMessageBtn.disabled = false;
                                newMessageBtn.innerHTML = originalHTML;
                            });
                        });
                    } else {
                        messageBtn.style.display = 'none';
                    }
                }
                
                // Show modal
                modal.classList.add('modal-active');
                document.body.style.overflow = 'hidden';
                
                console.log('Modal opened successfully');
            });
        });
    }
    
    // Close modal function
    function closeSpecialistModal() {
        const modal = document.getElementById('specialistModal');
        if (modal) {
            modal.classList.remove('modal-active');
            document.body.style.overflow = '';
            console.log('Modal closed');
        }
    }
    
    // Make close function globally accessible
    window.closeSpecialistModal = closeSpecialistModal;
    
    // Initialize close button and overlay listeners
    let closeButtonInitialized = false;
    function initModalCloseButtons() {
        if (closeButtonInitialized) return;
        
        const closeBtn = document.getElementById('specialistModalClose');
        const overlay = document.getElementById('specialistModalOverlay');
        
        if (closeBtn) {
            // Remove any existing listeners by cloning
            const newCloseBtn = closeBtn.cloneNode(true);
            closeBtn.parentNode.replaceChild(newCloseBtn, closeBtn);
            
            newCloseBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                console.log('Close button clicked');
                closeSpecialistModal();
            });
            console.log('Close button listener added');
        } else {
            console.error('Close button not found');
        }
        
        if (overlay) {
            // Remove any existing listeners by cloning
            const newOverlay = overlay.cloneNode(true);
            overlay.parentNode.replaceChild(newOverlay, overlay);
            
            newOverlay.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                console.log('Overlay clicked');
                closeSpecialistModal();
            });
            console.log('Overlay listener added');
        }
        
        // ESC key support (only add once)
        if (!window.escKeyListenerAdded) {
            document.addEventListener('keydown', function(e) {
                const modal = document.getElementById('specialistModal');
                if (e.key === 'Escape' && modal && modal.classList.contains('modal-active')) {
                    console.log('ESC key pressed');
                    closeSpecialistModal();
                }
            });
            window.escKeyListenerAdded = true;
        }
        
        closeButtonInitialized = true;
    }
    
    // Initialize when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function() {
            initSpecialistCardClicks();
            initModalCloseButtons();
        });
    } else {
        initSpecialistCardClicks();
        initModalCloseButtons();
    }
    
    // Also try after delays
    setTimeout(function() {
        initSpecialistCardClicks();
        initModalCloseButtons();
    }, 500);
    setTimeout(function() {
        initSpecialistCardClicks();
        initModalCloseButtons();
    }, 1000);
})();
</script>

<?php
get_footer();

