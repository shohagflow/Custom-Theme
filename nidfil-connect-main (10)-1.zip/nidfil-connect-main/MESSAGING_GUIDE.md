# Customer-Specialist Messaging System Guide

## How Customers and Specialists Can Chat

### Current Implementation
✅ **Messaging system is already built** with:
- Database tables for conversations and messages
- AJAX handlers for sending/receiving messages
- File upload support (images, documents)
- Real-time message polling
- Dashboard messaging UI for both customers and specialists

### How It Works Now

#### **For Customers:**
1. **Access Messages**: Login → Go to Dashboard → Click "Mensajes" section
2. **View Conversations**: See all conversations with specialists
3. **Start Chat**: Click on a conversation to view messages
4. **Send Messages**: Type message and click send, or attach files

#### **For Specialists:**
1. **Access Messages**: Login → Go to Dashboard → Click "Mensajes" section
2. **View Conversations**: See all conversations with customers
3. **Respond**: Click conversation and reply to customer messages
4. **Send Files**: Share images or documents with customers

### Recommended Improvements

#### **1. Add "Message" Button on Specialist Cards/Modal**
**Location**: Homepage specialist cards and specialist modal

**Implementation**:
- Add "Enviar Mensaje" button in specialist modal
- When clicked:
  - If customer is logged in → Create conversation → Redirect to dashboard messages
  - If not logged in → Show login modal → After login, create conversation → Redirect

**Code Needed**:
```javascript
// Add to specialist modal
<button id="modalMessage" class="action-btn message-btn">
    Enviar Mensaje
</button>

// JavaScript handler
document.getElementById('modalMessage').addEventListener('click', function() {
    const specialistId = this.getAttribute('data-specialist-id');
    startConversation(specialistId);
});
```

#### **2. Add Specialist ID to Cards**
**Current**: Cards have name, profession, etc. but no user ID
**Needed**: Add `data-specialist-id="123"` attribute to each specialist card

#### **3. Create "Start Conversation" Function**
**Backend (PHP)**:
```php
function nidfil_start_conversation() {
    // Check if logged in
    // Get customer ID and specialist ID
    // Create conversation using nidfil_get_or_create_conversation()
    // Return conversation ID
    // Redirect to dashboard messages with conversation ID
}
```

**Frontend (JavaScript)**:
```javascript
function startConversation(specialistId) {
    if (!isLoggedIn) {
        openClienteModal(); // Show login
        return;
    }
    
    // AJAX call to start conversation
    // Redirect to dashboard messages section
    window.location.href = dashboardUrl + '#messages&conversation=' + conversationId;
}
```

#### **4. Add Quick Message Button on Specialist Cards**
**Location**: Each specialist card on homepage

**Implementation**:
- Small "Message" icon button on each card
- Quick action without opening full modal
- Same flow as modal button

### Step-by-Step User Flow

#### **Scenario 1: Customer wants to message a specialist**

**Option A - From Homepage:**
1. Customer browses specialists on homepage
2. Clicks specialist card → Modal opens
3. Clicks "Enviar Mensaje" button
4. If logged in → Redirected to dashboard messages with conversation open
5. If not logged in → Login modal → After login → Conversation created → Redirected

**Option B - From Dashboard:**
1. Customer logs in → Goes to dashboard
2. Clicks "Mensajes" section
3. Clicks "Nueva Conversación" button
4. Selects specialist from list
5. Conversation created → Chat opens

#### **Scenario 2: Specialist receives message**

1. Specialist logs in → Dashboard
2. Sees notification badge on "Mensajes" (e.g., "3")
3. Clicks "Mensajes" section
4. Sees new conversation with customer
5. Clicks conversation → Chat opens
6. Responds to customer

### Database Structure

**Conversations Table**: Links customer and specialist
- `customer_id` - Customer user ID
- `specialist_id` - Specialist user ID
- `last_message_time` - For sorting
- `customer_unread_count` - Unread messages for customer
- `specialist_unread_count` - Unread messages for specialist

**Messages Table**: Individual messages
- `conversation_id` - Links to conversation
- `sender_id` - Who sent the message
- `receiver_id` - Who receives the message
- `message_type` - 'text', 'image', or 'document'
- `message_text` - Text content
- `file_url` - For images/documents
- `is_read` - Read status

### Features Already Implemented

✅ **Real-time Updates**: Messages refresh every 5 seconds
✅ **File Sharing**: Images and documents can be shared
✅ **Unread Badges**: Shows unread message count
✅ **Message History**: All messages are saved
✅ **Responsive Design**: Works on mobile and desktop

### Next Steps to Complete

1. **Add specialist IDs to cards** (data-specialist-id attribute)
2. **Add "Message" button to modal** (already added in code)
3. **Create start conversation AJAX handler**
4. **Add JavaScript to handle message button clicks**
5. **Add CSS styling for message button**
6. **Test the complete flow**

### Technical Implementation Notes

- Use `nidfil_get_or_create_conversation()` function to create conversations
- Check user login status before allowing messages
- Redirect to dashboard with conversation ID in URL hash
- JavaScript can read hash and auto-open conversation
- Use existing AJAX endpoints for all messaging operations

