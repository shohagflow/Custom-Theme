<?php
/**
 * 404 — plain HTML (no client framework).
 *
 * @package Batsheva
 */

get_header();
?>
<main id="primary" class="site-main" role="main">
	<div class="min-h-screen bg-background batsheva-simple-page batsheva-404">
		<div class="batsheva-container">
			<h1 class="batsheva-simple-page__title"><?php esc_html_e('Page not found', 'batsheva'); ?></h1>
			<p class="batsheva-simple-page__empty"><?php esc_html_e('The page you are looking for does not exist or was moved.', 'batsheva'); ?></p>
			<p><a class="batsheva-404__link" href="<?php echo esc_url(home_url('/')); ?>"><?php esc_html_e('Back to home', 'batsheva'); ?></a></p>
		</div>
	</div>
</main>
<?php
get_footer();
