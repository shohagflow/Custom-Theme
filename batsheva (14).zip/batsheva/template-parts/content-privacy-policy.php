<?php
/**
 * Privacy Policy page layout (hero band + article).
 *
 * @package Batsheva
 */

defined('ABSPATH') || exit;

while (have_posts()) :
	the_post();
	?>
<div class="min-h-screen bg-background batsheva-legal-page">
	<div class="batsheva-legal-page__hero">
		<div class="batsheva-container">
			<p class="batsheva-legal-page__eyebrow"><?php esc_html_e('Legal', 'batsheva'); ?></p>
			<h1 class="batsheva-legal-page__title"><?php echo esc_html(get_the_title()); ?></h1>
			<p class="batsheva-legal-page__meta">
				<?php
				printf(
					/* translators: %s: last modified date */
					esc_html__('Last updated: %s', 'batsheva'),
					esc_html(get_the_modified_date(get_option('date_format')))
				);
				?>
			</p>
		</div>
	</div>
	<div class="batsheva-container batsheva-legal-page__wrap">
		<article <?php post_class('batsheva-legal-page__article'); ?>>
			<div class="batsheva-legal-page__content entry-content">
				<?php the_content(); ?>
			</div>
		</article>
	</div>
</div>
	<?php
endwhile;
