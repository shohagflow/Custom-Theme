<?php
/**
 * Single post (plain HTML + theme CSS).
 *
 * @package Batsheva
 */

defined('ABSPATH') || exit;

while (have_posts()) :
	the_post();
	?>
<div class="min-h-screen bg-background batsheva-simple-page batsheva-single">
	<div class="batsheva-container batsheva-simple-page__articlewrap">
		<article <?php post_class('batsheva-page-article'); ?>>
			<header class="batsheva-page-article__head">
				<h1 class="batsheva-simple-page__title"><?php echo esc_html(get_the_title()); ?></h1>
				<time class="batsheva-archive-card__time" datetime="<?php echo esc_attr(get_the_date(DATE_W3C)); ?>"><?php echo esc_html(get_the_date()); ?></time>
			</header>
			<div class="batsheva-page-article__content entry-content">
				<?php the_content(); ?>
			</div>
		</article>
	</div>
</div>
	<?php
endwhile;
