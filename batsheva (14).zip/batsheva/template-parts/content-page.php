<?php
/**
 * Default page body (plain HTML + theme CSS).
 *
 * @package Batsheva
 */

defined('ABSPATH') || exit;

while (have_posts()) :
	the_post();
	?>
<div class="min-h-screen bg-background batsheva-simple-page batsheva-page">
	<div class="batsheva-container batsheva-simple-page__articlewrap">
		<article <?php post_class('batsheva-page-article'); ?>>
			<header class="batsheva-page-article__head">
				<h1 class="batsheva-simple-page__title"><?php echo esc_html(get_the_title()); ?></h1>
			</header>
			<div class="batsheva-page-article__content entry-content">
				<?php the_content(); ?>
			</div>
		</article>
	</div>
</div>
	<?php
endwhile;
