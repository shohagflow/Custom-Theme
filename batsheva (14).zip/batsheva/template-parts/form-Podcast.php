<?php
/**
 * Podcast listen modal (Spotify + Apple Podcasts).
 *
 * @package Batsheva
 */

defined('ABSPATH') || exit;
?>
		<div id="batsheva-podcast-modal" class="batsheva-modal batsheva-podcast-modal" hidden>
			<div class="batsheva-modal__backdrop" data-batsheva-modal-close tabindex="-1"></div>
			<div class="batsheva-modal__dialog batsheva-podcast-modal__dialog" role="dialog" aria-modal="true" aria-labelledby="batsheva-podcast-title">
				<button type="button" class="batsheva-modal__close batsheva-podcast-modal__close" data-batsheva-modal-close aria-label="<?php esc_attr_e('Close', 'batsheva'); ?>">
					<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 6 6 18"></path><path d="m6 6 12 12"></path></svg>
				</button>
				<div class="batsheva-podcast-modal__inner">
					<div class="batsheva-podcast-modal__body">
						<h3 id="batsheva-podcast-title" class="batsheva-podcast-modal__title"><?php esc_html_e('Meaningful Life Skills with Rabbi Simon Jacobson', 'batsheva'); ?></h3>
						<div class="batsheva-podcast-modal__links">
							<a href="<?php echo esc_url('https://open.spotify.com/show/2OwbzGvGZqG83NqG5h5Q5q'); ?>" class="batsheva-podcast-modal__link batsheva-podcast-modal__link--spotify" target="_blank" rel="noopener noreferrer">
								<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M12 0C5.4 0 0 5.4 0 12C0 18.6 5.4 24 12 24C18.6 24 24 18.6 24 12C24 5.4 18.6 0 12 0ZM17.5 17.3C17.2 17.7 16.6 17.9 16.2 17.6C13.4 15.9 9.9 15.5 5.8 16.4C5.3 16.5 4.8 16.1 4.7 15.6C4.6 15.1 5 14.6 5.5 14.5C10 13.4 13.9 13.9 17.1 15.8C17.5 16.1 17.7 16.7 17.5 17.3ZM19 14C18.6 14.6 17.9 14.8 17.3 14.4C14.1 12.5 9.3 11.9 5.6 13C4.9 13.2 4.2 12.8 4 12.1C3.8 11.4 4.2 10.7 4.9 10.5C9.3 9.1 14.8 9.8 18.5 12.1C19.1 12.4 19.3 13.2 19 14ZM19.1 10.6C15.2 8.3 8.8 8.1 5.1 9.2C4.5 9.4 3.9 9 3.7 8.4C3.5 7.8 3.9 7.2 4.5 7C8.8 5.7 15.9 6 20.4 8.7C21 9 21.2 9.7 20.9 10.3C20.5 10.9 19.7 11.1 19.1 10.6Z"></path></svg>
								<?php esc_html_e('Listen on Spotify', 'batsheva'); ?>
							</a>
							<a href="<?php echo esc_url('https://podcasts.apple.com/us/podcast/meaningful-life-skills-with-simon-jacobson/id969137688'); ?>" class="batsheva-podcast-modal__link batsheva-podcast-modal__link--apple" target="_blank" rel="noopener noreferrer">
								<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M18.7 19.5C19.2 19.5 19.6 19.1 19.6 18.6V5.4C19.6 4.9 19.2 4.5 18.7 4.5H5.3C4.8 4.5 4.4 4.9 4.4 5.4V18.6C4.4 19.1 4.8 19.5 5.3 19.5H18.7ZM14.1 16.2C14.1 16.9 13.5 17.5 12.8 17.5H11.2C10.5 17.5 9.9 16.9 9.9 16.2V14.6H8.2C7.5 14.6 6.9 14 6.9 13.3V10.7C6.9 10 7.5 9.4 8.2 9.4H9.9V7.8C9.9 7.1 10.5 6.5 11.2 6.5H12.8C13.5 6.5 14.1 7.1 14.1 7.8V9.4H15.8C16.5 9.4 17.1 10 17.1 10.7V13.3C17.1 14 16.5 14.6 15.8 14.6H14.1V16.2Z M12.5 11.5C11.7 11.5 11 12.2 11 13C11 13.8 11.7 14.5 12.5 14.5C13.3 14.5 14 13.8 14 13C14 12.2 13.3 11.5 12.5 11.5Z"></path><path d="M12 24C5.4 24 0 18.6 0 12C0 5.4 5.4 0 12 0C18.6 0 24 5.4 24 12C24 18.6 18.6 24 12 24Z" fill-opacity="0"></path></svg>
								<?php esc_html_e('Listen on Apple', 'batsheva'); ?>
							</a>
						</div>
					</div>
				</div>
			</div>
		</div>
