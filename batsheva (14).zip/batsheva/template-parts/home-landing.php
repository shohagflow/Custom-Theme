﻿<?php
/**
 * PHP landing blocks (hero, offerings, quiz, site footer). Loaded from front-page.php.
 *
 * @package Batsheva
 */

defined('ABSPATH') || exit;

$t_assets = trailingslashit(get_template_directory_uri()) . 'assets/images/';
$hero_bg   = $t_assets . 'hero-bg.png';
$icons_img = $t_assets . rawurlencode('float image.png');
$img_insp  = $t_assets . 'card-inspiration.png';
$img_jour  = $t_assets . 'card-journey.png';
$img_eng   = $t_assets . 'card-engage.png';
$img_deep_bg = $t_assets . rawurlencode('deep larning.png');
$programs = function_exists('batsheva_get_static_offerings_data') ? batsheva_get_static_offerings_data() : array();
$p1 = isset($programs['program1']) && is_array($programs['program1']) ? $programs['program1'] : array();
$p2 = isset($programs['program2']) && is_array($programs['program2']) ? $programs['program2'] : array();
$p3 = isset($programs['program3']) && is_array($programs['program3']) ? $programs['program3'] : array();
$p4 = isset($programs['program4']) && is_array($programs['program4']) ? $programs['program4'] : array();
?>
		<!-- Hero: matches Figma (relative h-[80vh] min-h-[600px] flex center, bg + black/30 + gradient-to-b, max-w-4xl z-10) -->
		<section class="batsheva-hero">
			<div class="batsheva-hero-media" aria-hidden="true">
				<img src="<?php echo esc_url($hero_bg); ?>" alt="" class="batsheva-hero-bg" width="1200" height="1800" sizes="100vw" fetchpriority="high" decoding="async">
				<div class="batsheva-hero-shade"></div>
				<div class="batsheva-hero-fade"></div>
			</div>
			<div class="batsheva-hero-inner">
				<div class="batsheva-hero-stack flex flex-col items-center">
					<img src="<?php echo esc_url($icons_img); ?>" alt="<?php echo esc_attr__('Meaningful Life Center', 'batsheva'); ?>" class="batsheva-hero-float" width="280" height="160" loading="eager">
					<h1 class="batsheva-hero-title">
						<?php echo wp_kses_post(__('Find Meaning in<br />Every Moment', 'batsheva')); ?>
					</h1>
					<p class="batsheva-hero-lede">
						<?php esc_html_e("Timeless wisdom for modern life. Whether you're seeking daily inspiration, deep study, or a guided journey.", 'batsheva'); ?>
					</p>
					<div class="batsheva-hero-actions">
						<a href="#offerings" class="batsheva-hero-btn-p">
							<?php esc_html_e('Explore Offerings', 'batsheva'); ?>
							<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" class="shrink-0" aria-hidden="true"><path d="M12 5v14"></path><path d="m19 12-7 7-7-7"></path></svg>
						</a>
						<button type="button" class="batsheva-hero-btn-s batsheva-js-undecided-open" aria-haspopup="dialog" aria-controls="batsheva-undecided-modal" aria-expanded="false">
							<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" class="shrink-0" aria-hidden="true"><path d="M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z"></path><path d="M20 3v4"></path><path d="M22 5h-4"></path><path d="M4 17v2"></path><path d="M5 18H3"></path></svg>
							<?php esc_html_e("I'm Undecided", 'batsheva'); ?>
						</button>
					</div>
				</div>
			</div>
		</section>

		<div id="batsheva-undecided-modal" class="batsheva-modal" hidden>
			<div class="batsheva-modal__backdrop" data-batsheva-modal-close tabindex="-1"></div>
			<div class="batsheva-modal__dialog" role="dialog" aria-modal="true" aria-labelledby="batsheva-undecided-title">
				<button type="button" class="batsheva-modal__close" data-batsheva-modal-close aria-label="<?php esc_attr_e('Close', 'batsheva'); ?>">
					<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 6 6 18"></path><path d="m6 6 12 12"></path></svg>
				</button>
				<div class="batsheva-modal__body">
					<div class="batsheva-undecided-step-wrap">
						<div class="batsheva-undecided-step"><?php esc_html_e('Step 1 of 3', 'batsheva'); ?></div>
						<h2 id="batsheva-undecided-title" class="batsheva-undecided-heading"><?php esc_html_e('What brings you here today?', 'batsheva'); ?></h2>
						<div class="batsheva-undecided-options">
							<?php
							$undecided_choices = array(
								__('I feel stuck or disconnected', 'batsheva'),
								__('I want stronger, healthier relationships', 'batsheva'),
								__('I\'m overwhelmed or carrying a lot', 'batsheva'),
								__('I want more clarity and purpose', 'batsheva'),
								__('I\'m exploring and want to grow', 'batsheva'),
							);
							foreach ($undecided_choices as $choice_label) {
								?>
							<button type="button" class="batsheva-undecided-option">
								<span class="batsheva-undecided-option__label"><?php echo esc_html($choice_label); ?></span>
								<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="batsheva-undecided-option__arrow" aria-hidden="true"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>
							</button>
								<?php
							}
							?>
						</div>
					</div>
				</div>
			</div>
		</div>

		<?php get_template_part('template-parts/form-soulgym'); ?>
		<?php get_template_part('template-parts/form-masterclass'); ?>
		<?php get_template_part('template-parts/form-newsletter'); ?>
		<?php get_template_part('template-parts/form-Podcast'); ?>
		<?php get_template_part('template-parts/form-SocialMedia'); ?>
		<?php get_template_part('template-parts/form-omer-journey'); ?>
		<?php get_template_part('template-parts/form-steps-freedom'); ?>
		<?php get_template_part('template-parts/form-ask-the-rabbi-aI'); ?>
		<?php get_template_part('template-parts/form-ayin-bais'); ?>
		<?php get_template_part('template-parts/form-samach-vav'); ?>
		<?php get_template_part('template-parts/form-tanya-applied'); ?>
		<?php get_template_part('template-parts/form-mylife-chassidus-applied'); ?>

		<!-- Choose Your Path (Figma-style: py-24, cards, row CTAs, deep-learning hover) -->
		<section id="offerings" class="batsheva-offerings">
			<div class="batsheva-container">
				<div class="batsheva-offerings-head">
					<h2><?php esc_html_e('Choose Your Path', 'batsheva'); ?></h2>
					<p><?php esc_html_e('We have created diverse pathways to help you connect with your soul and the world around you.', 'batsheva'); ?></p>
					<div class="batsheva-offerings-gift">
						<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="shrink-0" aria-hidden="true"><rect x="3" y="8" width="18" height="4" rx="1"></rect><path d="M12 8v13"></path><path d="M19 12v7a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2v-7"></path><path d="M7.5 8a2.5 2.5 0 0 1 0-5A4.8 8 0 0 1 12 8a4.8 8 0 0 1 4.5-5 2.5 2.5 0 0 1 0 5"></path></svg>
						<span><?php esc_html_e('All programs are available free of charge', 'batsheva'); ?></span>
					</div>
				</div>

				<div class="batsheva-offerings-grid">
					<!-- Inspiration -->
					<article class="batsheva-path-card">
						<div class="batsheva-path-card-media">
							<img src="<?php echo esc_url(isset($p1['image']) ? $p1['image'] : $img_insp); ?>" alt="<?php echo esc_attr(isset($p1['title']) ? $p1['title'] : __('I want Inspiration', 'batsheva')); ?>" loading="lazy" width="640" height="360">
							<div class="batsheva-path-card-over">
								<h3><?php echo esc_html(isset($p1['title']) ? $p1['title'] : __('I want Inspiration', 'batsheva')); ?></h3>
							</div>
						</div>
						<div class="batsheva-path-card-body">
							<p class="batsheva-path-lede"><?php echo esc_html(isset($p1['lede']) ? $p1['lede'] : __('Weekly doses of wisdom to uplift your spirit.', 'batsheva')); ?></p>
							<div class="batsheva-path-rows">
								<?php
								$insp_rows = isset($p1['rows']) && is_array($p1['rows']) ? $p1['rows'] : array();
								foreach ($insp_rows as $row) {
									$modal_key = isset($row['form']) ? (string) $row['form'] : '';
									$is_soulgym = ($modal_key === 'soulgym');
									$is_masterclass = ($modal_key === 'masterclass');
									$is_newsletter = ($modal_key === 'newsletter');
									$is_podcast = ($modal_key === 'podcast');
									$is_social = ($modal_key === 'social');
									$is_omer = ($modal_key === 'omer');
									$is_steps_freedom = ($modal_key === 'steps_freedom');
									$is_ask_rabbi_ai  = ($modal_key === 'ask_rabbi_ai');
									$is_ayin_bais     = ($modal_key === 'ayin_bais');
									$is_samach_vav   = ($modal_key === 'samach_vav');
									$is_tanya_applied = ($modal_key === 'tanya_applied');
									$is_mylife_chassidus_applied = ($modal_key === 'mylife_chassidus_applied');
									$row_title = isset($row['title']) ? $row['title'] : '';
									$row_desc = isset($row['desc']) ? $row['desc'] : '';
									?>
									<?php if ($is_soulgym) : ?>
									<button type="button" class="batsheva-path-row batsheva-js-soulgym-open" aria-haspopup="dialog" aria-controls="batsheva-soulgym-modal" aria-expanded="false">
										<span class="batsheva-path-row-left">
											<span class="batsheva-path-check">
												<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"></path></svg>
											</span>
											<span class="batsheva-path-row-text">
												<span class="batsheva-path-row-title"><?php echo esc_html($row_title); ?></span>
												<span class="batsheva-path-row-desc"><?php echo esc_html($row_desc); ?></span>
											</span>
										</span>
										<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="batsheva-path-arrow" aria-hidden="true"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>
									</button>
									<?php elseif ($is_masterclass) : ?>
									<button type="button" class="batsheva-path-row batsheva-js-masterclass-open" aria-haspopup="dialog" aria-controls="batsheva-masterclass-modal" aria-expanded="false">
										<span class="batsheva-path-row-left">
											<span class="batsheva-path-check">
												<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"></path></svg>
											</span>
											<span class="batsheva-path-row-text">
												<span class="batsheva-path-row-title"><?php echo esc_html($row_title); ?></span>
												<span class="batsheva-path-row-desc"><?php echo esc_html($row_desc); ?></span>
											</span>
										</span>
										<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="batsheva-path-arrow" aria-hidden="true"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>
									</button>
									<?php elseif ($is_newsletter) : ?>
									<button type="button" class="batsheva-path-row batsheva-js-newsletter-open" aria-haspopup="dialog" aria-controls="batsheva-newsletter-modal" aria-expanded="false">
										<span class="batsheva-path-row-left">
											<span class="batsheva-path-check">
												<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"></path></svg>
											</span>
											<span class="batsheva-path-row-text">
												<span class="batsheva-path-row-title"><?php echo esc_html($row_title); ?></span>
												<span class="batsheva-path-row-desc"><?php echo esc_html($row_desc); ?></span>
											</span>
										</span>
										<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="batsheva-path-arrow" aria-hidden="true"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>
									</button>
									<?php elseif ($is_podcast) : ?>
									<button type="button" class="batsheva-path-row batsheva-js-podcast-open" aria-haspopup="dialog" aria-controls="batsheva-podcast-modal" aria-expanded="false">
										<span class="batsheva-path-row-left">
											<span class="batsheva-path-check">
												<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"></path></svg>
											</span>
											<span class="batsheva-path-row-text">
												<span class="batsheva-path-row-title"><?php echo esc_html($row_title); ?></span>
												<span class="batsheva-path-row-desc"><?php echo esc_html($row_desc); ?></span>
											</span>
										</span>
										<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="batsheva-path-arrow" aria-hidden="true"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>
									</button>
									<?php elseif ($is_social) : ?>
									<button type="button" class="batsheva-path-row batsheva-js-social-open" aria-haspopup="dialog" aria-controls="batsheva-social-modal" aria-expanded="false">
										<span class="batsheva-path-row-left">
											<span class="batsheva-path-check">
												<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"></path></svg>
											</span>
											<span class="batsheva-path-row-text">
												<span class="batsheva-path-row-title"><?php echo esc_html($row_title); ?></span>
												<span class="batsheva-path-row-desc"><?php echo esc_html($row_desc); ?></span>
											</span>
										</span>
										<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="batsheva-path-arrow" aria-hidden="true"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>
									</button>
									<?php elseif ($is_omer) : ?>
									<button type="button" class="batsheva-path-row batsheva-js-omer-open" aria-haspopup="dialog" aria-controls="batsheva-omer-modal" aria-expanded="false">
										<span class="batsheva-path-row-left">
											<span class="batsheva-path-check">
												<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"></path></svg>
											</span>
											<span class="batsheva-path-row-text">
												<span class="batsheva-path-row-title"><?php echo esc_html($row_title); ?></span>
												<span class="batsheva-path-row-desc"><?php echo esc_html($row_desc); ?></span>
											</span>
										</span>
										<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="batsheva-path-arrow" aria-hidden="true"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>
									</button>
									<?php elseif ($is_steps_freedom) : ?>
									<button type="button" class="batsheva-path-row batsheva-js-steps-freedom-open" aria-haspopup="dialog" aria-controls="batsheva-steps-freedom-modal" aria-expanded="false">
										<span class="batsheva-path-row-left">
											<span class="batsheva-path-check">
												<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"></path></svg>
											</span>
											<span class="batsheva-path-row-text">
												<span class="batsheva-path-row-title"><?php echo esc_html($row_title); ?></span>
												<span class="batsheva-path-row-desc"><?php echo esc_html($row_desc); ?></span>
											</span>
										</span>
										<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="batsheva-path-arrow" aria-hidden="true"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>
									</button>
									<?php elseif ($is_ask_rabbi_ai) : ?>
									<button type="button" class="batsheva-path-row batsheva-js-ask-rabbi-ai-open" aria-haspopup="dialog" aria-controls="batsheva-ask-rabbi-ai-modal" aria-expanded="false">
										<span class="batsheva-path-row-left">
											<span class="batsheva-path-check">
												<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"></path></svg>
											</span>
											<span class="batsheva-path-row-text">
												<span class="batsheva-path-row-title"><?php echo esc_html($row_title); ?></span>
												<span class="batsheva-path-row-desc"><?php echo esc_html($row_desc); ?></span>
											</span>
										</span>
										<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="batsheva-path-arrow" aria-hidden="true"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>
									</button>
									<?php elseif ($is_ayin_bais) : ?>
									<button type="button" class="batsheva-path-row batsheva-js-ayin-bais-open" aria-haspopup="dialog" aria-controls="batsheva-ayin-bais-modal" aria-expanded="false">
										<span class="batsheva-path-row-left">
											<span class="batsheva-path-check">
												<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"></path></svg>
											</span>
											<span class="batsheva-path-row-text">
												<span class="batsheva-path-row-title"><?php echo esc_html($row_title); ?></span>
												<span class="batsheva-path-row-desc"><?php echo esc_html($row_desc); ?></span>
											</span>
										</span>
										<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="batsheva-path-arrow" aria-hidden="true"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>
									</button>
									<?php elseif ($is_samach_vav) : ?>
									<button type="button" class="batsheva-path-row batsheva-js-samach-vav-open" aria-haspopup="dialog" aria-controls="batsheva-samach-vav-modal" aria-expanded="false">
										<span class="batsheva-path-row-left">
											<span class="batsheva-path-check">
												<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"></path></svg>
											</span>
											<span class="batsheva-path-row-text">
												<span class="batsheva-path-row-title"><?php echo esc_html($row_title); ?></span>
												<span class="batsheva-path-row-desc"><?php echo esc_html($row_desc); ?></span>
											</span>
										</span>
										<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="batsheva-path-arrow" aria-hidden="true"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>
									</button>
									<?php elseif ($is_tanya_applied) : ?>
									<button type="button" class="batsheva-path-row batsheva-js-tanya-applied-open" aria-haspopup="dialog" aria-controls="batsheva-tanya-applied-modal" aria-expanded="false">
										<span class="batsheva-path-row-left">
											<span class="batsheva-path-check">
												<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"></path></svg>
											</span>
											<span class="batsheva-path-row-text">
												<span class="batsheva-path-row-title"><?php echo esc_html($row_title); ?></span>
												<span class="batsheva-path-row-desc"><?php echo esc_html($row_desc); ?></span>
											</span>
										</span>
										<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="batsheva-path-arrow" aria-hidden="true"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>
									</button>
									<?php elseif ($is_mylife_chassidus_applied) : ?>
									<button type="button" class="batsheva-path-row batsheva-js-mylife-chassidus-applied-open" aria-haspopup="dialog" aria-controls="batsheva-mylife-chassidus-applied-modal" aria-expanded="false">
										<span class="batsheva-path-row-left">
											<span class="batsheva-path-check">
												<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"></path></svg>
											</span>
											<span class="batsheva-path-row-text">
												<span class="batsheva-path-row-title"><?php echo esc_html($row_title); ?></span>
												<span class="batsheva-path-row-desc"><?php echo esc_html($row_desc); ?></span>
											</span>
										</span>
										<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="batsheva-path-arrow" aria-hidden="true"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>
									</button>
									<?php else : ?>
									<a href="#" class="batsheva-path-row">
										<span class="batsheva-path-row-left">
											<span class="batsheva-path-check">
												<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"></path></svg>
											</span>
											<span class="batsheva-path-row-text">
												<span class="batsheva-path-row-title"><?php echo esc_html($row_title); ?></span>
												<span class="batsheva-path-row-desc"><?php echo esc_html($row_desc); ?></span>
											</span>
										</span>
										<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="batsheva-path-arrow" aria-hidden="true"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>
									</a>
									<?php endif; ?>
									<?php
								}
								?>
							</div>
						</div>
					</article>

					<!-- Guided Journey -->
					<article class="batsheva-path-card">
						<div class="batsheva-path-card-media">
							<img src="<?php echo esc_url(isset($p2['image']) ? $p2['image'] : $img_jour); ?>" alt="<?php echo esc_attr(isset($p2['title']) ? $p2['title'] : __('I want a Guided Journey', 'batsheva')); ?>" loading="lazy" width="640" height="360">
							<div class="batsheva-path-card-over">
								<h3><?php echo esc_html(isset($p2['title']) ? $p2['title'] : __('I want a Guided Journey', 'batsheva')); ?></h3>
							</div>
						</div>
						<div class="batsheva-path-card-body">
							<p class="batsheva-path-lede"><?php echo esc_html(isset($p2['lede']) ? $p2['lede'] : __('Time-bound journeys based on the Jewish calendar and beyond', 'batsheva')); ?></p>
							<div class="batsheva-path-rows">
								<div class="batsheva-path-spotlight">
									<span class="batsheva-path-badge"><?php echo esc_html(isset($p2['spotlight_badge']) ? $p2['spotlight_badge'] : __('Now Open', 'batsheva')); ?></span>
									<h4><?php echo esc_html(isset($p2['spotlight_title']) ? $p2['spotlight_title'] : __('Omer Journey', 'batsheva')); ?></h4>
									<p><?php echo esc_html(isset($p2['spotlight_desc']) ? $p2['spotlight_desc'] : __('49 Days of inner refinement', 'batsheva')); ?></p>
									<div class="batsheva-path-spotlight-meta">
										<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><rect width="18" height="18" x="3" y="4" rx="2" ry="2"></rect><line x1="16" x2="16" y1="2" y2="6"></line><line x1="8" x2="8" y1="2" y2="6"></line><line x1="3" x2="21" y1="10" y2="10"></line></svg>
										<span><?php echo esc_html(isset($p2['spotlight_meta']) ? $p2['spotlight_meta'] : __('Begins April 2', 'batsheva')); ?></span>
									</div>
									<?php $p2_spotlight_form = isset($p2['spotlight_form']) ? (string) $p2['spotlight_form'] : ''; ?>
									<?php if ($p2_spotlight_form === 'soulgym') : ?>
										<button type="button" class="batsheva-path-spotlight-btn batsheva-js-soulgym-open" aria-haspopup="dialog" aria-controls="batsheva-soulgym-modal" aria-expanded="false"><?php echo esc_html(isset($p2['spotlight_cta']) ? $p2['spotlight_cta'] : __('Reserve My Spot', 'batsheva')); ?><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg></button>
									<?php elseif ($p2_spotlight_form === 'masterclass') : ?>
										<button type="button" class="batsheva-path-spotlight-btn batsheva-js-masterclass-open" aria-haspopup="dialog" aria-controls="batsheva-masterclass-modal" aria-expanded="false"><?php echo esc_html(isset($p2['spotlight_cta']) ? $p2['spotlight_cta'] : __('Reserve My Spot', 'batsheva')); ?><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg></button>
									<?php elseif ($p2_spotlight_form === 'newsletter') : ?>
										<button type="button" class="batsheva-path-spotlight-btn batsheva-js-newsletter-open" aria-haspopup="dialog" aria-controls="batsheva-newsletter-modal" aria-expanded="false"><?php echo esc_html(isset($p2['spotlight_cta']) ? $p2['spotlight_cta'] : __('Reserve My Spot', 'batsheva')); ?><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg></button>
									<?php elseif ($p2_spotlight_form === 'podcast') : ?>
										<button type="button" class="batsheva-path-spotlight-btn batsheva-js-podcast-open" aria-haspopup="dialog" aria-controls="batsheva-podcast-modal" aria-expanded="false"><?php echo esc_html(isset($p2['spotlight_cta']) ? $p2['spotlight_cta'] : __('Reserve My Spot', 'batsheva')); ?><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg></button>
									<?php elseif ($p2_spotlight_form === 'social') : ?>
										<button type="button" class="batsheva-path-spotlight-btn batsheva-js-social-open" aria-haspopup="dialog" aria-controls="batsheva-social-modal" aria-expanded="false"><?php echo esc_html(isset($p2['spotlight_cta']) ? $p2['spotlight_cta'] : __('Reserve My Spot', 'batsheva')); ?><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg></button>
									<?php elseif ($p2_spotlight_form === 'omer') : ?>
										<button type="button" class="batsheva-path-spotlight-btn batsheva-js-omer-open" aria-haspopup="dialog" aria-controls="batsheva-omer-modal" aria-expanded="false"><?php echo esc_html(isset($p2['spotlight_cta']) ? $p2['spotlight_cta'] : __('Reserve My Spot', 'batsheva')); ?><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg></button>
									<?php elseif ($p2_spotlight_form === 'steps_freedom') : ?>
										<button type="button" class="batsheva-path-spotlight-btn batsheva-js-steps-freedom-open" aria-haspopup="dialog" aria-controls="batsheva-steps-freedom-modal" aria-expanded="false"><?php echo esc_html(isset($p2['spotlight_cta']) ? $p2['spotlight_cta'] : __('Reserve My Spot', 'batsheva')); ?><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg></button>
									<?php elseif ($p2_spotlight_form === 'ask_rabbi_ai') : ?>
										<button type="button" class="batsheva-path-spotlight-btn batsheva-js-ask-rabbi-ai-open" aria-haspopup="dialog" aria-controls="batsheva-ask-rabbi-ai-modal" aria-expanded="false"><?php echo esc_html(isset($p2['spotlight_cta']) ? $p2['spotlight_cta'] : __('Reserve My Spot', 'batsheva')); ?><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg></button>
									<?php elseif ($p2_spotlight_form === 'ayin_bais') : ?>
										<button type="button" class="batsheva-path-spotlight-btn batsheva-js-ayin-bais-open" aria-haspopup="dialog" aria-controls="batsheva-ayin-bais-modal" aria-expanded="false"><?php echo esc_html(isset($p2['spotlight_cta']) ? $p2['spotlight_cta'] : __('Reserve My Spot', 'batsheva')); ?><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg></button>
									<?php elseif ($p2_spotlight_form === 'samach_vav') : ?>
										<button type="button" class="batsheva-path-spotlight-btn batsheva-js-samach-vav-open" aria-haspopup="dialog" aria-controls="batsheva-samach-vav-modal" aria-expanded="false"><?php echo esc_html(isset($p2['spotlight_cta']) ? $p2['spotlight_cta'] : __('Reserve My Spot', 'batsheva')); ?><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg></button>
									<?php elseif ($p2_spotlight_form === 'tanya_applied') : ?>
										<button type="button" class="batsheva-path-spotlight-btn batsheva-js-tanya-applied-open" aria-haspopup="dialog" aria-controls="batsheva-tanya-applied-modal" aria-expanded="false"><?php echo esc_html(isset($p2['spotlight_cta']) ? $p2['spotlight_cta'] : __('Reserve My Spot', 'batsheva')); ?><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg></button>
									<?php elseif ($p2_spotlight_form === 'mylife_chassidus_applied') : ?>
										<button type="button" class="batsheva-path-spotlight-btn batsheva-js-mylife-chassidus-applied-open" aria-haspopup="dialog" aria-controls="batsheva-mylife-chassidus-applied-modal" aria-expanded="false"><?php echo esc_html(isset($p2['spotlight_cta']) ? $p2['spotlight_cta'] : __('Reserve My Spot', 'batsheva')); ?><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg></button>
									<?php else : ?>
										<a href="#" class="batsheva-path-spotlight-btn"><?php echo esc_html(isset($p2['spotlight_cta']) ? $p2['spotlight_cta'] : __('Reserve My Spot', 'batsheva')); ?><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg></a>
									<?php endif; ?>
								</div>
								<?php $p2_row_form = isset($p2['row_form']) ? (string) $p2['row_form'] : ''; ?>
								<?php if ($p2_row_form === 'soulgym') : ?>
								<button type="button" class="batsheva-path-row batsheva-js-soulgym-open" aria-haspopup="dialog" aria-controls="batsheva-soulgym-modal" aria-expanded="false">
								<?php elseif ($p2_row_form === 'masterclass') : ?>
								<button type="button" class="batsheva-path-row batsheva-js-masterclass-open" aria-haspopup="dialog" aria-controls="batsheva-masterclass-modal" aria-expanded="false">
								<?php elseif ($p2_row_form === 'newsletter') : ?>
								<button type="button" class="batsheva-path-row batsheva-js-newsletter-open" aria-haspopup="dialog" aria-controls="batsheva-newsletter-modal" aria-expanded="false">
								<?php elseif ($p2_row_form === 'podcast') : ?>
								<button type="button" class="batsheva-path-row batsheva-js-podcast-open" aria-haspopup="dialog" aria-controls="batsheva-podcast-modal" aria-expanded="false">
								<?php elseif ($p2_row_form === 'social') : ?>
								<button type="button" class="batsheva-path-row batsheva-js-social-open" aria-haspopup="dialog" aria-controls="batsheva-social-modal" aria-expanded="false">
								<?php elseif ($p2_row_form === 'omer') : ?>
								<button type="button" class="batsheva-path-row batsheva-js-omer-open" aria-haspopup="dialog" aria-controls="batsheva-omer-modal" aria-expanded="false">
								<?php elseif ($p2_row_form === 'steps_freedom') : ?>
								<button type="button" class="batsheva-path-row batsheva-js-steps-freedom-open" aria-haspopup="dialog" aria-controls="batsheva-steps-freedom-modal" aria-expanded="false">
								<?php elseif ($p2_row_form === 'ask_rabbi_ai') : ?>
								<button type="button" class="batsheva-path-row batsheva-js-ask-rabbi-ai-open" aria-haspopup="dialog" aria-controls="batsheva-ask-rabbi-ai-modal" aria-expanded="false">
								<?php elseif ($p2_row_form === 'ayin_bais') : ?>
								<button type="button" class="batsheva-path-row batsheva-js-ayin-bais-open" aria-haspopup="dialog" aria-controls="batsheva-ayin-bais-modal" aria-expanded="false">
								<?php elseif ($p2_row_form === 'samach_vav') : ?>
								<button type="button" class="batsheva-path-row batsheva-js-samach-vav-open" aria-haspopup="dialog" aria-controls="batsheva-samach-vav-modal" aria-expanded="false">
								<?php elseif ($p2_row_form === 'tanya_applied') : ?>
								<button type="button" class="batsheva-path-row batsheva-js-tanya-applied-open" aria-haspopup="dialog" aria-controls="batsheva-tanya-applied-modal" aria-expanded="false">
								<?php elseif ($p2_row_form === 'mylife_chassidus_applied') : ?>
								<button type="button" class="batsheva-path-row batsheva-js-mylife-chassidus-applied-open" aria-haspopup="dialog" aria-controls="batsheva-mylife-chassidus-applied-modal" aria-expanded="false">
								<?php else : ?>
								<a href="#" class="batsheva-path-row">
								<?php endif; ?>
									<span class="batsheva-path-row-left">
										<span class="batsheva-path-check">
											<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"></path></svg>
										</span>
										<span class="batsheva-path-row-text">
											<span class="batsheva-path-row-title"><?php echo esc_html(isset($p2['row_title']) ? $p2['row_title'] : __('15 Steps to Freedom', 'batsheva')); ?></span>
											<span class="batsheva-path-row-desc"><?php echo esc_html(isset($p2['row_desc']) ? $p2['row_desc'] : __('A free downloadable guide to your Passover seder.', 'batsheva')); ?></span>
										</span>
									</span>
									<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="batsheva-path-arrow" aria-hidden="true"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>
								<?php if ($p2_row_form === 'soulgym' || $p2_row_form === 'masterclass' || $p2_row_form === 'newsletter' || $p2_row_form === 'podcast' || $p2_row_form === 'social' || $p2_row_form === 'omer' || $p2_row_form === 'steps_freedom' || $p2_row_form === 'ask_rabbi_ai' || $p2_row_form === 'ayin_bais' || $p2_row_form === 'samach_vav' || $p2_row_form === 'tanya_applied' || $p2_row_form === 'mylife_chassidus_applied') : ?>
								</button>
								<?php else : ?>
								</a>
								<?php endif; ?>
							</div>
						</div>
					</article>

					<!-- Ask & Engage -->
					<article class="batsheva-path-card">
						<div class="batsheva-path-card-media">
							<img src="<?php echo esc_url(isset($p3['image']) ? $p3['image'] : $img_eng); ?>" alt="<?php echo esc_attr(isset($p3['title']) ? $p3['title'] : __('I want to Ask & Engage', 'batsheva')); ?>" loading="lazy" width="640" height="360">
							<div class="batsheva-path-card-over">
								<h3><?php echo esc_html(isset($p3['title']) ? $p3['title'] : __('I want to Ask & Engage', 'batsheva')); ?></h3>
							</div>
						</div>
						<div class="batsheva-path-card-body">
							<p class="batsheva-path-lede"><?php echo esc_html(isset($p3['lede']) ? $p3['lede'] : __('Interactive tools and community connection.', 'batsheva')); ?></p>
							<div class="batsheva-path-rows">
								<?php
								$eng_rows = isset($p3['rows']) && is_array($p3['rows']) ? $p3['rows'] : array();
								foreach ($eng_rows as $row) {
									$row_form = isset($row['form']) ? (string) $row['form'] : '';
									?>
									<?php if ($row_form === 'soulgym') : ?>
									<button type="button" class="batsheva-path-row batsheva-js-soulgym-open" aria-haspopup="dialog" aria-controls="batsheva-soulgym-modal" aria-expanded="false">
									<?php elseif ($row_form === 'masterclass') : ?>
									<button type="button" class="batsheva-path-row batsheva-js-masterclass-open" aria-haspopup="dialog" aria-controls="batsheva-masterclass-modal" aria-expanded="false">
									<?php elseif ($row_form === 'newsletter') : ?>
									<button type="button" class="batsheva-path-row batsheva-js-newsletter-open" aria-haspopup="dialog" aria-controls="batsheva-newsletter-modal" aria-expanded="false">
									<?php elseif ($row_form === 'podcast') : ?>
									<button type="button" class="batsheva-path-row batsheva-js-podcast-open" aria-haspopup="dialog" aria-controls="batsheva-podcast-modal" aria-expanded="false">
									<?php elseif ($row_form === 'social') : ?>
									<button type="button" class="batsheva-path-row batsheva-js-social-open" aria-haspopup="dialog" aria-controls="batsheva-social-modal" aria-expanded="false">
									<?php elseif ($row_form === 'omer') : ?>
									<button type="button" class="batsheva-path-row batsheva-js-omer-open" aria-haspopup="dialog" aria-controls="batsheva-omer-modal" aria-expanded="false">
									<?php elseif ($row_form === 'steps_freedom') : ?>
									<button type="button" class="batsheva-path-row batsheva-js-steps-freedom-open" aria-haspopup="dialog" aria-controls="batsheva-steps-freedom-modal" aria-expanded="false">
									<?php elseif ($row_form === 'ask_rabbi_ai') : ?>
									<button type="button" class="batsheva-path-row batsheva-js-ask-rabbi-ai-open" aria-haspopup="dialog" aria-controls="batsheva-ask-rabbi-ai-modal" aria-expanded="false">
									<?php elseif ($row_form === 'ayin_bais') : ?>
									<button type="button" class="batsheva-path-row batsheva-js-ayin-bais-open" aria-haspopup="dialog" aria-controls="batsheva-ayin-bais-modal" aria-expanded="false">
									<?php elseif ($row_form === 'samach_vav') : ?>
									<button type="button" class="batsheva-path-row batsheva-js-samach-vav-open" aria-haspopup="dialog" aria-controls="batsheva-samach-vav-modal" aria-expanded="false">
									<?php elseif ($row_form === 'tanya_applied') : ?>
									<button type="button" class="batsheva-path-row batsheva-js-tanya-applied-open" aria-haspopup="dialog" aria-controls="batsheva-tanya-applied-modal" aria-expanded="false">
									<?php elseif ($row_form === 'mylife_chassidus_applied') : ?>
									<button type="button" class="batsheva-path-row batsheva-js-mylife-chassidus-applied-open" aria-haspopup="dialog" aria-controls="batsheva-mylife-chassidus-applied-modal" aria-expanded="false">
									<?php else : ?>
									<a href="#" class="batsheva-path-row">
									<?php endif; ?>
										<span class="batsheva-path-row-left">
											<span class="batsheva-path-check">
												<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"></path></svg>
											</span>
											<span class="batsheva-path-row-text">
												<span class="batsheva-path-row-title"><?php echo esc_html(isset($row['title']) ? $row['title'] : ''); ?></span>
												<span class="batsheva-path-row-desc"><?php echo esc_html(isset($row['desc']) ? $row['desc'] : ''); ?></span>
											</span>
										</span>
										<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="batsheva-path-arrow" aria-hidden="true"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>
									<?php if ($row_form === 'soulgym' || $row_form === 'masterclass' || $row_form === 'newsletter' || $row_form === 'podcast' || $row_form === 'social' || $row_form === 'omer' || $row_form === 'steps_freedom' || $row_form === 'ask_rabbi_ai' || $row_form === 'ayin_bais' || $row_form === 'samach_vav' || $row_form === 'tanya_applied' || $row_form === 'mylife_chassidus_applied') : ?>
									</button>
									<?php else : ?>
									</a>
									<?php endif; ?>
									<?php
								}
								?>
							</div>
						</div>
					</article>

					<!-- Deep Learning -->
					<article class="batsheva-path-deep">
						<div class="batsheva-path-deep-bg" aria-hidden="true">
							<img src="<?php echo esc_url(isset($p4['image']) ? $p4['image'] : $img_deep_bg); ?>" alt="" width="640" height="360">
							<div class="batsheva-path-deep-tint"></div>
							<div class="batsheva-path-deep-brand">
								<p class="batsheva-path-deep-brand-name"><?php echo esc_html(isset($p4['brand_name']) ? $p4['brand_name'] : 'MyLife'); ?></p>
								<p class="batsheva-path-deep-brand-tag"><?php echo esc_html(isset($p4['brand_tag']) ? $p4['brand_tag'] : __('Chassidus Applied', 'batsheva')); ?></p>
							</div>
						</div>
						<div class="batsheva-path-deep-front">
							<div>
								<h3><?php echo esc_html(isset($p4['title']) ? $p4['title'] : __('I want Deep Learning', 'batsheva')); ?></h3>
								<p class="batsheva-path-deep-sub"><?php echo esc_html(isset($p4['subtitle']) ? $p4['subtitle'] : __('For advanced Chassidic thought students only.', 'batsheva')); ?></p>
							</div>
							<div class="batsheva-path-deep-list">
								<?php
								$deep_rows = isset($p4['rows']) && is_array($p4['rows']) ? $p4['rows'] : array();
								foreach ($deep_rows as $row) {
									$row_form = isset($row['form']) ? (string) $row['form'] : '';
									?>
									<?php if ($row_form === 'soulgym') : ?>
									<button type="button" class="batsheva-path-row batsheva-js-soulgym-open" aria-haspopup="dialog" aria-controls="batsheva-soulgym-modal" aria-expanded="false">
									<?php elseif ($row_form === 'masterclass') : ?>
									<button type="button" class="batsheva-path-row batsheva-js-masterclass-open" aria-haspopup="dialog" aria-controls="batsheva-masterclass-modal" aria-expanded="false">
									<?php elseif ($row_form === 'newsletter') : ?>
									<button type="button" class="batsheva-path-row batsheva-js-newsletter-open" aria-haspopup="dialog" aria-controls="batsheva-newsletter-modal" aria-expanded="false">
									<?php elseif ($row_form === 'podcast') : ?>
									<button type="button" class="batsheva-path-row batsheva-js-podcast-open" aria-haspopup="dialog" aria-controls="batsheva-podcast-modal" aria-expanded="false">
									<?php elseif ($row_form === 'social') : ?>
									<button type="button" class="batsheva-path-row batsheva-js-social-open" aria-haspopup="dialog" aria-controls="batsheva-social-modal" aria-expanded="false">
									<?php elseif ($row_form === 'omer') : ?>
									<button type="button" class="batsheva-path-row batsheva-js-omer-open" aria-haspopup="dialog" aria-controls="batsheva-omer-modal" aria-expanded="false">
									<?php elseif ($row_form === 'steps_freedom') : ?>
									<button type="button" class="batsheva-path-row batsheva-js-steps-freedom-open" aria-haspopup="dialog" aria-controls="batsheva-steps-freedom-modal" aria-expanded="false">
									<?php elseif ($row_form === 'ask_rabbi_ai') : ?>
									<button type="button" class="batsheva-path-row batsheva-js-ask-rabbi-ai-open" aria-haspopup="dialog" aria-controls="batsheva-ask-rabbi-ai-modal" aria-expanded="false">
									<?php elseif ($row_form === 'ayin_bais') : ?>
									<button type="button" class="batsheva-path-row batsheva-js-ayin-bais-open" aria-haspopup="dialog" aria-controls="batsheva-ayin-bais-modal" aria-expanded="false">
									<?php elseif ($row_form === 'samach_vav') : ?>
									<button type="button" class="batsheva-path-row batsheva-js-samach-vav-open" aria-haspopup="dialog" aria-controls="batsheva-samach-vav-modal" aria-expanded="false">
									<?php elseif ($row_form === 'tanya_applied') : ?>
									<button type="button" class="batsheva-path-row batsheva-js-tanya-applied-open" aria-haspopup="dialog" aria-controls="batsheva-tanya-applied-modal" aria-expanded="false">
									<?php elseif ($row_form === 'mylife_chassidus_applied') : ?>
									<button type="button" class="batsheva-path-row batsheva-js-mylife-chassidus-applied-open" aria-haspopup="dialog" aria-controls="batsheva-mylife-chassidus-applied-modal" aria-expanded="false">
									<?php else : ?>
									<a href="#" class="batsheva-path-row">
									<?php endif; ?>
										<span class="batsheva-path-row-left">
											<span class="batsheva-path-check">
												<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"></path></svg>
											</span>
											<span class="batsheva-path-row-text">
												<span class="batsheva-path-row-title"><?php echo esc_html(isset($row['title']) ? $row['title'] : ''); ?></span>
												<span class="batsheva-path-row-desc"><?php echo esc_html(isset($row['desc']) ? $row['desc'] : ''); ?></span>
											</span>
										</span>
										<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="batsheva-path-arrow" aria-hidden="true"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>
									<?php if ($row_form === 'soulgym' || $row_form === 'masterclass' || $row_form === 'newsletter' || $row_form === 'podcast' || $row_form === 'social' || $row_form === 'omer' || $row_form === 'steps_freedom' || $row_form === 'ask_rabbi_ai' || $row_form === 'ayin_bais' || $row_form === 'samach_vav' || $row_form === 'tanya_applied' || $row_form === 'mylife_chassidus_applied') : ?>
									</button>
									<?php else : ?>
									</a>
									<?php endif; ?>
									<?php
								}
								?>
							</div>
						</div>
					</article>
				</div>

				<!-- Quiz CTA: same vertical block as Figma (after grid mb-20, inside py-24 offerings) -->
				<div class="batsheva-quiz-card">
					<div class="batsheva-quiz-icon" aria-hidden="true">
						<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z"></path><path d="M20 3v4"></path><path d="M22 5h-4"></path><path d="M4 17v2"></path><path d="M5 18H3"></path></svg>
					</div>
					<h3><?php esc_html_e('Not sure which program is right for you?', 'batsheva'); ?></h3>
					<p><?php esc_html_e('Take our short quiz to find the perfect learning journey tailored to your interests and schedule.', 'batsheva'); ?></p>
					<button type="button" class="batsheva-quiz-btn batsheva-js-undecided-open" aria-haspopup="dialog" aria-controls="batsheva-undecided-modal" aria-expanded="false">
						<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z"></path><path d="M20 3v4"></path><path d="M22 5h-4"></path><path d="M4 17v2"></path><path d="M5 18H3"></path></svg>
						<?php esc_html_e('Take a Quiz', 'batsheva'); ?>
					</button>
				</div>
			</div>
		</section>

		<!-- Footer + social (Figma: white, py-16, max-w-4xl, brand SVGs, bar links) -->
		<footer class="batsheva-site-footer">
			<div class="batsheva-site-footer-inner">
				<h3><?php esc_html_e('Browse and get inspired the way you want', 'batsheva'); ?></h3>
				<div class="batsheva-site-footer-social">
					<a href="<?php echo esc_url('https://www.youtube.com/user/MeaninfulLifeCenter'); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php esc_attr_e('YouTube', 'batsheva'); ?>">
						<span class="batsheva-site-footer-icon batsheva-site-footer-icon--yt">
							<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="0" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2.5 17a24.12 24.12 0 0 1 0-10 2 2 0 0 1 1.4-1.4 49.56 49.56 0 0 1 16.2 0A2 2 0 0 1 21.5 7a24.12 24.12 0 0 1 0 10 2 2 0 0 1-1.4 1.4 49.55 49.55 0 0 1-16.2 0A2 2 0 0 1 2.5 17"></path><path d="m10 15 5-3-5-3z"></path></svg>
						</span>
					</a>
					<a href="<?php echo esc_url('https://www.facebook.com/MeaningfulLifeCenter'); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php esc_attr_e('Facebook', 'batsheva'); ?>">
						<span class="batsheva-site-footer-icon batsheva-site-footer-icon--fb">
							<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="0" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path></svg>
						</span>
					</a>
					<a href="<?php echo esc_url('https://www.instagram.com/meaningfullifecenter'); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php esc_attr_e('Instagram', 'batsheva'); ?>">
						<span class="batsheva-site-footer-icon batsheva-site-footer-icon--ig">
							<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect width="20" height="20" x="2" y="2" rx="5" ry="5"></rect><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path><line x1="17.5" x2="17.51" y1="6.5" y2="6.5"></line></svg>
						</span>
					</a>
					<a href="<?php echo esc_url('https://simonjacobson.ai'); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php esc_attr_e('WhatsApp', 'batsheva'); ?>">
						<span class="batsheva-site-footer-icon batsheva-site-footer-icon--wa">
							<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M17.472 14.382C17.119 14.205 15.385 13.351 15.061 13.235C14.736 13.118 14.499 13.06 14.264 13.412C14.029 13.765 13.352 14.558 13.146 14.793C12.94 15.029 12.734 15.058 12.381 14.882C12.028 14.706 10.892 14.333 9.546 13.133C8.498 12.199 7.791 11.046 7.615 10.741C7.438 10.436 7.596 10.273 7.773 10.097C7.932 9.938 8.127 9.683 8.304 9.477C8.481 9.271 8.54 9.124 8.657 8.889C8.775 8.654 8.716 8.448 8.627 8.272C8.539 8.096 7.833 6.362 7.539 5.657C7.253 4.972 6.963 5.065 6.747 5.065C6.549 5.065 6.324 5.065 6.098 5.065C5.872 5.065 5.509 5.15 5.205 5.481C4.901 5.811 4.039 6.621 4.039 8.267C4.039 9.913 5.235 11.505 5.412 11.74C5.588 11.975 7.777 15.352 11.13 16.8C11.928 17.145 12.551 17.35 13.044 17.506C13.845 17.761 14.577 17.728 15.155 17.642C15.801 17.546 17.149 16.827 17.43 16.035C17.711 15.243 17.711 14.568 17.623 14.421C17.535 14.274 17.295 14.177 16.942 14.001H17.472ZM12.005 21.765C10.233 21.765 8.577 21.312 7.126 20.499L6.822 20.318L3.064 21.305L4.088 17.646L3.896 17.34C2.986 15.892 2.507 14.2 2.507 12.459C2.507 7.224 6.766 2.965 12.005 2.965C14.542 2.965 16.927 3.953 18.721 5.747C20.515 7.541 21.503 9.926 21.503 12.463C21.503 17.707 17.24 21.765 12.005 21.765Z"></path></svg>
						</span>
					</a>
				</div>
				<div class="batsheva-site-footer-bar">
					<p><?php echo esc_html(sprintf(__('© %s Meaningful Life Center. All rights reserved.', 'batsheva'), wp_date('Y'))); ?></p>
					<div class="batsheva-site-footer-links">
						<a href="<?php echo esc_url(batsheva_get_privacy_policy_url()); ?>"><?php esc_html_e('Privacy Policy', 'batsheva'); ?></a>
						<a href="#"><?php esc_html_e('Terms of Service', 'batsheva'); ?></a>
						<a href="#"><?php esc_html_e('Contact Us', 'batsheva'); ?></a>
					</div>
				</div>
			</div>
		</footer>
