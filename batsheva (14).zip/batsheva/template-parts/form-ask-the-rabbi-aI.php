<?php
/**
 * Ask the Rabbi AI signup modal.
 *
 * @package Batsheva
 */

defined('ABSPATH') || exit;

$rabbi_email_id = 'batsheva-ask-rabbi-ai-email';
?>
		<div id="batsheva-ask-rabbi-ai-modal" class="batsheva-modal batsheva-soulgym-modal batsheva-ask-rabbi-ai-modal batsheva-masterclass-modal" hidden>
			<div class="batsheva-modal__backdrop" data-batsheva-modal-close tabindex="-1"></div>
			<div class="batsheva-modal__dialog batsheva-soulgym-modal__dialog" role="dialog" aria-modal="true" aria-labelledby="batsheva-ask-rabbi-ai-title">
				<button type="button" class="batsheva-modal__close" data-batsheva-modal-close aria-label="<?php esc_attr_e('Close', 'batsheva'); ?>">
					<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 6 6 18"></path><path d="m6 6 12 12"></path></svg>
				</button>
				<div class="batsheva-soulgym-modal__inner">
					<div class="batsheva-soulgym-modal__main p-8">
						<div>
							<div class="inline-block px-3 py-1 bg-[#AC274A]/10 text-[#AC274A] rounded-full text-xs font-bold uppercase tracking-wide mb-3"><?php esc_html_e('Join Program', 'batsheva'); ?></div>
							<h2 id="batsheva-ask-rabbi-ai-title" class="text-3xl font-bold text-gray-900 mb-4"><?php esc_html_e('Ask the Rabbi AI', 'batsheva'); ?></h2>
							<p class="text-gray-600 leading-relaxed"><?php esc_html_e('Personalized guidance drawn from decades of Torah and Chassidic wisdom—helping you find clarity in purpose, faith, relationships, and your role in repairing the world.', 'batsheva'); ?></p>
						</div>
					</div>
					<div class="batsheva-soulgym-modal__aside bg-gray-50 border-l border-gray-100 p-8 flex flex-col justify-start">
						<h3 class="text-lg font-bold text-gray-900 mb-1"><?php esc_html_e('Get Started', 'batsheva'); ?></h3>
						<p class="text-sm text-gray-500 mb-6"><?php esc_html_e('Enter your email to subscribe specifically to this program.', 'batsheva'); ?></p>
						<form class="batsheva-soulgym-modal__form space-y-4" action="#" method="post">
							<div>
								<label for="<?php echo esc_attr($rabbi_email_id); ?>" class="block text-sm font-medium text-gray-700 mb-1"><?php esc_html_e('Email Address', 'batsheva'); ?></label>
								<div class="relative">
									<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-mail absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" aria-hidden="true"><rect width="20" height="16" x="2" y="4" rx="2"></rect><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"></path></svg>
									<input type="email" id="<?php echo esc_attr($rabbi_email_id); ?>" name="email" required class="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#AC274A] focus:border-[#AC274A] outline-none transition-all bg-white" placeholder="<?php esc_attr_e('you@example.com', 'batsheva'); ?>" autocomplete="email">
								</div>
							</div>
							<button type="submit" class="w-full bg-[#AC274A] hover:bg-[#8a1f3b] text-white font-bold py-3.5 rounded-xl transition-all shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 disabled:opacity-70 disabled:transform-none disabled:shadow-none"><?php esc_html_e('Reserve My Spot', 'batsheva'); ?></button>
							<div class="flex items-center gap-3 my-3">
								<div class="h-px bg-gray-200 flex-1"></div>
								<span class="text-gray-400 text-xs font-medium uppercase"><?php esc_html_e('or', 'batsheva'); ?></span>
								<div class="h-px bg-gray-200 flex-1"></div>
							</div>
							<button type="button" class="w-full bg-[#25D366] hover:bg-[#128C7E] text-white font-bold py-3.5 rounded-xl transition-all shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 flex items-center justify-center gap-2">
								<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-message-circle" aria-hidden="true"><path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z"></path></svg>
								<?php esc_html_e('Journey on WhatsApp', 'batsheva'); ?>
							</button>
							<div class="flex items-start gap-2 mt-4 text-xs text-gray-500 bg-white p-3 rounded-lg border border-gray-100">
								<div class="shrink-0 mt-0.5">
									<svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-circle-check-big text-green-500" aria-hidden="true"><path d="M21.801 10A10 10 0 1 1 17 3.335"></path><path d="m9 11 3 3L22 4"></path></svg>
								</div>
								<p><?php esc_html_e('Secure, spam-free, and you can unsubscribe at any time.', 'batsheva'); ?></p>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
