<?php
/**
 * Social follow modal (YouTube, Facebook, Instagram, fourth link).
 *
 * @package Batsheva
 */

defined('ABSPATH') || exit;
?>
		<div id="batsheva-social-modal" class="batsheva-modal batsheva-social-modal" hidden>
			<div class="batsheva-modal__backdrop" data-batsheva-modal-close tabindex="-1"></div>
			<div class="batsheva-modal__dialog batsheva-social-modal__dialog" role="dialog" aria-modal="true" aria-labelledby="batsheva-social-title">
				<button type="button" class="batsheva-modal__close batsheva-social-modal__close" data-batsheva-modal-close aria-label="<?php esc_attr_e('Close', 'batsheva'); ?>">
					<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 6 6 18"></path><path d="m6 6 12 12"></path></svg>
				</button>
				<div class="batsheva-social-modal__inner">
					<div class="batsheva-social-modal__body">
						<h3 id="batsheva-social-title" class="batsheva-social-modal__title"><?php esc_html_e('Follow us on social media', 'batsheva'); ?></h3>
						<div class="batsheva-social-modal__icons">
							<a href="<?php echo esc_url('https://www.youtube.com/user/MeaninfulLifeCenter'); ?>" class="batsheva-social-modal__icon-link" target="_blank" rel="noopener noreferrer" aria-label="<?php esc_attr_e('YouTube', 'batsheva'); ?>">
								<span class="batsheva-social-modal__icon batsheva-social-modal__icon--youtube" aria-hidden="true">
									<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="currentColor"><path d="M2.5 17a24.12 24.12 0 0 1 0-10 2 2 0 0 1 1.4-1.4 49.56 49.56 0 0 1 16.2 0A2 2 0 0 1 21.5 7a24.12 24.12 0 0 1 0 10 2 2 0 0 1-1.4 1.4 49.55 49.55 0 0 1-16.2 0A2 2 0 0 1 2.5 17"></path><path d="m10 15 5-3-5-3z"></path></svg>
								</span>
							</a>
							<a href="<?php echo esc_url('https://www.facebook.com/MeaningfulLifeCenter'); ?>" class="batsheva-social-modal__icon-link" target="_blank" rel="noopener noreferrer" aria-label="<?php esc_attr_e('Facebook', 'batsheva'); ?>">
								<span class="batsheva-social-modal__icon batsheva-social-modal__icon--facebook" aria-hidden="true">
									<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="currentColor"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path></svg>
								</span>
							</a>
							<a href="<?php echo esc_url('https://www.instagram.com/meaningfullifecenter'); ?>" class="batsheva-social-modal__icon-link" target="_blank" rel="noopener noreferrer" aria-label="<?php esc_attr_e('Instagram', 'batsheva'); ?>">
								<span class="batsheva-social-modal__icon batsheva-social-modal__icon--instagram" aria-hidden="true">
									<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="20" height="20" x="2" y="2" rx="5" ry="5"></rect><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path><line x1="17.5" x2="17.51" y1="6.5" y2="6.5"></line></svg>
								</span>
							</a>
							<a href="<?php echo esc_url('https://simonjacobson.ai'); ?>" class="batsheva-social-modal__icon-link" target="_blank" rel="noopener noreferrer" aria-label="<?php esc_attr_e('WhatsApp', 'batsheva'); ?>">
								<span class="batsheva-social-modal__icon batsheva-social-modal__icon--whatsapp" aria-hidden="true">
									<svg width="28" height="28" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path d="M17.472 14.382C17.119 14.205 15.385 13.351 15.061 13.235C14.736 13.118 14.499 13.06 14.264 13.412C14.029 13.765 13.352 14.558 13.146 14.793C12.94 15.029 12.734 15.058 12.381 14.882C12.028 14.706 10.892 14.333 9.546 13.133C8.498 12.199 7.791 11.046 7.615 10.741C7.438 10.436 7.596 10.273 7.773 10.097C7.932 9.938 8.127 9.683 8.304 9.477C8.481 9.271 8.54 9.124 8.657 8.889C8.775 8.654 8.716 8.448 8.627 8.272C8.539 8.096 7.833 6.362 7.539 5.657C7.253 4.972 6.963 5.065 6.747 5.065C6.549 5.065 6.324 5.065 6.098 5.065C5.872 5.065 5.509 5.15 5.205 5.481C4.901 5.811 4.039 6.621 4.039 8.267C4.039 9.913 5.235 11.505 5.412 11.74C5.588 11.975 7.777 15.352 11.13 16.8C11.928 17.145 12.551 17.35 13.044 17.506C13.845 17.761 14.577 17.728 15.155 17.642C15.801 17.546 17.149 16.827 17.43 16.035C17.711 15.243 17.711 14.568 17.623 14.421C17.535 14.274 17.295 14.177 16.942 14.001H17.472ZM12.005 21.765C10.233 21.765 8.577 21.312 7.126 20.499L6.822 20.318L3.064 21.305L4.088 17.646L3.896 17.34C2.986 15.892 2.507 14.2 2.507 12.459C2.507 7.224 6.766 2.965 12.005 2.965C14.542 2.965 16.927 3.953 18.721 5.747C20.515 7.541 21.503 9.926 21.503 12.463C21.503 17.707 17.24 21.765 12.005 21.765Z"></path></svg>
								</span>
							</a>
						</div>
					</div>
				</div>
			</div>
		</div>
