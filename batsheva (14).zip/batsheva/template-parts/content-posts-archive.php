<?php
/**
 * Blog / archive listing (plain HTML + theme CSS).
 *
 * @package Batsheva
 */

defined('ABSPATH') || exit;
?>
<div class="min-h-screen bg-background batsheva-simple-page batsheva-archive">
	<div class="batsheva-container">
		<header class="batsheva-simple-page__head">
			<h1 class="batsheva-simple-page__title"><?php echo esc_html(get_the_archive_title()); ?></h1>
			<?php
			$desc = get_the_archive_description();
			if ($desc) {
				echo '<div class="batsheva-simple-page__desc">' . wp_kses_post($desc) . '</div>';
			}
			?>
		</header>
		<?php if (have_posts()) : ?>
			<ul class="batsheva-archive-list">
				<?php
				while (have_posts()) :
					the_post();
					?>
					<li>
						<article class="batsheva-archive-card">
							<h2 class="batsheva-archive-card__title"><a href="<?php the_permalink(); ?>"><?php echo esc_html(get_the_title()); ?></a></h2>
							<time class="batsheva-archive-card__time" datetime="<?php echo esc_attr(get_the_date(DATE_W3C)); ?>"><?php echo esc_html(get_the_date()); ?></time>
							<?php if (has_excerpt() || get_the_excerpt()) : ?>
								<p class="batsheva-archive-card__excerpt"><?php echo esc_html(wp_strip_all_tags(get_the_excerpt())); ?></p>
							<?php endif; ?>
						</article>
					</li>
				<?php endwhile; ?>
			</ul>
			<?php
			the_posts_pagination(
				array(
					'mid_size'  => 2,
					'prev_text' => __('Newer', 'batsheva'),
					'next_text' => __('Older', 'batsheva'),
				)
			);
			?>
		<?php else : ?>
			<p class="batsheva-simple-page__empty"><?php esc_html_e('No posts found.', 'batsheva'); ?></p>
		<?php endif; ?>
	</div>
</div>
