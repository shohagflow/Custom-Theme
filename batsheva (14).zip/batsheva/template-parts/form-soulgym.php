<?php
/**
 * SoulGym program signup modal (two-column layout).
 *
 * @package Batsheva
 */

defined('ABSPATH') || exit;

$soulgym_email_id = 'batsheva-soulgym-email';
?>
		<div id="batsheva-soulgym-modal" class="batsheva-modal batsheva-soulgym-modal" hidden>
			<div class="batsheva-modal__backdrop" data-batsheva-modal-close tabindex="-1"></div>
			<div class="batsheva-modal__dialog batsheva-soulgym-modal__dialog" role="dialog" aria-modal="true" aria-labelledby="batsheva-soulgym-title">
				<button type="button" class="batsheva-modal__close" data-batsheva-modal-close aria-label="<?php esc_attr_e('Close', 'batsheva'); ?>">
					<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 6 6 18"></path><path d="m6 6 12 12"></path></svg>
				</button>
				<div class="batsheva-soulgym-modal__inner">
					<div class="batsheva-soulgym-modal__main p-8">
						<div>
							<div class="inline-block px-3 py-1 bg-[#AC274A]/10 text-[#AC274A] rounded-full text-xs font-bold uppercase tracking-wide mb-3"><?php esc_html_e('Join Program', 'batsheva'); ?></div>
							<h2 id="batsheva-soulgym-title" class="text-3xl font-bold text-gray-900 mb-4"><?php esc_html_e('SoulGym', 'batsheva'); ?></h2>
							<p class="text-gray-600 leading-relaxed"><?php esc_html_e('Practical insights and step-by-step exercises for personal growth and self-mastery drawn from ancient Jewish wisdom.', 'batsheva'); ?></p>
							<div class="batsheva-soulgym-highlights-wrap">
								<ul class="space-y-4">
									<li class="flex items-center gap-2 text-sm text-gray-700">
										<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-star text-[#AC274A] fill-[#AC274A]" aria-hidden="true"><path d="M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z"></path></svg>
										<span class="font-medium"><?php esc_html_e('New Spiritual Themes Every Week', 'batsheva'); ?></span>
									</li>
									<li class="flex items-center gap-2 text-sm text-gray-700">
										<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-star text-[#AC274A] fill-[#AC274A]" aria-hidden="true"><path d="M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z"></path></svg>
										<span class="font-medium"><?php esc_html_e('Daily Practices', 'batsheva'); ?></span>
									</li>
									<li class="flex items-center gap-2 text-sm text-gray-700">
										<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-star text-[#AC274A] fill-[#AC274A]" aria-hidden="true"><path d="M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z"></path></svg>
										<span class="font-medium"><?php esc_html_e('Spiritual Teachings', 'batsheva'); ?></span>
									</li>
									<li class="flex items-center gap-2 text-sm text-gray-700">
										<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-star text-[#AC274A] fill-[#AC274A]" aria-hidden="true"><path d="M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z"></path></svg>
										<span class="font-medium"><?php esc_html_e('Totally Free', 'batsheva'); ?></span>
									</li>
								</ul>
							</div>
							<div class="bg-gray-50 rounded-xl p-5 border border-gray-100">
								<h4 class="font-bold text-gray-900 mb-3 text-sm uppercase tracking-wide flex items-center gap-2">
									<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-gift text-[#AC274A]" aria-hidden="true"><rect x="3" y="8" width="18" height="4" rx="1"></rect><path d="M12 8v13"></path><path d="M19 12v7a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2v-7"></path><path d="M7.5 8a2.5 2.5 0 0 1 0-5A4.8 8 0 0 1 12 8a4.8 8 0 0 1 4.5-5 2.5 2.5 0 0 1 0 5"></path></svg>
									<?php esc_html_e('Membership Includes:', 'batsheva'); ?>
								</h4>
								<div class="space-y-4">
									<div class="flex gap-3">
										<div class="mt-1 bg-white p-1.5 rounded-lg border border-gray-100 shadow-sm shrink-0 h-fit">
											<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-book-open text-gray-500" aria-hidden="true"><path d="M12 7v14"></path><path d="M3 18a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h5a4 4 0 0 1 4 4 4 4 0 0 1 4-4h5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-6a3 3 0 0 0-3 3 3 3 0 0 0-3-3z"></path></svg>
										</div>
										<div>
											<div class="font-bold text-gray-900 text-sm"><?php esc_html_e('Soul Vitamin', 'batsheva'); ?></div>
											<div class="text-xs text-gray-500"><?php esc_html_e('Weekly inspirational video', 'batsheva'); ?></div>
										</div>
									</div>
									<div class="flex gap-3">
										<div class="mt-1 bg-white p-1.5 rounded-lg border border-gray-100 shadow-sm shrink-0 h-fit">
											<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-book-open text-gray-500" aria-hidden="true"><path d="M12 7v14"></path><path d="M3 18a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h5a4 4 0 0 1 4 4 4 4 0 0 1 4-4h5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-6a3 3 0 0 0-3 3 3 3 0 0 0-3-3z"></path></svg>
										</div>
										<div>
											<div class="font-bold text-gray-900 text-sm"><?php esc_html_e('Soul Workout', 'batsheva'); ?></div>
											<div class="text-xs text-gray-500"><?php esc_html_e('Weekly practical guide and exercise plan', 'batsheva'); ?></div>
										</div>
									</div>
									<div class="flex gap-3">
										<div class="mt-1 bg-white p-1.5 rounded-lg border border-gray-100 shadow-sm shrink-0 h-fit">
											<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-book-open text-gray-500" aria-hidden="true"><path d="M12 7v14"></path><path d="M3 18a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h5a4 4 0 0 1 4 4 4 4 0 0 1 4-4h5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-6a3 3 0 0 0-3 3 3 3 0 0 0-3-3z"></path></svg>
										</div>
										<div>
											<div class="font-bold text-gray-900 text-sm"><?php esc_html_e('Masterclass', 'batsheva'); ?></div>
											<div class="text-xs text-gray-500"><?php esc_html_e('Weekly virtual class with Rabbi Simon Jacobson', 'batsheva'); ?></div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="batsheva-soulgym-modal__aside bg-gray-50 p-8 flex flex-col justify-start">
						<h3 class="text-lg font-bold text-gray-900 mb-1"><?php esc_html_e('Get Started', 'batsheva'); ?></h3>
						<p class="text-sm text-gray-500 mb-6"><?php esc_html_e('Enter your email to subscribe specifically to this program.', 'batsheva'); ?></p>
						<form class="batsheva-soulgym-modal__form space-y-4" action="#" method="post">
							<div>
								<label for="<?php echo esc_attr($soulgym_email_id); ?>" class="block text-sm font-medium text-gray-700 mb-1"><?php esc_html_e('Email Address', 'batsheva'); ?></label>
								<div class="relative">
									<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-mail absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" aria-hidden="true"><rect width="20" height="16" x="2" y="4" rx="2"></rect><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"></path></svg>
									<input type="email" id="<?php echo esc_attr($soulgym_email_id); ?>" name="email" required class="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#AC274A] focus:border-[#AC274A] outline-none transition-all bg-white" placeholder="<?php esc_attr_e('you@example.com', 'batsheva'); ?>" autocomplete="email">
								</div>
							</div>
							<button type="submit" class="w-full bg-[#AC274A] hover:bg-[#8a1f3b] text-white font-bold py-3.5 rounded-xl transition-all shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 disabled:opacity-70 disabled:transform-none disabled:shadow-none"><?php esc_html_e('Start My Journey', 'batsheva'); ?></button>
							<div class="flex items-center gap-3 my-3">
								<div class="h-px bg-gray-200 flex-1"></div>
								<span class="text-gray-400 text-xs font-medium uppercase"><?php esc_html_e('or', 'batsheva'); ?></span>
								<div class="h-px bg-gray-200 flex-1"></div>
							</div>
							<button type="button" class="w-full bg-[#25D366] hover:bg-[#128C7E] text-white font-bold py-3.5 rounded-xl transition-all shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 flex items-center justify-center gap-2">
								<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-message-circle" aria-hidden="true"><path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z"></path></svg>
								<?php esc_html_e('Journey on WhatsApp', 'batsheva'); ?>
							</button>
							<div class="flex items-start gap-2 mt-4 text-xs text-gray-500 bg-white p-3 rounded-lg border border-gray-100">
								<div class="shrink-0 mt-0.5">
									<svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-circle-check-big text-green-500" aria-hidden="true"><path d="M21.801 10A10 10 0 1 1 17 3.335"></path><path d="m9 11 3 3L22 4"></path></svg>
								</div>
								<p><?php esc_html_e('Secure, spam-free, and you can unsubscribe at any time.', 'batsheva'); ?></p>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
