<?php
/**
 * Default HTML body for the Privacy Policy page (placeholder / lorem).
 *
 * @package Batsheva
 */

defined('ABSPATH') || exit;

/**
 * Returns default post_content HTML for the Privacy Policy page.
 *
 * @return string
 */
function batsheva_get_privacy_policy_default_content() {
	return <<<'HTML'
<p class="batsheva-legal-lead">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>

<h2>1. Information we collect</h2>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante venenatis dapibus posuere velit aliquet. Maecenas faucibus mollis interdum. Cras mattis consectetur purus sit amet fermentum. Nulla vitae elit libero, a pharetra augue.</p>
<p>Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Curabitur blandit tempus porttitor. Aenean lacinia bibendum nulla sed consectetur.</p>

<h3>1.1 Information you provide</h3>
<ul>
<li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
<li>Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor.</li>
<li>Donec id elit non mi porta gravida at eget metus.</li>
</ul>

<h3>1.2 Automatically collected data</h3>
<p>Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Praesent commodo cursus magna, vel scelerisque nisl consectetur et.</p>

<h2>2. How we use your information</h2>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Sed posuere consectetur est at lobortis. Integer posuere erat a ante venenatis dapibus posuere velit aliquet.</p>

<h2>3. Cookies and similar technologies</h2>
<p>Nullam quis risus eget urna mollis ornare vel eu leo. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec ullamcorper nulla non metus auctor fringilla. Vestibulum id ligula porta felis euismod semper.</p>

<h2>4. Data retention</h2>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi leo risus, porta ac consectetur ac, vestibulum at eros. Maecenas sed diam eget risus varius blandit sit amet non magna.</p>

<h2>5. Your rights</h2>
<p>Depending on your location, you may have certain rights regarding your personal data. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras justo odio, dapibus ac facilisis in, egestas eget quam.</p>
<ul>
<li>Right to access — lorem ipsum dolor sit amet.</li>
<li>Right to rectification — consectetur adipiscing elit.</li>
<li>Right to erasure — sed do eiusmod tempor incididunt.</li>
</ul>

<h2>6. Third-party services</h2>
<p>We may use trusted third-party services that collect, monitor, and analyze information. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean lacinia bibendum nulla sed consectetur.</p>

<h2>7. Contact us</h2>
<p>If you have questions about this Privacy Policy, please contact us. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Email: <a href="mailto:privacy@example.com">privacy@example.com</a> (placeholder).</p>
HTML;
}
