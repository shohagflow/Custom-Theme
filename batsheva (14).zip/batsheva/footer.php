<?php
/**
 * Theme footer.
 *
 * @package Batsheva
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<?php wp_footer(); ?>
</body>
</html>
