<?php
/**
 * Site front page (static “Home” or “latest posts” on front). Renders the PHP landing.
 *
 * @package Batsheva
 */

defined('ABSPATH') || exit;

get_header();
?>
<div class="min-h-screen bg-background">
	<main id="primary" class="site-main" role="main">
		<?php get_template_part('template-parts/home-landing'); ?>
	</main>
</div>
<?php
get_footer();
