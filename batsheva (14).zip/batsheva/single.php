<?php
/**
 * Single post template.
 *
 * @package Batsheva
 */

get_header();
?>
<main id="primary" class="site-main" role="main">
	<?php get_template_part('template-parts/content-single'); ?>
</main>
<?php
get_footer();
