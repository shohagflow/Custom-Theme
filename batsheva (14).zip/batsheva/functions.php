﻿<?php
/**
 * Batsheva theme — PHP templates, compiled CSS in /assets/css (Tailwind-style utilities + scoped blocks).
 *
 * @package Batsheva
 */

if (!defined('ABSPATH')) {
	exit;
}

define('BATSheVA_PATH', get_template_directory());
define('BATSheVA_URI', get_template_directory_uri());

require_once BATSheVA_PATH . '/inc/privacy-policy-default-content.php';

/** Built stylesheet (relative to theme root). */
define('BATSheVA_ASSETS_CSS', '/assets/css/index.css');

/**
 * Enqueue compiled CSS (no React / no SPA bundle).
 */
function batsheva_enqueue_built_assets() {
	if (is_admin()) {
		return;
	}

	$css_path = BATSheVA_PATH . BATSheVA_ASSETS_CSS;

	if (! is_readable($css_path)) {
		return;
	}

	$v_css = (string) filemtime($css_path);

	wp_enqueue_style(
		'batsheva-theme',
		BATSheVA_URI . BATSheVA_ASSETS_CSS,
		array(),
		$v_css
	);

	$theme_js_path = BATSheVA_PATH . '/assets/js/theme.js';
	if (is_readable($theme_js_path)) {
		wp_enqueue_script(
			'batsheva-theme',
			BATSheVA_URI . '/assets/js/theme.js',
			array(),
			(string) filemtime($theme_js_path),
			true
		);
	}
}
add_action('wp_enqueue_scripts', 'batsheva_enqueue_built_assets');

/**
 * Admin notice when built CSS is missing.
 */
function batsheva_admin_notice_missing_build() {
	if (! current_user_can('manage_options')) {
		return;
	}
	$css = BATSheVA_PATH . BATSheVA_ASSETS_CSS;
	if (is_readable($css)) {
		return;
	}
	echo '<div class="notice notice-error"><p>';
	esc_html_e('Batsheva: upload assets/css/index.css.', 'batsheva');
	echo '</p></div>';
}
add_action('admin_notices', 'batsheva_admin_notice_missing_build');

/**
 * Theme setup.
 */
function batsheva_setup() {
	load_theme_textdomain('batsheva', BATSheVA_PATH . '/languages');
	add_theme_support('title-tag');
	add_theme_support('post-thumbnails');
	add_theme_support(
		'html5',
		array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
			'style',
			'script',
		)
	);
	add_theme_support(
		'custom-logo',
		array(
			'height'      => 120,
			'width'       => 120,
			'flex-height' => true,
			'flex-width'  => true,
		)
	);
}
add_action('after_setup_theme', 'batsheva_setup');

/**
 * Ensure a published Privacy Policy page exists (slug: privacy-policy, lorem placeholder body).
 * Creation runs when the theme is activated and on admin requests (cannot insert posts from a front-end visitor).
 */
function batsheva_ensure_privacy_policy_page() {
	if (! current_user_can('publish_pages')) {
		return;
	}
	if (get_page_by_path('privacy-policy', OBJECT, 'page')) {
		return;
	}

	$author_id = (int) get_current_user_id();
	if ($author_id < 1) {
		$admins = get_users(
			array(
				'role'    => 'administrator',
				'number'  => 1,
				'orderby' => 'ID',
				'order'   => 'ASC',
				'fields'  => array('ID'),
			)
		);
		$author_id = ! empty($admins[0]->ID) ? (int) $admins[0]->ID : 1;
	}

	$post_id = wp_insert_post(
		array(
			'post_title'     => __('Privacy Policy', 'batsheva'),
			'post_name'      => 'privacy-policy',
			'post_status'    => 'publish',
			'post_type'      => 'page',
			'post_content'   => batsheva_get_privacy_policy_default_content(),
			'post_author'    => $author_id,
			'comment_status' => 'closed',
			'ping_status'    => 'closed',
		),
		true
	);

	if (is_wp_error($post_id) || $post_id < 1) {
		return;
	}
}
add_action('after_switch_theme', 'batsheva_ensure_privacy_policy_page');
add_action('admin_init', 'batsheva_ensure_privacy_policy_page', 30);

/**
 * Permalink for the Privacy Policy page, or a best-guess URL before the page exists.
 *
 * @return string
 */
function batsheva_get_privacy_policy_url() {
	$page = get_page_by_path('privacy-policy', OBJECT, 'page');
	if ($page instanceof WP_Post && $page->post_status === 'publish') {
		return get_permalink($page);
	}
	return home_url('/privacy-policy/');
}

/**
 * Set front page to static when the site still shows the blog on the homepage.
 *
 * @param int $page_id Page ID for the landing.
 */
function batsheva_maybe_set_static_front_page($page_id) {
	$page_id = (int) $page_id;
	if ($page_id <= 0) {
		return;
	}

	$show_on_front  = (string) get_option('show_on_front', 'posts');
	$page_on_front = (int) get_option('page_on_front', 0);

	if ($show_on_front === 'posts') {
		update_option('show_on_front', 'page');
		update_option('page_on_front', $page_id);
		return;
	}

	if ($show_on_front === 'page' && $page_on_front === 0) {
		update_option('page_on_front', $page_id);
	}
}

/**
 * On theme activation: ensure a published "Home" page exists and set it as the static
 * front page when WP still uses "Your latest posts". Landing markup comes from front-page.php
 * + template-parts/home-landing.php (no custom page template file).
 *
 * Runs once per site (option batsheva_pages_seeded). Uses after_switch_theme.
 */
function batsheva_seed_default_pages() {
	if (get_option('batsheva_pages_seeded', false)) {
		return;
	}

	$home_page = get_page_by_path('home', OBJECT, 'page');

	if ($home_page instanceof WP_Post) {
		$page_id = (int) $home_page->ID;
		$current = (string) get_post_meta($page_id, '_wp_page_template', true);
		if ($current === 'page-templates/template-home.php') {
			delete_post_meta($page_id, '_wp_page_template');
		}
		batsheva_maybe_set_static_front_page($page_id);
		update_option('batsheva_pages_seeded', 1);
		return;
	}

	$author_id = (int) get_current_user_id();
	if ($author_id < 1) {
		$admins = get_users(
			array(
				'role'    => 'administrator',
				'number'  => 1,
				'orderby' => 'ID',
				'order'   => 'ASC',
				'fields'  => array('ID'),
			)
		);
		if (! empty($admins[0]->ID)) {
			$author_id = (int) $admins[0]->ID;
		} else {
			$author_id = 1;
		}
	}

	$page_id = wp_insert_post(
		array(
			'post_title'     => __('Home', 'batsheva'),
			'post_name'      => 'home',
			'post_status'    => 'publish',
			'post_type'      => 'page',
			'post_content'   => '',
			'post_author'    => $author_id,
			'comment_status' => 'closed',
			'ping_status'    => 'closed',
		),
		true
	);

	if (is_wp_error($page_id) || $page_id < 1) {
		return;
	}

	batsheva_maybe_set_static_front_page((int) $page_id);
	update_option('batsheva_pages_seeded', 1);
}
add_action('after_switch_theme', 'batsheva_seed_default_pages');

/**
 * Static "Choose Your Path" offerings data (not from the database or admin).
 *
 * @return array<string,mixed>
 */
function batsheva_get_static_offerings_data() {
	$assets = trailingslashit(get_template_directory_uri()) . 'assets/images/';

	return array(
		'program1' => array(
			'image' => $assets . 'card-inspiration.png',
			'title' => __('I want Inspiration', 'batsheva'),
			'lede'  => __('Weekly doses of wisdom to uplift your spirit.', 'batsheva'),
			'rows'  => array(
				array('title' => __('SoulGym', 'batsheva'), 'desc' => __('Weekly bite-sized spiritual tools.', 'batsheva'), 'form' => 'soulgym'),
				array('title' => __('Masterclass', 'batsheva'), 'desc' => __('In-depth weekly lectures.', 'batsheva'), 'form' => 'masterclass'),
				array('title' => __('Weekly Newsletter', 'batsheva'), 'desc' => __('Curated insights in your inbox.', 'batsheva'), 'form' => 'newsletter'),
			),
		),
		'program2' => array(
			'image'           => $assets . 'card-journey.png',
			'title'           => __('I want a Guided Journey', 'batsheva'),
			'lede'            => __('Time-bound journeys based on the Jewish calendar and beyond', 'batsheva'),
			'spotlight_badge' => __('Now Open', 'batsheva'),
			'spotlight_title' => __('Omer Journey', 'batsheva'),
			'spotlight_desc'  => __('49 Days of inner refinement', 'batsheva'),
			'spotlight_meta'  => __('Begins April 2', 'batsheva'),
			'spotlight_cta'   => __('Reserve My Spot', 'batsheva'),
			'spotlight_form'  => 'omer',
			'row_title'       => __('15 Steps to Freedom', 'batsheva'),
			'row_desc'        => __('A free downloadable guide to your Passover seder.', 'batsheva'),
			'row_form'        => 'steps_freedom',
		),
		'program3' => array(
			'image' => $assets . 'card-engage.png',
			'title' => __('I want to Ask & Engage', 'batsheva'),
			'lede'  => __('Interactive tools and community connection.', 'batsheva'),
			'rows'  => array(
				array('title' => __('Ask the Rabbi AI', 'batsheva'), 'desc' => __('Instant answers to your questions.', 'batsheva'), 'form' => 'ask_rabbi_ai'),
				array('title' => __('Podcast', 'batsheva'), 'desc' => __('Listen on the go.', 'batsheva'), 'form' => 'podcast'),
				array('title' => __('Social Media', 'batsheva'), 'desc' => __('Join the conversation online.', 'batsheva'), 'form' => 'social'),
			),
		),
		'program4' => array(
			'image'      => $assets . rawurlencode('deep larning.png'),
			'brand_name' => 'MyLife',
			'brand_tag'  => __('Chassidus Applied', 'batsheva'),
			'title'      => __('I want Deep Learning', 'batsheva'),
			'subtitle'   => __('For advanced Chassidic thought students only.', 'batsheva'),
			'rows'       => array(
				array('title' => __('Ayin Bais', 'batsheva'), 'desc' => __('The 1912 series of discourses.', 'batsheva'), 'form' => 'ayin_bais'),
				array('title' => __('Samach Vav', 'batsheva'), 'desc' => __('Fundamental Chassidic concepts.', 'batsheva'), 'form' => 'samach_vav'),
				array('title' => __('Tanya Applied', 'batsheva'), 'desc' => __('Deepest teachings applied.', 'batsheva'), 'form' => 'tanya_applied'),
				array('title' => __('MyLife: Chassidus Applied', 'batsheva'), 'desc' => __('Weekly real-life guidance', 'batsheva'), 'form' => 'mylife_chassidus_applied'),
			),
		),
	);
}
