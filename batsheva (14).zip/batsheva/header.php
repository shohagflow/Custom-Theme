<?php
/**
 * Opening document only: doctype, head (charset, viewport, {@see wp_head()}), opening body.
 * No visible header / navigation markup here — page templates (e.g. landing) provide layout sections.
 *
 * @package Batsheva
 */

if (!defined('ABSPATH')) {
    exit;
}
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
