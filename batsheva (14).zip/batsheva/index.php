<?php
/**
 * Blog / archive views: posts page (Reading → “Posts page”), category, tag, date, author, and theme fallback.
 * Site front uses front-page.php instead.
 *
 * @package Batsheva
 */

get_header();
?>
<main id="primary" class="site-main" role="main">
	<?php get_template_part('template-parts/content-posts-archive'); ?>
</main>
<?php
get_footer();
