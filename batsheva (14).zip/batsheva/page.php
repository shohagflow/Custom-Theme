<?php
/**
 * Default page template — page title + content (PHP/HTML only).
 *
 * @package Batsheva
 */

get_header();
?>
<main id="primary" class="site-main" role="main">
	<?php get_template_part('template-parts/content-page'); ?>
</main>
<?php
get_footer();
