/**
 * Theme front-end (vanilla JS only). No React.
 */
(function () {
	'use strict';

	var modalRegistry = [];

	function initBatshevaModal(cfg) {
		var openBtns = document.querySelectorAll(cfg.openSelector);
		var modal = document.getElementById(cfg.modalId);
		if (!modal || openBtns.length === 0) {
			return;
		}

		var closers = modal.querySelectorAll('[data-batsheva-modal-close]');
		var dialog = modal.querySelector('.batsheva-modal__dialog');
		var lastTrigger = openBtns[0];

		function setTriggersExpanded(expanded) {
			var v = expanded ? 'true' : 'false';
			openBtns.forEach(function (btn) {
				btn.setAttribute('aria-expanded', v);
			});
		}

		function getFocusable() {
			return modal.querySelectorAll(
				'button:not([disabled]), [href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'
			);
		}

		function lockScroll() {
			/* Intentionally keep page scrollbar behavior unchanged while modal is open. */
		}

		function unlockScroll() {
			/* No-op: do not alter document scroll state. */
		}

		function openModal() {
			if (!modal.hasAttribute('hidden')) {
				return;
			}
			modal.classList.remove('batsheva-modal--open');
			modal.removeAttribute('hidden');
			lockScroll();
			setTriggersExpanded(true);
			requestAnimationFrame(function () {
				requestAnimationFrame(function () {
					modal.classList.add('batsheva-modal--open');
				});
			});
			window.setTimeout(function () {
				var focusable = getFocusable();
				if (focusable.length && !modal.hasAttribute('hidden')) {
					focusable[0].focus();
				}
			}, 50);
		}

		function closeModal() {
			if (modal.hasAttribute('hidden')) {
				return;
			}
			modal.classList.remove('batsheva-modal--open');
			var finished = false;
			function done() {
				if (finished) {
					return;
				}
				finished = true;
				if (dialog) {
					dialog.removeEventListener('transitionend', onTransitionEnd);
				}
				modal.setAttribute('hidden', '');
				unlockScroll();
				setTriggersExpanded(false);
				if (lastTrigger && typeof lastTrigger.focus === 'function') {
					lastTrigger.focus();
				}
			}
			function onTransitionEnd(e) {
				if (e.target === dialog) {
					done();
				}
			}
			if (dialog) {
				dialog.addEventListener('transitionend', onTransitionEnd);
			}
			window.setTimeout(done, 380);
		}

		openBtns.forEach(function (btn) {
			btn.addEventListener('click', function (e) {
				e.preventDefault();
				lastTrigger = btn;
				openModal();
			});
		});

		closers.forEach(function (el) {
			el.addEventListener('click', function (e) {
				e.preventDefault();
				closeModal();
			});
		});

		var form = modal.querySelector('.batsheva-soulgym-modal__form');
		if (form) {
			form.addEventListener('submit', function (e) {
				e.preventDefault();
			});
		}

		modalRegistry.push({
			modal: modal,
			dialog: dialog,
			getFocusable: getFocusable,
			closeModal: closeModal,
		});
	}

	function getActiveModalEntry() {
		var i;
		for (i = 0; i < modalRegistry.length; i++) {
			if (!modalRegistry[i].modal.hasAttribute('hidden')) {
				return modalRegistry[i];
			}
		}
		return null;
	}

	function onDocumentKeydown(e) {
		var entry = getActiveModalEntry();
		if (!entry) {
			return;
		}
		if (e.key === 'Escape') {
			e.preventDefault();
			entry.closeModal();
			return;
		}
		if (e.key !== 'Tab' || !entry.dialog) {
			return;
		}
		var nodes = entry.getFocusable();
		if (nodes.length === 0) {
			return;
		}
		var first = nodes[0];
		var last = nodes[nodes.length - 1];
		if (e.shiftKey) {
			if (document.activeElement === first) {
				e.preventDefault();
				last.focus();
			}
		} else if (document.activeElement === last) {
			e.preventDefault();
			first.focus();
		}
	}

	function boot() {
		initBatshevaModal({
			openSelector: '.batsheva-js-undecided-open',
			modalId: 'batsheva-undecided-modal',
		});
		initBatshevaModal({
			openSelector: '.batsheva-js-soulgym-open',
			modalId: 'batsheva-soulgym-modal',
		});
		initBatshevaModal({
			openSelector: '.batsheva-js-masterclass-open',
			modalId: 'batsheva-masterclass-modal',
		});
		initBatshevaModal({
			openSelector: '.batsheva-js-newsletter-open',
			modalId: 'batsheva-newsletter-modal',
		});
		initBatshevaModal({
			openSelector: '.batsheva-js-podcast-open',
			modalId: 'batsheva-podcast-modal',
		});
		initBatshevaModal({
			openSelector: '.batsheva-js-social-open',
			modalId: 'batsheva-social-modal',
		});
		initBatshevaModal({
			openSelector: '.batsheva-js-omer-open',
			modalId: 'batsheva-omer-modal',
		});
		initBatshevaModal({
			openSelector: '.batsheva-js-steps-freedom-open',
			modalId: 'batsheva-steps-freedom-modal',
		});
		initBatshevaModal({
			openSelector: '.batsheva-js-ask-rabbi-ai-open',
			modalId: 'batsheva-ask-rabbi-ai-modal',
		});
		initBatshevaModal({
			openSelector: '.batsheva-js-ayin-bais-open',
			modalId: 'batsheva-ayin-bais-modal',
		});
		initBatshevaModal({
			openSelector: '.batsheva-js-samach-vav-open',
			modalId: 'batsheva-samach-vav-modal',
		});
		initBatshevaModal({
			openSelector: '.batsheva-js-tanya-applied-open',
			modalId: 'batsheva-tanya-applied-modal',
		});
		initBatshevaModal({
			openSelector: '.batsheva-js-mylife-chassidus-applied-open',
			modalId: 'batsheva-mylife-chassidus-applied-modal',
		});

		document.addEventListener('keydown', onDocumentKeydown);
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', boot);
	} else {
		boot();
	}
})();
