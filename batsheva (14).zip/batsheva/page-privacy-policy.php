<?php
/**
 * Privacy Policy page template (slug: privacy-policy).
 *
 * @package Batsheva
 */

defined('ABSPATH') || exit;

get_header();
?>
<main id="primary" class="site-main" role="main">
	<?php get_template_part('template-parts/content-privacy-policy'); ?>
</main>
<?php
get_footer();
